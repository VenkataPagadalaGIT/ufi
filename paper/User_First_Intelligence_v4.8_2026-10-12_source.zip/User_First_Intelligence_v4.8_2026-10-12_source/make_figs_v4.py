"""Figures for manuscript v4.x. Vector PDF for XeLaTeX, 300 dpi PNG for DOCX.
Grayscale-safe: series differ by marker shape, line style and hatch, never by hue alone.
Grid and axes are solid hairlines; direct labels only where they carry the point."""
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.ticker import FuncFormatter, LogLocator, NullFormatter
import matplotlib.patches as mpatches

for f in ["FreeSerif", "FreeSerifBold", "FreeSerifItalic", "FreeSerifBoldItalic"]:
    font_manager.fontManager.addfont(f"/usr/share/fonts/truetype/freefont/{f}.ttf")
plt.rcParams.update({
    "font.family": "FreeSerif", "font.size": 8, "axes.titlesize": 8.5, "axes.labelsize": 8,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5,
    "axes.linewidth": 0.6, "pdf.fonttype": 42, "hatch.linewidth": 0.5,
    "axes.spines.top": False, "axes.spines.right": False,
})
OUT = "/home/claude/paper04/tex/"
K = FuncFormatter(lambda v, p: f"{v/1e6:g}M" if v >= 1e6 else (f"{v/1e3:g}K" if v >= 1e3 else f"{v:g}"))

def tidy(ax, ygrid=True):
    if ygrid: ax.grid(axis="y", color="0.88", lw=0.5)
    ax.set_axisbelow(True)

def save(fig, name):
    fig.savefig(OUT + name + ".pdf", bbox_inches="tight", pad_inches=0.02)
    fig.savefig(OUT + name + ".png", dpi=300, bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)

# ---------------------------------------------------------------- Fig 1: one prefix, two instruments
months = ["Jul 2026\n(total)", "Aug 2026\n(total)", "Sep 2026\n(total)", "Oct 2026\n(run-rate)"]
ahrefs = [3862, 32281, 150113, 215577]
sem_us = [100012, 876153, 1534362, 1610284]
sem_ww = [103045, 963937, 1765077, 1858297]
x = list(range(4))
fig, ax = plt.subplots(figsize=(3.3, 2.5))
ax.plot(x, sem_ww, color="0.55", lw=0.9, ls=":", marker="^", ms=3.4, mfc="white", label="Semrush, worldwide")
ax.plot(x, sem_us, color="black", lw=1.2, ls="--", marker="s", ms=3.2, label="Semrush, US database")
ax.plot(x, ahrefs, color="black", lw=1.2, marker="o", ms=3.4, label="Ahrefs, worldwide")
ax.set_yscale("log"); ax.set_ylim(2e3, 4e6)
ax.yaxis.set_major_formatter(K)
ax.yaxis.set_major_locator(LogLocator(base=10, numticks=5))
ax.yaxis.set_minor_formatter(NullFormatter())
ax.set_xticks(x); ax.set_xticklabels(months)
ax.set_ylabel("Estimated monthly visits (log)")
for xi, a, s, r in zip(x, ahrefs, sem_us, ["25.9x", "27.1x", "10.2x", "7.5x"]):
    ax.annotate("", xy=(xi, s), xytext=(xi, a), arrowprops=dict(arrowstyle="-", lw=0.5, color="0.35"))
    ax.text(xi + 0.07, math.sqrt(a * s), r, fontsize=7.5, va="center", ha="left")
ax.legend(loc="lower right", frameon=False, handlelength=2.6)
tidy(ax)
save(fig, "fig1_divergence")

# ---------------------------------------------------------------- Fig 2: twelve prefixes
pref = [("/local/area-codes/", 3, 7.24, 2.0), ("/product-compare/", 21, 0.75, 3.2), ("/local/bundles/", 36, 0.20, 16.1),
        ("/device-compare/", 39, 0.99, 5.2), ("/local/cell-phones/", 57, 3.62, 10.4), ("/support/", 93, 1.03, 9.1),
        ("/local/fiber/", 95, 0.46, 5.9), ("/buy/", 95, 1.57, 10.4), ("/local/internet/", 114, 0.91, 6.0),
        ("/stores/", 129, 6.57, 20.9), ("/deals/", 132, 1.03, 6.0), ("/es-us/local/", 133, 0.25, 3.7)]
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 2.6), sharey=True, gridspec_kw={"wspace": 0.08})
for ax in (a1, a2):
    ax.set_yscale("log"); ax.set_ylim(0.12, 12)
    ax.set_yticks([0.2, 0.5, 1, 2, 5, 10]); ax.set_yticklabels(["0.2x", "0.5x", "1x", "2x", "5x", "10x"])
    ax.yaxis.set_minor_formatter(NullFormatter())
    ax.axhline(1, color="0.5", lw=0.7)
    tidy(ax)
for name, age, vr, kr in pref:
    is_ac = "area-codes" in name
    for ax, xv in ((a1, age), (a2, kr)):
        ax.plot(xv, vr, marker="o", ms=5.5 if is_ac else 4.2, mfc="black" if is_ac else "white",
                mec="black", mew=0.8, ls="none")
a1.set_xscale("log"); a1.set_xlim(2, 200)
a1.set_xticks([3, 10, 30, 100]); a1.set_xticklabels(["3", "10", "30", "100"])
a1.xaxis.set_minor_formatter(NullFormatter())
a1.set_xlabel("Section age, months since first organic traffic (log)")
a1.set_ylabel("Semrush / Ahrefs, estimated visits (log)")
a1.set_title("(a) Divergence against age. Spearman ρ = −0.11", loc="left")
a2.set_xscale("log"); a2.set_xlim(1.5, 30)
a2.set_xticks([2, 5, 10, 20]); a2.set_xticklabels(["2x", "5x", "10x", "20x"])
a2.xaxis.set_minor_formatter(NullFormatter())
a2.set_xlabel("Semrush / Ahrefs, ranking keywords (log)")
a2.set_title("(b) Divergence against keyword-universe ratio", loc="left")
for ax, xk in ((a1, 1), (a2, 3)):
    for name, age, vr, kr in pref:
        if name in ("/local/area-codes/", "/local/bundles/", "/stores/", "/es-us/local/"):
            xv = (age, kr)[0 if xk == 1 else 1]
            right_edge = (xk == 1 and xv > 100) or (xk == 3 and xv > 15)
            ax.text(xv * (0.9 if right_edge else 1.12), vr, name, fontsize=6.8, va="center",
                    ha="right" if right_edge else "left")
a1.text(2.2, 0.14, "filled marker: the section followed in Sections 5.1 to 5.4 and 6 to 8",
        fontsize=6.8, color="0.3", ha="left", va="bottom")
save(fig, "fig4_prefixes")

# ---------------------------------------------------------------- Fig 3: positions, link arrival, interval rates
days = [0, 6, 15, 30, 37, 45, 60, 67, 75, 77]
pos_all = [2, 984, 3385, 14905, 15830, 20326, 37141, 38801, 43302, 43980]
pos_top3 = [0, 186, 727, 1801, 1874, 2649, 5822, 6942, 8753, 9239]
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(7.0, 4.3), sharex=True,
                               gridspec_kw={"height_ratios": [1.6, 1.0], "hspace": 0.1})
ax1.axvspan(37, 45, facecolor="none", edgecolor="0.45", hatch="////", lw=0, zorder=0)
ax1.text(41, 8200, "automated link\nnetwork arriving", fontsize=7, ha="center", va="center", color="0.2",
         bbox=dict(facecolor="white", edgecolor="none", pad=1.5))
for ax in (ax1, ax2):
    ax.axvline(60, color="0.5", lw=0.7, ls="-"); ax.axvline(65, color="0.5", lw=0.7, ls="-")
    ax.axvline(37, color="black", lw=0.9)
ax1.text(59.6, 26500, "spam update\n(day 60)", fontsize=6.8, color="0.3", va="center", ha="right")
ax1.text(65.4, 20500, "vendor data\nnotice (day 65)", fontsize=6.8, color="0.3", va="center", ha="left")
ax1.text(36.4, 30000, "day 37:\nprimary\ncheckpoint", fontsize=7, ha="right", va="center")
ax1.plot(days, pos_all, color="black", lw=1.2, marker="o", ms=3.2, label="ranking positions, all (1–100)")
ax1.plot(days, pos_top3, color="0.4", lw=1.0, ls="--", marker="s", ms=2.8, mfc="white", label="positions 1–3")
ax1.set_ylim(0, 48000); ax1.set_yticks([0, 15000, 30000, 45000]); ax1.yaxis.set_major_formatter(K)
ax1.set_ylabel("Ranking positions (Ahrefs,\nprefix mode, all locations)")
ax1.legend(loc="upper left", frameon=False, handlelength=2.4)
ax1.annotate("15,830", xy=(37, 15830), xytext=(24, 20500), fontsize=7.5,
             arrowprops=dict(arrowstyle="-", lw=0.5, color="0.3"))
ax1.annotate("43,980", xy=(77, 43980), xytext=(70.5, 46500), fontsize=7.5)
for d, n in [(30, 19), (37, 19), (45, 415), (60, 828), (75, 909)]:
    ax1.text(d, 49500, f"{n}", fontsize=6.8, ha="center", va="bottom", color="0.25", clip_on=False)
ax1.text(-1, 49500, "live referring domains:", fontsize=6.8, ha="left", va="bottom", color="0.25", clip_on=False)
tidy(ax1)
iv = [(0, 15, 226, "clean"), (15, 30, 768, "clean"), (30, 37, 132, "clean"),
      (37, 45, 562, "arriving"), (45, 60, 1121, "present"), (60, 75, 411, "present")]
for a, b, r, st in iv:
    hatch = {"clean": "", "arriving": "////", "present": "...."}[st]
    fc = {"clean": "0.75", "arriving": "white", "present": "white"}[st]
    ax2.bar((a + b) / 2, r, width=(b - a) - 0.6, color=fc, edgecolor="0.3", lw=0.6, hatch=hatch)
    ax2.text((a + b) / 2, r + 25, f"{r}", fontsize=7, ha="center", va="bottom")
ax2.set_ylim(0, 1550); ax2.set_yticks([0, 400, 800, 1200])
ax2.set_ylabel("Positions gained\nper day, by interval")
ax2.set_xlim(-1.5, 80); ax2.set_xticks([0, 15, 30, 37, 45, 60, 75])
ax2.set_xticklabels(["day 0\n26 Jul", "15\n10 Aug", "30\n25 Aug", "37\n1 Sep", "45\n9 Sep", "60\n24 Sep", "75\n9 Oct"])
ax2.set_xlabel("Days since first third-party detection of the section (26 July 2026)")
ax2.legend(handles=[mpatches.Patch(facecolor="0.75", edgecolor="0.3", label="no network"),
                    mpatches.Patch(facecolor="white", edgecolor="0.3", hatch="////", label="network arriving"),
                    mpatches.Patch(facecolor="white", edgecolor="0.3", hatch="....", label="network present")],
           loc="upper right", frameon=False, ncol=3, handlelength=1.6)
tidy(ax2)
save(fig, "fig6_positions")

# ---------------------------------------------------------------- Fig 4: AI Overview, two instruments
mo = ["Jul", "Aug", "Sep", "Oct"]
num = [47, 851, 3380, 7455]; den = [284, 6749, 22665, 37238]; semb = [138, 2221, 8187, 10018]
def wilson(k, n, z=1.96):
    p = k / n; d = 1 + z * z / n; c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return c - h, c + h
fig, (b1, b2) = plt.subplots(1, 2, figsize=(7.0, 2.5), gridspec_kw={"wspace": 0.3})
share = [k / n for k, n in zip(num, den)]
lo = [share[i] - wilson(num[i], den[i])[0] for i in range(4)]
hi = [wilson(num[i], den[i])[1] - share[i] for i in range(4)]
b1.errorbar(x, [s * 100 for s in share], yerr=[[v * 100 for v in lo], [v * 100 for v in hi]],
            fmt="o", color="black", ms=3.6, capsize=2.5, lw=0.9)
b1.set_ylim(0, 28); b1.set_xticks(x); b1.set_xticklabels([f"{m}\nn = {n:,}" for m, n in zip(mo, den)])
b1.set_ylabel("Definition (a): cited / all AIO\nkeywords the prefix ranks on, %")
b1.set_title("(a) Ahrefs share, 95% Wilson intervals", loc="left")
tidy(b1)
b2.plot(x, semb, color="black", lw=1.2, ls="--", marker="s", ms=3.2, label="(b) Semrush count")
b2.plot(x, num, color="black", lw=1.2, marker="o", ms=3.4, label="(a) Ahrefs numerator")
b2.set_yscale("log"); b2.set_ylim(30, 20000); b2.yaxis.set_major_formatter(K); b2.yaxis.set_minor_formatter(NullFormatter())
for xi, a, s, r in zip(x, num, semb, ["2.94x", "2.61x", "2.42x", "1.34x"]):
    b2.text(xi + 0.07, math.sqrt(a * s), r, fontsize=7.5, va="center", ha="left")
b2.set_xticks(x); b2.set_xticklabels(mo); b2.set_ylabel("Keywords (log)")
b2.set_title("(b) Two vendor counts, same months", loc="left")
b2.legend(loc="lower right", frameon=False, handlelength=2.6)
tidy(b2)
save(fig, "fig2_aio")

# ---------------------------------------------------------------- Fig 5: which pages are cited
pages = [("New York hub", 474, True), ("California hub", 337, True), ("Texas hub", 322, True), ("Florida hub", 304, True),
         ("national hub", 294, True), ("214 (Dallas) code page", 238, False), ("786 (Miami) code page", 228, False),
         ("404 (Atlanta) code page", 218, False)]
fig, ax = plt.subplots(figsize=(3.3, 2.4))
ys = list(range(len(pages)))[::-1]
for y, (name, n, hub) in zip(ys, pages):
    ax.barh(y, n, color="0.75" if hub else "white", edgecolor="0.25", lw=0.6, hatch="" if hub else "////", height=0.68)
    ax.text(n + 6, y, f"{n}", va="center", fontsize=7.5)
ax.set_yticks(ys); ax.set_yticklabels([p[0] for p in pages])
ax.set_xlim(0, 540); ax.set_xlabel("Stored AI answers citing the page (Ahrefs Brand Radar, 11 Oct 2026)")
ax.legend(handles=[mpatches.Patch(facecolor="0.75", edgecolor="0.25", label="enumerating page"),
                   mpatches.Patch(facecolor="white", edgecolor="0.25", hatch="////", label="per-entity page")],
          loc="lower right", frameon=False, handlelength=1.6)
ax.grid(axis="x", color="0.88", lw=0.5); ax.set_axisbelow(True)
save(fig, "fig5_cited")

# ---------------------------------------------------------------- Fig 6: referring domains by instrument
fig, ax = plt.subplots(figsize=(3.3, 1.85))
rows = [("Ahrefs\n913 domains", [(".info", 61.9, "0.75", ""), (".asia", 26.4, "white", "////"), (".xyz", 10.2, "white", "...."), ("other", 1.5, "white", "")]),
        ("Semrush\n80 domains", [(".xyz", 75.0, "white", "...."), ("not stated", 25.0, "white", "xx")])]
seen = {}
for y, (lab, segs) in enumerate(rows[::-1]):
    left = 0
    for tld, pct, fc, h in segs:
        ax.barh(y, pct, left=left, color=fc, edgecolor="0.25", lw=0.6, hatch=h, height=0.6)
        if pct >= 14:
            ax.text(left + pct / 2, y, f"{tld} {pct:g}%", ha="center", va="center", fontsize=7,
                    bbox=dict(facecolor="white", edgecolor="none", pad=1.2))
        elif pct >= 5:
            ax.text(left + pct / 2, y + 0.42, f"{tld} {pct:g}%", ha="center", va="bottom", fontsize=6.8)
        left += pct
ax.set_yticks([0, 1]); ax.set_yticklabels([rows[1][0], rows[0][0]])
ax.set_xlim(0, 100); ax.set_xticks([0, 25, 50, 75, 100]); ax.set_xticklabels(["0%", "25%", "50%", "75%", "100%"])
ax.set_xlabel("Share of live referring domains to the prefix, by top-level domain, 11 Oct 2026")
ax.grid(axis="x", color="0.88", lw=0.5); ax.set_axisbelow(True)
save(fig, "fig3_refdomains")
print("ok")
