#!/usr/bin/env python3
"""Convert manuscript_clean.md (via pandoc JSON) into a two-column XeLaTeX paper and compile it."""
import json, re, math, os, subprocess, sys, unicodedata, shutil

ROOT = "/home/claude/paper04"
TEX = os.path.join(ROOT, "tex")
SRC = os.path.join(ROOT, "manuscript_clean.md")
MD = os.path.join(TEX, "manuscript_tex.md")
AST = os.path.join(TEX, "ast_tex.json")
OUT = os.path.join(TEX, "paper.tex")

# ------------------------------------------------------------------ 1. source markdown (edited by edit_text.py)
SRC = os.path.join(ROOT, "manuscript_v48.md")
shutil.copy(SRC, MD)

subprocess.run(["pandoc", MD, "-f", "markdown+pipe_tables+tex_math_dollars+implicit_figures", "-t", "json", "-o", AST], check=True)
ast = json.load(open(AST))
blocks = ast["blocks"]

# ------------------------------------------------------------------ 2. inline rendering
SPECIAL = {"&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}",
           "~": r"\textasciitilde{}", "^": r"\textasciicircum{}", "\\": r"\textbackslash{}"}
CJK = re.compile(r"([\u2e80-\u9fff\uf900-\ufaff\uff00-\uffef]+)")
URLISH = re.compile(r"^(https?://\S+|www\.\S+|[A-Za-z0-9.-]+\.[a-z]{2,4}/\S+|[A-Za-z0-9_./-]+/[A-Za-z0-9_./-]+\.[a-z]{1,5})$")

def esc(s):
    s = "".join(SPECIAL.get(ch, ch) for ch in s)
    s = CJK.sub(r"{\\cjkfont \1}", s)
    return s

def render_str(s):
    # allow line breaks inside URL-like and path-like tokens
    core, trail = s, ""
    m = re.match(r"^(.*?)([.,;:)\]]+)$", s)
    if m and URLISH.match(m.group(1)):
        core, trail = m.group(1), m.group(2)
    if URLISH.match(core) and len(core) > 12:
        parts = core.split("/")
        return r"\allowbreak{}".join(esc(x) for x in parts).replace(r"\allowbreak{}", r"/\allowbreak{}") + esc(trail)
    return esc(s)

def inl(il, strong=True):
    out = []
    for x in il:
        t = x["t"]
        if t == "Str":
            out.append(render_str(x["c"]))
        elif t == "Space" or t == "SoftBreak":
            out.append(" ")
        elif t == "LineBreak":
            out.append(r"\\ ")
        elif t == "Emph":
            out.append(r"\emph{" + inl(x["c"], strong) + "}")
        elif t == "Strong":
            inner = inl(x["c"], strong)
            out.append((r"\textbf{" + inner + "}") if strong else inner)
        elif t == "Code":
            out.append(r"\texttt{" + esc(x["c"][1]).replace(":", ":\\allowbreak{}") + "}")
        elif t == "Math":
            kind, body = x["c"][0]["t"], x["c"][1]
            out.append("$" + body + "$" if kind == "InlineMath" else display_math(body))
        elif t == "Link":
            url = x["c"][2][0]
            text = inl(x["c"][1], strong)
            href = url.replace("%", r"\%").replace("#", r"\#")
            out.append(r"\href{" + href + "}{" + text + "}")
        elif t == "Quoted":
            q = x["c"][0]["t"]
            inner = inl(x["c"][1], strong)
            out.append(("“" + inner + "”") if q == "DoubleQuote" else ("‘" + inner + "’"))
        elif t == "Cite":
            out.append(inl(x["c"][1], strong))
        elif t in ("Span", "Underline", "SmallCaps", "Strikeout", "Superscript", "Subscript"):
            out.append(inl(x["c"][-1], strong))
        elif t == "RawInline":
            pass
        elif t == "Image":
            pass
        else:
            raise SystemExit("unhandled inline " + t)
    return "".join(out)

def plain(il):
    out = []
    for x in il:
        t = x["t"]
        if t == "Str": out.append(x["c"])
        elif t in ("Space", "SoftBreak"): out.append(" ")
        elif t == "LineBreak": out.append(" ")
        elif t in ("Emph", "Strong", "Underline", "SmallCaps", "Strikeout", "Superscript", "Subscript"): out.append(plain(x["c"]))
        elif t == "Code": out.append(x["c"][1])
        elif t == "Math": out.append(x["c"][1])
        elif t == "Link": out.append(plain(x["c"][1]))
        elif t == "Quoted": out.append('"' + plain(x["c"][1]) + '"')
        elif t in ("Span", "Cite"): out.append(plain(x["c"][-1]))
    return "".join(out)

OPS = ["CGS", "SG", "prior", "own", "cov", "ans", "rel", "dem", "rank"]
def display_math(body):
    b = body.strip()
    for op in OPS:
        b = re.sub(r"(?<![A-Za-z\\])" + op + r"(?![A-Za-z])", r"\\operatorname{" + op + "}", b)
    if b.startswith(r"\operatorname{CGS}(e)"):
        b = (r"\begin{split}\operatorname{CGS}(e) = \operatorname{prior}(e)\,\big(1 - \operatorname{own}(e)\big)\Big[\alpha\,\big(1 - \operatorname{cov}_K(e)\big)"
             r"\\ \qquad + (1-\alpha)\,\frac{1}{|Q_e|}\sum_{q \in Q_e}\big(1 - \operatorname{ans}(q,e)\big)\Big]\end{split}")
    elif b.startswith(r"\pi ="):
        b = (r"\begin{split}\pi &= (1-d)\, v_S + d\, P^{\top} \pi,\\ v_S(e) &= \begin{cases} 1/|S| & e \in S \\ 0 & \text{otherwise} \end{cases}\end{split}")
    elif b.startswith(r"\operatorname{SG}(r)"):
        b = (r"\begin{split}\operatorname{SG}(r) = \frac{1}{|E_r|}\sum_{e \in E_r} \operatorname{prior}(e)\,\big(1 - \operatorname{own}(e)\big)\\ \qquad\times\big(1 - \operatorname{ans}(q_r, e)\big)\end{split}")
    return "\n\\begin{equation*}\n" + b + "\n\\end{equation*}\n"

# ------------------------------------------------------------------ 3. block rendering helpers
TEXTWIDTH_PT = 7.0 * 72.27      # letter, 0.75in margins
TEXTHEIGHT_PT = 9.4 * 72.27
TABCOLSEP = 4.0

def cell_tex(cell):
    bl = cell[4]
    parts = []
    for b in bl:
        if b["t"] in ("Plain", "Para"):
            parts.append(inl(b["c"]))
        else:
            parts.append(render_block_inline_only(b))
    return r" \newline ".join(parts)

def cell_plain(cell):
    return " ".join(plain(b["c"]) for b in cell[4] if b["t"] in ("Plain", "Para"))

def render_block_inline_only(b):
    if b["t"] == "BulletList":
        return " ".join("• " + " ".join(inl(x["c"]) for x in it if x["t"] in ("Plain", "Para")) for it in b["c"])
    return ""

TABLES = []   # collected table specs; rendered after measurement

def table_tex(tb, caption, label_prefix, counter):
    """Collect the table; return a placeholder token replaced after the measurement pass."""
    attr, cap, colspecs, head, bodies, foot = tb["c"]
    ncol = len(colspecs)
    header = [cell_tex(c) for c in head[1][0][1]] if head[1] else None
    header_plain = [cell_plain(c) for c in head[1][0][1]] if head[1] else [""] * ncol
    rows = [[cell_tex(c) for c in row[1]] for bd in bodies for row in bd[3]]
    rows_plain = [[cell_plain(c) for c in row[1]] for bd in bodies for row in bd[3]]
    fs = 8.0 if (ncol >= 5 or sum(len(x) for r in rows_plain for x in r) > 1800) else 9.0
    cw = 0.45 * fs
    lens = [[len(r[j]) if j < len(r) else 0 for r in rows_plain] for j in range(ncol)]
    avail = TEXTWIDTH_PT - 2 * TABCOLSEP * ncol
    # minimum width: any cell of up to 22 characters, and any unbreakable token, fits on one line
    mins = []
    for j in range(ncol):
        cells = [r[j] for r in rows_plain if j < len(r)] + [header_plain[j]]
        longest_cell = max((len(c) for c in cells), default=4)
        toks = [t for c in cells for t in c.split()]
        longest_tok = max((len(t) for t in toks if "/" not in t), default=4)
        mins.append(max(min(longest_cell, 22), min(longest_tok, 18)) * cw + 2 * TABCOLSEP)
    scores = []
    for j in range(ncol):
        body = [L for L in lens[j] if L > 0] or [1]
        scores.append(max(0.35 * max(body) + 0.65 * (sum(body) / len(body)), 0.6 * len(header_plain[j]), 6))
    # allocate: each column gets at least mins[j]; remaining width in proportion to score
    widths = list(mins)
    rem = avail - sum(widths)
    if rem < 0:   # cannot honour all minima; scale them
        widths = [m * avail / sum(mins) for m in mins]; rem = 0
    tot = sum(scores)
    widths = [w + rem * sc / tot for w, sc in zip(widths, scores)]
    weights = [w / avail for w in widths]
    def row_h(r):
        lines = 1
        for j in range(ncol):
            cpl = max(widths[j] / cw, 4)
            txt = r[j] if j < len(r) else ""
            lines = max(lines, math.ceil(len(txt) / cpl) if txt else 1)
        return lines * fs * 1.2 + 3
    spec = dict(caption=caption, ncol=ncol, header=header, rows=rows, fs=fs,
                colfmt="".join(r">{\hsize=%.3f\hsize\RaggedRight\arraybackslash}X" % (w * ncol) for w in weights),
                est_rows=[row_h(rp) for rp in rows_plain], est_head=row_h(header_plain) + 8)
    TABLES.append(spec)
    return "@@TABLE%d@@" % (len(TABLES) - 1)

def tabular_body(spec, rows):
    out = [r"\begin{tabularx}{\textwidth}{" + spec["colfmt"] + "}\n\\toprule\n"]
    if spec["header"]:
        out.append(" & ".join(r"\textbf{" + h + "}" for h in spec["header"]) + r" \\" + "\n\\midrule\n")
    for r in rows:
        r = r + [""] * (spec["ncol"] - len(r))
        out.append(" & ".join(r) + r" \\" + "\n")
    out.append("\\bottomrule\n\\end{tabularx}\n")
    return "".join(out)

def measure_tables(preamble_pkgs):
    """Typeset every table once in a one-column document and read back its height."""
    doc = [preamble_pkgs, r"\begin{document}"]
    for k, spec in enumerate(TABLES):
        size = r"\footnotesize" if spec["fs"] == 8.0 else r"\small"
        doc.append(r"\setbox0=\vbox{" + size + "\n" + tabular_body(spec, spec["rows"]) + "}")
        doc.append(r"\typeout{TABLEHEIGHT %d \the\ht0 \the\dp0}" % k)
    doc.append(r"\end{document}")
    open(os.path.join(TEX, "measure.tex"), "w", encoding="utf-8").write("\n".join(doc))
    subprocess.run(["xelatex", "-interaction=nonstopmode", "-halt-on-error", "measure.tex"],
                   cwd=TEX, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    heights = {}
    for line in open(os.path.join(TEX, "measure.log"), encoding="utf-8", errors="replace"):
        m = re.match(r"TABLEHEIGHT (\d+) ([\d.]+)pt ?([\d.]+)pt", line)
        if m: heights[int(m.group(1))] = float(m.group(2)) + float(m.group(3))
    return heights

def render_tables(heights):
    limit = TEXTHEIGHT_PT * 0.92 - 46       # room for caption and float separation
    rendered = []
    for k, spec in enumerate(TABLES):
        measured = heights.get(k)
        est_total = spec["est_head"] + sum(spec["est_rows"])
        scale = (measured / est_total) if measured else 1.0
        head_h = spec["est_head"] * scale
        chunks, cur, curh = [], [], head_h
        for r, eh in zip(spec["rows"], spec["est_rows"]):
            h = eh * scale
            if cur and curh + h > limit:
                chunks.append(cur); cur, curh = [], head_h
            cur.append(r); curh += h
        if cur: chunks.append(cur)
        size = r"\footnotesize" if spec["fs"] == 8.0 else r"\small"
        out = []
        for ci, chunk in enumerate(chunks):
            cap_tex = spec["caption"] if ci == 0 else re.sub(r"^(\\textbf\{[^}]*\})(.*)$", r"\1 (continued)", spec["caption"], flags=re.S)
            out.append(r"\begin{table*}[tp]" + "\n" + r"\centering" + size + "\n" + r"\caption*{" + cap_tex + "}\n")
            out.append(tabular_body(spec, chunk))
            out.append("\\end{table*}\n\n")
        rendered.append("".join(out))
        print("table %d: measured %s pt, est %.0f, chunks %d" % (k, measured, est_total, len(chunks)))
    return rendered

def list_tex(b):
    if b["t"] == "BulletList":
        items = b["c"]; env = "itemize"; opts = "[leftmargin=1.1em, itemsep=1.5pt, topsep=2pt, parsep=0pt]"
    else:
        items = b["c"][1]; env = "enumerate"; opts = "[leftmargin=1.6em, itemsep=1.5pt, topsep=2pt, parsep=0pt]"
    out = [r"\begin{" + env + "}" + opts + "\n"]
    for it in items:
        out.append(r"\item " + " ".join(block_tex_simple(x) for x in it) + "\n")
    out.append(r"\end{" + env + "}\n")
    return "".join(out)

def block_tex_simple(b):
    if b["t"] in ("Plain", "Para"):
        return inl(b["c"])
    if b["t"] in ("BulletList", "OrderedList"):
        return list_tex(b)
    return ""

CAP_RE = re.compile(r"^(Table\s+[A-Z]?\d+[a-z]?\.)\s*(.*)$", re.S)
FIG_RE = re.compile(r"^(Figure\s+\d+\.)\s*(.*)$", re.S)

def caption_from_para(b):
    """Return LaTeX caption if this paragraph is a 'Table N.' caption, else None."""
    txt = plain(b["c"])
    m = CAP_RE.match(txt)
    if not m: return None
    il = b["c"]
    nonspace = [x for x in il if x["t"] != "Space"]
    if len(nonspace) == 1 and nonspace[0]["t"] == "Emph":   # italic caption paragraph
        il = nonspace[0]["c"]
    tex = inl(il, strong=False)
    m2 = CAP_RE.match(tex)
    return r"\textbf{" + m2.group(1) + "} " + m2.group(2)

def sort_key(s):
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return s.lower()

# ------------------------------------------------------------------ 4. walk blocks
title = plain(blocks[0]["c"][2])
author_lines = [[]]
for x in blocks[1]["c"]:
    if x["t"] in ("LineBreak", "SoftBreak"): author_lines.append([])
    else: author_lines[-1].append(x)
author_tex = [inl(l, strong=False) for l in author_lines]

body = []
abstract = []
keywords = ""
i = 2
mode = None          # 'abstract' while collecting abstract paragraphs
in_appendix = False
in_refs = False
REFITEMS = []
while i < len(blocks):
    b = blocks[i]; t = b["t"]
    if t == "Header":
        lvl, txt = b["c"][0], plain(b["c"][2])
        if lvl == 2 and txt == "Abstract":
            mode = "abstract"; i += 1; continue
        mode = None
        if lvl == 2:
            if txt == "References":
                body.append("\n\\section*{References}\n"); in_refs = True
            elif txt.startswith("Appendix"):
                if in_refs and REFITEMS:
                    body.append("\\begin{reflist}\n" + "".join("\\item " + e + "\n" for _, e in sorted(REFITEMS)) + "\\end{reflist}\n\n")
                    REFITEMS.clear(); in_refs = False
                if not in_appendix:
                    body.append("\n\\appendix\n"); in_appendix = True
                name = re.sub(r"^Appendix\s+[A-Z]\s*[—–.:-]\s*", "", txt)
                body.append("\n\\section{" + esc(name) + "}\n")
            else:
                name = re.sub(r"^\d+\s+", "", txt)
                body.append("\n\\section{" + esc(name) + "}\n")
        else:
            name = re.sub(r"^\d+\.\d+\s+", "", txt)
            body.append("\n\\subsection{" + esc(name) + "}\n")
        i += 1; continue
    if t == "Para":
        # display-math paragraph?
        nonspace = [x for x in b["c"] if x["t"] != "Space"]
        if len(nonspace) == 1 and nonspace[0]["t"] == "Math":
            body.append(display_math(nonspace[0]["c"][1])); i += 1; continue
        # table caption?
        if i + 1 < len(blocks) and blocks[i + 1]["t"] == "Table":
            cap = caption_from_para(b)
            if cap:
                body.append(table_tex(blocks[i + 1], cap, None, None)); i += 2; continue
        ptxt = plain(b["c"])
        if ptxt.startswith("Keywords:"):
            keywords = ptxt[len("Keywords:"):].strip(); i += 1; continue
        # run-in paragraph heading: a leading bold phrase ending with a period
        il = b["c"]
        if (mode != "abstract" and il and il[0]["t"] == "Strong"):
            lead = plain(il[0]["c"]).strip()
            if lead.endswith(".") and 3 < len(lead) < 80 and not lead.startswith("RQ"):
                rest = inl(il[1:]).lstrip()
                body.append("\\paragraph{" + inl(il[0]["c"], strong=False).strip().rstrip(".") + "}" + rest + "\n\n")
                i += 1; continue
        tex = inl(b["c"])
        if mode == "abstract": abstract.append(tex)
        elif in_refs and re.match(r"^[A-Z][^\n]*?\(\d{4}", ptxt):
            REFITEMS.append((sort_key(ptxt), tex))
        else:
            if in_refs and REFITEMS:
                body.append("\\begin{reflist}\n" + "".join("\\item " + e + "\n" for _, e in sorted(REFITEMS)) + "\\end{reflist}\n\n")
                REFITEMS.clear(); in_refs = False
            body.append(tex + "\n\n")
        i += 1; continue
    if t == "Table":
        hp = [cell_plain(c) for c in b["c"][3][1][0][1]] if b["c"][3][1] else []
        if hp[:2] == ["Hypothesis", "Statement"]:
            cap = r"\textbf{Hypotheses H1--H7.} Statement of each hypothesis and the section, table or figure in which it is tested."
        elif hp[:2] == ["Source class", "Examples"]:
            cap = r"\textbf{Source classes.} The five source classes, examples of each, the role each plays in the score, and the access route."
        elif hp[:2] == ["Ontology term", "Alignment target"]:
            cap = r"\textbf{Alignment of the area-code excerpt.} Ontology terms aligned to Wikidata and schema.org, with the predicate used and notes."
        else:
            cap = r"\textbf{Table.}"
        body.append(table_tex(b, cap, None, None)); i += 1; continue
    if t == "Figure":
        capil = b["c"][1][1][0]["c"] if b["c"][1][1] else []
        captex = inl(capil, strong=False)
        m = FIG_RE.match(captex)
        captex = (r"\textbf{" + m.group(1) + "} " + m.group(2)) if m else captex
        img = b["c"][2][0]["c"][0]["c"][2][0]
        key = img.split("_")[0]
        FIGS = {"fig0": ("figure*", "\\includegraphics[width=\\textwidth]{fig0_framework.pdf}"),
                "fig1": ("figure", "\\includegraphics[width=\\columnwidth]{fig1_divergence.pdf}"),
                "fig2": ("figure*", "\\includegraphics[width=\\textwidth]{fig2_aio.pdf}"),
                "fig3": ("figure", "\\includegraphics[width=\\columnwidth]{fig3_refdomains.pdf}"),
                "fig4": ("figure*", "\\includegraphics[width=\\textwidth]{fig4_prefixes.pdf}"),
                "fig5": ("figure", "\\includegraphics[width=\\columnwidth]{fig5_cited.pdf}"),
                "fig6": ("figure*", "\\includegraphics[width=\\textwidth]{fig6_positions.pdf}")}
        env, content = FIGS[key]
        body.append("\\begin{" + env + "}[t]\n\\centering\n" + content + "\n\\caption*{" + captex + "}\n\\end{" + env + "}\n\n")
        i += 1; continue
    if t in ("BulletList", "OrderedList"):
        if in_refs and t == "OrderedList":
            items = b["c"][1]
            entries = [(sort_key(plain(it[0]["c"])), " ".join(block_tex_simple(x) for x in it)) for it in items]
            entries.sort(key=lambda e: e[0])
            body.append("\\begin{reflist}\n")
            for _, e in entries:
                body.append("\\item " + e + "\n")
            body.append("\\end{reflist}\n\n")
            in_refs = False
        else:
            body.append(list_tex(b) + "\n")
        i += 1; continue
    raise SystemExit("unhandled block " + t)

KEYWORDS = keywords or "search measurement; instrument validity; AI Overviews; deployment measurement study"

PREAMBLE = r"""\documentclass[10pt,twocolumn]{article}
\usepackage[letterpaper,margin=0.75in,columnsep=0.25in,headheight=12pt,headsep=14pt,footskip=24pt]{geometry}
\usepackage{fontspec}
\setmainfont{TeX Gyre Termes}
\newfontfamily\cjkfont{Noto Serif CJK SC}
\usepackage{amsmath}
\usepackage{unicode-math}
\setmathfont{Latin Modern Math}
\usepackage{microtype}
\usepackage{booktabs,tabularx,array,ragged2e}
\usepackage{graphicx}
\usepackage{tikz}
\usetikzlibrary{arrows.meta,patterns,positioning}
\usepackage{caption}
\captionsetup{font=small,labelfont=bf,justification=justified,singlelinecheck=false,skip=5pt}
\usepackage{enumitem}
\usepackage{titlesec}
\titleformat{\section}{\large\bfseries}{\thesection}{0.6em}{}
\titleformat{\subsection}{\normalsize\bfseries}{\thesubsection}{0.6em}{}
\titlespacing*{\section}{0pt}{1.4ex plus 0.6ex minus 0.3ex}{0.8ex}
\titlespacing*{\subsection}{0pt}{1.1ex plus 0.5ex minus 0.3ex}{0.5ex}
\titleformat{\paragraph}[runin]{\normalfont\normalsize\bfseries}{}{0pt}{}[.]
\titlespacing*{\paragraph}{0pt}{0.9ex plus 0.3ex minus 0.2ex}{0.55em}
\usepackage{fancyhdr}
\pagestyle{fancy}
\fancyhf{}
\renewcommand{\headrulewidth}{0.3pt}
\fancyhead[L]{\small\itshape User First Intelligence: Content Gap Discovery Beyond Search Volume}
\fancyhead[R]{\small\itshape Pagadala, preprint v4.8, 12 October 2026}
\fancyfoot[C]{\small\thepage}
\usepackage[hyphens]{url}
\usepackage[colorlinks=true,linkcolor=black,citecolor=black,urlcolor=blue!50!black,pdftitle={User First Intelligence: Ontology-Driven Content Gap Discovery from Multi-Source Industry Knowledge Graphs Beyond Search Volume},pdfauthor={Venkata Pagadala}]{hyperref}
\usepackage{balance}
\renewcommand{\topfraction}{0.95}
\renewcommand{\dbltopfraction}{0.95}
\renewcommand{\textfraction}{0.05}
\renewcommand{\floatpagefraction}{0.75}
\renewcommand{\dblfloatpagefraction}{0.75}
\setcounter{topnumber}{3}
\setcounter{dbltopnumber}{3}
\setcounter{totalnumber}{4}
\makeatletter
\setlength{\@fptop}{0pt}
\setlength{\@dblfptop}{0pt}
\makeatother
\setlength{\parindent}{1.1em}
\setlength{\parskip}{0pt plus 1pt}
\setlength{\tabcolsep}{4pt}
\renewcommand{\arraystretch}{1.15}
\newlist{reflist}{itemize}{1}
\setlist[reflist]{label={},leftmargin=1.2em,itemindent=-1.2em,itemsep=2.5pt,parsep=0pt,topsep=3pt,font=\small}
\usepackage{etoolbox}
\AtBeginEnvironment{reflist}{\small\sloppy}
\emergencystretch=2em
\hyphenpenalty=150
\tolerance=2000
@@BEGINDOC@@
\makeatletter
\twocolumn[{%
\begin{@twocolumnfalse}
\begin{center}
{\LARGE\bfseries TITLE\par}
\vspace{1.3em}
{\large AUTHOR\par}
\vspace{0.35em}
{\normalsize AFFIL\par}
\vspace{0.35em}
{\small\itshape VERSION\par}
\end{center}
\vspace{0.6em}
\begin{center}
\begin{minipage}{0.94\textwidth}
\small
\noindent\textbf{Abstract.} ABSTRACT
\vspace{0.7em}

\noindent\textbf{Keywords:} KEYWORDS
\end{minipage}
\end{center}
\vspace{1.6em}
\end{@twocolumnfalse}
}]
\makeatother
"""

PKGS = PREAMBLE.split("@@BEGINDOC@@")[0].replace("[10pt,twocolumn]{article}", "[10pt]{article}")
heights = measure_tables(PKGS)
rendered = render_tables(heights)
body = [re.sub(r"@@TABLE(\d+)@@", lambda m: rendered[int(m.group(1))], x) for x in body]
PREAMBLE = PREAMBLE.replace("@@BEGINDOC@@", "\\begin{document}")
doc = (PREAMBLE.replace("TITLE", esc(title)).replace("AUTHOR", author_tex[0]).replace("AFFIL", author_tex[1])
       .replace("VERSION", author_tex[2]).replace("ABSTRACT", " ".join(abstract)).replace("KEYWORDS", KEYWORDS))
doc += "".join(body)
doc += "\n\\balance\n\\end{document}\n"
open(OUT, "w", encoding="utf-8").write(doc)
print("wrote", OUT, len(doc), "chars")
