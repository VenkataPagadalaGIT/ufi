"""Figure: first-party demand (review mentions) against tool-derived demand
(vendor monthly search volume) on one industry taxonomy. Reads only the
per-label and per-branch aggregate counts; no review text or names."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

plt.rcParams.update({"font.family": "serif", "font.size": 8, "axes.linewidth": 0.6})
agg = pd.read_csv("out/label_demand_aggregates.csv")
b = pd.read_csv("out/branch_shares.csv").sort_values("review_share", ascending=False)

fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.2, 3.0), gridspec_kw={"width_ratios": [1.05, 1.0], "wspace": 0.72})
x = agg["monthly_volume"].clip(lower=0.5)
y = agg["review_mentions"]
zero = agg["monthly_volume"] == 0
a1.scatter(x[~zero], y[~zero], s=7, facecolor="none", edgecolor="0.25", lw=0.5, label="label with reported volume")
a1.scatter(x[zero], y[zero], s=9, marker="s", facecolor="0.35", edgecolor="0.1", lw=0.4, label="zero reported volume (106)")
a1.set_xscale("log")
a1.set_yscale("log")
a1.set_xlabel("vendor monthly search volume for the label (log)")
a1.set_ylabel("reviews mentioning the label (log)")
a1.set_title("(a) 1,008 taxonomy labels, Spearman +0.19", loc="left", fontsize=8)
for lab in ["Customer Service", "iPhone", "New Phone", "Account"]:
    r = agg[agg["label"] == lab]
    if len(r):
        a1.annotate(lab, (max(float(r["monthly_volume"].iloc[0]), 0.5), float(r["review_mentions"].iloc[0])),
                    xytext=(4, 2), textcoords="offset points", fontsize=6.5)
pass
a1.grid(True, lw=0.3, color="0.85")

top = b.head(9)
yy = np.arange(len(top))
a2.barh(yy + 0.19, top["review_share"] * 100, height=0.38, color="0.35", label="share of review mentions")
a2.barh(yy - 0.19, top["volume_share"] * 100, height=0.38, color="white", edgecolor="0.2", hatch="////",
        label="share of search volume")
a2.set_yticks(yy)
a2.set_yticklabels(top["branch"], fontsize=7)
a2.invert_yaxis()
a2.set_xlabel("% of total")
a2.set_title("(b) top-level branches (nine of 17), Spearman +0.78", loc="left", fontsize=8)
a2.legend(fontsize=6.5, frameon=False, loc="lower right")
a2.grid(True, axis="x", lw=0.3, color="0.85")
fig.savefig("fig9_reviews.pdf", bbox_inches="tight")
fig.savefig("fig_reviews.png", dpi=170, bbox_inches="tight")
print("ok")
