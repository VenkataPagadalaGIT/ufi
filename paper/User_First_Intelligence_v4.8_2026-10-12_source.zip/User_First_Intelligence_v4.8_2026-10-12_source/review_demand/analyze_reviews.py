"""First-party demand (reviews) against tool-derived demand (keyword volume)
on one industry taxonomy.

Inputs: Telecom_reviews_and_responses.xlsx and Telecom_classification.xlsx
(DataForSEO-sourced exports). Output: per-label and per-branch aggregate
counts and the statistics quoted in the paper. Linking uses
ufi.demand.TokenLinker, the released whole-word exact-match linker, so every
attribution is auditable from the label. No review text or reviewer name is
written out.
"""
import re
import sys
from pathlib import Path

import pandas as pd
from scipy.stats import kendalltau, spearmanr

from ufi.demand import TokenLinker

SRC = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
OUT = Path(__file__).parent / "out"
OUT.mkdir(exist_ok=True)

r = pd.read_excel(SRC / "Telecom_reviews_and_responses.xlsx", sheet_name="Reviews")
t = pd.read_excel(SRC / "Telecom_classification.xlsx", sheet_name="Taxonomy")
r = r[r["Review text"].notna()].copy()
r["text"] = r["Review text"].astype(str)
n_reviews, n_biz = len(r), r["Business ID"].nunique()
print(f"reviews with text: {n_reviews}  businesses: {n_biz}  ratings: {r['Rating'].value_counts().sort_index().to_dict()}")

branch_name = {str(p).split(".")[1]: str(l) for p, l in zip(t[t["Depth"] == 1]["Path"], t[t["Depth"] == 1]["Label"])}
t = t[t["Depth"] >= 2].copy()
t["Label"] = t["Label"].astype(str).str.strip()
t["branch"] = t["Path"].astype(str).str.split(".").str[1]
STOP = {"telecom", "phone", "store", "stores", "service", "internet", "wireless", "overview", "reviews & ratings", "how-to & troubleshooting"}
lab = t[((t["Label"].str.split().str.len() >= 2) | (t["Label"].str.len() >= 6)) & ~t["Label"].str.lower().isin(STOP)]
per_label = lab.groupby("Label").agg(nodes=("Node ID", "size"), keywords=("Keywords", "sum"), monthly_volume=("Monthly volume", "sum"),
                                     branch=("branch", lambda x: x.value_counts().index[0]), depth=("Depth", "min"))
aliases = {label: [label] for label in per_label.index}
linker = TokenLinker(aliases)
print(f"linkable labels: {len(aliases)} (from {len(lab)} nodes)")

hits = {}
rows = []
for _, rv in r.iterrows():
    ids = linker.link(rv["text"])
    rows.append(len(ids))
    for i in ids:
        h = hits.setdefault(i, [0, 0, 0])
        h[0] += 1
        if rv["Rating"] <= 2:
            h[1] += 1
        if rv["Rating"] == 5:
            h[2] += 1
r["n_links"] = rows
linked = (r["n_links"] > 0).sum()
print(f"reviews linked to at least one label: {linked} ({linked/n_reviews:.1%}); mean labels per linked review {r.loc[r.n_links>0,'n_links'].mean():.2f}")

agg = pd.DataFrame([{"label": k, "branch": per_label.loc[k, "branch"], "nodes": int(per_label.loc[k, "nodes"]),
                     "review_mentions": v[0], "neg_mentions": v[1], "pos_mentions": v[2],
                     "keywords": int(per_label.loc[k, "keywords"]), "monthly_volume": int(per_label.loc[k, "monthly_volume"])}
                    for k, v in hits.items()]).sort_values("review_mentions", ascending=False)
agg.to_csv(OUT / "label_demand_aggregates.csv", index=False)
print(f"labels mentioned in at least one review: {len(agg)}")

rho, p = spearmanr(agg["review_mentions"], agg["monthly_volume"])
tau, _ = kendalltau(agg["review_mentions"], agg["monthly_volume"])
print(f"\nSpearman(review mentions, monthly volume) over {len(agg)} labels: rho={rho:+.3f} p={p:.2g}; Kendall tau={tau:+.3f}")
top = agg[agg["review_mentions"] >= 20]
rho2, p2 = spearmanr(top["review_mentions"], top["monthly_volume"])
print(f"  labels with >=20 mentions ({len(top)}): rho={rho2:+.3f} p={p2:.2g}")
negc = agg[agg["neg_mentions"] >= 20]
rho3, p3 = spearmanr(negc["neg_mentions"], negc["monthly_volume"])
print(f"  complaint labels (>=20 mentions in 1-2 star reviews, {len(negc)}): rho(neg mentions, volume)={rho3:+.3f} p={p3:.2g}")

zero = agg[agg["monthly_volume"] == 0]
low = agg[agg["monthly_volume"] < 1000]
tot = agg["review_mentions"].sum()
print(f"\nlabels with review mentions and ZERO monthly volume: {len(zero)} ({len(zero)/len(agg):.1%}), carrying {zero['review_mentions'].sum()/tot:.1%} of mentions")
print(f"labels with review mentions and <1,000 monthly volume: {len(low)} ({len(low)/len(agg):.1%}), carrying {low['review_mentions'].sum()/tot:.1%} of mentions")

agg["branch"] = agg["branch"].map(lambda x: branch_name.get(x, x))
b = agg.groupby("branch").agg(review=("review_mentions", "sum"), neg=("neg_mentions", "sum"), volume=("monthly_volume", "sum")).reset_index()
b["review_share"] = b["review"] / b["review"].sum()
b["volume_share"] = b["volume"] / b["volume"].sum()
b["ratio"] = b["review_share"] / b["volume_share"]
b = b.sort_values("review_share", ascending=False)
b.to_csv(OUT / "branch_shares.csv", index=False)
print("\nbranch | review share | volume share | ratio")
for _, x in b.iterrows():
    print(f"  {x.branch[:36]:36} {x.review_share:6.1%} {x.volume_share:6.1%} {x.ratio:6.2f}")
rb, pb = spearmanr(b["review_share"], b["volume_share"])
print(f"branch-level Spearman: rho={rb:+.3f} p={pb:.2g} over {len(b)} branches")

neg = r[r["Rating"] <= 2]
pat = re.compile(r"\b(?:wait(?:ed|ing)?|hours? (?:in|at) (?:line|the store)|long line)\b", re.I)
w = neg["text"].str.contains(pat)
print(f"\n1-2 star reviews: {len(neg)}; mentioning waiting: {w.sum()} ({w.mean():.1%}); in 5-star reviews: {r[r.Rating==5]['text'].str.contains(pat).mean():.1%}")
wait_nodes = agg[agg["label"].str.contains("wait", case=False)]
print("taxonomy labels containing 'wait':", len(wait_nodes), "| total monthly volume on them:", int(wait_nodes["monthly_volume"].sum()) if len(wait_nodes) else 0)
