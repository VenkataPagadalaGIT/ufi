"""Figure 1: the User First Intelligence framework.

(a) Where user questions are observed: the thirteen demand surfaces the released
    package reads, grouped by whether they carry a user's own words or a tool's
    reconstruction, with the ones this deployment actually collected marked.
(b) The pipeline from those sources to content, and where the two commercial
    instruments sit in it.

Grayscale-safe: fills, hatching and line weight carry every distinction.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, FancyArrowPatch

plt.rcParams.update({"font.family": "serif", "font.serif": ["FreeSerif", "DejaVu Serif"],
                     "font.size": 8, "axes.linewidth": 0.6})

fig = plt.figure(figsize=(7.0, 3.9))
gs = fig.add_gridspec(1, 2, width_ratios=[1.0, 1.65], wspace=0.06)

# ---------------------------------------------------------------- (a) surfaces
ax = fig.add_subplot(gs[0, 0]); ax.set_axis_off()
ax.set_xlim(0, 10); ax.set_ylim(0, 10)
ax.text(0.0, 9.75, "(a) Where questions are observed", fontsize=8.5, fontweight="bold", va="top")

first_party = [("forum", False), ("Q&A site", False), ("social group", False), ("social post", False),
               ("short video", False), ("long video", False), ("business reviews", False),
               ("review platform", False), ("app-store review", False), ("support ticket", False)]
tool_derived = [("people also ask", False), ("autocomplete", False), ("keyword export", True)]

def block(x0, y0, w, label, collected, hatched):
    r = Rectangle((x0, y0), w, 0.62, facecolor="0.82" if collected else "white",
                  edgecolor="0.1", lw=1.4 if collected else 0.7)
    ax.add_patch(r)
    ax.text(x0 + 0.18, y0 + 0.31, label, va="center", ha="left", fontsize=7.4,
            fontweight="bold" if collected else "normal")

ax.text(0.0, 9.05, "first-party voice:\nthe user's own words", fontsize=6.9, style="italic", va="top", color="0.2")
y = 7.75
for lab, col in first_party:
    block(0.0, y, 4.3, lab, col, False); y -= 0.72
ax.text(5.1, 9.05, "tool-derived:\na tool's reconstruction", fontsize=6.9, style="italic", va="top", color="0.2")
y = 7.75
for lab, col in tool_derived:
    block(5.1, y, 4.3, lab, col, True); y -= 0.72
# legend
ax.add_patch(Rectangle((5.1, 3.55), 0.5, 0.42, facecolor="0.82", edgecolor="0.1", lw=1.4))
ax.text(5.75, 3.76, "collected for this\ndeployment (one of 13)", fontsize=6.8, va="center")
ax.add_patch(Rectangle((5.1, 2.6), 0.5, 0.42, facecolor="white", edgecolor="0.15", lw=0.7))
ax.text(5.75, 2.81, "designed and released;\nnot collected here", fontsize=6.8, va="center")
ax.text(0.0, 0.55, "The released example exercises every surface on\nsynthetic records flagged as synthetic (Section 9.2).",
        fontsize=6.6, va="bottom", color="0.25")

# ---------------------------------------------------------------- (b) pipeline
bx = fig.add_subplot(gs[0, 1]); bx.set_axis_off()
bx.set_xlim(0, 10); bx.set_ylim(0, 10)
bx.text(0.0, 9.75, "(b) From observed questions to content, and where the instruments sit",
        fontsize=8.5, fontweight="bold", va="top")

def node(x, y, w, h, title, sub="", fill="white", hatch=None, lw=0.8):
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.12",
                       facecolor=fill, edgecolor="0.1", lw=lw, ls="--" if hatch else "-")
    bx.add_patch(p)
    two = "\n" in title
    bx.text(x + w / 2, y + h * ((0.72 if two else 0.66) if sub else 0.5), title, ha="center", va="center",
            fontsize=7.4, fontweight="bold")
    if sub:
        bx.text(x + w / 2, y + h * (0.22 if two else 0.3), sub, ha="center", va="center", fontsize=6.5, color="0.2")

def arrow(x1, y1, x2, y2, text="", style="-|>"):
    a = FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style, mutation_scale=9,
                        lw=0.8, color="0.15", shrinkA=1, shrinkB=1)
    bx.add_patch(a)
    if text:
        bx.text((x1 + x2) / 2, (y1 + y2) / 2 + 0.22, text, ha="center", fontsize=6.3, color="0.25")

# row 1: sources -> classify -> ontology/KG
node(0.0, 7.3, 2.5, 1.65, "Sources beyond\nthe website", "13 surfaces, panel (a)")
node(3.3, 7.4, 2.9, 1.45, "Classify and link", "questions to entities,\nby provenance class")
node(7.0, 7.3, 3.0, 1.65, "Ontology and\nknowledge graph", "three source roles\nkept separate")
arrow(2.5, 8.12, 3.3, 8.12); arrow(6.2, 8.12, 7.0, 8.12)
# row 2: CQs -> gaps
node(7.0, 4.75, 3.0, 1.45, "Competency questions", "schema pass rate;\ninstance coverage", hatch=None)
node(3.3, 4.75, 2.9, 1.45, "Gap scoring", "Content Gap Score\n(specified; not evaluated here)", fill="0.92")
node(0.0, 4.65, 2.5, 1.65, "Content in the\nform asked", "page, video, list ...")
arrow(8.5, 7.4, 8.5, 6.2); arrow(7.0, 5.47, 6.2, 5.47); arrow(3.3, 5.47, 2.5, 5.47)
# row 3: measurement
node(0.0, 1.9, 4.6, 1.5, "Two commercial instruments", "direction agrees 60 of 66; magnitudes\ndiffer 0.20x to 8.89x (Section 5)", hatch="y")
node(5.4, 1.9, 4.6, 1.5, "AI answer surfaces", "citations by page type (Section 7);\npersonalization unmeasured (Section 11)", hatch="y")
arrow(1.25, 4.65, 1.25, 3.4, "outcomes read on")
arrow(2.5, 2.65, 5.4, 2.65, style="<|-|>")
bx.text(5.0, 0.95, "dashed: the observation layers this paper reports; shaded: the component it specifies but does not evaluate",
        ha="center", fontsize=6.4, color="0.25")

fig.savefig("fig0_framework.pdf", bbox_inches="tight")
fig.savefig("fig0_framework.png", dpi=200, bbox_inches="tight")
print("ok")
