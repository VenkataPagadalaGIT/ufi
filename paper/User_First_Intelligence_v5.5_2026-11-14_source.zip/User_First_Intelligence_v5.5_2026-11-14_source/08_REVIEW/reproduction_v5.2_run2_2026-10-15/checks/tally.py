"""Reproducer's own bookkeeping: tallies of numbers_table.tsv by status and basis, counting numeric values
(a number with an optional sign, x or %) apart from text values (domain names, qualitative phrases).
Usage: python3 -I tally.py <numbers_table.tsv>
"""
import csv
import re
import sys
from collections import Counter

rows = list(csv.DictReader(open(sys.argv[1], encoding="utf-8"), delimiter="\t"))
NUMERIC = re.compile(r"^[−+-]?[\d,]+(\.\d+)?[x%]?$")
by_status_rows = Counter(r["status"].split(":")[0] for r in rows)
num, txt = Counter(), Counter()
num_basis = Counter()
for r in rows:
    st = r["status"].split(":")[0]
    for v in r["paper"].split("; "):
        if NUMERIC.match(v.strip()):
            num[st] += 1
            num_basis[(r["basis"], st)] += 1
        else:
            txt[st] += 1
print(f"checks (rows): {len(rows)}; " + ", ".join(f"{k} {v}" for k, v in sorted(by_status_rows.items())))
print(f"numeric values: {sum(num.values())}; " + ", ".join(f"{k} {v}" for k, v in sorted(num.items())))
print(f"text values (domain names, qualitative phrases): {sum(txt.values())}; " + ", ".join(f"{k} {v}" for k, v in sorted(txt.items())))
print("numeric values by basis: " + ", ".join(f"{b} {s} {v}" for (b, s), v in sorted(num_basis.items())))
s_scripts = Counter()
for r in rows:
    if r["basis"].startswith("S") or r["basis"] in ("F+S",):
        for sc in re.findall(r"[\w./-]+\.py|vendor_reliance|numbers_table", r["script"]):
            s_scripts[sc] += 1
print("rows per script among script-basis rows: " + ", ".join(f"{k} {v}" for k, v in s_scripts.most_common()))
x_scripts = Counter()
for r in rows:
    if r["basis"] == "X":
        for sc in re.findall(r"[\w./-]+\.py", r["script"]):
            x_scripts[sc] += 1
print("rows per script among CANNOT RUN (X) rows: " + ", ".join(f"{k} {v}" for k, v in x_scripts.most_common()))
