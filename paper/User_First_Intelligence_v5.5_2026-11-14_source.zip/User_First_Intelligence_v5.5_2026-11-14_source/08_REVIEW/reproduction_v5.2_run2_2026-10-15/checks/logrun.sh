#!/bin/bash
# logrun.sh: run one shell command, appending the command, its working directory,
# start time, exit code and a short output tail to the command log.
# Usage: logrun.sh <workdir> <command string>
W=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro52_run2_20261015_011513
LOG="$W/log/command_log.txt"
DIR="$1"; shift
CMD="$*"
TS=$(date '+%Y-%m-%d %H:%M:%S')
OUT=$(mktemp "$W/log/out.XXXXXX")
{
  echo "----"
  echo "[$TS] cwd: ${DIR/#$W/\$W}"
  echo "\$ ${CMD//$W/\$W}"
} >> "$LOG"
( cd "$DIR" && bash -c "$CMD" ) > "$OUT" 2>&1
RC=$?
echo "exit: $RC" >> "$LOG"
cat "$OUT"
echo "[logrun exit code: $RC]"
rm -f "$OUT"
exit $RC
