#!/bin/bash
# Attempt every edit_v*.py change-record script, each in its own disposable copy of the pristine bundle,
# exactly as a reader would run it (python3 <script> from the bundle's top folder), and report the exit code,
# the last line of its output, and whether it changed any file (sha256 of every file before and after).
W=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro52_run2_20261015_011513
P="$W/pristine/User_First_Intelligence_v5.2_2026-10-15_source"
R="$W/edit_runs"
mkdir -p "$R"
for f in $(cd "$P" && ls edit_v*.py | sort -V); do
  s="${f%.py}"
  d="$R/$s"
  rm -rf "$d"; mkdir -p "$d"
  cp -Rp "$P" "$d/"
  b="$d/User_First_Intelligence_v5.2_2026-10-15_source"
  (cd "$d" && find . -type f -print0 | sort -z | xargs -0 shasum -a 256) > "$d/before.sha"
  (cd "$b" && python3 "$f" > "$d/stdout.txt" 2> "$d/stderr.txt"); rc=$?
  (cd "$d" && find . -type f ! -name before.sha ! -name after.sha ! -name stdout.txt ! -name stderr.txt -print0 | sort -z | xargs -0 shasum -a 256) > "$d/after.sha"
  changed=$(diff <(grep -v -e ' ./before.sha$' -e ' ./stdout.txt$' -e ' ./stderr.txt$' "$d/before.sha") "$d/after.sha" | grep -c '^[<>]')
  last=$(cat "$d/stdout.txt" "$d/stderr.txt" | tail -1 | cut -c1-200)
  echo "$f | exit $rc | changed-file lines in sha diff: $changed | last line: $last"
done
