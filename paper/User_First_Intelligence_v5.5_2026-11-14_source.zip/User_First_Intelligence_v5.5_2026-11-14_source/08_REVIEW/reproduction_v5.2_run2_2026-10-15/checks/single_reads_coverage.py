"""Reproducer's own check: single dashboard reads the manuscript quotes, and whether each appears in a released
data file of the bundle (CSV, JSON or TXT data, excluding script outputs, the literature search and the earlier
reproduction). README.txt says single_reads_2026-10.csv holds "every single dashboard read the paper quotes";
Appendix A says version 5.2 "released every single dashboard read the paper quotes as a data file".
Usage: python3 -I single_reads_coverage.py <bundle dir>
"""
import re
import sys
from pathlib import Path

B = Path(sys.argv[1])
ms = (B / "manuscript_v50.md").read_text(encoding="utf-8")
data_files = [p for p in B.rglob("*") if p.is_file() and p.suffix in (".csv", ".json", ".txt")
              and not any(x in p.parts for x in ("08_REVIEW", "literature", "framework_test_r1"))
              and "_output" not in p.name and p.name not in ("arxiv_abstract.txt", "raw_exports_SHA1SUMS.txt")]
texts = {p.relative_to(B).as_posix(): p.read_text(encoding="utf-8", errors="replace") for p in data_files}
figs = (B / "make_figs_v4.py").read_text(encoding="utf-8")

# (what, how it is quoted in the paper, patterns that would count as the value in a data file)
READS = [
    ("Ahrefs Domain Rating of the domain", "an Ahrefs Domain Rating of 90", [r"\b90\b.*domain rating|domain rating.*\b90\b"]),
    ("Semrush Authority Score of the domain", "a Semrush Authority Score of 86", [r"authority score.*\b86\b|\b86\b.*authority score"]),
    ("Ahrefs ranking keywords, 11 Oct", "Ahrefs reports 29,000 for all locations", [r"\b29,?000\b"]),
    ("Semrush US ranking keywords, 10 Oct", "Semrush 58,586 for the US database", [r"\b58,?586\b"]),
    ("Semrush worldwide ranking keywords, 12 Oct", "is 92.3K", [r"\b92\.3K\b", r"\b92,?300\b"]),
    ("Semrush referring domains, 11 Oct", "indexes 80 for the subfolder", [r"semrush.*\b80\b.*referring|referring.*\b80\b"]),
    ("Ahrefs TLD composition", "Ahrefs puts 61.9% on .info, 26.4% on .asia and 10.2% on .xyz", [r"61\.9", r"26\.4%"]),
    ("Semrush TLD and Authority Score composition", "Semrush puts 75% on .xyz and 88% at Authority Score 0 to 10", [r"\b88%"]),
    ("Ahrefs new and lost referring domains, September", "917 new against 95 lost", [r"917 new", r"\b95 lost"]),
    ("Brand Radar answers citing each hub and code page", "New York 474 answers, California 337", [r"\b474\b.*(new york|hub)|(new york|hub).*\b474\b"]),
    ("Domain Ratings of the incumbent pages", "Domain Rating 13 to 83", [r"\b13\b.*\b83\b"]),
    ("Domain Rating of Wikipedia", "Wikipedia, at 97", [r"wikipedia.*\b97\b"]),
    ("URL Rating of linking pages", "every linking page at URL Rating below 10", [r"url rating"]),
    ("reported searches of the lowest-traffic keywords", "40 to 170 reported searches", [r"\b40\b.*\b170\b"]),
]
print(f"released data files searched: {len(texts)}")
for what, quote, pats in READS:
    assert quote in ms, quote
    hits = [f for f, t in texts.items() if any(re.search(p, t, re.I) for p in pats)]
    in_fig = "yes" if any(re.search(p, figs, re.I) for p in pats) or (what.startswith("Brand Radar") and "474" in figs) \
        or (what == "Ahrefs TLD composition" and "61.9" in figs) else "no"
    print(f"{what:55s} | paper: '{quote}' | in a released data file: {', '.join(hits) if hits else 'NO'} | literal in make_figs_v4.py: {in_fig}")
