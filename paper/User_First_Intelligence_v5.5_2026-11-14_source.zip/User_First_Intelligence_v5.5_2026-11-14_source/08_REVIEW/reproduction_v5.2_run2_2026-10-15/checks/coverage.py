"""Reproducer's own bookkeeping: which numeric tokens of the manuscript lie outside every quote checked in
numbers_table.tsv. Prints, per manuscript line, the numbers not covered, skipping the reference list.
Usage: python3 -I coverage.py <manuscript_v50.md> <numbers_table.tsv>
"""
import csv
import re
import sys

ms = open(sys.argv[1], encoding="utf-8").read().split("\n")
rows = list(csv.DictReader(open(sys.argv[2], encoding="utf-8"), delimiter="\t"))
NUM = re.compile(r"[−+-]?\d[\d,]*(?:\.\d+)?")
ref_start = next(i for i, line in enumerate(ms) if line.startswith("## References"))
ref_end = next(i for i, line in enumerate(ms) if line.startswith("## Appendix A"))
covered = {}
for r in rows:
    for ln in r["line"].split(","):
        covered.setdefault(int(ln), []).append(re.sub(r"\s+", " ", r["quote"]))
for i, line in enumerate(ms, 1):
    if ref_start < i <= ref_end or not line.strip():
        continue
    text = re.sub(r"\s+", " ", line)
    spans = []
    for q in covered.get(i, []):
        start = 0
        while True:
            k = text.find(q, start)
            if k < 0:
                break
            spans.append((k, k + len(q)))
            start = k + 1
    out = []
    for m in NUM.finditer(text):
        if not any(a <= m.start() and m.end() <= b for a, b in spans):
            out.append(m.group())
    if out:
        print(f"{i}: {' '.join(out)}")
