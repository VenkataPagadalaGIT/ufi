"""Compare two PDF files byte for byte and describe every differing region.

Usage: python3 -I pdfdiff_bytes.py <a.pdf> <b.pdf>

Prints the size of each file, the number of differing bytes (when sizes are equal), and for
each contiguous run of differing bytes the surrounding text from both files, so that a
difference confined to metadata (for example /CreationDate) can be told apart from a
difference in page content. If the only differences are inside /CreationDate (or /ModDate)
strings, the script says so explicitly.
"""
import re
import sys


def main(a_path, b_path):
    a = open(a_path, "rb").read()
    b = open(b_path, "rb").read()
    print(f"{a_path}: {len(a)} bytes")
    print(f"{b_path}: {len(b)} bytes")
    if a == b:
        print("IDENTICAL")
        return
    if len(a) != len(b):
        print("sizes differ: not a metadata-only difference of equal length")
    n = min(len(a), len(b))
    runs, i = [], 0
    while i < n:
        if a[i] != b[i]:
            j = i
            while j < n and a[j] != b[j]:
                j += 1
            runs.append((i, j))
            i = j
        else:
            i += 1
    print(f"differing runs (over the common length): {len(runs)}")
    date_re = re.compile(rb"/(CreationDate|ModDate) \(D:[0-9]{14}[^)]*\)")
    spans_a = [(m.start(), m.end()) for m in date_re.finditer(a)]
    only_dates = len(a) == len(b)
    for s, e in runs[:20]:
        ctx_a = a[max(0, s - 40):e + 40]
        ctx_b = b[max(0, s - 40):e + 40]
        print(f"  bytes {s}..{e}:")
        print(f"    a: {ctx_a!r}")
        print(f"    b: {ctx_b!r}")
        if not any(ds <= s and e <= de for ds, de in spans_a):
            only_dates = False
    if only_dates:
        print("RESULT: the files differ only inside /CreationDate or /ModDate strings (metadata timestamp)")
    else:
        print("RESULT: the files differ outside the PDF date metadata")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
