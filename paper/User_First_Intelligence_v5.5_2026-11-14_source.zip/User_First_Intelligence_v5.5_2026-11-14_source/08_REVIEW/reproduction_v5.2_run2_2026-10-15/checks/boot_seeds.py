"""Reproducer's own check: the Section 7 bootstrap interval of the two medians, recomputed from the released
aggregates with my own code, first with the seed section7_from_aggregates.py uses (20261013), then with seeds
1 to 20, to show how much the printed interval depends on the seed.
Usage: python3 -I boot_seeds.py <bundle dir>
"""
import csv
import random
import statistics
import sys
from pathlib import Path

B = Path(sys.argv[1])
SECT = ["xlk", "xlv", "xlf", "xly", "xlc", "xli", "xlp", "xle", "xlu", "xlre", "xlb"]
GOO = ["aio_searchqueries", "aio_prompts", "aimode_searchqueries", "aimode_prompts"]
OTH = ["chatgpt", "perplexity", "gemini", "copilot"]
PM = {(r["etf"], r["surface"]): float(r["share_community_video"])
      for r in csv.DictReader((B / "ai_citation_cross_sector/aggregates/cross_sector_platform_metrics.csv").open())}


def boot(seed):
    rnd = random.Random(seed)
    bg, bo = [], []
    for _ in range(10000):
        ss = [rnd.choice(SECT) for _ in SECT]
        bg.append(statistics.median([PM[(s, p)] for s in ss for p in GOO]))
        bo.append(statistics.median([PM[(s, p)] for s in ss for p in OTH]))
    bg.sort()
    bo.sort()
    return bg[249], bg[9749], bo[249], bo[9749]


a = boot(20261013)
print(f"seed 20261013 (the script's): Google {a[0]:.1%} to {a[1]:.1%}; other four {a[2]:.1%} to {a[3]:.1%}")
res = [boot(s) for s in range(1, 21)]
for i, k in enumerate(("Google lower", "Google upper", "other lower", "other upper")):
    vals = [r[i] for r in res]
    print(f"seeds 1 to 20, {k}: {min(vals):.1%} to {max(vals):.1%}")
