"""Offline reading of an OpenTimestamps proof (.ots), without the ots client (not installed here).

Usage: python3 -I ots_parse.py <file.ots> <stamped file>

Checks that the proof's file digest equals the SHA-256 of the stamped file, walks the timestamp tree executing
each operation (append, prepend, sha256, sha1, ripemd160, keccak256, reverse, hexlify), and prints every
attestation with the commitment reached there. For a Bitcoin attestation the commitment is the block's merkle
root in internal byte order; block explorers show the byte-reversed hex, so both are printed.
This verifies the structure and the claimed height offline; it cannot confirm that the merkle root belongs to
that block without a copy of the block header.
"""
import hashlib
import sys

MAGIC = b"\x00OpenTimestamps\x00\x00Proof\x00\xbf\x89\xe2\xe8\x84\xe8\x92\x94"
BTC = bytes.fromhex("0588960d73d71901")
PENDING = bytes.fromhex("83dfe30d2ef90c8e")
LTC = bytes.fromhex("06869a0d73d71b45")
ETH = bytes.fromhex("30fe8087b5c7ead7")


class R:
    def __init__(self, b):
        self.b, self.i = b, 0

    def byte(self):
        v = self.b[self.i]
        self.i += 1
        return v

    def bytes(self, n):
        v = self.b[self.i:self.i + n]
        if len(v) != n:
            raise ValueError("truncated")
        self.i += n
        return v

    def varuint(self):
        v, s = 0, 0
        while True:
            c = self.byte()
            v |= (c & 0x7F) << s
            if not c & 0x80:
                return v
            s += 7

    def varbytes(self):
        return self.bytes(self.varuint())


def keccak256(_):
    raise NotImplementedError("keccak256 op not supported offline here")


def apply(tag, arg, msg):
    if tag == 0xF0:
        return msg + arg
    if tag == 0xF1:
        return arg + msg
    if tag == 0xF2:
        return msg[::-1]
    if tag == 0xF3:
        return msg.hex().encode()
    if tag == 0x08:
        return hashlib.sha256(msg).digest()
    if tag == 0x02:
        return hashlib.sha1(msg).digest()
    if tag == 0x03:
        return hashlib.new("ripemd160", msg).digest()
    if tag == 0x67:
        return keccak256(msg)
    raise ValueError(f"unknown op tag {tag:#x}")


def walk(r, msg, depth, out):
    # A timestamp is: (0xff item)* item, where item is an attestation (0x00 ...) or an op followed by a timestamp.
    while True:
        tag = r.byte()
        last = tag != 0xFF
        if not last:
            tag = r.byte()
        if tag == 0x00:
            atag = r.bytes(8)
            payload = r.varbytes()
            p = R(payload)
            if atag == BTC:
                out.append(("bitcoin", p.varuint(), msg))
            elif atag == LTC:
                out.append(("litecoin", p.varuint(), msg))
            elif atag == PENDING:
                out.append(("pending", p.varbytes().decode("utf-8", "replace"), msg))
            elif atag == ETH:
                out.append(("ethereum", p.varuint(), msg))
            else:
                out.append(("unknown:" + atag.hex(), payload.hex(), msg))
        else:
            arg = r.varbytes() if tag in (0xF0, 0xF1) else b""
            walk(r, apply(tag, arg, msg), depth + 1, out)
        if last:
            return


def main(ots_path, stamped_path):
    b = open(ots_path, "rb").read()
    r = R(b)
    if r.bytes(len(MAGIC)) != MAGIC:
        raise SystemExit("not an OpenTimestamps proof (bad magic)")
    version = r.varuint()
    file_op = r.byte()
    if file_op != 0x08:
        raise SystemExit(f"file hash op {file_op:#x} is not SHA-256")
    digest = r.bytes(32)
    actual = hashlib.sha256(open(stamped_path, "rb").read()).digest()
    print(f"proof version {version}; file hash SHA-256 {digest.hex()}")
    print(f"SHA-256 of {stamped_path.split('/')[-1]}: {actual.hex()}  -> {'MATCH' if digest == actual else 'MISMATCH'}")
    out = []
    walk(r, digest, 0, out)
    print(f"bytes read {r.i} of {len(b)}")
    for kind, val, msg in out:
        if kind == "bitcoin":
            print(f"attestation: Bitcoin block height {val}; merkle root (internal order) {msg.hex()}; "
                  f"as block explorers show it {msg[::-1].hex()}")
        else:
            print(f"attestation: {kind} {val}; commitment {msg.hex()}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
