"""check_numbers.py: the reproducer's own check (run 2, 15 October 2026), not an author script.

Every number the paper (manuscript_v50.md in the bundle) quotes from a bundle script, and the arithmetic and
data-file numbers around them, compared with:
  S  the output of the bundle script as I reran it from the bundle (my rerun outputs in <W>/outputs);
  X  the output file shipped beside a script that cannot run here (status CANNOT RUN; agreement noted);
  C  my own recomputation from files in the bundle, or arithmetic on the paper's own tables;
  D  a value in a released data file (single dashboard reads, prefix data, design files);
  F  a literal in a bundle figure script;
  N  a number produced by a tool that is not in the bundle (status CANNOT RUN).
Every quote is looked up verbatim in the manuscript first; the script stops if a quote is not found.
A paper value matches when the obtained value, rounded half-up to the paper's precision, equals it.

Usage: python3 -I check_numbers.py <working folder> <out.md> <out.tsv>
"""
import csv
import math
import random
import re
import statistics
import sys
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP
from itertools import combinations
from pathlib import Path

from scipy.stats import kendalltau, spearmanr

W = Path(sys.argv[1])
OUT_MD, OUT_TSV = Path(sys.argv[2]), Path(sys.argv[3])
B = W / "pristine" / "User_First_Intelligence_v5.2_2026-10-15_source"
O = W / "outputs"
RAW = (B / "manuscript_v50.md").read_text(encoding="utf-8")
LINES = RAW.split("\n")
MS = re.sub(r"\s+", " ", RAW)
M = "\u2212"  # the manuscript's minus sign
med = statistics.median


def rd(p):
    return Path(p).read_text(encoding="utf-8")


# ----------------------------------------------------------------------------------------------- inputs
A = rd(O / "analyze_output.txt")
IE = rd(O / "instrument_extra_output.txt")
LC = rd(O / "r2_link_check_output.txt")
S7 = rd(O / "section7_from_aggregates_output.txt")
MT = rd(O / "make_tables_sector_surface_output.txt")
VR = rd(O / "vendor_reliance_output.txt")
NT = rd(O / "prev_checks/numbers_table_stdout.txt")
BR = rd(O / "make_brand_radar_urls_stdout.txt")
OTS = rd(O / "ots_parse.txt")
EXPL = rd(O / "block_explorer_check.txt")
AR = rd(B / "review_demand/analyze_reviews_output.txt")
SR = rd(B / "review_demand/supplement_r10_output.txt")
LS = rd(B / "review_demand/r2_link_sample_output.txt")
CS = rd(B / "ai_citation_cross_sector/scripts/cross_sector_output.txt")
CSS = rd(B / "ai_citation_cross_sector/scripts/cross_sector_sensitivity_output.txt")
CSS2 = rd(B / "ai_citation_cross_sector/scripts/cross_sector_sensitivity2_output.txt")
PIL = rd(B / "ai_citation_cross_sector/scripts/pilot_section_output.txt")
FIGS = rd(B / "make_figs_v4.py")
SINGLE = {r["quantity"]: r["value"] for r in csv.DictReader((B / "instrument_divergence_extra/single_reads_2026-10.csv").open())}
AC = {r["prefix"]: r for r in csv.DictReader((B / "data/ahrefs_prefixes_2026-10-12.csv").open())}
SC = {r["prefix"]: r for r in csv.DictReader((B / "data/semrush_prefixes_2026-10-12.csv").open())}
CODES = list(csv.DictReader((B / "instrument_divergence_extra/section_code_pages_2026-10-14.csv").open()))
AGG = B / "ai_citation_cross_sector/aggregates"
DES = B / "ai_citation_cross_sector/design"
COMPANIES = list(csv.DictReader((DES / "cross_sector_companies.csv").open()))
PROPS = list(csv.DictReader((DES / "cross_sector_company_properties.csv").open()))


def g(text, pat, *grp):
    m = re.search(pat, text, re.M)
    if not m:
        raise SystemExit(f"PATTERN NOT FOUND: {pat!r}")
    if not grp:
        return m.group(1) if len(m.groups()) == 1 else m.groups()
    return m.group(grp[0]) if len(grp) == 1 else tuple(m.group(i) for i in grp)


# ----------------------------------------------------------------------------------------------- comparison
def dec(v):
    if isinstance(v, float):
        return Decimal(repr(v))
    if isinstance(v, int):
        return Decimal(v)
    t = str(v).strip().replace(",", "").replace(M, "-").replace("+", "").replace("≈", "")
    t = re.sub(r"[x%]$", "", t)
    return Decimal(t)


def agree(paper, got):
    if isinstance(paper, str) and paper.startswith("="):
        return paper[1:] == str(got).removeprefix("=")
    p, v = dec(paper), dec(got)
    q = Decimal(1).scaleb(p.as_tuple().exponent)
    return v.quantize(q, rounding=ROUND_HALF_UP) == p


def show(v):
    if isinstance(v, float):
        s = f"{v:.4f}".rstrip("0").rstrip(".")
        return s
    return str(v).removeprefix("=")


def where(quote):
    q = re.sub(r"\s+", " ", quote)
    hits = [i + 1 for i, line in enumerate(LINES) if q in re.sub(r"\s+", " ", line)]
    if not hits:
        raise SystemExit(f"QUOTE NOT FOUND IN MANUSCRIPT: {quote!r}")
    return hits


ROWS = []


def R(sec, quote, script, basis, pairs, note=""):
    """One quoted number (or a group quoted together). pairs: (paper value, obtained value)."""
    lines = where(quote)
    if basis == "N":  # produced by a tool that is not in the bundle: nothing to compare
        ok, bad = True, []
    else:
        ok = all(agree(p, v) for p, v in pairs)
        bad = [f"paper {show(p)} vs obtained {show(v)}" for p, v in pairs if not agree(p, v)]
    if basis in ("X", "N"):
        status = "CANNOT RUN"
        if basis == "X":
            note = ("shipped output agrees" if ok else "shipped output DIFFERS: " + "; ".join(bad)) + (f"; {note}" if note else "")
    else:
        status = "MATCH" if ok else "MISMATCH: " + "; ".join(bad)
    ROWS.append(dict(sec=sec, line=",".join(map(str, lines[:3])), quote=quote, script=script, basis=basis,
                     paper="; ".join(show(p) for p, _ in pairs), got="; ".join(show(v) for _, v in pairs),
                     status=status, note=note))


def md_table(caption_prefix):
    i = next(k for k, line in enumerate(LINES) if line.startswith(caption_prefix))
    j = i + 1
    while not LINES[j].startswith("|"):
        j += 1
    start = j
    rows = []
    while j < len(LINES) and LINES[j].startswith("|"):
        rows.append([c.strip() for c in LINES[j].strip().strip("|").split("|")])
        j += 1
    return rows[0], rows[2:], start + 3  # header, body rows, 1-based line of first body row


def n(s):
    return float(str(s).replace(",", "").replace("≈", "").replace("*", "").strip())


# ===================================================================================================== Table 2
_, T2, _ = md_table("*Table 2.")
T2 = {r[0]: r for r in T2}
t2 = {}
for k in ("July 2026 (total)", "August 2026 (total)", "September 2026 (total)", "October 2026 (run-rate)"):
    r = T2[k]
    ah = n(r[2])
    us, ww = re.match(r"([\d,]+) \(([\d,]+)\)", r[3]).groups()
    t2[k] = dict(ah=ah, us=n(us), ww=n(ww), usww=n(us) / ah, wwww=n(ww) / ah, usus=n(us) / (ah * 0.815), row=r)
r_usww = [v["usww"] for v in t2.values()]
r_wwww = [v["wwww"] for v in t2.values()]
r_usus = [v["usus"] for v in t2.values()]
# Table 5 and Table 6
_, T5, _ = md_table("*Table 5.")
T5 = {r[0]: [c.replace("*", "") for c in r[1:]] for r in T5}
DAYS = [0, 15, 30, 37, 45, 60, 75, 77]


def t5(metric, day):
    v = T5[metric][DAYS.index(day)]
    return None if v in ("n/r",) else n(v)


_, T6, _ = md_table("*Table 6.")
_, T3, _ = md_table("*Table 3.")


def wilson(k, nn, z=1.96):
    p = k / nn
    c = (p + z * z / (2 * nn)) / (1 + z * z / nn)
    h = z * math.sqrt(p * (1 - p) / nn + z * z / (4 * nn * nn)) / (1 + z * z / nn)
    return c - h, c + h


# ===================================================================================================== analyze.py (my independent re-implementation with scipy, from the two data files)
pre = []
for p, a in AC.items():
    s = SC[p]
    y, mo = map(int, a["ahrefs_first_traffic_month"].split("-"))
    at, st = float(a["ahrefs_organic_traffic"]), float(s["semrush_organic_traffic_us"])
    ak, sk = float(a["ahrefs_organic_keywords"]), float(s["semrush_organic_keywords_us"])
    us = float(a["ahrefs_us_share"])
    pre.append(dict(p=p, age=(2026 - y) * 12 + (10 - mo), at=at, st=st, ak=ak, sk=sk, us=us, vr=st / at, vru=st / (at * us),
                    kr=sk / ak, rd=float(a["ahrefs_ref_domains"]) / float(s["semrush_ref_domains"]),
                    ard=float(a["ahrefs_ref_domains"]), srd=float(s["semrush_ref_domains"])))
my = {}
my["rho_age"] = spearmanr([r["age"] for r in pre], [r["vr"] for r in pre]).statistic
z = math.atanh(my["rho_age"])
my["fisher"] = (math.tanh(z - 1.96 / 3), math.tanh(z + 1.96 / 3))
my["rho_age_us"] = spearmanr([r["age"] for r in pre], [r["vru"] for r in pre]).statistic
px = [r for r in pre if "area-codes" not in r["p"]]
my["rho_age_x"] = spearmanr([r["age"] for r in px], [r["vr"] for r in px]).statistic
my["rho_kv"] = spearmanr([r["kr"] for r in pre], [r["vr"] for r in pre]).statistic
my["rho_kv_x"] = spearmanr([r["kr"] for r in px], [r["vr"] for r in px]).statistic
my["rho_v"] = spearmanr([r["at"] for r in pre], [r["st"] for r in pre]).statistic
my["tau_v"] = kendalltau([r["at"] for r in pre], [r["st"] for r in pre]).statistic
conc = sum(1 for a_, b_ in combinations(pre, 2) if (a_["at"] - b_["at"]) * (a_["st"] - b_["st"]) > 0)
my["conc"] = conc
my["median"] = med([r["vr"] for r in pre])
my["median_us"] = med([r["vru"] for r in pre])
my["below"] = sum(r["vr"] < 1 for r in pre)
my["below_us"] = sum(r["vru"] < 1 for r in pre)
rnd = random.Random(20261015)
obs = abs(my["rho_age"])
yy = [r["vr"] for r in pre]
hits = 0
for _ in range(20000):
    rnd.shuffle(yy)
    hits += abs(spearmanr([r["age"] for r in pre], yy).statistic) >= obs - 1e-12
my["perm_p"] = hits / 20000
# Fisher-approximation power for rho = 0.5, n = 12, two-sided 5%
zr, se = math.atanh(0.5), 1 / math.sqrt(9)
Phi = lambda x: 0.5 * (1 + math.erf(x / math.sqrt(2)))
my["power"] = Phi(zr / se - 1.959964) + Phi(-zr / se - 1.959964)
my_note = (f"my scipy re-implementation from the data files: rho(age) {my['rho_age']:+.3f}, Fisher [{my['fisher'][0]:+.2f}, "
           f"{my['fisher'][1]:+.2f}], permutation p {my['perm_p']:.2f} (own seed), matched {my['rho_age_us']:+.3f}, "
           f"excl. area codes {my['rho_age_x']:+.3f}")

# ===================================================================================================== Section 7 (my independent recomputation from the released aggregates)
SECT = ["xlk", "xlv", "xlf", "xly", "xlc", "xli", "xlp", "xle", "xlu", "xlre", "xlb"]
GOO = ["aio_searchqueries", "aio_prompts", "aimode_searchqueries", "aimode_prompts"]
OTH = ["chatgpt", "perplexity", "gemini", "copilot"]
SURF = GOO + OTH
PM = {(r["etf"], r["surface"]): r for r in csv.DictReader((AGG / "cross_sector_platform_metrics.csv").open())}
TS = {(r["etf"], r["surface"]): {k: float(v) for k, v in r.items() if k.startswith("share_")}
      for r in csv.DictReader((AGG / "cross_sector_type_shares.csv").open())}
CE = {(r["etf"], r["surface"]): r for r in csv.DictReader((AGG / "cross_sector_cells.csv").open())}
TOP = {}
for r in csv.DictReader((AGG / "cross_sector_top10_nonbrand.csv").open()):
    TOP.setdefault((r["etf"], r["surface"]), []).append((int(r["rank"]), r["domain"]))
TOP = {k: [d for _, d in sorted(v)] for k, v in TOP.items()}
CNT = {r["etf"]: r for r in csv.DictReader((AGG / "sector_answer_counts.csv").open())}
vc = {(s, p): float(PM[(s, p)]["share_community_video"]) for s in SECT for p in SURF}
q7 = {}
q7["g_med"] = med([vc[(s, p)] for s in SECT for p in GOO])
q7["o_med"] = med([vc[(s, p)] for s in SECT for p in OTH])
q7["g_rng"] = (min(vc[(s, p)] for s in SECT for p in GOO), max(vc[(s, p)] for s in SECT for p in GOO))
q7["o_rng"] = (min(vc[(s, p)] for s in SECT for p in OTH), max(vc[(s, p)] for s in SECT for p in OTH))
q7["surf"] = {p: med([vc[(s, p)] for s in SECT]) for p in SURF}
q7["dom"] = sum(min(vc[(s, p)] for p in GOO) > max(vc[(s, p)] for p in OTH) for s in SECT)
q7["prompts"] = med([vc[(s, p)] for s in SECT for p in ("aio_prompts", "aimode_prompts")])


def yrank(s, p):
    v = PM[(s, p)]["yt_rank_nonbrand"]
    return int(v) if v else 99999


q7["top3_g"] = sum(yrank(s, p) <= 3 for s in SECT for p in GOO)
q7["top3_o"] = sum(yrank(s, p) <= 3 for s in SECT for p in OTH)
q7["mrank"] = {p: med([yrank(s, p) for s in SECT]) for p in SURF}
noyt = {(s, p): vc[(s, p)] - float(PM[(s, p)]["yt_share"]) for s in SECT for p in SURF}
q7["noyt_g"] = med([noyt[(s, p)] for s in SECT for p in GOO])
q7["noyt_o"] = med([noyt[(s, p)] for s in SECT for p in OTH])
q7["noyt_dom"] = sum(min(noyt[(s, p)] for p in GOO) > max(noyt[(s, p)] for p in OTH) for s in SECT)
for t in ("reference", "forum", "report_brands", "other_web"):
    q7[t] = (med([TS[(s, p)][f"share_{t}"] for s in SECT for p in GOO]), med([TS[(s, p)][f"share_{t}"] for s in SECT for p in OTH]),
             med([TS[(s, "copilot")][f"share_{t}"] for s in SECT]))
q7["p1"] = {p: sum(PM[(s, p)]["top1_nonbrand"] == "youtube.com" for s in SECT) for p in GOO}
q7["p2"] = {p: sum(yrank(s, p) > 5 for s in SECT) for p in ("chatgpt", "perplexity", "copilot")}


def rrank(s, p):
    v = PM[(s, p)]["reddit_rank_nonbrand"]
    return int(v) if v else 99999


p3_hold = [s for s in SECT if all(rrank(s, p) <= 10 for p in SURF if p != "copilot")]
q7["p3"] = len(p3_hold)
q7["p3_chatgpt_fail"] = sum(rrank(s, "chatgpt") > 10 for s in SECT if s not in p3_hold)
CONS, NONC = ["xly", "xlp", "xlc", "xlv", "xlk"], ["xle", "xlb", "xlu", "xlre", "xli"]


def exact_p(a, b):
    obs_ = statistics.mean(a) - statistics.mean(b)
    allv = a + b
    ge = tot = 0
    for idx in combinations(range(len(allv)), len(a)):
        x = [allv[i] for i in idx]
        y = [allv[i] for i in range(len(allv)) if i not in idx]
        tot += 1
        ge += statistics.mean(x) - statistics.mean(y) >= obs_ - 1e-12
    return ge / tot


q7["p4"] = {p: (statistics.mean(vc[(s, p)] for s in CONS), statistics.mean(vc[(s, p)] for s in NONC),
                exact_p([vc[(s, p)] for s in CONS], [vc[(s, p)] for s in NONC])) for p in ("aio_searchqueries", "aio_prompts")}
q7["jac"] = {p: statistics.mean(len(set(TOP[(a_, p)]) & set(TOP[(b_, p)])) / len(set(TOP[(a_, p)]) | set(TOP[(b_, p)]))
                                for a_, b_ in combinations(SECT, 2)) for p in SURF}


def varshare(vals):
    gm = statistics.mean(vals.values())
    tot = sum((x - gm) ** 2 for x in vals.values())
    ssp = len(SECT) * sum((statistics.mean(vals[(s, p)] for s in SECT) - gm) ** 2 for p in SURF)
    sss = len(SURF) * sum((statistics.mean(vals[(s, p)] for p in SURF) - gm) ** 2 for s in SECT)
    return ssp / tot, sss / tot


TS2 = {k: dict(v, share_video_community=v["share_video"] + v["share_forum"] + v["share_social"] + v["share_user_publishing"]) for k, v in TS.items()}
q7["var"] = {t: varshare({(s, p): TS2[(s, p)][f"share_{t}"] for s in SECT for p in SURF})
             for t in ("video_community", "news", "government", "report_brands")}
q7["cells"] = (min(int(CE[(s, p)]["cited_in_sum"]) for s in SECT for p in SURF), max(int(CE[(s, p)]["cited_in_sum"]) for s in SECT for p in SURF))
q7["regdom"] = (min(int(CE[(s, p)]["registrable_domains"]) for s in SECT for p in SURF), max(int(CE[(s, p)]["registrable_domains"]) for s in SECT for p in SURF))
q7["trunc"] = {p: med([float(CE[(s, p)]["mass_rows_501_1000"]) for s in SECT]) for p in SURF}
q7["answers"] = sum(int(r["ai_responses_us_all_platforms"]) for r in CNT.values())
q7["ans_min"] = min(CNT.values(), key=lambda r: int(r["ai_responses_us_all_platforms"]))
q7["ans_max"] = max(CNT.values(), key=lambda r: int(r["ai_responses_us_all_platforms"]))
q7["read_first"] = min(r["read_at_local"] for r in CNT.values())
S10 = [s for s in SECT if s != "xli"]
q7["noind_chatgpt"] = med([vc[(s, "chatgpt")] for s in S10])
q7["noind_p2"] = {p: sum(yrank(s, p) > 5 for s in S10) for p in ("chatgpt", "perplexity", "copilot")}
q7["noind_p3"] = sum(all(rrank(s, p) <= 10 for p in SURF if p != "copilot") for s in S10)


def first_without_google(s, p):
    return next(d for d in TOP[(s, p)] if d != "google.com")


p1g = {p: sum(first_without_google(s, p) == "youtube.com" for s in SECT) for p in GOO}
p1g_both = sum((first_without_google(s, "aio_searchqueries") == "youtube.com" or first_without_google(s, "aio_prompts") == "youtube.com")
               and (first_without_google(s, "aimode_searchqueries") == "youtube.com" or first_without_google(s, "aimode_prompts") == "youtube.com")
               for s in SECT)
q7["p1_google_aside"] = p1g_both
# bootstrap over sectors of the two medians (my own seed and scheme: 10,000 resamples of the 11 sectors)
rb = random.Random(7)
bg, bo = [], []
for _ in range(10000):
    smp = [rb.choice(SECT) for _ in SECT]
    bg.append(med([vc[(s, p)] for s in smp for p in GOO]))
    bo.append(med([vc[(s, p)] for s in smp for p in OTH]))
bg.sort()
bo.sort()
q7["boot_g"] = (bg[249], bg[9749])
q7["boot_o"] = (bo[249], bo[9749])
s7_note = (f"my recomputation from the aggregates: Google {q7['g_med']:.1%}, other {q7['o_med']:.1%}; my own bootstrap "
           f"(seed 7) Google {q7['boot_g'][0]:.1%} to {q7['boot_g'][1]:.1%}, other {q7['boot_o'][0]:.1%} to {q7['boot_o'][1]:.1%}")

# ===================================================================================================== link check (my recount from the judgment files)
def judg(name, key):
    return {r["sample_id"]: r[key].strip().lower() for r in csv.DictReader((B / "review_demand" / name).open())}


def kappa(a, b):
    ids = sorted(set(a) & set(b))
    po = sum(a[i] == b[i] for i in ids) / len(ids)
    cats = set(a.values()) | set(b.values())
    pe = sum((sum(a[i] == c for i in ids) / len(ids)) * (sum(b[i] == c for i in ids) / len(ids)) for c in cats)
    return (po - pe) / (1 - pe), po


ja1, ja2 = judg("r2_judgments_A.csv", "judgment"), judg("r2_judgments_A_annotator2.csv", "judgment")
jb1, jb2 = judg("r2_judgments_B.csv", "waiting_complaint"), judg("r2_judgments_B_annotator2.csv", "waiting_complaint")
ka, poa = kappa(ja1, ja2)
kb, pob = kappa(jb1, jb2)
lc_note = f"my recount from the judgment files: A agreement {poa:.1%}, kappa {ka:.3f}; B agreement {pob:.1%}, kappa {kb:.3f}"

# ===================================================================================================== stakes (my recount from the work list)
works = list(csv.DictReader((B / "stakes/vendor_reliance_works.csv").open()))
seen, uniq = set(), []
for r in works:
    if r["id"] not in seen:
        seen.add(r["id"])
        uniq.append(r)
named = [r for r in uniq if int(r["n_tools"]) >= 1]
named_raw = [r for r in works if int(r["n_tools"]) >= 1]
yr = {y: sum(r["year"] == y for r in named) for y in ("2020", "2025", "2026")}
one = sum(int(r["n_tools"]) == 1 for r in named) / len(named)
vr_note = f"my recount from vendor_reliance_works.csv: {len(named)} works; 2020 {yr['2020']}, 2025 {yr['2025']}, 2026 {yr['2026']}; one tool {one:.1%}"

# ===================================================================================================== the rows, in the paper's order
# ---- Abstract
R("Abstract", "differed on estimated monthly visits by 7.5x to 27.1x, and by 8.6x to 29.9x with both read worldwide",
  "none (arithmetic on Table 2)", "C", [("7.5x", min(r_usww)), ("27.1x", max(r_usww)), ("8.6x", min(r_wwww)), ("29.9x", max(r_wwww))])
R("Abstract", f"the ratio ran from 0.20x to 7.24x, with no detectable relationship to section age (Spearman {M}0.11), while the platforms agreed on which section is larger in 60 of 66 pairs",
  "analyze.py", "S", [("0.20x", g(A, r"min ([\d.]+)x")), ("7.24x", g(A, r"max ([\d.]+)x")), (f"{M}0.11", g(A, r"rho\(age, visits ratio\) = ([+-][\d.]+)")),
                      ("60", g(A, r"(\d+) of \d+ pairs concordant")), ("66", g(A, r"\d+ of (\d+) pairs concordant"))], my_note)
R("Abstract", "On 37,193 reviews of 378 telecom stores linked to a 42,994-node keyword taxonomy", "analyze_reviews.py; supplement_r10.py", "X",
  [("37,193", g(AR, r"reviews with text: (\d+)")), ("378", g(AR, r"businesses: (\d+)")), ("42,994", g(SR, r"taxonomy nodes: (\d+)"))])
R("Abstract", "(Spearman +0.47 to +0.75, depending on how labels are attributed to branches) and barely on topics (+0.19)", "supplement_r10.py; analyze_reviews.py", "X",
  [("+0.47", g(SR, r"modal attribution: rho=([+-][\d.]+)")), ("+0.75", g(SR, r"split mentions: rho=([+-][\d.]+)")), ("+0.19", g(AR, r"rho=([+-][\d.]+) p=3.4e-09"))])
prec = [float(x) for x in re.findall(r"precision \d+/\d+ = ([\d.]+)% \[Wilson", LC)[:2]]
R("Abstract", "on links two blind annotators judged about two-thirds correct", "r2_link_check.py", "S",
  [("=about two-thirds", "=about two-thirds" if all(62 <= x <= 71 for x in prec) else f"={prec}")], f"precision {prec[1]}% and {prec[0]}% (annotators 2 and 1)")


def tally(text):
    p1 = "fails" in g(text, r"^\s*P1 .*-> (\w+)$", 1)
    p2 = g(text, r"^\s*P2 .*-> (\w+)$", 1) == "holds"
    p3 = "fails" in g(text, r"^\s*P3 .*-> (\w+);", 1)
    p4 = [(float(c), float(o), float(pp)) for c, o, pp in re.findall(r"P4 \w+: consumer ([\d.]+)% against other ([\d.]+)%; exact one-sided p ([\d.]+)", text)]
    direction_only = all(c > o and pp > 0.05 for c, o, pp in p4)
    held = int(p2)
    failed = int(p1) + int(p3)
    return f"={held} held, {int(direction_only)} direction only, {failed} failed"


R("Abstract", "four predictions written before collection yielded one held, one held in direction only and two failed", "section7_from_aggregates.py", "S",
  [("=1 held, 1 direction only, 2 failed", tally(S7))])
surf = dict(re.findall(r"(\w+) ([\d.]+)%", g(S7, r"per surface: (.*)$", 1)))
R("Abstract", "video and community sites took a median 21% of citation incidences on Google's AI Overviews and AI Mode against 0.6% to 9.2% on ChatGPT, Copilot, Perplexity and Gemini",
  "section7_from_aggregates.py", "S", [("21%", g(S7, r"Google views median ([\d.]+)%")), ("0.6%", min(float(surf[p]) for p in OTH)), ("9.2%", max(float(surf[p]) for p in OTH))], s7_note)
R("Abstract", "with the lowest Google figure above the highest of the other four in every sector", "section7_from_aggregates.py", "S",
  [("11", g(S7, r"exceeds the highest other surface: (\d+)/11")), ("11", g(S7, r"exceeds the highest other surface: \d+/(\d+)"))], f"my recount from the aggregates: {q7['dom']} of 11")

# ---- Section 1
R("1, para 3", "in OpenAlex, 456 works name Ahrefs, Semrush or Similarweb in their title or abstract, 27 of them published in 2020, 87 in 2025 and 110 in 2026 to mid-October, and 86% name only one of the three",
  "vendor_reliance.py --offline", "S", [("456", g(VR, r"; (\d+) name at least one tool")), ("27", g(VR, r"2020: (\d+)")), ("87", g(VR, r"2025: (\d+)")),
                                        ("110", g(VR, r"2026: (\d+)")), ("86%", g(VR, r"\((\d+)%\); two or more"))], vr_note)
R("1.1", "observed for 77 days", "none (date arithmetic: 26 July to 11 October 2026)", "C", [("77", (date(2026, 10, 11) - date(2026, 7, 26)).days)])
R("1.2", "differ by up to about 30 times worldwide (33 times US to US, estimated)", "none (arithmetic on Table 2)", "C", [("30", max(r_wwww)), ("33", max(r_usus))])
R("1.2, item 1", "differ on estimated visits by 7.5x to 27.1x (8.6x to 29.9x worldwide against worldwide); across twelve sections of one domain the ratio spans 0.20x to 7.24x",
  "arithmetic on Table 2; analyze.py", "S+C", [("7.5x", min(r_usww)), ("27.1x", max(r_usww)), ("8.6x", min(r_wwww)), ("29.9x", max(r_wwww)),
                                              ("0.20x", g(A, r"min ([\d.]+)x")), ("7.24x", g(A, r"max ([\d.]+)x"))])
R("1.2, item 1", "while the platforms agree on the ordering of sections in 60 of 66 pairs", "analyze.py", "S",
  [("60", g(A, r"(\d+) of \d+ pairs concordant")), ("66", g(A, r"\d+ of (\d+) pairs concordant"))])
R("1.2, item 2", "On 37,193 business reviews linked to a 42,994-node keyword taxonomy", "analyze_reviews.py; supplement_r10.py", "X",
  [("37,193", g(AR, r"reviews with text: (\d+)")), ("42,994", g(SR, r"taxonomy nodes: (\d+)"))])
R("1.2, item 3", "about ten times their pooled median share (21.3% against 2.1%)", "section7_from_aggregates.py (ratio: arithmetic)", "S",
  [("21.3%", g(S7, r"Google views median ([\d.]+)%")), ("2.1%", g(S7, r"other four median ([\d.]+)%")), ("10", 21.3 / 2.1)])
R("1.2, item 3", "of four predictions written before collection, one held, one held in direction only and two failed", "section7_from_aggregates.py", "S",
  [("=1 held, 1 direction only, 2 failed", tally(S7))])
R("1.2, item 5", "(1.2 to 2.0 times the most-cited one)", "none (arithmetic on the Section 9.1 counts)", "C", [("1.2", 294 / 238), ("2.0", 474 / 238)])
R("1.2, item 5", "a 77-day series", "none (date arithmetic)", "C", [("77", (date(2026, 10, 11) - date(2026, 7, 26)).days)])

# ---- Section 3
grp = {}
for r in CODES:
    grp[r["group"]] = grp.get(r["group"], 0) + 1
R("3, para 1", "the section holds 381 code pages**: 374 for geographic codes assigned to US states and the District of Columbia (all 372 in service and two assigned but not yet in service), and 7 for toll-free codes",
  "none (released file section_code_pages_2026-10-14.csv)", "D", [("381", len(CODES)), ("374", sum(r["registry_use"] == "G" for r in CODES)),
                                                                 ("372", grp["geographic, in service"]), ("2", grp["geographic, assigned, not in service"]), ("7", grp["toll-free"])],
  f"{len({r['location'] for r in CODES if r['registry_use'] == 'G'})} distinct state-level locations (50 states and DC); the 52 state hubs are not listed in the bundle")
R("3, para 2", "Table 5's series of pages holding a position (210, 365, 391, 414, 440)", "none (Table 5)", "C",
  [("210", t5("Pages holding a position", 15)), ("365", t5("Pages holding a position", 30)), ("391", t5("Pages holding a position", 45)),
   ("414", t5("Pages holding a position", 60)), ("440", t5("Pages holding a position", 75))])
R("3, para 2", "a fixed set of 434 URLs", "none (arithmetic: 381 code pages + 53 hubs)", "C", [("434", 381 + 53)])
R("3, para 3", "it exceeds 381 plus the 53 hub pages by seven", "none (arithmetic on Table 5)", "C", [("7", t5("Pages holding a position", 77) - 434)])
R("3, para 3", "Brand Radar's count of 455 distinct cited pages", "none (single-read file)", "D", [("455", SINGLE["distinct pages under the prefix cited in stored AI answers"])])
R("3, para 3", "exceeds 434 by 21", "none (arithmetic)", "C", [("21", 455 - 434)])

# ---- Section 4
R("4.1", "The section ranks in 105 countries with 18.5% of Ahrefs' estimated visits from outside the US (18.6% in the 12 October read of Table 4)",
  "none (single-read file; data/ahrefs file)", "D", [("105", SINGLE["countries in which the section ranks"]),
                                                    ("18.5%", SINGLE["share of Ahrefs-estimated visits from outside the US"]),
                                                    ("18.6%", 100 * (1 - float(AC["/local/area-codes/"]["ahrefs_us_share"])))])
R("4.1", "is nonetheless between 7.5 and 27.1 times larger", "none (arithmetic on Table 2)", "C", [("7.5", min(r_usww)), ("27.1", max(r_usww))])
R("4.1", "worldwide over worldwide (8.6x to 29.9x); and US over US (9.2x to 33.3x), estimated by applying Ahrefs' US share of its own visits, 81.5%",
  "none (arithmetic on Table 2; single-read file)", "C", [("8.6x", min(r_wwww)), ("29.9x", max(r_wwww)), ("9.2x", min(r_usus)), ("33.3x", max(r_usus)),
                                                         ("81.5%", SINGLE["Ahrefs' US share of its own visits used for the US-to-US ratios"])])
d0 = date(2026, 7, 26)
hdr = "| Metric | Day 0 (26 Jul) | Day 15 (10 Aug) | Day 30 (25 Aug) | **Day 37 (1 Sep)** | Day 45 (9 Sep) | Day 60 (24 Sep) | Day 75 (9 Oct) | Day 77 (11 Oct) |"
pairs = []
for d, (mm, dd) in zip(DAYS, [(7, 26), (8, 10), (8, 25), (9, 1), (9, 9), (9, 24), (10, 9), (10, 11)]):
    pairs.append((str(d), (date(2026, mm, dd) - d0).days))
R("Table 5 header; 4.3", hdr, "none (date arithmetic from day 0 = 26 July 2026)", "C", pairs)
R("4.3", "began on 24 September, day 60", "none (date arithmetic)", "C", [("60", (date(2026, 9, 24) - d0).days)])
R("4.3", "on 29 September, day 65", "none (date arithmetic)", "C", [("65", (date(2026, 9, 29) - d0).days)])

# ---- Section 5.1, Table 2
for k, lab in (("July 2026 (total)", "Jul"), ("August 2026 (total)", "Aug"), ("September 2026 (total)", "Sep"), ("October 2026 (run-rate)", "Oct")):
    v = t2[k]
    row = "| " + " | ".join(v["row"]) + " |"
    R(f"5.1, Table 2 ({lab})", row, "none (arithmetic on the row's own values)", "C",
      [(v["row"][4], v["usww"]), (v["row"][5], v["wwww"]), (v["row"][6], v["usus"])])
days_live = [int(T2[k][1].split()[0]) for k in ("July 2026 (total)", "August 2026 (total)", "September 2026 (total)", "October 2026 (run-rate)")]
R("5.1, Table 2 (days live)", "| 11 (77 cumulative) |", "none (arithmetic on the days-live column)", "C",
  [("77", sum(days_live))], f"the column's entries {days_live} sum to {sum(days_live)} (26 July counted as a day live); 77 is the days elapsed from 26 July to 11 October")
growth = [g(IE, r"July -> August: Ahrefs worldwide ([\d.]+)x; Semrush US ([\d.]+)x"), g(IE, r"August -> September: Ahrefs worldwide ([\d.]+)x; Semrush US ([\d.]+)x"),
          g(IE, r"September -> October \(run-rate\): Ahrefs worldwide ([\d.]+)x; Semrush US ([\d.]+)x")]
gratio = re.findall(r"Ahrefs growth / Semrush US growth ([\d.]+)", IE)
my_growth = [(t2[b]["ah"] / t2[a]["ah"], t2[b]["us"] / t2[a]["us"]) for a, b in zip(list(t2)[:-1], list(t2)[1:])]
R("5.1, para 3", "From July to August they did (8.4x on Ahrefs, 8.8x on Semrush US); from August to September Ahrefs' estimate grew 4.65x and Semrush's 1.75x, and into October's run-rate 1.44x against 1.05x",
  "instrument_extra.py", "S", [("8.4x", growth[0][0]), ("8.8x", growth[0][1]), ("4.65x", growth[1][0]), ("1.75x", growth[1][1]), ("1.44x", growth[2][0]), ("1.05x", growth[2][1])],
  "my recomputation from Table 2: " + ", ".join(f"{a:.2f}x/{b:.2f}x" for a, b in my_growth))
R("5.1, para 3", "by a factor of more than two", "instrument_extra.py", "S", [("=more than two", "=more than two" if max(map(float, gratio)) > 2 else "=no")], f"largest ratio of growth {max(map(float, gratio))}")
R("5.1, para 4", "the section draws 18.5% of its Ahrefs-estimated visits from outside the US", "none (single-read file)", "D", [("18.5%", SINGLE["share of Ahrefs-estimated visits from outside the US"])])
R("5.1, para 4", "worldwide against worldwide it runs from 8.6x to 29.9x, and US against US, estimated, from 9.2x to 33.3x", "none (arithmetic on Table 2)", "C",
  [("8.6x", min(r_wwww)), ("29.9x", max(r_wwww)), ("9.2x", min(r_usus)), ("33.3x", max(r_usus))])
R("5.1, para 5", "from 27.1x to 10.2x to 7.5x", "none (arithmetic on Table 2)", "C", [("27.1x", r_usww[1]), ("10.2x", r_usww[2]), ("7.5x", r_usww[3])])

# ---- 5.2 to 5.4
R("5.2", "Ahrefs reports 29,000 for all locations and Semrush 58,586 for the US database, read a day apart: a factor of 2.0", "none (arithmetic)", "C", [("2.0", 58586 / 29000)])
R("5.2", "3.2 times Ahrefs' 28,900 for all locations on the same day (Table 4)", "none (arithmetic; data/ahrefs file)", "C",
  [("3.2", 92300 / 28900), ("28,900", AC["/local/area-codes/"]["ahrefs_organic_keywords"])])
R("5.2", "Pages holding at least one position are 441 in Ahrefs", "none (Table 5)", "C", [("441", t5("Pages holding a position", 77))])
R("5.3", "Brand Radar's 17,206 stored answers citing the section and Semrush's 158,100 mentions read on 10 October differ by a factor of 9.2", "none (arithmetic; single-read file; Table 5)", "C",
  [("17,206", t5("AI answers citing the section", 77)), ("158,100", SINGLE["mentions in the AI-visibility panel"]), ("9.2", 158100 / 17206)])
R("5.3", "Semrush's companion count of 29,600 cited pages is 68 times the 434 URLs", "none (arithmetic; single-read file)", "C",
  [("29,600", SINGLE["cited pages in the AI-visibility panel"]), ("68", 29600 / 434)])
for r in T3:
    k, nn = map(n, re.match(r"([\d,]+) of ([\d,]+)", r[1]).groups())
    lo, hi = wilson(k, nn)
    pct, wl, wh = re.match(r"([\d.]+)% \[([\d.]+), ([\d.]+)\]", r[2]).groups()
    R(f"5.3, Table 3 ({r[0]})", "| " + " | ".join(r) + " |", "none (arithmetic on the row: Wilson interval, ratio)", "C",
      [(pct, 100 * k / nn), (wl, 100 * lo), (wh, 100 * hi), (r[4], n(r[3]) / k)])
R("5.3", "The ratio between the two counts falls from 2.94 to 1.34 over four months", "none (arithmetic on Table 3)", "C", [("2.94", 138 / 47), ("1.34", 10018 / 7455)])
fig3 = re.search(r'\("Ahrefs\\n913 domains", \[\("\.info", ([\d.]+).*?\("\.asia", ([\d.]+).*?\("\.xyz", ([\d.]+).*?\("Semrush\\n80 domains", \[\("\.xyz", ([\d.]+)', FIGS, re.S).groups()
R("5.4", "Ahrefs reports 913 referring domains to the prefix; Semrush Backlink Analytics indexes 80 for the subfolder: a factor of 11.4", "none (arithmetic)", "C", [("11.4", 913 / 80)])
R("5.4", "Ahrefs puts 61.9% on .info, 26.4% on .asia and 10.2% on .xyz; Semrush puts 75% on .xyz", "make_figs_v4.py (Figure 4 literals)", "F",
  [("61.9%", fig3[0]), ("26.4%", fig3[1]), ("10.2%", fig3[2]), ("75%", fig3[3])], "dashboard reads; no data file; agrees with the figure script")
R("5.4", "its daily series gives 909 at day 75 against 913 on 11 October, and its new-and-lost report for September gives 917 new against 95 lost, which with nineteen at day 37 implies about 841",
  "none (arithmetic; Table 5)", "C", [("909", t5("Live referring domains", 75)), ("913", t5("Live referring domains", 77)), ("841", 19 + 917 - 95)])

# ---- 5.5, Table 4 against the data files and instrument_extra.py
hdr4, T4, _ = md_table("*Table 4.")
ie_rows = {m.group(1): m.groups() for m in re.finditer(
    r"^\s+(/\S+/)\s+(\d+)\s+([\d.]+)%\s+([\d.]+)x\s+([\d.]+)x\s+([\d.]+)x\s+([\d.]+)x$", IE, re.M)}
for r in T4:
    pfx = r[0]
    a, s = AC[pfx], SC[pfx]
    y, mo = map(int, a["ahrefs_first_traffic_month"].split("-"))
    ie = ie_rows[pfx]
    cells = [c.replace("*", "") for c in r[1:]]
    pairs = [(cells[0], (2026 - y) * 12 + (10 - mo)), (cells[1], a["ahrefs_organic_traffic"]), (cells[2], s["semrush_organic_traffic_us"]),
             (cells[3], ie[3]), (cells[4], ie[2]), (cells[5], ie[4]), (cells[6], a["ahrefs_organic_keywords"]), (cells[7], s["semrush_organic_keywords_us"]),
             (cells[8], ie[5]), (cells[9], a["ahrefs_ref_domains"]), (cells[10], s["semrush_ref_domains"]), (cells[11], ie[6])]
    R(f"5.5, Table 4 ({pfx})", "| " + " | ".join(r) + " |", "instrument_extra.py (ratios, US share, age); data/ files (raw columns)", "S+D", pairs,
      "12 cells: age, both visits, unmatched ratio, US share, matched ratio, both keyword counts, keyword ratio, both RD counts, RD ratio")
ages = sorted(((pr["age"], pr["p"]) for pr in pre), reverse=True)
R("5.5, Table 4 caption", "the oldest age (/es-us/local/) is left-censored at that horizon and the next two lie within four months of it", "none (data/ahrefs file)", "C",
  [("=/es-us/local/", "=" + ages[0][1]), ("=yes", "=yes" if ages[0][0] - ages[2][0] <= 4 else "=no")], f"ages {ages[0]}, {ages[1]}, {ages[2]}")
R("5.5, para 3", f"Spearman's rank correlation between age and the unmatched visits ratio is {M}0.11 over twelve prefixes, with a Fisher 95% interval of {M}0.64 to +0.49 and a permutation p of 0.73; territory-matched it is {M}0.28; excluding the area-code section it is +0.15",
  "analyze.py", "S", [(f"{M}0.11", g(A, r"rho\(age, visits ratio\) = ([+-][\d.]+)")), (f"{M}0.64", g(A, r"CI \[([+-][\d.]+),")), ("+0.49", g(A, r"CI \[[+-][\d.]+, ([+-][\d.]+)\]")),
                      ("0.73", g(A, r"permutation p = ([\d.]+)")), (f"{M}0.28", g(A, r"rho\(age, ratio\) = ([+-][\d.]+)")), ("+0.15", g(A, r"area-code section: rho = ([+-][\d.]+)"))], my_note)
R("5.5, para 3", "Twelve prefixes give about 38% power to detect a correlation of 0.5 (37.8% by the Fisher approximation)", "instrument_extra.py (analyze.py prints a fixed 38%)", "S",
  [("38%", g(IE, r"Fisher approximation\): ([\d.]+)%")), ("37.8%", g(IE, r"Fisher approximation\): ([\d.]+)%"))],
  f"my computation: {100 * my['power']:.1f}%; analyze.py's '38%' is a fixed string, not computed")
R("5.5, para 3", "the seven sections aged between seven and eleven years sit anywhere from 0.25x to 6.57x unmatched (0.46x to 6.61x matched)", "instrument_extra.py", "S",
  [("7", g(IE, r"seven to eleven years: (\d+)")), ("0.25x", g(IE, r"unmatched ratio ([\d.]+)x to")), ("6.57x", g(IE, r"unmatched ratio [\d.]+x to ([\d.]+)x")),
   ("0.46x", g(IE, r"matched ([\d.]+)x to [\d.]+x$")), ("6.61x", g(IE, r"; matched [\d.]+x to ([\d.]+)x$"))])
R("5.5, para 3", "the narrowing of the area-code ratio from 27.1x to 7.5x over three months", "none (arithmetic on Table 2)", "C", [("27.1x", r_usww[1]), ("7.5x", r_usww[3])])
R("5.5, para 3", "Only one prefix in the cross-section is under twenty-one months old", "instrument_extra.py", "S", [("1", g(IE, r"under twenty-one months old: (\d+)"))])
R("5.5, para 4", "Semrush's estimate runs from one fifth of Ahrefs' (/local/bundles/, 0.20x) to seven times it (/local/area-codes/, 7.24x), a spread of 1.55 orders of magnitude, with a median of 1.01 and six of twelve prefixes below one",
  "analyze.py", "S", [("0.20x", g(A, r"min ([\d.]+)x \(/local/bundles/\)")), ("7.24x", g(A, r"max ([\d.]+)x \(/local/area-codes/\)")), ("1.55", g(A, r"spread ([\d.]+) decades")),
                      ("1.01", g(A, r"median ([\d.]+), spread")), ("6", g(A, r"below one: (\d+) of 12"))], f"my recomputation: median {my['median']:.3f}, below one {my['below']}")
R("5.5, para 4", "Matched for territory the spread is wider (0.20x to 8.89x), the median is 1.06, and four of twelve are below one", "analyze.py", "S",
  [("0.20x", g(A, r"TERRITORY-MATCHED .*?min ([\d.]+)x")), ("8.89x", g(A, r"TERRITORY-MATCHED .*?max ([\d.]+)x")), ("1.06", g(A, r"TERRITORY-MATCHED .*?median ([\d.]+)")),
   ("4", g(A, r"below one (\d+) of 12"))], f"my recomputation: median {my['median_us']:.3f}, below one {my['below_us']}")
R("5.5, para 4", "(/product-compare/, 69.6% US, from 0.75x to 1.07x; /device-compare/, 82.6% US, from 0.99x to 1.20x); /es-us/local/, at 42.6% US, moves from 0.25x to 0.58x",
  "instrument_extra.py", "S", [("69.6%", ie_rows["/product-compare/"][2]), ("0.75x", ie_rows["/product-compare/"][3]), ("1.07x", ie_rows["/product-compare/"][4]),
                               ("82.6%", ie_rows["/device-compare/"][2]), ("0.99x", ie_rows["/device-compare/"][3]), ("1.20x", ie_rows["/device-compare/"][4]),
                               ("42.6%", ie_rows["/es-us/local/"][2]), ("0.25x", ie_rows["/es-us/local/"][3]), ("0.58x", ie_rows["/es-us/local/"][4])])
R("5.5, para 4", "the unmatched ratio has a geometric mean of 1.13 (bootstrap 95% interval 0.62 to 2.12) and a geometric standard deviation of 3.1 (1.9 to 4.1), a normal range on the log scale of about 0.12x to 10.6x",
  "instrument_extra.py", "S", [("1.13", g(IE, r"geometric mean ([\d.]+)x, geometric SD")), ("0.62", g(IE, r"geometric mean of the ratio [\d.]+x \[([\d.]+)x")),
                               ("2.12", g(IE, r"geometric mean of the ratio [\d.]+x \[[\d.]+x, ([\d.]+)x\]")), ("3.1", g(IE, r"geometric SD ([\d.]+);")),
                               ("1.9", g(IE, r"geometric SD [\d.]+ \[([\d.]+),")), ("4.1", g(IE, r"geometric SD [\d.]+ \[[\d.]+, ([\d.]+)\]")),
                               ("0.12x", g(IE, r"not a prediction\) ([\d.]+)x to")), ("10.6x", g(IE, r"not a prediction\) [\d.]+x to ([\d.]+)x"))])
R("5.5, para 5", "is +0.94 (bootstrap 95% interval over prefixes +0.70 to +1.00; p < 0.001; Kendall's tau +0.82, interval +0.57 to +1.00; 60 of 66 pairs concordant)",
  "analyze.py; instrument_extra.py", "S", [("+0.94", g(A, r"ORDERING sections by visits: Spearman ([+-][\d.]+)")), ("+0.70", g(IE, r"Spearman \(ordering\) [+-][\d.]+ \[([+-][\d.]+),")),
                                          ("+1.00", g(IE, r"Spearman \(ordering\) [+-][\d.]+ \[[+-][\d.]+, ([+-][\d.]+)\]")),
                                          ("=p < 0.001", "=p < 0.001" if float(g(IE, r"Spearman \+[\d.]+ \(p=([\d.e+-]+)\)")) < 0.001 else "=no"),
                                          ("+0.82", g(A, r"Kendall tau ([+-][\d.]+)")), ("+0.57", g(IE, r"Kendall [+-][\d.]+ \[([+-][\d.]+),")),
                                          ("+1.00", g(IE, r"Kendall [+-][\d.]+ \[[+-][\d.]+, ([+-][\d.]+)\]")), ("60", g(A, r"(\d+) of \d+ pairs concordant")), ("66", g(A, r"\d+ of (\d+) pairs concordant"))],
  f"my scipy recomputation: Spearman {my['rho_v']:+.3f}, Kendall {my['tau_v']:+.3f}, concordant {my['conc']} of 66")
b3 = int(g(IE, r"differ 3x to 10x: (\d+) of")) + int(g(IE, r"differ over 10x: (\d+) of"))
R("5.5, para 5", "all 51 are ordered alike; of the 15 pairs within a factor of three, 9 are", "instrument_extra.py", "S",
  [("51", b3), ("15", g(IE, r"within 3x: \d+ of (\d+)")), ("9", g(IE, r"within 3x: (\d+) of"))])
R("5.5, para 6", "Semrush reports more ranking keywords than Ahrefs on every prefix, by between 2.0x and 20.9x", "analyze.py", "S",
  [("2.0x", g(A, r"keyword ratio Semrush/Ahrefs: min ([\d.]+)x")), ("20.9x", g(A, r"keyword ratio Semrush/Ahrefs: min [\d.]+x, max ([\d.]+)x"))])
R("5.5, para 6", "The rank correlation between the keyword ratio and the visits ratio is +0.17 over all twelve, and +0.52 with the area-code section excluded", "analyze.py", "S",
  [("+0.17", g(A, r"rho\(keyword ratio, visits ratio\) = ([+-][\d.]+)")), ("+0.52", g(A, r"excluding area-codes ([+-][\d.]+)"))], f"my recomputation: {my['rho_kv']:+.3f}, {my['rho_kv_x']:+.3f}")
R("5.5, para 6", "/local/bundles/ has the second-largest keyword ratio (16.1x) and the smallest visits ratio (0.20x)", "instrument_extra.py; analyze.py", "S",
  [("=/local/bundles/", "=" + g(IE, r"keyword ratio, largest two: \S+ [\d.]+x, (\S+) [\d.]+x")), ("16.1x", g(IE, r"keyword ratio, largest two: \S+ [\d.]+x, \S+ ([\d.]+)x")),
   ("0.20x", g(A, r"min ([\d.]+)x \(/local/bundles/\)"))])
R("5.5, para 7", "It has the highest visits ratio (7.24x unmatched, 8.89x matched; /stores/ is next at 6.57x) and the highest referring-domain ratio (11.3x) of the twelve",
  "analyze.py; instrument_extra.py", "S", [("7.24x", g(A, r"max ([\d.]+)x \(/local/area-codes/\)")), ("8.89x", g(A, r"TERRITORY-MATCHED .*?max ([\d.]+)x")),
                                          ("=/stores/", "=" + g(A, r"second [\d.]+x \((\S+)\)")), ("6.57x", g(A, r"second ([\d.]+)x")),
                                          ("11.3x", g(IE, r"referring-domain ratio \(Ahrefs over Semrush\), largest two: /local/area-codes/ ([\d.]+)x"))])
R("5.5, para 8", "reported 158.3K mentions and 29.5K cited pages for every one of the twelve subfolders, identically, on 12 October (Section 5.3 quotes the 10 October read of 158,100 and 29,600)",
  "none (single-read file)", "D", [("158.3", SINGLE["mentions in the AI-visibility panel (identical for all twelve subfolders)"].rstrip("K")),
                                   ("29.5", SINGLE["cited pages in the AI-visibility panel (identical for all twelve subfolders)"].rstrip("K")),
                                   ("158,100", SINGLE["mentions in the AI-visibility panel"]), ("29,600", SINGLE["cited pages in the AI-visibility panel"])])

# ---- 5.6
R("5.6, para 2", "the two readings cannot both lie within a factor of 5.2, the square root of 27.1", "none (arithmetic)", "C", [("5.2", math.sqrt(27.1)), ("27.1", r_usww[1])])
R("5.6, para 2", "the larger of the two errors is at least 13 times the smaller reading", "none (arithmetic: (27.1 - 1) / 2)", "C", [("13", (r_usww[1] - 1) / 2)])
R("5.6, para 3", "The ratio falls 27.1 → 10.2 → 7.5 over three months", "none (arithmetic on Table 2)", "C", [("27.1", r_usww[1]), ("10.2", r_usww[2]), ("7.5", r_usww[3])])
dec_us = g(IE, r"visits ([\d.]+)x = keywords ([\d.]+)x x per-keyword ([\d.]+)x; keyword share of log ratio (\d+)%")
dec_ww = re.findall(r"visits ([\d.]+)x = keywords ([\d.]+)x x per-keyword ([\d.]+)x; keyword share of log ratio (\d+)%", IE)[1]
R("5.6, para 4", "7.47x = 2.02x (keyword universe) × 3.70x (estimated visits per ranking keyword)", "instrument_extra.py", "S",
  [("7.47x", dec_us[0]), ("2.02x", dec_us[1]), ("3.70x", dec_us[2])],
  f"my recomputation: {1610284 / 215577:.2f} = {58586 / 29000:.2f} x {(1610284 / 215577) / (58586 / 29000):.2f}; log share {math.log(58586 / 29000) / math.log(1610284 / 215577):.0%}")
R("5.6, para 4", "so the keyword universe accounts for about 35% of the divergence in log terms", "instrument_extra.py", "S", [("35%", dec_us[3])])
R("5.6, para 4", "it is 8.62x = 3.19x (keyword universe) × 2.70x (per keyword), and the keyword universe accounts for about 54%", "instrument_extra.py", "S",
  [("8.62x", dec_ww[0]), ("3.19x", dec_ww[1]), ("2.70x", dec_ww[2]), ("54%", dec_ww[3])],
  f"my recomputation: {1858297 / 215577:.2f} = {92300 / 28900:.2f} x {(1858297 / 215577) / (92300 / 28900):.2f}; log share {math.log(92300 / 28900) / math.log(1858297 / 215577):.0%}")
R("5.6, para 5", "Matching worldwide to worldwide gives 8.62x for October and 26.7x to 29.9x in the first two months", "none (arithmetic on Table 2)", "C",
  [("8.62x", r_wwww[3]), ("26.7x", r_wwww[0]), ("29.9x", r_wwww[1])])
R("5.6, para 5", "gives **9.17x** for October against the 7.5x unmatched", "none (arithmetic on Table 2)", "C", [("9.17x", r_usus[3]), ("7.5x", r_usww[3])])
R("5.6, para 5", "Applying the same share to July, August and September gives 31.8x, 33.3x and 12.5x", "none (arithmetic on Table 2)", "C",
  [("31.8x", r_usus[0]), ("33.3x", r_usus[1]), ("12.5x", r_usus[2])])
R("5.6, para 6", "the vendor ratio on estimated visits spans 0.20x to 7.24x (0.20x to 8.89x territory-matched)", "analyze.py", "S",
  [("0.20x", g(A, r"min ([\d.]+)x")), ("7.24x", g(A, r"max ([\d.]+)x")), ("0.20x", g(A, r"TERRITORY-MATCHED .*?min ([\d.]+)x")), ("8.89x", g(A, r"TERRITORY-MATCHED .*?max ([\d.]+)x"))])
R("5.6, para 6", "The vendors agree on which of two sections is larger in 60 of 66 pairs", "analyze.py", "S",
  [("60", g(A, r"(\d+) of \d+ pairs concordant")), ("66", g(A, r"\d+ of (\d+) pairs concordant"))])
rev = re.findall(r"ordered oppositely: .*?Ahrefs [\d,]+ vs [\d,]+ \(([\d.]+)x\); Semrush [\d,]+ vs [\d,]+ \(([\d.]+)x\); three or more times apart on one instrument", IE)
R("5.6, para 6", "within a factor of three (9 of 15 pairs); measured on one instrument alone, two pairs six to seven times apart were ordered the other way on the second",
  "instrument_extra.py", "S", [("9", g(IE, r"within 3x: (\d+) of")), ("15", g(IE, r"within 3x: \d+ of (\d+)")), ("2", len(rev)),
                               ("=six to seven", "=six to seven" if all(6 <= max(map(float, x)) < 8 for x in rev) else f"={rev}")],
  "reversed pairs three or more times apart on one instrument: " + "; ".join(f"{max(map(float, x))}x" for x in rev))
R("5.6, para 6", "can differ by a factor of five below to nearly nine above", "analyze.py", "S",
  [("5", 1 / float(g(A, r"min ([\d.]+)x"))), ("=nearly nine", "=nearly nine" if 8.5 <= float(g(A, r"TERRITORY-MATCHED .*?max ([\d.]+)x")) < 9 else "=no")], "1 / 0.20 and 8.89")
R("5.6, para 6", "Growth measured on the two instruments also differed, by a factor of 2.7 in one month", "instrument_extra.py", "S", [("2.7", max(map(float, gratio)))])

# ---- Section 6 (the review data are licensed and withheld; the scripts cannot run)
R("6, para 1", "It holds 47,485 Google reviews of 379 retail locations", "supplement_r10.py", "X",
  [("47,485", g(SR, r"review rows (\d+)")), ("379", g(SR, r"locations in the export (\d+)"))])
R("6, para 1", "of which 37,193 carry text, at 378 of the locations", "supplement_r10.py", "X",
  [("37,193", g(SR, r"with text (\d+);")), ("378", g(SR, r"with at least one text review (\d+)"))])
R("6, para 1", "The export holds between 1 and 201 reviews per location (median 145)", "supplement_r10.py", "X",
  [("1", g(SR, r"reviews per location min (\d+)")), ("201", g(SR, r"max (\d+);")), ("145", g(SR, r"median (\d+), max"))])
R("6, para 1", "at 26 locations, they name five different carriers", "supplement_r10.py", "X",
  [("26", g(SR, r"name a carrier (\d+)")), ("5", g(SR, r"naming (\d+) different carriers"))], "also needs the private 03_DATA/private/carrier_name_patterns.txt")
R("6, para 1", "a 42,994-node telecom taxonomy built by the author's clustering engine from 1,898,584 keywords", "supplement_r10.py", "X",
  [("42,994", g(SR, r"taxonomy nodes (\d+);")), ("1,898,584", g(SR, r"built from (\d+)"))], "also needs the private Telecom_keywords_full.csv.gz")
R("6, para 1", "Of the 37,193 reviews, 20,663 (55.6%) linked to at least one of 27,817 linkable labels, at 2.25 labels per linked review, and 1,008 labels were mentioned at least once",
  "analyze_reviews.py", "X", [("37,193", g(AR, r"reviews with text: (\d+)")), ("20,663", g(AR, r"at least one label: (\d+)")), ("55.6%", g(AR, r"at least one label: \d+ \(([\d.]+)%")),
                              ("27,817", g(AR, r"linkable labels: (\d+)")), ("2.25", g(AR, r"per linked review ([\d.]+)")), ("1,008", g(AR, r"at least one review: (\d+)"))])
R("6, para 2", "At the level of the taxonomy's 17 top-level branches", "supplement_r10.py", "X", [("17", g(SR, r"over (\d+) branches"))])
R("6, para 2", "+0.75 (bootstrap 95% interval over branches +0.44 to +0.90; p < 0.001, 17 branches; Figure 6b), and +0.47 (+0.01 to +0.78; p = 0.06)", "supplement_r10.py", "X",
  [("+0.75", g(SR, r"split attribution: ([+-][\d.]+)")), ("+0.44", g(SR, r"split attribution: [+-][\d.]+ \[95% ([+-][\d.]+),")), ("+0.90", g(SR, r"split attribution: [+-][\d.]+ \[95% [+-][\d.]+, ([+-][\d.]+)\]")),
   ("=p < 0.001", "=p < 0.001" if float(g(SR, r"split mentions: rho=[+-][\d.]+ p=([\d.e-]+)")) < 0.001 else "=no"),
   ("+0.47", g(SR, r"modal attribution: ([+-][\d.]+)")), ("+0.01", g(SR, r"modal attribution: [+-][\d.]+ \[95% ([+-][\d.]+),")), ("+0.78", g(SR, r"modal attribution: [+-][\d.]+ \[95% [+-][\d.]+, ([+-][\d.]+)\]")),
   ("0.06", g(SR, r"modal attribution: rho=[+-][\d.]+ p=([\d.]+)"))])
R("6, para 2", "An earlier computation gave +0.78", "analyze_reviews.py", "X", [("+0.78", g(AR, r"branch-level Spearman: rho=([+-][\d.]+)"))])
R("6, para 2", "carriers draw 66.8% of review mentions and 14.9% of search volume, devices 11.0% and 32.7%, broadband 4.0% and 18.1%", "supplement_r10.py", "X",
  [("66.8%", g(SR, r"Mobile & Wireless Carriers\s+([\d.]+)%\s+[\d.]+%$")), ("14.9%", g(SR, r"Mobile & Wireless Carriers\s+[\d.]+%\s+([\d.]+)%$")),
   ("11.0%", g(SR, r"Devices & Hardware\s+([\d.]+)%\s+[\d.]+%$")), ("32.7%", g(SR, r"Devices & Hardware\s+[\d.]+%\s+([\d.]+)%$")),
   ("4.0%", g(SR, r"Internet & Broadband \(ISP\)\s+([\d.]+)%\s+[\d.]+%$")), ("18.1%", g(SR, r"Internet & Broadband \(ISP\)\s+[\d.]+%\s+([\d.]+)%$"))])
R("6, para 2", "the rank correlation between review mentions and monthly volume is +0.19 (bootstrap 95% interval +0.12 to +0.25; Kendall's tau +0.13)", "analyze_reviews.py; supplement_r10.py", "X",
  [("+0.19", g(AR, r"rho=([+-][\d.]+) p=3.4e-09")), ("+0.12", g(SR, r"mentioned labels: [+-][\d.]+ \[95% ([+-][\d.]+),")),
   ("+0.25", g(SR, r"mentioned labels: [+-][\d.]+ \[95% [+-][\d.]+, ([+-][\d.]+)\]")), ("+0.13", g(AR, r"Kendall tau=([+-][\d.]+)"))])
R("6, para 2", "counting the 26,809 linkable labels that no review mentions as zero, it is +0.27 (+0.26 to +0.29); both p < 0.001", "supplement_r10.py", "X",
  [("26,809", int(g(SR, r"linkable labels: (\d+); mentioned")) - int(g(SR, r"; mentioned: (\d+)"))), ("+0.27", g(SR, r"all linkable labels: ([+-][\d.]+) \[")),
   ("+0.26", g(SR, r"all linkable labels: [+-][\d.]+ \[95% ([+-][\d.]+),")), ("+0.29", g(SR, r"all linkable labels: [+-][\d.]+ \[95% [+-][\d.]+, ([+-][\d.]+)\]"))],
  "the printed upper bound is +0.285, so +0.29 relies on rounding a value printed to three decimals")
R("6, para 2", "It is +0.28 (p < 0.001) among the 213 labels with at least twenty mentions, and +0.16 (p = 0.10) among the 106 labels mentioned at least twenty times in one- and two-star reviews",
  "analyze_reviews.py", "X", [("+0.28", g(AR, r">=20 mentions \(\d+\): rho=([+-][\d.]+)")), ("213", g(AR, r">=20 mentions \((\d+)\)")),
                              ("+0.16", g(AR, r"complaint labels .*?rho\(neg mentions, volume\)=([+-][\d.]+)")), ("0.10", g(AR, r"complaint labels .*? p=([\d.]+)$")),
                              ("106", g(AR, r"1-2 star reviews, (\d+)\)"))])
R("6, para 2", "Of the 1,008 labels, 367 (36.4%) carry under 1,000 monthly searches and 106 (10.5%) carry none", "analyze_reviews.py", "X",
  [("367", g(AR, r"<1,000 monthly volume: (\d+)")), ("36.4%", g(AR, r"<1,000 monthly volume: \d+ \(([\d.]+)%")), ("106", g(AR, r"ZERO monthly volume: (\d+)")),
   ("10.5%", g(AR, r"ZERO monthly volume: \d+ \(([\d.]+)%"))])
R("6, para 2", "the two label-level correlations are +0.16 and +0.26", "supplement_r10.py", "X",
  [("+0.16", g(SR, r"own \(non-nested\) volumes: mentioned labels ([+-][\d.]+)")), ("+0.26", g(SR, r"own \(non-nested\) volumes: .*all linkable labels ([+-][\d.]+)"))])
pa = re.findall(r"annotator \d: \{[^}]*\}; precision (\d+)/(\d+) = ([\d.]+)% \[Wilson 95% ([\d.]+)%, ([\d.]+)%\] excluding unclear; \d+/\d+ = ([\d.]+)% \[([\d.]+)%, ([\d.]+)%\]", LC)
A_prec = [float(x[2]) for x in pa[:2]] + [float(x[5]) for x in pa[:2]]
A_lo = [float(x[3]) for x in pa[:2]] + [float(x[6]) for x in pa[:2]]
A_hi = [float(x[4]) for x in pa[:2]] + [float(x[7]) for x in pa[:2]]
R("6, para 3", "judged 200 links drawn uniformly from the 46,517: 65% to 67% are correct (Wilson 95% intervals about 58% to 73%), and the two agree on 95.5% of the items (Cohen's kappa 0.90)",
  "r2_link_check.py (46,517: r2_link_sample.py)", "S", [("200", g(LC, r"\((\d+) sampled uniformly")), ("46,517", g(LS, r"links: (\d+)")),
                                                         ("65%", min(A_prec)), ("67%", max(A_prec)), ("58%", min(A_lo)), ("73%", max(A_hi)),
                                                         ("95.5%", g(LC, r"agreement: ([\d.]+)% of 200 items")), ("0.90", g(LC, r"of 200 items; Cohen's kappa ([\d.]+)"))],
  "46,517 is a fixed string in r2_link_check.py; it is computed only by r2_link_sample.py, which cannot run (its shipped output prints 46517); " + lc_note)
sw = [float(x) for x in re.findall(r"single-word labels: \d+/\d+ = ([\d.]+)%", LC)]
mw = [float(x) for x in re.findall(r"multi-word labels: \d+/\d+ = ([\d.]+)%", LC)]
R("6, para 3", "which are right about half the time", "r2_link_check.py", "S", [("=about half", "=about half" if all(45 <= x <= 55 for x in sw) else f"={sw}")], f"single-word labels {sw}")
R("6, para 3", "while multi-word labels are 95% to 96% right", "r2_link_check.py", "S", [("95%", min(mw)), ("96%", max(mw))], f"multi-word labels {mw}; 94.5% rounds half-up to 95%")
R("6, para 3", "the branch-level correlation is +0.91 (bootstrap 95% interval +0.74 to +0.98) with split attribution and +0.65 with modal attribution, the label-level correlation over mentioned labels is +0.24 (+0.16 to +0.33), and carriers still draw 56% of review mentions against 15% of search volume",
  "supplement_r10.py", "X", [("+0.91", g(SR, r"own volumes: split ([+-][\d.]+)")), ("+0.74", g(SR, r"own volumes: split [+-][\d.]+ \[95% ([+-][\d.]+),")),
                             ("+0.98", g(SR, r"own volumes: split [+-][\d.]+ \[95% [+-][\d.]+, ([+-][\d.]+)\]")), ("+0.65", g(SR, r"modal ([+-][\d.]+) \(p=0.0048\)")),
                             ("+0.24", g(SR, r"label-level Spearman: mentioned labels ([+-][\d.]+) \[")), ("+0.16", g(SR, r"label-level Spearman: mentioned labels [+-][\d.]+ \[95% ([+-][\d.]+),")),
                             ("+0.33", g(SR, r"label-level Spearman: mentioned labels [+-][\d.]+ \[95% [+-][\d.]+, ([+-][\d.]+)\]")),
                             ("56%", g(SR, r"Mobile & Wireless Carriers ([\d.]+)% of mentions")), ("15%", g(SR, r"Mobile & Wireless Carriers [\d.]+% of mentions, ([\d.]+)% of volume"))],
  "the printed lower bound is +0.735, so +0.74 relies on rounding a value printed to three decimals")
wl1, wh1 = wilson(924, 6620)
wl5, wh5 = wilson(564, 29225)
R("6, para 4", "Of 6,620 one- and two-star reviews, 924 (14.0%, Wilson 95% interval 13.1% to 14.8%) match a pattern for waiting", "analyze_reviews.py; supplement_r10.py", "X",
  [("6,620", g(AR, r"1-2 star reviews: (\d+)")), ("924", g(AR, r"mentioning waiting: (\d+)")), ("14.0%", g(AR, r"mentioning waiting: \d+ \(([\d.]+)%")),
   ("13.1%", g(SR, r"one- and two-star 924/6620 = [\d.]+% \[Wilson 95% ([\d.]+)%")), ("14.8%", g(SR, r"one- and two-star 924/6620 = [\d.]+% \[Wilson 95% [\d.]+%, ([\d.]+)%\]"))],
  f"my Wilson interval from the printed counts: {wl1:.1%} to {wh1:.1%}")
R("6, para 4", "against 1.9% (1.8% to 2.1%) of five-star reviews", "analyze_reviews.py; supplement_r10.py", "X",
  [("1.9%", g(AR, r"in 5-star reviews: ([\d.]+)%")), ("1.8%", g(SR, r"five-star 564/29225 = [\d.]+% \[([\d.]+)%")), ("2.1%", g(SR, r"five-star 564/29225 = [\d.]+% \[[\d.]+%, ([\d.]+)%\]"))],
  f"my Wilson interval from the printed counts: {wl5:.1%} to {wh5:.1%}")
pb = re.findall(r"annotator \d: \{[^}]*\}; precision (\d+)/(\d+) = ([\d.]+)% \[Wilson 95% [\d.]+%, [\d.]+%\] excluding unclear; \d+/\d+ = ([\d.]+)%", LC.split("== B.")[1])
B_prec = [float(x[2]) for x in pb[:2]] + [float(x[3]) for x in pb[:2]]
instore = [float(x) for x in re.findall(r"in store \d+/\d+ = ([\d.]+)%", LC)]
implied = [float(x) for x in re.findall(r"= ([\d.]+)%$", LC, re.M)]
R("6, para 4", "The same annotators judged 100 of the 924 matches: 83% to 85% are complaints about waiting (Cohen's kappa 0.93), and about nine in ten of those concern waiting in the store, so roughly 12% of one- and two-star reviews complain about a wait",
  "r2_link_check.py", "S", [("100", g(LC, r"\((\d+) sampled uniformly from the 924")), ("924", g(LC, r"uniformly from the (\d+) one- and two-star")),
                            ("83%", min(B_prec)), ("85%", max(B_prec)), ("0.93", g(LC, r"of 100 items; Cohen's kappa ([\d.]+)")),
                            ("=about nine in ten", "=about nine in ten" if all(85 <= x <= 95 for x in instore) else f"={instore}"),
                            ("12%", statistics.mean(implied[-2:]))], f"in store {instore}; implied shares {implied[-2:]}; " + lc_note)
R("6, para 4", 'The whole taxonomy, built from 1.9 million keywords, holds 11 labels containing "wait", with 622 searches a month between them', "supplement_r10.py", "X",
  [("1.9", int(g(SR, r"built from (\d+)")) / 1e6), ("11", g(SR, r"distinct such labels: (\d+)")), ("622", g(SR, r"their monthly volume: (\d+)"))])
R("6, para 4", "the one that reviews mention carries 12", "analyze_reviews.py", "X",
  [("1", g(AR, r"taxonomy\): (\d+) \|")), ("12", g(AR, r"total monthly volume on them: (\d+)"))])
R("6, para 4", "Eight labels name a remedy, appointments, queues or callbacks, with 13,170 searches a month between them, most of it for appointment reminders; the label for scheduling a store appointment carries none, and no label concerns check-in",
  "supplement_r10.py", "X", [("8", g(SR, r"queues or callbacks: (\d+) labels")), ("13,170", g(SR, r"queues or callbacks: \d+ labels, (\d+) searches")),
                             ("=most", "=most" if int(g(SR, r"Appointment Reminders: (\d+)")) / int(g(SR, r"queues or callbacks: \d+ labels, (\d+) searches")) > 0.5 else "=no"),
                             ("0", g(SR, r"Scheduling a Store Appointment for Tech Help: (\d+)")), ("0", g(SR, r"naming check-in: (\d+)"))])
R("6, Figure 6 caption", "37,193 Google reviews of 378 retail locations of major US telecom carriers, linked to a 42,994-node taxonomy", "analyze_reviews.py; supplement_r10.py", "X",
  [("37,193", g(AR, r"reviews with text: (\d+)")), ("378", g(AR, r"businesses: (\d+)")), ("42,994", g(SR, r"taxonomy nodes: (\d+)"))],
  "the shipped figure (fig9_reviews.png) prints 1,008 labels, +0.19 and +0.75; its script needs out/*.csv, not shipped")
R("6, Figure 6 caption", "Each marker is one of the 1,008 taxonomy labels mentioned in at least one review", "analyze_reviews.py", "X", [("1,008", g(AR, r"at least one review: (\d+)"))])
R("6, Figure 6 caption", "the nine largest of the 17 top-level branches", "supplement_r10.py", "X", [("17", g(SR, r"over (\d+) branches"))])
R("6, para 5", "exact-match links of which about two in three are correct", "r2_link_check.py", "S",
  [("=about two in three", "=about two in three" if all(62 <= x <= 71 for x in prec) else f"={prec}")])

# ---- Section 7
R("7.1", "youtube.com was the most-cited non-brand domain on all four Google views and ranked 28th on ChatGPT, 4th on Perplexity, 5th on Gemini and 9th on Copilot, and reddit.com was in the top three on every surface except Copilot (240th)",
  "cross_sector_sensitivity.py, project copy (pilot section not released; pilot exports withheld)", "X",
  [("1", max(int(x) for x in re.findall(r"\((?:search queries|prompts)\)\s+YouTube non-brand rank (\d+)", PIL))),
   ("28", g(PIL, r"ChatGPT\s+YouTube non-brand rank (\d+)")), ("4", g(PIL, r"Perplexity\s+YouTube non-brand rank (\d+)")),
   ("5", g(PIL, r"Gemini\s+YouTube non-brand rank (\d+)")), ("9", g(PIL, r"Copilot\s+YouTube non-brand rank (\d+)")),
   ("3", max(int(x) for x in re.findall(r"Reddit (\d+);", PIL) if int(x) != 240)), ("240", g(PIL, r"Copilot\s+YouTube non-brand rank \d+; Reddit (\d+)"))],
  "pilot_section_output.txt is a copy of the project script's output, not produced by any bundle script")
R("7.2", "109 companies, because Communication Services counts one issuer, Alphabet, through two share classes", "make_brand_radar_urls.py; design/cross_sector_companies.csv", "S+D",
  [("109", sum(int(x) for x in re.findall(r"'\w+': (\d+)", BR))), ("109", len(COMPANIES))], "companies per sector printed by make_brand_radar_urls.py: Communication Services " + g(BR, r"'xlc': (\d+)"))
R("7.2", "which reduce to 760 to 975 registrable domains; the 88 exports are analyzed", "section7_from_aggregates.py", "S",
  [("760", g(S7, r"registrable domains per export (\d+) to")), ("975", g(S7, r"registrable domains per export \d+ to (\d+)")), ("88", g(S7, r"(\d+) cells;"))],
  f"my recomputation from cross_sector_cells.csv: {q7['regdom']}")
R("7.2", "Summed over sectors it holds 20,389,967 answer records, from 18,763 (Utilities) to 7,766,466 (Consumer Discretionary)", "section7_from_aggregates.py", "S",
  [("20,389,967", g(S7, r"summed over sectors ([\d,]+);")), ("18,763", g(S7, r"range ([\d,]+) \(xlu\)")), ("7,766,466", g(S7, r"to ([\d,]+) \(xly\)"))],
  f"my sum of sector_answer_counts.csv: {q7['answers']:,}")
R("7.2", "(exports until 01:05, answer counts from 01:10)", "none (aggregates/sector_answer_counts.csv read times)", "D",
  [("=01:10", "=" + q7["read_first"].split()[1])], "the export end time 01:05 is not in a released file")
R("7.3", "In every one of the eleven sectors, the lowest of the four Google views gave video and community domains a larger share of citation incidences than the highest of ChatGPT, Copilot, Perplexity and Gemini",
  "section7_from_aggregates.py", "S", [("11", g(S7, r"exceeds the highest other surface: (\d+)/11"))], f"my recount: {q7['dom']}")
R("7.3", "the median share was 21.3% on the Google views (range 8.1% to 35.8%; 95% bootstrap interval over sectors 17.2% to 26.7%) against 2.1% on the other four (range 0.3% to 16.7%; interval 1.7% to 2.7%), and by surface 0.6% on Copilot, 0.9% on ChatGPT, 4.6% on Perplexity and 9.2% on Gemini",
  "section7_from_aggregates.py", "S", [("21.3%", g(S7, r"Google views median ([\d.]+)%")), ("8.1%", g(S7, r"Google views median [\d.]+% \(range ([\d.]+)%")),
                                      ("35.8%", g(S7, r"Google views median [\d.]+% \(range [\d.]+% to ([\d.]+)%")), ("17.2%", g(S7, r"Google ([\d.]+)% to [\d.]+%; other four")),
                                      ("26.7%", g(S7, r"Google [\d.]+% to ([\d.]+)%; other four")), ("2.1%", g(S7, r"other four median ([\d.]+)%")),
                                      ("0.3%", g(S7, r"other four median [\d.]+% \(range ([\d.]+)%")), ("16.7%", g(S7, r"other four median [\d.]+% \(range [\d.]+% to ([\d.]+)%")),
                                      ("1.7%", g(S7, r"other four ([\d.]+)% to [\d.]+%$")), ("2.7%", g(S7, r"other four [\d.]+% to ([\d.]+)%$")),
                                      ("0.6%", surf["copilot"]), ("0.9%", surf["chatgpt"]), ("4.6%", surf["perplexity"]), ("9.2%", surf["gemini"])], s7_note)
R("7.3", "the Google median is 24.6%", "section7_from_aggregates.py", "S", [("24.6%", g(S7, r"Google prompt views only: median ([\d.]+)%"))], f"my recomputation: {q7['prompts']:.1%}")
mr = dict(re.findall(r"^\s+(\w+)\s+median rank\s+(\d+);", S7, re.M))
R("7.3", "youtube.com was among the three most-cited domains other than the sector's own companies in 38 of the 44 sector-by-Google-view cells and in none of the 44 others; its median rank was 1 on AI Overviews, 2 on AI Mode, 7 on Perplexity and Gemini, 151 on ChatGPT and 161 on Copilot",
  "section7_from_aggregates.py", "S", [("38", g(S7, r"top three on Google views (\d+)/44")), ("0", g(S7, r"on the other four (\d+)/44")),
                                      ("1", mr["aio_searchqueries"]), ("1", mr["aio_prompts"]), ("2", mr["aimode_searchqueries"]), ("2", mr["aimode_prompts"]),
                                      ("7", mr["perplexity"]), ("7", mr["gemini"]), ("151", mr["chatgpt"]), ("161", mr["copilot"])],
  f"my recount: top three {q7['top3_g']}/44 and {q7['top3_o']}/44; median ranks {q7['mrank']}")
R("7.3", "without it, the medians are 12.7% and 1.6%, and the lowest Google view exceeds the highest other surface in 7 of 11 sectors", "section7_from_aggregates.py", "S",
  [("12.7%", g(S7, r"without YouTube: Google median ([\d.]+)%")), ("1.6%", g(S7, r"without YouTube: Google median [\d.]+%, other four ([\d.]+)%")), ("7", g(S7, r"highest other in (\d+)/11"))],
  f"my recomputation: {q7['noyt_g']:.1%}, {q7['noyt_o']:.1%}, {q7['noyt_dom']} of 11")
ot = {k: g(S7, rf"^\s+{k}\s+Google ([\d.]+)%; other four ([\d.]+)%; Copilot ([\d.]+)%$") for k in ("reference", "forum", "report_brands", "other_web")}
R("7.3", "the median reference share was 2.7% on the other four surfaces against 3.2% on the Google views, and forum sites 1.1% against 5.7%", "section7_from_aggregates.py", "S",
  [("2.7%", ot["reference"][1]), ("3.2%", ot["reference"][0]), ("1.1%", ot["forum"][1]), ("5.7%", ot["forum"][0])],
  f"my recomputation: reference {q7['reference'][1]:.1%}/{q7['reference'][0]:.1%}, forum {q7['forum'][1]:.1%}/{q7['forum'][0]:.1%}")
R("7.3", "the largest classified type was the sector's own company domains (median 14.1%)", "section7_from_aggregates.py", "S", [("14.1%", ot["report_brands"][1])])
R("7.3", "held a median 61% of incidences on the Google views and 72% on the other four (90% on Copilot)", "section7_from_aggregates.py", "S",
  [("61%", ot["other_web"][0]), ("72%", ot["other_web"][1]), ("90%", ot["other_web"][2])])
TYPES_SRC = rd(B / "ai_citation_cross_sector/scripts/cross_sector.py")
comm = set()
for t in ("video", "forum", "social", "user_publishing"):
    comm |= set(re.findall(r'"([\w.]+\.\w+)"', g(TYPES_SRC, rf'"{t}": \{{([^}}]*)\}}', 1)))
platforms = {d for d in comm if d != "twitter.com"}  # x.com and twitter.com are one platform
R("7.3", "the claim here is about the share going to seventeen named video and community platforms", "cross_sector.py (type list)", "C",
  [("17", len(platforms))], f"{len(comm)} domains, of which x.com and twitter.com are one platform")
var = {k: g(S7, rf"^\s+{k}\s+surface (\d+)%\s+sector (\d+)%$") for k in ("video_community", "news", "government", "report_brands")}
R("7.3", "Across the 88 cells, answer surface explains 77% of the variance of that share (bootstrap 95% interval over sectors 70% to 91%) and sector 14% (5% to 20%); for news (12% against 73%), government (26% against 49%) and the companies' own domains (40% against 45%)",
  "section7_from_aggregates.py", "S", [("88", g(S7, r"(\d+) cells;")), ("77%", var["video_community"][0]), ("70%", g(S7, r"bootstrap video_community\s+surface \[(\d+)%")),
                                      ("91%", g(S7, r"bootstrap video_community\s+surface \[\d+%, (\d+)%\]")), ("14%", var["video_community"][1]),
                                      ("5%", g(S7, r"bootstrap video_community\s+surface \[\d+%, \d+%\]\s+sector \[(\d+)%")),
                                      ("20%", g(S7, r"bootstrap video_community\s+surface \[\d+%, \d+%\]\s+sector \[\d+%, (\d+)%\]")),
                                      ("12%", var["news"][0]), ("73%", var["news"][1]), ("26%", var["government"][0]), ("49%", var["government"][1]),
                                      ("40%", var["report_brands"][0]), ("45%", var["report_brands"][1])],
  "my recomputation: " + ", ".join(f"{k} {a:.0%}/{b:.0%}" for k, (a, b) in q7["var"].items()))
jac = dict(re.findall(r"(\w+) ([\d.]+)", g(S7, r"^\s+aio_searchqueries 0[\d.]+, .*$", 0)))
R("7.3", "(mean pairwise Jaccard 0.36 to 0.40 across the 55 sector pairs) than on the other four (0.08 to 0.23)", "section7_from_aggregates.py", "S",
  [("0.36", min(float(jac[p]) for p in GOO)), ("0.40", max(float(jac[p]) for p in GOO)), ("55", g(S7, r"across the (\d+) sector pairs")),
   ("0.08", min(float(jac[p]) for p in OTH)), ("0.23", max(float(jac[p]) for p in OTH))],
  "my recomputation from the top-ten file: " + ", ".join(f"{p} {v:.2f}" for p, v in q7["jac"].items()))
c3 = {}
c3rows = [l for l in MT.split("\n\n")[0].splitlines()[2:]]
for line in c3rows:
    cells = [c.strip().rstrip("†") for c in line.strip().strip("|").split("|")]
    c3[cells[0]] = cells[1:]
chat_col = [c3[s][4] for s in ["Information Technology", "Health Care", "Financials", "Consumer Discretionary", "Communication Services", "Industrials",
                               "Consumer Staples", "Energy", "Utilities", "Real Estate", "Materials"]]
R("7.3", "ChatGPT, whose most-cited domain other than the sector's own companies was a search engine (Information Technology), the Food and Drug Administration (Health Care), a personal-finance publisher (Financials), a streaming guide (Consumer Discretionary), a Disney property (Communication Services), a graphics-card maker (Industrials, the ambiguous name described under Limits), reddit.com (Consumer Staples), the Securities and Exchange Commission (Energy, Utilities and Real Estate) and a paint maker (Materials)",
  "make_tables_sector_surface.py", "S", [("=google|fda.gov|nerdwallet|justwatch|go|nvidia|reddit|sec.gov|sec.gov|sec.gov|benjaminmoore", "=" + "|".join(chat_col))],
  "descriptions mapped to domains by me: search engine = google.com, personal-finance publisher = nerdwallet.com, streaming guide = justwatch.com, Disney property = go.com, graphics-card maker = nvidia.com, paint maker = benjaminmoore.com")
R("7.3", "with the company-property list its direction reversed on search queries (22.5% against 24.2%), and in no check did it approach significance (p = 0.23 to 0.63)",
  "cross_sector_sensitivity2.py (needs the raw exports)", "X", [("22.5%", g(CSS2, r"company properties\s+AI Overviews \(search queries\)\s+([\d.]+)% vs")),
                                                                ("24.2%", g(CSS2, r"company properties\s+AI Overviews \(search queries\)\s+[\d.]+% vs ([\d.]+)%")),
                                                                ("0.23", min(float(x) for x in re.findall(r"vs [\d.]+%, p ([\d.]+)", CSS2))),
                                                                ("0.63", max(float(x) for x in re.findall(r"vs [\d.]+%, p ([\d.]+)", CSS2)))])
R("7.3", "Sherwin-Williams holds 94% of Materials, Amazon 75% of Consumer Discretionary, Walmart 65% of Consumer Staples, Apple 62% of Information Technology and Uber 55% of Industrials",
  "cross_sector_sensitivity.py (needs the raw all-surface exports)", "X",
  [("94%", g(CSS, r"Materials\s+Sherwin-Williams\s+([\d.]+)%")), ("75%", g(CSS, r"Consumer Discretionary\s+Amazon\s+([\d.]+)%")),
   ("65%", g(CSS, r"Consumer Staples\s+Walmart\s+([\d.]+)%")), ("62%", g(CSS, r"Information Technology\s+Apple\s+([\d.]+)%")), ("55%", g(CSS, r"Industrials\s+Uber\s+([\d.]+)%"))])
c4 = {}
for line in MT.split("\n\n")[1].splitlines()[2:]:
    cells = [c.strip() for c in line.strip().strip("|").split("|")]
    c4[cells[0]] = (cells[1].split(", "), cells[2].split(", "))
chat3 = {d for v in c4.values() for d in v[1]}
R("7.3", "such as go.com, chase.com and mobil.com among ChatGPT's top three", "make_tables_sector_surface.py", "S",
  [("=yes", "=yes" if {"go†", "chase†", "mobil†"} <= chat3 else "=no")], "Table C4 ChatGPT column, marked as company properties")
R("7.4", "it held on AI Overviews (9 of 11 sectors on search queries, 8 of 11 on prompts) and not on AI Mode (2 of 11 on each)", "section7_from_aggregates.py", "S",
  [("9", g(S7, r"'aio_searchqueries': (\d+)")), ("8", g(S7, r"'aio_prompts': (\d+)")), ("2", g(S7, r"'aimode_searchqueries': (\d+)")), ("2", g(S7, r"'aimode_prompts': (\d+)"))],
  f"my recount from the aggregates: {q7['p1']}")
R("7.4", "(median 93% and 98% of its incidences on the two views)", "cross_sector_sensitivity2.py (needs the raw exports)", "X",
  [("93%", g(CSS2, r"AI Mode \(search queries\)\s+www.google.com (\d+)%")), ("98%", g(CSS2, r"AI Mode \(prompts\)\s+www.google.com (\d+)%"))])
R("7.4", "it would hold (9 of 11) if google.com, Google's answer surfaces citing Google's own pages, were set aside", "cross_sector_sensitivity.py (needs the raw exports)", "X",
  [("9", g(CSS, r"P1 with google.com set aside: .* both products (\d+)"))], f"my recount from the released top-ten file: {q7['p1_google_aside']} of 11")
R("7.4", "held on all three (11, 6 and 11 of 11)", "section7_from_aggregates.py", "S",
  [("11", g(S7, r"'chatgpt': (\d+)")), ("6", g(S7, r"'perplexity': (\d+)")), ("11", g(S7, r"'copilot': (\d+)"))], f"my recount: {q7['p2']}")
R("7.4", "it held in 3 of 11, and ChatGPT was a failing surface in all eight sectors where it did not hold", "section7_from_aggregates.py", "S",
  [("3", g(S7, r"every surface but Copilot (\d+)/11")), ("8", g(S7, r"ChatGPT fails in (\d+) of")), ("8", g(S7, r"ChatGPT fails in \d+ of the (\d+) others"))],
  f"my recount: {q7['p3']} of 11; ChatGPT failing in {q7['p3_chatgpt_fail']}")
p4 = re.findall(r"P4 (\w+): consumer ([\d.]+)% against other ([\d.]+)%; exact one-sided p ([\d.]+)", S7)
R("7.4", "held in direction (26.9% against 24.2% on search queries, 29.6% against 24.4% on prompts) and not beyond chance (exact one-sided permutation p = 0.27 and 0.21)",
  "section7_from_aggregates.py", "S", [("26.9%", p4[0][1]), ("24.2%", p4[0][2]), ("29.6%", p4[1][1]), ("24.4%", p4[1][2]), ("0.27", p4[0][3]), ("0.21", p4[1][3])],
  "my recomputation (exact over 252 splits): " + "; ".join(f"{p} {a:.1%} vs {b:.1%}, p {pp:.3f}" for p, (a, b, pp) in q7["p4"].items()))
R("7.5", "(Google median 21.5%, other four 3.3%; lowest Google view above the highest other surface in 11 of 11 sectors)", "cross_sector_sensitivity.py (needs the raw exports)", "X",
  [("21.5%", g(CSS, r"'Found in' instead of 'Cited in': Google median ([\d.]+)%")), ("3.3%", g(CSS, r"'Found in' instead of 'Cited in': Google median [\d.]+%, other four median ([\d.]+)%")),
   ("11", g(CSS, r"'Found in' instead of 'Cited in': .* in (\d+)/11 sectors"))])
R("7.5", "with the largest single host in place of summed hosts (22.0%, 2.4%, 11 of 11)", "cross_sector_sensitivity.py (needs the raw exports)", "X",
  [("22.0%", g(CSS, r"largest single host instead of summed hosts: Google median ([\d.]+)%")), ("2.4%", g(CSS, r"largest single host instead of summed hosts: Google median [\d.]+%, other four median ([\d.]+)%")),
   ("11", g(CSS, r"largest single host instead of summed hosts: .* in (\d+)/11 sectors"))])
R("7.5", "and with 64 properties of the sector's companies", "none (design/cross_sector_company_properties.csv)", "D", [("64", len(PROPS))])
R("7.5", "counted as company domains (19.8%, 2.1%, 10 of 11)", "cross_sector_sensitivity.py (needs the raw exports)", "X",
  [("19.8%", g(CSS, r"company properties counted as company domains: Google median ([\d.]+)%")), ("2.1%", g(CSS, r"company properties counted as company domains: Google median [\d.]+%, other four median ([\d.]+)%")),
   ("10", g(CSS, r"company properties counted as company domains: .* in (\d+)/11 sectors"))])
cs_line = g(CSS, r"^Communication Services, entered domains -> .*$", 0)
cs_pairs = re.findall(r"([\w ()]+?) ([\d.]+)% -> ([\d.]+)%", cs_line)
cs_g = [(float(a), float(b)) for nm, a, b in cs_pairs if nm.strip().startswith(("AI Overviews", "AI Mode"))]
R("7.5", "the Google views fall from 20.2% to 32.4% to 5.9% to 12.7%, and Gemini's 9.2% exceeds AI Mode on search queries", "cross_sector_sensitivity.py (needs the raw exports)", "X",
  [("20.2%", min(a for a, _ in cs_g)), ("32.4%", max(a for a, _ in cs_g)), ("5.9%", min(b for _, b in cs_g)), ("12.7%", max(b for _, b in cs_g)),
   ("9.2%", g(cs_line, r"Gemini [\d.]+% -> ([\d.]+)%", 1)),
   ("=yes", "=yes" if float(g(cs_line, r"Gemini [\d.]+% -> ([\d.]+)%", 1)) > float(g(cs_line, r"AI Mode \(search queries\) [\d.]+% -> ([\d.]+)%", 1)) else "=no")])
tr = {k: g(CSS, rf"first {k} export rows only: Google median ([\d.]+)%, other four median ([\d.]+)%") for k in ("100", "250", "500")}
R("7.5", "Restricting each export to its first 100, 250 or 500 rows gives Google medians of 30.6%, 26.3% and 23.3% against 3.0%, 2.6% and 2.3%", "cross_sector_sensitivity.py (needs the raw exports)", "X",
  [("30.6%", tr["100"][0]), ("26.3%", tr["250"][0]), ("23.3%", tr["500"][0]), ("3.0%", tr["100"][1]), ("2.6%", tr["250"][1]), ("2.3%", tr["500"][1])])
R("7.5", "while the ratio between the two groups stays near ten", "cross_sector_sensitivity.py (needs the raw exports); ratio: arithmetic", "X",
  [("=near ten", "=near ten" if all(9 <= float(a) / float(b) <= 11 for a, b in tr.values()) else "=no")],
  "ratios " + ", ".join(f"{float(a) / float(b):.1f}" for a, b in tr.values()))
trs = dict(re.findall(r"(\w+) ([\d.]+)%", g(S7, r"^\s+aio_searchqueries [\d.]+%, aio_prompts .*range of medians.*$", 0)))
R("7.5", "Ranks 501 to 1,000 carry a median 7.6% to 13.8% of each export's incidences", "section7_from_aggregates.py", "S",
  [("7.6%", min(float(trs[p]) for p in SURF)), ("13.8%", max(float(trs[p]) for p in SURF))],
  "my recomputation from cross_sector_cells.csv: " + f"{min(q7['trunc'].values()):.1%} to {max(q7['trunc'].values()):.1%}")
rtx = {p: g(S7, rf"^\s+{p}\s+video and community ([\d.]+)% -> ([\d.]+)%; YouTube rank (\d+) -> (\d+); top non-company (\S+) -> (\S+)$") for p in SURF if p != "chatgpt"}
R("7.6", "(video and community share 31.3% to 30.1% on AI Overviews search queries; YouTube's rank stayed 1 on AI Overviews and moved from 2 to 1 on AI Mode prompts), moved Perplexity from 6.2% to 5.5% and Gemini from 15.0% to 13.4%, and changed Copilot's top non-company domain from amazon.com to a flight-route site",
  "section7_from_aggregates.py", "S", [("31.3%", rtx["aio_searchqueries"][0]), ("30.1%", rtx["aio_searchqueries"][1]), ("1", rtx["aio_searchqueries"][3]), ("1", rtx["aio_prompts"][3]),
                                      ("2", rtx["aimode_prompts"][2]), ("1", rtx["aimode_prompts"][3]), ("6.2%", rtx["perplexity"][0]), ("5.5%", rtx["perplexity"][1]),
                                      ("15.0%", rtx["gemini"][0]), ("13.4%", rtx["gemini"][1]), ("=amazon.com", "=" + rtx["copilot"][4]),
                                      ("=a flight-route site", "=a flight-route site" if rtx["copilot"][5] == "flightconnections.com" else "=" + rtx["copilot"][5])])
R("7.6", "without Industrials the ChatGPT median is 0.8%, P2 holds on ChatGPT and Copilot in 10 of 10 sectors and on Perplexity in 6 of 10, and P3 holds in 3 of 10",
  "cross_sector_sensitivity.py; cross_sector_sensitivity2.py (need the raw exports)", "X",
  [("0.8%", g(CSS, r"ChatGPT without Industrials \(RTX\): comm\+video median ([\d.]+)%")), ("10", g(CSS2, r"P2 ChatGPT\s+(\d+)/10")), ("10", g(CSS2, r"P2 Copilot\s+(\d+)/10")),
   ("6", g(CSS2, r"P2 Perplexity\s+(\d+)/10")), ("3", g(CSS2, r"P3 (\d+)/10"))],
  f"my recomputation from the released aggregates: ChatGPT median {q7['noind_chatgpt']:.1%}; P2 {q7['noind_p2']}; P3 {q7['noind_p3']} of 10")
visa = [float(x) for x in re.findall(r"state.gov\+uscis.gov\+cbp.gov\+dhs.gov ([\d.]+)%", CSS)]
R("7.6", "four immigration and border domains of the US government hold up to 2.2% of a Financials surface's incidences", "cross_sector_sensitivity.py (needs the raw exports)", "X",
  [("4", len(g(CSS, r"(state.gov\+uscis.gov\+cbp.gov\+dhs.gov)", 1).split("+"))), ("2.2%", max(visa))])
R("7.6", "cells range from 860 to 18,381,848 incidences", "section7_from_aggregates.py", "S",
  [("860", g(S7, r"per cell ([\d,]+) to")), ("18,381,848", g(S7, r"per cell [\d,]+ to ([\d,]+)"))], f"my recomputation: {q7['cells']}")
R("7.6, last para", "give video and community domains about ten times the pooled median share of the other four surfaces, and more than twice Gemini's", "section7_from_aggregates.py (ratios: arithmetic)", "S",
  [("10", float(g(S7, r"Google views median ([\d.]+)%")) / float(g(S7, r"other four median ([\d.]+)%"))),
   ("=more than twice", "=more than twice" if float(g(S7, r"Google views median ([\d.]+)%")) / float(surf["gemini"]) > 2 else "=no")])
R("7, Figure 7 caption", "(nine companies in Communication Services)", "make_brand_radar_urls.py", "S", [("9", g(BR, r"'xlc': (\d+)"))])

# ---- Section 8, Table 5
derived = []
for d in DAYS:
    tot, b1, b2, b3_ = t5("Ranking positions, all", d), t5("Positions 1–3", d), t5("Positions 4–10", d), t5("Positions 11–20", d)
    if None in (tot, b1, b2, b3_):
        continue
    derived.append((T5["Positions 21–100 (derived)"][DAYS.index(d)], tot - b1 - b2 - b3_))
R("8, Table 5", "| Positions 21–100 (derived) | 1 | 255 | 314 | **n/r** | 242 | 250 | 70 | n/r |", "none (arithmetic on Table 5)", "C", derived, "total less the three reported bands, every full column")
R("8", "the section held 15,830 ranking positions, 1,874 of them in positions 1 to 3, with an estimated 51,800 monthly visits and nineteen referring domains", "none (Table 5, day 37)", "C",
  [("15,830", t5("Ranking positions, all", 37)), ("1,874", t5("Positions 1–3", 37)), ("51,800", t5("Estimated visits (Ahrefs)", 37)), ("19", t5("Live referring domains", 37))])
R("8", "By day 77 it held 43,980 positions across 441 URLs holding at least one position, ranked for 29,000 keywords in one instrument and 58,586 in the other, was recorded as a cited source in Google AI Overviews on 7,455 keywords, and appeared in 17,206 stored AI answers",
  "none (Table 5; Table 3; Section 5.2)", "C", [("43,980", t5("Ranking positions, all", 77)), ("441", t5("Pages holding a position", 77)),
                                               ("7,455", n(T3[3][1].split(" of ")[0])), ("17,206", t5("AI answers citing the section", 77))])
R("8", "the ten highest-traffic carry 22.8% of estimated visits and the top 50 carry 64.9%", "none (single-read file)", "D",
  [("22.8%", SINGLE["share of estimated visits carried by the ten highest-traffic URLs of the 441 holding a position"]),
   ("64.9%", SINGLE["share of estimated visits carried by the top 50 of the 441 URLs"])])
R("8", "Fifty of 441 is 11% of the pages", "none (arithmetic)", "C", [("11%", 100 * 50 / 441)])
R("8", "The section ranks in 105 countries, with 18.5% of Ahrefs-estimated visits from outside the US", "none (single-read file)", "D",
  [("105", SINGLE["countries in which the section ranks"]), ("18.5%", SINGLE["share of Ahrefs-estimated visits from outside the US"])])

# ---- Section 9
pages = dict((k, int(v)) for k, v in re.findall(r'\("([^"]+?) (?:hub|code page)", (\d+), (?:True|False)\)', FIGS))
R("9.1", "New York 474 answers, California 337, Texas 322, Florida 304, and the national hub 294. Each exceeds any individual code page: 214 Dallas 238, 786 Miami 228, 404 Atlanta 218",
  "make_figs_v4.py (Figure 8 literals)", "F", [("474", pages["New York"]), ("337", pages["California"]), ("322", pages["Texas"]), ("304", pages["Florida"]),
                                               ("294", pages["national"]), ("238", pages["214 (Dallas)"]), ("228", pages["786 (Miami)"]), ("218", pages["404 (Atlanta)"]),
                                               ("=yes", "=yes" if min(474, 337, 322, 304, 294) > 238 else "=no")], "dashboard reads; no data file")
per = {st: sum(r["location"] == st for r in CODES) for st in ("NY", "CA", "TX", "FL")}
R("9.1", "per code it lists, a state hub is cited less often than the most-cited code pages", "none (arithmetic; section_code_pages file)", "C",
  [("=yes", "=yes" if max(474 / per["NY"], 337 / per["CA"], 322 / per["TX"], 304 / per["FL"]) < 218 else "=no")],
  f"answers per listed code: NY {474 / per['NY']:.0f} ({per['NY']} codes), CA {337 / per['CA']:.0f}, TX {322 / per['TX']:.0f}, FL {304 / per['FL']:.0f}")
R("9.2", "Wikipedia, at 97, is co-cited in roughly 11,000 of the answers that cite the section. Two other national carriers of comparable authority are co-cited 9 times (Domain Rating 91) and 240 times (Domain Rating 87), against the section's 17,206",
  "none (single-read file; Table 5)", "D", [("11,000", SINGLE["answers citing the section that also cite wikipedia.org"].replace("about ", "")),
                                           ("9", SINGLE["answers citing the section that also cite a national carrier (Domain Rating 91)"]),
                                           ("240", SINGLE["answers citing the section that also cite a national carrier (Domain Rating 87)"]),
                                           ("17,206", t5("AI answers citing the section", 77))])

# ---- Section 10
R("10", "which with nineteen at day 37 implies about 841 at the end of September", "none (arithmetic)", "C", [("841", 19 + 917 - 95)])
R("10", "61.9% .info, 26.4% .asia, 10.2% .xyz", "make_figs_v4.py (Figure 4 literals)", "F", [("61.9%", fig3[0]), ("26.4%", fig3[1]), ("10.2%", fig3[2])])
R("10", "The second instrument indexes 80 referring domains for the subfolder, 88% from domains at Authority Score 0–10 and 75% on .xyz", "make_figs_v4.py (Figure 4 literals)", "F",
  [("80", 80 if "Semrush\\n80 domains" in FIGS else 0), ("75%", fig3[3])], "88% is a dashboard read in no file")
seq = [(0, 15), (15, 30), (30, 37), (37, 45), (45, 60), (60, 75)]
for r_, (a_, b_) in zip(T6, seq):
    rda, rdb = t5("Live referring domains", a_), t5("Live referring domains", b_)
    pa_, pb_ = t5("Ranking positions, all", a_), t5("Ranking positions, all", b_)
    rate = n(r_[4].split("/")[0])
    R(f"10.1, Table 6 ({r_[0]})", "| " + " | ".join(r_) + " |", "none (arithmetic on Table 5)", "C",
      [(r_[1].split(" to ")[0], rda), (r_[1].split(" to ")[1], rdb), (r_[2], rdb - rda), (r_[3], pb_ - pa_), (str(int(rate)), (pb_ - pa_) / (b_ - a_))])
R("10.1, Figure 9 caption", "day 6 (984 positions, 186 in 1–3) and day 67 (38,801 and 6,942)", "none (single-read file); make_figs_v4.py literals", "D+F",
  [("984", SINGLE["ranking positions at day 6"]), ("186", SINGLE["positions 1 to 3 at day 6"]), ("38,801", SINGLE["ranking positions at day 67"]),
   ("6,942", SINGLE["positions 1 to 3 at day 67"]), ("=yes", "=yes" if "984" in FIGS and "38801" in FIGS and "6942" in FIGS and "186" in FIGS else "=no")])
p75, p37, p45 = t5("Ranking positions, all", 75), t5("Ranking positions, all", 37), t5("Ranking positions, all", 45)
R("10.1", "Of the 43,302 positions held at day 75, 15,830 (36.6%) were held at day 37 and 27,472 (63.4%) were acquired after the network began arriving", "none (arithmetic on Table 5)", "C",
  [("43,302", p75), ("15,830", p37), ("36.6%", 100 * p37 / p75), ("27,472", p75 - p37), ("63.4%", 100 * (p75 - p37) / p75)])
R("10.1", "that share is itself bounded rather than exact: 53.1% to 63.4%", "none (arithmetic on Table 5: day 45 and day 37)", "C",
  [("53.1%", 100 * (p75 - p45) / p75), ("63.4%", 100 * (p75 - p37) / p75)])
a75, a30, a45 = t5("AI answers citing the section", 75), t5("AI answers citing the section", 30), t5("AI answers citing the section", 45)
R("10.1", "so the corresponding share is bounded 56.9% to 74.9%", "none (arithmetic on Table 5: day 45 and day 30)", "C",
  [("56.9%", 100 * (a75 - a45) / a75), ("74.9%", 100 * (a75 - a30) / a75)])
R("10.1", "The fastest clean interval, 768 a day across days 15 to 30, is 37% faster than the 562 a day of the arrival interval", "none (arithmetic on Table 6)", "C",
  [("37%", 100 * (768 / 562 - 1))])

# ---- Section 12
R("12", "2.0x on ranking keywords (3.2x worldwide) and 11.4x on referring domains", "none (arithmetic)", "C", [("2.0x", 58586 / 29000), ("3.2x", 92300 / 28900), ("11.4x", 913 / 80)])
R("12", "across twelve prefixes of the same domain the visits ratio runs from 0.20x to 7.24x (8.89x territory-matched)", "analyze.py", "S",
  [("0.20x", g(A, r"min ([\d.]+)x")), ("7.24x", g(A, r"max ([\d.]+)x")), ("8.89x", g(A, r"TERRITORY-MATCHED .*?max ([\d.]+)x"))])
R("12", "which differ by a factor that falls from 2.94 to 1.34", "none (arithmetic on Table 3)", "C", [("2.94", 138 / 47), ("1.34", 10018 / 7455)])
R("12", "The two instruments also disagree about growth, by a factor of 2.7 in one month, and the share of the divergence the keyword universe explains depends on the territory pairing (35% or 54%)",
  "instrument_extra.py", "S", [("2.7", max(map(float, gratio))), ("35%", dec_us[3]), ("54%", dec_ww[3])])
R("12", "between 53.1% and 63.4% of day-75 positions postdate its arrival", "none (arithmetic on Table 5)", "C", [("53.1%", 100 * (p75 - p45) / p75), ("63.4%", 100 * (p75 - p37) / p75)])

# ---- Section 13
R("13", "The example ships a 924-query demonstration over the 66 codes in its registry extract, at digest `f05ce279942be5f8`", "ufi freeze (ufi repository; not in the bundle)", "N", [("924", "-"), ("66", "-")])
R("13", "lock digest `7290a2235d8de05f`, locked 12 October 2026", "ufi parameter lock (ufi repository; not in the bundle)", "N", [("=7290a2235d8de05f", "-")])
R("13", "Every one of the 372 geographic codes in service received a page", "none (section_code_pages file)", "D", [("372", grp["geographic, in service"])])
ots_h = g(OTS, r"Bitcoin block height (\d+)", 1)
ots_ok = "MATCH" in g(OTS, r"-> (MATCH|MISMATCH)", 1)
ex_root = g(EXPL, r"merkle_root (\w+)", 1)
ex_time = g(EXPL, r"timestamp (\S+)", 1)
ots_root = g(OTS, r"as block explorers show it (\w+)", 1)
R("13", "the stamp is anchored in Bitcoin block 971,506, mined at 04:05 UTC on 15 October 2026", "none (framework_test_r1 .ots proof, read offline; block explorer)", "C",
  [("971,506", ots_h), ("=04:05 UTC on 15 October 2026", "=04:05 UTC on 15 October 2026" if ex_time.startswith("2026-10-15T04:05") else "=" + ex_time),
   ("=proof commits to the shipped manifest", "=proof commits to the shipped manifest" if ots_ok else "=no"),
   ("=merkle root in the proof equals the block's", "=merkle root in the proof equals the block's" if ex_root == ots_root else "=no")],
  f"merkle root {ots_root}; block time {ex_time}; the held-back R1 files themselves are not in the bundle")
R("13", "(14 of 88 exports, 44,463 answers)", "none (prompt-level exports withheld; no file in the bundle)", "N", [("14", "-"), ("44,463", "-")])
R("13", "was stamped with OpenTimestamps before any reading under it, in the same Bitcoin block", "none (the second-domain protocol and its proof are not in the bundle)", "N", [("=same block", "-")])
R("13.1", "Costco is one of the 109 companies of Section 7", "none (design/cross_sector_companies.csv)", "D",
  [("=yes", "=yes" if any(r["brand_name_used"] == "Costco" for r in COMPANIES) else "=no"), ("109", len(COMPANIES))])

# ---- Section 14
R("14", "which moved from 14,823 (9 October) to 17,206 (11 October) and 17,400 (12 October)", "none (Table 5; data/ahrefs file)", "D",
  [("14,823", t5("AI answers citing the section", 75)), ("17,206", t5("AI answers citing the section", 77)), ("17,400", AC["/local/area-codes/"]["ahrefs_ai_responses"])])
R("14", "the October run-rate had moved by about 3% (worldwide 1,910,867, US 1,659,636)", "none (single-read file; arithmetic)", "D+C",
  [("1,910,867", SINGLE["October run-rate visits on the Semrush re-read (worldwide)"]), ("1,659,636", SINGLE["October run-rate visits on the Semrush re-read (US)"]),
   ("3%", 100 * (1910867 / 1858297 - 1)), ("3%", 100 * (1659636 / 1610284 - 1))])
R("14", "of 173 numbers the paper quotes, 136 matched what the released scripts and data give, none differed, and 37 could not be checked", "08_REVIEW/.../checks/numbers_table.py", "S",
  [("173", g(NT, r"rows (\d+);")), ("136", g(NT, r"MATCH (\d+) \(")), ("0", g(NT, r"MISMATCH (\d+);")), ("37", g(NT, r"CANNOT RUN (\d+)"))],
  "numbers_table.py is a hand-written table of the earlier run's verdicts (on the 14 October bundle); it recomputes nothing")

# ---- Appendix A
R("Appendix A", "withdrew a 9.2x AI-answer comparison as a scope mismatch", "none (arithmetic)", "C", [("9.2x", 158100 / 17206)])
R("Appendix A", "corrected that bound from 13 times to a factor of 5.2", "none (arithmetic)", "C", [("13", (r_usww[1] - 1) / 2), ("5.2", math.sqrt(27.1))])
R("Appendix A", "branch agreement reported as +0.47 to +0.75 depending on how labels are attributed, replacing an earlier +0.78", "supplement_r10.py; analyze_reviews.py", "X",
  [("+0.47", g(SR, r"modal attribution: rho=([+-][\d.]+)")), ("+0.75", g(SR, r"split mentions: rho=([+-][\d.]+)")), ("+0.78", g(AR, r"branch-level Spearman: rho=([+-][\d.]+)"))])
R("Appendix A", "the taxonomy-wide count of waiting labels, 11 rather than one", "supplement_r10.py; analyze_reviews.py", "X",
  [("11", g(SR, r"distinct such labels: (\d+)")), ("1", g(AR, r"taxonomy\): (\d+) \|"))])
R("Appendix A", f"replaced a stale copy of Figure 5 whose panel showed {M}0.09 for the {M}0.11 the text reports", "make_figs_v4.py (Figure 5 title); analyze.py", "F+S",
  [(f"{M}0.11", g(FIGS, r"Spearman ρ = ([−-][\d.]+)", 1)), (f"{M}0.11", g(A, r"rho\(age, visits ratio\) = ([+-][\d.]+)"))])
R("Appendix A", "the count of works naming the vendor tools included three duplicates (456, not 459)", "vendor_reliance.py --offline", "S",
  [("3", g(VR, r"\((\d+) duplicates dropped\)")), ("456", g(VR, r"; (\d+) name at least one tool")), ("459", len(named_raw))], "459 = my count of named works before removing duplicate ids")

# ---- Appendix B
R("Appendix B", "about 0.22 when 30 of 66 entities have none", "ufi score (ufi repository; not in the bundle)", "N", [("0.22", "-")],
  "(30 + 1) / 2 tied rank normalized as (r - 1) / (n - 1) gives 0.223; the implementation is not in the bundle")
R("Appendix B", "On the released example these are 4/5 and 70.4%", "ufi cq (ufi repository; not in the bundle)", "N", [("=4/5", "-"), ("70.4%", "-")])

# ---- Appendix C: Tables C1 to C4 against the script outputs
_, C1, _ = md_table("*Table C1.")
c1s = {}
for line in g(S7, r"== Appendix C1:.*?\n((?:  .*\n)+)", 1).splitlines():
    nm = line.split()[0]
    c1s[nm] = re.findall(r"([\d.]+)% \(([\d.]+)%-([\d.]+)%\)", line)
names = {"AI Overviews, search queries": "aio_searchqueries", "AI Overviews, prompts": "aio_prompts", "AI Mode, search queries": "aimode_searchqueries",
         "AI Mode, prompts": "aimode_prompts", "ChatGPT": "chatgpt", "Perplexity": "perplexity", "Gemini": "gemini", "Copilot": "copilot"}
for r in C1:
    got = c1s[names[r[0]]]
    pairs = []
    for cell, (m_, lo_, hi_) in zip(r[1:], got):
        pm, plo, phi = re.match(r"([\d.]+)% \(([\d.]+)–([\d.]+)\)", cell).groups()
        pairs += [(pm, m_), (plo, lo_), (phi, hi_)]
    R(f"Appendix C, Table C1 ({r[0]})", "| " + " | ".join(r) + " |", "section7_from_aggregates.py", "S", pairs, "6 cells x (median, min, max)")
_, C2, _ = md_table("*Table C2.")
c2s = {}
for line in g(S7, r"== Appendix C2:.*?\n((?:  .*\n)+)", 1).splitlines():
    parts = line.split()
    c2s[parts[0]] = parts[1:]
sec_code = {"Information Technology": "xlk", "Health Care": "xlv", "Financials": "xlf", "Consumer Discretionary": "xly", "Communication Services": "xlc",
            "Industrials": "xli", "Consumer Staples": "xlp", "Energy": "xle", "Utilities": "xlu", "Real Estate": "xlre", "Materials": "xlb"}
for r in C2:
    R(f"Appendix C, Table C2 ({r[0]})", "| " + " | ".join(r) + " |", "section7_from_aggregates.py", "S", list(zip(r[1:], c2s[sec_code[r[0]]])), "8 cells, thousands")
_, C3, _ = md_table("*Table C3.")
c3m = {}
for line in MT.split("\n\n")[0].splitlines()[2:]:
    cells = [c.strip() for c in line.strip().strip("|").split("|")]
    c3m[cells[0]] = cells[1:]
for r in C3:
    R(f"Appendix C, Table C3 ({r[0]})", "| " + " | ".join(r) + " |", "make_tables_sector_surface.py", "S", [("=" + c, "=" + d) for c, d in zip(r[1:], c3m[r[0]])], "8 cells (domain names)")
_, C4, _ = md_table("*Table C4.")
c4m = {}
for line in MT.split("\n\n")[1].splitlines()[2:]:
    cells = [c.strip() for c in line.strip().strip("|").split("|")]
    c4m[cells[0]] = cells[1:]
for r in C4:
    R(f"Appendix C, Table C4 ({r[0]})", "| " + " | ".join(r) + " |", "make_tables_sector_surface.py", "S", [("=" + c, "=" + d) for c, d in zip(r[1:], c4m[r[0]])], "2 cells x 3 domains")
cs_google = [c.rstrip("†") for c in c3m["Communication Services"][:4]]
R("Appendix C, closing para", "the top source is youtube.com or google.com in 38 of the 44 sector-by-view cells, four of them Alphabet's own properties in Communication Services. On Perplexity and Gemini it is wikipedia.org or reddit.com in 15 of 22, on ChatGPT a government domain in 4 of 11 sectors, and on Copilot a retailer (walmart.com or amazon.com) in 6 of 11",
  "make_tables_sector_surface.py", "S", [("38", g(MT, r"youtube.com or google.com in (\d+) of")), ("44", g(MT, r"youtube.com or google.com in \d+ of (\d+)")),
                                         ("4", sum(c.endswith("†") for c in c3m["Communication Services"][:4])), ("15", g(MT, r"wikipedia.org or reddit.com in (\d+) of 22")),
                                         ("4", g(MT, r"a .gov domain in (\d+) of 11")), ("6", g(MT, r"walmart.com or amazon.com in (\d+) of 11"))])

# ---- Appendix D, Table D1
_, D1, d1line = md_table("*Table D1.")
D1 = {r[0]: r for r in D1}


def d1(metric):
    r = D1[metric]
    return "| " + " | ".join(r) + " |"


R("Appendix D, Table D1", d1("Stakes"), "vendor_reliance.py --offline", "S", [("456", g(VR, r"; (\d+) name at least one tool")), ("86%", g(VR, r"\((\d+)%\); two or more"))])
R("Appendix D, Table D1", d1("M1 visits ratio"), "arithmetic on Table 2", "C",
  [("7.5x", min(r_usww)), ("27.1x", max(r_usww)), ("8.6x", min(r_wwww)), ("29.9x", max(r_wwww)), ("9.2x", min(r_usus)), ("33.3x", max(r_usus))])
R("Appendix D, Table D1", d1("M1 growth agreement"), "instrument_extra.py", "S", [("0.95", gratio[0]), ("2.66", gratio[1]), ("1.37", gratio[2])])
R("Appendix D, Table D1", d1("M1 error bound"), "arithmetic on Table 2", "C", [("5.2", math.sqrt(27.1)), ("27.1x", r_usww[1])])
R("Appendix D, Table D1", d1("M1 decomposition"), "instrument_extra.py", "S", [("35%", dec_us[3]), ("54%", dec_ww[3])])
R("Appendix D, Table D1", d1("M1 cross-section"), "analyze.py", "S",
  [("0.20x", g(A, r"min ([\d.]+)x")), ("7.24x", g(A, r"max ([\d.]+)x")), ("8.89x", g(A, r"TERRITORY-MATCHED .*?max ([\d.]+)x")), ("1.01", g(A, r"median ([\d.]+), spread"))])
R("Appendix D, Table D1", d1("M1 age relationship"), "analyze.py", "S",
  [(f"{M}0.11", g(A, r"rho\(age, visits ratio\) = ([+-][\d.]+)")), (f"{M}0.64", g(A, r"CI \[([+-][\d.]+),")), ("+0.49", g(A, r"CI \[[+-][\d.]+, ([+-][\d.]+)\]")), ("0.73", g(A, r"permutation p = ([\d.]+)"))])
R("Appendix D, Table D1", d1("M1 ordering agreement"), "analyze.py; instrument_extra.py", "S",
  [("+0.94", g(A, r"ORDERING sections by visits: Spearman ([+-][\d.]+)")), ("+0.82", g(A, r"Kendall tau ([+-][\d.]+)")), ("60", g(A, r"(\d+) of \d+ pairs concordant")),
   ("66", g(A, r"\d+ of (\d+) pairs concordant")), ("51", b3), ("51", b3), ("9", g(IE, r"within 3x: (\d+) of")), ("15", g(IE, r"within 3x: \d+ of (\d+)"))])
R("Appendix D, Table D1", d1("M1 dispersion"), "instrument_extra.py", "S", [("1.13", g(IE, r"geometric mean ([\d.]+)x, geometric SD")), ("3.1", g(IE, r"geometric SD ([\d.]+);"))])
pcts = [100 * n(r[1].split(" of ")[0]) / n(r[1].split(" of ")[1]) for r in T3]
R("Appendix D, Table D1", d1("M1 AI Overview citation"), "arithmetic on Table 3", "C", [("12.6%", min(pcts)), ("20.0%", max(pcts))])
R("Appendix D, Table D1", d1("M2 link rate"), "analyze_reviews.py", "X", [("55.6%", g(AR, r"at least one label: \d+ \(([\d.]+)%")), ("2.25", g(AR, r"per linked review ([\d.]+)"))])
R("Appendix D, Table D1", d1("M2 label agreement"), "analyze_reviews.py; supplement_r10.py", "X",
  [("+0.19", g(AR, r"rho=([+-][\d.]+) p=3.4e-09")), ("+0.27", g(SR, r"unmentioned = 0\): ([+-][\d.]+)"))])
R("Appendix D, Table D1", d1("M2 branch agreement"), "supplement_r10.py", "X",
  [("+0.47", g(SR, r"modal attribution: rho=([+-][\d.]+)")), ("+0.75", g(SR, r"split mentions: rho=([+-][\d.]+)"))])
R("Appendix D, Table D1", d1("M2 complaint rate"), "analyze_reviews.py", "X", [("14.0%", g(AR, r"mentioning waiting: \d+ \(([\d.]+)%")), ("1.9%", g(AR, r"in 5-star reviews: ([\d.]+)%"))])
R("Appendix D, Table D1", d1("M2 link precision"), "r2_link_check.py", "S",
  [("65%", min(A_prec)), ("67%", max(A_prec)), ("0.90", g(LC, r"of 200 items; Cohen's kappa ([\d.]+)")), ("=about 50%", "=about 50%" if all(45 <= x <= 55 for x in sw) else f"={sw}"), ("95%", min(mw)), ("96%", max(mw))],
  f"single-word {sw} (paper: 'about 50%')")
R("Appendix D, Table D1", d1("M2 waiting-match precision"), "r2_link_check.py", "S",
  [("83%", min(B_prec)), ("85%", max(B_prec)), ("0.93", g(LC, r"of 100 items; Cohen's kappa ([\d.]+)")), ("90%", statistics.mean(instore))], f"in store {instore}")
R("Appendix D, Table D1", d1("M3 surface contrast"), "section7_from_aggregates.py (table names cross_sector_sensitivity.py)", "S",
  [("21.3%", g(S7, r"Google views median ([\d.]+)%")), ("17.2", g(S7, r"Google ([\d.]+)% to [\d.]+%; other four")), ("26.7", g(S7, r"Google [\d.]+% to ([\d.]+)%; other four")),
   ("2.1%", g(S7, r"other four median ([\d.]+)%")), ("1.7", g(S7, r"other four ([\d.]+)% to [\d.]+%$")), ("2.7", g(S7, r"other four [\d.]+% to ([\d.]+)%$"))],
  "the shipped cross_sector_sensitivity_output.txt prints the same values")
R("Appendix D, Table D1", d1("M3 every-sector dominance"), "section7_from_aggregates.py (table names cross_sector_sensitivity.py)", "S",
  [("11", g(S7, r"exceeds the highest other surface: (\d+)/11"))])
R("Appendix D, Table D1", d1("M3 cross-sector overlap"), "section7_from_aggregates.py (table names cross_sector.py)", "S",
  [("0.36", min(float(jac[p]) for p in GOO)), ("0.40", max(float(jac[p]) for p in GOO)), ("0.08", min(float(jac[p]) for p in OTH)), ("0.23", max(float(jac[p]) for p in OTH))])
R("Appendix D, Table D1", d1("M3 variance decomposition"), "section7_from_aggregates.py (table names cross_sector_sensitivity2.py)", "S",
  [("77%", var["video_community"][0]), ("14%", var["video_community"][1])])
R("Appendix D, Table D1", d1("M3 predictions"), "section7_from_aggregates.py (table names cross_sector.py)", "S", [("=1 held, 1 direction only, 2 failed", tally(S7))])
R("Appendix D, Table D1", d1("Schema pass rate"), "ufi cq (not in the bundle)", "N", [("=4/5", "-")])
R("Appendix D, Table D1", d1("Instance coverage rate"), "ufi cq (not in the bundle)", "N", [("70.4%", "-")])

# ===================================================================================================== output
cnt = {}
for r in ROWS:
    k = r["status"].split(":")[0]
    cnt[k] = cnt.get(k, 0) + 1
nnum = {}
for r in ROWS:
    k = r["status"].split(":")[0]
    nnum[k] = nnum.get(k, 0) + len(r["paper"].split("; "))
with OUT_TSV.open("w", newline="", encoding="utf-8") as f:
    w = csv.writer(f, delimiter="\t")
    w.writerow(["#", "section", "line", "quote", "script", "basis", "paper", "obtained", "status", "note"])
    for i, r in enumerate(ROWS, 1):
        w.writerow([i, r["sec"], r["line"], r["quote"], r["script"], r["basis"], r["paper"], r["got"], r["status"], r["note"]])


def esc(s):
    return s.replace("|", "\\|").replace("\n", " ")


out = ["| # | Where (section; manuscript line) | Quoted in the paper | Script (basis) | Paper value(s) | Obtained | Status | Note |",
       "|---|---|---|---|---|---|---|---|"]
for i, r in enumerate(ROWS, 1):
    q = r["quote"] if len(r["quote"]) <= 160 else r["quote"][:157] + "..."
    out.append(f"| {i} | {esc(r['sec'])}; l. {r['line']} | {esc(q)} | {esc(r['script'])} ({r['basis']}) | {esc(r['paper'])} | {esc(r['got'])} | {esc(r['status'])} | {esc(r['note'])} |")
OUT_MD.write_text("\n".join(out) + "\n", encoding="utf-8")
print(f"rows {len(ROWS)}: " + ", ".join(f"{k} {v}" for k, v in sorted(cnt.items())))
print(f"individual values: " + ", ".join(f"{k} {v}" for k, v in sorted(nnum.items())))
by_basis = {}
for r in ROWS:
    k = (r["basis"], r["status"].split(":")[0])
    by_basis[k] = by_basis.get(k, 0) + len(r["paper"].split("; "))
print("values by basis and status: " + ", ".join(f"{b}/{s} {v}" for (b, s), v in sorted(by_basis.items())))
for i, r in enumerate(ROWS, 1):
    if r["status"].startswith("MISMATCH") or "DIFFERS" in r["note"]:
        print(f"  #{i} {r['sec']}: {r['status']} {r['note']}")
