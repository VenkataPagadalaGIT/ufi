# Second independent reproduction of the v5.2 source bundle (15 October 2026)

Run by the `independent-reproducer` agent, separate from the agent that writes the paper, on
`06_MANUSCRIPT/User_First_Intelligence_v5.2_2026-10-15_source.zip` as packaged at 01:13 EDT (SHA-256
`4e917905da08d4b3e60630416c19861b6981d0c8a35ab76579491bf23fff0ba4`), from 01:15 to 01:53 EDT in a fresh scratch folder,
with nothing from the project except the zip. The agent wrote its check scripts (`checks/`), its outputs and full
numbers table (`outputs/numbers_table.tsv`) and its command log (`command_log.txt`) here; the harness did not let it
write its report file, so its summary and its list of problems are copied below from the report it returned, and the
authoring agent added what was done about each.

## Summary as returned

1. Scripts: 22 of the bundle's 52 scripts ran, none failed, 30 could not run (8 need withheld data; 22 are edit
   records that need pre-edit manuscripts). Every shipped output of a script that ran was reproduced byte for byte,
   `paper.tex` included (figure PDFs differ only in their creation timestamp), and the paper builds to a 32-page PDF
   and to DOCX.
2. Matched: 899 of 1,056 quoted numeric values (and 139 of 147 domain names and phrases) matched the reruns, the
   agent's own recomputations or the released data.
3. Mismatched: 1. Table 2's days-live column adds to 78 (6 + 31 + 30 + 11) but was labelled "77 cumulative". No
   number printed by a script differed.
4. Could not run: 156 numeric values (and 8 text values), mostly Measurement 2 (licensed review export) and the
   Section 7 sensitivities that need the raw exports. Every one agrees with its script's shipped output.
5. Most important problem: Appendix A and README.txt said every single dashboard read is released as a data file,
   but 14 quoted reads were in no released file.

## Problems found, and what was done (same day)

1. **Quoted single reads not in a released file** (the keyword counts 29,000, 58,586 and 92.3K; Semrush's 80
   referring domains, 75% on .xyz and 88% at Authority Score 0 to 10; Ahrefs' top-level-domain shares; 917 new and 95
   lost referring domains; the eight Figure 8 page counts; Domain Ratings 90, 86, 13 to 83, 87, 91 and 97; "URL Rating
   below 10"; "40 to 170 reported searches"). All added to `03_DATA/single_reads_2026-10.csv` (47 rows), with the read
   dates the paper and its Table 1 state.
2. **Measurement 2 and Figure 6 not reproducible from the bundle.** Anonymized per-label counts (no label names,
   volumes as ranks) and `m2_from_counts.py` now recompute every Section 6 correlation, branch share and interval
   that does not need the review text (34 of 35 lines of the private analysis, identical). Figure 6's panel (a) needs
   per-label volumes from the licensed export and is still not redrawable outside the project; its script now saves
   beside itself outside the project.
3. **The raw-export scripts' stop message overstated what the aggregates recompute.** Reworded: the sensitivities that
   need row-level data are in the saved outputs only.
4. **Two edit records corrupted the manuscript if rerun** (`edit_v52f.py`, `edit_v52j.py`). Every edit script now
   refuses to run twice; rerunning all of them on the final manuscript changes nothing.
5. **Table 2's days-live column.** Now "78 in all, days 0 to 77".
6. **Smaller drift.** (a) The protocol's "Reproduce" commands now give the source-bundle paths too. (b) The data
   README now says which Section 5.5 figures `analyze.py` prints and which `instrument_extra.py` prints. (c) The 37.8%
   power is computed by `instrument_extra.py`; the public `analyze.py` keeps its fixed string. (d) `r2_link_check.py`
   reads the 46,517 links and 924 matches from the released outputs instead of fixed strings. (e) The earlier tally
   (173, 136, 0, 37) is that run's own verdict table; the paper now quotes this run. (f) The 17.2% bootstrap bound is
   reported with its fixed seed; over other seeds the lower bound moves by about half a point. (g) Figure PNGs depend
   on the fonts installed; noted.

Also checked by the agent, no problem found: the timestamp proof (Bitcoin block 971,506, merkle root and time
confirmed on a block explorer), the answer counts' checksum, the code-page file (381 = 372 + 2 + 7), the platform
list, the arXiv abstract's length, Figures 1, 6 and 7 against the text, and the same numbers in the Markdown and the
LaTeX.
