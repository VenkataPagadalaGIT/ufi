# Independent reproduction, run 4: User First Intelligence, manuscript v5.2 source bundle

Reproducer: an AI agent (Claude Code), working from the released bundle only, in a fresh temporary folder, on 15 October 2026. It did not use the three earlier reproductions included in the bundle; it searched the third one's report only for the totals that Section 14 of the paper quotes from it.

## 1. Environment and bundle

- **Environment:** macOS 15.4.1 (arm64); Python 3.13.2 (Homebrew) with numpy 2.4.1, scipy 1.17.1, pandas 3.0.0, matplotlib 3.11.1 (pyparsing 3.3.2) and openpyxl 3.1.5; tectonic 0.17.0; pandoc 3.9.0.2; poppler 26.02 (pdftotext, pdfinfo, pdffonts); no XeLaTeX; no OpenTimestamps client (`outputs/environment.txt`).
- **Bundle:** `06_MANUSCRIPT/User_First_Intelligence_v5.2_2026-10-15_source.zip`, SHA-256 `1dcc4128398d5d7bb7912f492bb201310fa276dac0ae0103b98e7ce50c2c14f4` (equal to the value given by the caller; checked on the original and on the copy), 305 files.
- **Working folders** (fresh, created with `mktemp -d` in the session scratchpad, nothing else copied in): `pristine/` (never touched; its 305 SHA-256 digests were identical before and after all runs), `run/` (analysis and figure scripts), `build/` (a second fresh extraction for the paper build, so the shipped figures were used), `editrun/` (edit scripts), `mutant/` (the checker's self-test). Every script with a relative upward path resolves inside that folder, so no file of the author's project could be read.
- **Scope:** this report covers the bundle as named. During the run another process changed the project's working copy: `06_MANUSCRIPT/src/manuscript_v50.md` (03:37:45, 9 lines added and 5 removed, by a new `edit_v52t.py` that adds two citations), with new files in `06_MANUSCRIPT/measurements/`. The bundle was not changed (SHA-256 rechecked at the end) and this reproduction wrote nothing outside its own folder, so the working manuscript now differs from the one reproduced here.
- The `ufi` package (0.2.0) happens to be installed on this machine. It is not in the bundle. The three review scripts import it before they stop on the missing licensed export; no result here depends on it.

## 2. Results at a glance

- **Scripts:** 15 of the bundle's 52 paper scripts ran as documented (plus the tectonic compile); 1 failed (`protocols/reread_compare.py`); 36 cannot run (8 need withheld data or a live API, 28 edit scripts need the v4.8 manuscript, which is not in the bundle). Every one of the 7 shipped script outputs reproduced byte for byte, and every data file a script rewrote came back byte-identical.
- **Numbers:** 1,479 numbers the paper quotes from its own study were checked (1,337 numeric tokens and 142 counts or facts stated in words): **1,342 MATCH, 0 MISMATCH, 137 CANNOT RUN**. Of the 137 that cannot be run, 102 agree with the output the author shipped for the script that prints them; the other 35 have no shipped record at all. 55 figures cited from other works were not checked (listed in section 8.4).
- **Coverage:** of the 2,188 numeric tokens outside the reference list, 1,447 are checked and 741 are excluded as labels (section, table and figure numbers, years, dates and the like) by stated rules; none is left uncovered (section 8.1).
- **Build:** `build_tex.py` regenerates `paper.tex` byte for byte; tectonic 0.17 compiles it to a 34-page PDF with no errors, no missing glyphs and no undefined references; `build_docx.sh` writes a DOCX with all nine figures. Neither built file is missing any number of the source.
- **Figures:** every figure script runs; all eight regenerated PNGs are byte-identical to the shipped ones and the PDFs differ only in their `/CreationDate`. Figure 6, which needs the licensed export, cannot be redrawn; its shipped file prints +0.18 and +0.75, as the text does. The hard-coded figure data agree with the released data (14 of 14 checks).
- **Stamped protocol:** all 7 SHA-256 digests in `protocols/protocols_manifest.txt` match the released files. Its OpenTimestamps proof commits to the manifest and attests Bitcoin block 971,506, whose merkle root (7bdc6025...59a3) and time (04:05:42 UTC, 15 October 2026) a block explorer confirms.

## 3. Problems found, most important first

1. **`protocols/reread_compare.py` cannot run from the bundle (FAILED).** It reads `HERE.parents[1] / "03_DATA/instrument_divergence_ahrefs_prefixes_2026-10-12.csv"`, a project path two folders above `protocols/`; the bundle holds the same data as `data/ahrefs_prefixes_2026-10-12.csv`. Run as its docstring says (`python3 reread_compare.py`), it stops with `FileNotFoundError` before it reads the sheet. This is the comparer for the third-party re-read of Table 4 and the day-37 row that Section 14 calls the one check that would change the paper's standing, and its SHA-256 is fixed by the stamped manifest, so it cannot be corrected without breaking the stamp. A re-reader using the bundle must recreate the project layout (`03_DATA/` with the project file names) two levels above `protocols/`. The protocol's analysis step has a milder form of the same issue: it says to run `analyze.py` and `instrument_extra.py` "on the new files unchanged", but both read fixed file names (`ahrefs_prefixes_2026-10-12.csv`, `semrush_prefixes_2026-10-12.csv`), so new reads must be saved under the old names.
2. **Rounding at exact halves follows no single rule (observation, not a mismatch).** Five quoted values sit exactly on a rounding boundary (table in section 8.3). Each quoted value is a valid rounding of the exact value, but round-half-up would change four of them (82% to 83%, 5.2 to 5.3, 405.6 to 405.7, 2.1 to 2.2), round-half-even one (2.1 to 2.2), and Python's float formatting, which the scripts use, one (+0.74 to +0.73). The paper takes Python's printed value in four places and rounds the printed 0.735 up by hand in the fifth.
3. **147 of the matches cannot fail.** The monthly and checkpoint series (Tables 2, 3 and 5, and the text that quotes them) are released only as CSVs that `instrument_extra.py` writes by parsing the manuscript's own tables, and as constants in the figure scripts, typed from the same tables. The paper says so (Section 14). Their arithmetic (ratios, derived row, intervals, rates) is a real check; the read values themselves are not.
4. **137 values rest on inputs the bundle does not contain** (section 8.2): the licensed review export (Section 6), the raw Brand Radar exports (Section 7 sensitivities, the pilot, company dominance), the `ufi` repository (the parameter lock, the example's 924 queries and 4/5 and 70.4%, the commit counts) and the author's own records (cost, export times, page fetches). This is disclosed. Where the author shipped the output of the script that prints a value, the paper agrees with it in every case.
5. **Small documentation gaps.** `README.txt` says the edit scripts run from `edit_v49*.py` to `edit_v52m.py`; the bundle also holds `edit_v52n.py` to `edit_v52s.py`. The `ai_citation_cross_sector` README says the three raw-export scripts "stop with a message"; `cross_sector_sensitivity2.py` first prints its variance block (identical to the shipped output's first 760 bytes) and then stops. The proof `framework_test_r1/framework_retro_test_381_amendment_2026-10-15.md.ots` carries only pending calendar attestations, so the amendment's date cannot yet be checked against Bitcoin from the bundle (the paper says only that it was "stamped separately").

## 4. Scripts

Each script was run from its own folder exactly as its README or docstring says, from `run/` (or `build/`), with the bundle's files only. "Byte-identical" means `cmp` found no difference with the output file shipped beside the script.

| # | Script | How run (folder: command) | Status | Comparison with the shipped output |
|---|---|---|---|---|
| 1 | `data/analyze.py` | data/: `python3 analyze.py` | RAN | No shipped output file. Every printed value equals an independent recomputation from the two prefix CSVs. |
| 2 | `instrument_divergence_extra/instrument_extra.py` | instrument_divergence_extra/: `python3 instrument_extra.py` | RAN | stdout byte-identical to `instrument_extra_output.txt` (4,840 bytes); the four `instrument_series_table*.csv` it rewrites are byte-identical. |
| 3 | `protocols/instrument_extra_as_stamped.py` | protocols/: `python3 instrument_extra_as_stamped.py` | RAN | No shipped output. Its stdout equals sections 1 to 6 of the current script's, as `protocols/README.md` says; the four CSVs it writes into `protocols/` equal the released ones. |
| 4 | `protocols/reread_compare.py` | protocols/: `python3 reread_compare.py` | FAILED | `FileNotFoundError: .../run/03_DATA/instrument_divergence_ahrefs_prefixes_2026-10-12.csv` (project path, not in the bundle). Its input, a filled re-read sheet, does not exist yet either (`reread_sheet.csv` is empty by design). |
| 5 | `review_demand/m2_from_counts.py` | review_demand/: `python3 m2_from_counts.py` | RAN | Byte-identical (2,465 bytes). |
| 6 | `review_demand/r2_link_check.py` | review_demand/: `python3 r2_link_check.py` | RAN | Byte-identical (1,997 bytes). It reads two population sizes from the shipped outputs of scripts that cannot run (46,517 links; 924 of 6,620). |
| 7 | `review_demand/analyze_reviews.py` | review_demand/: `python3 analyze_reviews.py` | CANNOT RUN | Stops: `FileNotFoundError: Telecom_reviews_and_responses.xlsx` (licensed DataForSEO export, withheld; also needs `Telecom_classification.xlsx`). Shipped output used only to note agreement. |
| 8 | `review_demand/supplement_r10.py` | review_demand/: `python3 supplement_r10.py` | CANNOT RUN | Same missing export, and `Telecom_keywords_full.csv.gz` and a private carrier-name file. |
| 9 | `review_demand/r2_link_sample.py` | review_demand/: `python3 r2_link_sample.py` | CANNOT RUN | Same missing export. |
| 10 | `review_demand/make_fig_reviews_v50.py` | review_demand/: `python3 make_fig_reviews_v50.py` | CANNOT RUN | Stops: `out/label_demand_aggregates.csv` not found (written from the licensed export). |
| 11 | `stakes/vendor_reliance.py` | stakes/: `python3 vendor_reliance.py --offline` (as the README says) | RAN | Byte-identical (470 bytes). The online mode, which queries OpenAlex and rewrites the list, was not run. |
| 12 | `stakes/stakes_screen_check.py` | stakes/: `python3 stakes_screen_check.py` | RAN | Byte-identical (600 bytes). |
| 13 | `stakes/stakes_screen_sample.py` | not run | CANNOT RUN | Needs the live OpenAlex API for titles and abstracts (not released) and writes outside the bundle. Its seeded draw (`random.Random(20261015).sample` of the 456 works), replayed offline, gives exactly the 120 ids in `stakes_screen_ids.csv`. |
| 14 | `ai_citation_cross_sector/scripts/section7_from_aggregates.py` | scripts/: `python3 section7_from_aggregates.py` | RAN | Byte-identical (6,873 bytes). |
| 15 | `ai_citation_cross_sector/scripts/make_tables_sector_surface.py` | scripts/: `python3 make_tables_sector_surface.py` | RAN | Byte-identical (3,007 bytes); Tables C3 and C4 of the paper equal its output cell for cell. |
| 16 | `ai_citation_cross_sector/scripts/make_fig_sources.py` | scripts/: `python3 make_fig_sources.py` | RAN | Writes `fig10_sources.png` (byte-identical to the shipped one) and `.pdf` (identical except `/CreationDate`) beside itself. |
| 17 | `ai_citation_cross_sector/scripts/make_brand_radar_urls.py` | scripts/: `python3 make_brand_radar_urls.py` | RAN | Rewrites `design/cross_sector_report_urls.json` byte-identical; stdout (11 sectors, 9 companies in XLC) has no shipped copy. |
| 18 | `ai_citation_cross_sector/scripts/cross_sector.py` | scripts/: `python3 cross_sector.py` | CANNOT RUN | Stops with its own message: the raw Brand Radar exports are not released. |
| 19 | `ai_citation_cross_sector/scripts/cross_sector_sensitivity.py` | scripts/: `python3 cross_sector_sensitivity.py` | CANNOT RUN | Same message. |
| 20 | `ai_citation_cross_sector/scripts/cross_sector_sensitivity2.py` | scripts/: `python3 cross_sector_sensitivity2.py` | CANNOT RUN | Prints its first block from the aggregates (byte-identical to the first 760 bytes of the shipped output), then stops on the raw exports. |
| 21 | `make_figs_v4.py` | top folder: `python3 make_figs_v4.py` | RAN | Six figures: PNG byte-identical; PDF identical except `/CreationDate`. |
| 22 | `make_fig0.py` | top folder: `python3 make_fig0.py` | RAN | PNG byte-identical; PDF identical except `/CreationDate`. |
| 23 | `build_tex.py` | `build/` copy, top folder: `python3 build_tex.py` | RAN | `build/paper.tex` byte-identical to the shipped `paper.tex` (199,354 bytes). |
| 24 | (tectonic on build/paper.tex) | build/: `tectonic --keep-logs paper.tex` | RAN | 34 pages, exit 0; only box warnings (5 overfull, at most 3.98 pt; 77 underfull). No shipped PDF to compare. |
| 25 | `build_docx.sh` | top folder: `./build_docx.sh` | RAN | `build/paper.docx` with 9 embedded figures; no shipped DOCX to compare. |
| 26 | edit_v49.py, edit_v49_r9.py, edit_v49_r9b.py, edit_v49_r9c.py, edit_v50.py (5) | `editrun/` copy: `python3 <script>`, in order | CANNOT RUN | Read `manuscript_v49.md` (the v4.8 to v5.0 source), which is not in the bundle: `FileNotFoundError`. |
| 27 | edit_v50b.py to edit_v52s.py (23) | same | CANNOT RUN | Each refuses (`REFUSE: 0 matches` or `already applied`) and leaves `manuscript_v50.md` unchanged, as expected for a record of edits already applied; the chain cannot be replayed without the v4.8 source. |
| 28 | 08_REVIEW/*/checks/* (28 files) | not run | not a paper script | Tooling of the three earlier reproductions; some carry absolute paths of their own work folders. Out of scope. |

Tally: RAN 15 scripts (rows 1 to 3, 5, 6, 11, 12, 14 to 17, 21 to 23, 25) plus the compile; FAILED 1; CANNOT RUN 36 (8 data or API, 28 edit scripts).

## 5. Build and figures

- `paper.tex`: regenerated byte for byte by `build_tex.py` (pandoc 3.9.0.2). The compile used tectonic because XeLaTeX is not installed; `build_tex.py` itself falls back to tectonic for its table-measuring pass, which succeeded.
- Built PDF: 34 pages, letter size, all 20 fonts embedded (`outputs/built_paper_pdffonts.txt`), no `Missing character` lines, no undefined references or citations. Every number in the source occurs at least as often in the built PDF's text (2,927 numeric tokens against 2,577; the surplus is page numbers, running heads and figure text; 0 numbers short) and in the DOCX's text (2,577 against 2,577; 0 short) (`outputs/md_vs_built.txt`).
- Figure comparison (`outputs/compare_figures.txt`):
  - `fig0_framework` (make_fig0.py): PNG byte-identical; PDF identical except the creation timestamp
  - `fig1_divergence` (make_figs_v4.py): PNG byte-identical; PDF identical except the creation timestamp
  - `fig2_aio` (make_figs_v4.py): PNG byte-identical; PDF identical except the creation timestamp
  - `fig3_refdomains` (make_figs_v4.py): PNG byte-identical; PDF identical except the creation timestamp
  - `fig4_prefixes` (make_figs_v4.py): PNG byte-identical; PDF identical except the creation timestamp
  - `fig5_cited` (make_figs_v4.py): PNG byte-identical; PDF identical except the creation timestamp
  - `fig6_positions` (make_figs_v4.py): PNG byte-identical; PDF identical except the creation timestamp
  - `fig10_sources` (make_fig_sources.py): PNG byte-identical; PDF identical except the creation timestamp
  - `fig9_reviews` (Figure 6): not regenerable (`make_fig_reviews_v50.py` needs the licensed export); its shipped PDF prints "1,008 taxonomy labels, Spearman +0.18" and "(nine of 17), Spearman +0.75", as the paper does.
- Figure data against released data (`outputs/figure_check.txt`): 14 of 14 figure checks OK.

## 6. Stamped protocol and timestamps

    manifest lines with a SHA-256: 7
      MATCH    09_SUBMISSION/author_tasks/second_domain_protocol.md -> protocols/second_domain_protocol.md
      MATCH    09_SUBMISSION/author_tasks/second_read_template.csv -> protocols/second_read_template.csv
      MATCH    09_SUBMISSION/author_tasks/second_domain_template.csv -> protocols/second_domain_template.csv
      MATCH    09_SUBMISSION/author_tasks/reread_sheet.csv -> protocols/reread_sheet.csv
      MATCH    09_SUBMISSION/author_tasks/reread_compare.py -> protocols/reread_compare.py
      MATCH    04_ANALYSIS/instrument_divergence/release_data/analyze.py -> data/analyze.py
      MATCH    04_ANALYSIS/instrument_divergence/instrument_extra.py -> protocols/instrument_extra_as_stamped.py
    7 of 7 match
    current instrument_divergence_extra/instrument_extra.py d2d2b1be0d82d5eef38ddea21e5e34ce046a135463450b06aa104224ebc15ee2: differs from the stamped digest (README: it gained sections 7 to 9)
    other files in protocols/: ['README.md', 'protocols_manifest.txt', 'protocols_manifest.txt.ots']

OpenTimestamps proofs, parsed offline (`check_scripts/ots_parse.py`, `outputs/ots_parse.txt`):

- `protocols/protocols_manifest.txt.ots`: commits to SHA-256 `e52d0565...d67a`, which is the manifest's; one Bitcoin attestation, block 971,506, merkle root (explorer byte order) `7bdc60257b41068f09d1157f28005268d7430ba65143d263243a5d46a24659a3`, plus four pending calendar attestations.
- `framework_test_r1/framework_retro_test_381_manifest.txt.ots`: commits to the manifest's SHA-256; same block and merkle root.
- `framework_test_r1/framework_retro_test_381_amendment_2026-10-15.md.ots`: commits to the amendment's SHA-256; pending calendar attestations only.
- Block explorer (blockstream.info, the check `protocols/README.md` prescribes): block 971,506 has merkle root 7bdc60257b41068f09d1157f28005268d7430ba65143d263243a5d46a24659a3 (equal to the proofs') and block time 2026-10-15 04:05:42 UTC (`outputs/block_explorer_check.txt`).
- The manifests were written at 03:45 and 03:48 UTC; the block was mined at 04:05:42 UTC. The Study R1 files themselves are held back, so only the manifest can be checked.

## 7. Other checks

- `arxiv_abstract.txt`: 1,907 characters, under the 1,920 that `README.txt` states; every number in it appears in the manuscript's abstract (it omits −0.11 and the read date).
- `UFI_Metrics_and_Evaluation_Protocol_v1.0.pdf` against its `.md`: the same numbers (the one apparent difference, a DOI `30.1-2.81`, is a line-break hyphen that text extraction drops).
- `ai_citation_cross_sector/README.md`'s note on YouTube's rank where it is not cited (825 for Utilities on ChatGPT): confirmed in the aggregates; the ChatGPT and Copilot medians (151, 161) are the same under either reading.
- Rerun outputs written into the run copy, and nothing else: figure files, the four protocol CSVs, `fig10_sources.*` beside its script, and an empty `review_demand/out/` made by `analyze_reviews.py` before it stopped.

## 8. Numbers

### 8.1 Method

`check_scripts/check_numbers.py` holds one entry for every number the paper quotes from its own study, line by line through the manuscript (`manuscript_v50.md`, the bundle's source of truth), including Tables 2 to 7, C1 and C2 cell by cell and counts written in words ("nineteen", "one fifth"). Each value was compared at the precision the paper prints with the most precise value available: an independent recomputation from the released data where possible (prefix CSVs, aggregates, anonymized label counts, judgment CSVs, the single-read and code-list files), the rerun script's output otherwise, and the full-precision value wherever the script's printed value ends in 5 at the next digit (`check_scripts/m2_precise.py`, `m2_boundary.py`). A value matches when it equals the full-precision value rounded half-up; a value exactly on the boundary is accepted either way and flagged. `check_scripts/coverage.py` then extracts every numeric token from the manuscript (the reference list excepted) and requires each to be checked or excluded by a stated rule:

    numeric tokens outside the reference list: 2188; claimed 1447; excluded as labels 741; uncovered 0
    labels by rule: reference to a section/table/figure/version 305, year 183, day number 67, date 55, heading 45, enumeration 27, band definition 26, confidence level 14, time 12, name (S&P 500, path) 7

The excluded tokens are section, table and figure numbers, citation years, dates and day numbers used as names, times, enumerations, confidence levels ("95%"), position-band names and "S&P 500"; `outputs/label_audit.txt` lists every date, day, band, time and enumeration exclusion for review, and none hides a quantity. The checker was tested: on known cases (`outputs/mutation_unit_test.txt`, 12 of 12) and on a copy of the manuscript with five numbers altered, all five were caught (`outputs/mutation_end_to_end.txt`: four as MISMATCH, the fifth by the coverage check).

### 8.2 Tally

| Section | MATCH | MISMATCH | CANNOT RUN |
|---|---|---|---|
| Abstract | 24 | 0 | 3 |
| 1 Introduction | 15 | 0 | 0 |
| 1.1 Why a new section is the right instrument | 4 | 0 | 0 |
| 1.2 What this paper reports | 20 | 0 | 2 |
| 1.3 What this paper does not report | 2 | 0 | 0 |
| 2 Related work | 2 | 0 | 0 |
| 3 Setting | 25 | 0 | 3 |
| 3.1 Six conditions that make this deployment unrepresentative | 6 | 0 | 0 |
| 4.1 Instruments, definitions and denominators | 22 | 0 | 0 |
| 4.3 The primary checkpoint | 5 | 0 | 0 |
| 5.1 Estimated visits: a divergence of 7.5x to 27.1x on one prefix | 53 | 0 | 0 |
| 5.2 Ranking keywords: a factor of two, and three like for like | 8 | 0 | 0 |
| 5.3 AI answers and AI Overviews: two definitions, converging | 47 | 0 | 0 |
| 5.4 Referring domains: 11.4x, and disagreement about composition | 22 | 0 | 0 |
| 5.5 Twelve prefixes on one domain: the divergence is prefix-specific, with no detectable relationship to age | 237 | 0 | 0 |
| 5.6 What follows for applied search research | 39 | 0 | 0 |
| 6 Measurement 2: reviews against keyword volume on one taxonomy | 64 | 0 | 42 |
| 7.1 Pilot | 5 | 0 | 9 |
| 7.2 Design | 21 | 0 | 2 |
| 7.3 Results | 64 | 0 | 9 |
| 7.4 The predictions written before collection | 23 | 0 | 5 |
| 7.5 Sensitivity | 4 | 0 | 22 |
| 7.6 Limits | 27 | 0 | 3 |
| 8 The deployment series | 98 | 0 | 0 |
| 9.1 Enumerating pages are cited more often than any single code page | 14 | 0 | 0 |
| 9.2 Who else is cited, and what that does not establish | 10 | 0 | 0 |
| 10 The link profile | 27 | 0 | 0 |
| 10.1 What the link profile can and cannot explain | 55 | 0 | 0 |
| 11.1 Cost | 0 | 0 | 5 |
| 11.2 Six lessons, stated as this deployment's failures | 1 | 0 | 1 |
| 12 Threats to validity | 9 | 0 | 0 |
| 13 What would test what this paper declines to claim | 12 | 0 | 5 |
| 13.1 Further directions | 2 | 0 | 0 |
| 14 Reproducibility, ethics and conflicts of interest | 22 | 0 | 3 |
| 15 Conclusion | 21 | 0 | 4 |
| Appendix A: Corrections across versions | 16 | 0 | 2 |
| Appendix B: The Content Gap Score, as a specification | 0 | 0 | 10 |
| Appendix C: Section 7 by source type and cell | 244 | 0 | 0 |
| Appendix D: Metrics, values and scripts | 72 | 0 | 7 |
| **All** | **1,342** | **0** | **137** |

CANNOT RUN, by missing input:

- 57: licensed review export (Section 6) not in the bundle
- 46: raw Brand Radar exports (Section 7) not in the bundle
- 22: ufi repository or package (lock, example, commits) not in the bundle
- 12: author's reconstruction or unreleased records (cost, export log, page fetch, registry)

Of the 1,342 matches, 147 rest only on records transcribed from the manuscript itself (problem 3).

### 8.3 Values on a rounding boundary

Exact values from `outputs/rounding_boundaries.txt` (computed with rational arithmetic from the released data):

| Where | Exact value | Quoted | Half-up | Half-even | Python format |
|---|---|---|---|---|---|
| Section 1 and Table D1: screen sample using vendor figures, annotator 1 (99/120) | 82.5% | 82% | 83% | 82% | 82% |
| Table 4: /device-compare/ keyword ratio (12,600 / 2,400) | 5.25 | 5.2 | 5.3 | 5.2 | 5.2 |
| Table C2: Information Technology, Copilot (405,650 incidences, in thousands) | 405.65 | 405.6 | 405.7 | 405.6 | 405.6 |
| Table C2: Real Estate, Gemini (2,150 incidences, in thousands) | 2.15 | 2.1 | 2.2 | 2.2 | 2.1 |
| Section 6: lower end of the multi-word branch-level interval (Sxy/sqrt(Sxx Syy) = 294/400) | 0.735 | +0.74 | 0.74 | 0.74 | 0.73 |

### 8.4 Figures cited from other works (not checked)

| # | Line | Quoted | Source cited |
|---|---|---|---|
| 71 | 77 | 25 | Langridge 2016; reference entry says 25 sites |
| 72 | 77 | 17% | Langridge 2016 |
| 73 | 77 | 30% | Langridge 2016 |
| 74 | 77 | 1,635 | Soulo 2022; reference entry says 1,635 sites |
| 75 | 77 | 49.5% | Soulo 2022 |
| 76 | 77 | 68.4% | Soulo 2022 |
| 77 | 77 | 0.76 | Soulo 2022 |
| 78 | 77 | 0.74 | Soulo 2022 |
| 79 | 77 | 18 | Kamerer 2013 |
| 80 | 77 | 86 | Jansen, Jung & Salminen 2022; reference title says 86 websites |
| 81 | 77 | 50 | Rasool, Thakur & Nabi 2026 |
| 82 | 77 | 4% | Rasool, Thakur & Nabi 2026 |
| 83 | 77 | 0.997 | Rasool, Thakur & Nabi 2026 |
| 84 | 77 | 7% | Zhao & Berman 2025 |
| 85 | 81 | 55,393 | Xu, Iqbal & Montgomery 2026 |
| 86 | 81 | 30% | Xu et al. 2026 |
| 87 | 81 | 15,000 | Linehan & Guan 2025; reference entry says 15,000 prompts |
| 88 | 81 | 12% | Linehan & Guan 2025; reference title says 12% |
| 89 | 81 | 28.6% | Linehan & Guan 2025 |
| 90 | 81 | 1% | Chapekis & Lieb 2025 |
| 91 | 81 | 45 | Martinez 2026 |
| 92 | 81 | 366,000 | Yang 2025 |
| 93 | 81 | 11,000 | Huang et al. 2026 |
| 94 | 81 | 712 | Allaham & Diakopoulos 2026 |
| 95 | 81 | 16% | Allaham & Diakopoulos 2026 |
| 96 | 81 | 480 | Hendricks 2026 |
| 97 | 81 | 6,095,520 | OtterlyAI 2026; reference entry says 6,095,520 |
| 98 | 81 | 17 | OtterlyAI 2026 |
| 99 | 81 | 31% | Tinuiti 2026 |
| 100 | 81 | 7% | Tinuiti 2026 |
| 101 | 81 | 19.4% | Punturo et al. 2026 |
| 102 | 81 | 5.3% | Punturo et al. 2026 |
| 103 | 81 | 15 | Punturo et al. 2026 |
| 104 | 81 | 86% | Yext 2025; reference title says 86% |
| 105 | 81 | 100,000 | Kumar 2026; literature README agrees |
| 106 | 81 | 100 | Kumar 2026 |
| 107 | 81 | 78% | Kumar 2026; literature/novelty_search_2026-10-14/README.md says about 78% |
| 108 | 81 | 23 | Romero Ramos et al. 2026; literature README says 23 studies |
| 109 | 83 | 11.7% | Hannak et al. 2013 |
| 721 | 307 | 282 | vendor documentation (Bek 2026) |
| 722 | 307 | 24 | vendor documentation (Bek 2026) |
| 723 | 307 | 13 | vendor documentation (Bek 2026) |
| 724 | 307 | 15 | vendor documentation (Bek 2026) |
| 725 | 307 | 90 | vendor documentation (Bek 2026) |
| 886 | 329 | 19.4% | Punturo et al. 2026; same figure as Section 2 |
| 887 | 329 | 31% | Tinuiti 2026; same figure as Section 2 |
| 1131 | 482 | 21% | Gottfried & Park 2025 |
| 1132 | 482 | 37% | Gottfried & Park 2025 |
| 1133 | 482 | 18% | Gottfried & Park 2025 |
| 1134 | 482 | 26% | Gottfried & Park 2025 |
| 1136 | 486 | 93.9 | Costco Wholesale Corporation 2026 press release |
| 1137 | 486 | 11.2% | Costco Wholesale Corporation 2026 press release |
| 1212 | 712 | 12,000 | Wulczyn et al. 2016 |
| 1213 | 712 | 3.2 | Wulczyn et al. 2016 |
| 1214 | 712 | 80% | Piccardi et al. 2018 |

### 8.5 Every checked number

Line numbers refer to `manuscript_v50.md` in the bundle; `outputs/numbers_table.tsv` has the same rows with the surrounding text. "Obtained" is the full-precision value in the unit the paper prints (percent values as percentages). Sources: `rerun` a script run here; `data` a released file; `arith` arithmetic on released files; `shipped` an output the author shipped for a script that cannot run.

| # | Line | Section | Quoted | Status | Obtained | Source | Note |
|---|---|---|---|---|---|---|---|
| 1 | 14 | Abstract | 381 | MATCH | 381 | data section_code_pages_2026-10-14.csv (rows) |  |
| 2 | 14 | Abstract | 53 | MATCH | 53 | arith 52 registry locations in the released code list (one state hub each) + the nation... | the hub list itself is not released |
| 3 | 14 | Abstract | 7.5x | MATCH | 7.46965 | arith Table 2 values (released series CSV, transcribed from the manuscript); Semrush US... |  |
| 4 | 14 | Abstract | 27.1x | MATCH | 27.1414 | arith Table 2 values (released series CSV, transcribed from the manuscript); highest month |  |
| 5 | 14 | Abstract | 8.6x | MATCH | 8.62011 | arith Table 2 values (released series CSV, transcribed from the manuscript); worldwide ... |  |
| 6 | 14 | Abstract | 29.9x | MATCH | 29.8608 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 7 | 14 | Abstract | 0.20x | MATCH | 0.203125 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 8 | 14 | Abstract | 7.24x | MATCH | 7.23982 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 9 | 14 | Abstract | −0.11 | MATCH | -0.112084 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 10 | 14 | Abstract | 60 | MATCH | 60 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 11 | 14 | Abstract | 66 | MATCH | 66 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 12 | 14 | Abstract | 9 | MATCH | 9 | rerun instrument_extra.py (byte-identical to shipped output); pairs within a factor of ... |  |
| 13 | 14 | Abstract | 15 | MATCH | 15 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 14 | 14 | Abstract | 37,193 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 15 | 14 | Abstract | 378 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 16 | 14 | Abstract | 42,994 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 17 | 14 | Abstract | +0.47 | MATCH | 0.468137 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 18 | 14 | Abstract | +0.75 | MATCH | 0.747549 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 19 | 14 | Abstract | +0.18 | MATCH | 0.184869 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... | full precision 0.18487 |
| 20 | 14 | Abstract | about two-thirds correct | MATCH | 131/196, 130/200 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 21 | 14 | Abstract | 21% | MATCH | 21.3411 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 22 | 14 | Abstract | 0.6% | MATCH | 0.558 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 23 | 14 | Abstract | 9.2% | MATCH | 9.2146 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 24 | 14 | Abstract | twelve sections | MATCH | 12 | data two prefix CSVs |  |
| 25 | 14 | Abstract | one held, one held in direction only and two failed | MATCH | P1 fails, P2 holds, P3 fails, P4 dire... | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 26 | 14 | Abstract | lowest Google figure above the highest of the other four in every s... | MATCH | 11/11 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 27 | 14 | Abstract | ten largest holdings of each sector fund | MATCH | 10 per fund, 9 companies in XLC | data design/cross_sector_companies.csv |  |
| 28 | 22 | 1 Introduction | 456 | MATCH | 456 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 29 | 22 | 1 Introduction | 27 | MATCH | 27 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 30 | 22 | 1 Introduction | 87 | MATCH | 87 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 31 | 22 | 1 Introduction | 110 | MATCH | 110 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 32 | 22 | 1 Introduction | 120 | MATCH | 120 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 33 | 22 | 1 Introduction | a random sample of 120 of them (seed 20261015) | MATCH | offline replay of the draw = released... | check:random.Random(20261015).sample of the 456 deduplicated works vs stakes/stakes_scr... | stakes_screen_sample.py itself needs the live OpenAlex API |
| 34 | 22 | 1 Introduction | 82% | MATCH | 82.5 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... | 99/120 = 82.5% exactly; 82% is the round-half-to-even reading (the script prints 82%); full-precision value... |
| 35 | 22 | 1 Introduction | 87% | MATCH | 86.6667 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 36 | 22 | 1 Introduction | 75% | MATCH | 74.7241 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 37 | 22 | 1 Introduction | 92% | MATCH | 91.6235 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 38 | 22 | 1 Introduction | 0.63 | MATCH | 0.631336 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 39 | 22 | 1 Introduction | 87% | MATCH | 86.8687 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 40 | 22 | 1 Introduction | 88% | MATCH | 87.5 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... | full-precision value lies exactly on the rounding boundary |
| 41 | 22 | 1 Introduction | five to seven compare vendors | MATCH | 7 and 5 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 42 | 22 | 1 Introduction | an independent search of five databases | MATCH | OpenAlex, Crossref, arXiv, Semantic S... | data literature/novelty_search_scout_2026-10-15/README.md |  |
| 43 | 32 | 1.1 Why a new section is ... | 381 | MATCH | 381 | data section_code_pages_2026-10-14.csv |  |
| 44 | 32 | 1.1 Why a new section is ... | 77 | MATCH | 77 | arith 26 July to 11 October 2026 |  |
| 45 | 32 | 1.1 Why a new section is ... | seven checkpoints | MATCH | Table 5 columns other than day 37 (or... | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | Table 5 has eight dated columns; seven of them carry the other quantities in full or nearly; reading accepted |
| 46 | 34 | 1.1 Why a new section is ... | thirteen demand-surface types | MATCH | 13 | data make_fig0.py surface lists (10 first-party + 3 tool-derived) |  |
| 47 | 38 | 1.2 What this paper reports | 30 | MATCH | 29.8608 | arith Table 2 values (released series CSV, transcribed from the manuscript) | approximate wording, accepted within 5% |
| 48 | 38 | 1.2 What this paper reports | 33 | MATCH | 33.3024 | arith Table 2 values (released series CSV, transcribed from the manuscript); US to US, ... | approximate wording, accepted within 5% |
| 49 | 42 | 1.2 What this paper reports | 7.5x | MATCH | 7.46965 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 50 | 42 | 1.2 What this paper reports | 27.1x | MATCH | 27.1414 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 51 | 42 | 1.2 What this paper reports | 8.6x | MATCH | 8.62011 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 52 | 42 | 1.2 What this paper reports | 29.9x | MATCH | 29.8608 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 53 | 42 | 1.2 What this paper reports | 0.20x | MATCH | 0.203125 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 54 | 42 | 1.2 What this paper reports | 7.24x | MATCH | 7.23982 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 55 | 42 | 1.2 What this paper reports | 60 | MATCH | 60 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 56 | 42 | 1.2 What this paper reports | 66 | MATCH | 66 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 57 | 43 | 1.2 What this paper reports | 37,193 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 58 | 43 | 1.2 What this paper reports | 42,994 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 59 | 44 | 1.2 What this paper reports | 21.3% | MATCH | 21.3411 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 60 | 44 | 1.2 What this paper reports | 2.1% | MATCH | 2.06095 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 61 | 44 | 1.2 What this paper reports | about ten times | MATCH | 10.355 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 62 | 44 | 1.2 What this paper reports | in every sector | MATCH | 11/11 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 63 | 46 | 1.2 What this paper reports | 77 | MATCH | 77 | arith day 0 = 26 July 2026 to 11 October 2026 |  |
| 64 | 46 | 1.2 What this paper reports | 1.2 | MATCH | 1.23529 | data single_reads_2026-10.csv; least-cited of the five hubs / most-cited code page (294... |  |
| 65 | 46 | 1.2 What this paper reports | 2.0 | MATCH | 1.9916 | data single_reads_2026-10.csv; 474/238 |  |
| 66 | 46 | 1.2 What this paper reports | five most-cited hub pages | MATCH | 294 > 238 | data single_reads_2026-10.csv |  |
| 67 | 46 | 1.2 What this paper reports | six enabling conditions | MATCH | 6 | manuscript Section 3.1 list |  |
| 68 | 46 | 1.2 What this paper reports | six lessons | MATCH | 6 | manuscript Section 11.2 list |  |
| 69 | 54 | 1.3 What this paper does ... | 90 | MATCH | 90 | data single_reads_2026-10.csv |  |
| 70 | 54 | 1.3 What this paper does ... | 86 | MATCH | 86 | data single_reads_2026-10.csv |  |
| 110 | 85 | 2 Related work | 381 | MATCH | 381 | data section_code_pages_2026-10-14.csv |  |
| 111 | 85 | 2 Related work | 29,000 | MATCH | 29000 | data single_reads_2026-10.csv |  |
| 112 | 95 | 3 Setting | 52 | MATCH | 52 | data section_code_pages_2026-10-14.csv; the section's 52 state hubs = 52 registry locat... |  |
| 113 | 95 | 3 Setting | 381 | MATCH | 381 | data section_code_pages_2026-10-14.csv |  |
| 114 | 95 | 3 Setting | 374 | MATCH | 374 | data section_code_pages_2026-10-14.csv; geographic codes |  |
| 115 | 95 | 3 Setting | 372 | MATCH | 372 | data section_code_pages_2026-10-14.csv |  |
| 116 | 95 | 3 Setting | two assigned but not yet in service | MATCH | ['565', '761'] | data section_code_pages_2026-10-14.csv |  |
| 117 | 95 | 3 Setting | 7 | MATCH | 7 | data section_code_pages_2026-10-14.csv; toll-free |  |
| 118 | 95 | 3 Setting | 52 | MATCH | 52 | data section_code_pages_2026-10-14.csv; distinct registry locations |  |
| 119 | 95 | 3 Setting | 50 | MATCH | 50 | data section_code_pages_2026-10-14.csv; states among the locations (with DC and 'NANP A... |  |
| 120 | 95 | 3 Setting | 381 | MATCH | 381 | data section_code_pages_2026-10-14.csv; the 14 October re-fetch |  |
| 121 | 95 | 3 Setting | 381 | CANNOT RUN |  | fetch results (HTTP status, canonical tags) not released | All 381 return HTTP 200 ... |
| 122 | 95 | 3 Setting | 200 | CANNOT RUN |  | fetch results not released |  |
| 123 | 95 | 3 Setting | six assigned to US territories | CANNOT RUN |  | the numbering-plan registry extract is not released (it is in the Study R1 manifest only) |  |
| 124 | 95 | 3 Setting | 451 | MATCH | 451 absent from the released code list | data section_code_pages_2026-10-14.csv | its assignment date (15 September 2026) needs the unreleased registry |
| 125 | 97 | 3 Setting | 210 | MATCH | 210 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 126 | 97 | 3 Setting | 365 | MATCH | 365 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 127 | 97 | 3 Setting | 391 | MATCH | 391 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 128 | 97 | 3 Setting | 414 | MATCH | 414 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 129 | 97 | 3 Setting | 440 | MATCH | 440 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 130 | 97 | 3 Setting | 434 | MATCH | 434 | arith 381 code pages + 53 hubs |  |
| 131 | 99 | 3 Setting | 381 | MATCH | 381 | data section_code_pages_2026-10-14.csv |  |
| 132 | 99 | 3 Setting | 441 | MATCH | 441 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 133 | 99 | 3 Setting | 381 | MATCH | 381 | data section_code_pages_2026-10-14.csv |  |
| 134 | 99 | 3 Setting | 53 | MATCH | 53 | arith 52 locations + national hub |  |
| 135 | 99 | 3 Setting | exceeds 381 plus the 53 hub pages by seven | MATCH | 7 | arith 441 - 434 |  |
| 136 | 99 | 3 Setting | 455 | MATCH | 455 | data single_reads_2026-10.csv |  |
| 137 | 99 | 3 Setting | 434 | MATCH | 434 | arith |  |
| 138 | 99 | 3 Setting | 21 | MATCH | 21 | arith 455 - 434 |  |
| 139 | 99 | 3 Setting | day 0 = 26 July 2026 | MATCH | 2026-07-26 | definition; consistent with Table 5 header |  |
| 140 | 108 | 3.1 Six conditions that m... | 90 | MATCH | 90 | data single_reads_2026-10.csv |  |
| 141 | 108 | 3.1 Six conditions that m... | 86 | MATCH | 86 | data single_reads_2026-10.csv |  |
| 142 | 109 | 3.1 Six conditions that m... | 87 | MATCH | 87 and 91 | data single_reads_2026-10.csv |  |
| 143 | 109 | 3.1 Six conditions that m... | 91 | MATCH | 87 and 91 | data single_reads_2026-10.csv |  |
| 144 | 110 | 3.1 Six conditions that m... | 13 | MATCH | 13 to 83 | data single_reads_2026-10.csv |  |
| 145 | 110 | 3.1 Six conditions that m... | 83 | MATCH | 13 to 83 | data single_reads_2026-10.csv |  |
| 146 | 125 | 4.1 Instruments, definiti... | 11 | MATCH | 2026-10-11 | data single_reads_2026-10.csv (read date) |  |
| 147 | 125 | 4.1 Instruments, definiti... | 10 | MATCH | 2026-10-10 | data single_reads_2026-10.csv (read date) |  |
| 148 | 125 | 4.1 Instruments, definiti... | 12 | MATCH | 2026-10-12 | data single_reads_2026-10.csv (read date) |  |
| 149 | 131 | 4.1 Instruments, definiti... | 10 | MATCH | 2026-10-10 | data single_reads_2026-10.csv (read date) |  |
| 150 | 131 | 4.1 Instruments, definiti... | 12 | MATCH | 2026-10-12 | data single_reads_2026-10.csv (read date) |  |
| 151 | 132 | 4.1 Instruments, definiti... | 11 | MATCH | 2026-10-11 | data single_reads_2026-10.csv (read date) |  |
| 152 | 133 | 4.1 Instruments, definiti... | 2015 | MATCH | 2015-09 | data ahrefs_prefixes CSV, earliest first-traffic month |  |
| 153 | 133 | 4.1 Instruments, definiti... | 12 | MATCH | 2026-10-12 | data ahrefs_prefixes CSV read_date |  |
| 154 | 134 | 4.1 Instruments, definiti... | 12 | MATCH | 2026-10-12 | data ahrefs_prefixes CSV read_date |  |
| 155 | 137 | 4.1 Instruments, definiti... | 1,000 | MATCH | export_rows = 1000 in all 88 cells | data aggregates/cross_sector_cells.csv |  |
| 156 | 137 | 4.1 Instruments, definiti... | 12 | MATCH | answer counts read 2026-10-13 01:10-0... | data design file and sector_answer_counts.csv |  |
| 157 | 137 | 4.1 Instruments, definiti... | 13 | MATCH | 2026-10-13 | data sector_answer_counts.csv |  |
| 158 | 145 | 4.1 Instruments, definiti... | 105 | MATCH | 105 | data single_reads_2026-10.csv |  |
| 159 | 145 | 4.1 Instruments, definiti... | 18.5% | MATCH | 18.5 | data single_reads_2026-10.csv |  |
| 160 | 145 | 4.1 Instruments, definiti... | 18.6% | MATCH | 18.6 | data ahrefs_prefixes CSV, 1 - US share of /local/area-codes/ (0.814) |  |
| 161 | 145 | 4.1 Instruments, definiti... | 7.5 | MATCH | 7.46965 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 162 | 145 | 4.1 Instruments, definiti... | 27.1 | MATCH | 27.1414 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 163 | 145 | 4.1 Instruments, definiti... | 8.6x | MATCH | 8.62011 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 164 | 145 | 4.1 Instruments, definiti... | 29.9x | MATCH | 29.8608 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 165 | 145 | 4.1 Instruments, definiti... | 9.2x | MATCH | 9.16521 | arith Table 2 values (released series CSV, transcribed from the manuscript) with the 81... |  |
| 166 | 145 | 4.1 Instruments, definiti... | 33.3x | MATCH | 33.3024 | arith Table 2 values (released series CSV, transcribed from the manuscript) with the 81... |  |
| 167 | 145 | 4.1 Instruments, definiti... | 81.5% | MATCH | 81.5 | data single_reads_2026-10.csv | also 100% - 18.5% |
| 168 | 155 | 4.3 The primary checkpoint | 24 September, day 60 | MATCH | 2026-09-24 | arith 26 July + 60 days |  |
| 169 | 155 | 4.3 The primary checkpoint | 29 September, day 65 | MATCH | 2026-09-29 | arith 26 July + 65 days |  |
| 170 | 155 | 4.3 The primary checkpoint | days 65 to 75 | MATCH | 2026-10-09 | arith notice period ends at the last daily read (9 October) |  |
| 172 | 157 | 4.3 The primary checkpoint | Day 37 (1 September 2026) | MATCH | 2026-09-01 | arith 26 July + 37 days |  |
| 173 | 157 | 4.3 The primary checkpoint | four of the nine quantities | MATCH | 4 of 9 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 174 | 163 | 5.1 Estimated visits: a d... | 7.5x | MATCH | 7.46965 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 175 | 163 | 5.1 Estimated visits: a d... | 27.1x | MATCH | 27.1414 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 176 | 165 | 5.1 Estimated visits: a d... | 81.5% | MATCH | 81.5 | data single_reads_2026-10.csv |  |
| 177 | 165 | 5.1 Estimated visits: a d... | 11 | MATCH | 2026-10-11 | data single_reads_2026-10.csv (read on 11 October) |  |
| 178 | 169 | 5.1 Estimated visits: a d... | 0 | MATCH | 0 | June days live, data instrument_series_table2 CSV (transcribed) |  |
| 179 | 169 | 5.1 Estimated visits: a d... | 0 | MATCH | 0 | June Ahrefs visits, data instrument_series_table2 CSV (transcribed) |  |
| 180 | 169 | 5.1 Estimated visits: a d... | 0 | MATCH | 0 (0) | June Semrush US visits, data instrument_series_table2 CSV (transcribed) |  |
| 181 | 169 | 5.1 Estimated visits: a d... | 0 | MATCH | 0 (0) | June Semrush worldwide visits, data instrument_series_table2 CSV (transcribed) |  |
| 182 | 170 | 5.1 Estimated visits: a d... | 6 | MATCH | 6 | arith calendar days live in the month (launch 26 July; October read on day 77, 11 October) |  |
| 183 | 170 | 5.1 Estimated visits: a d... | 3,862 | MATCH | 3862 | data instrument_series_table2 CSV and instrument_extra.py constants (both transcribed) |  |
| 184 | 170 | 5.1 Estimated visits: a d... | 100,012 | MATCH | 100,012.0 | data instrument_series_table2 CSV and instrument_extra.py constants (both transcribed) |  |
| 185 | 170 | 5.1 Estimated visits: a d... | 103,045 | MATCH | 103,045.0 | data instrument_series_table2 CSV and instrument_extra.py constants (both transcribed) |  |
| 186 | 170 | 5.1 Estimated visits: a d... | 25.9x | MATCH | 25.8964 | arith Semrush US / Ahrefs worldwide |  |
| 187 | 170 | 5.1 Estimated visits: a d... | 26.7x | MATCH | 26.6818 | arith Semrush worldwide / Ahrefs worldwide |  |
| 188 | 170 | 5.1 Estimated visits: a d... | 31.8x | MATCH | 31.7748 | arith Semrush US / (Ahrefs worldwide x 81.5%) |  |
| 189 | 171 | 5.1 Estimated visits: a d... | 31 | MATCH | 31 | arith calendar days live in the month (launch 26 July; October read on day 77, 11 October) |  |
| 190 | 171 | 5.1 Estimated visits: a d... | 32,281 | MATCH | 32281 | data instrument_series_table2 CSV and instrument_extra.py constants (both transcribed) |  |
| 191 | 171 | 5.1 Estimated visits: a d... | 876,153 | MATCH | 876,153.0 | data instrument_series_table2 CSV and instrument_extra.py constants (both transcribed) |  |
| 192 | 171 | 5.1 Estimated visits: a d... | 963,937 | MATCH | 963,937.0 | data instrument_series_table2 CSV and instrument_extra.py constants (both transcribed) |  |
| 193 | 171 | 5.1 Estimated visits: a d... | 27.1x | MATCH | 27.1414 | arith Semrush US / Ahrefs worldwide |  |
| 194 | 171 | 5.1 Estimated visits: a d... | 29.9x | MATCH | 29.8608 | arith Semrush worldwide / Ahrefs worldwide |  |
| 195 | 171 | 5.1 Estimated visits: a d... | 33.3x | MATCH | 33.3024 | arith Semrush US / (Ahrefs worldwide x 81.5%) |  |
| 196 | 172 | 5.1 Estimated visits: a d... | 30 | MATCH | 30 | arith calendar days live in the month (launch 26 July; October read on day 77, 11 October) |  |
| 197 | 172 | 5.1 Estimated visits: a d... | 150,113 | MATCH | 150,113.0 | data instrument_series_table2 CSV and instrument_extra.py constants (both transcribed) |  |
| 198 | 172 | 5.1 Estimated visits: a d... | 1,534,362 | MATCH | 1,534,362.0 | data instrument_series_table2 CSV and instrument_extra.py constants (both transcribed) |  |
| 199 | 172 | 5.1 Estimated visits: a d... | 1,765,077 | MATCH | 1,765,077.0 | data instrument_series_table2 CSV and instrument_extra.py constants (both transcribed) |  |
| 200 | 172 | 5.1 Estimated visits: a d... | 10.2x | MATCH | 10.2214 | arith Semrush US / Ahrefs worldwide |  |
| 201 | 172 | 5.1 Estimated visits: a d... | 11.8x | MATCH | 11.7583 | arith Semrush worldwide / Ahrefs worldwide |  |
| 202 | 172 | 5.1 Estimated visits: a d... | 12.5x | MATCH | 12.5416 | arith Semrush US / (Ahrefs worldwide x 81.5%) |  |
| 203 | 173 | 5.1 Estimated visits: a d... | 11 | MATCH | 11 | arith calendar days live in the month (launch 26 July; October read on day 77, 11 October) |  |
| 204 | 173 | 5.1 Estimated visits: a d... | 215,577 | MATCH | 215,577.0 | data instrument_series_table2 CSV and instrument_extra.py constants (both transcribed) |  |
| 205 | 173 | 5.1 Estimated visits: a d... | 1,610,284 | MATCH | 1,610,284.0 | data instrument_series_table2 CSV and instrument_extra.py constants (both transcribed) |  |
| 206 | 173 | 5.1 Estimated visits: a d... | 1,858,297 | MATCH | 1,858,297.0 | data instrument_series_table2 CSV and instrument_extra.py constants (both transcribed) |  |
| 207 | 173 | 5.1 Estimated visits: a d... | 7.5x | MATCH | 7.46965 | arith Semrush US / Ahrefs worldwide |  |
| 208 | 173 | 5.1 Estimated visits: a d... | 8.6x | MATCH | 8.62011 | arith Semrush worldwide / Ahrefs worldwide |  |
| 209 | 173 | 5.1 Estimated visits: a d... | 9.2x | MATCH | 9.16521 | arith Semrush US / (Ahrefs worldwide x 81.5%) |  |
| 210 | 173 | 5.1 Estimated visits: a d... | 78 | MATCH | 78 | arith 6 + 31 + 30 + 11 |  |
| 211 | 173 | 5.1 Estimated visits: a d... | days 0 to 77 | MATCH | 77 | arith |  |
| 212 | 179 | 5.1 Estimated visits: a d... | 8.4x | MATCH | 8.35862 | arith Table 2 values (released series CSV, transcribed from the manuscript); Ahrefs gro... |  |
| 213 | 179 | 5.1 Estimated visits: a d... | 8.8x | MATCH | 8.76048 | arith Table 2 values (released series CSV, transcribed from the manuscript); Semrush US... |  |
| 214 | 179 | 5.1 Estimated visits: a d... | 4.65x | MATCH | 4.6502 | arith Table 2 values (released series CSV, transcribed from the manuscript) = rerun ins... |  |
| 215 | 179 | 5.1 Estimated visits: a d... | 1.75x | MATCH | 1.75125 | arith Table 2 values (released series CSV, transcribed from the manuscript) = rerun ins... |  |
| 216 | 179 | 5.1 Estimated visits: a d... | 1.44x | MATCH | 1.4361 | arith Table 2 values (released series CSV, transcribed from the manuscript) = rerun ins... |  |
| 217 | 179 | 5.1 Estimated visits: a d... | 1.05x | MATCH | 1.04948 | arith Table 2 values (released series CSV, transcribed from the manuscript) = rerun ins... |  |
| 218 | 179 | 5.1 Estimated visits: a d... | by a factor of more than two | MATCH | 2.65536 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 219 | 181 | 5.1 Estimated visits: a d... | 18.5% | MATCH | 18.5 | data single_reads_2026-10.csv |  |
| 220 | 181 | 5.1 Estimated visits: a d... | 8.6x | MATCH | 8.62011 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 221 | 181 | 5.1 Estimated visits: a d... | 29.9x | MATCH | 29.8608 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 222 | 181 | 5.1 Estimated visits: a d... | 9.2x | MATCH | 9.16521 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 223 | 181 | 5.1 Estimated visits: a d... | 33.3x | MATCH | 33.3024 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 224 | 183 | 5.1 Estimated visits: a d... | 27.1x | MATCH | 27.1414 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 225 | 183 | 5.1 Estimated visits: a d... | 10.2x | MATCH | 10.2214 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 226 | 183 | 5.1 Estimated visits: a d... | 7.5x | MATCH | 7.46965 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 227 | 187 | 5.2 Ranking keywords: a f... | 29,000 | MATCH | 29000 | data single_reads_2026-10.csv |  |
| 228 | 187 | 5.2 Ranking keywords: a f... | 58,586 | MATCH | 58586 | data single_reads_2026-10.csv |  |
| 229 | 187 | 5.2 Ranking keywords: a f... | 2.0 | MATCH | 2.02021 | arith 58,586 / 29,000 |  |
| 230 | 187 | 5.2 Ranking keywords: a f... | 12 | MATCH | 2026-10-12 | data single_reads_2026-10.csv (read date) |  |
| 231 | 187 | 5.2 Ranking keywords: a f... | 92.3K | MATCH | 92.3 | data single_reads_2026-10.csv |  |
| 232 | 187 | 5.2 Ranking keywords: a f... | 3.2 | MATCH | 3.19377 | arith 92,300 / 28,900 |  |
| 233 | 187 | 5.2 Ranking keywords: a f... | 28,900 | MATCH | 28900 | data ahrefs_prefixes CSV (/local/area-codes/) |  |
| 234 | 187 | 5.2 Ranking keywords: a f... | 441 | MATCH | 441 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 235 | 191 | 5.3 AI answers and AI Ove... | 17,206 | MATCH | 17206 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript); single... |  |
| 236 | 191 | 5.3 AI answers and AI Ove... | 158,100 | MATCH | 158,100.0 | data single_reads_2026-10.csv |  |
| 237 | 191 | 5.3 AI answers and AI Ove... | 10 | MATCH | 2026-10-10 | data single_reads_2026-10.csv (read date) |  |
| 238 | 191 | 5.3 AI answers and AI Ove... | 9.2 | MATCH | 9.18866 | arith 158,100 / 17,206 |  |
| 239 | 191 | 5.3 AI answers and AI Ove... | 29,600 | MATCH | 29600 | data single_reads_2026-10.csv |  |
| 240 | 191 | 5.3 AI answers and AI Ove... | 68 | MATCH | 68.2028 | arith 29,600 / 434 |  |
| 241 | 191 | 5.3 AI answers and AI Ove... | 434 | MATCH | 434 | arith 381 + 53 |  |
| 242 | 193 | 5.3 AI answers and AI Ove... | 17,206 | MATCH | 17206 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 243 | 201 | 5.3 AI answers and AI Ove... | 47 | MATCH | 47 | data instrument_series_table3 CSV and make_figs_v4.py constants (transcribed) |  |
| 244 | 201 | 5.3 AI answers and AI Ove... | 284 | MATCH | 284 | data instrument_series_table3 CSV and make_figs_v4.py constants (transcribed) |  |
| 245 | 201 | 5.3 AI answers and AI Ove... | 16.5% | MATCH | 16.5493 | arith numerator / denominator |  |
| 246 | 201 | 5.3 AI answers and AI Ove... | 12.7 | MATCH | 12.6794 | arith Wilson 95% lower |  |
| 247 | 201 | 5.3 AI answers and AI Ove... | 21.3 | MATCH | 21.3121 | arith Wilson 95% upper |  |
| 248 | 201 | 5.3 AI answers and AI Ove... | 138 | MATCH | 138 | data instrument_series_table3 CSV and make_figs_v4.py constants (transcribed) |  |
| 249 | 201 | 5.3 AI answers and AI Ove... | 2.94x | MATCH | 2.93617 | arith (b) / (a) numerator |  |
| 250 | 202 | 5.3 AI answers and AI Ove... | 851 | MATCH | 851 | data instrument_series_table3 CSV and make_figs_v4.py constants (transcribed) |  |
| 251 | 202 | 5.3 AI answers and AI Ove... | 6,749 | MATCH | 6749 | data instrument_series_table3 CSV and make_figs_v4.py constants (transcribed) |  |
| 252 | 202 | 5.3 AI answers and AI Ove... | 12.6% | MATCH | 12.6093 | arith numerator / denominator |  |
| 253 | 202 | 5.3 AI answers and AI Ove... | 11.8 | MATCH | 11.8385 | arith Wilson 95% lower |  |
| 254 | 202 | 5.3 AI answers and AI Ove... | 13.4 | MATCH | 13.4226 | arith Wilson 95% upper |  |
| 255 | 202 | 5.3 AI answers and AI Ove... | 2,221 | MATCH | 2221 | data instrument_series_table3 CSV and make_figs_v4.py constants (transcribed) |  |
| 256 | 202 | 5.3 AI answers and AI Ove... | 2.61x | MATCH | 2.60987 | arith (b) / (a) numerator |  |
| 257 | 203 | 5.3 AI answers and AI Ove... | 3,380 | MATCH | 3380 | data instrument_series_table3 CSV and make_figs_v4.py constants (transcribed) |  |
| 258 | 203 | 5.3 AI answers and AI Ove... | 22,665 | MATCH | 22665 | data instrument_series_table3 CSV and make_figs_v4.py constants (transcribed) |  |
| 259 | 203 | 5.3 AI answers and AI Ove... | 14.9% | MATCH | 14.9129 | arith numerator / denominator |  |
| 260 | 203 | 5.3 AI answers and AI Ove... | 14.5 | MATCH | 14.4551 | arith Wilson 95% lower |  |
| 261 | 203 | 5.3 AI answers and AI Ove... | 15.4 | MATCH | 15.3826 | arith Wilson 95% upper |  |
| 262 | 203 | 5.3 AI answers and AI Ove... | 8,187 | MATCH | 8187 | data instrument_series_table3 CSV and make_figs_v4.py constants (transcribed) |  |
| 263 | 203 | 5.3 AI answers and AI Ove... | 2.42x | MATCH | 2.42219 | arith (b) / (a) numerator |  |
| 264 | 204 | 5.3 AI answers and AI Ove... | 7,455 | MATCH | 7455 | data instrument_series_table3 CSV and make_figs_v4.py constants (transcribed) |  |
| 265 | 204 | 5.3 AI answers and AI Ove... | 37,238 | MATCH | 37238 | data instrument_series_table3 CSV and make_figs_v4.py constants (transcribed) |  |
| 266 | 204 | 5.3 AI answers and AI Ove... | 20.0% | MATCH | 20.0199 | arith numerator / denominator |  |
| 267 | 204 | 5.3 AI answers and AI Ove... | 19.6 | MATCH | 19.6165 | arith Wilson 95% lower |  |
| 268 | 204 | 5.3 AI answers and AI Ove... | 20.4 | MATCH | 20.4294 | arith Wilson 95% upper |  |
| 269 | 204 | 5.3 AI answers and AI Ove... | 10,018 | MATCH | 10018 | data instrument_series_table3 CSV and make_figs_v4.py constants (transcribed) |  |
| 270 | 204 | 5.3 AI answers and AI Ove... | 1.34x | MATCH | 1.3438 | arith (b) / (a) numerator |  |
| 271 | 206 | 5.3 AI answers and AI Ove... | 284 | MATCH | 284 | data Table 3 series CSV |  |
| 272 | 206 | 5.3 AI answers and AI Ove... | 37,238 | MATCH | 37238 | data Table 3 series CSV |  |
| 273 | 208 | 5.3 AI answers and AI Ove... | 2.94 | MATCH | 2.93617 | arith Table 3 |  |
| 274 | 208 | 5.3 AI answers and AI Ove... | 1.34 | MATCH | 1.3438 | arith Table 3 |  |
| 275 | 208 | 5.3 AI answers and AI Ove... | three intervals | MATCH | 3 | arith four months |  |
| 276 | 208 | 5.3 AI answers and AI Ove... | 47 | MATCH | 47 | data Table 3 series CSV |  |
| 277 | 208 | 5.3 AI answers and AI Ove... | six days live | MATCH | 6 | arith |  |
| 278 | 210 | 5.3 AI answers and AI Ove... | 284 | MATCH | 284 | data Table 3 series CSV |  |
| 279 | 210 | 5.3 AI answers and AI Ove... | 37,238 | MATCH | 37238 | data Table 3 series CSV |  |
| 280 | 210 | 5.3 AI answers and AI Ove... | grows by two orders of magnitude | MATCH | 2.11767 | arith log10(37,238 / 284) |  |
| 281 | 210 | 5.3 AI answers and AI Ove... | it is not monotone | MATCH | [16.5, 12.6, 14.9, 20.0] | arith |  |
| 282 | 212 | 5.4 Referring domains: 11... | 11.4x | MATCH | 11.4125 | arith 913 / 80 |  |
| 283 | 216 | 5.4 Referring domains: 11... | 913 | MATCH | 913 | data single_reads_2026-10.csv |  |
| 284 | 216 | 5.4 Referring domains: 11... | 80 | MATCH | 80 | data single_reads_2026-10.csv |  |
| 285 | 216 | 5.4 Referring domains: 11... | 11.4 | MATCH | 11.4125 | arith 913 / 80 |  |
| 286 | 216 | 5.4 Referring domains: 11... | 61.9% | MATCH | 61.9 | data single_reads_2026-10.csv |  |
| 287 | 216 | 5.4 Referring domains: 11... | 26.4% | MATCH | 26.4 | data single_reads_2026-10.csv |  |
| 288 | 216 | 5.4 Referring domains: 11... | 10.2% | MATCH | 10.2 | data single_reads_2026-10.csv |  |
| 289 | 216 | 5.4 Referring domains: 11... | 75% | MATCH | 75 | data single_reads_2026-10.csv |  |
| 290 | 216 | 5.4 Referring domains: 11... | 88% | MATCH | 88 | data single_reads_2026-10.csv |  |
| 291 | 216 | 5.4 Referring domains: 11... | 0 | MATCH | 0 to 10 | data single_reads_2026-10.csv |  |
| 292 | 216 | 5.4 Referring domains: 11... | 10 | MATCH | 0 to 10 | data single_reads_2026-10.csv |  |
| 293 | 218 | 5.4 Referring domains: 11... | 11 | MATCH | 2026-10-11 | data single_reads_2026-10.csv (read date) |  |
| 294 | 218 | 5.4 Referring domains: 11... | 913 | MATCH | 913 | data single_reads_2026-10.csv |  |
| 295 | 218 | 5.4 Referring domains: 11... | 80 | MATCH | 80 | data single_reads_2026-10.csv |  |
| 296 | 218 | 5.4 Referring domains: 11... | 75% | MATCH | 75 | data single_reads_2026-10.csv and make_figs_v4.py (Semrush .xyz 75.0) |  |
| 297 | 220 | 5.4 Referring domains: 11... | 909 | MATCH | 909 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 298 | 220 | 5.4 Referring domains: 11... | 913 | MATCH | 913 | data single_reads_2026-10.csv |  |
| 299 | 220 | 5.4 Referring domains: 11... | 11 | MATCH | 2026-10-11 | data single_reads_2026-10.csv |  |
| 300 | 220 | 5.4 Referring domains: 11... | 917 | MATCH | 917 | data single_reads_2026-10.csv |  |
| 301 | 220 | 5.4 Referring domains: 11... | 95 | MATCH | 95 | data single_reads_2026-10.csv |  |
| 302 | 220 | 5.4 Referring domains: 11... | nineteen | MATCH | 19 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 303 | 220 | 5.4 Referring domains: 11... | 841 | MATCH | 841 | arith 19 + 917 - 95 |  |
| 304 | 224 | 5.5 Twelve prefixes on on... | 12 | MATCH | 2026-10-12 | data both prefix CSVs (read_date) |  |
| 305 | 224 | 5.5 Twelve prefixes on on... | twelve sections ... the area-code section and eleven others | MATCH | 12 | data prefix CSVs |  |
| 306 | 224 | 5.5 Twelve prefixes on on... | ages from under two years to the instrument's horizon | MATCH | second youngest 21 months; oldest 201... | data ahrefs_prefixes CSV |  |
| 307 | 226 | 5.5 Twelve prefixes on on... | 12 | MATCH | 2026-10-12 | data prefix CSVs (read_date) |  |
| 308 | 226 | 5.5 Twelve prefixes on on... | 2015 | MATCH | 2015-09 | data ahrefs_prefixes CSV |  |
| 309 | 226 | 5.5 Twelve prefixes on on... | the next two lie within four months of it | MATCH | [129, 132, 133] | data ahrefs_prefixes CSV (129, 132, 133 months) |  |
| 310 | 226 | 5.5 Twelve prefixes on on... | 29,000 | MATCH | 29000 | data single_reads_2026-10.csv |  |
| 311 | 226 | 5.5 Twelve prefixes on on... | 58,586 | MATCH | 58586 | data single_reads_2026-10.csv |  |
| 312 | 226 | 5.5 Twelve prefixes on on... | 80 | MATCH | 80 | data single_reads_2026-10.csv |  |
| 313 | 226 | 5.5 Twelve prefixes on on... | 11.4x | MATCH | 11.4125 | arith |  |
| 314 | 230 | 5.5 Twelve prefixes on on... | 3 | MATCH | 3 | data ahrefs CSV first_traffic_month -> months to Oct 2026 |  |
| 315 | 230 | 5.5 Twelve prefixes on on... | 221,000 | MATCH | 221,000.0 | data ahrefs CSV |  |
| 316 | 230 | 5.5 Twelve prefixes on on... | 1,600,000 | MATCH | 1,600,000.0 | data semrush CSV |  |
| 317 | 230 | 5.5 Twelve prefixes on on... | 7.24 | MATCH | 7.23982 | arith Semrush / Ahrefs (= instrument_extra.py s.8) |  |
| 318 | 230 | 5.5 Twelve prefixes on on... | 81.4% | MATCH | 81.4 | data ahrefs CSV ahrefs_us_share |  |
| 319 | 230 | 5.5 Twelve prefixes on on... | 8.89 | MATCH | 8.89413 | arith Semrush / (Ahrefs x US share) (= instrument_extra.py s.8) |  |
| 320 | 230 | 5.5 Twelve prefixes on on... | 28,900 | MATCH | 28900 | data ahrefs CSV |  |
| 321 | 230 | 5.5 Twelve prefixes on on... | 59,000 | MATCH | 59000 | data semrush CSV |  |
| 322 | 230 | 5.5 Twelve prefixes on on... | 2.0 | MATCH | 2.04152 | arith Semrush kw / Ahrefs kw |  |
| 323 | 230 | 5.5 Twelve prefixes on on... | 913 | MATCH | 913 | data ahrefs CSV |  |
| 324 | 230 | 5.5 Twelve prefixes on on... | 81 | MATCH | 81 | data semrush CSV |  |
| 325 | 230 | 5.5 Twelve prefixes on on... | 11.3 | MATCH | 11.2716 | arith Ahrefs RD / Semrush RD |  |
| 326 | 231 | 5.5 Twelve prefixes on on... | 21 | MATCH | 21 | data ahrefs CSV first_traffic_month -> months to Oct 2026 |  |
| 327 | 231 | 5.5 Twelve prefixes on on... | 5,500 | MATCH | 5500 | data ahrefs CSV |  |
| 328 | 231 | 5.5 Twelve prefixes on on... | 4,100 | MATCH | 4100 | data semrush CSV |  |
| 329 | 231 | 5.5 Twelve prefixes on on... | 0.75 | MATCH | 0.745455 | arith Semrush / Ahrefs (= instrument_extra.py s.8) |  |
| 330 | 231 | 5.5 Twelve prefixes on on... | 69.6% | MATCH | 69.6 | data ahrefs CSV ahrefs_us_share |  |
| 331 | 231 | 5.5 Twelve prefixes on on... | 1.07 | MATCH | 1.07106 | arith Semrush / (Ahrefs x US share) (= instrument_extra.py s.8) |  |
| 332 | 231 | 5.5 Twelve prefixes on on... | 716 | MATCH | 716 | data ahrefs CSV |  |
| 333 | 231 | 5.5 Twelve prefixes on on... | 2,300 | MATCH | 2300 | data semrush CSV |  |
| 334 | 231 | 5.5 Twelve prefixes on on... | 3.2 | MATCH | 3.21229 | arith Semrush kw / Ahrefs kw |  |
| 335 | 231 | 5.5 Twelve prefixes on on... | 187 | MATCH | 187 | data ahrefs CSV |  |
| 336 | 231 | 5.5 Twelve prefixes on on... | 41 | MATCH | 41 | data semrush CSV |  |
| 337 | 231 | 5.5 Twelve prefixes on on... | 4.6 | MATCH | 4.56098 | arith Ahrefs RD / Semrush RD |  |
| 338 | 232 | 5.5 Twelve prefixes on on... | 36 | MATCH | 36 | data ahrefs CSV first_traffic_month -> months to Oct 2026 |  |
| 339 | 232 | 5.5 Twelve prefixes on on... | 25,600 | MATCH | 25600 | data ahrefs CSV |  |
| 340 | 232 | 5.5 Twelve prefixes on on... | 5,200 | MATCH | 5200 | data semrush CSV |  |
| 341 | 232 | 5.5 Twelve prefixes on on... | 0.20 | MATCH | 0.203125 | arith Semrush / Ahrefs (= instrument_extra.py s.8) |  |
| 342 | 232 | 5.5 Twelve prefixes on on... | 99.2% | MATCH | 99.2 | data ahrefs CSV ahrefs_us_share |  |
| 343 | 232 | 5.5 Twelve prefixes on on... | 0.20 | MATCH | 0.204763 | arith Semrush / (Ahrefs x US share) (= instrument_extra.py s.8) |  |
| 344 | 232 | 5.5 Twelve prefixes on on... | 2,100 | MATCH | 2100 | data ahrefs CSV |  |
| 345 | 232 | 5.5 Twelve prefixes on on... | 33,800 | MATCH | 33800 | data semrush CSV |  |
| 346 | 232 | 5.5 Twelve prefixes on on... | 16.1 | MATCH | 16.0952 | arith Semrush kw / Ahrefs kw |  |
| 347 | 232 | 5.5 Twelve prefixes on on... | 115 | MATCH | 115 | data ahrefs CSV |  |
| 348 | 232 | 5.5 Twelve prefixes on on... | 194 | MATCH | 194 | data semrush CSV |  |
| 349 | 232 | 5.5 Twelve prefixes on on... | 0.6 | MATCH | 0.592784 | arith Ahrefs RD / Semrush RD |  |
| 350 | 233 | 5.5 Twelve prefixes on on... | 39 | MATCH | 39 | data ahrefs CSV first_traffic_month -> months to Oct 2026 |  |
| 351 | 233 | 5.5 Twelve prefixes on on... | 26,700 | MATCH | 26700 | data ahrefs CSV |  |
| 352 | 233 | 5.5 Twelve prefixes on on... | 26,400 | MATCH | 26400 | data semrush CSV |  |
| 353 | 233 | 5.5 Twelve prefixes on on... | 0.99 | MATCH | 0.988764 | arith Semrush / Ahrefs (= instrument_extra.py s.8) |  |
| 354 | 233 | 5.5 Twelve prefixes on on... | 82.6% | MATCH | 82.6 | data ahrefs CSV ahrefs_us_share |  |
| 355 | 233 | 5.5 Twelve prefixes on on... | 1.20 | MATCH | 1.19705 | arith Semrush / (Ahrefs x US share) (= instrument_extra.py s.8) |  |
| 356 | 233 | 5.5 Twelve prefixes on on... | 2,400 | MATCH | 2400 | data ahrefs CSV |  |
| 357 | 233 | 5.5 Twelve prefixes on on... | 12,600 | MATCH | 12600 | data semrush CSV |  |
| 358 | 233 | 5.5 Twelve prefixes on on... | 5.2 | MATCH | 5.25 | arith Semrush kw / Ahrefs kw | full-precision value lies exactly on the rounding boundary |
| 359 | 233 | 5.5 Twelve prefixes on on... | 47 | MATCH | 47 | data ahrefs CSV |  |
| 360 | 233 | 5.5 Twelve prefixes on on... | 45 | MATCH | 45 | data semrush CSV |  |
| 361 | 233 | 5.5 Twelve prefixes on on... | 1.0 | MATCH | 1.04444 | arith Ahrefs RD / Semrush RD |  |
| 362 | 234 | 5.5 Twelve prefixes on on... | 57 | MATCH | 57 | data ahrefs CSV first_traffic_month -> months to Oct 2026 |  |
| 363 | 234 | 5.5 Twelve prefixes on on... | 37,300 | MATCH | 37300 | data ahrefs CSV |  |
| 364 | 234 | 5.5 Twelve prefixes on on... | 135,100 | MATCH | 135,100.0 | data semrush CSV |  |
| 365 | 234 | 5.5 Twelve prefixes on on... | 3.62 | MATCH | 3.62198 | arith Semrush / Ahrefs (= instrument_extra.py s.8) |  |
| 366 | 234 | 5.5 Twelve prefixes on on... | 98.8% | MATCH | 98.8 | data ahrefs CSV ahrefs_us_share |  |
| 367 | 234 | 5.5 Twelve prefixes on on... | 3.67 | MATCH | 3.66598 | arith Semrush / (Ahrefs x US share) (= instrument_extra.py s.8) |  |
| 368 | 234 | 5.5 Twelve prefixes on on... | 3,600 | MATCH | 3600 | data ahrefs CSV |  |
| 369 | 234 | 5.5 Twelve prefixes on on... | 37,500 | MATCH | 37500 | data semrush CSV |  |
| 370 | 234 | 5.5 Twelve prefixes on on... | 10.4 | MATCH | 10.4167 | arith Semrush kw / Ahrefs kw |  |
| 371 | 234 | 5.5 Twelve prefixes on on... | 144 | MATCH | 144 | data ahrefs CSV |  |
| 372 | 234 | 5.5 Twelve prefixes on on... | 225 | MATCH | 225 | data semrush CSV |  |
| 373 | 234 | 5.5 Twelve prefixes on on... | 0.6 | MATCH | 0.64 | arith Ahrefs RD / Semrush RD |  |
| 374 | 235 | 5.5 Twelve prefixes on on... | 93 | MATCH | 93 | data ahrefs CSV first_traffic_month -> months to Oct 2026 |  |
| 375 | 235 | 5.5 Twelve prefixes on on... | 1,900,000 | MATCH | 1,900,000.0 | data ahrefs CSV |  |
| 376 | 235 | 5.5 Twelve prefixes on on... | 1,957,880 | MATCH | 1,957,880.0 | data semrush CSV |  |
| 377 | 235 | 5.5 Twelve prefixes on on... | 1.03 | MATCH | 1.03046 | arith Semrush / Ahrefs (= instrument_extra.py s.8) |  |
| 378 | 235 | 5.5 Twelve prefixes on on... | 98.7% | MATCH | 98.7 | data ahrefs CSV ahrefs_us_share |  |
| 379 | 235 | 5.5 Twelve prefixes on on... | 1.04 | MATCH | 1.04404 | arith Semrush / (Ahrefs x US share) (= instrument_extra.py s.8) |  |
| 380 | 235 | 5.5 Twelve prefixes on on... | 38,700 | MATCH | 38700 | data ahrefs CSV |  |
| 381 | 235 | 5.5 Twelve prefixes on on... | 351,854 | MATCH | 351,854.0 | data semrush CSV |  |
| 382 | 235 | 5.5 Twelve prefixes on on... | 9.1 | MATCH | 9.09183 | arith Semrush kw / Ahrefs kw |  |
| 383 | 235 | 5.5 Twelve prefixes on on... | 10,600 | MATCH | 10600 | data ahrefs CSV |  |
| 384 | 235 | 5.5 Twelve prefixes on on... | 7,056 | MATCH | 7056 | data semrush CSV |  |
| 385 | 235 | 5.5 Twelve prefixes on on... | 1.5 | MATCH | 1.50227 | arith Ahrefs RD / Semrush RD |  |
| 386 | 236 | 5.5 Twelve prefixes on on... | 95 | MATCH | 95 | data ahrefs CSV first_traffic_month -> months to Oct 2026 |  |
| 387 | 236 | 5.5 Twelve prefixes on on... | 102,000 | MATCH | 102,000.0 | data ahrefs CSV |  |
| 388 | 236 | 5.5 Twelve prefixes on on... | 47,300 | MATCH | 47300 | data semrush CSV |  |
| 389 | 236 | 5.5 Twelve prefixes on on... | 0.46 | MATCH | 0.463725 | arith Semrush / Ahrefs (= instrument_extra.py s.8) |  |
| 390 | 236 | 5.5 Twelve prefixes on on... | 99.8% | MATCH | 99.8 | data ahrefs CSV ahrefs_us_share |  |
| 391 | 236 | 5.5 Twelve prefixes on on... | 0.46 | MATCH | 0.464655 | arith Semrush / (Ahrefs x US share) (= instrument_extra.py s.8) |  |
| 392 | 236 | 5.5 Twelve prefixes on on... | 5,400 | MATCH | 5400 | data ahrefs CSV |  |
| 393 | 236 | 5.5 Twelve prefixes on on... | 31,900 | MATCH | 31900 | data semrush CSV |  |
| 394 | 236 | 5.5 Twelve prefixes on on... | 5.9 | MATCH | 5.90741 | arith Semrush kw / Ahrefs kw |  |
| 395 | 236 | 5.5 Twelve prefixes on on... | 258 | MATCH | 258 | data ahrefs CSV |  |
| 396 | 236 | 5.5 Twelve prefixes on on... | 245 | MATCH | 245 | data semrush CSV |  |
| 397 | 236 | 5.5 Twelve prefixes on on... | 1.1 | MATCH | 1.05306 | arith Ahrefs RD / Semrush RD |  |
| 398 | 237 | 5.5 Twelve prefixes on on... | 95 | MATCH | 95 | data ahrefs CSV first_traffic_month -> months to Oct 2026 |  |
| 399 | 237 | 5.5 Twelve prefixes on on... | 644,000 | MATCH | 644,000.0 | data ahrefs CSV |  |
| 400 | 237 | 5.5 Twelve prefixes on on... | 1,014,124 | MATCH | 1,014,124.0 | data semrush CSV |  |
| 401 | 237 | 5.5 Twelve prefixes on on... | 1.57 | MATCH | 1.57473 | arith Semrush / Ahrefs (= instrument_extra.py s.8) |  |
| 402 | 237 | 5.5 Twelve prefixes on on... | 98.5% | MATCH | 98.5 | data ahrefs CSV ahrefs_us_share |  |
| 403 | 237 | 5.5 Twelve prefixes on on... | 1.60 | MATCH | 1.59871 | arith Semrush / (Ahrefs x US share) (= instrument_extra.py s.8) |  |
| 404 | 237 | 5.5 Twelve prefixes on on... | 19,800 | MATCH | 19800 | data ahrefs CSV |  |
| 405 | 237 | 5.5 Twelve prefixes on on... | 206,365 | MATCH | 206,365.0 | data semrush CSV |  |
| 406 | 237 | 5.5 Twelve prefixes on on... | 10.4 | MATCH | 10.4225 | arith Semrush kw / Ahrefs kw |  |
| 407 | 237 | 5.5 Twelve prefixes on on... | 7,400 | MATCH | 7400 | data ahrefs CSV |  |
| 408 | 237 | 5.5 Twelve prefixes on on... | 3,246 | MATCH | 3246 | data semrush CSV |  |
| 409 | 237 | 5.5 Twelve prefixes on on... | 2.3 | MATCH | 2.27973 | arith Ahrefs RD / Semrush RD |  |
| 410 | 238 | 5.5 Twelve prefixes on on... | 114 | MATCH | 114 | data ahrefs CSV first_traffic_month -> months to Oct 2026 |  |
| 411 | 238 | 5.5 Twelve prefixes on on... | 243,000 | MATCH | 243,000.0 | data ahrefs CSV |  |
| 412 | 238 | 5.5 Twelve prefixes on on... | 220,600 | MATCH | 220,600.0 | data semrush CSV |  |
| 413 | 238 | 5.5 Twelve prefixes on on... | 0.91 | MATCH | 0.907819 | arith Semrush / Ahrefs (= instrument_extra.py s.8) |  |
| 414 | 238 | 5.5 Twelve prefixes on on... | 93.6% | MATCH | 93.6 | data ahrefs CSV ahrefs_us_share |  |
| 415 | 238 | 5.5 Twelve prefixes on on... | 0.97 | MATCH | 0.969892 | arith Semrush / (Ahrefs x US share) (= instrument_extra.py s.8) |  |
| 416 | 238 | 5.5 Twelve prefixes on on... | 13,300 | MATCH | 13300 | data ahrefs CSV |  |
| 417 | 238 | 5.5 Twelve prefixes on on... | 79,700 | MATCH | 79700 | data semrush CSV |  |
| 418 | 238 | 5.5 Twelve prefixes on on... | 6.0 | MATCH | 5.99248 | arith Semrush kw / Ahrefs kw |  |
| 419 | 238 | 5.5 Twelve prefixes on on... | 1,700 | MATCH | 1700 | data ahrefs CSV |  |
| 420 | 238 | 5.5 Twelve prefixes on on... | 516 | MATCH | 516 | data semrush CSV |  |
| 421 | 238 | 5.5 Twelve prefixes on on... | 3.3 | MATCH | 3.29457 | arith Ahrefs RD / Semrush RD |  |
| 422 | 239 | 5.5 Twelve prefixes on on... | 129 | MATCH | 129 | data ahrefs CSV first_traffic_month -> months to Oct 2026 |  |
| 423 | 239 | 5.5 Twelve prefixes on on... | 312,000 | MATCH | 312,000.0 | data ahrefs CSV |  |
| 424 | 239 | 5.5 Twelve prefixes on on... | 2,051,269 | MATCH | 2,051,269.0 | data semrush CSV |  |
| 425 | 239 | 5.5 Twelve prefixes on on... | 6.57 | MATCH | 6.57458 | arith Semrush / Ahrefs (= instrument_extra.py s.8) |  |
| 426 | 239 | 5.5 Twelve prefixes on on... | 99.4% | MATCH | 99.4 | data ahrefs CSV ahrefs_us_share |  |
| 427 | 239 | 5.5 Twelve prefixes on on... | 6.61 | MATCH | 6.61427 | arith Semrush / (Ahrefs x US share) (= instrument_extra.py s.8) |  |
| 428 | 239 | 5.5 Twelve prefixes on on... | 14,700 | MATCH | 14700 | data ahrefs CSV |  |
| 429 | 239 | 5.5 Twelve prefixes on on... | 306,952 | MATCH | 306,952.0 | data semrush CSV |  |
| 430 | 239 | 5.5 Twelve prefixes on on... | 20.9 | MATCH | 20.8811 | arith Semrush kw / Ahrefs kw |  |
| 431 | 239 | 5.5 Twelve prefixes on on... | 4,100 | MATCH | 4100 | data ahrefs CSV |  |
| 432 | 239 | 5.5 Twelve prefixes on on... | 3,527 | MATCH | 3527 | data semrush CSV |  |
| 433 | 239 | 5.5 Twelve prefixes on on... | 1.2 | MATCH | 1.16246 | arith Ahrefs RD / Semrush RD |  |
| 434 | 240 | 5.5 Twelve prefixes on on... | 132 | MATCH | 132 | data ahrefs CSV first_traffic_month -> months to Oct 2026 |  |
| 435 | 240 | 5.5 Twelve prefixes on on... | 214,000 | MATCH | 214,000.0 | data ahrefs CSV |  |
| 436 | 240 | 5.5 Twelve prefixes on on... | 219,600 | MATCH | 219,600.0 | data semrush CSV |  |
| 437 | 240 | 5.5 Twelve prefixes on on... | 1.03 | MATCH | 1.02617 | arith Semrush / Ahrefs (= instrument_extra.py s.8) |  |
| 438 | 240 | 5.5 Twelve prefixes on on... | 99.3% | MATCH | 99.3 | data ahrefs CSV ahrefs_us_share |  |
| 439 | 240 | 5.5 Twelve prefixes on on... | 1.03 | MATCH | 1.0334 | arith Semrush / (Ahrefs x US share) (= instrument_extra.py s.8) |  |
| 440 | 240 | 5.5 Twelve prefixes on on... | 5,300 | MATCH | 5300 | data ahrefs CSV |  |
| 441 | 240 | 5.5 Twelve prefixes on on... | 32,000 | MATCH | 32000 | data semrush CSV |  |
| 442 | 240 | 5.5 Twelve prefixes on on... | 6.0 | MATCH | 6.03774 | arith Semrush kw / Ahrefs kw |  |
| 443 | 240 | 5.5 Twelve prefixes on on... | 1,600 | MATCH | 1600 | data ahrefs CSV |  |
| 444 | 240 | 5.5 Twelve prefixes on on... | 2,042 | MATCH | 2042 | data semrush CSV |  |
| 445 | 240 | 5.5 Twelve prefixes on on... | 0.8 | MATCH | 0.783546 | arith Ahrefs RD / Semrush RD |  |
| 446 | 241 | 5.5 Twelve prefixes on on... | 133 | MATCH | 133 | data ahrefs CSV first_traffic_month -> months to Oct 2026 |  |
| 447 | 241 | 5.5 Twelve prefixes on on... | 8,900 | MATCH | 8900 | data ahrefs CSV |  |
| 448 | 241 | 5.5 Twelve prefixes on on... | 2,200 | MATCH | 2200 | data semrush CSV |  |
| 449 | 241 | 5.5 Twelve prefixes on on... | 0.25 | MATCH | 0.247191 | arith Semrush / Ahrefs (= instrument_extra.py s.8) |  |
| 450 | 241 | 5.5 Twelve prefixes on on... | 42.6% | MATCH | 42.6 | data ahrefs CSV ahrefs_us_share |  |
| 451 | 241 | 5.5 Twelve prefixes on on... | 0.58 | MATCH | 0.580261 | arith Semrush / (Ahrefs x US share) (= instrument_extra.py s.8) |  |
| 452 | 241 | 5.5 Twelve prefixes on on... | 1,300 | MATCH | 1300 | data ahrefs CSV |  |
| 453 | 241 | 5.5 Twelve prefixes on on... | 4,800 | MATCH | 4800 | data semrush CSV |  |
| 454 | 241 | 5.5 Twelve prefixes on on... | 3.7 | MATCH | 3.69231 | arith Semrush kw / Ahrefs kw |  |
| 455 | 241 | 5.5 Twelve prefixes on on... | 284 | MATCH | 284 | data ahrefs CSV |  |
| 456 | 241 | 5.5 Twelve prefixes on on... | 62 | MATCH | 62 | data semrush CSV |  |
| 457 | 241 | 5.5 Twelve prefixes on on... | 4.6 | MATCH | 4.58065 | arith Ahrefs RD / Semrush RD |  |
| 458 | 243 | 5.5 Twelve prefixes on on... | 12 | MATCH | 2026-10-12 | data prefix CSVs (read_date) |  |
| 459 | 245 | 5.5 Twelve prefixes on on... | Six things follow | MATCH | 6 | manuscript: bold-led paragraphs of Section 5.5 before Limits |  |
| 460 | 247 | 5.5 Twelve prefixes on on... | −0.11 | MATCH | -0.112084 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 461 | 247 | 5.5 Twelve prefixes on on... | −0.64 | MATCH | -0.644533 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 462 | 247 | 5.5 Twelve prefixes on on... | +0.49 | MATCH | 0.493575 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 463 | 247 | 5.5 Twelve prefixes on on... | 0.73 | MATCH | 0.73 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CS... |  |
| 464 | 247 | 5.5 Twelve prefixes on on... | −0.28 | MATCH | -0.283713 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CS... |  |
| 465 | 247 | 5.5 Twelve prefixes on on... | +0.15 | MATCH | 0.154898 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CS... |  |
| 466 | 247 | 5.5 Twelve prefixes on on... | 38% | MATCH | 37.7644 | rerun instrument_extra.py (byte-identical to shipped output); Fisher approximation |  |
| 467 | 247 | 5.5 Twelve prefixes on on... | 37.8% | MATCH | 37.7644 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 468 | 247 | 5.5 Twelve prefixes on on... | the seven sections aged between seven and eleven years | MATCH | 7 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 469 | 247 | 5.5 Twelve prefixes on on... | 0.25x | MATCH | 0.247191 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 470 | 247 | 5.5 Twelve prefixes on on... | 6.57x | MATCH | 6.57458 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 471 | 247 | 5.5 Twelve prefixes on on... | 0.46x | MATCH | 0.464655 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 472 | 247 | 5.5 Twelve prefixes on on... | 6.61x | MATCH | 6.61427 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 473 | 247 | 5.5 Twelve prefixes on on... | 27.1x | MATCH | 27.1414 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 474 | 247 | 5.5 Twelve prefixes on on... | 7.5x | MATCH | 7.46965 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 475 | 247 | 5.5 Twelve prefixes on on... | Only one prefix ... under twenty-one months old | MATCH | 1 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 476 | 249 | 5.5 Twelve prefixes on on... | one fifth of Ahrefs' | MATCH | 0.203125 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 477 | 249 | 5.5 Twelve prefixes on on... | seven times it | MATCH | 7.23982 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 478 | 249 | 5.5 Twelve prefixes on on... | 0.20x | MATCH | 0.203125 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 479 | 249 | 5.5 Twelve prefixes on on... | 7.24x | MATCH | 7.23982 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 480 | 249 | 5.5 Twelve prefixes on on... | 1.55 | MATCH | 1.55196 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CS... |  |
| 481 | 249 | 5.5 Twelve prefixes on on... | 1.01 | MATCH | 1.00747 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 482 | 249 | 5.5 Twelve prefixes on on... | six of twelve prefixes below one | MATCH | 6 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 483 | 249 | 5.5 Twelve prefixes on on... | 0.20x | MATCH | 0.204763 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CS... |  |
| 484 | 249 | 5.5 Twelve prefixes on on... | 8.89x | MATCH | 8.89413 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CS... |  |
| 485 | 249 | 5.5 Twelve prefixes on on... | 1.06 | MATCH | 1.05755 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 486 | 249 | 5.5 Twelve prefixes on on... | four of twelve are below one | MATCH | 4 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 487 | 249 | 5.5 Twelve prefixes on on... | two of the six sub-one prefixes cross one | MATCH | ['/device-compare/', '/product-compar... | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 488 | 249 | 5.5 Twelve prefixes on on... | 69.6% | MATCH | 69.6 | data ahrefs CSV |  |
| 489 | 249 | 5.5 Twelve prefixes on on... | 0.75x | MATCH | 0.745455 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 490 | 249 | 5.5 Twelve prefixes on on... | 1.07x | MATCH | 1.07106 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 491 | 249 | 5.5 Twelve prefixes on on... | 82.6% | MATCH | 82.6 | data ahrefs CSV |  |
| 492 | 249 | 5.5 Twelve prefixes on on... | 0.99x | MATCH | 0.988764 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 493 | 249 | 5.5 Twelve prefixes on on... | 1.20x | MATCH | 1.19705 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 494 | 249 | 5.5 Twelve prefixes on on... | 42.6% | MATCH | 42.6 | data ahrefs CSV |  |
| 495 | 249 | 5.5 Twelve prefixes on on... | 0.25x | MATCH | 0.247191 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 496 | 249 | 5.5 Twelve prefixes on on... | 0.58x | MATCH | 0.580261 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 497 | 249 | 5.5 Twelve prefixes on on... | 1.13 | MATCH | 1.13296 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 498 | 249 | 5.5 Twelve prefixes on on... | 0.62 | MATCH | 0.62 | rerun instrument_extra.py (byte-identical to shipped output); bootstrap, seed 20261015 |  |
| 499 | 249 | 5.5 Twelve prefixes on on... | 2.12 | MATCH | 2.12 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 500 | 249 | 5.5 Twelve prefixes on on... | 3.1 | MATCH | 3.13014 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 501 | 249 | 5.5 Twelve prefixes on on... | 1.9 | MATCH | 1.92 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 502 | 249 | 5.5 Twelve prefixes on on... | 4.1 | MATCH | 4.14 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 503 | 249 | 5.5 Twelve prefixes on on... | 0.12x | MATCH | 0.121034 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 504 | 249 | 5.5 Twelve prefixes on on... | 10.6x | MATCH | 10.6052 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 505 | 251 | 5.5 Twelve prefixes on on... | +0.94 | MATCH | 0.937063 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 506 | 251 | 5.5 Twelve prefixes on on... | +0.70 | MATCH | 0.7 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 507 | 251 | 5.5 Twelve prefixes on on... | +1.00 | MATCH | 1 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 508 | 251 | 5.5 Twelve prefixes on on... | 0.001 | MATCH | 6.99316e-06 | rerun instrument_extra.py (byte-identical to shipped output) (p = 7e-06) |  |
| 509 | 251 | 5.5 Twelve prefixes on on... | +0.82 | MATCH | 0.818182 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 510 | 251 | 5.5 Twelve prefixes on on... | +0.57 | MATCH | 0.57 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 511 | 251 | 5.5 Twelve prefixes on on... | +1.00 | MATCH | 1 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 512 | 251 | 5.5 Twelve prefixes on on... | 60 | MATCH | 60 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 513 | 251 | 5.5 Twelve prefixes on on... | 66 | MATCH | 66 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 514 | 251 | 5.5 Twelve prefixes on on... | 60 | MATCH | 60 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 515 | 251 | 5.5 Twelve prefixes on on... | 66 | MATCH | 66 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 516 | 251 | 5.5 Twelve prefixes on on... | 51 | MATCH | 51 | rerun instrument_extra.py (byte-identical to shipped output); all 51 ordered alike |  |
| 517 | 251 | 5.5 Twelve prefixes on on... | 15 | MATCH | 15 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 518 | 251 | 5.5 Twelve prefixes on on... | 9 | MATCH | 9 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 519 | 253 | 5.5 Twelve prefixes on on... | on every prefix | MATCH | 2.04152 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 520 | 253 | 5.5 Twelve prefixes on on... | 2.0x | MATCH | 2.04152 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 521 | 253 | 5.5 Twelve prefixes on on... | 20.9x | MATCH | 20.8811 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 522 | 253 | 5.5 Twelve prefixes on on... | +0.17 | MATCH | 0.167832 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 523 | 253 | 5.5 Twelve prefixes on on... | +0.52 | MATCH | 0.518182 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 524 | 253 | 5.5 Twelve prefixes on on... | 16.1x | MATCH | 16.0952 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 525 | 253 | 5.5 Twelve prefixes on on... | the second-largest keyword ratio | MATCH | /local/bundles/ | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 526 | 253 | 5.5 Twelve prefixes on on... | 0.20x | MATCH | 0.203125 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 527 | 253 | 5.5 Twelve prefixes on on... | 0.60 | MATCH | 0.602099 | rerun instrument_extra.py (byte-identical to shipped output); t approximation (permutat... |  |
| 528 | 253 | 5.5 Twelve prefixes on on... | 0.10 | MATCH | 0.102492 | rerun instrument_extra.py (byte-identical to shipped output); t approximation (permutat... |  |
| 529 | 255 | 5.5 Twelve prefixes on on... | 7.24x | MATCH | 7.23982 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 530 | 255 | 5.5 Twelve prefixes on on... | 8.89x | MATCH | 8.89413 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 531 | 255 | 5.5 Twelve prefixes on on... | 6.57x | MATCH | 6.57458 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CS... |  |
| 532 | 255 | 5.5 Twelve prefixes on on... | 11.3x | MATCH | 11.2716 | rerun instrument_extra.py (byte-identical to shipped output); highest RD ratio |  |
| 533 | 255 | 5.5 Twelve prefixes on on... | the highest visits ratio ... and the highest referring-domain ratio | MATCH | /local/area-codes/ | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 534 | 255 | 5.5 Twelve prefixes on on... | three months old | MATCH | 3 | data ahrefs CSV |  |
| 535 | 257 | 5.5 Twelve prefixes on on... | 158.3K | MATCH | 158.3 | data single_reads_2026-10.csv |  |
| 536 | 257 | 5.5 Twelve prefixes on on... | 29.5K | MATCH | 29.5 | data single_reads_2026-10.csv |  |
| 537 | 257 | 5.5 Twelve prefixes on on... | 12 | MATCH | 2026-10-12 | data single_reads_2026-10.csv |  |
| 538 | 257 | 5.5 Twelve prefixes on on... | 158,100 | MATCH | 158,100.0 | data single_reads_2026-10.csv |  |
| 539 | 257 | 5.5 Twelve prefixes on on... | 29,600 | MATCH | 29600 | data single_reads_2026-10.csv |  |
| 540 | 259 | 5.5 Twelve prefixes on on... | 2015 | MATCH | 2015-09; 2015-10, 2016-01 | data ahrefs CSV (one prefix at the horizon, two close to it) |  |
| 541 | 267 | 5.6 What follows for appl... | 27.1x | MATCH | 27.1414 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 542 | 267 | 5.6 What follows for appl... | 5.2 | MATCH | 5.20975 | arith sqrt(27.14) |  |
| 543 | 267 | 5.6 What follows for appl... | 27.1 | MATCH | 27.1414 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 544 | 267 | 5.6 What follows for appl... | 13 | MATCH | 13.0707 | arith (876,153 - 32,281) / 2 / 32,281 |  |
| 545 | 269 | 5.6 What follows for appl... | 27.1 | MATCH | 27.1414 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 546 | 269 | 5.6 What follows for appl... | 10.2 | MATCH | 10.2214 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 547 | 269 | 5.6 What follows for appl... | 7.5 | MATCH | 7.46965 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 548 | 269 | 5.6 What follows for appl... | several hundred automated referring domains | MATCH | 890 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 549 | 269 | 5.6 What follows for appl... | covering two of the four months | MATCH | 29 Sep to 9 Oct | arith days 65 to 75 |  |
| 551 | 273 | 5.6 What follows for appl... | 7.47x | MATCH | 7.46965 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 552 | 273 | 5.6 What follows for appl... | 2.02x | MATCH | 2.02021 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 553 | 273 | 5.6 What follows for appl... | 3.70x | MATCH | 3.69747 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 554 | 275 | 5.6 What follows for appl... | 35% | MATCH | 34.9703 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 555 | 275 | 5.6 What follows for appl... | 12 | MATCH | 2026-10-12 | data single_reads_2026-10.csv |  |
| 556 | 275 | 5.6 What follows for appl... | 8.62x | MATCH | 8.62011 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 557 | 275 | 5.6 What follows for appl... | 3.19x | MATCH | 3.19377 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 558 | 275 | 5.6 What follows for appl... | 2.70x | MATCH | 2.69904 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 559 | 275 | 5.6 What follows for appl... | 54% | MATCH | 53.9067 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 560 | 277 | 5.6 What follows for appl... | 8.62x | MATCH | 8.62011 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 561 | 277 | 5.6 What follows for appl... | 26.7x | MATCH | 26.6818 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 562 | 277 | 5.6 What follows for appl... | 29.9x | MATCH | 29.8608 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 563 | 277 | 5.6 What follows for appl... | 18.5% | MATCH | 18.5 | data single_reads_2026-10.csv |  |
| 564 | 277 | 5.6 What follows for appl... | 9.17x | MATCH | 9.16521 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 565 | 277 | 5.6 What follows for appl... | 7.5x | MATCH | 7.46965 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 566 | 277 | 5.6 What follows for appl... | 31.8x | MATCH | 31.7748 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 567 | 277 | 5.6 What follows for appl... | 33.3x | MATCH | 33.3024 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 568 | 277 | 5.6 What follows for appl... | 12.5x | MATCH | 12.5416 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 569 | 279 | 5.6 What follows for appl... | 0.20x | MATCH | 0.203125 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 570 | 279 | 5.6 What follows for appl... | 7.24x | MATCH | 7.23982 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 571 | 279 | 5.6 What follows for appl... | 0.20x | MATCH | 0.204763 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 572 | 279 | 5.6 What follows for appl... | 8.89x | MATCH | 8.89413 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 573 | 279 | 5.6 What follows for appl... | 60 | MATCH | 60 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 574 | 279 | 5.6 What follows for appl... | 66 | MATCH | 66 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 575 | 279 | 5.6 What follows for appl... | 9 | MATCH | 9 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 576 | 279 | 5.6 What follows for appl... | 15 | MATCH | 15 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 577 | 279 | 5.6 What follows for appl... | two pairs six to seven times apart were ordered the other way | MATCH | [7.25, 6.09] | rerun instrument_extra.py (byte-identical to shipped output) | 7.25x is read as 'seven' |
| 578 | 279 | 5.6 What follows for appl... | 2.7 | MATCH | 2.65536 | rerun instrument_extra.py (byte-identical to shipped output) (2.66) |  |
| 579 | 279 | 5.6 What follows for appl... | a factor of five below to nearly nine above | MATCH | (0.203125, 8.894126541185365) | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 580 | 281 | 5.6 What follows for appl... | 77 | MATCH | 77 | arith |  |
| 581 | 285 | 6 Measurement 2: reviews ... | 47,485 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 582 | 285 | 6 Measurement 2: reviews ... | 379 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 583 | 285 | 6 Measurement 2: reviews ... | 37,193 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 584 | 285 | 6 Measurement 2: reviews ... | 378 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 585 | 285 | 6 Measurement 2: reviews ... | 1 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 586 | 285 | 6 Measurement 2: reviews ... | 201 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 587 | 285 | 6 Measurement 2: reviews ... | 145 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 588 | 285 | 6 Measurement 2: reviews ... | 26 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 589 | 285 | 6 Measurement 2: reviews ... | five different carriers | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 590 | 285 | 6 Measurement 2: reviews ... | 42,994 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 591 | 285 | 6 Measurement 2: reviews ... | 1,898,584 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 592 | 285 | 6 Measurement 2: reviews ... | 37,193 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 593 | 285 | 6 Measurement 2: reviews ... | 20,663 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped analyze_reviews_output.txt (needs the licensed review export, not released); also 20,66... |
| 594 | 285 | 6 Measurement 2: reviews ... | 55.6% | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped analyze_reviews_output.txt (needs the licensed review export, not released) (20,663 / 3... |
| 595 | 285 | 6 Measurement 2: reviews ... | 27,817 | MATCH | 27817 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 596 | 285 | 6 Measurement 2: reviews ... | 2.25 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped outputs (46,517 links / 20,663 reviews) |
| 597 | 285 | 6 Measurement 2: reviews ... | 1,008 | MATCH | 1008 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 598 | 287 | 6 Measurement 2: reviews ... | 17 | MATCH | 17 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 599 | 287 | 6 Measurement 2: reviews ... | +0.75 | MATCH | 0.747549 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 600 | 287 | 6 Measurement 2: reviews ... | +0.44 | MATCH | 0.442663 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 601 | 287 | 6 Measurement 2: reviews ... | +0.90 | MATCH | 0.900374 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 602 | 287 | 6 Measurement 2: reviews ... | 0.001 | MATCH | 0.000561238 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 603 | 287 | 6 Measurement 2: reviews ... | 17 | MATCH | 17 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 604 | 287 | 6 Measurement 2: reviews ... | +0.47 | MATCH | 0.468137 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 605 | 287 | 6 Measurement 2: reviews ... | +0.01 | MATCH | 0.00625782 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 606 | 287 | 6 Measurement 2: reviews ... | +0.78 | MATCH | 0.782772 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 607 | 287 | 6 Measurement 2: reviews ... | 0.06 | MATCH | 0.0580719 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 608 | 287 | 6 Measurement 2: reviews ... | +0.78 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped analyze_reviews_output.txt (needs the licensed review export, not released) |
| 609 | 287 | 6 Measurement 2: reviews ... | 66.8% | MATCH | 66.7617 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 610 | 287 | 6 Measurement 2: reviews ... | 14.9% | MATCH | 14.9203 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 611 | 287 | 6 Measurement 2: reviews ... | 11.0% | MATCH | 10.9782 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 612 | 287 | 6 Measurement 2: reviews ... | 32.7% | MATCH | 32.7052 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 613 | 287 | 6 Measurement 2: reviews ... | 4.0% | MATCH | 4.01239 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 614 | 287 | 6 Measurement 2: reviews ... | 18.1% | MATCH | 18.0787 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 615 | 287 | 6 Measurement 2: reviews ... | 1,008 | MATCH | 1008 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 616 | 287 | 6 Measurement 2: reviews ... | +0.18 | MATCH | 0.184869 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... | 0.18487 |
| 617 | 287 | 6 Measurement 2: reviews ... | +0.12 | MATCH | 0.124023 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 618 | 287 | 6 Measurement 2: reviews ... | +0.25 | MATCH | 0.245035 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... | printed +0.245; full precision 0.245035 |
| 619 | 287 | 6 Measurement 2: reviews ... | +0.13 | MATCH | 0.131702 | recomputed from m2_label_counts.csv (Kendall over mentioned labels; ranks preserve orde... |  |
| 620 | 287 | 6 Measurement 2: reviews ... | 26,809 | MATCH | 26809 | arith 27,817 - 1,008 |  |
| 621 | 287 | 6 Measurement 2: reviews ... | +0.27 | MATCH | 0.272602 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 622 | 287 | 6 Measurement 2: reviews ... | +0.26 | MATCH | 0.260054 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 623 | 287 | 6 Measurement 2: reviews ... | +0.28 | MATCH | 0.284982 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... | printed 0.285; full precision 0.284982 |
| 624 | 287 | 6 Measurement 2: reviews ... | +0.28 | MATCH | 0.281843 | recomputed from m2_label_counts.csv (labels with at least 20 mentions); shipped analyze... |  |
| 625 | 287 | 6 Measurement 2: reviews ... | 213 | MATCH | 213 | recomputed from m2_label_counts.csv |  |
| 626 | 287 | 6 Measurement 2: reviews ... | +0.16 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped analyze_reviews_output.txt (needs the licensed review export, not released) |
| 627 | 287 | 6 Measurement 2: reviews ... | 106 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped analyze_reviews_output.txt (needs the licensed review export, not released) |
| 628 | 287 | 6 Measurement 2: reviews ... | 0.001 | MATCH | ['0', '3.4e-09'] | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... | the p-values below 0.001 that the scripts print |
| 629 | 287 | 6 Measurement 2: reviews ... | 1,008 | MATCH | 1008 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 630 | 287 | 6 Measurement 2: reviews ... | 367 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped analyze_reviews_output.txt (needs the licensed review export, not released) |
| 631 | 287 | 6 Measurement 2: reviews ... | 36.4% | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped analyze_reviews_output.txt (needs the licensed review export, not released) |
| 632 | 287 | 6 Measurement 2: reviews ... | 106 | MATCH | 106 | recomputed from m2_label_counts.csv: mentioned labels in the lowest volume-rank group (... | agrees with shipped analyze_reviews_output.txt (106) |
| 633 | 287 | 6 Measurement 2: reviews ... | 10.5% | MATCH | 10.5159 | arith 106 / 1,008 |  |
| 634 | 287 | 6 Measurement 2: reviews ... | +0.16 | MATCH | 0.162395 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 635 | 287 | 6 Measurement 2: reviews ... | +0.26 | MATCH | 0.258434 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 636 | 289 | 6 Measurement 2: reviews ... | 200 | MATCH | 200 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 637 | 289 | 6 Measurement 2: reviews ... | 46,517 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped r2_link_sample_output.txt |
| 638 | 289 | 6 Measurement 2: reviews ... | 65% | MATCH | 65 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs; annotat... |  |
| 639 | 289 | 6 Measurement 2: reviews ... | 67% | MATCH | 66.8367 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs; annotat... |  |
| 640 | 289 | 6 Measurement 2: reviews ... | 58% | MATCH | 58.1633 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 641 | 289 | 6 Measurement 2: reviews ... | 73% | MATCH | 73.0486 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 642 | 289 | 6 Measurement 2: reviews ... | 95.5% | MATCH | 95.5 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 643 | 289 | 6 Measurement 2: reviews ... | 0.90 | MATCH | 0.90228 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 644 | 289 | 6 Measurement 2: reviews ... | right about half the time | MATCH | (0.5, 0.48031496062992124) | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 645 | 289 | 6 Measurement 2: reviews ... | 95% | MATCH | 94.5205 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs (69/73 =... |  |
| 646 | 289 | 6 Measurement 2: reviews ... | 96% | MATCH | 95.8333 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs (69/72) |  |
| 647 | 289 | 6 Measurement 2: reviews ... | +0.91 | MATCH | 0.914216 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 648 | 289 | 6 Measurement 2: reviews ... | +0.74 | MATCH | 0.735 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... | exactly 0.735 (294/400, m2_boundary.txt); half-up and half-even both give 0.74, Python's float formatting w... |
| 649 | 289 | 6 Measurement 2: reviews ... | +0.98 | MATCH | 0.982565 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 650 | 289 | 6 Measurement 2: reviews ... | +0.65 | MATCH | 0.648682 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 651 | 289 | 6 Measurement 2: reviews ... | +0.24 | MATCH | 0.243221 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 652 | 289 | 6 Measurement 2: reviews ... | +0.16 | MATCH | 0.158339 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 653 | 289 | 6 Measurement 2: reviews ... | +0.33 | MATCH | 0.325815 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 654 | 289 | 6 Measurement 2: reviews ... | 56% | MATCH | 56.1011 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 655 | 289 | 6 Measurement 2: reviews ... | 15% | MATCH | 14.9203 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 656 | 291 | 6 Measurement 2: reviews ... | 6,620 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped analyze_reviews_output.txt (needs the licensed review export, not released) |
| 657 | 291 | 6 Measurement 2: reviews ... | 924 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped analyze_reviews_output.txt (needs the licensed review export, not released); also 924 i... |
| 658 | 291 | 6 Measurement 2: reviews ... | 14.0% | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped analyze_reviews_output.txt (needs the licensed review export, not released) |
| 659 | 291 | 6 Measurement 2: reviews ... | 13.1% | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with Wilson interval on the shipped counts |
| 660 | 291 | 6 Measurement 2: reviews ... | 14.8% | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with Wilson interval on the shipped counts |
| 661 | 291 | 6 Measurement 2: reviews ... | 1.9% | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) (564 / 29,225) |
| 662 | 291 | 6 Measurement 2: reviews ... | 1.8% | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with Wilson interval on the shipped counts |
| 663 | 291 | 6 Measurement 2: reviews ... | 2.1% | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with Wilson interval on the shipped counts |
| 664 | 291 | 6 Measurement 2: reviews ... | 100 | MATCH | 100 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 665 | 291 | 6 Measurement 2: reviews ... | 924 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped r2_link_sample_output.txt |
| 666 | 291 | 6 Measurement 2: reviews ... | 83% | MATCH | 83 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs; annotat... |  |
| 667 | 291 | 6 Measurement 2: reviews ... | 85% | MATCH | 84.8485 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs; annotat... |  |
| 668 | 291 | 6 Measurement 2: reviews ... | 0.93 | MATCH | 0.927876 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 669 | 291 | 6 Measurement 2: reviews ... | about nine in ten of those concern waiting in the store | MATCH | (0.905, 0.892) | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 670 | 291 | 6 Measurement 2: reviews ... | 12% | MATCH | 11.7494 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs (11.9% a... | approximate wording, accepted within 5% |
| 671 | 291 | 6 Measurement 2: reviews ... | 1.9 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) (1,898,584 k... |
| 672 | 291 | 6 Measurement 2: reviews ... | 11 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 673 | 291 | 6 Measurement 2: reviews ... | 622 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 674 | 291 | 6 Measurement 2: reviews ... | none concerns waiting in a store | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) (label list)... |
| 675 | 291 | 6 Measurement 2: reviews ... | 12 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped analyze_reviews_output.txt (needs the licensed review export, not released) |
| 676 | 291 | 6 Measurement 2: reviews ... | Eight labels name a remedy | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 677 | 291 | 6 Measurement 2: reviews ... | 13,170 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 678 | 291 | 6 Measurement 2: reviews ... | the label for scheduling a store appointment carries none | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 679 | 291 | 6 Measurement 2: reviews ... | no label concerns check-in | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 680 | 293 | 6 Measurement 2: reviews ... | 37,193 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 681 | 293 | 6 Measurement 2: reviews ... | 378 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 682 | 293 | 6 Measurement 2: reviews ... | 42,994 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 683 | 293 | 6 Measurement 2: reviews ... | 1,008 | MATCH | 1008 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 684 | 293 | 6 Measurement 2: reviews ... | 17 | MATCH | 17 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 685 | 293 | 6 Measurement 2: reviews ... | the nine largest of the 17 top-level branches | MATCH | head(9) | data make_fig_reviews_v50.py |  |
| 686 | 295 | 6 Measurement 2: reviews ... | about two in three are correct | MATCH | 0.65 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 687 | 303 | 7.1 Pilot | 12 | MATCH | 12 Oct 22:21-22:26 | data pilot_section_output.txt (shipped) |  |
| 688 | 303 | 7.1 Pilot | 22 | MATCH | 22:21-22:26 | data pilot_section_output.txt (shipped) |  |
| 689 | 303 | 7.1 Pilot | 21 | MATCH | 22:21-22:26 | data pilot_section_output.txt (shipped) |  |
| 690 | 303 | 7.1 Pilot | 22 | MATCH | 22:21-22:26 | data pilot_section_output.txt (shipped) |  |
| 691 | 303 | 7.1 Pilot | 26 | MATCH | 22:21-22:26 | data pilot_section_output.txt (shipped) |  |
| 692 | 303 | 7.1 Pilot | under an hour before the first sector export | CANNOT RUN |  | the export log with the first export's time (23:05) is not released |  |
| 693 | 303 | 7.1 Pilot | six online-learning brands | CANNOT RUN |  | the pilot's brand set and exports are withheld |  |
| 694 | 303 | 7.1 Pilot | the most-cited non-brand domain on all four Google views | CANNOT RUN |  | raw Brand Radar exports not in the bundle (pilot) | agrees with shipped pilot_section_output.txt (the pilot's section of the script and its exports are withheld) |
| 695 | 303 | 7.1 Pilot | 28th on ChatGPT | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped pilot_section_output.txt (the pilot's section of the script and its exports are withheld) |
| 696 | 303 | 7.1 Pilot | 4th on Perplexity | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped pilot_section_output.txt (the pilot's section of the script and its exports are withheld) |
| 697 | 303 | 7.1 Pilot | 5th on Gemini | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped pilot_section_output.txt (the pilot's section of the script and its exports are withheld) |
| 698 | 303 | 7.1 Pilot | 9th on Copilot | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped pilot_section_output.txt (the pilot's section of the script and its exports are withheld) |
| 699 | 303 | 7.1 Pilot | reddit.com in the top three on every surface except Copilot | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped pilot_section_output.txt (the pilot's section of the script and its exports are withheld) |
| 700 | 303 | 7.1 Pilot | 240th | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped pilot_section_output.txt (the pilot's section of the script and its exports are withheld) |
| 701 | 307 | 7.2 Design | 12 | MATCH | design file status line | data design/cross_sector_ai_citation_study.md |  |
| 702 | 307 | 7.2 Design | eight exports that repeated a view or mixed two platforms | MATCH | A2 | data design file |  |
| 703 | 307 | 7.2 Design | 14 | MATCH | 14 of 88 | data design file (Energy 8 surfaces + Utilities 6) |  |
| 704 | 307 | 7.2 Design | 88 | MATCH | 88 | data design file; 11 x 8 |  |
| 705 | 307 | 7.2 Design | 9 | MATCH | holdings as of 9 October 2026 | data design file |  |
| 706 | 307 | 7.2 Design | 109 | MATCH | 109 | data design/cross_sector_companies.csv (rows) |  |
| 707 | 307 | 7.2 Design | 109 companies, because Communication Services counts one issuer, Al... | MATCH | XLC holds 9 companies | data companies CSV and design file |  |
| 708 | 307 | 7.2 Design | 23:05 | CANNOT RUN |  | the export log is not released | start of the collection session |
| 709 | 307 | 7.2 Design | 01:15 | MATCH | 2026-10-13 01:15 | data aggregates/sector_answer_counts.csv read_at_local |  |
| 710 | 307 | 7.2 Design | 01:05 | CANNOT RUN |  | the export log is not released | last export |
| 711 | 307 | 7.2 Design | 01:10 | MATCH | 2026-10-13 01:10 | data sector_answer_counts.csv read_at_local |  |
| 712 | 307 | 7.2 Design | eight vendor views of six answer products | MATCH | 8 surfaces; AIO, AIM, ChatGPT, Perple... | data aggregates |  |
| 713 | 307 | 7.2 Design | 1,000 | MATCH | 1,000 | data cross_sector_cells.csv export_rows |  |
| 714 | 307 | 7.2 Design | 760 | MATCH | 760 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 715 | 307 | 7.2 Design | 975 | MATCH | 975 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 716 | 307 | 7.2 Design | 88 | MATCH | 88 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 717 | 307 | 7.2 Design | 20,389,967 | MATCH | 20,389,967.0 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 718 | 307 | 7.2 Design | 18,763 | MATCH | 18763 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 719 | 307 | 7.2 Design | 7,766,466 | MATCH | 7,766,466.0 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 720 | 307 | 7.2 Design | from 18,763 (Utilities) to 7,766,466 (Consumer Discretionary) | MATCH | xlu, xly | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 726 | 309 | 7.2 Design | nine companies in Communication Services | MATCH | 9 | data companies CSV |  |
| 727 | 309 | 7.2 Design | the seventeen video and community platforms listed | MATCH | 18 domains (x.com and twitter.com are... | data cross_sector.py TYPES |  |
| 728 | 313 | 7.3 Results | 21.3% | MATCH | 21.3411 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 729 | 313 | 7.3 Results | 8.1% | MATCH | 8.0839 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 730 | 313 | 7.3 Results | 35.8% | MATCH | 35.7705 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 731 | 313 | 7.3 Results | 17.2% | MATCH | 17.2 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 732 | 313 | 7.3 Results | 26.7% | MATCH | 26.7 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 733 | 313 | 7.3 Results | 2.1% | MATCH | 2.06095 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 734 | 313 | 7.3 Results | 0.3% | MATCH | 0.334 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 735 | 313 | 7.3 Results | 16.7% | MATCH | 16.685 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 736 | 313 | 7.3 Results | 1.7% | MATCH | 1.7 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 737 | 313 | 7.3 Results | 2.7% | MATCH | 2.7 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 738 | 313 | 7.3 Results | 0.6% | MATCH | 0.558 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 739 | 313 | 7.3 Results | 0.9% | MATCH | 0.894 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 740 | 313 | 7.3 Results | 4.6% | MATCH | 4.6083 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 741 | 313 | 7.3 Results | 9.2% | MATCH | 9.2146 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 742 | 313 | 7.3 Results | In every one of the eleven sectors | MATCH | 11/11 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 743 | 313 | 7.3 Results | 24.6% | MATCH | 24.6181 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 744 | 313 | 7.3 Results | 38 | MATCH | 38 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 745 | 313 | 7.3 Results | 44 | MATCH | 44 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 746 | 313 | 7.3 Results | none of the 44 others | MATCH | 0 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 747 | 313 | 7.3 Results | 44 | MATCH | 44 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 748 | 313 | 7.3 Results | 1 | MATCH | 1 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 749 | 313 | 7.3 Results | 1 on AI Overviews | MATCH | (1, 1) | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 750 | 313 | 7.3 Results | 2 | MATCH | 2 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 751 | 313 | 7.3 Results | 2 on AI Mode | MATCH | (2, 2) | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 752 | 313 | 7.3 Results | 7 | MATCH | 7 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 753 | 313 | 7.3 Results | 7 on Perplexity and Gemini | MATCH | (7, 7) | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 754 | 313 | 7.3 Results | 151 | MATCH | 151 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 755 | 313 | 7.3 Results | 161 | MATCH | 161 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 756 | 313 | 7.3 Results | 12.7% | MATCH | 12.6689 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 757 | 313 | 7.3 Results | 1.6% | MATCH | 1.64725 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 758 | 313 | 7.3 Results | 7 | MATCH | 7 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 759 | 313 | 7.3 Results | 11 | MATCH | 11 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 760 | 313 | 7.3 Results | Gemini ... is the highest of the other four | MATCH | gemini | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 761 | 315 | 7.3 Results | 2.7% | MATCH | 2.66085 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 762 | 315 | 7.3 Results | 3.2% | MATCH | 3.1756 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 763 | 315 | 7.3 Results | 1.1% | MATCH | 1.05055 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 764 | 315 | 7.3 Results | 5.7% | MATCH | 5.6527 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 765 | 315 | 7.3 Results | 14.1% | MATCH | 14.0958 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 766 | 315 | 7.3 Results | the largest classified type on those four was the company domains | MATCH | company domains | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 767 | 315 | 7.3 Results | 61% | MATCH | 61.1058 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 768 | 315 | 7.3 Results | 72% | MATCH | 71.674 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 769 | 315 | 7.3 Results | 90% | MATCH | 89.8952 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 770 | 315 | 7.3 Results | seventeen named video and community platforms | MATCH | 17 platforms, 18 domains | data cross_sector.py TYPES |  |
| 771 | 315 | 7.3 Results | 88 | MATCH | 88 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 772 | 315 | 7.3 Results | 77% | MATCH | 77.3681 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 773 | 315 | 7.3 Results | 70% | MATCH | 70 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 774 | 315 | 7.3 Results | 91% | MATCH | 91 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 775 | 315 | 7.3 Results | 14% | MATCH | 14.1544 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 776 | 315 | 7.3 Results | 5% | MATCH | 5 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 777 | 315 | 7.3 Results | 20% | MATCH | 20 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 778 | 315 | 7.3 Results | 12% | MATCH | 11.6166 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 779 | 315 | 7.3 Results | 73% | MATCH | 72.5967 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 780 | 315 | 7.3 Results | 26% | MATCH | 25.9082 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 781 | 315 | 7.3 Results | 49% | MATCH | 48.5536 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 782 | 315 | 7.3 Results | 40% | MATCH | 40.0106 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 783 | 315 | 7.3 Results | 45% | MATCH | 44.9915 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 784 | 315 | 7.3 Results | 88 | MATCH | 88 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 785 | 317 | 7.3 Results | ChatGPT's most-cited non-company domain by sector (search engine, F... | MATCH | ['google.com', 'fda.gov', 'nerdwallet... | data aggregates/cross_sector_top10_nonbrand.csv |  |
| 786 | 317 | 7.3 Results | 0.36 | MATCH | 0.362118 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 787 | 317 | 7.3 Results | 0.40 | MATCH | 0.403026 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 788 | 317 | 7.3 Results | 55 | MATCH | 55 | arith 11 choose 2 |  |
| 789 | 317 | 7.3 Results | 0.08 | MATCH | 0.0750117 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... | 0.0750 (ChatGPT) |
| 790 | 317 | 7.3 Results | 0.23 | MATCH | 0.226183 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 791 | 317 | 7.3 Results | 22.5% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity2_output.txt (needs the raw exports) |
| 792 | 317 | 7.3 Results | 24.2% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity2_output.txt (needs the raw exports) |
| 793 | 317 | 7.3 Results | 0.23 | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity2_output.txt (needs the raw exports) (smallest p of the four ch... |
| 794 | 317 | 7.3 Results | 0.63 | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity2_output.txt (needs the raw exports) (largest p) |
| 795 | 317 | 7.3 Results | 94% | CANNOT RUN |  | raw Brand Radar exports not in the bundle (all-surface export) | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports); Sherwin-Williams |
| 796 | 317 | 7.3 Results | 75% | CANNOT RUN |  | raw Brand Radar exports not in the bundle (all-surface export) | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports); Amazon |
| 797 | 317 | 7.3 Results | 65% | CANNOT RUN |  | raw Brand Radar exports not in the bundle (all-surface export) | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports); Walmart |
| 798 | 317 | 7.3 Results | 62% | CANNOT RUN |  | raw Brand Radar exports not in the bundle (all-surface export) | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports); Apple |
| 799 | 317 | 7.3 Results | 55% | CANNOT RUN |  | raw Brand Radar exports not in the bundle (all-surface export) | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports); Uber |
| 800 | 317 | 7.3 Results | go.com, chase.com and mobil.com among ChatGPT's top three | MATCH | xlc go.com, xlf chase.com, xle mobil.com | data cross_sector_top10_nonbrand.csv |  |
| 801 | 321 | 7.4 The predictions writt... | 9 | MATCH | 9 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 802 | 321 | 7.4 The predictions writt... | 11 | MATCH | 11 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 803 | 321 | 7.4 The predictions writt... | 8 | MATCH | 8 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 804 | 321 | 7.4 The predictions writt... | 11 | MATCH | 11 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 805 | 321 | 7.4 The predictions writt... | 2 | MATCH | 2 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 806 | 321 | 7.4 The predictions writt... | 2 of 11 on each | MATCH | (2, 2) | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 807 | 321 | 7.4 The predictions writt... | 11 | MATCH | 11 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 808 | 321 | 7.4 The predictions writt... | P1 fails as written | MATCH | 4/11 sectors on both products | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 809 | 321 | 7.4 The predictions writt... | 93% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity2_output.txt (needs the raw exports) |
| 810 | 321 | 7.4 The predictions writt... | 98% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity2_output.txt (needs the raw exports) |
| 811 | 321 | 7.4 The predictions writt... | 9 | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 812 | 321 | 7.4 The predictions writt... | 11 | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 813 | 321 | 7.4 The predictions writt... | It fails under every domain reduction tried | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) (both products 4/11, 4/11, ... |
| 814 | 321 | 7.4 The predictions writt... | 11 | MATCH | 11 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 815 | 321 | 7.4 The predictions writt... | 6 | MATCH | 6 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 816 | 321 | 7.4 The predictions writt... | 11 | MATCH | 11 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 817 | 321 | 7.4 The predictions writt... | 11 | MATCH | 11 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 818 | 321 | 7.4 The predictions writt... | 3 | MATCH | 3 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 819 | 321 | 7.4 The predictions writt... | 11 | MATCH | 11 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 820 | 321 | 7.4 The predictions writt... | ChatGPT was a failing surface in all eight sectors where it did not... | MATCH | 8 of 8 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 821 | 321 | 7.4 The predictions writt... | five consumer-facing sectors than in five others | MATCH | 5 and 5, Financials in neither | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 822 | 321 | 7.4 The predictions writt... | 26.9% | MATCH | 26.9348 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 823 | 321 | 7.4 The predictions writt... | 24.2% | MATCH | 24.1714 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 824 | 321 | 7.4 The predictions writt... | 29.6% | MATCH | 29.5982 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 825 | 321 | 7.4 The predictions writt... | 24.4% | MATCH | 24.3983 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 826 | 321 | 7.4 The predictions writt... | 0.27 | MATCH | 0.27381 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 827 | 321 | 7.4 The predictions writt... | 0.21 | MATCH | 0.210317 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 828 | 321 | 7.4 The predictions writt... | Of the four, one held, one held in direction only and two failed | MATCH | P1 fail, P2 hold, P3 fail, P4 directi... | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 829 | 325 | 7.5 Sensitivity | 21.5% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 830 | 325 | 7.5 Sensitivity | 3.3% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 831 | 325 | 7.5 Sensitivity | 11 | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 833 | 325 | 7.5 Sensitivity | 22.0% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 834 | 325 | 7.5 Sensitivity | 2.4% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 835 | 325 | 7.5 Sensitivity | 11 | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 837 | 325 | 7.5 Sensitivity | 19.8% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 838 | 325 | 7.5 Sensitivity | 2.1% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 839 | 325 | 7.5 Sensitivity | 10 | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 841 | 325 | 7.5 Sensitivity | 64 | MATCH | 64 | data design/cross_sector_company_properties.csv (rows) | the design file also says 64 |
| 842 | 325 | 7.5 Sensitivity | 20.2% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 843 | 325 | 7.5 Sensitivity | 32.4% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 844 | 325 | 7.5 Sensitivity | 5.9% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 845 | 325 | 7.5 Sensitivity | 12.7% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 846 | 325 | 7.5 Sensitivity | 9.2% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 847 | 325 | 7.5 Sensitivity | Gemini's 9.2% exceeds AI Mode on search queries | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 849 | 325 | 7.5 Sensitivity | 30.6% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 850 | 325 | 7.5 Sensitivity | 3.0% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 852 | 325 | 7.5 Sensitivity | 26.3% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 853 | 325 | 7.5 Sensitivity | 2.6% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 855 | 325 | 7.5 Sensitivity | 23.3% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 856 | 325 | 7.5 Sensitivity | 2.3% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 857 | 325 | 7.5 Sensitivity | the ratio between the two groups stays near ten | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 858 | 325 | 7.5 Sensitivity | 7.6% | MATCH | 7.5922 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 859 | 325 | 7.5 Sensitivity | 13.8% | MATCH | 13.8135 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 860 | 329 | 7.6 Limits | 31.3% | MATCH | 31.2812 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 861 | 329 | 7.6 Limits | 30.1% | MATCH | 30.1491 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 862 | 329 | 7.6 Limits | YouTube's rank stayed 1 on AI Overviews | MATCH | 1 -> 1 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 863 | 329 | 7.6 Limits | 1 | MATCH | 1 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 864 | 329 | 7.6 Limits | 2 | MATCH | 2 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 865 | 329 | 7.6 Limits | 1 | MATCH | 1 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 866 | 329 | 7.6 Limits | 6.2% | MATCH | 6.2045 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 867 | 329 | 7.6 Limits | 5.5% | MATCH | 5.4848 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 868 | 329 | 7.6 Limits | 15.0% | MATCH | 15.0291 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 869 | 329 | 7.6 Limits | 13.4% | MATCH | 13.4491 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 870 | 329 | 7.6 Limits | Copilot's top non-company domain from amazon.com to a flight-route ... | MATCH | amazon.com -> flightconnections.com | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 871 | 329 | 7.6 Limits | its ChatGPT export failed twice on the vendor's side | MATCH | no xli_rtxcorp ChatGPT row | data design file A2 and aggregates |  |
| 872 | 329 | 7.6 Limits | 0.8% | MATCH | 0.77755 | recomputed from aggregates/cross_sector_platform_metrics.csv (ChatGPT median without In... | agrees with shipped sensitivity outputs |
| 873 | 329 | 7.6 Limits | 10 | MATCH | 10 | recomputed from aggregates (P2 without Industrials, ChatGPT) |  |
| 874 | 329 | 7.6 Limits | 10 | MATCH | 10 | denominator: ten sectors without Industrials |  |
| 875 | 329 | 7.6 Limits | P2 holds on ChatGPT and Copilot in 10 of 10 | MATCH | (10, 10) | recomputed from aggregates |  |
| 876 | 329 | 7.6 Limits | 6 | MATCH | 6 | recomputed from aggregates |  |
| 877 | 329 | 7.6 Limits | 10 | MATCH | 10 | denominator |  |
| 878 | 329 | 7.6 Limits | 3 | MATCH | 3 | recomputed from aggregates (P3 without Industrials) |  |
| 879 | 329 | 7.6 Limits | 10 | MATCH | 10 | denominator |  |
| 880 | 329 | 7.6 Limits | 2.2% | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) (largest of the eight Finan... |
| 881 | 329 | 7.6 Limits | four immigration and border domains of the US government | CANNOT RUN |  | raw Brand Radar exports not in the bundle | agrees with shipped cross_sector_sensitivity_output.txt (needs the raw exports) |
| 882 | 329 | 7.6 Limits | 25 | MATCH | 25 | data design file (company-property screen) |  |
| 883 | 329 | 7.6 Limits | two possible further cases | CANNOT RUN |  | raw Brand Radar exports not in the bundle | domain-level screen of the raw exports |
| 884 | 329 | 7.6 Limits | 860 | MATCH | 860 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 885 | 329 | 7.6 Limits | 18,381,848 | MATCH | 18,381,848.0 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 888 | 329 | 7.6 Limits | 4.6% | MATCH | 4.6083 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 889 | 331 | 7.6 Limits | about ten times the pooled median share of the other four surfaces | MATCH | 10.355 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 890 | 331 | 7.6 Limits | more than twice Gemini's | MATCH | 2.31601 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 891 | 331 | 7.6 Limits | news, government and company sources vary more by sector | MATCH | sector > surface | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 892 | 335 | 8 The deployment series | 381 | MATCH | 381 | data section_code_pages_2026-10-14.csv |  |
| 894 | 339 | 8 The deployment series | 26 | MATCH | 2026-07-26 | arith day 0 = 26 July + 0 days |  |
| 895 | 339 | 8 The deployment series | 10 | MATCH | 2026-08-10 | arith day 15 = 26 July + 15 days |  |
| 896 | 339 | 8 The deployment series | 25 | MATCH | 2026-08-25 | arith day 30 = 26 July + 30 days |  |
| 897 | 339 | 8 The deployment series | 1 | MATCH | 2026-09-01 | arith day 37 = 26 July + 37 days |  |
| 898 | 339 | 8 The deployment series | 9 | MATCH | 2026-09-09 | arith day 45 = 26 July + 45 days |  |
| 899 | 339 | 8 The deployment series | 24 | MATCH | 2026-09-24 | arith day 60 = 26 July + 60 days |  |
| 900 | 339 | 8 The deployment series | 9 | MATCH | 2026-10-09 | arith day 75 = 26 July + 75 days |  |
| 901 | 339 | 8 The deployment series | 11 | MATCH | 2026-10-11 | arith day 77 = 26 July + 77 days |  |
| 902 | 341 | 8 The deployment series | 2 | MATCH | 2 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 903 | 341 | 8 The deployment series | 210 | MATCH | 210 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 904 | 341 | 8 The deployment series | 365 | MATCH | 365 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 905 | 341 | 8 The deployment series | 391 | MATCH | 391 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 906 | 341 | 8 The deployment series | 414 | MATCH | 414 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 907 | 341 | 8 The deployment series | 440 | MATCH | 440 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 908 | 341 | 8 The deployment series | 441 | MATCH | 441 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 909 | 342 | 8 The deployment series | 2 | MATCH | 2 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 2 |
| 910 | 342 | 8 The deployment series | 3,385 | MATCH | 3385 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 3385 |
| 911 | 342 | 8 The deployment series | 14,905 | MATCH | 14905 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 14905 |
| 912 | 342 | 8 The deployment series | 15,830 | MATCH | 15830 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 15830 |
| 913 | 342 | 8 The deployment series | 20,326 | MATCH | 20326 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 20326 |
| 914 | 342 | 8 The deployment series | 37,141 | MATCH | 37141 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 37141 |
| 915 | 342 | 8 The deployment series | 43,302 | MATCH | 43302 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 43302 |
| 916 | 342 | 8 The deployment series | 43,980 | MATCH | 43980 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 43980 |
| 917 | 343 | 8 The deployment series | 0 | MATCH | 0 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 0 |
| 918 | 343 | 8 The deployment series | 727 | MATCH | 727 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 727 |
| 919 | 343 | 8 The deployment series | 1,801 | MATCH | 1801 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 1801 |
| 920 | 343 | 8 The deployment series | 1,874 | MATCH | 1874 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 1874 |
| 921 | 343 | 8 The deployment series | 2,649 | MATCH | 2649 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 2649 |
| 922 | 343 | 8 The deployment series | 5,822 | MATCH | 5822 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 5822 |
| 923 | 343 | 8 The deployment series | 8,753 | MATCH | 8753 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 8753 |
| 924 | 343 | 8 The deployment series | 9,239 | MATCH | 9239 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) | make_figs_v4.py constant 9239 |
| 925 | 344 | 8 The deployment series | 1 | MATCH | 1 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 926 | 344 | 8 The deployment series | 1,494 | MATCH | 1494 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 927 | 344 | 8 The deployment series | 10,151 | MATCH | 10151 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 928 | 344 | 8 The deployment series | 15,104 | MATCH | 15104 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 929 | 344 | 8 The deployment series | 28,733 | MATCH | 28733 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 930 | 344 | 8 The deployment series | 33,203 | MATCH | 33203 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 931 | 344 | 8 The deployment series | 33,560 | MATCH | 33560 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 932 | 345 | 8 The deployment series | 0 | MATCH | 0 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 933 | 345 | 8 The deployment series | 909 | MATCH | 909 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 934 | 345 | 8 The deployment series | 2,639 | MATCH | 2639 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 935 | 345 | 8 The deployment series | 2,331 | MATCH | 2331 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 936 | 345 | 8 The deployment series | 2,336 | MATCH | 2336 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 937 | 345 | 8 The deployment series | 1,276 | MATCH | 1276 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 938 | 346 | 8 The deployment series | 1 | MATCH | 1 | arith total - (1-3) - (4-10) - (11-20) |  |
| 939 | 346 | 8 The deployment series | 255 | MATCH | 255 | arith total - (1-3) - (4-10) - (11-20) |  |
| 940 | 346 | 8 The deployment series | 314 | MATCH | 314 | arith total - (1-3) - (4-10) - (11-20) |  |
| 941 | 346 | 8 The deployment series | 242 | MATCH | 242 | arith total - (1-3) - (4-10) - (11-20) |  |
| 942 | 346 | 8 The deployment series | 250 | MATCH | 250 | arith total - (1-3) - (4-10) - (11-20) |  |
| 943 | 346 | 8 The deployment series | 70 | MATCH | 70 | arith total - (1-3) - (4-10) - (11-20) |  |
| 944 | 347 | 8 The deployment series | 2 | MATCH | 2 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 945 | 347 | 8 The deployment series | 22,016 | MATCH | 22016 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 946 | 347 | 8 The deployment series | 51,517 | MATCH | 51517 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 947 | 347 | 8 The deployment series | 51,800 | MATCH | 51800 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 948 | 347 | 8 The deployment series | 92,897 | MATCH | 92897 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 949 | 347 | 8 The deployment series | 244,041 | MATCH | 244,041.0 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 950 | 347 | 8 The deployment series | 221,933 | MATCH | 221,933.0 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 951 | 348 | 8 The deployment series | 0 | MATCH | 0 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 952 | 348 | 8 The deployment series | 1 | MATCH | 1 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 953 | 348 | 8 The deployment series | 19 | MATCH | 19 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 954 | 348 | 8 The deployment series | 19 | MATCH | 19 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 955 | 348 | 8 The deployment series | 415 | MATCH | 415 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 956 | 348 | 8 The deployment series | 828 | MATCH | 828 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 957 | 348 | 8 The deployment series | 909 | MATCH | 909 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 958 | 348 | 8 The deployment series | 913 | MATCH | 913 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 959 | 349 | 8 The deployment series | 0 | MATCH | 0 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 960 | 349 | 8 The deployment series | 1,603 | MATCH | 1603 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 961 | 349 | 8 The deployment series | 3,725 | MATCH | 3725 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 962 | 349 | 8 The deployment series | 6,390 | MATCH | 6390 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 963 | 349 | 8 The deployment series | 10,266 | MATCH | 10266 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 964 | 349 | 8 The deployment series | 14,823 | MATCH | 14823 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 965 | 349 | 8 The deployment series | 17,206 | MATCH | 17206 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 966 | 351 | 8 The deployment series | the instrument reports only three bands and the total | MATCH | rows 1-3, 4-10, 11-20, total | manuscript Table 5 |  |
| 967 | 353 | 8 The deployment series | The estimated-visits peak at day 60 | MATCH | day 60 (244,041) | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 968 | 355 | 8 The deployment series | 15,830 | MATCH | 15830 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 969 | 355 | 8 The deployment series | 1,874 | MATCH | 1874 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 970 | 355 | 8 The deployment series | 51,800 | MATCH | 51800 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 971 | 355 | 8 The deployment series | nineteen referring domains | MATCH | 19 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 972 | 355 | 8 The deployment series | 43,980 | MATCH | 43980 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 973 | 355 | 8 The deployment series | 441 | MATCH | 441 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 974 | 355 | 8 The deployment series | 29,000 | MATCH | 29000 | data single_reads_2026-10.csv |  |
| 975 | 355 | 8 The deployment series | 58,586 | MATCH | 58586 | data single_reads_2026-10.csv |  |
| 976 | 355 | 8 The deployment series | 7,455 | MATCH | 7455 | data Table 3 series CSV (October numerator) |  |
| 977 | 355 | 8 The deployment series | 17,206 | MATCH | 17206 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 978 | 357 | 8 The deployment series | 441 | MATCH | 441 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 979 | 357 | 8 The deployment series | 11 | MATCH | 2026-10-11 | data single_reads_2026-10.csv (read date) |  |
| 980 | 357 | 8 The deployment series | 22.8% | MATCH | 22.8 | data single_reads_2026-10.csv |  |
| 982 | 357 | 8 The deployment series | 64.9% | MATCH | 64.9 | data single_reads_2026-10.csv |  |
| 983 | 357 | 8 The deployment series | 441 | MATCH | 441 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 984 | 357 | 8 The deployment series | 11% | MATCH | 11.3379 | arith 50 / 441 |  |
| 985 | 357 | 8 The deployment series | about two thirds of the estimated traffic | MATCH | 64.9% | data single_reads_2026-10.csv |  |
| 986 | 359 | 8 The deployment series | 58,586 | MATCH | 58586 | data single_reads_2026-10.csv |  |
| 987 | 359 | 8 The deployment series | 40 | MATCH | 40 to 170, or none | data single_reads_2026-10.csv |  |
| 988 | 359 | 8 The deployment series | 170 | MATCH | 40 to 170, or none | data single_reads_2026-10.csv |  |
| 989 | 359 | 8 The deployment series | 105 | MATCH | 105 | data single_reads_2026-10.csv |  |
| 990 | 359 | 8 The deployment series | 18.5% | MATCH | 18.5 | data single_reads_2026-10.csv |  |
| 991 | 365 | 9.1 Enumerating pages are... | 474 | MATCH | 474 | data single_reads_2026-10.csv (and make_figs_v4.py, Figure 8) |  |
| 992 | 365 | 9.1 Enumerating pages are... | 337 | MATCH | 337 | data single_reads_2026-10.csv (and make_figs_v4.py, Figure 8) |  |
| 993 | 365 | 9.1 Enumerating pages are... | 322 | MATCH | 322 | data single_reads_2026-10.csv (and make_figs_v4.py, Figure 8) |  |
| 994 | 365 | 9.1 Enumerating pages are... | 304 | MATCH | 304 | data single_reads_2026-10.csv (and make_figs_v4.py, Figure 8) |  |
| 995 | 365 | 9.1 Enumerating pages are... | 294 | MATCH | 294 | data single_reads_2026-10.csv (and make_figs_v4.py, Figure 8) |  |
| 996 | 365 | 9.1 Enumerating pages are... | 238 | MATCH | 238 | data single_reads_2026-10.csv (and make_figs_v4.py, Figure 8) |  |
| 997 | 365 | 9.1 Enumerating pages are... | 228 | MATCH | 228 | data single_reads_2026-10.csv (and make_figs_v4.py, Figure 8) |  |
| 998 | 365 | 9.1 Enumerating pages are... | 218 | MATCH | 218 | data single_reads_2026-10.csv (and make_figs_v4.py, Figure 8) |  |
| 999 | 365 | 9.1 Enumerating pages are... | 214 | MATCH | TX | data section_code_pages_2026-10-14.csv; area code 214 in TX |  |
| 1000 | 365 | 9.1 Enumerating pages are... | 786 | MATCH | FL | data section_code_pages_2026-10-14.csv; area code 786 in FL |  |
| 1001 | 365 | 9.1 Enumerating pages are... | 404 | MATCH | GA | data section_code_pages_2026-10-14.csv; area code 404 in GA |  |
| 1002 | 365 | 9.1 Enumerating pages are... | per code it lists, a state hub is cited less often than the most-ci... | MATCH | {'NY': 20.6, 'CA': 8.2, 'TX': 11.1, '... | data single_reads_2026-10.csv and data section_code_pages_2026-10-14.csv (codes per state) |  |
| 1003 | 367 | 9.1 Enumerating pages are... | The eight pages | MATCH | 8 | data make_figs_v4.py Figure 8 data |  |
| 1004 | 369 | 9.1 Enumerating pages are... | 1.0 | MATCH | Appendix B rubric | internal consistency with Appendix B (the rubric itself is in the ufi repository, not i... |  |
| 1006 | 375 | 9.2 Who else is cited, an... | five domains with the largest keyword overlap | MATCH | Domain Rating of the five domains wit... | data single_reads_2026-10.csv |  |
| 1007 | 375 | 9.2 Who else is cited, an... | 13 | MATCH | 13 to 83 | data single_reads_2026-10.csv |  |
| 1008 | 375 | 9.2 Who else is cited, an... | 83 | MATCH | 13 to 83 | data single_reads_2026-10.csv |  |
| 1009 | 375 | 9.2 Who else is cited, an... | 97 | MATCH | 97 | data single_reads_2026-10.csv |  |
| 1010 | 375 | 9.2 Who else is cited, an... | 11,000 | MATCH | 11000 | data single_reads_2026-10.csv ('about 11,000') |  |
| 1011 | 375 | 9.2 Who else is cited, an... | 9 | MATCH | 9 | data single_reads_2026-10.csv |  |
| 1012 | 375 | 9.2 Who else is cited, an... | 91 | MATCH | 91 | data single_reads_2026-10.csv (the single read is recorded for the carrier at Domain Ra... |  |
| 1013 | 375 | 9.2 Who else is cited, an... | 240 | MATCH | 240 | data single_reads_2026-10.csv |  |
| 1014 | 375 | 9.2 Who else is cited, an... | 87 | MATCH | 87 | data single_reads_2026-10.csv (the single read is recorded for the carrier at Domain Ra... |  |
| 1015 | 375 | 9.2 Who else is cited, an... | 17,206 | MATCH | 17206 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1016 | 383 | 10 The link profile | zero live referring domains through 31 July | MATCH | 0 on days 0 to 5 | data single_reads_2026-10.csv |  |
| 1017 | 383 | 10 The link profile | 31 | MATCH | 2026-07-31 | arith day 5 |  |
| 1018 | 383 | 10 The link profile | one on 10 August | MATCH | 1 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1019 | 383 | 10 The link profile | 10 | MATCH | 2026-08-10 | arith day 15 |  |
| 1020 | 383 | 10 The link profile | nineteen on 25 August | MATCH | 19 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1021 | 383 | 10 The link profile | 25 | MATCH | 2026-08-25 | arith day 30 |  |
| 1022 | 383 | 10 The link profile | still nineteen on 1 September | MATCH | 19 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1023 | 383 | 10 The link profile | 1 | MATCH | 2026-09-01 | arith day 37 |  |
| 1024 | 383 | 10 The link profile | 15,830 | MATCH | 15830 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1025 | 385 | 10 The link profile | 11 | MATCH | 2026-10-11 | data single_reads_2026-10.csv (read date of 913) |  |
| 1026 | 385 | 10 The link profile | 913 | MATCH | 913 | data single_reads_2026-10.csv |  |
| 1027 | 385 | 10 The link profile | 909 | MATCH | 909 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1028 | 385 | 10 The link profile | 917 | MATCH | 917 | data single_reads_2026-10.csv |  |
| 1029 | 385 | 10 The link profile | 95 | MATCH | 95 | data single_reads_2026-10.csv |  |
| 1030 | 385 | 10 The link profile | nineteen at day 37 | MATCH | 19 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1031 | 385 | 10 The link profile | 841 | MATCH | 841 | arith 19 + 917 - 95 |  |
| 1032 | 385 | 10 The link profile | several hundred within three weeks | MATCH | 828 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1033 | 385 | 10 The link profile | roughly nine hundred by day 75 | MATCH | 909 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1034 | 387 | 10 The link profile | 61.9% | MATCH | 61.9 | data single_reads_2026-10.csv |  |
| 1035 | 387 | 10 The link profile | 26.4% | MATCH | 26.4 | data single_reads_2026-10.csv |  |
| 1036 | 387 | 10 The link profile | 10.2% | MATCH | 10.2 | data single_reads_2026-10.csv |  |
| 1037 | 387 | 10 The link profile | 10 | MATCH | every linking page below 10 | data single_reads_2026-10.csv |  |
| 1038 | 387 | 10 The link profile | 80 | MATCH | 80 | data single_reads_2026-10.csv |  |
| 1039 | 387 | 10 The link profile | 88% | MATCH | 88 | data single_reads_2026-10.csv |  |
| 1040 | 387 | 10 The link profile | 0 | MATCH | 0 to 10 | data single_reads_2026-10.csv |  |
| 1041 | 387 | 10 The link profile | 10 | MATCH | 0 to 10 | data single_reads_2026-10.csv |  |
| 1042 | 387 | 10 The link profile | 75% | MATCH | 75 | data single_reads_2026-10.csv |  |
| 1043 | 395 | 10.1 What the link profil... | 0 | MATCH | 0 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) (referr... |  |
| 1044 | 395 | 10.1 What the link profil... | 1 | MATCH | 1 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) (at the... |  |
| 1045 | 395 | 10.1 What the link profil... | 1 | MATCH | 1 | arith Table 5 referring domains, end - start |  |
| 1046 | 395 | 10.1 What the link profil... | 3,383 | MATCH | 3383 | arith Table 5 positions, end - start |  |
| 1047 | 395 | 10.1 What the link profil... | 226 | MATCH | 225.533 | arith positions gained / 15 days |  |
| 1048 | 396 | 10.1 What the link profil... | 1 | MATCH | 1 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) (referr... |  |
| 1049 | 396 | 10.1 What the link profil... | 19 | MATCH | 19 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) (at the... |  |
| 1050 | 396 | 10.1 What the link profil... | 18 | MATCH | 18 | arith Table 5 referring domains, end - start |  |
| 1051 | 396 | 10.1 What the link profil... | 11,520 | MATCH | 11520 | arith Table 5 positions, end - start |  |
| 1052 | 396 | 10.1 What the link profil... | 768 | MATCH | 768 | arith positions gained / 15 days |  |
| 1053 | 397 | 10.1 What the link profil... | 19 | MATCH | 19 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) (referr... |  |
| 1054 | 397 | 10.1 What the link profil... | 19 | MATCH | 19 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) (at the... |  |
| 1055 | 397 | 10.1 What the link profil... | 0 | MATCH | 0 | arith Table 5 referring domains, end - start |  |
| 1056 | 397 | 10.1 What the link profil... | 925 | MATCH | 925 | arith Table 5 positions, end - start |  |
| 1057 | 397 | 10.1 What the link profil... | 132 | MATCH | 132.143 | arith positions gained / 7 days |  |
| 1058 | 398 | 10.1 What the link profil... | 19 | MATCH | 19 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) (referr... |  |
| 1059 | 398 | 10.1 What the link profil... | 415 | MATCH | 415 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) (at the... |  |
| 1060 | 398 | 10.1 What the link profil... | 396 | MATCH | 396 | arith Table 5 referring domains, end - start |  |
| 1061 | 398 | 10.1 What the link profil... | 4,496 | MATCH | 4496 | arith Table 5 positions, end - start |  |
| 1062 | 398 | 10.1 What the link profil... | 562 | MATCH | 562 | arith positions gained / 8 days |  |
| 1063 | 399 | 10.1 What the link profil... | 415 | MATCH | 415 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) (referr... |  |
| 1064 | 399 | 10.1 What the link profil... | 828 | MATCH | 828 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) (at the... |  |
| 1065 | 399 | 10.1 What the link profil... | 413 | MATCH | 413 | arith Table 5 referring domains, end - start |  |
| 1066 | 399 | 10.1 What the link profil... | 16,815 | MATCH | 16815 | arith Table 5 positions, end - start |  |
| 1067 | 399 | 10.1 What the link profil... | 1,121 | MATCH | 1121 | arith positions gained / 15 days |  |
| 1068 | 400 | 10.1 What the link profil... | 828 | MATCH | 828 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) (referr... |  |
| 1069 | 400 | 10.1 What the link profil... | 909 | MATCH | 909 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) (at the... |  |
| 1070 | 400 | 10.1 What the link profil... | 81 | MATCH | 81 | arith Table 5 referring domains, end - start |  |
| 1071 | 400 | 10.1 What the link profil... | 6,161 | MATCH | 6161 | arith Table 5 positions, end - start |  |
| 1072 | 400 | 10.1 What the link profil... | 411 | MATCH | 410.733 | arith positions gained / 15 days |  |
| 1073 | 402 | 10.1 What the link profil... | 984 | MATCH | 984 | data single_reads_2026-10.csv and make_figs_v4.py |  |
| 1074 | 402 | 10.1 What the link profil... | 186 | MATCH | 186 | data single_reads_2026-10.csv and make_figs_v4.py |  |
| 1075 | 402 | 10.1 What the link profil... | 38,801 | MATCH | 38801 | data single_reads_2026-10.csv and make_figs_v4.py |  |
| 1076 | 402 | 10.1 What the link profil... | 6,942 | MATCH | 6942 | data single_reads_2026-10.csv and make_figs_v4.py |  |
| 1077 | 404 | 10.1 What the link profil... | 43,302 | MATCH | 43302 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1078 | 404 | 10.1 What the link profil... | 15,830 | MATCH | 15830 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1079 | 404 | 10.1 What the link profil... | 36.6% | MATCH | 36.5572 | arith 15,830 / 43,302 |  |
| 1080 | 404 | 10.1 What the link profil... | 27,472 | MATCH | 27472 | arith 43,302 - 15,830 |  |
| 1081 | 404 | 10.1 What the link profil... | 63.4% | MATCH | 63.4428 | arith |  |
| 1082 | 404 | 10.1 What the link profil... | an eight-day interval | MATCH | 8 | arith day 37 to day 45 |  |
| 1083 | 404 | 10.1 What the link profil... | 53.1% | MATCH | 53.0599 | arith (43,302 - 20,326) / 43,302 |  |
| 1084 | 404 | 10.1 What the link profil... | 63.4% | MATCH | 63.4428 | arith |  |
| 1085 | 404 | 10.1 What the link profil... | 56.9% | MATCH | 56.8913 | arith (14,823 - 6,390) / 14,823 |  |
| 1086 | 404 | 10.1 What the link profil... | 74.9% | MATCH | 74.8701 | arith (14,823 - 3,725) / 14,823 |  |
| 1087 | 406 | 10.1 What the link profil... | 15,830 | MATCH | 15830 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1088 | 406 | 10.1 What the link profil... | 1,874 | MATCH | 1874 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1089 | 406 | 10.1 What the link profil... | nineteen referring domains, a count unchanged for the preceding week | MATCH | 19 at day 30 and day 37 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1090 | 410 | 10.1 What the link profil... | 768 | MATCH | 768 | arith Table 6 |  |
| 1091 | 410 | 10.1 What the link profil... | 37% | MATCH | 36.6548 | arith 768 / 562 - 1 |  |
| 1092 | 410 | 10.1 What the link profil... | 562 | MATCH | 562 | arith Table 6 |  |
| 1093 | 410 | 10.1 What the link profil... | 132 | MATCH | 132.143 | arith Table 6 |  |
| 1094 | 410 | 10.1 What the link profil... | that baseline sits at the series minimum | MATCH | 132 | arith Table 6 |  |
| 1095 | 410 | 10.1 What the link profil... | all six intervals | MATCH | 6 | Table 6 |  |
| 1096 | 410 | 10.1 What the link profil... | 441 | MATCH | 441 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1097 | 424 | 11.1 Cost | 3 | CANNOT RUN |  | author's reconstruction from unreleased project records | ≈ 3 person-weeks |
| 1098 | 425 | 11.1 Cost | 2 | CANNOT RUN |  | author's reconstruction from unreleased project records | ≈ 2 person-weeks |
| 1099 | 426 | 11.1 Cost | 0 | CANNOT RUN |  | author's reconstruction | ≈ 0 marginal production cost |
| 1100 | 427 | 11.1 Cost | 0 | CANNOT RUN |  | author's reconstruction | editorial and link acquisition 0 |
| 1101 | 428 | 11.1 Cost | 6,000 | CANNOT RUN |  | author's reconstruction | ≈ USD 6,000 / year |
| 1102 | 439 | 11.2 Six lessons, stated ... | of the thirteen demand-surface types | MATCH | 13 | data make_fig0.py (13 surfaces) |  |
| 1103 | 439 | 11.2 Six lessons, stated ... | four of the thirteen surface types | CANNOT RUN |  | the ufi repository's example is not in the bundle | synthetic records in the released example |
| 1104 | 446 | 12 Threats to validity | 65 | MATCH | 2026-09-29 | arith day 65 = 29 September, the notice date of Section 4.3 |  |
| 1105 | 446 | 12 Threats to validity | 75 | MATCH | 2026-10-09 | arith day 75 = 9 October, the last daily read |  |
| 1106 | 446 | 12 Threats to validity | 2.94 | MATCH | 2.93617 | arith Table 3 |  |
| 1107 | 446 | 12 Threats to validity | 1.34 | MATCH | 1.3438 | arith Table 3 |  |
| 1108 | 446 | 12 Threats to validity | 77 | MATCH | 77 | arith |  |
| 1109 | 448 | 12 Threats to validity | about two in three correct, half for single-word labels | MATCH | (0.65, 0.48031496062992124) | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 1110 | 452 | 12 Threats to validity | 53.1% | MATCH | 53.0599 | arith |  |
| 1111 | 452 | 12 Threats to validity | 63.4% | MATCH | 63.4428 | arith |  |
| 1112 | 452 | 12 Threats to validity | 77 | MATCH | 77 | arith |  |
| 1113 | 460 | 13 What would test what t... | 1.2 | MATCH | 1.23529 | data single_reads_2026-10.csv |  |
| 1114 | 460 | 13 What would test what t... | 2.0 | MATCH | 1.9916 | data single_reads_2026-10.csv |  |
| 1115 | 462 | 13 What would test what t... | 924 | CANNOT RUN |  | the ufi repository (examples/nanp/out/) is not in the bundle |  |
| 1116 | 462 | 13 What would test what t... | 66 | CANNOT RUN |  | the ufi repository is not in the bundle |  |
| 1117 | 464 | 13 What would test what t... | 0.5 | CANNOT RUN |  | parameter lock in the ufi repository, not in the bundle | alpha |
| 1118 | 464 | 13 What would test what t... | 0.5 | CANNOT RUN |  | parameter lock in the ufi repository | beta |
| 1119 | 464 | 13 What would test what t... | 0.85 | CANNOT RUN |  | parameter lock in the ufi repository | damping |
| 1120 | 466 | 13 What would test what t... | 372 | MATCH | 372 | data section_code_pages_2026-10-14.csv |  |
| 1122 | 466 | 13 What would test what t... | 971,506 | MATCH | ['971506'] | data protocols_manifest.txt.ots and framework_test_r1 .ots proofs, parsed (ots_parse.py) |  |
| 1123 | 466 | 13 What would test what t... | 04 | MATCH | 2026-10-15T04:05:42Z | external block explorer (blockstream.info), the check protocols/README.md prescribes | merkle root equal to the proofs' |
| 1124 | 466 | 13 What would test what t... | 05 | MATCH | 2026-10-15T04:05:42Z | external block explorer (blockstream.info) |  |
| 1125 | 472 | 13 What would test what t... | 10,000 | MATCH | A1 | data design file |  |
| 1126 | 472 | 13 What would test what t... | 10,000 | MATCH | A1 | data design file | first 10,000 rows in default order (A2/A3) |
| 1127 | 472 | 13 What would test what t... | 14 | MATCH | 14 of 88 | data design file |  |
| 1128 | 472 | 13 What would test what t... | 88 | MATCH | 14 of 88 | data design file |  |
| 1129 | 472 | 13 What would test what t... | 44,463 | MATCH | 44,463 rows | data design file | the paper says answers, the design file says rows |
| 1130 | 472 | 13 What would test what t... | two small sectors, Energy and Utilities | MATCH | Energy 8 + Utilities 6 = 14 | data design file |  |
| 1135 | 482 | 13.1 Further directions | over the same four years | MATCH | 4 | arith 2021 to 2025 |  |
| 1138 | 486 | 13.1 Further directions | 109 | MATCH | 109 | data companies CSV |  |
| 1139 | 490 | 14 Reproducibility, ethic... | 22 | CANNOT RUN |  | the ufi repository's commit history is not in the bundle |  |
| 1140 | 490 | 14 Reproducibility, ethic... | 21 | CANNOT RUN |  | the ufi repository's commit history is not in the bundle |  |
| 1141 | 490 | 14 Reproducibility, ethic... | 924 | CANNOT RUN |  | the ufi repository is not in the bundle |  |
| 1142 | 492 | 14 Reproducibility, ethic... | 109 | MATCH | 109 | data companies CSV |  |
| 1143 | 494 | 14 Reproducibility, ethic... | 14,823 | MATCH | 14823 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1144 | 494 | 14 Reproducibility, ethic... | 9 | MATCH | 2026-10-09 | arith day 75 = 9 October |  |
| 1145 | 494 | 14 Reproducibility, ethic... | 17,206 | MATCH | 17206 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1146 | 494 | 14 Reproducibility, ethic... | 11 | MATCH | 2026-10-11 | arith day 77 |  |
| 1147 | 494 | 14 Reproducibility, ethic... | 17,400 | MATCH | 17400 | data single_reads_2026-10.csv; also ahrefs_ai_responses = 17400 in the prefix CSV |  |
| 1148 | 494 | 14 Reproducibility, ethic... | 12 | MATCH | 2026-10-12 | data single_reads_2026-10.csv and prefix CSV |  |
| 1149 | 494 | 14 Reproducibility, ethic... | 13 | MATCH | 2026-10-13 | data single_reads_2026-10.csv |  |
| 1150 | 494 | 14 Reproducibility, ethic... | 3% | MATCH | 2.94687 | arith re-read / Table 2 October (2.8% worldwide, 3.1% US) | approximate wording, accepted within 10% |
| 1151 | 494 | 14 Reproducibility, ethic... | 1,910,867 | MATCH | 1,910,867.0 | data single_reads_2026-10.csv |  |
| 1152 | 494 | 14 Reproducibility, ethic... | 1,659,636 | MATCH | 1,659,636.0 | data single_reads_2026-10.csv |  |
| 1153 | 510 | 14 Reproducibility, ethic... | 109 | MATCH | 109 | data companies CSV |  |
| 1154 | 512 | 14 Reproducibility, ethic... | 1,696 | MATCH | 1,696 / 1,555 / 7 / 134 | data 08_REVIEW/reproduction_v5.2_run3_2026-10-15/reproduction_report.md (in the bundle) |  |
| 1155 | 512 | 14 Reproducibility, ethic... | 1,555 | MATCH | 1,555 | data run-3 report |  |
| 1156 | 512 | 14 Reproducibility, ethic... | seven differed | MATCH | 7 | data run-3 report |  |
| 1157 | 512 | 14 Reproducibility, ethic... | 134 | MATCH | 134 | data run-3 report |  |
| 1160 | 512 | 14 Reproducibility, ethic... | +0.18 | MATCH | 0.184869 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 1161 | 512 | 14 Reproducibility, ethic... | +0.28 | MATCH | 0.284982 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 1162 | 512 | 14 Reproducibility, ethic... | three times in clean folders | MATCH | 3 | data 08_REVIEW folders in the bundle |  |
| 1163 | 512 | 14 Reproducibility, ethic... | 15 | MATCH | 2026-10-15 | data 08_REVIEW folder names |  |
| 1164 | 520 | 15 Conclusion | 7.5 | MATCH | 7.46965 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 1165 | 520 | 15 Conclusion | 27.1 | MATCH | 27.1414 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 1166 | 520 | 15 Conclusion | 8.6 | MATCH | 8.62011 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 1167 | 520 | 15 Conclusion | 29.9 | MATCH | 29.8608 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 1168 | 520 | 15 Conclusion | 2.7 | MATCH | 2.65536 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 1169 | 520 | 15 Conclusion | about its referring domains by a factor of eleven | MATCH | 11.4125 | arith 913 / 80 |  |
| 1170 | 520 | 15 Conclusion | from one fifth to seven times | MATCH | (0.203125, 7.239819004524887) | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1171 | 520 | 15 Conclusion | 60 | MATCH | 60 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1172 | 520 | 15 Conclusion | 66 | MATCH | 66 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1173 | 522 | 15 Conclusion | 37,193 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 1174 | 522 | 15 Conclusion | +0.47 | MATCH | 0.468137 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 1175 | 522 | 15 Conclusion | +0.75 | MATCH | 0.747549 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 1176 | 522 | 15 Conclusion | +0.18 | MATCH | 0.184869 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 1177 | 522 | 15 Conclusion | +0.27 | MATCH | 0.272602 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 1178 | 522 | 15 Conclusion | one in seven unhappy reviews | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped analyze_reviews_output.txt (needs the licensed review export, not released) (924 / 6,62... |
| 1179 | 522 | 15 Conclusion | 11 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 1180 | 522 | 15 Conclusion | 622 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 1181 | 524 | 15 Conclusion | 21% | MATCH | 21.3411 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1182 | 524 | 15 Conclusion | 0.6% | MATCH | 0.558 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1183 | 524 | 15 Conclusion | 9.2% | MATCH | 9.2146 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1184 | 524 | 15 Conclusion | higher on every Google view than on every other surface in every se... | MATCH | 11 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1185 | 524 | 15 Conclusion | two of four predictions written before collection failed | MATCH | P1, P3 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1186 | 526 | 15 Conclusion | 15,830 | MATCH | 15830 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1187 | 526 | 15 Conclusion | nineteen referring domains at day 37 | MATCH | 19 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1188 | 526 | 15 Conclusion | 17,206 | MATCH | 17206 | data instrument_series_table5_checkpoints.csv (transcribed from the manuscript) |  |
| 1189 | 701 | Appendix A: Corrections a... | 381 | MATCH | 381 | data section_code_pages_2026-10-14.csv |  |
| 1192 | 701 | Appendix A: Corrections a... | 9.2x | MATCH | 9.18866 | arith 158,100 / 17,206 |  |
| 1193 | 701 | Appendix A: Corrections a... | 78 | MATCH | 78 | arith |  |
| 1194 | 701 | Appendix A: Corrections a... | 0 | MATCH | days 0 to 77 = 78 days | arith 6 + 31 + 30 + 11 = 78 |  |
| 1195 | 701 | Appendix A: Corrections a... | 77 | MATCH | 77 | arith |  |
| 1196 | 701 | Appendix A: Corrections a... | 5.2 | MATCH | 5.20975 | arith |  |
| 1197 | 701 | Appendix A: Corrections a... | 27.1x | MATCH | 27.1414 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 1200 | 701 | Appendix A: Corrections a... | −0.11 | MATCH | -0.112084 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1201 | 701 | Appendix A: Corrections a... | a stale copy of Figure 5 ... was replaced | MATCH | make_figs_v4.py prints ρ = −0.11 in F... | data make_figs_v4.py |  |
| 1202 | 703 | Appendix A: Corrections a... | +0.47 | MATCH | 0.468137 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 1203 | 703 | Appendix A: Corrections a... | +0.75 | MATCH | 0.747549 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 1204 | 703 | Appendix A: Corrections a... | +0.78 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped analyze_reviews_output.txt (needs the licensed review export, not released) |
| 1205 | 703 | Appendix A: Corrections a... | 11 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 1206 | 705 | Appendix A: Corrections a... | 456 | MATCH | 456 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 1207 | 705 | Appendix A: Corrections a... | 459 | MATCH | 459 | data vendor_reliance_works.csv rows naming a tool, duplicates included | the superseded count |
| 1208 | 705 | Appendix A: Corrections a... | three works were counted twice | MATCH | 3 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 1209 | 705 | Appendix A: Corrections a... | +0.18 | MATCH | 0.184869 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 1211 | 705 | Appendix A: Corrections a... | +0.185 | MATCH | +0.185 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 1215 | 718 | Appendix B: The Content G... | 0.22 | CANNOT RUN |  | rank normalization in the ufi implementation, not in the bundle | consistent with (rank - 1)/(n - 1) and shared ranks: (15.5 - 1) / 65 = 0.223 |
| 1216 | 718 | Appendix B: The Content G... | 30 | CANNOT RUN |  | ufi example, not in the bundle |  |
| 1217 | 718 | Appendix B: The Content G... | 66 | CANNOT RUN |  | ufi example, not in the bundle |  |
| 1225 | 722 | Appendix B: The Content G... | 0.5 | CANNOT RUN |  | parameter lock in the ufi repository |  |
| 1226 | 722 | Appendix B: The Content G... | 0.5 | CANNOT RUN |  | parameter lock in the ufi repository |  |
| 1227 | 722 | Appendix B: The Content G... | 0.85 | CANNOT RUN |  | parameter lock in the ufi repository |  |
| 1228 | 724 | Appendix B: The Content G... | 0.8 | CANNOT RUN |  | ufi example, not in the bundle | rel term correlates with degree at roughly 0.8 |
| 1229 | 726 | Appendix B: The Content G... | 4 | CANNOT RUN |  | ufi example, not in the bundle | schema pass rate 4/5 |
| 1230 | 726 | Appendix B: The Content G... | 5 | CANNOT RUN |  | ufi example, not in the bundle | schema pass rate 4/5 |
| 1231 | 726 | Appendix B: The Content G... | 70.4% | CANNOT RUN |  | ufi example, not in the bundle |  |
| 1232 | 734 | Appendix C: Section 7 by ... | 25.8% | MATCH | 25.8408 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1233 | 734 | Appendix C: Section 7 by ... | 14.3 | MATCH | 14.3362 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1234 | 734 | Appendix C: Section 7 by ... | 34.3 | MATCH | 34.2886 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1235 | 734 | Appendix C: Section 7 by ... | 4.3% | MATCH | 4.3177 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1236 | 734 | Appendix C: Section 7 by ... | 1.3 | MATCH | 1.2865 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1237 | 734 | Appendix C: Section 7 by ... | 8.1 | MATCH | 8.1212 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1238 | 734 | Appendix C: Section 7 by ... | 0.7% | MATCH | 0.7123 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1239 | 734 | Appendix C: Section 7 by ... | 0.2 | MATCH | 0.1582 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1240 | 734 | Appendix C: Section 7 by ... | 2.8 | MATCH | 2.7779 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1241 | 734 | Appendix C: Section 7 by ... | 0.4% | MATCH | 0.4356 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1242 | 734 | Appendix C: Section 7 by ... | 0.2 | MATCH | 0.1565 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1243 | 734 | Appendix C: Section 7 by ... | 8.6 | MATCH | 8.6478 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1244 | 734 | Appendix C: Section 7 by ... | 11.9% | MATCH | 11.894 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1245 | 734 | Appendix C: Section 7 by ... | 6.1 | MATCH | 6.1185 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1246 | 734 | Appendix C: Section 7 by ... | 23.5 | MATCH | 23.4514 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1247 | 734 | Appendix C: Section 7 by ... | 55.6% | MATCH | 55.5705 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1248 | 734 | Appendix C: Section 7 by ... | 41.1 | MATCH | 41.1403 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1249 | 734 | Appendix C: Section 7 by ... | 62.0 | MATCH | 61.9765 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1250 | 735 | Appendix C: Section 7 by ... | 32.4% | MATCH | 32.3534 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1251 | 735 | Appendix C: Section 7 by ... | 13.4 | MATCH | 13.4491 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1252 | 735 | Appendix C: Section 7 by ... | 35.8 | MATCH | 35.7705 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1253 | 735 | Appendix C: Section 7 by ... | 2.6% | MATCH | 2.6203 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1254 | 735 | Appendix C: Section 7 by ... | 0.7 | MATCH | 0.7422 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1255 | 735 | Appendix C: Section 7 by ... | 3.9 | MATCH | 3.9498 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1256 | 735 | Appendix C: Section 7 by ... | 1.0% | MATCH | 1.0317 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1257 | 735 | Appendix C: Section 7 by ... | 0.1 | MATCH | 0.1216 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1258 | 735 | Appendix C: Section 7 by ... | 5.8 | MATCH | 5.7748 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1259 | 735 | Appendix C: Section 7 by ... | 0.3% | MATCH | 0.3106 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1260 | 735 | Appendix C: Section 7 by ... | 0.1 | MATCH | 0.073 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1261 | 735 | Appendix C: Section 7 by ... | 3.8 | MATCH | 3.8015 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1262 | 735 | Appendix C: Section 7 by ... | 8.1% | MATCH | 8.0683 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1263 | 735 | Appendix C: Section 7 by ... | 2.7 | MATCH | 2.672 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1264 | 735 | Appendix C: Section 7 by ... | 20.5 | MATCH | 20.5103 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1265 | 735 | Appendix C: Section 7 by ... | 59.0% | MATCH | 59.0074 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1266 | 735 | Appendix C: Section 7 by ... | 42.0 | MATCH | 42.0156 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1267 | 735 | Appendix C: Section 7 by ... | 75.3 | MATCH | 75.3399 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1268 | 736 | Appendix C: Section 7 by ... | 17.8% | MATCH | 17.7949 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1269 | 736 | Appendix C: Section 7 by ... | 9.0 | MATCH | 8.9697 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1270 | 736 | Appendix C: Section 7 by ... | 23.8 | MATCH | 23.8201 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1271 | 736 | Appendix C: Section 7 by ... | 4.2% | MATCH | 4.2202 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1272 | 736 | Appendix C: Section 7 by ... | 2.2 | MATCH | 2.1531 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1273 | 736 | Appendix C: Section 7 by ... | 10.4 | MATCH | 10.4294 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1274 | 736 | Appendix C: Section 7 by ... | 1.0% | MATCH | 1.0409 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1275 | 736 | Appendix C: Section 7 by ... | 0.3 | MATCH | 0.3247 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1276 | 736 | Appendix C: Section 7 by ... | 4.2 | MATCH | 4.1795 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1277 | 736 | Appendix C: Section 7 by ... | 0.4% | MATCH | 0.3834 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1278 | 736 | Appendix C: Section 7 by ... | 0.1 | MATCH | 0.113 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1279 | 736 | Appendix C: Section 7 by ... | 8.6 | MATCH | 8.5822 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1280 | 736 | Appendix C: Section 7 by ... | 10.8% | MATCH | 10.7781 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1281 | 736 | Appendix C: Section 7 by ... | 5.1 | MATCH | 5.1307 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1282 | 736 | Appendix C: Section 7 by ... | 17.6 | MATCH | 17.5871 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1283 | 736 | Appendix C: Section 7 by ... | 65.3% | MATCH | 65.2887 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1284 | 736 | Appendix C: Section 7 by ... | 53.1 | MATCH | 53.1251 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1285 | 736 | Appendix C: Section 7 by ... | 71.4 | MATCH | 71.4499 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1286 | 737 | Appendix C: Section 7 by ... | 24.1% | MATCH | 24.1106 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1287 | 737 | Appendix C: Section 7 by ... | 8.1 | MATCH | 8.0839 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1288 | 737 | Appendix C: Section 7 by ... | 28.3 | MATCH | 28.2927 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1289 | 737 | Appendix C: Section 7 by ... | 2.7% | MATCH | 2.7226 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1290 | 737 | Appendix C: Section 7 by ... | 0.9 | MATCH | 0.9308 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1291 | 737 | Appendix C: Section 7 by ... | 4.5 | MATCH | 4.4954 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1292 | 737 | Appendix C: Section 7 by ... | 1.4% | MATCH | 1.4145 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1293 | 737 | Appendix C: Section 7 by ... | 0.3 | MATCH | 0.2912 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1294 | 737 | Appendix C: Section 7 by ... | 5.6 | MATCH | 5.6048 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1295 | 737 | Appendix C: Section 7 by ... | 0.4% | MATCH | 0.3822 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1296 | 737 | Appendix C: Section 7 by ... | 0.1 | MATCH | 0.0971 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1297 | 737 | Appendix C: Section 7 by ... | 5.0 | MATCH | 5.02 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1298 | 737 | Appendix C: Section 7 by ... | 9.5% | MATCH | 9.4626 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1299 | 737 | Appendix C: Section 7 by ... | 2.7 | MATCH | 2.7002 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1300 | 737 | Appendix C: Section 7 by ... | 19.3 | MATCH | 19.3496 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1301 | 737 | Appendix C: Section 7 by ... | 65.1% | MATCH | 65.1076 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1302 | 737 | Appendix C: Section 7 by ... | 50.1 | MATCH | 50.0632 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1303 | 737 | Appendix C: Section 7 by ... | 79.3 | MATCH | 79.2849 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1304 | 738 | Appendix C: Section 7 by ... | 0.9% | MATCH | 0.8941 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1305 | 738 | Appendix C: Section 7 by ... | 0.3 | MATCH | 0.3339 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1306 | 738 | Appendix C: Section 7 by ... | 2.5 | MATCH | 2.5077 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1307 | 738 | Appendix C: Section 7 by ... | 1.7% | MATCH | 1.6604 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1308 | 738 | Appendix C: Section 7 by ... | 0.5 | MATCH | 0.5128 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1309 | 738 | Appendix C: Section 7 by ... | 3.4 | MATCH | 3.3805 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1310 | 738 | Appendix C: Section 7 by ... | 1.7% | MATCH | 1.6708 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1311 | 738 | Appendix C: Section 7 by ... | 0.7 | MATCH | 0.6801 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1312 | 738 | Appendix C: Section 7 by ... | 5.2 | MATCH | 5.2126 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1313 | 738 | Appendix C: Section 7 by ... | 3.0% | MATCH | 2.9785 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1314 | 738 | Appendix C: Section 7 by ... | 1.6 | MATCH | 1.5783 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1315 | 738 | Appendix C: Section 7 by ... | 18.2 | MATCH | 18.2252 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1316 | 738 | Appendix C: Section 7 by ... | 27.4% | MATCH | 27.378 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1317 | 738 | Appendix C: Section 7 by ... | 13.5 | MATCH | 13.5496 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1318 | 738 | Appendix C: Section 7 by ... | 38.2 | MATCH | 38.2483 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1319 | 738 | Appendix C: Section 7 by ... | 61.5% | MATCH | 61.4981 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1320 | 738 | Appendix C: Section 7 by ... | 51.2 | MATCH | 51.1827 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1321 | 738 | Appendix C: Section 7 by ... | 76.1 | MATCH | 76.1141 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1322 | 739 | Appendix C: Section 7 by ... | 4.6% | MATCH | 4.6083 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1323 | 739 | Appendix C: Section 7 by ... | 1.8 | MATCH | 1.7963 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1324 | 739 | Appendix C: Section 7 by ... | 7.7 | MATCH | 7.7203 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1325 | 739 | Appendix C: Section 7 by ... | 5.9% | MATCH | 5.8948 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1326 | 739 | Appendix C: Section 7 by ... | 2.8 | MATCH | 2.8317 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1327 | 739 | Appendix C: Section 7 by ... | 10.7 | MATCH | 10.7015 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1328 | 739 | Appendix C: Section 7 by ... | 1.5% | MATCH | 1.5302 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1329 | 739 | Appendix C: Section 7 by ... | 0.3 | MATCH | 0.2671 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1330 | 739 | Appendix C: Section 7 by ... | 7.9 | MATCH | 7.9118 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1331 | 739 | Appendix C: Section 7 by ... | 0.8% | MATCH | 0.8442 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1332 | 739 | Appendix C: Section 7 by ... | 0.1 | MATCH | 0.0836 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1333 | 739 | Appendix C: Section 7 by ... | 12.0 | MATCH | 11.9712 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1334 | 739 | Appendix C: Section 7 by ... | 15.6% | MATCH | 15.611 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1335 | 739 | Appendix C: Section 7 by ... | 8.2 | MATCH | 8.2437 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1336 | 739 | Appendix C: Section 7 by ... | 29.8 | MATCH | 29.8279 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1337 | 739 | Appendix C: Section 7 by ... | 67.8% | MATCH | 67.7907 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1338 | 739 | Appendix C: Section 7 by ... | 56.4 | MATCH | 56.3698 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1339 | 739 | Appendix C: Section 7 by ... | 73.9 | MATCH | 73.9375 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1340 | 740 | Appendix C: Section 7 by ... | 9.2% | MATCH | 9.2145 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1341 | 740 | Appendix C: Section 7 by ... | 2.9 | MATCH | 2.8767 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1342 | 740 | Appendix C: Section 7 by ... | 16.7 | MATCH | 16.685 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1343 | 740 | Appendix C: Section 7 by ... | 3.7% | MATCH | 3.6927 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1344 | 740 | Appendix C: Section 7 by ... | 1.2 | MATCH | 1.2091 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1345 | 740 | Appendix C: Section 7 by ... | 6.9 | MATCH | 6.8837 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1346 | 740 | Appendix C: Section 7 by ... | 0.5% | MATCH | 0.5479 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1347 | 740 | Appendix C: Section 7 by ... | 0.1 | MATCH | 0.0612 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1348 | 740 | Appendix C: Section 7 by ... | 3.8 | MATCH | 3.82 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1349 | 740 | Appendix C: Section 7 by ... | 0.3% | MATCH | 0.2571 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1350 | 740 | Appendix C: Section 7 by ... | 0.1 | MATCH | 0.0649 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1351 | 740 | Appendix C: Section 7 by ... | 2.4 | MATCH | 2.3973 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1352 | 740 | Appendix C: Section 7 by ... | 8.3% | MATCH | 8.3104 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1353 | 740 | Appendix C: Section 7 by ... | 3.2 | MATCH | 3.1622 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1354 | 740 | Appendix C: Section 7 by ... | 33.2 | MATCH | 33.2194 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1355 | 740 | Appendix C: Section 7 by ... | 75.2% | MATCH | 75.1628 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1356 | 740 | Appendix C: Section 7 by ... | 49.5 | MATCH | 49.4912 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1357 | 740 | Appendix C: Section 7 by ... | 85.3 | MATCH | 85.274 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1358 | 741 | Appendix C: Section 7 by ... | 0.6% | MATCH | 0.5579 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1359 | 741 | Appendix C: Section 7 by ... | 0.3 | MATCH | 0.3468 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1360 | 741 | Appendix C: Section 7 by ... | 1.0 | MATCH | 0.967 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1361 | 741 | Appendix C: Section 7 by ... | 1.6% | MATCH | 1.6465 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1362 | 741 | Appendix C: Section 7 by ... | 0.3 | MATCH | 0.3435 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1363 | 741 | Appendix C: Section 7 by ... | 2.7 | MATCH | 2.6776 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1364 | 741 | Appendix C: Section 7 by ... | 0.9% | MATCH | 0.9106 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1365 | 741 | Appendix C: Section 7 by ... | 0.2 | MATCH | 0.2458 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1366 | 741 | Appendix C: Section 7 by ... | 5.2 | MATCH | 5.2131 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1367 | 741 | Appendix C: Section 7 by ... | 0.1% | MATCH | 0.1339 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1368 | 741 | Appendix C: Section 7 by ... | 0.0 | MATCH | 0 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1369 | 741 | Appendix C: Section 7 by ... | 2.2 | MATCH | 2.1843 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1370 | 741 | Appendix C: Section 7 by ... | 4.5% | MATCH | 4.4902 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1371 | 741 | Appendix C: Section 7 by ... | 1.6 | MATCH | 1.5512 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1372 | 741 | Appendix C: Section 7 by ... | 27.0 | MATCH | 27.0056 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1373 | 741 | Appendix C: Section 7 by ... | 89.9% | MATCH | 89.8952 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1374 | 741 | Appendix C: Section 7 by ... | 71.6 | MATCH | 71.5623 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1375 | 741 | Appendix C: Section 7 by ... | 94.6 | MATCH | 94.6493 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1376 | 747 | Appendix C: Section 7 by ... | 10,891.5 | MATCH | 10891.5 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1377 | 747 | Appendix C: Section 7 by ... | 294.3 | MATCH | 294.304 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1378 | 747 | Appendix C: Section 7 by ... | 1,128.4 | MATCH | 1128.45 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1379 | 747 | Appendix C: Section 7 by ... | 352.4 | MATCH | 352.449 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1380 | 747 | Appendix C: Section 7 by ... | 317.5 | MATCH | 317.479 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1381 | 747 | Appendix C: Section 7 by ... | 186.8 | MATCH | 186.779 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1382 | 747 | Appendix C: Section 7 by ... | 147.9 | MATCH | 147.885 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1383 | 747 | Appendix C: Section 7 by ... | 405.6 | MATCH | 405.65 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... | full-precision value lies exactly on the rounding boundary |
| 1384 | 748 | Appendix C: Section 7 by ... | 604.2 | MATCH | 604.246 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1385 | 748 | Appendix C: Section 7 by ... | 10.1 | MATCH | 10.075 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1386 | 748 | Appendix C: Section 7 by ... | 69.8 | MATCH | 69.807 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1387 | 748 | Appendix C: Section 7 by ... | 16.5 | MATCH | 16.494 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1388 | 748 | Appendix C: Section 7 by ... | 13.9 | MATCH | 13.909 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1389 | 748 | Appendix C: Section 7 by ... | 8.5 | MATCH | 8.462 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1390 | 748 | Appendix C: Section 7 by ... | 7.4 | MATCH | 7.359 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1391 | 748 | Appendix C: Section 7 by ... | 20.9 | MATCH | 20.922 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1392 | 749 | Appendix C: Section 7 by ... | 1,776.8 | MATCH | 1776.75 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1393 | 749 | Appendix C: Section 7 by ... | 78.8 | MATCH | 78.791 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1394 | 749 | Appendix C: Section 7 by ... | 173.5 | MATCH | 173.488 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1395 | 749 | Appendix C: Section 7 by ... | 97.5 | MATCH | 97.506 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1396 | 749 | Appendix C: Section 7 by ... | 64.4 | MATCH | 64.44 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1397 | 749 | Appendix C: Section 7 by ... | 37.4 | MATCH | 37.4 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1398 | 749 | Appendix C: Section 7 by ... | 45.3 | MATCH | 45.288 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1399 | 749 | Appendix C: Section 7 by ... | 85.9 | MATCH | 85.88 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1400 | 750 | Appendix C: Section 7 by ... | 18,381.8 | MATCH | 18381.8 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1401 | 750 | Appendix C: Section 7 by ... | 790.0 | MATCH | 790.033 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1402 | 750 | Appendix C: Section 7 by ... | 1,752.1 | MATCH | 1752.09 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1403 | 750 | Appendix C: Section 7 by ... | 660.9 | MATCH | 660.907 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1404 | 750 | Appendix C: Section 7 by ... | 347.0 | MATCH | 347.003 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1405 | 750 | Appendix C: Section 7 by ... | 441.7 | MATCH | 441.73 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1406 | 750 | Appendix C: Section 7 by ... | 128.8 | MATCH | 128.84 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1407 | 750 | Appendix C: Section 7 by ... | 1,581.3 | MATCH | 1581.33 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1408 | 751 | Appendix C: Section 7 by ... | 4,350.7 | MATCH | 4350.72 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1409 | 751 | Appendix C: Section 7 by ... | 134.3 | MATCH | 134.309 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1410 | 751 | Appendix C: Section 7 by ... | 591.5 | MATCH | 591.503 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1411 | 751 | Appendix C: Section 7 by ... | 163.5 | MATCH | 163.472 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1412 | 751 | Appendix C: Section 7 by ... | 150.1 | MATCH | 150.095 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1413 | 751 | Appendix C: Section 7 by ... | 71.8 | MATCH | 71.753 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1414 | 751 | Appendix C: Section 7 by ... | 76.0 | MATCH | 76.037 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1415 | 751 | Appendix C: Section 7 by ... | 197.9 | MATCH | 197.899 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1416 | 752 | Appendix C: Section 7 by ... | 1,223.2 | MATCH | 1223.15 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1417 | 752 | Appendix C: Section 7 by ... | 52.6 | MATCH | 52.607 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1418 | 752 | Appendix C: Section 7 by ... | 112.9 | MATCH | 112.889 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1419 | 752 | Appendix C: Section 7 by ... | 60.2 | MATCH | 60.164 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1420 | 752 | Appendix C: Section 7 by ... | 52.6 | MATCH | 52.642 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1421 | 752 | Appendix C: Section 7 by ... | 21.7 | MATCH | 21.726 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1422 | 752 | Appendix C: Section 7 by ... | 27.2 | MATCH | 27.154 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1423 | 752 | Appendix C: Section 7 by ... | 79.3 | MATCH | 79.336 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1424 | 753 | Appendix C: Section 7 by ... | 8,832.0 | MATCH | 8832.03 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1425 | 753 | Appendix C: Section 7 by ... | 395.4 | MATCH | 395.394 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1426 | 753 | Appendix C: Section 7 by ... | 982.3 | MATCH | 982.34 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1427 | 753 | Appendix C: Section 7 by ... | 446.6 | MATCH | 446.609 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1428 | 753 | Appendix C: Section 7 by ... | 351.7 | MATCH | 351.715 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1429 | 753 | Appendix C: Section 7 by ... | 215.6 | MATCH | 215.597 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1430 | 753 | Appendix C: Section 7 by ... | 149.8 | MATCH | 149.768 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1431 | 753 | Appendix C: Section 7 by ... | 1,295.6 | MATCH | 1295.62 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1432 | 754 | Appendix C: Section 7 by ... | 103.6 | MATCH | 103.604 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1433 | 754 | Appendix C: Section 7 by ... | 3.8 | MATCH | 3.78 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1434 | 754 | Appendix C: Section 7 by ... | 14.8 | MATCH | 14.837 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1435 | 754 | Appendix C: Section 7 by ... | 5.5 | MATCH | 5.481 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1436 | 754 | Appendix C: Section 7 by ... | 5.1 | MATCH | 5.089 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1437 | 754 | Appendix C: Section 7 by ... | 2.0 | MATCH | 1.953 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1438 | 754 | Appendix C: Section 7 by ... | 2.9 | MATCH | 2.941 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1439 | 754 | Appendix C: Section 7 by ... | 9.0 | MATCH | 8.961 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1440 | 755 | Appendix C: Section 7 by ... | 50.3 | MATCH | 50.308 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1441 | 755 | Appendix C: Section 7 by ... | 2.1 | MATCH | 2.133 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1442 | 755 | Appendix C: Section 7 by ... | 7.2 | MATCH | 7.206 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1443 | 755 | Appendix C: Section 7 by ... | 2.6 | MATCH | 2.573 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1444 | 755 | Appendix C: Section 7 by ... | 2.1 | MATCH | 2.096 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1445 | 755 | Appendix C: Section 7 by ... | 0.9 | MATCH | 0.86 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1446 | 755 | Appendix C: Section 7 by ... | 1.5 | MATCH | 1.46 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1447 | 755 | Appendix C: Section 7 by ... | 3.2 | MATCH | 3.207 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1448 | 756 | Appendix C: Section 7 by ... | 77.9 | MATCH | 77.865 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1449 | 756 | Appendix C: Section 7 by ... | 6.4 | MATCH | 6.409 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1450 | 756 | Appendix C: Section 7 by ... | 22.1 | MATCH | 22.119 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1451 | 756 | Appendix C: Section 7 by ... | 6.8 | MATCH | 6.807 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1452 | 756 | Appendix C: Section 7 by ... | 6.8 | MATCH | 6.823 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1453 | 756 | Appendix C: Section 7 by ... | 4.4 | MATCH | 4.365 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1454 | 756 | Appendix C: Section 7 by ... | 2.1 | MATCH | 2.15 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... | full-precision value lies exactly on the rounding boundary |
| 1455 | 756 | Appendix C: Section 7 by ... | 6.8 | MATCH | 6.846 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1456 | 757 | Appendix C: Section 7 by ... | 337.5 | MATCH | 337.499 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1457 | 757 | Appendix C: Section 7 by ... | 15.6 | MATCH | 15.629 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1458 | 757 | Appendix C: Section 7 by ... | 24.3 | MATCH | 24.327 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1459 | 757 | Appendix C: Section 7 by ... | 17.5 | MATCH | 17.511 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1460 | 757 | Appendix C: Section 7 by ... | 18.5 | MATCH | 18.526 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1461 | 757 | Appendix C: Section 7 by ... | 5.6 | MATCH | 5.615 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1462 | 757 | Appendix C: Section 7 by ... | 6.5 | MATCH | 6.534 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1463 | 757 | Appendix C: Section 7 by ... | 18.7 | MATCH | 18.748 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1464 | 763 | Appendix C: Section 7 by ... | Tables C3 and C4 (every cell) | MATCH | identical to make_tables_sector_surfa... | rerun make_tables_sector_surface.py (byte-identical to shipped output) |  |
| 1465 | 793 | Appendix C: Section 7 by ... | 38 | MATCH | 38 | rerun make_tables_sector_surface.py |  |
| 1466 | 793 | Appendix C: Section 7 by ... | 44 | MATCH | 44 | rerun make_tables_sector_surface.py |  |
| 1467 | 793 | Appendix C: Section 7 by ... | four of them Alphabet's own properties in Communication Services | MATCH | C3 marks youtube†, youtube†, google†,... | rerun make_tables_sector_surface.py | 4 of the 5 marked C3 cells are on Google views |
| 1468 | 793 | Appendix C: Section 7 by ... | 15 | MATCH | 15 | rerun make_tables_sector_surface.py |  |
| 1469 | 793 | Appendix C: Section 7 by ... | 22 | MATCH | 22 | rerun make_tables_sector_surface.py (Perplexity and Gemini x 11 sectors) |  |
| 1470 | 793 | Appendix C: Section 7 by ... | 4 | MATCH | 4 | rerun make_tables_sector_surface.py |  |
| 1471 | 793 | Appendix C: Section 7 by ... | 11 | MATCH | 11 | rerun make_tables_sector_surface.py |  |
| 1472 | 793 | Appendix C: Section 7 by ... | 6 | MATCH | 6 | rerun make_tables_sector_surface.py |  |
| 1473 | 793 | Appendix C: Section 7 by ... | 11 | MATCH | 11 | rerun make_tables_sector_surface.py |  |
| 1474 | 797 | Appendix D: Metrics, valu... | a benchmark of seven tasks | MATCH | 7 | data UFI_Metrics_and_Evaluation_Protocol_v1.0.md |  |
| 1475 | 803 | Appendix D: Metrics, valu... | 14 | MATCH | 14 October 2026 | data vendor_reliance.py docstring |  |
| 1476 | 803 | Appendix D: Metrics, valu... | 120 | MATCH | 120 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 1477 | 803 | Appendix D: Metrics, valu... | 456 | MATCH | 456 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 1478 | 803 | Appendix D: Metrics, valu... | 82% | MATCH | 82.5 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... | 82.5% exactly; see Section 1; full-precision value lies exactly on the rounding boundary |
| 1479 | 803 | Appendix D: Metrics, valu... | 87% | MATCH | 86.6667 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 1480 | 803 | Appendix D: Metrics, valu... | 0.63 | MATCH | 0.631336 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 1481 | 803 | Appendix D: Metrics, valu... | 87% | MATCH | 86.8687 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... |  |
| 1482 | 803 | Appendix D: Metrics, valu... | 88% | MATCH | 87.5 | rerun vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomp... | full-precision value lies exactly on the rounding boundary |
| 1483 | 804 | Appendix D: Metrics, valu... | 7.5x | MATCH | 7.46965 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 1484 | 804 | Appendix D: Metrics, valu... | 27.1x | MATCH | 27.1414 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 1485 | 804 | Appendix D: Metrics, valu... | 8.6x | MATCH | 8.62011 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 1486 | 804 | Appendix D: Metrics, valu... | 29.9x | MATCH | 29.8608 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 1487 | 804 | Appendix D: Metrics, valu... | 9.2x | MATCH | 9.16521 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 1488 | 804 | Appendix D: Metrics, valu... | 33.3x | MATCH | 33.3024 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 1489 | 805 | Appendix D: Metrics, valu... | 0.95 | MATCH | 0.954129 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 1490 | 805 | Appendix D: Metrics, valu... | 2.66 | MATCH | 2.65536 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 1491 | 805 | Appendix D: Metrics, valu... | 1.37 | MATCH | 1.36839 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 1492 | 806 | Appendix D: Metrics, valu... | 5.2 | MATCH | 5.20975 | arith |  |
| 1493 | 806 | Appendix D: Metrics, valu... | 27.1x | MATCH | 27.1414 | arith Table 2 values (released series CSV, transcribed from the manuscript) |  |
| 1494 | 807 | Appendix D: Metrics, valu... | 35% | MATCH | 34.9703 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 1495 | 807 | Appendix D: Metrics, valu... | 54% | MATCH | 53.9067 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 1496 | 808 | Appendix D: Metrics, valu... | 0.20x | MATCH | 0.203125 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1497 | 808 | Appendix D: Metrics, valu... | 7.24x | MATCH | 7.23982 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1498 | 808 | Appendix D: Metrics, valu... | 8.89x | MATCH | 8.89413 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1499 | 808 | Appendix D: Metrics, valu... | 1.01 | MATCH | 1.00747 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1500 | 809 | Appendix D: Metrics, valu... | −0.11 | MATCH | -0.112084 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1501 | 809 | Appendix D: Metrics, valu... | −0.64 | MATCH | -0.644533 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1502 | 809 | Appendix D: Metrics, valu... | +0.49 | MATCH | 0.493575 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1503 | 809 | Appendix D: Metrics, valu... | 0.73 | MATCH | 0.73 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1504 | 810 | Appendix D: Metrics, valu... | +0.94 | MATCH | 0.937063 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1505 | 810 | Appendix D: Metrics, valu... | +0.82 | MATCH | 0.818182 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1506 | 810 | Appendix D: Metrics, valu... | 60 | MATCH | 60 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1507 | 810 | Appendix D: Metrics, valu... | 66 | MATCH | 66 | rerun data/analyze.py (identical to an independent recomputation from the two prefix CSVs) |  |
| 1508 | 810 | Appendix D: Metrics, valu... | 51 | MATCH | 51 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 1509 | 810 | Appendix D: Metrics, valu... | 51 | MATCH | 51 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 1511 | 810 | Appendix D: Metrics, valu... | 9 | MATCH | 9 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 1512 | 810 | Appendix D: Metrics, valu... | 15 | MATCH | 15 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 1513 | 811 | Appendix D: Metrics, valu... | 1.13 | MATCH | 1.13296 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 1514 | 811 | Appendix D: Metrics, valu... | 3.1 | MATCH | 3.13014 | rerun instrument_extra.py (byte-identical to shipped output) |  |
| 1515 | 812 | Appendix D: Metrics, valu... | 12.6% | MATCH | 12.6093 | arith Table 3 |  |
| 1516 | 812 | Appendix D: Metrics, valu... | 20.0% | MATCH | 20.0199 | arith Table 3 |  |
| 1517 | 813 | Appendix D: Metrics, valu... | 55.6% | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped analyze_reviews_output.txt (needs the licensed review export, not released) |
| 1518 | 813 | Appendix D: Metrics, valu... | 2.25 | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped outputs |
| 1519 | 814 | Appendix D: Metrics, valu... | +0.18 | MATCH | 0.184869 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 1520 | 814 | Appendix D: Metrics, valu... | +0.27 | MATCH | 0.272602 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 1521 | 815 | Appendix D: Metrics, valu... | +0.47 | MATCH | 0.468137 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 1522 | 815 | Appendix D: Metrics, valu... | +0.75 | MATCH | 0.747549 | rerun m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2... |  |
| 1523 | 816 | Appendix D: Metrics, valu... | 14.0% | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped analyze_reviews_output.txt (needs the licensed review export, not released) |
| 1524 | 816 | Appendix D: Metrics, valu... | 1.9% | CANNOT RUN |  | licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx... | agrees with shipped supplement_r10_output.txt (needs the licensed review export, not released) |
| 1525 | 817 | Appendix D: Metrics, valu... | 65% | MATCH | 65 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 1526 | 817 | Appendix D: Metrics, valu... | 67% | MATCH | 66.8367 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 1527 | 817 | Appendix D: Metrics, valu... | 0.90 | MATCH | 0.90228 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 1528 | 817 | Appendix D: Metrics, valu... | 50% | MATCH | 49.0157 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs (50.0% a... | approximate wording, accepted within 5% |
| 1529 | 817 | Appendix D: Metrics, valu... | 95% | MATCH | 94.5205 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 1530 | 817 | Appendix D: Metrics, valu... | 96% | MATCH | 95.8333 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 1531 | 818 | Appendix D: Metrics, valu... | 83% | MATCH | 83 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 1532 | 818 | Appendix D: Metrics, valu... | 85% | MATCH | 84.8485 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 1533 | 818 | Appendix D: Metrics, valu... | 0.93 | MATCH | 0.927876 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs |  |
| 1534 | 818 | Appendix D: Metrics, valu... | 90% | MATCH | 89.8164 | rerun r2_link_check.py (byte-identical) + recomputation from the judgment CSVs (90.5% a... | approximate wording, accepted within 5% |
| 1535 | 820 | Appendix D: Metrics, valu... | 21.3% | MATCH | 21.3411 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1536 | 820 | Appendix D: Metrics, valu... | 17.2 | MATCH | 17.2 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1537 | 820 | Appendix D: Metrics, valu... | 26.7 | MATCH | 26.7 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1538 | 820 | Appendix D: Metrics, valu... | 2.1% | MATCH | 2.06095 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1539 | 820 | Appendix D: Metrics, valu... | 1.7 | MATCH | 1.7 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1540 | 820 | Appendix D: Metrics, valu... | 2.7 | MATCH | 2.7 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1541 | 821 | Appendix D: Metrics, valu... | 11 | MATCH | 11 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1542 | 821 | Appendix D: Metrics, valu... | 11 | MATCH | 11 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1543 | 822 | Appendix D: Metrics, valu... | 0.36 | MATCH | 0.362118 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1544 | 822 | Appendix D: Metrics, valu... | 0.40 | MATCH | 0.403026 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1545 | 822 | Appendix D: Metrics, valu... | 0.08 | MATCH | 0.0750117 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1546 | 822 | Appendix D: Metrics, valu... | 0.23 | MATCH | 0.226183 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1547 | 823 | Appendix D: Metrics, valu... | 77% | MATCH | 77.3681 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1548 | 823 | Appendix D: Metrics, valu... | 14% | MATCH | 14.1544 | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1549 | 824 | Appendix D: Metrics, valu... | one held, one in direction, two failed | MATCH | P2 held; P4 direction; P1, P3 failed | rerun section7_from_aggregates.py (byte-identical) + independent recomputation from agg... |  |
| 1550 | 825 | Appendix D: Metrics, valu... | 4 | CANNOT RUN |  | ufi example, not in the bundle | 4/5 |
| 1551 | 825 | Appendix D: Metrics, valu... | 5 | CANNOT RUN |  | ufi example, not in the bundle | 4/5 |
| 1552 | 826 | Appendix D: Metrics, valu... | 70.4% | CANNOT RUN |  | ufi example, not in the bundle |  |
| 1555 | 309 | 7.2 Design | 1,000 | MATCH | 1,000 | data cross_sector_cells.csv export_rows (the export cap) |  |
| 1556 | 325 | 7.5 Sensitivity | 1,000 | MATCH | 1,000 | data cross_sector_cells.csv export_rows (the export cap) |  |
| 1557 | 730 | Appendix C: Section 7 by ... | 1,000 | MATCH | 1,000 | data cross_sector_cells.csv export_rows (the export cap) |  |
| 1558 | 761 | Appendix C: Section 7 by ... | 1,000 | MATCH | 1,000 | data cross_sector_cells.csv export_rows (the export cap) |  |
| 1559 | 819 | Appendix D: Metrics, valu... | 1,000 | MATCH | 1,000 | data cross_sector_cells.csv export_rows (the export cap) |  |
| 1564 | 355 | 8 The deployment series | 37 | MATCH | 2026-09-01 | arith 37 days after 26 July |  |
| 1567 | 402 | 10.1 What the link profil... | 77 | MATCH | 77 | arith day 0 to day 77 |  |
| 1570 | 502 | 14 Reproducibility, ethic... | 13 | MATCH | 13 to 83 | data single_reads_2026-10.csv |  |
| 1571 | 502 | 14 Reproducibility, ethic... | 83 | MATCH | 13 to 83 | data single_reads_2026-10.csv |  |

### 8.6 Entries judged not to be quantitative claims

| # | Line | Quoted | Why |
|---|---|---|---|
| 171 | 155 | three disturbances | count of the list that follows in the same paragraph |
| 550 | 271 | 10 | read date (10 and 11 October), as in Table 1 |
| 832 | 325 | 11 | denominator, eleven sectors |
| 836 | 325 | 11 | denominator, eleven sectors |
| 840 | 325 | 11 | denominator, eleven sectors |
| 848 | 325 | 100 | row cut-off |
| 851 | 325 | 250 | row cut-off |
| 854 | 325 | 500 | row cut-off |
| 893 | 337 | 11 | read date of Table 5 |
| 981 | 357 | 50 | definition: the top 50 URLs |
| 1005 | 369 | 0.5 | rubric grade (specification), as in Appendix B |
| 1121 | 466 | 02 | path 02_DESIGN |
| 1158 | 512 | +0.19 | the superseded value, quoted as the error |
| 1159 | 512 | +0.29 | the superseded value, quoted as the error |
| 1190 | 701 | 290 | superseded value |
| 1191 | 701 | 88 | superseded 88-code control |
| 1198 | 701 | 13 | superseded reading of the bound |
| 1199 | 701 | −0.09 | the stale figure value |
| 1210 | 705 | +0.19 | superseded value |
| 1218 | 720 | 1.0 | rubric grade (specification) |
| 1219 | 720 | 0.5 | rubric grade (specification) |
| 1220 | 720 | 0 | rubric grade (specification) |
| 1221 | 720 | 1.0 | rubric grade (specification) |
| 1222 | 720 | 0.5 | rubric grade (specification) |
| 1223 | 720 | 0 | rubric grade (specification) |
| 1224 | 720 | 0 | rubric grade (specification) |
| 1510 | 810 | 3x | band threshold |
| 1553 | 247 | 0.5 | power-analysis parameter (a correlation of 0.5) |
| 1554 | 287 | 1,000 | threshold (under 1,000 monthly searches) |
| 1560 | 351 | 21 | row name 21-100 |
| 1561 | 351 | 100 | row name 21-100 |
| 1562 | 351 | 21 | row name 21-100 |
| 1563 | 351 | 100 | row name 21-100 |
| 1565 | 369 | 214 | area code used as a name |
| 1566 | 369 | 214 | area code used as a name |
| 1568 | 402 | 1 | band 1-3 |
| 1569 | 402 | 3 | band 1-3 |
| 1572 | 502 | 6 | Condition 6 |
| 1573 | 512 | 10 | folder name date |
| 1574 | 700 | 2 | version v2.2 |
| 1575 | 716 | 1 | formula constant |
| 1576 | 716 | 1 | formula constant |
| 1577 | 716 | 1 | formula constant |
| 1578 | 716 | 1 | formula constant |
| 1579 | 718 | 1 | formula constant |
| 1580 | 112 | 1 | condition numbers |
| 1581 | 112 | 3 | condition numbers |
| 1582 | 112 | 4 | condition numbers |
| 1583 | 112 | 6 | condition numbers |
| 1584 | 135 | 12 | export dates of an unreleased file |
| 1585 | 143 | 10 | read dates |
| 1586 | 175 | 10 | read dates |
| 1587 | 309 | 12 | collection dates |
| 1588 | 730 | 12 | collection dates |
| 1589 | 761 | 12 | collection dates |
| 1590 | 265 | 2 | formula constant |

## 9. Files in this folder

- `check_scripts/`: `logrun.sh` (command logger), `run_one.sh` (script runner), `compare_outputs.py`, `compare_figures.py`, `check_numbers.py`, `m2_precise.py`, `m2_boundary.py`, `tokens.py`, `coverage.py`, `label_audit.py`, `ots_parse.py`, `manifest_check.py`, `figure_check.py`, `md_vs_built.py`, `make_report.py`.
- `outputs/`: every script's stdout and stderr (`*_stdout.txt`, `*_stderr.txt`), `run_status.tsv`, the comparisons, `numbers_table.tsv`, the coverage and mutation tests, the OTS and block-explorer checks, SHA-256 lists of the pristine copy before and after, and `built_artifacts/` (the built `paper.pdf` and `paper.docx`).
- `command_log.txt`: every command, with its exit status; reproduced below.

## 10. Command log

```
# Command log, independent reproduction run 4 of the Paper 03 v5.2 source bundle
# Fresh working folder: /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
# Review folder: /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
# Commands before the logger existed:
[2026-10-15 03:09:07] $ ls -la <bundle zip>; shasum -a 256 <bundle zip>   (result 1dcc4128398d5d7bb7912f492bb201310fa276dac0ae0103b98e7ce50c2c14f4)
[2026-10-15 03:09:07] $ mkdir -p $R/check_scripts $R/outputs; T=$(mktemp -d scratchpad/repro_run4_XXXXXX); write $R/check_scripts/logrun.sh
[2026-10-15 03:09:12] $ T=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
mkdir -p "$T/zip"
cp /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/06_MANUSCRIPT/User_First_Intelligence_v5.2_2026-10-15_source.zip "$T/zip/"
shasum -a 256 "$T/zip/User_First_Intelligence_v5.2_2026-10-15_source.zip"
unzip -l "$T/zip/User_First_Intelligence_v5.2_2026-10-15_source.zip"
    -> exit 0
[2026-10-15 03:09:25] $ T=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
mkdir -p "$T/pristine" "$T/run"
cd "$T/pristine" && unzip -q "$T/zip/User_First_Intelligence_v5.2_2026-10-15_source.zip"
cd "$T/run" && unzip -q "$T/zip/User_First_Intelligence_v5.2_2026-10-15_source.zip"
ls "$T/pristine" "$T/run"
cd "$T/pristine/User_First_Intelligence_v5.2_2026-10-15_source" && find . -type f | LC_ALL=C sort | xargs shasum -a 256 > "$T/pristine_sha256.txt"
wc -l "$T/pristine_sha256.txt"
cp "$T/pristine_sha256.txt" /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/outputs/pristine_sha256_before.txt
    -> exit 0
[2026-10-15 03:14:31] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
{ echo "date: $(date -u '+%Y-%m-%d %H:%M:%S UTC')"; sw_vers 2>/dev/null | tr '\n' ' '; echo; uname -a; which python3; python3 --version; python3 -I -c "
import numpy, scipy, pandas, matplotlib, sys
print('numpy', numpy.__version__, 'scipy', scipy.__version__, 'pandas', pandas.__version__, 'matplotlib', matplotlib.__version__)
try:
    import openpyxl; print('openpyxl', openpyxl.__version__)
except Exception as e: print('openpyxl not installed', e)
try:
    import ufi; print('ufi installed', ufi.__file__)
except Exception as e: print('ufi not importable:', type(e).__name__, e)
"; tectonic --version; pandoc --version | head -1; which xelatex || echo "xelatex: not installed"; which ots || echo "ots (opentimestamps-client): not installed"; } | tee "$R/outputs/environment.txt"
    -> exit 0
[2026-10-15 03:14:48] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
{ echo "date: $(date -u '+%Y-%m-%d %H:%M:%S UTC')"; sw_vers 2>/dev/null | tr '\n' ' '; echo; uname -mrs; echo "python3 -> $(python3 -c 'import sys; print(sys.executable)')"; python3 --version; python3 -E -P -c "
import numpy, scipy, pandas, matplotlib, pyparsing
print('numpy', numpy.__version__, '| scipy', scipy.__version__, '| pandas', pandas.__version__, '| matplotlib', matplotlib.__version__, '| pyparsing', pyparsing.__version__)
for m in ('openpyxl', 'ufi'):
    try:
        mod = __import__(m); print(m, getattr(mod, '__version__', '?'), 'importable')
    except Exception as e: print(m, 'not importable:', type(e).__name__)
"; tectonic --version; pandoc --version | head -1; which xelatex || echo "xelatex: not installed (build_tex.py falls back to tectonic)"; which ots || echo "ots (opentimestamps-client): not installed"; } | tee "$R/outputs/environment.txt"
    -> exit 0
[2026-10-15 03:15:06] $ X=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts/run_one.sh
B=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/run/User_First_Intelligence_v5.2_2026-10-15_source
$X "$B/data" analyze python3 analyze.py
$X "$B/review_demand" m2_from_counts python3 m2_from_counts.py
$X "$B/review_demand" r2_link_check python3 r2_link_check.py
$X "$B/stakes" vendor_reliance_offline python3 vendor_reliance.py --offline
$X "$B/stakes" stakes_screen_check python3 stakes_screen_check.py
$X "$B/ai_citation_cross_sector/scripts" section7_from_aggregates python3 section7_from_aggregates.py
$X "$B/ai_citation_cross_sector/scripts" make_tables_sector_surface python3 make_tables_sector_surface.py
    -> exit 0
[2026-10-15 03:16:38] $ X=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts/run_one.sh
B=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/run/User_First_Intelligence_v5.2_2026-10-15_source
$X "$B/instrument_divergence_extra" instrument_extra python3 instrument_extra.py
$X "$B/protocols" instrument_extra_as_stamped python3 instrument_extra_as_stamped.py
$X "$B/protocols" reread_compare python3 reread_compare.py
    -> exit 0
[2026-10-15 03:17:30] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
T=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
cd "$R/check_scripts" && python3 -E -P compare_outputs.py "$T/pristine/User_First_Intelligence_v5.2_2026-10-15_source" "$T/run/User_First_Intelligence_v5.2_2026-10-15_source" "$R/outputs" | tee "$R/outputs/compare_batch1_2.txt"
    -> exit 0
[2026-10-15 03:17:36] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/outputs
awk '/^== 7\./{exit} {print}' "$R/instrument_extra_stdout.txt" > "$R/instrument_extra_sections1to6.txt"
cmp "$R/instrument_extra_as_stamped_stdout.txt" "$R/instrument_extra_sections1to6.txt" && echo "stamped script stdout == current script sections 1 to 6: IDENTICAL" | tee "$R/stamped_vs_current_sections1to6.txt"
wc -c "$R/instrument_extra_as_stamped_stdout.txt" "$R/instrument_extra_sections1to6.txt"
    -> exit 0
[2026-10-15 03:17:42] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/outputs
tail -c 40 "$R/instrument_extra_sections1to6.txt" | od -c | tail -3
diff "$R/instrument_extra_as_stamped_stdout.txt" "$R/instrument_extra_sections1to6.txt"; echo "diff exit $?"
# drop the one blank separator line that the current script prints before its section 7 heading
sed -e '$ { /^$/d; }' "$R/instrument_extra_sections1to6.txt" > "$R/instrument_extra_sections1to6_trimmed.txt"
cmp "$R/instrument_extra_as_stamped_stdout.txt" "$R/instrument_extra_sections1to6_trimmed.txt" && echo "stamped script stdout == current script sections 1 to 6 (less the blank line before section 7): IDENTICAL" | tee "$R/stamped_vs_current_sections1to6.txt"
    -> exit 0
[2026-10-15 03:18:01] $ X=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts/run_one.sh
B=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/run/User_First_Intelligence_v5.2_2026-10-15_source
$X "$B/review_demand" analyze_reviews_attempt python3 analyze_reviews.py
$X "$B/review_demand" supplement_r10_attempt python3 supplement_r10.py
$X "$B/review_demand" r2_link_sample_attempt python3 r2_link_sample.py
$X "$B/review_demand" make_fig_reviews_v50_attempt python3 make_fig_reviews_v50.py
$X "$B/ai_citation_cross_sector/scripts" cross_sector_attempt python3 cross_sector.py
$X "$B/ai_citation_cross_sector/scripts" cross_sector_sensitivity_attempt python3 cross_sector_sensitivity.py
$X "$B/ai_citation_cross_sector/scripts" cross_sector_sensitivity2_attempt python3 cross_sector_sensitivity2.py
$X "$B/ai_citation_cross_sector/scripts" make_brand_radar_urls python3 make_brand_radar_urls.py
R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/outputs
for f in analyze_reviews_attempt supplement_r10_attempt r2_link_sample_attempt make_fig_reviews_v50_attempt cross_sector_attempt cross_sector_sensitivity_attempt cross_sector_sensitivity2_attempt make_brand_radar_urls; do echo "---- $f: stdout"; cat "$R/${f}_stdout.txt"; echo "---- $f: last stderr line"; tail -1 "$R/${f}_stderr.txt"; done
    -> exit 0
[2026-10-15 03:18:14] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
T=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
P=$T/pristine/User_First_Intelligence_v5.2_2026-10-15_source; B=$T/run/User_First_Intelligence_v5.2_2026-10-15_source
cmp "$B/ai_citation_cross_sector/design/cross_sector_report_urls.json" "$P/ai_citation_cross_sector/design/cross_sector_report_urls.json" && echo "cross_sector_report_urls.json regenerated by make_brand_radar_urls.py: IDENTICAL to shipped"
head -c $(wc -c < "$R/outputs/cross_sector_sensitivity2_attempt_stdout.txt") "$P/ai_citation_cross_sector/scripts/cross_sector_sensitivity2_output.txt" | cmp - "$R/outputs/cross_sector_sensitivity2_attempt_stdout.txt" && echo "cross_sector_sensitivity2.py partial stdout (variance block, printed before it stops): IDENTICAL to the first $(wc -c < "$R/outputs/cross_sector_sensitivity2_attempt_stdout.txt") bytes of the shipped output"
ls -la "$B/review_demand/out" 2>&1
    -> exit 0
[2026-10-15 03:18:24] $ X=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts/run_one.sh
B=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/run/User_First_Intelligence_v5.2_2026-10-15_source
$X "$B" make_figs_v4 python3 make_figs_v4.py
$X "$B" make_fig0 python3 make_fig0.py
$X "$B/ai_citation_cross_sector/scripts" make_fig_sources python3 make_fig_sources.py
R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/outputs
for f in make_figs_v4 make_fig0 make_fig_sources; do echo "---- $f"; cat "$R/${f}_stdout.txt"; cat "$R/${f}_stderr.txt"; done
    -> exit 0
[2026-10-15 03:18:48] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
T=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
cd "$R/check_scripts" && python3 -E -P compare_figures.py "$T/pristine/User_First_Intelligence_v5.2_2026-10-15_source" "$T/run/User_First_Intelligence_v5.2_2026-10-15_source" | tee "$R/outputs/compare_figures.txt"
    -> exit 0
[2026-10-15 03:19:04] $ T=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
X=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts/run_one.sh
mkdir -p "$T/build" && cd "$T/build" && unzip -q "$T/zip/User_First_Intelligence_v5.2_2026-10-15_source.zip"
BB="$T/build/User_First_Intelligence_v5.2_2026-10-15_source"
$X "$BB" build_tex python3 build_tex.py
ls -la "$BB/build"
cmp "$BB/build/paper.tex" "$BB/paper.tex" && echo "build/paper.tex written by build_tex.py: IDENTICAL to the shipped paper.tex"
    -> exit 0
[2026-10-15 03:19:15] $ T=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
X=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts/run_one.sh
BB="$T/build/User_First_Intelligence_v5.2_2026-10-15_source"
$X "$BB/build" tectonic_paper tectonic --keep-logs paper.tex
ls -la "$BB/build"/paper.*
R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/outputs
tail -5 "$R/tectonic_paper_stdout.txt"; echo "---- stderr tail"; tail -15 "$R/tectonic_paper_stderr.txt"
    -> exit 0
[2026-10-15 03:19:28] $ T=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
L="$T/build/User_First_Intelligence_v5.2_2026-10-15_source/build/paper.log"
R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/outputs
cp "$L" "$R/tectonic_paper.log"
echo "Missing character lines: $(grep -c 'Missing character' "$L")"; grep 'Missing character' "$L" | sort | uniq -c | head -20
echo "undefined/error/not found lines:"; grep -n -i -E "undefined|^! |error|not found|LaTeX Warning: (Reference|Citation)|File .* not found" "$L" | head -20
echo "Overfull lines: $(grep -c 'Overfull' "$L"); Underfull lines: $(grep -c 'Underfull' "$L")"
grep -E "Output written|pages" "$L" | tail -3
which pdftotext pdfinfo mutool qpdf swift 2>/dev/null; python3 -E -P -c "import importlib.util as u; print({m: bool(u.find_spec(m)) for m in ('pypdf','PyPDF2','fitz','pdfminer','pdfplumber','docx')})"
    -> exit 0
[2026-10-15 03:19:36] $ T=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
X=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts/run_one.sh
BB="$T/build/User_First_Intelligence_v5.2_2026-10-15_source"
ls -la "$BB/build_docx.sh"
if [ -x "$BB/build_docx.sh" ]; then $X "$BB" build_docx ./build_docx.sh; else $X "$BB" build_docx zsh build_docx.sh; fi
R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/outputs
cat "$R/build_docx_stdout.txt" "$R/build_docx_stderr.txt"; ls -la "$BB/build/paper.docx" "$BB/build/manuscript_docx.md"
    -> exit 0
[2026-10-15 03:19:49] $ T=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
BB="$T/build/User_First_Intelligence_v5.2_2026-10-15_source"
R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/outputs
unzip -l "$BB/build/paper.docx" | grep -E "media/" | tee "$R/docx_media.txt"; echo "media files: $(grep -c media/ "$R/docx_media.txt")"
pdfinfo "$BB/build/paper.pdf" | tee "$R/built_paper_pdfinfo.txt"
pdftotext -layout "$BB/build/paper.pdf" "$R/built_paper_pdf_layout.txt"; pdftotext "$BB/build/paper.pdf" "$R/built_paper_pdf_raw.txt"; wc -c "$R"/built_paper_pdf_*.txt
shasum -a 256 "$BB/build/paper.pdf" "$BB/build/paper.docx" "$BB/build/paper.tex" | tee "$R/built_artifacts_sha256.txt"
mkdir -p "$R/built_artifacts" && cp "$BB/build/paper.pdf" "$BB/build/paper.docx" "$R/built_artifacts/"
    -> exit 0
[2026-10-15 03:21:10] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
M=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source/manuscript_v50.md
cd "$R/check_scripts" && python3 -E -P tokens.py "$M" 1 531 > "$R/outputs/tokens_body.txt"; python3 -E -P tokens.py "$M" 696 829 > "$R/outputs/tokens_appendices.txt"; tail -1 "$R/outputs/tokens_body.txt"; tail -1 "$R/outputs/tokens_appendices.txt"
    -> exit 0
[2026-10-15 03:29:51] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
P=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source
cd "$R/check_scripts" && python3 -E -P m2_precise.py "$P/review_demand" > "$R/outputs/m2_precise.json" && cat "$R/outputs/m2_precise.json"
    -> exit 0
[2026-10-15 03:31:02] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
P=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source
cd "$R/check_scripts" && python3 -E -P m2_boundary.py "$P/review_demand" | tee "$R/outputs/m2_boundary.txt"
    -> exit 0
[2026-10-15 03:33:08] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
P=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source
cd "$R/check_scripts" && python3 -E -P -c "
import sys; sys.argv=['x', '$P', '$R/outputs']
exec(open('check_numbers.py').read())
print('rho_age', rho_age, 'fisher', fisher, 'perm_p', perm_p, 'power', power)
print('gmean', gmean, 'gsd', gsd, 'range', grange, 'med', med_vr, med_vm)
print('conc', conc, disc, {k: (sum(v), len(v)) for k, v in bands.items()})
print('R_US_AW', R_US_AW); print('R_WW', R_WW); print('R_USUS', R_USUS)
print('T3V', T3V); print('EVERY', EVERY, 'EVERY_NYT', EVERY_NYT, 'P1', P1, 'P2', P2, 'P3', P3, P3_CHATFAIL, 'P4', P4)
print('CHATGPT_MED_NOXLI', CHATGPT_MED_NOXLI, P2_NOXLI, P3_NOXLI)
print('VAR', VAR); print('TYPEMED', TYPEMED); print('JAC', JAC); print('TRUNC', TRUNC)
print('locs', len(LOCS), 'codes', len(CODES)); print('opposite', opposite)
"
    -> exit 0
[2026-10-15 03:34:49] $ (patched check_numbers.py: P1 condition, line-44 claim)
[2026-10-15 03:36:29] $ (patched check_numbers.py: single-read lookups keyed by quantity and instrument; placeholder expressions removed)
[2026-10-15 03:40:42] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
P=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source
cd "$R/check_scripts"
python3 -E -P manifest_check.py "$P" | tee "$R/outputs/manifest_check.txt"
echo
python3 -E -P ots_parse.py "$P/protocols/protocols_manifest.txt.ots" "$P/framework_test_r1/framework_retro_test_381_manifest.txt.ots" "$P/framework_test_r1/framework_retro_test_381_amendment_2026-10-15.md.ots" | tee "$R/outputs/ots_parse.txt"
    -> exit 0
[2026-10-15 03:41:01] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
H=$(curl -s --max-time 20 https://blockstream.info/api/block-height/971506)
echo "block hash: $H"
if [ -n "$H" ] && [ ${#H} -eq 64 ]; then curl -s --max-time 20 "https://blockstream.info/api/block/$H" > "$R/outputs/block_971506.json"; python3 -E -P -c "
import json, datetime, sys
d = json.load(open(sys.argv[1]))
print('height', d['height'], 'merkle_root', d['merkle_root'])
print('timestamp', d['timestamp'], datetime.datetime.fromtimestamp(d['timestamp'], datetime.UTC).isoformat())
print('merkle root equals the one the proofs commit to:', d['merkle_root'] == '7bdc60257b41068f09d1157f28005268d7430ba65143d263243a5d46a24659a3')
" "$R/outputs/block_971506.json" | tee "$R/outputs/block_explorer_check.txt"; else echo "no block hash returned (network unavailable or block unknown)" | tee "$R/outputs/block_explorer_check.txt"; fi
    -> exit 0
[2026-10-15 03:42:09] $ (patched check_numbers.py: 459 from the works list, C3 dagger check, placeholders removed)
[2026-10-15 03:42:14] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
P=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source
cd "$R/check_scripts" && python3 -E -P check_numbers.py "$P" "$R/outputs" 2>&1 | tee "$R/outputs/check_numbers_stdout.txt"
    -> exit 0
[2026-10-15 03:43:02] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
P=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source
cd "$R/check_scripts" && python3 -E -P coverage.py "$P/manuscript_v50.md" "$R/outputs/numbers_table.tsv" > "$R/outputs/coverage.txt"; head -5 "$R/outputs/coverage.txt"; grep -c "^  line" "$R/outputs/coverage.txt"
    -> exit 0
[2026-10-15 03:43:32] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
P=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source
cd "$R/check_scripts" && python3 -E -P check_numbers.py "$P" "$R/outputs" 2>&1 | tee "$R/outputs/check_numbers_stdout.txt" && python3 -E -P coverage.py "$P/manuscript_v50.md" "$R/outputs/numbers_table.tsv" > "$R/outputs/coverage.txt"; head -40 "$R/outputs/coverage.txt"
    -> exit 0
[2026-10-15 03:43:58] $ python3 -E -P label_audit.py manuscript numbers_table.tsv > outputs/label_audit.txt
[2026-10-15 03:44:33] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
P=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source
cd "$R/check_scripts" && python3 -E -P - "$P" "$R/outputs" <<'PY' | tee "$R/outputs/mutation_unit_test.txt"
import sys
src = open("check_numbers.py").read().split("# ------------------------------------------------------------------------------------------------ released data")[0]
ns = {"__name__": "unit"}
sys.argv = ["check_numbers.py"] + sys.argv[1:]
exec(compile(src, "check_numbers_helpers", "exec"), ns)
M, ROWS = ns["M"], ns["ROWS"]
cases = [("+0.19", 0.18487, "MISMATCH"), ("+0.18", 0.18487, "MATCH"), ("+0.74", 0.735, "MATCH"), ("37,193", 37192, "MISMATCH"),
         ("7.5x", 7.4697, "MATCH"), ("7.4x", 7.4697, "MISMATCH"), ("−0.11", 0.112, "MISMATCH"), ("82%", 82.5, "MATCH"),
         ("55.6%", 55.4, "MISMATCH"), ("+0.25", 0.24503, "MATCH"), ("+0.25", 0.2449, "MISMATCH"), ("92.3K", 92.3, "MATCH")]
bad = 0
for tok, v, want in cases:
    M(0, tok, v, "unit test")
    got = ROWS[-1]["status"]
    bad += got != want
    print(f"{tok:>8} vs {v:<9} -> {got:9} (expected {want}) {ROWS[-1]['note']}")
print("unit test", "PASSED" if bad == 0 else f"FAILED ({bad})")
PY
    -> exit 0
[2026-10-15 03:44:48] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
T=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
rm -rf "$T/mutant" && mkdir -p "$T/mutant/outputs" && cp -R "$T/pristine/User_First_Intelligence_v5.2_2026-10-15_source" "$T/mutant/bundle" && cp "$R"/outputs/*.txt "$R"/outputs/*.json "$T/mutant/outputs/"
python3 -E -P - "$T/mutant/bundle/manuscript_v50.md" <<'PY'
import sys
p = sys.argv[1]; L = open(p, encoding="utf-8").read().split("\n")
muts = [(232, "| 0.20 | 99.2% |", "| 0.21 | 99.2% |"), (734, "25.8% (14.3–34.3)", "25.9% (14.3–34.3)"), (747, "10,891.5", "10,881.5"),
        (287, "is +0.18 (bootstrap", "is +0.19 (bootstrap"), (342, "20,326", "20,362")]
for ln, a, b in muts:
    assert L[ln - 1].count(a) == 1, (ln, a)
    L[ln - 1] = L[ln - 1].replace(a, b)
open(p, "w", encoding="utf-8").write("\n".join(L)); print("mutated", len(muts), "places")
PY
cd "$R/check_scripts" && python3 -E -P check_numbers.py "$T/mutant/bundle" "$T/mutant/outputs" | tee "$R/outputs/mutation_end_to_end.txt"
python3 -E -P coverage.py "$T/mutant/bundle/manuscript_v50.md" "$T/mutant/outputs/numbers_table.tsv" | tee -a "$R/outputs/mutation_end_to_end.txt"
    -> exit 0
[2026-10-15 03:46:06] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
P=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source
cd "$R/check_scripts" && python3 -E -P figure_check.py "$P" | tee "$R/outputs/figure_check.txt"
    -> exit 0
[2026-10-15 03:46:15] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
P=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source
cd "$R/check_scripts" && python3 -E -P figure_check.py "$P" | tee "$R/outputs/figure_check.txt"
    -> exit 0
[2026-10-15 03:46:33] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
T=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
BB="$T/build/User_First_Intelligence_v5.2_2026-10-15_source"
pandoc "$BB/build/paper.docx" -t plain --wrap=none -o "$R/outputs/built_paper_docx.txt"
cd "$R/check_scripts" && python3 -E -P md_vs_built.py "$BB/manuscript_v50.md" "$R/outputs/built_paper_pdf_raw.txt" "$R/outputs/built_paper_docx.txt" | tee "$R/outputs/md_vs_built.txt"
    -> exit 0
[2026-10-15 03:46:54] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
T=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
rm -rf "$T/editrun" && mkdir -p "$T/editrun" && cd "$T/editrun" && unzip -q "$T/zip/User_First_Intelligence_v5.2_2026-10-15_source.zip"
E="$T/editrun/User_First_Intelligence_v5.2_2026-10-15_source"
cd "$E"
OUTF="$R/outputs/edit_scripts_attempts.txt"; : > "$OUTF"
before=$(shasum -a 256 manuscript_v50.md | cut -c1-16)
for f in edit_v49.py edit_v49_r9.py edit_v49_r9b.py edit_v49_r9c.py edit_v50.py edit_v50b.py edit_v50c.py edit_v51.py edit_v51b.py edit_v52.py edit_v52b.py edit_v52c.py edit_v52d.py edit_v52e.py edit_v52f.py edit_v52g.py edit_v52h.py edit_v52i.py edit_v52j.py edit_v52k.py edit_v52l.py edit_v52m.py edit_v52n.py edit_v52o.py edit_v52p.py edit_v52q.py edit_v52r.py edit_v52s.py; do
  msg=$(python3 "$f" 2>&1 | tail -1 | cut -c1-160); rc=$?
  rc=$(python3 -c "print(0)" >/dev/null; echo ${PIPESTATUS[0]})
  after=$(shasum -a 256 manuscript_v50.md | cut -c1-16)
  printf '%-18s manuscript %s -> %s  last line: %s\n' "$f" "$before" "$after" "$msg" >> "$OUTF"
  before=$after
done
cat "$OUTF"
ls manuscript_v49.md 2>&1 | head -1
    -> exit 0
[2026-10-15 03:47:17] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
P=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source
pdftotext "$P/UFI_Metrics_and_Evaluation_Protocol_v1.0.pdf" "$R/outputs/protocol_pdf_text.txt"
python3 -E -P - "$P" "$R/outputs/protocol_pdf_text.txt" <<'PY' | tee "$R/outputs/misc_consistency.txt"
import sys, re, csv
from collections import Counter
from pathlib import Path
P = Path(sys.argv[1])
NUM = re.compile(r"(?<![\w.])(\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)(?![\d])")
ab = (P / "arxiv_abstract.txt").read_text(encoding="utf-8")
ms = (P / "manuscript_v50.md").read_text(encoding="utf-8")
abstract = ms[ms.index("## Abstract") + 11: ms.index("## 1 Introduction")]
print(f"arxiv_abstract.txt: {len(ab)} characters ({len(ab.strip())} stripped); README says under 1,920: {len(ab.strip()) < 1920}")
na, nm = Counter(NUM.findall(ab)), Counter(NUM.findall(abstract))
print(f"  numbers in arxiv_abstract.txt not in the manuscript abstract: {sorted((na - nm).elements())}")
print(f"  numbers in the manuscript abstract not in arxiv_abstract.txt: {sorted((nm - na).elements())}")
md = (P / "UFI_Metrics_and_Evaluation_Protocol_v1.0.md").read_text(encoding="utf-8")
pdf = open(sys.argv[2], encoding="utf-8", errors="replace").read()
cm, cp = Counter(NUM.findall(md)), Counter(NUM.findall(pdf))
print(f"protocol: numbers in the .md missing from the .pdf text: {sorted((cm - cp).elements())[:40]}")
print(f"protocol: numbers in the .pdf text not in the .md (page numbers etc. expected): {sorted((cp - cm).elements())[:40]}")
pm = {(r["etf"], r["surface"]): r for r in csv.DictReader((P / "ai_citation_cross_sector/aggregates/cross_sector_platform_metrics.csv").open())}
cells = {(r["etf"], r["surface"]): r for r in csv.DictReader((P / "ai_citation_cross_sector/aggregates/cross_sector_cells.csv").open())}
print(f"README note: Utilities ChatGPT yt_rank_nonbrand = {pm[('xlu','chatgpt')]['yt_rank_nonbrand']!r}, youtube_cited_in = {cells[('xlu','chatgpt')]['youtube_cited_in']!r}; "
      f"Utilities Copilot yt_rank_nonbrand = {pm[('xlu','copilot')]['yt_rank_nonbrand']!r}, youtube_cited_in = {cells[('xlu','copilot')]['youtube_cited_in']!r}")
import statistics
for p in ("chatgpt", "copilot"):
    base = [int(pm[(s, p)]["yt_rank_nonbrand"]) if pm[(s, p)]["yt_rank_nonbrand"] else 9999 for s in ["xlk","xlv","xlf","xly","xlc","xli","xlp","xle","xlu","xlre","xlb"]]
    alt = [9999 if int(cells[(s, p)]["youtube_cited_in"]) == 0 else r for s, r in zip(["xlk","xlv","xlf","xly","xlc","xli","xlp","xle","xlu","xlre","xlb"], base)]
    print(f"  {p}: median YouTube rank with ranks as stored {statistics.median(base)}, with uncited cells as not cited {statistics.median(alt)}")
PY
    -> exit 0
[2026-10-15 03:48:12] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
T=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
P=$T/pristine/User_First_Intelligence_v5.2_2026-10-15_source
echo "08_REVIEW scripts in the bundle and the absolute paths they reference:"
for f in $(find "$P/08_REVIEW" -type f \( -name "*.py" -o -name "*.sh" \) | sort); do n=$(grep -c -E "/private/tmp|/Users/|scratchpad" "$f"); echo "  ${f#$P/}: $n lines with absolute paths"; done
cd "$P" && find . -type f | LC_ALL=C sort | xargs shasum -a 256 > "$R/outputs/pristine_sha256_after.txt"
cmp "$R/outputs/pristine_sha256_before.txt" "$R/outputs/pristine_sha256_after.txt" && echo "pristine copy unchanged after all runs (305 files, identical SHA-256 list)"
cd "$R/check_scripts" && python3 -E -P compare_outputs.py "$P" "$T/run/User_First_Intelligence_v5.2_2026-10-15_source" "$R/outputs" > "$R/outputs/compare_final.txt"; sed -n '/Every file/,$p' "$R/outputs/compare_final.txt"
    -> exit 0
[2026-10-15 03:48:56] $ python3 -E -P - "/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source" <<'PY' | tee "/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/outputs/rounding_boundaries.txt"
import csv, sys
from decimal import Decimal, ROUND_HALF_UP, ROUND_HALF_EVEN
from fractions import Fraction
from pathlib import Path
P = Path(sys.argv[1])
cells = {(r["etf"], r["surface"]): int(r["cited_in_sum"]) for r in csv.DictReader((P / "ai_citation_cross_sector/aggregates/cross_sector_cells.csv").open())}
cases = [("Section 1 and Table D1: share of the screen sample using vendor figures, annotator 1", Fraction(99, 120) * 100, "82%", 0),
         ("Table 4: /device-compare/ keyword ratio, Semrush 12,600 / Ahrefs 2,400", Fraction(12600, 2400), "5.2", 1),
         ("Table C2: Information Technology, Copilot, thousands", Fraction(cells[("xlk", "copilot")], 1000), "405.6", 1),
         ("Table C2: Real Estate, Gemini, thousands", Fraction(cells[("xlre", "gemini")], 1000), "2.1", 1),
         ("Section 6: lower end of the multi-word branch interval (exact 294/400, m2_boundary.txt)", Fraction(294, 400), "0.74", 2)]
print(f"{'value':42s} exact      quoted  half-up  half-even  Python-format")
for name, v, q, d in cases:
    dv = Decimal(v.numerator) / Decimal(v.denominator)
    e = Decimal(1).scaleb(-d)
    hu, he = dv.quantize(e, ROUND_HALF_UP), dv.quantize(e, ROUND_HALF_EVEN)
    pf = f"{float(v):.{d}f}"
    print(f"{name[:42]:42s} {str(dv):10s} {q:7s} {str(hu):8s} {str(he):10s} {pf}")
print("raw cells:", cells[("xlk", "copilot")], cells[("xlre", "gemini")])
PY
    -> exit 0
[2026-10-15 03:50:19] $ (patched check_numbers.py: 14 literal-True checks made real or reclassified as labels)
[2026-10-15 03:50:42] $ (patched check_numbers.py: constant-valued checks computed from data)
[2026-10-15 03:50:49] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
P=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source
cd "$R/check_scripts" && python3 -E -P check_numbers.py "$P" "$R/outputs" 2>&1 | tee "$R/outputs/check_numbers_stdout.txt" && python3 -E -P coverage.py "$P/manuscript_v50.md" "$R/outputs/numbers_table.tsv" > "$R/outputs/coverage.txt"; head -4 "$R/outputs/coverage.txt"
    -> exit 0
[2026-10-15 03:51:24] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
T=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN
cp "$R"/outputs/*.txt "$R"/outputs/*.json "$T/mutant/outputs/"
cd "$R/check_scripts" && { echo "Mutant: manuscript_v50.md with five numbers altered (Table 4 0.20->0.21, Table C1 25.8%->25.9%, Table C2 10,891.5->10,881.5, Section 6 +0.18->+0.19, Table 5 20,326->20,362)"; python3 -E -P check_numbers.py "$T/mutant/bundle" "$T/mutant/outputs"; python3 -E -P coverage.py "$T/mutant/bundle/manuscript_v50.md" "$T/mutant/outputs/numbers_table.tsv"; } > "$R/outputs/mutation_end_to_end.txt" 2>&1; grep -E "MISMATCH|not found|^  line 287" "$R/outputs/mutation_end_to_end.txt"
wc -c "$R/command_log.txt"
    -> exit 0
[2026-10-15 03:53:28] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
pdffonts "$R/outputs/built_artifacts/paper.pdf" | tee "$R/outputs/built_paper_pdffonts.txt"
grep -o "Overfull \\\\hbox ([0-9.]*pt too wide)" "$R/outputs/tectonic_paper.log" | sort -t'(' -k2 -n | tail -5
    -> exit 0
[2026-10-15 03:53:38] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
cd "$R/check_scripts" && python3 -E -P make_report.py "$R"
    -> exit 0
[2026-10-15 03:54:16] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
P=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source
cd "$R/check_scripts" && python3 -E -P make_report.py "$R" "$P/manuscript_v50.md"
    -> exit 0
[2026-10-15 03:54:49] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
P=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source
cd "$R/check_scripts" && python3 -E -P make_report.py "$R" "$P/manuscript_v50.md"
    -> exit 0
[2026-10-15 03:55:28] $ R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
P=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run4_7q11XN/pristine/User_First_Intelligence_v5.2_2026-10-15_source
shasum -a 256 /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/06_MANUSCRIPT/User_First_Intelligence_v5.2_2026-10-15_source.zip
cd "$R/check_scripts" && python3 -E -P make_report.py "$R" "$P/manuscript_v50.md" && grep -c "—" "$R/reproduction_report.md"
```
