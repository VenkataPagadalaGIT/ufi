"""Do the built PDF and DOCX carry every number of the manuscript source?

Compares the multiset of numeric tokens (digits with thousands commas and decimals; signs and unit suffixes dropped,
so 7.5x and 7.5×, -0.11 and −0.11 compare equal) in manuscript_v50.md with those in the text of the built paper.pdf
(pdftotext) and paper.docx (pandoc to plain text). A number that occurs fewer times in a built file than in the
source is reported; extra occurrences in the built files (page numbers, running heads, figure text) are expected.

Usage: python3 -E -P md_vs_built.py <manuscript_v50.md> <pdf text file> <docx text file>
"""
import re
import sys
from collections import Counter

NUM = re.compile(r"(?<![\w.])(\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)(?![\d])")


def nums(text):
    text = text.replace("­", "").replace(" ", "").replace(" ", "")
    return Counter(m.group(1) for m in NUM.finditer(text))


md = nums(open(sys.argv[1], encoding="utf-8").read())
for label, path in (("PDF", sys.argv[2]), ("DOCX", sys.argv[3])):
    built = nums(open(path, encoding="utf-8", errors="replace").read())
    short = {k: (v, built.get(k, 0)) for k, v in md.items() if built.get(k, 0) < v}
    print(f"== {label}: {sum(md.values())} numeric tokens in the source, {sum(built.values())} in the built text; "
          f"{len(short)} distinct numbers occur fewer times in the built text")
    for k, (a, b) in sorted(short.items(), key=lambda kv: -(kv[1][0] - kv[1][1]))[:60]:
        print(f"   {k!r}: source {a}, built {b}")
