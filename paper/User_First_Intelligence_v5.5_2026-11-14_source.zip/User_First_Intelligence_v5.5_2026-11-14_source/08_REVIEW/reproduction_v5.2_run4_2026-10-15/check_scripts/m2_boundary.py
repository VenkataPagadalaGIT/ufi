"""Is the lower end of the multi-word branch-level bootstrap interval exactly 0.735, or just below it?

Replays m2_from_counts.py's bootstrap sequence (seed 20261015) up to its last call (multi-word branch shares against
own-volume shares, 10,000 resamples of 17 branches), keeps every replicate's index list, finds the replicate at the
2.5% position, and recomputes its Spearman correlation exactly (rational average ranks, 60-digit square root).

Usage: python3 -E -P m2_boundary.py <review_demand folder>
"""
import csv
import random
import sys
from decimal import Decimal, getcontext
from fractions import Fraction
from pathlib import Path

from scipy.stats import spearmanr

D = Path(sys.argv[1])
L = list(csv.DictReader((D / "m2_label_counts.csv").open()))
BR = list(csv.DictReader((D / "m2_branches.csv").open()))
bv = {b["branch_id"]: float(b["own_volume_share"]) for b in BR}
ment = [int(x["mentions"]) for x in L]
vrank = [float(x["volume_rank"]) for x in L]
nodes = [{k: int(c) for k, c in (p.split(":") for p in x["branch_nodes"].split(";"))} for x in L]
multi = [int(x["words"]) >= 2 for x in L]


def branch_split(counts, rows):
    o = {}
    for k in rows:
        if counts[k]:
            tot = sum(nodes[k].values())
            for b, c in nodes[k].items():
                o[b] = o.get(b, 0) + counts[k] * c / tot
    return o


def branch_modal(counts, rows):
    o = {}
    for k in rows:
        if counts[k]:
            b = max(nodes[k].items(), key=lambda bc: bc[1])[0]
            o[b] = o.get(b, 0) + counts[k]
    return o


def shares(d):
    tot = sum(d.get(b, 0) for b in bv)
    return [d.get(b, 0) / tot for b in bv]


rng = random.Random(20261015)


def boot(xs, ys, reps, keep=False):
    n, o = len(xs), []
    for _ in range(reps):
        idx = [rng.randrange(n) for _ in range(n)]
        r_ = spearmanr([xs[i] for i in idx], [ys[i] for i in idx]).statistic
        if r_ == r_:
            o.append((r_, idx) if keep else r_)
    return o


mi = [k for k in range(len(L)) if ment[k] > 0]
bm = branch_split(ment, range(len(L)))
rs, vs = shares(bm), [bv[b] / sum(bv.values()) for b in bv]
B = sorted(zip(bv, rs, vs), key=lambda t: -t[1])
r2v = shares(branch_modal(ment, range(len(L))))
boot([ment[k] for k in mi], [vrank[k] for k in mi], 10_000)
boot(ment, vrank, 2_000)
boot([t[1] for t in B], [t[2] for t in B], 10_000)
boot(r2v, vs, 10_000)
mw = sorted((k for k in range(len(L)) if multi[k]), key=lambda k: int(L[k]["multiword_order"]))
cm = {k: int(L[k]["mentions_multiword_linker"]) for k in mw}
mmw = [k for k in mw if cm[k] > 0]
boot([cm[k] for k in mmw], [vrank[k] for k in mmw], 10_000)
cnt_mw = [cm.get(k, 0) for k in range(len(L))]
Bm = shares(branch_split(cnt_mw, mw))
reps = boot(Bm, vs, 10_000, keep=True)
reps.sort(key=lambda t: t[0])
lo_pos = int(0.025 * len(reps))
r_lo, idx = reps[lo_pos]
print(f"replicates kept {len(reps)}; 2.5% position {lo_pos}; float value {r_lo!r}")
print("neighbouring replicate values:", [repr(reps[lo_pos + d][0]) for d in (-2, -1, 0, 1, 2)])


def avg_ranks(xs):
    order = sorted(range(len(xs)), key=lambda i: xs[i])
    r = [Fraction(0)] * len(xs)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and xs[order[j + 1]] == xs[order[i]]:
            j += 1
        for k in range(i, j + 1):
            r[order[k]] = Fraction(i + j, 2) + 1
        i = j + 1
    return r


x = [Fraction(Bm[i]) for i in idx]  # exact binary values of the shares, as scipy sees them
y = [Fraction(vs[i]) for i in idx]
rx, ry = avg_ranks(x), avg_ranks(y)
n = len(rx)
mx, my = sum(rx) / n, sum(ry) / n
sxy = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
sxx = sum((a - mx) ** 2 for a in rx)
syy = sum((b - my) ** 2 for b in ry)
getcontext().prec = 60
exact = Decimal(sxy.numerator) / Decimal(sxy.denominator) / (
    (Decimal(sxx.numerator) / Decimal(sxx.denominator)) * (Decimal(syy.numerator) / Decimal(syy.denominator))).sqrt()
print(f"exact Spearman of that replicate: Sxy={sxy}, Sxx={sxx}, Syy={syy}")
print(f"  = {exact}")
print(f"  compared with 0.735: {'equal' if exact == Decimal('0.735') else ('above' if exact > Decimal('0.735') else 'below')}")
print(f"  rounded half-up to 2 decimals: {exact.quantize(Decimal('0.01'), rounding='ROUND_HALF_UP')}; "
      f"half-even: {exact.quantize(Decimal('0.01'), rounding='ROUND_HALF_EVEN')}; Python float format: {r_lo:.2f}")
