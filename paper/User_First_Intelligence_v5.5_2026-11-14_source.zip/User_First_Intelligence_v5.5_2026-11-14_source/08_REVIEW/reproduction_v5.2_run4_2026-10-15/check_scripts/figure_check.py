"""Figure content against the data: the constants hard-coded in make_figs_v4.py against the released data files, and
the labels printed in the shipped Figure 6 (fig9_reviews.pdf, which cannot be redrawn without the licensed export).

Usage: python3 -E -P figure_check.py <bundle root>     (needs pdftotext on PATH)
"""
import ast
import csv
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(sys.argv[1])
src = (ROOT / "make_figs_v4.py").read_text()


def const(name):
    return ast.literal_eval(re.search(rf"(?:^|; ){name} = (\[.*?\])", src, re.M | re.S).group(1))


def num(x):
    return float(str(x).replace(",", "").replace("≈", "").strip())


res = []


def check(what, ok, detail=""):
    res.append(ok)
    print(f"{'OK      ' if ok else 'DIFFERS '} {what}" + (f": {detail}" if detail else ""))


def series(name):
    return list(csv.reader((ROOT / "instrument_divergence_extra" / name).open(encoding="utf-8")))


# Figure 2 (fig1_divergence): Table 2
T2 = series("instrument_series_table2_visits_by_month.csv")[2:]
a = [num(r[2]) for r in T2]
u = [num(r[3].split(" (")[0]) for r in T2]
w = [num(r[3].split(" (")[1].rstrip(")")) for r in T2]
check("Figure 2 Ahrefs, Semrush US, Semrush worldwide = Table 2", const("ahrefs") == a and const("sem_us") == u and const("sem_ww") == w)
labels = re.search(r'zip\(x, ahrefs, sem_us, (\[.*?\])\)', src).group(1)
check("Figure 2 ratio labels = Semrush US / Ahrefs to one decimal", ast.literal_eval(labels) == [f"{s_ / a_:.1f}x" for s_, a_ in zip(u, a)], labels)
# Figure 5 (fig4_prefixes): Table 4 from the CSVs
A = {r["prefix"]: r for r in csv.DictReader((ROOT / "data/ahrefs_prefixes_2026-10-12.csv").open())}
S = {r["prefix"]: r for r in csv.DictReader((ROOT / "data/semrush_prefixes_2026-10-12.csv").open())}
ok = True
for name, age, vr, kr in const("pref"):
    a_, s_ = A[name], S[name]
    age_c = (2026 - int(a_["ahrefs_first_traffic_month"][:4])) * 12 + (10 - int(a_["ahrefs_first_traffic_month"][5:7]))
    vr_c = float(s_["semrush_organic_traffic_us"]) / float(a_["ahrefs_organic_traffic"])
    kr_c = float(s_["semrush_organic_keywords_us"]) / float(a_["ahrefs_organic_keywords"])
    if age != age_c or abs(vr - vr_c) > 0.005 or abs(kr - kr_c) > 0.05:
        ok = False
        print(f"   {name}: figure ({age}, {vr}, {kr}) data ({age_c}, {vr_c:.3f}, {kr_c:.2f})")
check("Figure 5 points (age, visits ratio, keyword ratio) = prefix CSVs", ok)
check("Figure 5 panel (a) title gives Spearman -0.11", "Spearman ρ = −0.11" in src)
# Figure 9 (fig6_positions): Table 5, single reads, Table 6
T5 = {r[0]: r[1:] for r in series("instrument_series_table5_checkpoints.csv")[1:]}
DAYS = [0, 15, 30, 37, 45, 60, 75, 77]
SR = {(r["quantity"]): r["value"] for r in csv.DictReader((ROOT / "instrument_divergence_extra/single_reads_2026-10.csv").open(encoding="utf-8"))}
fd, fa, ft = const("days"), const("pos_all"), const("pos_top3")
exp_a = {d: num(T5["Ranking positions, all"][DAYS.index(d)]) for d in DAYS}
exp_t = {d: num(T5["Positions 1–3"][DAYS.index(d)]) for d in DAYS}
exp_a.update({6: num(SR["ranking positions at day 6"]), 67: num(SR["ranking positions at day 67"])})
exp_t.update({6: num(SR["positions 1 to 3 at day 6"]), 67: num(SR["positions 1 to 3 at day 67"])})
check("Figure 9 positions, all, by day = Table 5 and single reads", all(exp_a[d] == v for d, v in zip(fd, fa)), str(list(zip(fd, fa))))
check("Figure 9 positions 1-3 by day = Table 5 and single reads", all(exp_t[d] == v for d, v in zip(fd, ft)))
rd = ast.literal_eval(re.search(r"for d, n in (\[.*?\]):", src).group(1))
check("Figure 9 referring-domain labels = Table 5", all(num(T5["Live referring domains"][DAYS.index(d)]) == n for d, n in rd), str(rd))
T6 = series("instrument_series_table6_intervals.csv")[1:]
iv = ast.literal_eval(re.search(r"^iv = (\[.*?\])", src, re.M | re.S).group(1))
check("Figure 9 interval rates = Table 6", [r for _, _, r, _ in iv] == [int(num(x[4].split(" /")[0])) for x in T6], str([r for _, _, r, _ in iv]))
# Figure 3 (fig2_aio): Table 3
T3 = series("instrument_series_table3_ai_overview_citation_by_month.csv")[1:]
check("Figure 3 numerators, denominators, Semrush counts = Table 3",
      const("num") == [num(r[1].split(" of ")[0]) for r in T3] and const("den") == [num(r[1].split(" of ")[1]) for r in T3]
      and const("semb") == [num(r[3]) for r in T3])
# Figure 8 (fig5_cited) and Figure 4 (fig3_refdomains): single reads
pages = ast.literal_eval(re.search(r"^pages = (\[.*?\])", src, re.M | re.S).group(1))
key = {"New York hub": "New York state hub", "California hub": "California state hub", "Texas hub": "Texas state hub", "Florida hub": "Florida state hub",
       "national hub": "national hub", "214 (Dallas) code page": "214 (Dallas) code page", "786 (Miami) code page": "786 (Miami) code page",
       "404 (Atlanta) code page": "404 (Atlanta) code page"}
check("Figure 8 answers per page = single reads", all(num(SR[f"stored AI answers citing the page: {key[p]}"]) == n for p, n, _ in pages))
tld = re.findall(r'\("(\.[a-z]+|other|not stated)", ([\d.]+),', src)
check("Figure 4 TLD shares = single reads (.info 61.9, .asia 26.4, .xyz 10.2; Semrush .xyz 75)",
      [(t, float(v)) for t, v in tld] == [(".info", 61.9), (".asia", 26.4), (".xyz", 10.2), ("other", 1.5), (".xyz", 75.0), ("not stated", 25.0)], str(tld))
# Figure 6 (fig9_reviews.pdf): labels printed in the shipped figure
txt = subprocess.run(["pdftotext", "-layout", str(ROOT / "fig9_reviews.pdf"), "-"], capture_output=True, text=True).stdout
check("Figure 6 (shipped) panel (a) reads '1,008 taxonomy labels, Spearman +0.18'", "1,008 taxonomy labels, Spearman +0.18" in txt)
check("Figure 6 (shipped) panel (b) reads 'nine of 17), Spearman +0.75'", "(nine of 17), Spearman +0.75" in txt)
check("Figure 6 script titles match the shipped figure", "1,008 taxonomy labels, Spearman +0.18" in (ROOT / "review_demand/make_fig_reviews_v50.py").read_text())
print(f"{sum(res)} of {len(res)} figure checks OK")
