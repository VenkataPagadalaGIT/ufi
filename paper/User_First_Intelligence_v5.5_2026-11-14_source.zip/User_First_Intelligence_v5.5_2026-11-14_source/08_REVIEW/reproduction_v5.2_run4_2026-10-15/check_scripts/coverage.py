"""Coverage of the number check: every numeric token in the manuscript (body and appendices, not the reference list)
must be either claimed in numbers_table.tsv or excluded by a stated rule as a label (section, table, figure, year,
date, day number, time, version, enumeration, confidence level, band definition, name).

Usage: python3 -E -P coverage.py <manuscript_v50.md> <numbers_table.tsv>
Prints uncovered tokens with context, and claims whose token was not found on their line.
"""
import csv
import re
import sys
from collections import Counter, defaultdict

from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))  # this review folder's own tokens.py
from tokens import TOK, tokens  # noqa: E402  (this folder's tokens.py)

lines = open(sys.argv[1], encoding="utf-8").read().split("\n")
claims = defaultdict(list)
for r in csv.DictReader(open(sys.argv[2], encoding="utf-8"), delimiter="\t"):
    if TOK.fullmatch(r["token"]):
        claims[int(r["line"])].append(r["token"])
REF_START, REF_END = 532, 695   # the reference list
MONTH = r"(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)"
REFWORD = r"(?:Sections?|Tables?|Figures?|Appendix|Appendices|lessons?|conditions?|items?|Measurements?|amendments?|clause|section|sections|step|Round|rounds?|Task|version|versions|Version|Versions|v|Opus|Fable|Python|Apache|tectonic|chapter|equation|digest|commit|SHA-256)"
RULES = [
    ("heading", lambda s, i, t: s.startswith("#")),
    ("year", lambda s, i, t: re.fullmatch(r"(19|20)\d\d", t) is not None),
    ("reference to a section/table/figure/version", lambda s, i, t: re.search(REFWORD + r"\s+(?:[\dA-Z][\w.]*(?:\s*(?:,|and|to|or|–|-)\s*)?)*$", s[:i]) is not None),
    ("date", lambda s, i, t: re.match(r"\s*(?:–\s*\d+\s+)?" + MONTH, s[i + len(t):]) is not None or re.search(MONTH + r"\s+$", s[:i]) is not None),
    ("day number", lambda s, i, t: re.search(r"(?:\b[Dd]ays?|-day|day-)[\s-]*(?:\d+\s*(?:,|and|to|–)\s*)*$", s[:i]) is not None),
    ("time", lambda s, i, t: re.match(r":\d\d", s[i + len(t):]) is not None or re.search(r"\d\d:$", s[:i]) is not None),
    ("enumeration", lambda s, i, t: (i == 0 and s[len(t):len(t) + 2] == ". ") or (s[i - 1:i] == "(" and s[i + len(t):i + len(t) + 1] == ")")),
    ("confidence level", lambda s, i, t: t == "95%" and (re.match(r"\s*(?:Wilson|CI|bootstrap|confidence|interval|intervals)\b", s[i + len(t):]) is not None
                                                        or re.search(r"(?:Wilson|bootstrap|Fisher)\s+$", s[:i]) is not None)),
    ("band definition", lambda s, i, t: re.search(r"(?:[Pp]ositions?|ranks?|band|rows?|Ranks)\s+(?:\d+\s*(?:–|to|-)\s*)?$", s[:i]) is not None
                                        and re.match(r"(?:\s*(?:–|to)\s*\d+)?", s[i + len(t):]) is not None and int(float(t.replace(",", "").rstrip("%x").replace("−", "-"))) in (1, 3, 4, 10, 11, 20, 21, 100, 501, 1000, 250, 500)),
    ("name (S&P 500, path)", lambda s, i, t: (t == "500" and s[max(0, i - 4):i] == "S&P ") or s[i + len(t):i + len(t) + 1] == "_" or s[i - 1:i] == "_"),
    ("model or tool version", lambda s, i, t: re.search(r"(?:Opus|Fable|Python|Apache|version|tectonic|v)\s*$", s[:i]) is not None),
]

total = covered = labelled = 0
unc_out, miss_out = [], []
rule_count = Counter()
for n in list(range(1, REF_START)) + list(range(REF_END + 1, len(lines) + 1)):
    s = lines[n - 1]
    toks = tokens(s)
    if not toks and not claims.get(n):
        continue
    status = []
    for i, t in toks:
        lab = next((name for name, f in RULES if f(s, i, t)), None)
        status.append([i, t, lab, False])
    pending = list(claims.get(n, []))
    for want in list(pending):
        cand = [x for x in status if x[1] == want and not x[3] and x[2] is None] or [x for x in status if x[1] == want and not x[3]]
        if cand:
            cand[0][3] = True
            pending.remove(want)
    for t in pending:
        miss_out.append(f"line {n}: claim token {t!r} not found among the line's tokens")
    for i, t, lab, used in status:
        total += 1
        if used:
            covered += 1
        elif lab:
            labelled += 1
            rule_count[lab] += 1
        else:
            unc_out.append(f"line {n}: {t!r}  ...{s[max(0, i - 70):i]}[{t}]{s[i + len(t):i + len(t) + 40]}...")
print(f"numeric tokens outside the reference list: {total}; claimed {covered}; excluded as labels {labelled}; uncovered {len(unc_out)}")
print("labels by rule: " + ", ".join(f"{k} {v}" for k, v in rule_count.most_common()))
print(f"claims whose token was not found on their line: {len(miss_out)}")
for x in miss_out:
    print("  " + x)
print("uncovered tokens:")
for x in unc_out:
    print("  " + x)
