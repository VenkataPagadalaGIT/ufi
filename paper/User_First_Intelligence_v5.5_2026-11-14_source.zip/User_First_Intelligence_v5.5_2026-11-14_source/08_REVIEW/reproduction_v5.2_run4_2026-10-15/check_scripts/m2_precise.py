"""Measurement 2 statistics at full precision from the released anonymized counts (an independent re-implementation,
not the bundle's script). Replicates m2_from_counts.py's definitions and its bootstrap sequence (seed 20261015, same
order of calls and of data), prints every value with 6 decimals, and adds three statistics the paper quotes that
m2_from_counts.py does not print but the released counts allow: Kendall's tau over mentioned labels, the Spearman
over labels with at least twenty mentions, and the number of mentioned labels in the lowest volume-rank group.

Usage: python3 -E -P m2_precise.py <review_demand folder> > m2_precise.txt
"""
import csv
import json
import random
import sys
from pathlib import Path

from scipy.stats import kendalltau, spearmanr

D = Path(sys.argv[1])
L = list(csv.DictReader((D / "m2_label_counts.csv").open()))
BR = list(csv.DictReader((D / "m2_branches.csv").open()))
bv = {b["branch_id"]: float(b["own_volume_share"]) for b in BR}
names = {b["branch_id"]: b["branch"] for b in BR}
ment = [int(x["mentions"]) for x in L]
vrank = [float(x["volume_rank"]) for x in L]
orank = [float(x["own_volume_rank"]) for x in L]
nodes = [{k: int(c) for k, c in (p.split(":") for p in x["branch_nodes"].split(";"))} for x in L]
multi = [int(x["words"]) >= 2 for x in L]
out = {}

out["n_labels"] = len(L)
mi = [k for k in range(len(L)) if ment[k] > 0]
out["n_mentioned"] = len(mi)
out["rho_all"] = spearmanr(ment, vrank).statistic
out["tau_all"] = kendalltau(ment, vrank).statistic
out["rho_mentioned"] = spearmanr([ment[k] for k in mi], [vrank[k] for k in mi]).statistic
out["tau_mentioned"] = kendalltau([ment[k] for k in mi], [vrank[k] for k in mi]).statistic
ge20 = [k for k in mi if ment[k] >= 20]
out["n_ge20"] = len(ge20)
out["rho_ge20"] = spearmanr([ment[k] for k in ge20], [vrank[k] for k in ge20]).statistic
low = min(vrank)
out["min_volume_rank"] = low
out["n_labels_min_volume_rank"] = sum(1 for v in vrank if v == low)
out["n_mentioned_min_volume_rank"] = sum(1 for k in mi if vrank[k] == low)


def branch_split(counts, rows):
    o = {}
    for k in rows:
        if counts[k]:
            tot = sum(nodes[k].values())
            for b, c in nodes[k].items():
                o[b] = o.get(b, 0) + counts[k] * c / tot
    return o


def branch_modal(counts, rows):
    o = {}
    for k in rows:
        if counts[k]:
            b = max(nodes[k].items(), key=lambda bc: bc[1])[0]
            o[b] = o.get(b, 0) + counts[k]
    return o


def shares(d):
    tot = sum(d.get(b, 0) for b in bv)
    return [d.get(b, 0) / tot for b in bv]


bm = branch_split(ment, range(len(L)))
rs, vs = shares(bm), [bv[b] / sum(bv.values()) for b in bv]
B = sorted(zip(bv, rs, vs), key=lambda t: -t[1])
out["branch_shares_split"] = {names[b]: [r_, v_] for b, r_, v_ in B}
out["rho_branch_split"] = spearmanr([t[1] for t in B], [t[2] for t in B]).statistic
out["p_branch_split"] = spearmanr([t[1] for t in B], [t[2] for t in B]).pvalue
r2v = shares(branch_modal(ment, range(len(L))))
out["rho_branch_modal"] = spearmanr(r2v, vs).statistic
out["p_branch_modal"] = spearmanr(r2v, vs).pvalue
out["rho_own_mentioned"] = spearmanr([ment[k] for k in mi], [orank[k] for k in mi]).statistic
out["rho_own_all"] = spearmanr(ment, orank).statistic

rng = random.Random(20261015)


def boot(xs, ys, reps):
    n, o = len(xs), []
    for _ in range(reps):
        idx = [rng.randrange(n) for _ in range(n)]
        r_ = spearmanr([xs[i] for i in idx], [ys[i] for i in idx]).statistic
        if r_ == r_:
            o.append(r_)
    o.sort()
    return o[int(0.025 * len(o))], o[int(0.975 * len(o)) - 1]


out["ci_mentioned"] = boot([ment[k] for k in mi], [vrank[k] for k in mi], 10_000)
out["ci_all"] = boot(ment, vrank, 2_000)
out["ci_branch_split"] = boot([t[1] for t in B], [t[2] for t in B], 10_000)
out["ci_branch_modal"] = boot(r2v, vs, 10_000)

mw = sorted((k for k in range(len(L)) if multi[k]), key=lambda k: int(L[k]["multiword_order"]))
cm = {k: int(L[k]["mentions_multiword_linker"]) for k in mw}
mmw = [k for k in mw if cm[k] > 0]
out["mw_n_labels"], out["mw_n_mentioned"] = len(mw), len(mmw)
out["mw_rho_all"] = spearmanr([cm[k] for k in mw], [vrank[k] for k in mw]).statistic
out["mw_rho_mentioned"] = spearmanr([cm[k] for k in mmw], [vrank[k] for k in mmw]).statistic
out["mw_ci_mentioned"] = boot([cm[k] for k in mmw], [vrank[k] for k in mmw], 10_000)
cnt_mw = [cm.get(k, 0) for k in range(len(L))]
Bm = shares(branch_split(cnt_mw, mw))
out["mw_rho_branch_split"] = spearmanr(Bm, vs).statistic
out["mw_ci_branch_split"] = boot(Bm, vs, 10_000)
out["mw_rho_branch_modal"] = spearmanr(shares(branch_modal(cnt_mw, mw)), vs).statistic
top = sorted(zip(bv, Bm, vs), key=lambda t: -t[1])[:3]
out["mw_top3_branches"] = {names[b]: [r_, v_] for b, r_, v_ in top}

json.dump(out, sys.stdout, indent=1, default=float)
print()
