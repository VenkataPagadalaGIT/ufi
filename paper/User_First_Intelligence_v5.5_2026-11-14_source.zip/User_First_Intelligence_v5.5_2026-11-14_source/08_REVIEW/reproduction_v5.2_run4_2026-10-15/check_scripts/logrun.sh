#!/bin/bash
# Command logger for the run-4 reproduction. Reads one command (possibly multi-line)
# from stdin, appends it with a timestamp to command_log.txt, runs it with bash -c,
# and records the exit status.
LOG=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15/command_log.txt
CMD=$(cat)
{ printf '[%s] $ ' "$(date '+%Y-%m-%d %H:%M:%S')"; printf '%s\n' "$CMD"; } >> "$LOG"
bash -c "$CMD" </dev/null
rc=$?
printf '    -> exit %d\n' "$rc" >> "$LOG"
exit $rc
