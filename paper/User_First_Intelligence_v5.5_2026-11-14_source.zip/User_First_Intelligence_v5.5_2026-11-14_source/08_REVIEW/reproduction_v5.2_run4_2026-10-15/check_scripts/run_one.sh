#!/bin/bash
# usage: run_one.sh <working dir> <label> <command...>
# Runs a bundle script exactly as documented from its own folder; saves stdout and stderr
# to outputs/<label>_stdout.txt and outputs/<label>_stderr.txt and appends a status line.
R=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run4_2026-10-15
dir="$1"; label="$2"; shift 2
cd "$dir" || { echo "no such dir $dir"; exit 99; }
start=$(date +%s)
"$@" > "$R/outputs/${label}_stdout.txt" 2> "$R/outputs/${label}_stderr.txt"
rc=$?
end=$(date +%s)
printf '%s\texit=%d\tseconds=%d\tcwd=%s\tcmd=%s\n' "$label" "$rc" "$((end-start))" "$dir" "$*" | tee -a "$R/outputs/run_status.tsv"
exit 0
