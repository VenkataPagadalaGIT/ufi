"""Numeric tokens of the manuscript, by line, for the coverage check.

Usage: python3 -E -P tokens.py <manuscript_v50.md> [first line] [last line]
A token is a run of digits with optional sign, thousands commas, decimals, and a %, x, K or M suffix.
"""
import re
import sys

TOK = re.compile(r"(?<![A-Za-z0-9_])([−+\-]?\d[\d,]*(?:\.\d+)?)(%|x|K|M)?(?![A-Za-z0-9])")


def tokens(line):
    out = []
    for m in TOK.finditer(line):
        t = m.group(1).rstrip(",")
        out.append((m.start(), t + (m.group(2) or "")))
    return out


if __name__ == "__main__":
    lines = open(sys.argv[1], encoding="utf-8").read().split("\n")
    lo = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    hi = int(sys.argv[3]) if len(sys.argv) > 3 else len(lines)
    total = 0
    for i in range(lo, hi + 1):
        t = tokens(lines[i - 1])
        total += len(t)
        if t:
            print(f"{i}: " + " | ".join(x for _, x in t))
    print(f"total tokens {total}")
