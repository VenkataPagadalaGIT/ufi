"""Every number the manuscript quotes, checked at the precision it is quoted against what the rerun scripts print, the
released data files and arithmetic (independent reproduction, run 4, 15 October 2026).

Usage: python3 -E -P check_numbers.py <pristine bundle root> <review outputs dir>
Writes <outputs>/numbers_table.tsv and prints a summary. Reads the rerun outputs saved in <outputs> and, for scripts
that cannot run, the outputs shipped in the bundle (only to say whether the paper agrees with them).

Statuses
  MATCH       the quoted value equals, at its quoted precision, a rerun script's output, a released data file, or
              arithmetic on released files (half-up rounding of the full-precision value; a value exactly on a
              rounding boundary is accepted either way and flagged)
  MISMATCH    it does not; both values are given
  CANNOT RUN  the value rests on input the bundle does not contain (withheld licensed or vendor data, the author's
              unreleased records, an external repository); the note says whether it agrees with a shipped output
  EXTERNAL    a figure the paper cites from another work; not reproducible from the bundle and not counted
"""
import csv
import json
import math
import re
import statistics
import sys
from datetime import date, timedelta
from fractions import Fraction
from itertools import combinations
from pathlib import Path

import numpy as np
from scipy.stats import kendalltau, spearmanr

PRI, OUT = Path(sys.argv[1]), Path(sys.argv[2])
MS = (PRI / "manuscript_v50.md").read_text(encoding="utf-8").split("\n")


def rd(name):
    return (OUT / name).read_text(encoding="utf-8")


def sh(rel):
    return (PRI / rel).read_text(encoding="utf-8")


def g(text, pat, grp=1, cast=float):
    m = re.search(pat, text)
    if not m:
        raise SystemExit(f"pattern not found: {pat}")
    return cast(m.group(grp).replace(",", ""))


# ------------------------------------------------------------------------------------------------ outputs to check
ANA = rd("analyze_stdout.txt")
IEX = rd("instrument_extra_stdout.txt")
M2O = rd("m2_from_counts_stdout.txt")
R2O = rd("r2_link_check_stdout.txt")
VRO = rd("vendor_reliance_offline_stdout.txt")
SSO = rd("stakes_screen_check_stdout.txt")
S7O = rd("section7_from_aggregates_stdout.txt")
TBO = rd("make_tables_sector_surface_stdout.txt")
URL = rd("make_brand_radar_urls_stdout.txt")
M2P = json.loads(rd("m2_precise.json"))
# shipped outputs of scripts that cannot run on the bundle (used only to report agreement)
ARO = sh("review_demand/analyze_reviews_output.txt")
SUP = sh("review_demand/supplement_r10_output.txt")
RLS = sh("review_demand/r2_link_sample_output.txt")
SCR = "ai_citation_cross_sector/scripts/"
CSO = sh(SCR + "cross_sector_output.txt")
SEN = sh(SCR + "cross_sector_sensitivity_output.txt")
SEN2 = sh(SCR + "cross_sector_sensitivity2_output.txt")
PIL = sh(SCR + "pilot_section_output.txt")
DESIGN = sh("ai_citation_cross_sector/design/cross_sector_ai_citation_study.md")

# ------------------------------------------------------------------------------------------------ claim registry
ROWS = []
SECTION = [""]


def sec(name):
    SECTION[0] = name


def _parse(tok):
    t = tok.replace("−", "-").replace(",", "").replace("+", "")
    unit = ""
    if t and t[-1] in "%xKM":
        unit, t = t[-1], t[:-1]
    d = len(t.split(".")[1]) if "." in t else 0
    return float(t), d, unit


def _fmt(v):
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, (int, np.integer)):
        return f"{int(v):,}"
    if isinstance(v, (float, np.floating)):
        return f"{float(v):.6g}" if abs(v) < 1e5 else f"{float(v):,.1f}"
    return str(v)


def _add(line, tok, status, computed, basis, note, cat="study", circ=False):
    ROWS.append(dict(line=line, section=SECTION[0], token=tok, status=status, computed=computed, basis=basis,
                     note=note, category=cat, circular=int(circ), context=_ctx(line, tok)))


def _ctx(line, tok):
    if not line:
        return ""
    s = MS[line - 1]
    i = s.find(tok)
    if i < 0:
        return s[:90]
    return s[max(0, i - 60): i + len(tok) + 30].replace("|", "/")


def M(line, tok, value, basis, note="", approx=None, circ=False):
    """Numeric check of a quoted token against a value in the token's unit (percent tokens take percent values)."""
    q, d, unit = _parse(tok)
    v = float(value)
    tol = 0.5 * 10 ** -d
    boundary = abs(abs(v - q) - tol) < 1e-9
    ok = abs(v - q) <= tol + 1e-9
    if approx is not None:  # the paper says "about", "roughly" or "nearly": accept within the stated relative band
        ok = ok or abs(v - q) <= abs(q) * approx
        note = (note + "; " if note else "") + f"approximate wording, accepted within {approx:.0%}"
    if boundary:
        note = (note + "; " if note else "") + "full-precision value lies exactly on the rounding boundary"
    if "−" in tok or tok.startswith("+") or tok.startswith("-"):
        sign_q = -1 if tok.startswith(("−", "-")) else 1
        if q != 0 and v != 0 and sign_q * v < 0:
            ok = False
    _add(line, tok, "MATCH" if ok else "MISMATCH", _fmt(v), basis, note, circ=circ)


def B(line, tok, ok, computed, basis, note="", circ=False):
    """A check that is not a rounding comparison (a count stated in words, a date, a text fact)."""
    _add(line, tok, "MATCH" if ok else "MISMATCH", _fmt(computed), basis, note, circ=circ)


def CR(line, tok, basis, shipped=None, note=""):
    """Cannot run: shipped = (value in the token's unit, source) when a shipped output carries the figure."""
    if shipped is not None:
        v, src = shipped
        if isinstance(v, bool):
            agree = v
            val = ""
        else:
            q, d, unit = _parse(tok)
            agree = abs(float(v) - q) <= 0.5 * 10 ** -d + 1e-9
            val = _fmt(v)
        note = (f"agrees with {src}" if agree else f"DISAGREES with {src} ({val})") + (f"; {note}" if note else "")
    _add(line, tok, "CANNOT RUN", "", basis, note)


def EXT(line, tok, note=""):
    _add(line, tok, "EXTERNAL", "", "cited from another work", note, cat="external")


def LAB(line, tok, note=""):
    _add(line, tok, "LABEL", "", "not a quantitative claim", note, cat="label")


def wilson(k, n, z=1.96):
    p = k / n
    c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return c - h, c + h


def num(s):
    return float(str(s).replace(",", "").replace("≈", "").strip())


D0 = date(2026, 7, 26)


def day(n):
    return D0 + timedelta(days=n)


# ------------------------------------------------------------------------------------------------ released data
CODES = list(csv.DictReader((PRI / "instrument_divergence_extra/section_code_pages_2026-10-14.csv").open()))
CODE = {r["code"]: r for r in CODES}
LOCS = sorted({r["location"] for r in CODES})
SRL = list(csv.DictReader((PRI / "instrument_divergence_extra/single_reads_2026-10.csv").open(encoding="utf-8")))
SR = {r["quantity"]: r for r in SRL}  # for prefix lookups only; quantities that repeat are read through _srrow


def _srrow(q, inst=None):
    rows = [r for r in SRL if r["quantity"] == q and (inst is None or r["instrument"].startswith(inst))]
    if len(rows) != 1:
        raise SystemExit(f"single read {q!r} ({inst}): {len(rows)} rows")
    return rows[0]


def sr(q, inst=None):
    return _srrow(q, inst)["value"]


def sr_date(q, inst=None):
    return _srrow(q, inst)["read date as stated in the paper"]


A = {r["prefix"]: r for r in csv.DictReader((PRI / "data/ahrefs_prefixes_2026-10-12.csv").open())}
S = {r["prefix"]: r for r in csv.DictReader((PRI / "data/semrush_prefixes_2026-10-12.csv").open())}
P = list(A)
AC = "/local/area-codes/"
at = {p: float(A[p]["ahrefs_organic_traffic"]) for p in P}
st = {p: float(S[p]["semrush_organic_traffic_us"]) for p in P}
ak = {p: float(A[p]["ahrefs_organic_keywords"]) for p in P}
sk = {p: float(S[p]["semrush_organic_keywords_us"]) for p in P}
ard = {p: float(A[p]["ahrefs_ref_domains"]) for p in P}
srd = {p: float(S[p]["semrush_ref_domains"]) for p in P}
us = {p: float(A[p]["ahrefs_us_share"]) for p in P}
age = {p: (2026 - int(A[p]["ahrefs_first_traffic_month"][:4])) * 12 + (10 - int(A[p]["ahrefs_first_traffic_month"][5:7])) for p in P}
vr = {p: st[p] / at[p] for p in P}
vm = {p: st[p] / (at[p] * us[p]) for p in P}
kr = {p: sk[p] / ak[p] for p in P}
rr = {p: ard[p] / srd[p] for p in P}


def series(name):
    with (PRI / f"instrument_divergence_extra/{name}").open(encoding="utf-8") as f:
        return list(csv.reader(f))


T2 = series("instrument_series_table2_visits_by_month.csv")
T3 = series("instrument_series_table3_ai_overview_citation_by_month.csv")
T5 = series("instrument_series_table5_checkpoints.csv")
T6 = series("instrument_series_table6_intervals.csv")


def t2(month_prefix):
    row = [r for r in T2 if r[0].startswith(month_prefix)][0]
    a = num(row[2])
    us_, ww = re.match(r"([\d,]+) \(([\d,]+)\)", row[3]).groups()
    return a, num(us_), num(ww)


MONTHS = ["July", "August", "September", "October"]
T2V = {m: t2(m) for m in MONTHS}
R_US_AW = {m: T2V[m][1] / T2V[m][0] for m in MONTHS}
R_WW = {m: T2V[m][2] / T2V[m][0] for m in MONTHS}
US_SHARE_T2 = float(sr("Ahrefs' US share of its own visits used for the US-to-US ratios").rstrip("%")) / 100
R_USUS = {m: T2V[m][1] / (T2V[m][0] * US_SHARE_T2) for m in MONTHS}
T3V = {}
for r in T3[1:]:
    k, n = (num(x) for x in r[1].split(" of "))
    T3V[r[0].split()[0]] = (k, n, num(r[3]))
T5H = T5[0]
T5R = {r[0]: r[1:] for r in T5[1:]}
T5DAYS = [0, 15, 30, 37, 45, 60, 75, 77]


def t5(metric, d):
    v = T5R[metric][T5DAYS.index(d)]
    return None if v == "n/r" else num(v)


# ------------------------------------------------------------------------------------------------ M1 statistics, recomputed
def ranks(x):
    return list(np.argsort(np.argsort(x)))


AGES = [age[p] for p in P]
rho_age = spearmanr(AGES, [vr[p] for p in P]).statistic
z, se = math.atanh(rho_age), 1 / math.sqrt(len(P) - 3)
fisher = (math.tanh(z - 1.96 * se), math.tanh(z + 1.96 * se))
PX = [p for p in P if p != AC]
rho_age_x = spearmanr([age[p] for p in PX], [vr[p] for p in PX]).statistic
rho_age_m = spearmanr(AGES, [vm[p] for p in P]).statistic
rho_kv = spearmanr([kr[p] for p in P], [vr[p] for p in P])
rho_kv_x = spearmanr([kr[p] for p in PX], [vr[p] for p in PX])
rho_v = spearmanr([at[p] for p in P], [st[p] for p in P])
tau_v = kendalltau([at[p] for p in P], [st[p] for p in P])
conc = disc = 0
bands = {"within": [], "beyond": []}
opposite = []
for x, y in combinations(P, 2):
    s_ = (at[x] - at[y]) * (st[x] - st[y])
    conc += s_ > 0
    disc += s_ < 0
    gm = max(math.sqrt(at[x] * st[x]), math.sqrt(at[y] * st[y])) / min(math.sqrt(at[x] * st[x]), math.sqrt(at[y] * st[y]))
    bands["within" if gm <= 3 else "beyond"].append(s_ > 0)
    if s_ < 0:
        opposite.append((x, y, max(at[x], at[y]) / min(at[x], at[y]), max(st[x], st[y]) / min(st[x], st[y])))
lr = [math.log(vr[p]) for p in P]
gmean, gsd = math.exp(statistics.mean(lr)), math.exp(statistics.stdev(lr))
grange = (math.exp(statistics.mean(lr) - 1.96 * statistics.stdev(lr)), math.exp(statistics.mean(lr) + 1.96 * statistics.stdev(lr)))
med_vr, med_vm = statistics.median(vr.values()), statistics.median(vm.values())
mid = [p for p in P if 84 <= age[p] < 144]
from statistics import NormalDist
zr = math.atanh(0.5)
power = NormalDist().cdf(zr / se - 1.96) + NormalDist().cdf(-zr / se - 1.96)
# permutation p for rho(age, ratio), independently (numpy, 200,000 permutations; analyze.py uses its own seed)
rng_np = np.random.default_rng(4)
ra_, rv_ = np.array(ranks(AGES), float), np.array(ranks([vr[p] for p in P]), float)
# average ranks for ties in age (two prefixes share 95 months)
from scipy.stats import rankdata
ra_, rv_ = rankdata(AGES), rankdata([vr[p] for p in P])
obs = abs(np.corrcoef(ra_, rv_)[0, 1])
perm = np.array([abs(np.corrcoef(ra_, rng_np.permutation(rv_))[0, 1]) for _ in range(200_000)])
perm_p = float(np.mean(perm >= obs - 1e-12))

# ------------------------------------------------------------------------------------------------ M3 aggregates, recomputed
AGG = PRI / "ai_citation_cross_sector/aggregates"
PM = {(r["etf"], r["surface"]): r for r in csv.DictReader((AGG / "cross_sector_platform_metrics.csv").open())}
TS = {(r["etf"], r["surface"]): {k: float(v) for k, v in r.items() if k.startswith("share_")}
      for r in csv.DictReader((AGG / "cross_sector_type_shares.csv").open())}
for t in TS.values():
    t["share_video_community"] = t["share_video"] + t["share_forum"] + t["share_social"] + t["share_user_publishing"]
CELLS = {(r["etf"], r["surface"]): r for r in csv.DictReader((AGG / "cross_sector_cells.csv").open())}
COUNTS = {r["etf"]: r for r in csv.DictReader((AGG / "sector_answer_counts.csv").open())}
TOP = {}
for r in csv.DictReader((AGG / "cross_sector_top10_nonbrand.csv").open()):
    TOP.setdefault((r["etf"], r["surface"]), []).append((int(r["rank"]), r["domain"]))
TOP = {k: [d for _, d in sorted(v)] for k, v in TOP.items()}
SECTORS = ["xlk", "xlv", "xlf", "xly", "xlc", "xli", "xlp", "xle", "xlu", "xlre", "xlb"]
GOOGLE = ["aio_searchqueries", "aio_prompts", "aimode_searchqueries", "aimode_prompts"]
CHAT = ["chatgpt", "perplexity", "gemini", "copilot"]
SURF = GOOGLE + CHAT
COMP = list(csv.DictReader((PRI / "ai_citation_cross_sector/design/cross_sector_companies.csv").open()))
PROPS = list(csv.DictReader((PRI / "ai_citation_cross_sector/design/cross_sector_company_properties.csv").open()))


def comm(s, p):
    return float(PM[(s, p)]["share_community_video"])


def yr(s, p, col="yt_rank_nonbrand"):
    v = PM[(s, p)][col]
    return int(v) if v else 9999


med = statistics.median
G_ALL = [comm(s, p) for s in SECTORS for p in GOOGLE]
C_ALL = [comm(s, p) for s in SECTORS for p in CHAT]
SURF_MED = {p: med([comm(s, p) for s in SECTORS]) for p in SURF}
EVERY = sum(min(comm(s, p) for p in GOOGLE) > max(comm(s, p) for p in CHAT) for s in SECTORS)
NYT = lambda s, p: comm(s, p) - float(PM[(s, p)]["yt_share"])
EVERY_NYT = sum(min(NYT(s, p) for p in GOOGLE) > max(NYT(s, p) for p in CHAT) for s in SECTORS)
YT_MED = {p: med([yr(s, p) for s in SECTORS]) for p in SURF}
YT_TOP3_G = sum(yr(s, p) <= 3 for s in SECTORS for p in GOOGLE)
YT_TOP3_C = sum(yr(s, p) <= 3 for s in SECTORS for p in CHAT)
P1 = {p: sum(yr(s, p) == 1 for s in SECTORS) for p in GOOGLE}
P2 = {p: sum(yr(s, p) > 5 for s in SECTORS) for p in ("chatgpt", "perplexity", "copilot")}
P1_BOTH = sum(any(yr(s, p) == 1 for p in GOOGLE[:2]) and any(yr(s, p) == 1 for p in GOOGLE[2:]) for s in SECTORS)
P3 = [s for s in SECTORS if all(yr(s, p, "reddit_rank_nonbrand") <= 10 for p in SURF if p != "copilot")]
P3_CHATFAIL = sum(yr(s, "chatgpt", "reddit_rank_nonbrand") > 10 for s in SECTORS if s not in P3)
CONS, NONC = ["xly", "xlp", "xlc", "xlv", "xlk"], ["xle", "xlb", "xlu", "xlre", "xli"]


def exact_p(a, b):
    pooled, obsd = a + b, statistics.mean(a) - statistics.mean(b)
    hits = tot = 0
    for idx in combinations(range(len(pooled)), len(a)):
        x = [pooled[i] for i in idx]
        y = [pooled[i] for i in range(len(pooled)) if i not in set(idx)]
        tot += 1
        hits += (statistics.mean(x) - statistics.mean(y)) >= obsd - 1e-12
    return hits / tot


P4 = {p: (statistics.mean([comm(s, p) for s in CONS]), statistics.mean([comm(s, p) for s in NONC]),
          exact_p([comm(s, p) for s in CONS], [comm(s, p) for s in NONC])) for p in ("aio_searchqueries", "aio_prompts")}
JAC = {p: statistics.mean(len(set(TOP[(a, p)]) & set(TOP[(b, p)])) / len(set(TOP[(a, p)]) | set(TOP[(b, p)]))
                          for a, b in combinations(SECTORS, 2)) for p in SURF}


def var_split(key):
    v = {(s, p): TS[(s, p)][key] for s in SECTORS for p in SURF}
    gm_ = statistics.mean(v.values())
    tot = sum((x - gm_) ** 2 for x in v.values())
    ssp = len(SECTORS) * sum((statistics.mean(v[(s, p)] for s in SECTORS) - gm_) ** 2 for p in SURF)
    sss = len(SURF) * sum((statistics.mean(v[(s, p)] for p in SURF) - gm_) ** 2 for s in SECTORS)
    return ssp / tot, sss / tot


VAR = {k: var_split(k) for k in ("share_video_community", "share_news", "share_government", "share_report_brands")}
TYPEMED = {k: (med([TS[(s, p)][k] for s in SECTORS for p in GOOGLE]), med([TS[(s, p)][k] for s in SECTORS for p in CHAT]),
               med([TS[(s, "copilot")][k] for s in SECTORS]))
           for k in ("share_reference", "share_forum", "share_report_brands", "share_other_web")}
NO_XLI = [s for s in SECTORS if s != "xli"]
CHATGPT_MED_NOXLI = med([comm(s, "chatgpt") for s in NO_XLI])
P2_NOXLI = {p: sum(yr(s, p) > 5 for s in NO_XLI) for p in ("chatgpt", "perplexity", "copilot")}
P3_NOXLI = sum(all(yr(s, p, "reddit_rank_nonbrand") <= 10 for p in SURF if p != "copilot") for s in NO_XLI)
SIZES = [int(CELLS[(s, p)]["cited_in_sum"]) for s in SECTORS for p in SURF]
DOMS = [int(CELLS[(s, p)]["registrable_domains"]) for s in SECTORS for p in SURF]
TRUNC = {p: med([float(CELLS[(s, p)]["mass_rows_501_1000"]) for s in SECTORS]) for p in SURF}
ANS = {s: int(COUNTS[s]["ai_responses_us_all_platforms"]) for s in SECTORS}

# ================================================================================================ CLAIMS
# Shipped values of scripts that cannot run (for the agreement note only)
SUP_REVIEWS = g(SUP, r"review rows (\d+)")
SUP_TEXT = g(SUP, r"with text (\d+)")
SUP_NODES = g(SUP, r"taxonomy nodes (\d+);")
SUP_KW = g(SUP, r"keywords the taxonomy was built from (\d+)")
SUP_LOC = g(SUP, r"locations in the export (\d+)")
SUP_LOCTXT = g(SUP, r"with at least one text review (\d+)")
SUP_MIN, SUP_MED, SUP_MAX = (g(SUP, r"reviews per location min (\d+), median (\d+), max (\d+)", i) for i in (1, 2, 3))
SUP_CARR_LOC = g(SUP, r"locations whose owner responses name a carrier (\d+)")
SUP_CARR_N = g(SUP, r"naming (\d+) different carriers")
ARO_LINKED = g(ARO, r"reviews linked to at least one label: (\d+)")
ARO_RATE = g(ARO, r"reviews linked to at least one label: \d+ \(([\d.]+)%\)")
ARO_PER = g(ARO, r"mean labels per linked review ([\d.]+)")
RLS_LINKS = g(RLS, r"links: (\d+) over")
RLS_WAIT = g(RLS, r"matching the waiting pattern: (\d+)")
NEG_N = g(ARO, r"1-2 star reviews: (\d+);")
NEG_W = g(ARO, r"mentioning waiting: (\d+)")
FIVE_K = g(SUP, r"five-star (\d+)/(\d+)", 1)
FIVE_N = g(SUP, r"five-star (\d+)/(\d+)", 2)
SUPS = "shipped supplement_r10_output.txt (needs the licensed review export, not released)"
AROS = "shipped analyze_reviews_output.txt (needs the licensed review export, not released)"
WITHHELD_REV = "licensed review export (Telecom_reviews_and_responses.xlsx, Telecom_classification.xlsx) not in the bundle"
WITHHELD_RAW = "raw Brand Radar exports not in the bundle"
SENS = "shipped cross_sector_sensitivity_output.txt (needs the raw exports)"
SENS2 = "shipped cross_sector_sensitivity2_output.txt (needs the raw exports)"
RERUN_A = "rerun:data/analyze.py (identical to an independent recomputation from the two prefix CSVs)"
RERUN_I = "rerun:instrument_extra.py (byte-identical to shipped output)"
RERUN_M2 = "rerun:m2_from_counts.py (byte-identical) + independent full-precision recomputation (m2_precise.json)"
RERUN_R2 = "rerun:r2_link_check.py (byte-identical) + recomputation from the judgment CSVs"
RERUN_S7 = "rerun:section7_from_aggregates.py (byte-identical) + independent recomputation from aggregates/"
RERUN_ST = "rerun:vendor_reliance.py --offline and stakes_screen_check.py (byte-identical) + recomputation"
T2S = "arith:Table 2 values (released series CSV, transcribed from the manuscript)"
SRF = "data:single_reads_2026-10.csv"
CODEF = "data:section_code_pages_2026-10-14.csv"
T5S = "data:instrument_series_table5_checkpoints.csv (transcribed from the manuscript)"

# ---- Section 6 link check and stakes screen, recomputed from the released judgments
def judg(name, key):
    return {r["sample_id"]: r[key].strip().lower() for r in csv.DictReader((PRI / "review_demand" / name).open())}


def judg_rows(name):
    return {r["sample_id"]: r for r in csv.DictReader((PRI / "review_demand" / name).open())}


def kappa(a, b):
    ids = sorted(set(a) & set(b))
    n = len(ids)
    po = sum(a[i] == b[i] for i in ids) / n
    from collections import Counter
    ca, cb = Counter(a[i] for i in ids), Counter(b[i] for i in ids)
    pe = sum(ca[c] * cb[c] for c in set(ca) | set(cb)) / (n * n)
    return (po - pe) / (1 - pe), po, n


A1, A2 = judg("r2_judgments_A.csv", "judgment"), judg("r2_judgments_A_annotator2.csv", "judgment")
B1, B2 = judg("r2_judgments_B.csv", "waiting_complaint"), judg("r2_judgments_B_annotator2.csv", "waiting_complaint")
B1R, B2R = judg_rows("r2_judgments_B.csv"), judg_rows("r2_judgments_B_annotator2.csv")
WORDS = {r["sample_id"]: int(r["label_word_count"]) for r in csv.DictReader((PRI / "review_demand/r2_sample_A_label_words.csv").open())}


def prec(j, pos, neg, strict=False):
    k = sum(v == pos for v in j.values())
    n = len(j) if strict else sum(v in (pos, neg) for v in j.values())
    return k, n


pa1, pa1s, pa2 = prec(A1, "correct", "incorrect"), prec(A1, "correct", "incorrect", True), prec(A2, "correct", "incorrect")
kA = kappa(A1, A2)
pb1, pb1s, pb2 = prec(B1, "yes", "no"), prec(B1, "yes", "no", True), prec(B2, "yes", "no")
kB = kappa(B1, B2)
inst1 = sum(B1R[i]["where"].strip().lower() == "in_store" for i in B1R if B1[i] == "yes") / sum(v == "yes" for v in B1.values())
inst2 = sum(B2R[i]["where"].strip().lower() == "in_store" for i in B2R if B2[i] == "yes") / sum(v == "yes" for v in B2.values())


def by_len(j, single):
    sel = [s for s in j if (WORDS[s] == 1) == single and j[s] in ("correct", "incorrect")]
    return sum(j[s] == "correct" for s in sel) / len(sel)


SW1, SW2, MW1, MW2 = by_len(A1, True), by_len(A2, True), by_len(A1, False), by_len(A2, False)
WAIT_SHARE = round(NEG_W / NEG_N, 3)
IMPL1, IMPL2 = WAIT_SHARE * pb1[0] / pb1[1], WAIT_SHARE * pb2[0] / pb2[1]
J1 = {r["sample_id"]: r for r in csv.DictReader((PRI / "stakes/stakes_screen_judgments_1.csv").open())}
J2 = {r["sample_id"]: r for r in csv.DictReader((PRI / "stakes/stakes_screen_judgments_2.csv").open())}
IDS = sorted(set(J1) & set(J2))
U1 = {i: J1[i]["uses_vendor_data"].strip().lower() for i in IDS}
U2 = {i: J2[i]["uses_vendor_data"].strip().lower() for i in IDS}


def screen(J, U):
    yes = [i for i in IDS if U[i] == "yes"]
    one = sum(1 for i in yes if len([t for t in J[i]["tools_used"].split(";") if t.strip()]) == 1)
    comp = sum(1 for i in yes if J[i]["compares_tools"].strip().lower() == "yes")
    return len(yes), one, comp


SC1, SC2 = screen(J1, U1), screen(J2, U2)
KS = kappa(U1, U2)
WORKS = list(csv.DictReader((PRI / "stakes/vendor_reliance_works.csv").open()))
seen, UNIQ = set(), []
for r in WORKS:
    if r["id"] not in seen:
        seen.add(r["id"])
        UNIQ.append(r)
MATCHED = [r for r in UNIQ if int(r["n_tools"]) >= 1]
BY_YEAR = {}
for r in MATCHED:
    BY_YEAR[r["year"]] = BY_YEAR.get(r["year"], 0) + 1
# the screen's random sample, replayed offline: stakes_screen_sample.py draws random.Random(20261015).sample(rows, 120)
import random as _random
_sample = _random.Random(20261015).sample(MATCHED, 120)
IDFILE = list(csv.DictReader((PRI / "stakes/stakes_screen_ids.csv").open()))
SAMPLE_OK = [r["id"] for r in _sample] == [r["openalex_id"] for r in IDFILE]

# ================================================================================================ Abstract
sec("Abstract")
M(14, "381", len(CODES), CODEF + " (rows)")
M(14, "53", len(LOCS) + 1, "arith:52 registry locations in the released code list (one state hub each) + the national hub", "the hub list itself is not released")
M(14, "7.5x", min(R_US_AW.values()), T2S + "; Semrush US / Ahrefs worldwide, lowest month")
M(14, "27.1x", max(R_US_AW.values()), T2S + "; highest month")
M(14, "8.6x", min(R_WW.values()), T2S + "; worldwide / worldwide")
M(14, "29.9x", max(R_WW.values()), T2S)
M(14, "0.20x", min(vr.values()), RERUN_A)
M(14, "7.24x", max(vr.values()), RERUN_A)
M(14, "−0.11", rho_age, RERUN_A)
M(14, "60", conc, RERUN_A)
M(14, "66", conc + disc, RERUN_A)
M(14, "9", sum(bands["within"]), RERUN_I + "; pairs within a factor of three ordered alike")
M(14, "15", len(bands["within"]), RERUN_I)
CR(14, "37,193", WITHHELD_REV, (SUP_TEXT, SUPS))
CR(14, "378", WITHHELD_REV, (SUP_LOCTXT, SUPS))
CR(14, "42,994", WITHHELD_REV, (SUP_NODES, SUPS))
M(14, "+0.47", M2P["rho_branch_modal"], RERUN_M2)
M(14, "+0.75", M2P["rho_branch_split"], RERUN_M2)
M(14, "+0.18", M2P["rho_mentioned"], RERUN_M2, "full precision 0.18487")
B(14, "about two-thirds correct", 0.6 <= pa2[0] / pa2[1] <= 0.7 and 0.6 <= pa1[0] / pa1[1] <= 0.7,
  f"{pa1[0]}/{pa1[1]}, {pa2[0]}/{pa2[1]}", RERUN_R2)
M(14, "21%", 100 * med(G_ALL), RERUN_S7)
M(14, "0.6%", 100 * SURF_MED["copilot"], RERUN_S7 + "; lowest of the four non-Google surface medians")
M(14, "9.2%", 100 * SURF_MED["gemini"], RERUN_S7 + "; highest of the four")
B(14, "twelve sections", len(P) == 12, len(P), "data:two prefix CSVs")
B(14, "one held, one held in direction only and two failed",
  P1_BOTH < 6 and all(v >= 6 for v in P2.values()) and len(P3) < 6 and min(P4[p][2] for p in P4) > 0.05
  and all(P4[p][0] > P4[p][1] for p in P4), "P1 fails, P2 holds, P3 fails, P4 direction only", RERUN_S7)
B(14, "lowest Google figure above the highest of the other four in every sector", EVERY == 11, f"{EVERY}/11", RERUN_S7)
B(14, "ten largest holdings of each sector fund", all(sum(c["etf"] == e for c in COMP) == 10 for e in {c["etf"] for c in COMP} if e != "XLC")
  and sum(c["etf"] == "XLC" for c in COMP) == 9, "10 per fund, 9 companies in XLC", "data:design/cross_sector_companies.csv")

# ================================================================================================ Section 1
sec("1 Introduction")
M(22, "456", len(MATCHED), RERUN_ST)
M(22, "27", BY_YEAR.get("2020", 0), RERUN_ST + "; works of 2020")
M(22, "87", BY_YEAR.get("2025", 0), RERUN_ST + "; works of 2025")
M(22, "110", BY_YEAR.get("2026", 0), RERUN_ST + "; works of 2026")
M(22, "120", len(IDS), RERUN_ST + "; works judged by both annotators")
B(22, "a random sample of 120 of them (seed 20261015)", SAMPLE_OK, "offline replay of the draw = released stakes_screen_ids.csv",
  "check:random.Random(20261015).sample of the 456 deduplicated works vs stakes/stakes_screen_ids.csv",
  "stakes_screen_sample.py itself needs the live OpenAlex API")
M(22, "82%", 100 * SC1[0] / len(IDS), RERUN_ST, "99/120 = 82.5% exactly; 82% is the round-half-to-even reading (the script prints 82%)")
M(22, "87%", 100 * SC2[0] / len(IDS), RERUN_ST)
M(22, "75%", 100 * wilson(SC1[0], len(IDS))[0], RERUN_ST + "; lower Wilson end, annotator 1")
M(22, "92%", 100 * wilson(SC2[0], len(IDS))[1], RERUN_ST + "; upper Wilson end, annotator 2")
M(22, "0.63", KS[0], RERUN_ST)
M(22, "87%", 100 * SC1[1] / SC1[0], RERUN_ST + "; one vendor only, annotator 1 (86/99)")
M(22, "88%", 100 * SC2[1] / SC2[0], RERUN_ST + "; one vendor only, annotator 2 (91/104 = 87.5%)")
B(22, "five to seven compare vendors", sorted([SC1[2], SC2[2]]) == [5, 7], f"{SC1[2]} and {SC2[2]}", RERUN_ST)
B(22, "an independent search of five databases", all(x in sh("literature/novelty_search_scout_2026-10-15/README.md")
                                                       for x in ("OpenAlex", "Crossref", "arXiv API", "Semantic Scholar", "Google Scholar")),
  "OpenAlex, Crossref, arXiv, Semantic Scholar, Google Scholar (DBLP was down)", "data:literature/novelty_search_scout_2026-10-15/README.md")
M(32, "381", len(CODES), CODEF)
B(32, "77", (date(2026, 10, 11) - D0).days == 77, (date(2026, 10, 11) - D0).days, "arith:26 July to 11 October 2026")
B(32, "seven checkpoints", len([d for d in T5DAYS if d != 37]) == 7, "Table 5 columns other than day 37 (or the fifteen-day checkpoints plus day 77)",
  T5S, "Table 5 has eight dated columns; seven of them carry the other quantities in full or nearly; reading accepted")
B(34, "thirteen demand-surface types", len(re.findall(r'\("([^"]+)", (?:False|True|"run")\)', sh("make_fig0.py"))) == 13,
  len(re.findall(r'\("([^"]+)", (?:False|True|"run")\)', sh("make_fig0.py"))), "data:make_fig0.py surface lists (10 first-party + 3 tool-derived)")
M(38, "30", max(R_WW.values()), T2S, approx=0.05)
M(38, "33", max(R_USUS.values()), T2S + "; US to US, estimated", approx=0.05)
for tok, v in (("7.5x", min(R_US_AW.values())), ("27.1x", max(R_US_AW.values())), ("8.6x", min(R_WW.values())), ("29.9x", max(R_WW.values()))):
    M(42, tok, v, T2S)
M(42, "0.20x", min(vr.values()), RERUN_A)
M(42, "7.24x", max(vr.values()), RERUN_A)
M(42, "60", conc, RERUN_A)
M(42, "66", conc + disc, RERUN_A)
CR(43, "37,193", WITHHELD_REV, (SUP_TEXT, SUPS))
CR(43, "42,994", WITHHELD_REV, (SUP_NODES, SUPS))
M(44, "21.3%", 100 * med(G_ALL), RERUN_S7)
M(44, "2.1%", 100 * med(C_ALL), RERUN_S7)
B(44, "about ten times", 9 <= med(G_ALL) / med(C_ALL) <= 11, med(G_ALL) / med(C_ALL), RERUN_S7)
B(44, "in every sector", EVERY == 11, f"{EVERY}/11", RERUN_S7)
M(46, "77", (date(2026, 10, 11) - D0).days, "arith:day 0 = 26 July 2026 to 11 October 2026")
hubs = [int(sr(f"stored AI answers citing the page: {h}")) for h in ("New York state hub", "California state hub", "Texas state hub", "Florida state hub", "national hub")]
top_code = int(sr("stored AI answers citing the page: 214 (Dallas) code page"))
M(46, "1.2", min(hubs) / top_code, SRF + "; least-cited of the five hubs / most-cited code page (294/238)")
M(46, "2.0", max(hubs) / top_code, SRF + "; 474/238")
B(46, "five most-cited hub pages", len(hubs) == 5 and min(hubs) > top_code, f"{min(hubs)} > {top_code}", SRF)
B(46, "six enabling conditions", len(re.findall(r"^\d\. \*\*", "\n".join(MS[104:110]), re.M)) == 6, 6, "manuscript Section 3.1 list")
B(46, "six lessons", len(re.findall(r"^\d\. \*\*", "\n".join(MS[436:442]), re.M)) == 6, 6, "manuscript Section 11.2 list")
M(54, "90", num(sr("Domain Rating of the domain")), SRF)
M(54, "86", num(sr("Authority Score of the domain")), SRF)

# ================================================================================================ Section 2 (citations of other works)
sec("2 Related work")
for tok, note in (("25", "Langridge 2016; reference entry says 25 sites"), ("17%", "Langridge 2016"), ("30%", "Langridge 2016"),
                  ("1,635", "Soulo 2022; reference entry says 1,635 sites"), ("49.5%", "Soulo 2022"), ("68.4%", "Soulo 2022"),
                  ("0.76", "Soulo 2022"), ("0.74", "Soulo 2022"), ("18", "Kamerer 2013"), ("86", "Jansen, Jung & Salminen 2022; reference title says 86 websites"),
                  ("50", "Rasool, Thakur & Nabi 2026"), ("4%", "Rasool, Thakur & Nabi 2026"), ("0.997", "Rasool, Thakur & Nabi 2026"),
                  ("7%", "Zhao & Berman 2025")):
    EXT(77, tok, note)
for tok, note in (("55,393", "Xu, Iqbal & Montgomery 2026"), ("30%", "Xu et al. 2026"), ("15,000", "Linehan & Guan 2025; reference entry says 15,000 prompts"),
                  ("12%", "Linehan & Guan 2025; reference title says 12%"), ("28.6%", "Linehan & Guan 2025"), ("1%", "Chapekis & Lieb 2025"),
                  ("45", "Martinez 2026"), ("366,000", "Yang 2025"), ("11,000", "Huang et al. 2026"), ("712", "Allaham & Diakopoulos 2026"),
                  ("16%", "Allaham & Diakopoulos 2026"), ("480", "Hendricks 2026"), ("6,095,520", "OtterlyAI 2026; reference entry says 6,095,520"),
                  ("17", "OtterlyAI 2026"), ("31%", "Tinuiti 2026"), ("7%", "Tinuiti 2026"), ("19.4%", "Punturo et al. 2026"), ("5.3%", "Punturo et al. 2026"),
                  ("15", "Punturo et al. 2026"), ("86%", "Yext 2025; reference title says 86%"), ("100,000", "Kumar 2026; literature README agrees"),
                  ("100", "Kumar 2026"), ("78%", "Kumar 2026; literature/novelty_search_2026-10-14/README.md says about 78%"),
                  ("23", "Romero Ramos et al. 2026; literature README says 23 studies")):
    EXT(81, tok, note)
EXT(83, "11.7%", "Hannak et al. 2013")
M(85, "381", len(CODES), CODEF)
M(85, "29,000", num(sr("distinct keywords on which a URL under the prefix ranks 1 to 100 (all locations)")), SRF)

# ================================================================================================ Section 3
sec("3 Setting")
B(95, "52", len(LOCS) == 52, len(LOCS), CODEF + "; the section's 52 state hubs = 52 registry locations")
M(95, "381", len(CODES), CODEF)
M(95, "374", sum(r["registry_use"] == "G" for r in CODES), CODEF + "; geographic codes")
M(95, "372", sum(r["group"] == "geographic, in service" for r in CODES), CODEF)
B(95, "two assigned but not yet in service", sum(r["group"] == "geographic, assigned, not in service" for r in CODES) == 2,
  [r["code"] for r in CODES if r["in_service"] == "N"], CODEF)
M(95, "7", sum(r["group"] == "toll-free" for r in CODES), CODEF + "; toll-free")
M(95, "52", len(LOCS), CODEF + "; distinct registry locations")
STATES = {"AK", "AL", "AR", "AZ", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "IA", "ID", "IL", "IN", "KS", "KY", "LA", "MA", "MD", "ME", "MI",
          "MN", "MO", "MS", "MT", "NC", "ND", "NE", "NH", "NJ", "NM", "NV", "NY", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT",
          "VA", "VT", "WA", "WI", "WV", "WY"}
M(95, "50", len(STATES & set(LOCS)), CODEF + "; states among the locations (with DC and 'NANP AREA' for toll-free)")
M(95, "381", len(CODES), CODEF + "; the 14 October re-fetch")
CR(95, "381", "fetch results (HTTP status, canonical tags) not released", None, "All 381 return HTTP 200 ...")
CR(95, "200", "fetch results not released")
CR(95, "six assigned to US territories", "the numbering-plan registry extract is not released (it is in the Study R1 manifest only)")
B(95, "451", "451" not in CODE, "451 absent from the released code list", CODEF, "its assignment date (15 September 2026) needs the unreleased registry")
M(97, "210", t5("Pages holding a position", 15), T5S, circ=True)
M(97, "365", t5("Pages holding a position", 30), T5S, circ=True)
M(97, "391", t5("Pages holding a position", 45), T5S, circ=True)
M(97, "414", t5("Pages holding a position", 60), T5S, circ=True)
M(97, "440", t5("Pages holding a position", 75), T5S, circ=True)
M(97, "434", len(CODES) + len(LOCS) + 1, "arith:381 code pages + 53 hubs")
M(99, "381", len(CODES), CODEF)
M(99, "441", t5("Pages holding a position", 77), T5S, circ=True)
M(99, "381", len(CODES), CODEF)
M(99, "53", len(LOCS) + 1, "arith:52 locations + national hub")
B(99, "exceeds 381 plus the 53 hub pages by seven", t5("Pages holding a position", 77) - 434 == 7, t5("Pages holding a position", 77) - 434, "arith:441 - 434")
M(99, "455", num(sr("distinct pages under the prefix cited in stored AI answers")), SRF)
M(99, "434", len(CODES) + len(LOCS) + 1, "arith")
M(99, "21", num(sr("distinct pages under the prefix cited in stored AI answers")) - 434, "arith:455 - 434")
B(99, "day 0 = 26 July 2026", day(0) == date(2026, 7, 26), day(0), "definition; consistent with Table 5 header")
M(108, "90", num(sr("Domain Rating of the domain")), SRF)
M(108, "86", num(sr("Authority Score of the domain")), SRF)
B(109, "87", sr("Domain Ratings of the two national carriers co-cited with the section") == "87 and 91", sr("Domain Ratings of the two national carriers co-cited with the section"), SRF)
B(109, "91", sr("Domain Ratings of the two national carriers co-cited with the section") == "87 and 91", "87 and 91", SRF)
B(110, "13", sr(next(k for k in SR if k.startswith("Domain Rating of the five domains"))) == "13 to 83", "13 to 83", SRF)
B(110, "83", sr(next(k for k in SR if k.startswith("Domain Rating of the five domains"))) == "13 to 83", "13 to 83", SRF)

# ================================================================================================ Section 4
sec("4 Measurement design")
B(125, "11", sr_date("distinct keywords on which a URL under the prefix ranks 1 to 100 (all locations)") == "2026-10-11", "2026-10-11", SRF + " (read date)")
B(125, "10", sr_date("distinct keywords on which a URL under the prefix ranks 1 to 100 (US database)") == "2026-10-10", "2026-10-10", SRF + " (read date)")
B(125, "12", sr_date("distinct keywords on which a URL under the prefix ranks 1 to 100 (worldwide)") == "2026-10-12", "2026-10-12", SRF + " (read date)")
B(131, "10", sr_date("mentions in the AI-visibility panel") == "2026-10-10", "2026-10-10", SRF + " (read date)")
B(131, "12", sr_date("mentions in the AI-visibility panel (identical for all twelve subfolders)") == "2026-10-12", "2026-10-12", SRF + " (read date)")
B(132, "11", sr_date("live referring domains to the prefix") == "2026-10-11" and sr_date("referring domains to the subfolder") == "2026-10-11", "2026-10-11", SRF + " (read date)")
B(133, "2015", min(A[p]["ahrefs_first_traffic_month"] for p in P) == "2015-09", min(A[p]["ahrefs_first_traffic_month"] for p in P), "data:ahrefs_prefixes CSV, earliest first-traffic month")
B(133, "12", all(A[p]["read_date"] == "2026-10-12" for p in P), "2026-10-12", "data:ahrefs_prefixes CSV read_date")
B(134, "12", all(A[p]["read_date"] == "2026-10-12" for p in P), "2026-10-12", "data:ahrefs_prefixes CSV read_date")
B(137, "1,000", all(int(CELLS[(s, p)]["export_rows"]) == 1000 for s in SECTORS for p in SURF), "export_rows = 1000 in all 88 cells", "data:aggregates/cross_sector_cells.csv")
B(137, "12", "12 October" in DESIGN and all(COUNTS[s]["read_at_local"].startswith("2026-10-13") for s in SECTORS), "answer counts read 2026-10-13 01:10-01:15", "data:design file and sector_answer_counts.csv")
B(137, "13", all(COUNTS[s]["read_at_local"].startswith("2026-10-13") for s in SECTORS), "2026-10-13", "data:sector_answer_counts.csv")
M(145, "105", num(sr("countries in which the section ranks")), SRF)
M(145, "18.5%", num(sr("share of Ahrefs-estimated visits from outside the US").rstrip("%")), SRF)
M(145, "18.6%", 100 * (1 - us[AC]), "data:ahrefs_prefixes CSV, 1 - US share of /local/area-codes/ (0.814)")
M(145, "7.5", min(R_US_AW.values()), T2S)
M(145, "27.1", max(R_US_AW.values()), T2S)
M(145, "8.6x", min(R_WW.values()), T2S)
M(145, "29.9x", max(R_WW.values()), T2S)
M(145, "9.2x", min(R_USUS.values()), T2S + " with the 81.5% US share")
M(145, "33.3x", max(R_USUS.values()), T2S + " with the 81.5% US share")
M(145, "81.5%", 100 * US_SHARE_T2, SRF, "also 100% - 18.5%")
B(155, "24 September, day 60", day(60) == date(2026, 9, 24), day(60), "arith:26 July + 60 days")
B(155, "29 September, day 65", day(65) == date(2026, 9, 29), day(65), "arith:26 July + 65 days")
B(155, "days 65 to 75", day(75) == date(2026, 10, 9), day(75), "arith:notice period ends at the last daily read (9 October)")
LAB(155, "three disturbances", "count of the list that follows in the same paragraph")
B(157, "Day 37 (1 September 2026)", day(37) == date(2026, 9, 1), day(37), "arith:26 July + 37 days")
B(157, "four of the nine quantities", sum(t5(m, 37) is not None for m in T5R) == 4 and len(T5R) == 9,
  f"{sum(t5(m, 37) is not None for m in T5R)} of {len(T5R)}", T5S, circ=True)

# ================================================================================================ Section 5
sec("5.1 Table 2 and text")
M(163, "7.5x", min(R_US_AW.values()), T2S)
M(163, "27.1x", max(R_US_AW.values()), T2S)
M(165, "81.5%", 100 * US_SHARE_T2, SRF)
B(165, "11", sr_date("Ahrefs' US share of its own visits used for the US-to-US ratios") == "2026-10-11", "2026-10-11", SRF + " (read on 11 October)")
B(169, "0", T2[1][1] == "0", T2[1][1], "June days live, data:instrument_series_table2 CSV (transcribed)", circ=True)
B(169, "0", T2[1][2] == "0", T2[1][2], "June Ahrefs visits, data:instrument_series_table2 CSV (transcribed)", circ=True)
B(169, "0", T2[1][3].split(" (")[0] == "0", T2[1][3], "June Semrush US visits, data:instrument_series_table2 CSV (transcribed)", circ=True)
B(169, "0", T2[1][3] == "0 (0)", T2[1][3], "June Semrush worldwide visits, data:instrument_series_table2 CSV (transcribed)", circ=True)
DAYS_LIVE = {"July": (date(2026, 7, 31) - D0).days + 1, "August": 31, "September": 30, "October": 11}
for ln, m, toks in ((170, "July", ("6", "3,862", "100,012", "103,045", "25.9x", "26.7x", "31.8x")),
                    (171, "August", ("31", "32,281", "876,153", "963,937", "27.1x", "29.9x", "33.3x")),
                    (172, "September", ("30", "150,113", "1,534,362", "1,765,077", "10.2x", "11.8x", "12.5x")),
                    (173, "October", ("11", "215,577", "1,610,284", "1,858,297", "7.5x", "8.6x", "9.2x"))):
    a_, u_, w_ = T2V[m]
    M(ln, toks[0], DAYS_LIVE[m], "arith:calendar days live in the month (launch 26 July; October read on day 77, 11 October)")
    M(ln, toks[1], a_, "data:instrument_series_table2 CSV and instrument_extra.py constants (both transcribed)", circ=True)
    M(ln, toks[2], u_, "data:instrument_series_table2 CSV and instrument_extra.py constants (both transcribed)", circ=True)
    M(ln, toks[3], w_, "data:instrument_series_table2 CSV and instrument_extra.py constants (both transcribed)", circ=True)
    M(ln, toks[4], R_US_AW[m], "arith:Semrush US / Ahrefs worldwide")
    M(ln, toks[5], R_WW[m], "arith:Semrush worldwide / Ahrefs worldwide")
    M(ln, toks[6], R_USUS[m], "arith:Semrush US / (Ahrefs worldwide x 81.5%)")
M(173, "78", sum(DAYS_LIVE.values()), "arith:6 + 31 + 30 + 11")
B(173, "days 0 to 77", (date(2026, 10, 11) - D0).days == 77, 77, "arith")
M(179, "8.4x", T2V["August"][0] / T2V["July"][0], T2S + "; Ahrefs growth July to August")
M(179, "8.8x", T2V["August"][1] / T2V["July"][1], T2S + "; Semrush US growth")
M(179, "4.65x", T2V["September"][0] / T2V["August"][0], T2S + " = " + RERUN_I)
M(179, "1.75x", T2V["September"][1] / T2V["August"][1], T2S + " = " + RERUN_I)
M(179, "1.44x", T2V["October"][0] / T2V["September"][0], T2S + " = " + RERUN_I)
M(179, "1.05x", T2V["October"][1] / T2V["September"][1], T2S + " = " + RERUN_I)
B(179, "by a factor of more than two", (T2V["September"][0] / T2V["August"][0]) / (T2V["September"][1] / T2V["August"][1]) > 2,
  (T2V["September"][0] / T2V["August"][0]) / (T2V["September"][1] / T2V["August"][1]), T2S)
M(181, "18.5%", num(sr("share of Ahrefs-estimated visits from outside the US").rstrip("%")), SRF)
for tok, v in (("8.6x", min(R_WW.values())), ("29.9x", max(R_WW.values())), ("9.2x", min(R_USUS.values())), ("33.3x", max(R_USUS.values()))):
    M(181, tok, v, T2S)
M(183, "27.1x", R_US_AW["August"], T2S)
M(183, "10.2x", R_US_AW["September"], T2S)
M(183, "7.5x", R_US_AW["October"], T2S)

sec("5.2 Ranking keywords")
KW_A = num(sr("distinct keywords on which a URL under the prefix ranks 1 to 100 (all locations)"))
KW_S = num(sr("distinct keywords on which a URL under the prefix ranks 1 to 100 (US database)"))
KW_W = num(sr("distinct keywords on which a URL under the prefix ranks 1 to 100 (worldwide)").rstrip("K")) * 1000
M(187, "29,000", KW_A, SRF)
M(187, "58,586", KW_S, SRF)
M(187, "2.0", KW_S / KW_A, "arith:58,586 / 29,000")
B(187, "12", sr_date("distinct keywords on which a URL under the prefix ranks 1 to 100 (worldwide)") == "2026-10-12", "2026-10-12", SRF + " (read date)")
M(187, "92.3K", KW_W / 1000, SRF)
M(187, "3.2", KW_W / ak[AC], "arith:92,300 / 28,900")
M(187, "28,900", ak[AC], "data:ahrefs_prefixes CSV (/local/area-codes/)")
M(187, "441", t5("Pages holding a position", 77), T5S, circ=True)

sec("5.3 AI answers and AI Overviews")
AI_ANS = t5("AI answers citing the section", 77)
MENT10 = num(sr("mentions in the AI-visibility panel"))
CITED10 = num(sr("cited pages in the AI-visibility panel"))
M(191, "17,206", AI_ANS, T5S + "; single_reads note also gives 17,206 on 11 October", circ=True)
M(191, "158,100", MENT10, SRF)
B(191, "10", sr_date("mentions in the AI-visibility panel") == "2026-10-10", "2026-10-10", SRF + " (read date)")
M(191, "9.2", MENT10 / AI_ANS, "arith:158,100 / 17,206")
M(191, "29,600", CITED10, SRF)
M(191, "68", CITED10 / 434, "arith:29,600 / 434")
M(191, "434", len(CODES) + len(LOCS) + 1, "arith:381 + 53")
M(193, "17,206", AI_ANS, T5S, circ=True)
for ln, m, toks in ((201, "July", ("47", "284", "16.5%", "12.7", "21.3", "138", "2.94x")),
                    (202, "August", ("851", "6,749", "12.6%", "11.8", "13.4", "2,221", "2.61x")),
                    (203, "September", ("3,380", "22,665", "14.9%", "14.5", "15.4", "8,187", "2.42x")),
                    (204, "October", ("7,455", "37,238", "20.0%", "19.6", "20.4", "10,018", "1.34x"))):
    k, n, b = T3V[m]
    lo, hi = wilson(k, n)
    M(ln, toks[0], k, "data:instrument_series_table3 CSV and make_figs_v4.py constants (transcribed)", circ=True)
    M(ln, toks[1], n, "data:instrument_series_table3 CSV and make_figs_v4.py constants (transcribed)", circ=True)
    M(ln, toks[2], 100 * k / n, "arith:numerator / denominator")
    M(ln, toks[3], 100 * lo, "arith:Wilson 95% lower")
    M(ln, toks[4], 100 * hi, "arith:Wilson 95% upper")
    M(ln, toks[5], b, "data:instrument_series_table3 CSV and make_figs_v4.py constants (transcribed)", circ=True)
    M(ln, toks[6], b / k, "arith:(b) / (a) numerator")
M(206, "284", T3V["July"][1], "data:Table 3 series CSV", circ=True)
M(206, "37,238", T3V["October"][1], "data:Table 3 series CSV", circ=True)
M(208, "2.94", T3V["July"][2] / T3V["July"][0], "arith:Table 3")
M(208, "1.34", T3V["October"][2] / T3V["October"][0], "arith:Table 3")
B(208, "three intervals", len(T3V) - 1 == 3, 3, "arith:four months")
M(208, "47", T3V["July"][0], "data:Table 3 series CSV", circ=True)
B(208, "six days live", DAYS_LIVE["July"] == 6, 6, "arith")
M(210, "284", T3V["July"][1], "data:Table 3 series CSV", circ=True)
M(210, "37,238", T3V["October"][1], "data:Table 3 series CSV", circ=True)
B(210, "grows by two orders of magnitude", 2 <= math.log10(T3V["October"][1] / T3V["July"][1]) < 3, math.log10(T3V["October"][1] / T3V["July"][1]), "arith:log10(37,238 / 284)")
B(210, "it is not monotone", not (sorted([T3V[m][0] / T3V[m][1] for m in MONTHS]) == [T3V[m][0] / T3V[m][1] for m in MONTHS]),
  [round(100 * T3V[m][0] / T3V[m][1], 1) for m in MONTHS], "arith")

sec("5.4 Referring domains")
RD_A, RD_S = num(sr("live referring domains to the prefix")), num(sr("referring domains to the subfolder"))
M(212, "11.4x", RD_A / RD_S, "arith:913 / 80")
M(216, "913", RD_A, SRF)
M(216, "80", RD_S, SRF)
M(216, "11.4", RD_A / RD_S, "arith:913 / 80")
M(216, "61.9%", num(sr("share of those referring domains on .info").rstrip("%")), SRF)
M(216, "26.4%", num(sr("share of those referring domains on .asia").rstrip("%")), SRF)
M(216, "10.2%", num(sr("share of those referring domains on .xyz", "Ahrefs").rstrip("%")), SRF)
M(216, "75%", num(sr("share of those referring domains on .xyz", "Semrush").rstrip("%")), SRF)
M(216, "88%", num(sr("share of those referring domains at Authority Score 0 to 10").rstrip("%")), SRF)
B(216, "0", any(r["quantity"].endswith("Authority Score 0 to 10") for r in SRL), "0 to 10", SRF)
B(216, "10", any(r["quantity"].endswith("Authority Score 0 to 10") for r in SRL), "0 to 10", SRF)
B(218, "11", sr_date("live referring domains to the prefix") == "2026-10-11", "2026-10-11", SRF + " (read date)")
M(218, "913", RD_A, SRF)
M(218, "80", RD_S, SRF)
M(218, "75%", num(sr("share of those referring domains on .xyz", "Semrush").rstrip("%")), SRF + " and make_figs_v4.py (Semrush .xyz 75.0)")
M(220, "909", t5("Live referring domains", 75), T5S, circ=True)
M(220, "913", RD_A, SRF)
B(220, "11", sr_date("live referring domains to the prefix") == "2026-10-11", "2026-10-11", SRF)
M(220, "917", num(sr("new referring domains in September (new-and-lost report)")), SRF)
M(220, "95", num(sr("lost referring domains in September (new-and-lost report)")), SRF)
B(220, "nineteen", t5("Live referring domains", 37) == 19, 19, T5S, circ=True)
M(220, "841", t5("Live referring domains", 37) + num(sr("new referring domains in September (new-and-lost report)")) - num(sr("lost referring domains in September (new-and-lost report)")),
  "arith:19 + 917 - 95")

sec("5.5 Twelve prefixes")
B(224, "12", all(A[p]["read_date"] == "2026-10-12" == S[p]["read_date"] for p in P), "2026-10-12", "data:both prefix CSVs (read_date)")
B(224, "twelve sections ... the area-code section and eleven others", len(P) == 12, len(P), "data:prefix CSVs")
B(224, "ages from under two years to the instrument's horizon", sorted(age.values())[1] < 24 and max(age.values()) == 133,
  f"second youngest {sorted(age.values())[1]} months; oldest 2015-09", "data:ahrefs_prefixes CSV")
B(226, "12", all(A[p]["read_date"] == "2026-10-12" == S[p]["read_date"] for p in P), "2026-10-12", "data:prefix CSVs (read_date)")
B(226, "2015", A["/es-us/local/"]["ahrefs_first_traffic_month"] == "2015-09", "2015-09", "data:ahrefs_prefixes CSV")
B(226, "the next two lie within four months of it", sorted(age.values())[-3] >= 133 - 4 and sorted(age.values())[-2] >= 133 - 4,
  sorted(age.values())[-3:], "data:ahrefs_prefixes CSV (129, 132, 133 months)")
M(226, "29,000", KW_A, SRF)
M(226, "58,586", KW_S, SRF)
M(226, "80", RD_S, SRF)
M(226, "11.4x", RD_A / RD_S, "arith")
# Table 4 rows, cell by cell against the CSVs
for ln in range(230, 242):
    cells = [c.strip().replace("**", "") for c in MS[ln - 1].strip().strip("|").split("|")]
    p = cells[0]
    vals = [age[p], at[p], st[p], vr[p], 100 * us[p], vm[p], ak[p], sk[p], kr[p], ard[p], srd[p], rr[p]]
    bases = ["data:ahrefs CSV first_traffic_month -> months to Oct 2026", "data:ahrefs CSV", "data:semrush CSV", "arith:Semrush / Ahrefs (= instrument_extra.py s.8)",
             "data:ahrefs CSV ahrefs_us_share", "arith:Semrush / (Ahrefs x US share) (= instrument_extra.py s.8)", "data:ahrefs CSV", "data:semrush CSV",
             "arith:Semrush kw / Ahrefs kw", "data:ahrefs CSV", "data:semrush CSV", "arith:Ahrefs RD / Semrush RD"]
    for tok, v, b in zip(cells[1:], vals, bases):
        M(ln, tok, v, b)
B(243, "12", all(A[p]["read_date"] == "2026-10-12" for p in P), "2026-10-12", "data:prefix CSVs (read_date)")
B(245, "Six things follow", len(re.findall(r"^\*\*", "\n".join(MS[246:257]), re.M)) == 6, len(re.findall(r"^\*\*", "\n".join(MS[246:257]), re.M)), "manuscript: bold-led paragraphs of Section 5.5 before Limits")
M(247, "−0.11", rho_age, RERUN_A)
M(247, "−0.64", fisher[0], RERUN_A)
M(247, "+0.49", fisher[1], RERUN_A)
M(247, "0.73", g(ANA, r"permutation p = ([\d.]+)"), RERUN_A + f"; independent 200,000-permutation estimate {perm_p:.3f}")
M(247, "−0.28", rho_age_m, RERUN_A + "; territory-matched")
M(247, "+0.15", rho_age_x, RERUN_A + "; without /local/area-codes/")
M(247, "38%", 100 * power, RERUN_I + "; Fisher approximation")
M(247, "37.8%", 100 * power, RERUN_I)
B(247, "the seven sections aged between seven and eleven years", len(mid) == 7, len(mid), RERUN_I)
M(247, "0.25x", min(vr[p] for p in mid), RERUN_I)
M(247, "6.57x", max(vr[p] for p in mid), RERUN_I)
M(247, "0.46x", min(vm[p] for p in mid), RERUN_I)
M(247, "6.61x", max(vm[p] for p in mid), RERUN_I)
M(247, "27.1x", R_US_AW["August"], T2S)
M(247, "7.5x", R_US_AW["October"], T2S)
B(247, "Only one prefix ... under twenty-one months old", sum(age[p] < 21 for p in P) == 1, sum(age[p] < 21 for p in P), RERUN_I)
B(249, "one fifth of Ahrefs'", abs(min(vr.values()) - 0.2) < 0.01, min(vr.values()), RERUN_A)
B(249, "seven times it", abs(max(vr.values()) - 7) < 0.5, max(vr.values()), RERUN_A)
M(249, "0.20x", min(vr.values()), RERUN_A)
M(249, "7.24x", max(vr.values()), RERUN_A)
M(249, "1.55", math.log10(max(vr.values()) / min(vr.values())), RERUN_A + "; orders of magnitude")
M(249, "1.01", med_vr, RERUN_A)
B(249, "six of twelve prefixes below one", sum(v < 1 for v in vr.values()) == 6, sum(v < 1 for v in vr.values()), RERUN_A)
M(249, "0.20x", min(vm.values()), RERUN_A + "; matched")
M(249, "8.89x", max(vm.values()), RERUN_A + "; matched")
M(249, "1.06", med_vm, RERUN_A)
B(249, "four of twelve are below one", sum(v < 1 for v in vm.values()) == 4, sum(v < 1 for v in vm.values()), RERUN_A)
B(249, "two of the six sub-one prefixes cross one", sum(vr[p] < 1 <= vm[p] for p in P) == 2, [p for p in P if vr[p] < 1 <= vm[p]], RERUN_A)
M(249, "69.6%", 100 * us["/product-compare/"], "data:ahrefs CSV")
M(249, "0.75x", vr["/product-compare/"], RERUN_I)
M(249, "1.07x", vm["/product-compare/"], RERUN_I)
M(249, "82.6%", 100 * us["/device-compare/"], "data:ahrefs CSV")
M(249, "0.99x", vr["/device-compare/"], RERUN_I)
M(249, "1.20x", vm["/device-compare/"], RERUN_I)
M(249, "42.6%", 100 * us["/es-us/local/"], "data:ahrefs CSV")
M(249, "0.25x", vr["/es-us/local/"], RERUN_I)
M(249, "0.58x", vm["/es-us/local/"], RERUN_I)
M(249, "1.13", gmean, RERUN_I)
M(249, "0.62", g(IEX, r"geometric mean of the ratio [\d.]+x \[([\d.]+)x"), RERUN_I + "; bootstrap, seed 20261015")
M(249, "2.12", g(IEX, r"geometric mean of the ratio [\d.]+x \[[\d.]+x, ([\d.]+)x\]"), RERUN_I)
M(249, "3.1", gsd, RERUN_I)
M(249, "1.9", g(IEX, r"geometric SD [\d.]+ \[([\d.]+),"), RERUN_I)
M(249, "4.1", g(IEX, r"geometric SD [\d.]+ \[[\d.]+, ([\d.]+)\]"), RERUN_I)
M(249, "0.12x", grange[0], RERUN_I)
M(249, "10.6x", grange[1], RERUN_I)
M(251, "+0.94", rho_v.statistic, RERUN_A)
M(251, "+0.70", g(IEX, r"Spearman \(ordering\) \+[\d.]+ \[([+\-][\d.]+),"), RERUN_I)
M(251, "+1.00", g(IEX, r"Spearman \(ordering\) \+[\d.]+ \[[+\-][\d.]+, ([+\-][\d.]+)\]"), RERUN_I)
B(251, "0.001", rho_v.pvalue < 0.001, rho_v.pvalue, RERUN_I + " (p = 7e-06)")
M(251, "+0.82", tau_v.statistic, RERUN_A)
M(251, "+0.57", g(IEX, r"Kendall \+[\d.]+ \[([+\-][\d.]+),"), RERUN_I)
M(251, "+1.00", g(IEX, r"Kendall \+[\d.]+ \[[+\-][\d.]+, ([+\-][\d.]+)\]"), RERUN_I)
for _ in range(2):
    M(251, "60", conc, RERUN_A)
    M(251, "66", conc + disc, RERUN_A)
M(251, "51", sum(bands["beyond"]), RERUN_I + f"; all {len(bands['beyond'])} ordered alike")
M(251, "15", len(bands["within"]), RERUN_I)
M(251, "9", sum(bands["within"]), RERUN_I)
B(253, "on every prefix", min(kr.values()) > 1, min(kr.values()), RERUN_A)
M(253, "2.0x", min(kr.values()), RERUN_A)
M(253, "20.9x", max(kr.values()), RERUN_A)
M(253, "+0.17", rho_kv.statistic, RERUN_A)
M(253, "+0.52", rho_kv_x.statistic, RERUN_A)
M(253, "16.1x", kr["/local/bundles/"], RERUN_I)
B(253, "the second-largest keyword ratio", sorted(kr.values())[-2] == kr["/local/bundles/"], sorted(kr, key=kr.get)[-2], RERUN_I)
M(253, "0.20x", vr["/local/bundles/"], RERUN_A)
M(253, "0.60", rho_kv.pvalue, RERUN_I + "; t approximation (permutation 0.60)")
M(253, "0.10", rho_kv_x.pvalue, RERUN_I + "; t approximation (permutation 0.11)")
M(255, "7.24x", vr[AC], RERUN_A)
M(255, "8.89x", vm[AC], RERUN_I)
M(255, "6.57x", sorted(vr.values())[-2], RERUN_A + "; /stores/ second")
M(255, "11.3x", rr[AC], RERUN_I + "; highest RD ratio")
B(255, "the highest visits ratio ... and the highest referring-domain ratio", max(vr, key=vr.get) == AC and max(rr, key=rr.get) == AC, AC, RERUN_I)
B(255, "three months old", age[AC] == 3, age[AC], "data:ahrefs CSV")
M(257, "158.3K", num(sr("mentions in the AI-visibility panel (identical for all twelve subfolders)").rstrip("K")), SRF)
M(257, "29.5K", num(sr("cited pages in the AI-visibility panel (identical for all twelve subfolders)").rstrip("K")), SRF)
B(257, "12", sr_date("mentions in the AI-visibility panel (identical for all twelve subfolders)") == "2026-10-12", "2026-10-12", SRF)
M(257, "158,100", MENT10, SRF)
M(257, "29,600", CITED10, SRF)
B(259, "2015", [A[x]["ahrefs_first_traffic_month"] for x in ("/es-us/local/", "/deals/", "/stores/")] == ["2015-09", "2015-10", "2016-01"], "2015-09; 2015-10, 2016-01", "data:ahrefs CSV (one prefix at the horizon, two close to it)")

sec("5.6 What follows")
M(267, "27.1x", R_US_AW["August"], T2S)
M(267, "5.2", math.sqrt(R_US_AW["August"]), "arith:sqrt(27.14)")
M(267, "27.1", R_US_AW["August"], T2S)
M(267, "13", (T2V["August"][1] - T2V["August"][0]) / 2 / T2V["August"][0], "arith:(876,153 - 32,281) / 2 / 32,281")
M(269, "27.1", R_US_AW["August"], T2S)
M(269, "10.2", R_US_AW["September"], T2S)
M(269, "7.5", R_US_AW["October"], T2S)
B(269, "several hundred automated referring domains", 300 <= t5("Live referring domains", 75) - 19 <= 1000, t5("Live referring domains", 75) - 19, T5S, circ=True)
B(269, "covering two of the four months", day(65).month == 9 and day(75).month == 10, "29 Sep to 9 Oct", "arith:days 65 to 75")
LAB(271, "10", "read date (10 and 11 October), as in Table 1")
v_us, k_us = T2V["October"][1] / T2V["October"][0], KW_S / KW_A
v_ww, k_ww = T2V["October"][2] / T2V["October"][0], KW_W / ak[AC]
M(273, "7.47x", v_us, RERUN_I)
M(273, "2.02x", k_us, RERUN_I)
M(273, "3.70x", v_us / k_us, RERUN_I)
M(275, "35%", 100 * math.log(k_us) / math.log(v_us), RERUN_I)
B(275, "12", sr_date("distinct keywords on which a URL under the prefix ranks 1 to 100 (worldwide)") == "2026-10-12", "2026-10-12", SRF)
M(275, "8.62x", v_ww, RERUN_I)
M(275, "3.19x", k_ww, RERUN_I)
M(275, "2.70x", v_ww / k_ww, RERUN_I)
M(275, "54%", 100 * math.log(k_ww) / math.log(v_ww), RERUN_I)
M(277, "8.62x", v_ww, RERUN_I)
M(277, "26.7x", R_WW["July"], T2S)
M(277, "29.9x", R_WW["August"], T2S)
M(277, "18.5%", 100 - 100 * US_SHARE_T2, SRF)
M(277, "9.17x", R_USUS["October"], T2S)
M(277, "7.5x", R_US_AW["October"], T2S)
M(277, "31.8x", R_USUS["July"], T2S)
M(277, "33.3x", R_USUS["August"], T2S)
M(277, "12.5x", R_USUS["September"], T2S)
M(279, "0.20x", min(vr.values()), RERUN_A)
M(279, "7.24x", max(vr.values()), RERUN_A)
M(279, "0.20x", min(vm.values()), RERUN_A)
M(279, "8.89x", max(vm.values()), RERUN_A)
M(279, "60", conc, RERUN_A)
M(279, "66", conc + disc, RERUN_A)
M(279, "9", sum(bands["within"]), RERUN_I)
M(279, "15", len(bands["within"]), RERUN_I)
far = [o for o in opposite if max(o[2], o[3]) >= 3]
B(279, "two pairs six to seven times apart were ordered the other way", len(far) == 2 and all(6 <= max(o[2], o[3]) < 7.5 for o in far),
  [round(max(o[2], o[3]), 2) for o in far], RERUN_I, "7.25x is read as 'seven'")
M(279, "2.7", (T2V["September"][0] / T2V["August"][0]) / (T2V["September"][1] / T2V["August"][1]), RERUN_I + " (2.66)")
B(279, "a factor of five below to nearly nine above", min(vr.values()) <= 0.21 and 8.5 <= max(vm.values()) < 9, (min(vr.values()), max(vm.values())), RERUN_A)
M(281, "77", (date(2026, 10, 11) - D0).days, "arith")

# ================================================================================================ Section 6
sec("6 Measurement 2")
CR(285, "47,485", WITHHELD_REV, (SUP_REVIEWS, SUPS))
CR(285, "379", WITHHELD_REV, (SUP_LOC, SUPS))
CR(285, "37,193", WITHHELD_REV, (SUP_TEXT, SUPS))
CR(285, "378", WITHHELD_REV, (SUP_LOCTXT, SUPS))
CR(285, "1", WITHHELD_REV, (SUP_MIN, SUPS))
CR(285, "201", WITHHELD_REV, (SUP_MAX, SUPS))
CR(285, "145", WITHHELD_REV, (SUP_MED, SUPS))
CR(285, "26", WITHHELD_REV, (SUP_CARR_LOC, SUPS))
CR(285, "five different carriers", WITHHELD_REV, (SUP_CARR_N == 5, SUPS))
CR(285, "42,994", WITHHELD_REV, (SUP_NODES, SUPS))
CR(285, "1,898,584", WITHHELD_REV, (SUP_KW, SUPS))
CR(285, "37,193", WITHHELD_REV, (SUP_TEXT, SUPS))
CR(285, "20,663", WITHHELD_REV, (ARO_LINKED, AROS), "also 20,663 in the shipped r2_link_sample_output.txt")
CR(285, "55.6%", WITHHELD_REV, (100 * ARO_LINKED / SUP_TEXT, AROS + " (20,663 / 37,193)"))
M(285, "27,817", M2P["n_labels"], RERUN_M2 + "; rows of m2_label_counts.csv")
CR(285, "2.25", WITHHELD_REV, (RLS_LINKS / ARO_LINKED, "shipped outputs (46,517 links / 20,663 reviews)"))
M(285, "1,008", M2P["n_mentioned"], RERUN_M2)
M(287, "17", len(M2P["branch_shares_split"]), RERUN_M2 + "; m2_branches.csv rows")
M(287, "+0.75", M2P["rho_branch_split"], RERUN_M2)
M(287, "+0.44", M2P["ci_branch_split"][0], RERUN_M2)
M(287, "+0.90", M2P["ci_branch_split"][1], RERUN_M2)
B(287, "0.001", M2P["p_branch_split"] < 0.001, M2P["p_branch_split"], RERUN_M2)
M(287, "17", len(M2P["branch_shares_split"]), RERUN_M2)
M(287, "+0.47", M2P["rho_branch_modal"], RERUN_M2)
M(287, "+0.01", M2P["ci_branch_modal"][0], RERUN_M2)
M(287, "+0.78", M2P["ci_branch_modal"][1], RERUN_M2)
M(287, "0.06", M2P["p_branch_modal"], RERUN_M2)
CR(287, "+0.78", WITHHELD_REV + " (the superseded computation)", (g(ARO, r"branch-level Spearman: rho=([+\-][\d.]+)"), AROS))
BS = M2P["branch_shares_split"]
M(287, "66.8%", 100 * BS["Mobile & Wireless Carriers"][0], RERUN_M2)
M(287, "14.9%", 100 * BS["Mobile & Wireless Carriers"][1], RERUN_M2)
M(287, "11.0%", 100 * BS["Devices & Hardware"][0], RERUN_M2)
M(287, "32.7%", 100 * BS["Devices & Hardware"][1], RERUN_M2)
M(287, "4.0%", 100 * BS["Internet & Broadband (ISP)"][0], RERUN_M2)
M(287, "18.1%", 100 * BS["Internet & Broadband (ISP)"][1], RERUN_M2)
M(287, "1,008", M2P["n_mentioned"], RERUN_M2)
M(287, "+0.18", M2P["rho_mentioned"], RERUN_M2, "0.18487")
M(287, "+0.12", M2P["ci_mentioned"][0], RERUN_M2)
M(287, "+0.25", M2P["ci_mentioned"][1], RERUN_M2, "printed +0.245; full precision 0.245035")
M(287, "+0.13", M2P["tau_mentioned"], "recomputed from m2_label_counts.csv (Kendall over mentioned labels; ranks preserve order); shipped analyze_reviews_output.txt prints +0.132")
M(287, "26,809", M2P["n_labels"] - M2P["n_mentioned"], "arith:27,817 - 1,008")
M(287, "+0.27", M2P["rho_all"], RERUN_M2)
M(287, "+0.26", M2P["ci_all"][0], RERUN_M2)
M(287, "+0.28", M2P["ci_all"][1], RERUN_M2, "printed 0.285; full precision 0.284982")
M(287, "+0.28", M2P["rho_ge20"], "recomputed from m2_label_counts.csv (labels with at least 20 mentions); shipped analyze_reviews_output.txt prints +0.282")
M(287, "213", M2P["n_ge20"], "recomputed from m2_label_counts.csv")
CR(287, "+0.16", WITHHELD_REV + " (needs one- and two-star mentions per label, not in the released counts)", (g(ARO, r"complaint labels .*?rho\(neg mentions, volume\)=([+\-][\d.]+)"), AROS))
CR(287, "106", WITHHELD_REV, (g(ARO, r"complaint labels \(>=20 mentions in 1-2 star reviews, (\d+)\)"), AROS))
B(287, "0.001", all(float(x) < 0.001 for x in re.findall(r"\(p=([\d.e+-]+)\)", M2O.split("branch |")[0])), re.findall(r"\(p=([\d.e+-]+)\)", M2O.split("branch |")[0]), RERUN_M2 + " (label-level p-values printed)", "the p-values below 0.001 that the scripts print")
M(287, "1,008", M2P["n_mentioned"], RERUN_M2)
CR(287, "367", WITHHELD_REV + " (volume values, not ranks, needed)", (g(ARO, r"<1,000 monthly volume: (\d+)"), AROS))
CR(287, "36.4%", WITHHELD_REV, (100 * g(ARO, r"<1,000 monthly volume: (\d+)") / 1008, AROS))
M(287, "106", M2P["n_mentioned_min_volume_rank"], "recomputed from m2_label_counts.csv: mentioned labels in the lowest volume-rank group (zero volume)",
  "agrees with shipped analyze_reviews_output.txt (106)")
M(287, "10.5%", 100 * M2P["n_mentioned_min_volume_rank"] / M2P["n_mentioned"], "arith:106 / 1,008")
M(287, "+0.16", M2P["rho_own_mentioned"], RERUN_M2 + "; own (non-nested) volumes")
M(287, "+0.26", M2P["rho_own_all"], RERUN_M2)
M(289, "200", len(A1), RERUN_R2)
CR(289, "46,517", WITHHELD_REV + " (r2_link_check.py reads it from the shipped r2_link_sample_output.txt)", (RLS_LINKS, "shipped r2_link_sample_output.txt"))
M(289, "65%", 100 * pa2[0] / pa2[1], RERUN_R2 + "; annotator 2 (and annotator 1 counting unclear as wrong, 65.5%)")
M(289, "67%", 100 * pa1[0] / pa1[1], RERUN_R2 + "; annotator 1 excluding unclear")
M(289, "58%", 100 * min(wilson(*pa1)[0], wilson(*pa2)[0], wilson(pa1s[0], pa1s[1])[0]), RERUN_R2)
M(289, "73%", 100 * max(wilson(*pa1)[1], wilson(*pa2)[1]), RERUN_R2)
M(289, "95.5%", 100 * kA[1], RERUN_R2)
M(289, "0.90", kA[0], RERUN_R2)
B(289, "right about half the time", all(0.45 <= x <= 0.55 for x in (SW1, SW2)), (SW1, SW2), RERUN_R2)
M(289, "95%", 100 * min(MW1, MW2), RERUN_R2 + " (69/73 = 94.52%)")
M(289, "96%", 100 * max(MW1, MW2), RERUN_R2 + " (69/72)")
M(289, "+0.91", M2P["mw_rho_branch_split"], RERUN_M2)
M(289, "+0.74", M2P["mw_ci_branch_split"][0], RERUN_M2, "exactly 0.735 (294/400, m2_boundary.txt); half-up and half-even both give 0.74, Python's float formatting would give 0.73")
M(289, "+0.98", M2P["mw_ci_branch_split"][1], RERUN_M2)
M(289, "+0.65", M2P["mw_rho_branch_modal"], RERUN_M2)
M(289, "+0.24", M2P["mw_rho_mentioned"], RERUN_M2)
M(289, "+0.16", M2P["mw_ci_mentioned"][0], RERUN_M2)
M(289, "+0.33", M2P["mw_ci_mentioned"][1], RERUN_M2)
M(289, "56%", 100 * M2P["mw_top3_branches"]["Mobile & Wireless Carriers"][0], RERUN_M2)
M(289, "15%", 100 * M2P["mw_top3_branches"]["Mobile & Wireless Carriers"][1], RERUN_M2)
CR(291, "6,620", WITHHELD_REV, (NEG_N, AROS))
CR(291, "924", WITHHELD_REV, (NEG_W, AROS), "also 924 in shipped r2_link_sample_output.txt")
CR(291, "14.0%", WITHHELD_REV, (100 * NEG_W / NEG_N, AROS))
CR(291, "13.1%", WITHHELD_REV, (100 * wilson(NEG_W, NEG_N)[0], "Wilson interval on the shipped counts"))
CR(291, "14.8%", WITHHELD_REV, (100 * wilson(NEG_W, NEG_N)[1], "Wilson interval on the shipped counts"))
CR(291, "1.9%", WITHHELD_REV, (100 * FIVE_K / FIVE_N, SUPS + " (564 / 29,225)"))
CR(291, "1.8%", WITHHELD_REV, (100 * wilson(FIVE_K, FIVE_N)[0], "Wilson interval on the shipped counts"))
CR(291, "2.1%", WITHHELD_REV, (100 * wilson(FIVE_K, FIVE_N)[1], "Wilson interval on the shipped counts"))
M(291, "100", len(B1), RERUN_R2)
CR(291, "924", WITHHELD_REV, (RLS_WAIT, "shipped r2_link_sample_output.txt"))
M(291, "83%", 100 * pb2[0] / pb2[1], RERUN_R2 + "; annotator 2")
M(291, "85%", 100 * pb1[0] / pb1[1], RERUN_R2 + "; annotator 1 excluding unclear (84.8%)")
M(291, "0.93", kB[0], RERUN_R2)
B(291, "about nine in ten of those concern waiting in the store", all(0.85 <= x <= 0.95 for x in (inst1, inst2)), (round(inst1, 3), round(inst2, 3)), RERUN_R2)
M(291, "12%", 100 * statistics.mean([IMPL1, IMPL2]), RERUN_R2 + " (11.9% and 11.6%, using the shipped 924 / 6,620)", approx=0.05)
CR(291, "1.9", WITHHELD_REV, (SUP_KW / 1e6, SUPS + " (1,898,584 keywords)"))
CR(291, "11", WITHHELD_REV, (g(SUP, r"distinct such labels: (\d+)"), SUPS))
CR(291, "622", WITHHELD_REV, (g(SUP, r"their monthly volume: (\d+)"), SUPS))
CR(291, "none concerns waiting in a store", WITHHELD_REV, (True, SUPS + " (label list)"), "the eleven labels are listed in the shipped output")
CR(291, "12", WITHHELD_REV, (g(ARO, r"total monthly volume on them: (\d+)"), AROS))
CR(291, "Eight labels name a remedy", WITHHELD_REV, (g(SUP, r"naming appointments, queues or callbacks: (\d+) labels") == 8, SUPS))
CR(291, "13,170", WITHHELD_REV, (g(SUP, r"naming appointments, queues or callbacks: \d+ labels, (\d+) searches"), SUPS))
CR(291, "the label for scheduling a store appointment carries none", WITHHELD_REV, ("Scheduling a Store Appointment for Tech Help: 0" in SUP, SUPS))
CR(291, "no label concerns check-in", WITHHELD_REV, ("naming check-in: 0" in SUP, SUPS))
CR(293, "37,193", WITHHELD_REV, (SUP_TEXT, SUPS))
CR(293, "378", WITHHELD_REV, (SUP_LOCTXT, SUPS))
CR(293, "42,994", WITHHELD_REV, (SUP_NODES, SUPS))
M(293, "1,008", M2P["n_mentioned"], RERUN_M2)
M(293, "17", len(M2P["branch_shares_split"]), RERUN_M2)
B(293, "the nine largest of the 17 top-level branches", "top = b.head(9)" in sh("review_demand/make_fig_reviews_v50.py"), "head(9)", "data:make_fig_reviews_v50.py")
B(295, "about two in three are correct", 0.6 <= pa2[0] / pa2[1] <= 0.7, pa2[0] / pa2[1], RERUN_R2)

# ================================================================================================ Section 7
sec("7 Measurement 3")
PILOTS = "shipped pilot_section_output.txt (the pilot's section of the script and its exports are withheld)"
B(303, "12", "12 Oct 22:21-22:26" in PIL, "12 Oct 22:21-22:26", "data:pilot_section_output.txt (shipped)")
B(303, "22", "22:21-22:26" in PIL, "22:21-22:26", "data:pilot_section_output.txt (shipped)")
B(303, "21", "22:21-22:26" in PIL, "22:21-22:26", "data:pilot_section_output.txt (shipped)")
B(303, "22", "22:21-22:26" in PIL, "22:21-22:26", "data:pilot_section_output.txt (shipped)")
B(303, "26", "22:21-22:26" in PIL, "22:21-22:26", "data:pilot_section_output.txt (shipped)")
CR(303, "under an hour before the first sector export", "the export log with the first export's time (23:05) is not released")
CR(303, "six online-learning brands", "the pilot's brand set and exports are withheld")
pil = {m.group(1).strip(): (int(m.group(2)), int(m.group(3))) for m in re.finditer(r"  (.+?)\s+YouTube non-brand rank (\d+); Reddit (\d+);", PIL)}
CR(303, "the most-cited non-brand domain on all four Google views", WITHHELD_RAW + " (pilot)", (all(pil[k][0] == 1 for k in pil if k.startswith("AI ")), PILOTS))
CR(303, "28th on ChatGPT", WITHHELD_RAW, (pil["ChatGPT"][0] == 28, PILOTS))
CR(303, "4th on Perplexity", WITHHELD_RAW, (pil["Perplexity"][0] == 4, PILOTS))
CR(303, "5th on Gemini", WITHHELD_RAW, (pil["Gemini"][0] == 5, PILOTS))
CR(303, "9th on Copilot", WITHHELD_RAW, (pil["Copilot"][0] == 9, PILOTS))
CR(303, "reddit.com in the top three on every surface except Copilot", WITHHELD_RAW, (all(v[1] <= 3 for k, v in pil.items() if k != "Copilot"), PILOTS))
CR(303, "240th", WITHHELD_RAW, (pil["Copilot"][1] == 240, PILOTS))
B(307, "12", "written 12 October 2026 before any sector data was collected" in DESIGN, "design file status line", "data:design/cross_sector_ai_citation_study.md")
B(307, "eight exports that repeated a view or mixed two platforms", "Eight exports that repeated an earlier view or mixed two platforms" in DESIGN, "A2", "data:design file")
B(307, "14", "after 14 of 88 exports" in DESIGN, "14 of 88", "data:design file (Energy 8 surfaces + Utilities 6)")
B(307, "88", "after 14 of 88 exports" in DESIGN and len(SECTORS) * len(SURF) == 88, 88, "data:design file; 11 x 8")
B(307, "9", "holdings as of 9 October 2026" in DESIGN, "holdings as of 9 October 2026", "data:design file")
M(307, "109", len(COMP), "data:design/cross_sector_companies.csv (rows)")
B(307, "109 companies, because Communication Services counts one issuer, Alphabet, through two share classes",
  sum(c["etf"] == "XLC" for c in COMP) == 9 and "Alphabet" in DESIGN, "XLC holds 9 companies", "data:companies CSV and design file")
CR(307, "23:05", "the export log is not released", None, "start of the collection session")
B(307, "01:15", max(COUNTS[s]["read_at_local"] for s in SECTORS) == "2026-10-13 01:15", max(COUNTS[s]["read_at_local"] for s in SECTORS), "data:aggregates/sector_answer_counts.csv read_at_local")
CR(307, "01:05", "the export log is not released", None, "last export")
B(307, "01:10", min(COUNTS[s]["read_at_local"] for s in SECTORS) == "2026-10-13 01:10", min(COUNTS[s]["read_at_local"] for s in SECTORS), "data:sector_answer_counts.csv read_at_local")
B(307, "eight vendor views of six answer products", len(SURF) == 8, "8 surfaces; AIO, AIM, ChatGPT, Perplexity, Gemini, Copilot", "data:aggregates")
B(307, "1,000", all(int(CELLS[(s, p)]["export_rows"]) == 1000 for s in SECTORS for p in SURF), 1000, "data:cross_sector_cells.csv export_rows")
M(307, "760", min(DOMS), RERUN_S7)
M(307, "975", max(DOMS), RERUN_S7)
M(307, "88", len(SIZES), RERUN_S7)
M(307, "20,389,967", sum(ANS.values()), RERUN_S7 + "; sector_answer_counts.csv")
M(307, "18,763", ANS["xlu"], RERUN_S7 + "; Utilities")
M(307, "7,766,466", ANS["xly"], RERUN_S7 + "; Consumer Discretionary")
B(307, "from 18,763 (Utilities) to 7,766,466 (Consumer Discretionary)", min(ANS, key=ANS.get) == "xlu" and max(ANS, key=ANS.get) == "xly", "xlu, xly", RERUN_S7)
for tok in ("282", "24", "13", "15", "90"):
    EXT(307, tok, "vendor documentation (Bek 2026)")
CSRC = sh(SCR + "cross_sector.py")
plat = re.findall(r'"([a-z.]+\.(?:com|net|to))"', CSRC[CSRC.index("TYPES = {"):CSRC.index('"reference"')])
B(309, "nine companies in Communication Services", sum(c["etf"] == "XLC" for c in COMP) == 9, 9, "data:companies CSV")
B(309, "the seventeen video and community platforms listed", len(plat) == 18 and "x.com" in plat and "twitter.com" in plat, f"{len(plat)} domains (x.com and twitter.com are one platform)", "data:cross_sector.py TYPES")
M(313, "21.3%", 100 * med(G_ALL), RERUN_S7)
M(313, "8.1%", 100 * min(G_ALL), RERUN_S7)
M(313, "35.8%", 100 * max(G_ALL), RERUN_S7)
M(313, "17.2%", g(S7O, r"Google ([\d.]+)% to [\d.]+%; other four"), RERUN_S7 + "; bootstrap over sectors, seed 20261013")
M(313, "26.7%", g(S7O, r"Google [\d.]+% to ([\d.]+)%; other four"), RERUN_S7)
M(313, "2.1%", 100 * med(C_ALL), RERUN_S7)
M(313, "0.3%", 100 * min(C_ALL), RERUN_S7)
M(313, "16.7%", 100 * max(C_ALL), RERUN_S7)
M(313, "1.7%", g(S7O, r"other four ([\d.]+)% to [\d.]+%\n"), RERUN_S7)
M(313, "2.7%", g(S7O, r"other four [\d.]+% to ([\d.]+)%\n"), RERUN_S7)
M(313, "0.6%", 100 * SURF_MED["copilot"], RERUN_S7)
M(313, "0.9%", 100 * SURF_MED["chatgpt"], RERUN_S7)
M(313, "4.6%", 100 * SURF_MED["perplexity"], RERUN_S7)
M(313, "9.2%", 100 * SURF_MED["gemini"], RERUN_S7)
B(313, "In every one of the eleven sectors", EVERY == 11, f"{EVERY}/11", RERUN_S7)
M(313, "24.6%", 100 * med([comm(s, p) for s in SECTORS for p in ("aio_prompts", "aimode_prompts")]), RERUN_S7)
M(313, "38", YT_TOP3_G, RERUN_S7)
M(313, "44", len(SECTORS) * 4, RERUN_S7)
B(313, "none of the 44 others", YT_TOP3_C == 0, YT_TOP3_C, RERUN_S7)
M(313, "44", len(SECTORS) * 4, RERUN_S7)
M(313, "1", YT_MED["aio_searchqueries"], RERUN_S7 + "; median rank on both AI Overviews views is 1")
B(313, "1 on AI Overviews", YT_MED["aio_searchqueries"] == 1 and YT_MED["aio_prompts"] == 1, (YT_MED["aio_searchqueries"], YT_MED["aio_prompts"]), RERUN_S7)
M(313, "2", YT_MED["aimode_searchqueries"], RERUN_S7)
B(313, "2 on AI Mode", YT_MED["aimode_searchqueries"] == 2 and YT_MED["aimode_prompts"] == 2, (YT_MED["aimode_searchqueries"], YT_MED["aimode_prompts"]), RERUN_S7)
M(313, "7", YT_MED["perplexity"], RERUN_S7)
B(313, "7 on Perplexity and Gemini", YT_MED["perplexity"] == 7 and YT_MED["gemini"] == 7, (YT_MED["perplexity"], YT_MED["gemini"]), RERUN_S7)
M(313, "151", YT_MED["chatgpt"], RERUN_S7)
M(313, "161", YT_MED["copilot"], RERUN_S7)
M(313, "12.7%", 100 * med([NYT(s, p) for s in SECTORS for p in GOOGLE]), RERUN_S7 + "; without YouTube")
M(313, "1.6%", 100 * med([NYT(s, p) for s in SECTORS for p in CHAT]), RERUN_S7)
M(313, "7", EVERY_NYT, RERUN_S7)
M(313, "11", len(SECTORS), RERUN_S7)
B(313, "Gemini ... is the highest of the other four", max(SURF_MED[p] for p in CHAT) == SURF_MED["gemini"], "gemini", RERUN_S7)
M(315, "2.7%", 100 * TYPEMED["share_reference"][1], RERUN_S7 + "; reference, other four")
M(315, "3.2%", 100 * TYPEMED["share_reference"][0], RERUN_S7 + "; reference, Google views")
M(315, "1.1%", 100 * TYPEMED["share_forum"][1], RERUN_S7 + "; forum, other four")
M(315, "5.7%", 100 * TYPEMED["share_forum"][0], RERUN_S7 + "; forum, Google views")
M(315, "14.1%", 100 * TYPEMED["share_report_brands"][1], RERUN_S7 + "; company domains, other four")
B(315, "the largest classified type on those four was the company domains",
  TYPEMED["share_report_brands"][1] == max(med([TS[(s, p)][k] for s in SECTORS for p in CHAT]) for k in
                                           ("share_video_community", "share_reference", "share_news", "share_government", "share_report_brands")),
  "company domains", RERUN_S7)
M(315, "61%", 100 * TYPEMED["share_other_web"][0], RERUN_S7 + " (61.1%)")
M(315, "72%", 100 * TYPEMED["share_other_web"][1], RERUN_S7 + " (71.7%)")
M(315, "90%", 100 * TYPEMED["share_other_web"][2], RERUN_S7 + " (89.9%)")
B(315, "seventeen named video and community platforms", len(plat) == 18, "17 platforms, 18 domains", "data:cross_sector.py TYPES")
M(315, "88", len(SIZES), RERUN_S7)
M(315, "77%", 100 * VAR["share_video_community"][0], RERUN_S7)
M(315, "70%", g(S7O, r"bootstrap video_community\s+surface \[(\d+)%"), RERUN_S7 + "; seed 20261015")
M(315, "91%", g(S7O, r"bootstrap video_community\s+surface \[\d+%, (\d+)%\]"), RERUN_S7)
M(315, "14%", 100 * VAR["share_video_community"][1], RERUN_S7)
M(315, "5%", g(S7O, r"bootstrap video_community\s+surface \[\d+%, \d+%\]\s+sector \[(\d+)%"), RERUN_S7)
M(315, "20%", g(S7O, r"bootstrap video_community\s+surface \[\d+%, \d+%\]\s+sector \[\d+%, (\d+)%\]"), RERUN_S7)
M(315, "12%", 100 * VAR["share_news"][0], RERUN_S7)
M(315, "73%", 100 * VAR["share_news"][1], RERUN_S7)
M(315, "26%", 100 * VAR["share_government"][0], RERUN_S7)
M(315, "49%", 100 * VAR["share_government"][1], RERUN_S7)
M(315, "40%", 100 * VAR["share_report_brands"][0], RERUN_S7)
M(315, "45%", 100 * VAR["share_report_brands"][1], RERUN_S7)
M(315, "88", len(SIZES), RERUN_S7)
CHAT_TOP = {s: TOP[(s, "chatgpt")][0] for s in SECTORS}
B(317, "ChatGPT's most-cited non-company domain by sector (search engine, FDA, personal-finance publisher, streaming guide, Disney property, graphics-card maker, reddit.com, SEC x3, paint maker)",
  [CHAT_TOP[s] for s in SECTORS] == ["google.com", "fda.gov", "nerdwallet.com", "justwatch.com", "go.com", "nvidia.com", "reddit.com", "sec.gov", "sec.gov", "sec.gov", "benjaminmoore.com"],
  [CHAT_TOP[s] for s in SECTORS], "data:aggregates/cross_sector_top10_nonbrand.csv")
M(317, "0.36", min(JAC[p] for p in GOOGLE), RERUN_S7)
M(317, "0.40", max(JAC[p] for p in GOOGLE), RERUN_S7)
M(317, "55", len(list(combinations(SECTORS, 2))), "arith:11 choose 2")
M(317, "0.08", min(JAC[p] for p in CHAT), RERUN_S7, "0.0750 (ChatGPT)")
M(317, "0.23", max(JAC[p] for p in CHAT), RERUN_S7)
CR(317, "22.5%", WITHHELD_RAW, (g(SEN2, r"company properties\s+AI Overviews \(search queries\)\s+([\d.]+)%"), SENS2))
CR(317, "24.2%", WITHHELD_RAW, (g(SEN2, r"company properties\s+AI Overviews \(search queries\)\s+[\d.]+% vs ([\d.]+)%"), SENS2))
sens_p = [float(x) for x in re.findall(r"vs [\d.]+%, p ([\d.]+)", SEN2)]
CR(317, "0.23", WITHHELD_RAW, (min(sens_p), SENS2 + " (smallest p of the four checks)"))
CR(317, "0.63", WITHHELD_RAW, (max(sens_p), SENS2 + " (largest p)"))
for tok, comp_, pat in (("94%", "Sherwin-Williams", r"Materials\s+Sherwin-Williams\s+([\d.]+)%"), ("75%", "Amazon", r"Consumer Discretionary\s+Amazon\s+([\d.]+)%"),
                        ("65%", "Walmart", r"Consumer Staples\s+Walmart\s+([\d.]+)%"), ("62%", "Apple", r"Information Technology\s+Apple\s+([\d.]+)%"),
                        ("55%", "Uber", r"Industrials\s+Uber\s+([\d.]+)%")):
    CR(317, tok, WITHHELD_RAW + " (all-surface export)", (g(SEN, pat), SENS), comp_)
TOPS = {(s, p): TOP[(s, p)][:3] for s in SECTORS for p in SURF}
B(317, "go.com, chase.com and mobil.com among ChatGPT's top three", "go.com" in TOPS[("xlc", "chatgpt")] and "chase.com" in TOPS[("xlf", "chatgpt")] and "mobil.com" in TOPS[("xle", "chatgpt")],
  "xlc go.com, xlf chase.com, xle mobil.com", "data:cross_sector_top10_nonbrand.csv")
M(321, "9", P1["aio_searchqueries"], RERUN_S7)
M(321, "11", len(SECTORS), RERUN_S7)
M(321, "8", P1["aio_prompts"], RERUN_S7)
M(321, "11", len(SECTORS), RERUN_S7)
M(321, "2", P1["aimode_searchqueries"], RERUN_S7)
B(321, "2 of 11 on each", P1["aimode_searchqueries"] == P1["aimode_prompts"] == 2, (P1["aimode_searchqueries"], P1["aimode_prompts"]), RERUN_S7)
M(321, "11", len(SECTORS), RERUN_S7)
B(321, "P1 fails as written", P1_BOTH < 6, f"{P1_BOTH}/11 sectors on both products", RERUN_S7)
CR(321, "93%", WITHHELD_RAW, (g(SEN2, r"AI Mode \(search queries\)\s+www\.google\.com (\d+)%"), SENS2))
CR(321, "98%", WITHHELD_RAW, (g(SEN2, r"AI Mode \(prompts\)\s+www\.google\.com (\d+)%"), SENS2))
CR(321, "9", WITHHELD_RAW, (g(SEN, r"P1 with google\.com set aside: .*? both products (\d+)"), SENS))
CR(321, "11", WITHHELD_RAW, (11, SENS))
CR(321, "It fails under every domain reduction tried", WITHHELD_RAW,
   (all(int(x) < 6 for x in re.findall(r"both products (\d+)/11", SEN)), SENS + " (both products 4/11, 4/11, 5/11)"))
M(321, "11", P2["chatgpt"], RERUN_S7)
M(321, "6", P2["perplexity"], RERUN_S7)
M(321, "11", P2["copilot"], RERUN_S7)
M(321, "11", len(SECTORS), RERUN_S7)
M(321, "3", len(P3), RERUN_S7)
M(321, "11", len(SECTORS), RERUN_S7)
B(321, "ChatGPT was a failing surface in all eight sectors where it did not hold", P3_CHATFAIL == 8 and len(P3) == 3, f"{P3_CHATFAIL} of {11 - len(P3)}", RERUN_S7)
B(321, "five consumer-facing sectors than in five others", len(CONS) == 5 and len(NONC) == 5 and "xlf" not in CONS + NONC, "5 and 5, Financials in neither", RERUN_S7)
M(321, "26.9%", 100 * P4["aio_searchqueries"][0], RERUN_S7)
M(321, "24.2%", 100 * P4["aio_searchqueries"][1], RERUN_S7)
M(321, "29.6%", 100 * P4["aio_prompts"][0], RERUN_S7)
M(321, "24.4%", 100 * P4["aio_prompts"][1], RERUN_S7)
M(321, "0.27", P4["aio_searchqueries"][2], RERUN_S7 + "; exact one-sided permutation")
M(321, "0.21", P4["aio_prompts"][2], RERUN_S7)
B(321, "Of the four, one held, one held in direction only and two failed", P1_BOTH < 6 and all(v >= 6 for v in P2.values()) and len(P3) < 6
  and all(P4[p][0] > P4[p][1] and P4[p][2] > 0.05 for p in P4), "P1 fail, P2 hold, P3 fail, P4 direction only", RERUN_S7)


def sen(label):
    m = re.search(re.escape(label) + r": Google median ([\d.]+)%, other four median ([\d.]+)%.*?in (\d+)/11 sectors", SEN)
    return float(m.group(1)), float(m.group(2)), int(m.group(3))


for (tok1, tok2, tok3, tok4, lab) in (("21.5%", "3.3%", "11", "11", "'Found in' instead of 'Cited in'"),
                                     ("22.0%", "2.4%", "11", "11", "largest single host instead of summed hosts"),
                                     ("19.8%", "2.1%", "10", "11", "company properties counted as company domains")):
    v = sen(lab)
    CR(325, tok1, WITHHELD_RAW, (v[0], SENS))
    CR(325, tok2, WITHHELD_RAW, (v[1], SENS))
    CR(325, tok3, WITHHELD_RAW, (v[2], SENS))
    LAB(325, tok4, "denominator, eleven sectors")
M(325, "64", len(PROPS), "data:design/cross_sector_company_properties.csv (rows)", "the design file also says 64")
cs_line = re.search(r"Communication Services, entered domains -> with Alphabet and Meta properties as company: (.*)", SEN).group(1)
cs_vals = {k.strip(): (float(a), float(b)) for k, a, b in re.findall(r"([A-Za-z() ]+?) ([\d.]+)% -> ([\d.]+)%", cs_line)}
g_before = [cs_vals[k][0] for k in cs_vals if k.startswith("AI ")]
g_after = [cs_vals[k][1] for k in cs_vals if k.startswith("AI ")]
CR(325, "20.2%", WITHHELD_RAW, (min(g_before), SENS))
CR(325, "32.4%", WITHHELD_RAW, (max(g_before), SENS))
CR(325, "5.9%", WITHHELD_RAW, (min(g_after), SENS))
CR(325, "12.7%", WITHHELD_RAW, (max(g_after), SENS))
CR(325, "9.2%", WITHHELD_RAW, (cs_vals["Gemini"][1], SENS))
CR(325, "Gemini's 9.2% exceeds AI Mode on search queries", WITHHELD_RAW, (cs_vals["Gemini"][1] > cs_vals["AI Mode (search queries)"][1], SENS))
for rows_, gm_, cm_ in (("100", "30.6%", "3.0%"), ("250", "26.3%", "2.6%"), ("500", "23.3%", "2.3%")):
    v = sen(f"first {rows_} export rows only")
    LAB(325, rows_, "row cut-off")
    CR(325, gm_, WITHHELD_RAW, (v[0], SENS))
    CR(325, cm_, WITHHELD_RAW, (v[1], SENS))
CR(325, "the ratio between the two groups stays near ten", WITHHELD_RAW,
   (all(9 <= sen(f"first {r} export rows only")[0] / sen(f"first {r} export rows only")[1] <= 11 for r in ("100", "250", "500")), SENS))
M(325, "7.6%", 100 * min(TRUNC.values()), RERUN_S7 + "; median mass of rows 501 to 1,000, lowest surface")
M(325, "13.8%", 100 * max(TRUNC.values()), RERUN_S7 + "; highest surface")
RTX = {p: (PM[("xli", p)], PM[("xli_rtxcorp", p)]) for p in SURF if ("xli_rtxcorp", p) in PM}
M(329, "31.3%", 100 * float(RTX["aio_searchqueries"][0]["share_community_video"]), RERUN_S7 + "; RTX re-run")
M(329, "30.1%", 100 * float(RTX["aio_searchqueries"][1]["share_community_video"]), RERUN_S7)
B(329, "YouTube's rank stayed 1 on AI Overviews", all(RTX[p][0]["yt_rank_nonbrand"] == RTX[p][1]["yt_rank_nonbrand"] == "1" for p in ("aio_searchqueries", "aio_prompts")), "1 -> 1", RERUN_S7)
M(329, "1", int(RTX["aio_searchqueries"][1]["yt_rank_nonbrand"]), RERUN_S7)
M(329, "2", int(RTX["aimode_prompts"][0]["yt_rank_nonbrand"]), RERUN_S7 + "; AI Mode prompts before")
M(329, "1", int(RTX["aimode_prompts"][1]["yt_rank_nonbrand"]), RERUN_S7 + "; after")
M(329, "6.2%", 100 * float(RTX["perplexity"][0]["share_community_video"]), RERUN_S7)
M(329, "5.5%", 100 * float(RTX["perplexity"][1]["share_community_video"]), RERUN_S7)
M(329, "15.0%", 100 * float(RTX["gemini"][0]["share_community_video"]), RERUN_S7)
M(329, "13.4%", 100 * float(RTX["gemini"][1]["share_community_video"]), RERUN_S7)
B(329, "Copilot's top non-company domain from amazon.com to a flight-route site", RTX["copilot"][0]["top1_nonbrand"] == "amazon.com" and RTX["copilot"][1]["top1_nonbrand"] == "flightconnections.com",
  f'{RTX["copilot"][0]["top1_nonbrand"]} -> {RTX["copilot"][1]["top1_nonbrand"]}', RERUN_S7)
B(329, "its ChatGPT export failed twice on the vendor's side", "failed twice with a vendor-side error" in DESIGN and "chatgpt" not in RTX, "no xli_rtxcorp ChatGPT row", "data:design file A2 and aggregates")
M(329, "0.8%", 100 * CHATGPT_MED_NOXLI, "recomputed from aggregates/cross_sector_platform_metrics.csv (ChatGPT median without Industrials)", "agrees with shipped sensitivity outputs")
M(329, "10", P2_NOXLI["chatgpt"], "recomputed from aggregates (P2 without Industrials, ChatGPT)")
M(329, "10", len(NO_XLI), "denominator: ten sectors without Industrials")
B(329, "P2 holds on ChatGPT and Copilot in 10 of 10", P2_NOXLI["chatgpt"] == P2_NOXLI["copilot"] == 10, (P2_NOXLI["chatgpt"], P2_NOXLI["copilot"]), "recomputed from aggregates")
M(329, "6", P2_NOXLI["perplexity"], "recomputed from aggregates")
M(329, "10", len(NO_XLI), "denominator")
M(329, "3", P3_NOXLI, "recomputed from aggregates (P3 without Industrials)")
M(329, "10", len(NO_XLI), "denominator")
visa = [float(x) for x in re.findall(r"state\.gov\+uscis\.gov\+cbp\.gov\+dhs\.gov ([\d.]+)%", SEN)]
CR(329, "2.2%", WITHHELD_RAW, (max(visa), SENS + " (largest of the eight Financials surfaces)"))
CR(329, "four immigration and border domains of the US government", WITHHELD_RAW, (len("state.gov+uscis.gov+cbp.gov+dhs.gov".split("+")) == 4, SENS))
B(329, "25", "25 most-cited non-company" in DESIGN, "25", "data:design file (company-property screen)")
CR(329, "two possible further cases", WITHHELD_RAW, None, "domain-level screen of the raw exports")
M(329, "860", min(SIZES), RERUN_S7)
M(329, "18,381,848", max(SIZES), RERUN_S7)
EXT(329, "19.4%", "Punturo et al. 2026; same figure as Section 2")
EXT(329, "31%", "Tinuiti 2026; same figure as Section 2")
M(329, "4.6%", 100 * SURF_MED["perplexity"], RERUN_S7)
B(331, "about ten times the pooled median share of the other four surfaces", 9 <= med(G_ALL) / med(C_ALL) <= 11, med(G_ALL) / med(C_ALL), RERUN_S7)
B(331, "more than twice Gemini's", med(G_ALL) > 2 * SURF_MED["gemini"], med(G_ALL) / SURF_MED["gemini"], RERUN_S7)
B(331, "news, government and company sources vary more by sector", all(VAR[k][1] > VAR[k][0] for k in ("share_news", "share_government", "share_report_brands")), "sector > surface", RERUN_S7)

# ================================================================================================ Section 8 and Table 5
sec("8 Deployment series, Table 5")
M(335, "381", len(CODES), CODEF)
LAB(337, "11", "read date of Table 5")
HDR = {0: (26, 7), 15: (10, 8), 30: (25, 8), 37: (1, 9), 45: (9, 9), 60: (24, 9), 75: (9, 10), 77: (11, 10)}
for d, (dd, mm) in HDR.items():
    B(339, str(dd), day(d) == date(2026, mm, dd), day(d), f"arith:day {d} = 26 July + {d} days")
FIGS4 = sh("make_figs_v4.py")
fig_days = eval(re.search(r"^days = (\[.*?\])", FIGS4, re.M).group(1))
fig_all = eval(re.search(r"^pos_all = (\[.*?\])", FIGS4, re.M).group(1))
fig_top3 = eval(re.search(r"^pos_top3 = (\[.*?\])", FIGS4, re.M).group(1))
FIGD = dict(zip(fig_days, zip(fig_all, fig_top3)))
T5MAP = {341: "Pages holding a position", 342: "Ranking positions, all", 343: "Positions 1–3", 344: "Positions 4–10", 345: "Positions 11–20",
         346: "Positions 21–100 (derived)", 347: "Estimated visits (Ahrefs)", 348: "Live referring domains", 349: "AI answers citing the section"}
for ln, metric in T5MAP.items():
    cells = [c.strip().replace("**", "").replace("≈", "") for c in MS[ln - 1].strip().strip("|").split("|")][1:]
    for d, cell in zip(T5DAYS, cells):
        if cell == "n/r":
            continue
        v = t5(metric, d)
        basis, circ, note = T5S, True, ""
        if metric == "Positions 21–100 (derived)":
            parts = [t5(m_, d) for m_ in ("Ranking positions, all", "Positions 1–3", "Positions 4–10", "Positions 11–20")]
            v = parts[0] - parts[1] - parts[2] - parts[3]
            basis, circ, note = "arith:total - (1-3) - (4-10) - (11-20)", False, ""
        elif metric in ("Ranking positions, all", "Positions 1–3") and d in FIGD:
            fv = FIGD[d][0 if metric == "Ranking positions, all" else 1]
            note = f"make_figs_v4.py constant {fv}" + ("" if fv == v else " DIFFERS")
        M(ln, f"{num(cell):,.0f}" if num(cell) >= 1000 else cell, v, basis, note, circ=circ)
B(351, "the instrument reports only three bands and the total", len(T5MAP) == 9, "rows 1-3, 4-10, 11-20, total", "manuscript Table 5")
B(353, "The estimated-visits peak at day 60", max((t5("Estimated visits (Ahrefs)", d) or 0, d) for d in T5DAYS)[1] == 60, "day 60 (244,041)", T5S, circ=True)
M(355, "15,830", t5("Ranking positions, all", 37), T5S, circ=True)
M(355, "1,874", t5("Positions 1–3", 37), T5S, circ=True)
M(355, "51,800", t5("Estimated visits (Ahrefs)", 37), T5S, circ=True)
B(355, "nineteen referring domains", t5("Live referring domains", 37) == 19, 19, T5S, circ=True)
M(355, "43,980", t5("Ranking positions, all", 77), T5S, circ=True)
M(355, "441", t5("Pages holding a position", 77), T5S, circ=True)
M(355, "29,000", KW_A, SRF)
M(355, "58,586", KW_S, SRF)
M(355, "7,455", T3V["October"][0], "data:Table 3 series CSV (October numerator)", circ=True)
M(355, "17,206", t5("AI answers citing the section", 77), T5S, circ=True)
M(357, "441", t5("Pages holding a position", 77), T5S, circ=True)
B(357, "11", sr_date("share of estimated visits carried by the top 50 of the 441 URLs") == "2026-10-11", "2026-10-11", SRF + " (read date)")
M(357, "22.8%", num(sr("share of estimated visits carried by the ten highest-traffic URLs of the 441 holding a position").rstrip("%")), SRF)
LAB(357, "50", "definition: the top 50 URLs")
M(357, "64.9%", num(sr("share of estimated visits carried by the top 50 of the 441 URLs").rstrip("%")), SRF)
M(357, "441", t5("Pages holding a position", 77), T5S, circ=True)
M(357, "11%", 100 * 50 / 441, "arith:50 / 441")
B(357, "about two thirds of the estimated traffic", 0.6 <= 0.649 <= 0.7, "64.9%", SRF)
M(359, "58,586", KW_S, SRF)
B(359, "40", sr(next(k for k in SR if k.startswith("reported monthly searches of the lowest-traffic rows"))) == "40 to 170, or none", "40 to 170, or none", SRF)
B(359, "170", sr(next(k for k in SR if k.startswith("reported monthly searches of the lowest-traffic rows"))) == "40 to 170, or none", "40 to 170, or none", SRF)
M(359, "105", num(sr("countries in which the section ranks")), SRF)
M(359, "18.5%", num(sr("share of Ahrefs-estimated visits from outside the US").rstrip("%")), SRF)

# ================================================================================================ Section 9
sec("9 What the answers cite")
for tok, q in (("474", "New York state hub"), ("337", "California state hub"), ("322", "Texas state hub"), ("304", "Florida state hub"),
               ("294", "national hub"), ("238", "214 (Dallas) code page"), ("228", "786 (Miami) code page"), ("218", "404 (Atlanta) code page")):
    M(365, tok, num(sr(f"stored AI answers citing the page: {q}")), SRF + " (and make_figs_v4.py, Figure 8)")
for code, city_state in (("214", "TX"), ("786", "FL"), ("404", "GA")):
    B(365, code, CODE[code]["location"] == city_state, CODE[code]["location"], CODEF + f"; area code {code} in {city_state}")
per_code = {st_: num(sr(f"stored AI answers citing the page: {name} state hub")) / sum(r["location"] == st_ for r in CODES)
            for st_, name in (("NY", "New York"), ("CA", "California"), ("TX", "Texas"), ("FL", "Florida"))}
B(365, "per code it lists, a state hub is cited less often than the most-cited code pages", all(v < 218 for v in per_code.values()),
  {k: round(v, 1) for k, v in per_code.items()}, SRF + " and " + CODEF + " (codes per state)")
B(367, "The eight pages", len(re.findall(r'\("([^"]+)", \d+, (?:True|False)\)', FIGS4)) == 8, 8, "data:make_figs_v4.py Figure 8 data")
B(369, "1.0", "grades 1.0 for a dedicated page" in "\n".join(MS) and "0.5 for a list or section page" in "\n".join(MS), "Appendix B rubric", "internal consistency with Appendix B (the rubric itself is in the ufi repository, not in the bundle)")
LAB(369, "0.5", "rubric grade (specification), as in Appendix B")
FIVE = next(k for k in SR if k.startswith("Domain Rating of the five domains"))
B(375, "five domains with the largest keyword overlap", "five domains" in FIVE and "two area-code directories, a time-zone reference, two voice vendors" in FIVE, FIVE[:60], SRF)
B(375, "13", sr(FIVE) == "13 to 83", "13 to 83", SRF)
B(375, "83", sr(FIVE) == "13 to 83", "13 to 83", SRF)
M(375, "97", num(sr("Domain Rating of wikipedia.org")), SRF)
M(375, "11,000", num(sr("answers citing the section that also cite wikipedia.org").replace("about ", "")), SRF + " ('about 11,000')")
M(375, "9", num(sr("answers citing the section that also cite a national carrier (Domain Rating 91)")), SRF)
M(375, "91", int(re.search(r"Domain Rating (\d+)", "answers citing the section that also cite a national carrier (Domain Rating 91)").group(1)) if any(r["quantity"].endswith("(Domain Rating 91)") for r in SRL) else -1, SRF + " (the single read is recorded for the carrier at Domain Rating 91)")
M(375, "240", num(sr("answers citing the section that also cite a national carrier (Domain Rating 87)")), SRF)
M(375, "87", 87 if any(r["quantity"].endswith("(Domain Rating 87)") for r in SRL) else -1, SRF + " (the single read is recorded for the carrier at Domain Rating 87)")
M(375, "17,206", t5("AI answers citing the section", 77), T5S, circ=True)

# ================================================================================================ Section 10 and Table 6
sec("10 Link profile, Table 6")
B(383, "zero live referring domains through 31 July", sr("live referring domains to the prefix, 26 to 31 July (days 0 to 5)") == "0" and day(5) == date(2026, 7, 31), "0 on days 0 to 5", SRF)
B(383, "31", day(5) == date(2026, 7, 31), day(5), "arith:day 5")
B(383, "one on 10 August", t5("Live referring domains", 15) == 1 and day(15) == date(2026, 8, 10), 1, T5S, circ=True)
B(383, "10", day(15) == date(2026, 8, 10), day(15), "arith:day 15")
B(383, "nineteen on 25 August", t5("Live referring domains", 30) == 19 and day(30) == date(2026, 8, 25), 19, T5S, circ=True)
B(383, "25", day(30) == date(2026, 8, 25), day(30), "arith:day 30")
B(383, "still nineteen on 1 September", t5("Live referring domains", 37) == 19 and day(37) == date(2026, 9, 1), 19, T5S, circ=True)
B(383, "1", day(37) == date(2026, 9, 1), day(37), "arith:day 37")
M(383, "15,830", t5("Ranking positions, all", 37), T5S, circ=True)
B(385, "11", sr_date("live referring domains to the prefix") == "2026-10-11", "2026-10-11", SRF + " (read date of 913)")
M(385, "913", RD_A, SRF)
M(385, "909", t5("Live referring domains", 75), T5S, circ=True)
M(385, "917", num(sr("new referring domains in September (new-and-lost report)")), SRF)
M(385, "95", num(sr("lost referring domains in September (new-and-lost report)")), SRF)
B(385, "nineteen at day 37", t5("Live referring domains", 37) == 19, 19, T5S, circ=True)
M(385, "841", 19 + 917 - 95, "arith:19 + 917 - 95")
B(385, "several hundred within three weeks", t5("Live referring domains", 60) >= 300 and 60 - 37 <= 23, t5("Live referring domains", 60), T5S, circ=True)
B(385, "roughly nine hundred by day 75", 850 <= t5("Live referring domains", 75) <= 950, t5("Live referring domains", 75), T5S, circ=True)
M(387, "61.9%", num(sr("share of those referring domains on .info").rstrip("%")), SRF)
M(387, "26.4%", num(sr("share of those referring domains on .asia").rstrip("%")), SRF)
M(387, "10.2%", num(sr("share of those referring domains on .xyz", "Ahrefs").rstrip("%")), SRF)
B(387, "10", sr("URL Rating of the linking pages") == "every linking page below 10", "every linking page below 10", SRF)
M(387, "80", RD_S, SRF)
M(387, "88%", num(sr("share of those referring domains at Authority Score 0 to 10").rstrip("%")), SRF)
B(387, "0", any(r["quantity"].endswith("Authority Score 0 to 10") for r in SRL), "0 to 10", SRF)
B(387, "10", any(r["quantity"].endswith("Authority Score 0 to 10") for r in SRL), "0 to 10", SRF)
M(387, "75%", num(sr("share of those referring domains on .xyz", "Semrush").rstrip("%")), SRF)
T6I = [(0, 15), (15, 30), (30, 37), (37, 45), (45, 60), (60, 75)]
for ln, (d0, d1) in zip(range(395, 401), T6I):
    cells = [c.strip() for c in MS[ln - 1].strip().strip("|").split("|")]
    rd0, rd1 = t5("Live referring domains", d0), t5("Live referring domains", d1)
    p0, p1 = t5("Ranking positions, all", d0), t5("Ranking positions, all", d1)
    a_, b_ = (num(x) for x in cells[1].split(" to "))
    B(ln, cells[1].split(" to ")[0], a_ == rd0, rd0, T5S + " (referring domains at the interval start)", circ=True)
    B(ln, cells[1].split(" to ")[1], b_ == rd1, rd1, T5S + " (at the interval end)", circ=True)
    M(ln, cells[2], rd1 - rd0, "arith:Table 5 referring domains, end - start")
    M(ln, cells[3], p1 - p0, "arith:Table 5 positions, end - start")
    M(ln, cells[4].split(" /")[0], (p1 - p0) / (d1 - d0), f"arith:positions gained / {d1 - d0} days")
B(402, "984", sr("ranking positions at day 6") == "984" and FIGD[6][0] == 984, 984, SRF + " and make_figs_v4.py")
B(402, "186", sr("positions 1 to 3 at day 6") == "186" and FIGD[6][1] == 186, 186, SRF + " and make_figs_v4.py")
M(402, "38,801", num(sr("ranking positions at day 67")), SRF + " and make_figs_v4.py")
M(402, "6,942", num(sr("positions 1 to 3 at day 67")), SRF + " and make_figs_v4.py")
p75, p37, p45 = t5("Ranking positions, all", 75), t5("Ranking positions, all", 37), t5("Ranking positions, all", 45)
M(404, "43,302", p75, T5S, circ=True)
M(404, "15,830", p37, T5S, circ=True)
M(404, "36.6%", 100 * p37 / p75, "arith:15,830 / 43,302")
M(404, "27,472", p75 - p37, "arith:43,302 - 15,830")
M(404, "63.4%", 100 * (p75 - p37) / p75, "arith")
B(404, "an eight-day interval", 45 - 37 == 8, 8, "arith:day 37 to day 45")
M(404, "53.1%", 100 * (p75 - p45) / p75, "arith:(43,302 - 20,326) / 43,302")
M(404, "63.4%", 100 * (p75 - p37) / p75, "arith")
a75, a30, a45 = t5("AI answers citing the section", 75), t5("AI answers citing the section", 30), t5("AI answers citing the section", 45)
M(404, "56.9%", 100 * (a75 - a45) / a75, "arith:(14,823 - 6,390) / 14,823")
M(404, "74.9%", 100 * (a75 - a30) / a75, "arith:(14,823 - 3,725) / 14,823")
M(406, "15,830", p37, T5S, circ=True)
M(406, "1,874", t5("Positions 1–3", 37), T5S, circ=True)
B(406, "nineteen referring domains, a count unchanged for the preceding week", t5("Live referring domains", 30) == t5("Live referring domains", 37) == 19 and 37 - 30 == 7, "19 at day 30 and day 37", T5S, circ=True)
rates = [(t5("Ranking positions, all", b) - t5("Ranking positions, all", a)) / (b - a) for a, b in T6I]
M(410, "768", rates[1], "arith:Table 6")
M(410, "37%", 100 * (round(rates[1]) / round(rates[3]) - 1), "arith:768 / 562 - 1")
M(410, "562", rates[3], "arith:Table 6")
M(410, "132", rates[2], "arith:Table 6")
B(410, "that baseline sits at the series minimum", min(rates) == rates[2], round(min(rates)), "arith:Table 6")
B(410, "all six intervals", len(rates) == 6, 6, "Table 6")
M(410, "441", t5("Pages holding a position", 77), T5S, circ=True)

# ================================================================================================ Section 11 to 15
sec("11 Cost")
CR(424, "3", "author's reconstruction from unreleased project records", None, "≈ 3 person-weeks")
CR(425, "2", "author's reconstruction from unreleased project records", None, "≈ 2 person-weeks")
CR(426, "0", "author's reconstruction", None, "≈ 0 marginal production cost")
CR(427, "0", "author's reconstruction", None, "editorial and link acquisition 0")
CR(428, "6,000", "author's reconstruction", None, "≈ USD 6,000 / year")
B(439, "of the thirteen demand-surface types", len(re.findall(r'\("([^"]+)", (?:False|True|"run")\)', sh("make_fig0.py"))) == 13, 13, "data:make_fig0.py (13 surfaces)")
CR(439, "four of the thirteen surface types", "the ufi repository's example is not in the bundle", None, "synthetic records in the released example")
sec("12 Threats")
B(446, "65", day(65) == date(2026, 9, 29), day(65), "arith:day 65 = 29 September, the notice date of Section 4.3")
B(446, "75", day(75) == date(2026, 10, 9), day(75), "arith:day 75 = 9 October, the last daily read")
M(446, "2.94", T3V["July"][2] / T3V["July"][0], "arith:Table 3")
M(446, "1.34", T3V["October"][2] / T3V["October"][0], "arith:Table 3")
M(446, "77", (date(2026, 10, 11) - D0).days, "arith")
B(448, "about two in three correct, half for single-word labels", 0.6 <= pa2[0] / pa2[1] <= 0.7 and 0.45 <= SW2 <= 0.55, (pa2[0] / pa2[1], SW2), RERUN_R2)
M(452, "53.1%", 100 * (p75 - p45) / p75, "arith")
M(452, "63.4%", 100 * (p75 - p37) / p75, "arith")
M(452, "77", (date(2026, 10, 11) - D0).days, "arith")
sec("13 What would test")
M(460, "1.2", min(hubs) / top_code, SRF)
M(460, "2.0", max(hubs) / top_code, SRF)
CR(462, "924", "the ufi repository (examples/nanp/out/) is not in the bundle")
CR(462, "66", "the ufi repository is not in the bundle")
CR(464, "0.5", "parameter lock in the ufi repository, not in the bundle", None, "alpha")
CR(464, "0.5", "parameter lock in the ufi repository", None, "beta")
CR(464, "0.85", "parameter lock in the ufi repository", None, "damping")
M(466, "372", sum(r["group"] == "geographic, in service" for r in CODES), CODEF)
LAB(466, "02", "path 02_DESIGN")
# 971,506 is checked from the OpenTimestamps proof by ots_parse.py (outputs/ots_parse.txt)
OTS = rd("ots_parse.txt") if (OUT / "ots_parse.txt").exists() else ""
ots_heights = sorted(set(re.findall(r"BitcoinBlockHeaderAttestation height (\d+)", OTS)))
B(466, "971,506", ots_heights == ["971506"], ots_heights, "data:protocols_manifest.txt.ots and framework_test_r1 .ots proofs, parsed (ots_parse.py)")
BEX = rd("block_explorer_check.txt") if (OUT / "block_explorer_check.txt").exists() else ""
bex_ok = "2026-10-15T04:05" in BEX and "merkle root equals the one the proofs commit to: True" in BEX
B(466, "04", bex_ok, "2026-10-15T04:05:42Z", "external:block explorer (blockstream.info), the check protocols/README.md prescribes", "merkle root equal to the proofs'")
B(466, "05", bex_ok, "2026-10-15T04:05:42Z", "external:block explorer (blockstream.info)")
B(472, "10,000", "the 10,000 highest-volume prompts" in DESIGN, "A1", "data:design file")
B(472, "10,000", "the 10,000 highest-volume prompts" in DESIGN, "A1", "data:design file", "first 10,000 rows in default order (A2/A3)")
B(472, "14", "after 14 of 88 exports" in DESIGN, "14 of 88", "data:design file")
B(472, "88", "after 14 of 88 exports" in DESIGN, "14 of 88", "data:design file")
B(472, "44,463", "44,463 rows" in DESIGN, "44,463 rows", "data:design file", "the paper says answers, the design file says rows")
B(472, "two small sectors, Energy and Utilities", "Energy, all eight surfaces, and Utilities, six surfaces" in DESIGN, "Energy 8 + Utilities 6 = 14", "data:design file")
for tok, note in (("21%", "Gottfried & Park 2025"), ("37%", "Gottfried & Park 2025"), ("18%", "Gottfried & Park 2025"), ("26%", "Gottfried & Park 2025")):
    EXT(482, tok, note)
B(482, "over the same four years", 2025 - 2021 == 4, 4, "arith:2021 to 2025")
EXT(486, "93.9", "Costco Wholesale Corporation 2026 press release")
EXT(486, "11.2%", "Costco Wholesale Corporation 2026 press release")
M(486, "109", len(COMP), "data:companies CSV")
sec("14 Reproducibility")
CR(490, "22", "the ufi repository's commit history is not in the bundle")
CR(490, "21", "the ufi repository's commit history is not in the bundle")
CR(490, "924", "the ufi repository is not in the bundle")
M(492, "109", len(COMP), "data:companies CSV")
M(494, "14,823", t5("AI answers citing the section", 75), T5S, circ=True)
B(494, "9", day(75) == date(2026, 10, 9), day(75), "arith:day 75 = 9 October")
M(494, "17,206", t5("AI answers citing the section", 77), T5S, circ=True)
B(494, "11", day(77) == date(2026, 10, 11), day(77), "arith:day 77")
M(494, "17,400", num(sr("stored AI answers citing the section")), SRF + "; also ahrefs_ai_responses = 17400 in the prefix CSV")
B(494, "12", sr_date("stored AI answers citing the section") == "2026-10-12" and A[AC]["ahrefs_ai_responses"] == "17400", "2026-10-12", SRF + " and prefix CSV")
B(494, "13", sr_date("October run-rate visits on the Semrush re-read (worldwide)") == "2026-10-13", "2026-10-13", SRF)
W13, U13 = num(sr("October run-rate visits on the Semrush re-read (worldwide)")), num(sr("October run-rate visits on the Semrush re-read (US)"))
M(494, "3%", 100 * statistics.mean([W13 / T2V["October"][2] - 1, U13 / T2V["October"][1] - 1]), "arith:re-read / Table 2 October (2.8% worldwide, 3.1% US)", approx=0.1)
M(494, "1,910,867", W13, SRF)
M(494, "1,659,636", U13, SRF)
M(510, "109", len(COMP), "data:companies CSV")
RUN3 = sh("08_REVIEW/reproduction_v5.2_run3_2026-10-15/reproduction_report.md")
B(512, "1,696", "1,696 quoted values were checked: 1,555 MATCH, 7 MISMATCH, 134 CANNOT RUN" in RUN3, "1,696 / 1,555 / 7 / 134", "data:08_REVIEW/reproduction_v5.2_run3_2026-10-15/reproduction_report.md (in the bundle)")
B(512, "1,555", "1,555 MATCH" in RUN3, 1555, "data:run-3 report")
B(512, "seven differed", "7 MISMATCH" in RUN3, 7, "data:run-3 report")
B(512, "134", "134 CANNOT RUN" in RUN3, 134, "data:run-3 report")
LAB(512, "+0.19", "the superseded value, quoted as the error")
LAB(512, "+0.29", "the superseded value, quoted as the error")
M(512, "+0.18", M2P["rho_mentioned"], RERUN_M2)
M(512, "+0.28", M2P["ci_all"][1], RERUN_M2)
B(512, "three times in clean folders", len([d for d in (PRI / "08_REVIEW").iterdir() if d.is_dir()]) == 3, 3, "data:08_REVIEW folders in the bundle")
B(512, "15", all(d.name.endswith("2026-10-15") for d in (PRI / "08_REVIEW").iterdir() if d.is_dir()), "2026-10-15", "data:08_REVIEW folder names")
sec("15 Conclusion")
M(520, "7.5", min(R_US_AW.values()), T2S)
M(520, "27.1", max(R_US_AW.values()), T2S)
M(520, "8.6", min(R_WW.values()), T2S)
M(520, "29.9", max(R_WW.values()), T2S)
M(520, "2.7", (T2V["September"][0] / T2V["August"][0]) / (T2V["September"][1] / T2V["August"][1]), RERUN_I)
B(520, "about its referring domains by a factor of eleven", round(RD_A / RD_S) == 11, RD_A / RD_S, "arith:913 / 80")
B(520, "from one fifth to seven times", abs(min(vr.values()) - 0.2) < 0.01 and round(max(vr.values())) == 7, (min(vr.values()), max(vr.values())), RERUN_A)
M(520, "60", conc, RERUN_A)
M(520, "66", conc + disc, RERUN_A)
CR(522, "37,193", WITHHELD_REV, (SUP_TEXT, SUPS))
M(522, "+0.47", M2P["rho_branch_modal"], RERUN_M2)
M(522, "+0.75", M2P["rho_branch_split"], RERUN_M2)
M(522, "+0.18", M2P["rho_mentioned"], RERUN_M2)
M(522, "+0.27", M2P["rho_all"], RERUN_M2)
CR(522, "one in seven unhappy reviews", WITHHELD_REV, (abs(NEG_W / NEG_N - 1 / 7) < 0.01, AROS + " (924 / 6,620 = 1 in 7.2)"))
CR(522, "11", WITHHELD_REV, (g(SUP, r"distinct such labels: (\d+)"), SUPS))
CR(522, "622", WITHHELD_REV, (g(SUP, r"their monthly volume: (\d+)"), SUPS))
M(524, "21%", 100 * med(G_ALL), RERUN_S7)
M(524, "0.6%", 100 * SURF_MED["copilot"], RERUN_S7)
M(524, "9.2%", 100 * SURF_MED["gemini"], RERUN_S7)
B(524, "higher on every Google view than on every other surface in every sector", EVERY == 11, EVERY, RERUN_S7)
B(524, "two of four predictions written before collection failed", P1_BOTH < 6 and len(P3) < 6, "P1, P3", RERUN_S7)
M(526, "15,830", t5("Ranking positions, all", 37), T5S, circ=True)
B(526, "nineteen referring domains at day 37", t5("Live referring domains", 37) == 19, 19, T5S, circ=True)
M(526, "17,206", t5("AI answers citing the section", 77), T5S, circ=True)

# ================================================================================================ Appendices
sec("Appendix A")
M(701, "381", len(CODES), CODEF)
LAB(701, "290", "superseded value")
LAB(701, "88", "superseded 88-code control")
M(701, "9.2x", MENT10 / AI_ANS, "arith:158,100 / 17,206")
M(701, "78", sum(DAYS_LIVE.values()), "arith")
B(701, "0", 77 - 0 + 1 == sum(DAYS_LIVE.values()), "days 0 to 77 = 78 days", "arith:6 + 31 + 30 + 11 = 78")
M(701, "77", (date(2026, 10, 11) - D0).days, "arith")
M(701, "5.2", math.sqrt(R_US_AW["August"]), "arith")
M(701, "27.1x", R_US_AW["August"], T2S)
LAB(701, "13", "superseded reading of the bound")
LAB(701, "−0.09", "the stale figure value")
M(701, "−0.11", rho_age, RERUN_A)
B(701, "a stale copy of Figure 5 ... was replaced", "Spearman ρ = −0.11" in FIGS4, "make_figs_v4.py prints ρ = −0.11 in Figure 5's title", "data:make_figs_v4.py")
M(703, "+0.47", M2P["rho_branch_modal"], RERUN_M2)
M(703, "+0.75", M2P["rho_branch_split"], RERUN_M2)
CR(703, "+0.78", WITHHELD_REV + " (superseded computation)", (g(ARO, r"branch-level Spearman: rho=([+\-][\d.]+)"), AROS))
CR(703, "11", WITHHELD_REV, (g(SUP, r"distinct such labels: (\d+)"), SUPS))
M(705, "456", len(MATCHED), RERUN_ST)
M(705, "459", sum(int(r["n_tools"]) >= 1 for r in WORKS), "data:vendor_reliance_works.csv rows naming a tool, duplicates included", "the superseded count")
B(705, "three works were counted twice", len(WORKS) - len(UNIQ) == 3, len(WORKS) - len(UNIQ), RERUN_ST + " (3 duplicates dropped)")
M(705, "+0.18", M2P["rho_mentioned"], RERUN_M2)
LAB(705, "+0.19", "superseded value")
B(705, "+0.185", "Spearman over mentioned labels only (published): +0.185" in M2O, "+0.185", RERUN_M2 + " (printed value)")
sec("Appendix B")
for tok, note in (("12,000", "Wulczyn et al. 2016"), ("3.2", "Wulczyn et al. 2016"), ("80%", "Piccardi et al. 2018")):
    EXT(712, tok, note)
CR(718, "0.22", "rank normalization in the ufi implementation, not in the bundle", None, "consistent with (rank - 1)/(n - 1) and shared ranks: (15.5 - 1) / 65 = 0.223")
CR(718, "30", "ufi example, not in the bundle")
CR(718, "66", "ufi example, not in the bundle")
for tok in ("1.0", "0.5", "0", "1.0", "0.5", "0", "0"):
    LAB(720, tok, "rubric grade (specification)")
CR(722, "0.5", "parameter lock in the ufi repository")
CR(722, "0.5", "parameter lock in the ufi repository")
CR(722, "0.85", "parameter lock in the ufi repository")
CR(724, "0.8", "ufi example, not in the bundle", None, "rel term correlates with degree at roughly 0.8")
CR(726, "4", "ufi example, not in the bundle", None, "schema pass rate 4/5")
CR(726, "5", "ufi example, not in the bundle", None, "schema pass rate 4/5")
CR(726, "70.4%", "ufi example, not in the bundle")
sec("Appendix C, Table C1")
C1KEYS = ["share_video_community", "share_reference", "share_news", "share_government", "share_report_brands", "share_other_web"]
for ln, p in zip(range(734, 742), SURF):
    cells = [c.strip() for c in MS[ln - 1].strip().strip("|").split("|")][1:]
    for cell, k in zip(cells, C1KEYS):
        m = re.match(r"([\d.]+)% \(([\d.]+)–([\d.]+)\)", cell)
        vals = [TS[(s, p)][k] for s in SECTORS]
        M(ln, m.group(1) + "%", 100 * med(vals), RERUN_S7 + " (Appendix C1)")
        M(ln, m.group(2), 100 * min(vals), RERUN_S7 + " (Appendix C1, min)")
        M(ln, m.group(3), 100 * max(vals), RERUN_S7 + " (Appendix C1, max)")
sec("Appendix C, Table C2")
C2S = {"Information Technology": "xlk", "Health Care": "xlv", "Financials": "xlf", "Consumer Discretionary": "xly", "Communication Services": "xlc",
       "Industrials": "xli", "Consumer Staples": "xlp", "Energy": "xle", "Utilities": "xlu", "Real Estate": "xlre", "Materials": "xlb"}
for ln in range(747, 758):
    cells = [c.strip() for c in MS[ln - 1].strip().strip("|").split("|")]
    s_ = C2S[cells[0]]
    for cell, p in zip(cells[1:], SURF):
        M(ln, cell, int(CELLS[(s_, p)]["cited_in_sum"]) / 1000, RERUN_S7 + " (Appendix C2, thousands)")
sec("Appendix C, Tables C3 and C4")
c3c4_ms = "\n".join(MS[762:791])
c3c4_tb = TBO.split("\n\nGoogle surfaces")[0].strip()
B(763, "Tables C3 and C4 (every cell)", c3c4_tb.replace("\n\n", "\n") == "\n".join(x for x in MS[762:791] if x.strip() and not x.startswith("*Table C4")),
  "identical to make_tables_sector_surface.py output", "rerun:make_tables_sector_surface.py (byte-identical to shipped output)")
M(793, "38", g(TBO, r"top source youtube.com or google.com in (\d+) of"), "rerun:make_tables_sector_surface.py")
M(793, "44", g(TBO, r"youtube.com or google.com in \d+ of (\d+) cells"), "rerun:make_tables_sector_surface.py")
CS_ROW = [c.strip() for c in next(x for x in TBO.splitlines() if x.startswith("| Communication Services |") and x.count("|") > 5).strip("|").split("|")]
B(793, "four of them Alphabet's own properties in Communication Services", [c.endswith("†") for c in CS_ROW[1:5]] == [True] * 4,
  "C3 marks youtube†, youtube†, google†, google† and go† (ChatGPT) in Communication Services", "rerun:make_tables_sector_surface.py", "4 of the 5 marked C3 cells are on Google views")
M(793, "15", g(TBO, r"wikipedia.org or reddit.com in (\d+) of 22"), "rerun:make_tables_sector_surface.py")
M(793, "22", 2 * len(SECTORS), "rerun:make_tables_sector_surface.py (Perplexity and Gemini x 11 sectors)")
M(793, "4", g(TBO, r"a \.gov domain in (\d+) of 11"), "rerun:make_tables_sector_surface.py")
M(793, "11", len(SECTORS), "rerun:make_tables_sector_surface.py")
M(793, "6", g(TBO, r"walmart.com or amazon.com in (\d+) of 11"), "rerun:make_tables_sector_surface.py")
M(793, "11", len(SECTORS), "rerun:make_tables_sector_surface.py")
sec("Appendix D")
B(797, "a benchmark of seven tasks", len(re.findall(r"^\*\*Task [A-Z]\.", sh("UFI_Metrics_and_Evaluation_Protocol_v1.0.md"), re.M)) == 7,
  len(re.findall(r"^\*\*Task [A-Z]\.", sh("UFI_Metrics_and_Evaluation_Protocol_v1.0.md"), re.M)), "data:UFI_Metrics_and_Evaluation_Protocol_v1.0.md")
B(803, "14", "the 14 October 2026 read" in sh("stakes/vendor_reliance.py"), "14 October 2026", "data:vendor_reliance.py docstring")
M(803, "120", len(IDS), RERUN_ST)
M(803, "456", len(MATCHED), RERUN_ST)
M(803, "82%", 100 * SC1[0] / len(IDS), RERUN_ST, "82.5% exactly; see Section 1")
M(803, "87%", 100 * SC2[0] / len(IDS), RERUN_ST)
M(803, "0.63", KS[0], RERUN_ST)
M(803, "87%", 100 * SC1[1] / SC1[0], RERUN_ST)
M(803, "88%", 100 * SC2[1] / SC2[0], RERUN_ST)
for tok, v in (("7.5x", min(R_US_AW.values())), ("27.1x", max(R_US_AW.values())), ("8.6x", min(R_WW.values())), ("29.9x", max(R_WW.values())),
               ("9.2x", min(R_USUS.values())), ("33.3x", max(R_USUS.values()))):
    M(804, tok, v, T2S)
M(805, "0.95", (T2V["August"][0] / T2V["July"][0]) / (T2V["August"][1] / T2V["July"][1]), RERUN_I)
M(805, "2.66", (T2V["September"][0] / T2V["August"][0]) / (T2V["September"][1] / T2V["August"][1]), RERUN_I)
M(805, "1.37", (T2V["October"][0] / T2V["September"][0]) / (T2V["October"][1] / T2V["September"][1]), RERUN_I)
M(806, "5.2", math.sqrt(R_US_AW["August"]), "arith")
M(806, "27.1x", R_US_AW["August"], T2S)
M(807, "35%", 100 * math.log(k_us) / math.log(v_us), RERUN_I)
M(807, "54%", 100 * math.log(k_ww) / math.log(v_ww), RERUN_I)
M(808, "0.20x", min(vr.values()), RERUN_A)
M(808, "7.24x", max(vr.values()), RERUN_A)
M(808, "8.89x", max(vm.values()), RERUN_A)
M(808, "1.01", med_vr, RERUN_A)
M(809, "−0.11", rho_age, RERUN_A)
M(809, "−0.64", fisher[0], RERUN_A)
M(809, "+0.49", fisher[1], RERUN_A)
M(809, "0.73", g(ANA, r"permutation p = ([\d.]+)"), RERUN_A)
M(810, "+0.94", rho_v.statistic, RERUN_A)
M(810, "+0.82", tau_v.statistic, RERUN_A)
M(810, "60", conc, RERUN_A)
M(810, "66", conc + disc, RERUN_A)
M(810, "51", sum(bands["beyond"]), RERUN_I)
M(810, "51", len(bands["beyond"]), RERUN_I)
LAB(810, "3x", "band threshold")
M(810, "9", sum(bands["within"]), RERUN_I)
M(810, "15", len(bands["within"]), RERUN_I)
M(811, "1.13", gmean, RERUN_I)
M(811, "3.1", gsd, RERUN_I)
M(812, "12.6%", 100 * min(T3V[m][0] / T3V[m][1] for m in MONTHS), "arith:Table 3")
M(812, "20.0%", 100 * max(T3V[m][0] / T3V[m][1] for m in MONTHS), "arith:Table 3")
CR(813, "55.6%", WITHHELD_REV, (100 * ARO_LINKED / SUP_TEXT, AROS))
CR(813, "2.25", WITHHELD_REV, (RLS_LINKS / ARO_LINKED, "shipped outputs"))
M(814, "+0.18", M2P["rho_mentioned"], RERUN_M2)
M(814, "+0.27", M2P["rho_all"], RERUN_M2)
M(815, "+0.47", M2P["rho_branch_modal"], RERUN_M2)
M(815, "+0.75", M2P["rho_branch_split"], RERUN_M2)
CR(816, "14.0%", WITHHELD_REV, (100 * NEG_W / NEG_N, AROS))
CR(816, "1.9%", WITHHELD_REV, (100 * FIVE_K / FIVE_N, SUPS))
M(817, "65%", 100 * pa2[0] / pa2[1], RERUN_R2)
M(817, "67%", 100 * pa1[0] / pa1[1], RERUN_R2)
M(817, "0.90", kA[0], RERUN_R2)
M(817, "50%", 100 * statistics.mean([SW1, SW2]), RERUN_R2 + " (50.0% and 48.0%; 'about 50%')", approx=0.05)
M(817, "95%", 100 * min(MW1, MW2), RERUN_R2)
M(817, "96%", 100 * max(MW1, MW2), RERUN_R2)
M(818, "83%", 100 * pb2[0] / pb2[1], RERUN_R2)
M(818, "85%", 100 * pb1[0] / pb1[1], RERUN_R2)
M(818, "0.93", kB[0], RERUN_R2)
M(818, "90%", 100 * statistics.mean([inst1, inst2]), RERUN_R2 + " (90.5% and 89.2%; 'about 90%')", approx=0.05)
M(820, "21.3%", 100 * med(G_ALL), RERUN_S7)
M(820, "17.2", g(S7O, r"Google ([\d.]+)% to [\d.]+%; other four"), RERUN_S7)
M(820, "26.7", g(S7O, r"Google [\d.]+% to ([\d.]+)%; other four"), RERUN_S7)
M(820, "2.1%", 100 * med(C_ALL), RERUN_S7)
M(820, "1.7", g(S7O, r"other four ([\d.]+)% to [\d.]+%\n"), RERUN_S7)
M(820, "2.7", g(S7O, r"other four [\d.]+% to ([\d.]+)%\n"), RERUN_S7)
M(821, "11", EVERY, RERUN_S7)
M(821, "11", len(SECTORS), RERUN_S7)
M(822, "0.36", min(JAC[p] for p in GOOGLE), RERUN_S7)
M(822, "0.40", max(JAC[p] for p in GOOGLE), RERUN_S7)
M(822, "0.08", min(JAC[p] for p in CHAT), RERUN_S7)
M(822, "0.23", max(JAC[p] for p in CHAT), RERUN_S7)
M(823, "77%", 100 * VAR["share_video_community"][0], RERUN_S7)
M(823, "14%", 100 * VAR["share_video_community"][1], RERUN_S7)
B(824, "one held, one in direction, two failed", P1_BOTH < 6 and all(v >= 6 for v in P2.values()) and len(P3) < 6, "P2 held; P4 direction; P1, P3 failed", RERUN_S7)
CR(825, "4", "ufi example, not in the bundle", None, "4/5")
CR(825, "5", "ufi example, not in the bundle", None, "4/5")
CR(826, "70.4%", "ufi example, not in the bundle")


# ---- tokens found by the coverage check (coverage.py) that need a claim or an explicit label
sec("coverage additions")
LAB(247, "0.5", "power-analysis parameter (a correlation of 0.5)")
LAB(287, "1,000", "threshold (under 1,000 monthly searches)")
for ln in (309, 325, 730, 761, 819):
    B(ln, "1,000", all(int(CELLS[(s, p)]["export_rows"]) == 1000 for s in SECTORS for p in SURF), 1000, "data:cross_sector_cells.csv export_rows (the export cap)")
for t in ("21", "100", "21", "100"):
    LAB(351, t, "row name 21-100")
B(355, "37", day(37) == date(2026, 9, 1), day(37), "arith:37 days after 26 July")
LAB(369, "214", "area code used as a name")
LAB(369, "214", "area code used as a name")
M(402, "77", (date(2026, 10, 11) - D0).days, "arith:day 0 to day 77")
LAB(402, "1", "band 1-3")
LAB(402, "3", "band 1-3")
B(502, "13", sr(FIVE) == "13 to 83", "13 to 83", SRF)
B(502, "83", sr(FIVE) == "13 to 83", "13 to 83", SRF)
LAB(502, "6", "Condition 6")
LAB(512, "10", "folder name date")
LAB(700, "2", "version v2.2")
for _ in range(4):
    LAB(716, "1", "formula constant")
LAB(718, "1", "formula constant")
for t in ("1", "3", "4", "6"):
    LAB(112, t, "condition numbers")
LAB(135, "12", "export dates of an unreleased file")
LAB(143, "10", "read dates")
LAB(175, "10", "read dates")
for ln in (309, 730, 761):
    LAB(ln, "12", "collection dates")
LAB(265, "2", "formula constant")

# ================================================================================================ output
cols = ["id", "line", "section", "token", "status", "computed", "basis", "note", "category", "circular", "context"]
with (OUT / "numbers_table.tsv").open("w", encoding="utf-8", newline="") as f:
    w = csv.writer(f, delimiter="\t", lineterminator="\n")
    w.writerow(cols)
    for i, r in enumerate(ROWS, 1):
        w.writerow([i] + [r[c] for c in cols[1:]])
from collections import Counter
st_ = Counter(r["status"] for r in ROWS)
print(f"claims registered {len(ROWS)}: " + ", ".join(f"{k} {v}" for k, v in sorted(st_.items())))
study = [r for r in ROWS if r["category"] == "study"]
print(f"study numbers {len(study)}: " + ", ".join(f"{k} {v}" for k, v in sorted(Counter(r['status'] for r in study).items())))
print(f"  of the matches, {sum(r['circular'] for r in study if r['status'] == 'MATCH')} rest only on a record transcribed from the manuscript itself")
dis = [r for r in ROWS if r["status"] == "CANNOT RUN" and "DISAGREES" in r["note"]]
print(f"CANNOT RUN values that disagree with a shipped output: {len(dis)}")
for r in ROWS:
    if r["status"] == "MISMATCH" or (r["status"] == "CANNOT RUN" and "DISAGREES" in r["note"]):
        print(f"  line {r['line']} [{r['section']}] {r['token']!r}: {r['status']} computed {r['computed']} ({r['basis']}) {r['note']}")
