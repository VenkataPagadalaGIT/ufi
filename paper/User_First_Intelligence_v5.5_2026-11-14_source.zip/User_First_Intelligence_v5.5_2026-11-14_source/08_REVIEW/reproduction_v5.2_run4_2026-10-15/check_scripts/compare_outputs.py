"""Byte-for-byte comparison of rerun outputs with the outputs shipped in the bundle.

Usage: python3 -E -P compare_outputs.py <pristine bundle root> <run bundle root> <review outputs dir>
Prints one line per pair: IDENTICAL, or DIFFERENT with the first differing line of each.
Also lists every file in the run copy that differs from or is absent in the pristine copy.
"""
import hashlib
import sys
from pathlib import Path

PRI, RUN, OUT = (Path(a) for a in sys.argv[1:4])

PAIRS = [  # (rerun stdout in OUT, shipped output in the pristine bundle)
    ("m2_from_counts_stdout.txt", "review_demand/m2_from_counts_output.txt"),
    ("r2_link_check_stdout.txt", "review_demand/r2_link_check_output.txt"),
    ("vendor_reliance_offline_stdout.txt", "stakes/vendor_reliance_output.txt"),
    ("stakes_screen_check_stdout.txt", "stakes/stakes_screen_check_output.txt"),
    ("section7_from_aggregates_stdout.txt", "ai_citation_cross_sector/scripts/section7_from_aggregates_output.txt"),
    ("make_tables_sector_surface_stdout.txt", "ai_citation_cross_sector/scripts/make_tables_sector_surface_output.txt"),
    ("instrument_extra_stdout.txt", "instrument_divergence_extra/instrument_extra_output.txt"),
]
FILE_PAIRS = [  # (file regenerated in the run copy, shipped file in the pristine copy)
    ("instrument_divergence_extra/instrument_series_table2_visits_by_month.csv",) * 2,
    ("instrument_divergence_extra/instrument_series_table3_ai_overview_citation_by_month.csv",) * 2,
    ("instrument_divergence_extra/instrument_series_table5_checkpoints.csv",) * 2,
    ("instrument_divergence_extra/instrument_series_table6_intervals.csv",) * 2,
    ("protocols/instrument_series_table2_visits_by_month.csv", "instrument_divergence_extra/instrument_series_table2_visits_by_month.csv"),
    ("protocols/instrument_series_table3_ai_overview_citation_by_month.csv", "instrument_divergence_extra/instrument_series_table3_ai_overview_citation_by_month.csv"),
    ("protocols/instrument_series_table5_checkpoints.csv", "instrument_divergence_extra/instrument_series_table5_checkpoints.csv"),
    ("protocols/instrument_series_table6_intervals.csv", "instrument_divergence_extra/instrument_series_table6_intervals.csv"),
]


def first_diff(a: bytes, b: bytes):
    la, lb = a.decode("utf-8", "replace").splitlines(), b.decode("utf-8", "replace").splitlines()
    for i, (x, y) in enumerate(zip(la, lb)):
        if x != y:
            return f"line {i + 1}: rerun {x!r} | shipped {y!r}"
    return f"line counts differ: rerun {len(la)}, shipped {len(lb)}" if len(la) != len(lb) else "same lines, bytes differ (line endings or trailing newline)"


def report(label, new: Path, old: Path):
    if not new.exists():
        print(f"{label}: MISSING rerun file {new}")
        return
    if not old.exists():
        print(f"{label}: no shipped file {old}")
        return
    a, b = new.read_bytes(), old.read_bytes()
    print(f"{label}: {'IDENTICAL' if a == b else 'DIFFERENT, ' + first_diff(a, b)} ({len(a)} vs {len(b)} bytes)")


print("== Script stdout against the shipped output file")
for o, s in PAIRS:
    report(o, OUT / o, PRI / s)
print("\n== Files the scripts rewrote, against the shipped files")
for n, s in FILE_PAIRS:
    report(n, RUN / n, PRI / s)

print("\n== Every file in the run copy that is new or differs from the pristine copy")
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
for p in sorted(RUN.rglob("*")):
    if p.is_file():
        rel = p.relative_to(RUN)
        q = PRI / rel
        if not q.exists():
            print(f"  NEW       {rel}")
        elif digest(p) != digest(q):
            print(f"  CHANGED   {rel}")
for q in sorted(PRI.rglob("*")):
    if q.is_file() and not (RUN / q.relative_to(PRI)).exists():
        print(f"  REMOVED   {q.relative_to(PRI)}")
