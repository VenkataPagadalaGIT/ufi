"""Parse OpenTimestamps proofs offline (no ots client, no network).

For each proof: checks that the digest it commits to equals the SHA-256 of the file beside it, replays every operation
of the timestamp tree from that digest, and prints each attestation with the message it commits to. For a Bitcoin
block-header attestation the message is the block's merkle root in internal byte order; block explorers and `ots info`
show it byte-reversed, which is printed too.

Usage: python3 -E -P ots_parse.py <proof.ots> [<proof.ots> ...]   (the stamped file is the proof name without .ots)
"""
import hashlib
import sys
from pathlib import Path

MAGIC = b"\x00OpenTimestamps\x00\x00Proof\x00\xbf\x89\xe2\xe8\x84\xe8\x92\x94"
UNARY = {0x08: ("sha256", lambda m: hashlib.sha256(m).digest()), 0x02: ("sha1", lambda m: hashlib.sha1(m).digest()),
         0x03: ("ripemd160", lambda m: hashlib.new("ripemd160", m).digest()), 0xf7: ("reverse", lambda m: m[::-1]),
         0xf3: ("hexlify", lambda m: m.hex().encode())}
BINARY = {0xf0: "append", 0xf1: "prepend"}
ATTEST = {bytes.fromhex("0588960d73d71901"): "BitcoinBlockHeaderAttestation", bytes.fromhex("83dfe30d2ef90c8e"): "PendingAttestation",
          bytes.fromhex("06869a0d73d71b45"): "LitecoinBlockHeaderAttestation"}


class Reader:
    def __init__(self, b):
        self.b, self.i = b, 0

    def byte(self):
        x = self.b[self.i]
        self.i += 1
        return x

    def bytes_(self, n):
        x = self.b[self.i:self.i + n]
        if len(x) != n:
            raise ValueError("truncated proof")
        self.i += n
        return x

    def varuint(self):
        v, shift = 0, 0
        while True:
            x = self.byte()
            v |= (x & 0x7f) << shift
            if not x & 0x80:
                return v
            shift += 7

    def varbytes(self):
        return self.bytes_(self.varuint())


def walk(r, msg, depth, out):
    def one(tag):
        if tag == 0x00:
            kind = r.bytes_(8)
            payload = r.varbytes()
            name = ATTEST.get(kind, "UnknownAttestation " + kind.hex())
            if name == "BitcoinBlockHeaderAttestation":
                height = Reader(payload).varuint()
                out.append(f"{'  ' * depth}{name} height {height}; message (internal order) {msg.hex()}; "
                           f"merkle root as explorers show it {msg[::-1].hex()}")
            elif name == "PendingAttestation":
                out.append(f"{'  ' * depth}{name} uri {Reader(payload).varbytes().decode(errors='replace')}")
            else:
                out.append(f"{'  ' * depth}{name} payload {payload.hex()}")
        elif tag in UNARY:
            walk(r, UNARY[tag][1](msg), depth + 1, out)
        elif tag in BINARY:
            arg = r.varbytes()
            walk(r, (msg + arg) if tag == 0xf0 else (arg + msg), depth + 1, out)
        else:
            raise ValueError(f"unknown tag {tag:#x}")

    tag = r.byte()
    while tag == 0xff:
        one(r.byte())
        tag = r.byte()
    one(tag)


for name in sys.argv[1:]:
    proof = Path(name)
    stamped = proof.with_suffix("")
    b = proof.read_bytes()
    print(f"== {proof.name} ({len(b)} bytes)")
    if not b.startswith(MAGIC):
        print("  not an OpenTimestamps proof (bad magic)")
        continue
    r = Reader(b)
    r.i = len(MAGIC)
    version = r.varuint()
    op = r.byte()
    if op != 0x08:
        print(f"  file hash op {op:#x}, not SHA-256")
        continue
    digest = r.bytes_(32)
    actual = hashlib.sha256(stamped.read_bytes()).hexdigest() if stamped.exists() else None
    print(f"  version {version}; committed SHA-256 {digest.hex()}")
    print(f"  SHA-256 of {stamped.name}: {actual}  -> {'MATCH' if actual == digest.hex() else 'MISMATCH'}")
    out = []
    walk(r, digest, 1, out)
    print("  attestations:")
    for line in out:
        print("  " + line)
    print(f"  bytes parsed {r.i} of {len(b)}")
