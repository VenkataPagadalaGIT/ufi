"""Compare regenerated figures with the figures shipped in the bundle.

Usage: python3 -E -P compare_figures.py <pristine bundle root> <run bundle root>
For each figure: raw bytes; PDF bytes with only the /CreationDate value masked; PNG pixels (shape, share of pixels
that differ, largest channel difference).
"""
import re
import sys
from pathlib import Path

import matplotlib.image as mpimg
import numpy as np

PRI, RUN = Path(sys.argv[1]), Path(sys.argv[2])
FIGS = [  # (regenerated file stem in the run copy, shipped stem in the pristine copy, script)
    ("fig0_framework", "fig0_framework", "make_fig0.py"),
    ("fig1_divergence", "fig1_divergence", "make_figs_v4.py"),
    ("fig2_aio", "fig2_aio", "make_figs_v4.py"),
    ("fig3_refdomains", "fig3_refdomains", "make_figs_v4.py"),
    ("fig4_prefixes", "fig4_prefixes", "make_figs_v4.py"),
    ("fig5_cited", "fig5_cited", "make_figs_v4.py"),
    ("fig6_positions", "fig6_positions", "make_figs_v4.py"),
    ("ai_citation_cross_sector/scripts/fig10_sources", "fig10_sources", "make_fig_sources.py"),
]
CD = re.compile(rb"/CreationDate \(D:[^)]*\)")

for new, old, script in FIGS:
    line = [f"{old} ({script}):"]
    pn, po = RUN / f"{new}.pdf", PRI / f"{old}.pdf"
    a, b = pn.read_bytes(), po.read_bytes()
    if a == b:
        line.append("PDF bytes IDENTICAL")
    else:
        ma, mb = CD.sub(b"/CreationDate ()", a), CD.sub(b"/CreationDate ()", b)
        dates = (CD.findall(a)[:1], CD.findall(b)[:1])
        line.append(f"PDF bytes differ ({len(a)} vs {len(b)}); with /CreationDate masked: "
                    f"{'IDENTICAL' if ma == mb else 'STILL DIFFERENT'} (dates {dates[0]} vs {dates[1]})")
    gn, go = RUN / f"{new}.png", PRI / f"{old}.png"
    c, d = gn.read_bytes(), go.read_bytes()
    if c == d:
        line.append("PNG bytes IDENTICAL")
    else:
        x, y = mpimg.imread(gn), mpimg.imread(go)
        if x.shape != y.shape:
            line.append(f"PNG differ: shapes {x.shape} vs {y.shape}")
        else:
            diff = np.abs(x.astype(float) - y.astype(float))
            line.append(f"PNG bytes differ; pixels: {np.mean(diff.max(axis=-1) > 0):.4%} differ, max channel diff {diff.max():.4f}")
    print(" ".join(line))
