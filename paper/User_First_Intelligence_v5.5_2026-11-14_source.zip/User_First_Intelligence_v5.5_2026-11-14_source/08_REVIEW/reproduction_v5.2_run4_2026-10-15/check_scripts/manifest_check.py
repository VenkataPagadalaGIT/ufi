"""Compare each SHA-256 in protocols/protocols_manifest.txt with the released file of that name.

The manifest lists project paths; protocols/README.md says every listed file is released in protocols/ under the same
name, except analyze.py (released in data/) and instrument_extra.py (released as protocols/instrument_extra_as_stamped.py).
The script also hashes the current instrument_extra.py to show that it, as the README says, differs from the stamp.

Usage: python3 -E -P manifest_check.py <bundle root>
"""
import hashlib
import re
import sys
from pathlib import Path

ROOT = Path(sys.argv[1])
MAP = {"analyze.py": ROOT / "data/analyze.py", "instrument_extra.py": ROOT / "protocols/instrument_extra_as_stamped.py"}
text = (ROOT / "protocols/protocols_manifest.txt").read_text()
rows = re.findall(r"^([0-9a-f]{64})  (\S+)$", text, re.M)
print(f"manifest lines with a SHA-256: {len(rows)}")
ok = 0
for digest, path in rows:
    name = Path(path).name
    f = MAP.get(name, ROOT / "protocols" / name)
    actual = hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None
    good = actual == digest
    ok += good
    print(f"  {'MATCH   ' if good else 'MISMATCH'} {path} -> {f.relative_to(ROOT)}"
          + ("" if good else f" (manifest {digest}, file {actual})"))
print(f"{ok} of {len(rows)} match")
cur = hashlib.sha256((ROOT / "instrument_divergence_extra/instrument_extra.py").read_bytes()).hexdigest()
stamped = dict((Path(p).name, d) for d, p in rows)["instrument_extra.py"]
print(f"current instrument_divergence_extra/instrument_extra.py {cur}: {'equal to' if cur == stamped else 'differs from'} the stamped digest (README: it gained sections 7 to 9)")
listed = {Path(p).name for _, p in rows} | {"instrument_extra_as_stamped.py"}
others = sorted(p.name for p in (ROOT / "protocols").iterdir() if p.is_file() and p.name not in listed)
print(f"other files in protocols/: {others}")
