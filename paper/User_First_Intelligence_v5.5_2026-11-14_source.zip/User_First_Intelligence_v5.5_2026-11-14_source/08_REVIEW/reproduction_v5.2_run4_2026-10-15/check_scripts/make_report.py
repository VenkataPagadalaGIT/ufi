"""Write reproduction_report.md from the saved outputs of this reproduction (run 4).

Usage: python3 -E -P make_report.py <review folder> <manuscript_v50.md>
"""
import csv
import re
import sys
from collections import Counter, OrderedDict
from pathlib import Path

RV = Path(sys.argv[1])
O = RV / "outputs"
MSL = Path(sys.argv[2]).read_text(encoding="utf-8").split("\n")  # manuscript_v50.md: sections are taken from its headings
HEADS = [(i + 1, x.lstrip("#").strip()) for i, x in enumerate(MSL) if x.startswith("## ") or x.startswith("### ")]


def section_of(line):
    h = [t for n, t in HEADS if n <= int(line)]
    return h[-1] if h else "Front matter"


def rd(name):
    return (O / name).read_text(encoding="utf-8")


rows = list(csv.DictReader((O / "numbers_table.tsv").open(encoding="utf-8"), delimiter="\t"))
for r in rows:
    r["section"] = section_of(r["line"])
TOK = re.compile(r"[−+\-]?\d[\d,]*(?:\.\d+)?(?:%|x|K|M)?")
study = [r for r in rows if r["category"] == "study"]
ext = [r for r in rows if r["category"] == "external"]
lab = [r for r in rows if r["category"] == "label"]
st = Counter(r["status"] for r in study)
circ = sum(int(r["circular"]) for r in study if r["status"] == "MATCH")
agree = sum(1 for r in study if r["status"] == "CANNOT RUN" and r["note"].startswith("agrees"))
numeric = sum(1 for r in study if TOK.fullmatch(r["token"]))
cov = rd("coverage.txt").splitlines()[0]
covlab = rd("coverage.txt").splitlines()[1]
env = rd("environment.txt").strip().splitlines()


def clean(s, n=None):
    s = (s or "").replace("|", "/").replace("\n", " ").replace("—", ", ")
    return s if n is None or len(s) <= n else s[: n - 3] + "..."


def short_basis(b):
    b = b.replace("rerun:", "rerun ").replace("data:", "data ").replace("arith:", "arith ").replace("external:", "external ")
    return clean(b, 90)


by_sec = OrderedDict()
for r in study:
    by_sec.setdefault(r["section"], Counter())[r["status"]] += 1

cr_reason = Counter()
for r in study:
    if r["status"] == "CANNOT RUN":
        b = r["basis"]
        key = ("licensed review export (Section 6) not in the bundle" if b.startswith("licensed review export") else
               "raw Brand Radar exports (Section 7) not in the bundle" if b.startswith("raw Brand Radar") else
               "ufi repository or package (lock, example, commits) not in the bundle" if "ufi" in b else
               "author's reconstruction or unreleased records (cost, export log, page fetch, registry)" )
        cr_reason[key] += 1

L = []
w = L.append
w("# Independent reproduction, run 4: User First Intelligence, manuscript v5.2 source bundle")
w("")
w("Reproducer: an AI agent (Claude Code), working from the released bundle only, in a fresh temporary folder, on 15 October 2026. "
  "It did not use the three earlier reproductions included in the bundle; it searched the third one's report only for the totals that Section 14 of the paper quotes from it.")
w("")
w("## 1. Environment and bundle")
w("")
w("- **Environment:** macOS 15.4.1 (arm64); Python 3.13.2 (Homebrew) with numpy 2.4.1, scipy 1.17.1, pandas 3.0.0, matplotlib 3.11.1 (pyparsing 3.3.2) and openpyxl 3.1.5; "
  "tectonic 0.17.0; pandoc 3.9.0.2; poppler 26.02 (pdftotext, pdfinfo, pdffonts); no XeLaTeX; no OpenTimestamps client (`outputs/environment.txt`).")
w("- **Bundle:** `06_MANUSCRIPT/User_First_Intelligence_v5.2_2026-10-15_source.zip`, SHA-256 "
  "`1dcc4128398d5d7bb7912f492bb201310fa276dac0ae0103b98e7ce50c2c14f4` (equal to the value given by the caller; checked on the original and on the copy), 305 files.")
w("- **Working folders** (fresh, created with `mktemp -d` in the session scratchpad, nothing else copied in): `pristine/` (never touched; its 305 SHA-256 digests were identical before and after all runs), "
  "`run/` (analysis and figure scripts), `build/` (a second fresh extraction for the paper build, so the shipped figures were used), `editrun/` (edit scripts), `mutant/` (the checker's self-test). "
  "Every script with a relative upward path resolves inside that folder, so no file of the author's project could be read.")
w("- **Scope:** this report covers the bundle as named. During the run another process changed the project's working copy: `06_MANUSCRIPT/src/manuscript_v50.md` "
  "(03:37:45, 9 lines added and 5 removed, by a new `edit_v52t.py` that adds two citations), with new files in `06_MANUSCRIPT/measurements/`. The bundle was not changed "
  "(SHA-256 rechecked at the end) and this reproduction wrote nothing outside its own folder, so the working manuscript now differs from the one reproduced here.")
w("- The `ufi` package (0.2.0) happens to be installed on this machine. It is not in the bundle. The three review scripts import it before they stop on the missing licensed export; no result here depends on it.")
w("")
w("## 2. Results at a glance")
w("")
w(f"- **Scripts:** 15 of the bundle's 52 paper scripts ran as documented (plus the tectonic compile); 1 failed (`protocols/reread_compare.py`); 36 cannot run "
  "(8 need withheld data or a live API, 28 edit scripts need the v4.8 manuscript, which is not in the bundle). Every one of the 7 shipped script outputs reproduced byte for byte, "
  "and every data file a script rewrote came back byte-identical.")
w(f"- **Numbers:** {len(study):,} numbers the paper quotes from its own study were checked ({numeric:,} numeric tokens and {len(study) - numeric} counts or facts stated in words): "
  f"**{st['MATCH']:,} MATCH, {st.get('MISMATCH', 0)} MISMATCH, {st['CANNOT RUN']} CANNOT RUN**. Of the {st['CANNOT RUN']} that cannot be run, {agree} agree with the output the author shipped for the script that prints them; "
  f"the other {st['CANNOT RUN'] - agree} have no shipped record at all. {len(ext)} figures cited from other works were not checked (listed in section 8.4).")
nums_ = [int(x.replace(",", "")) for x in re.findall(r"[\d,]+", cov)]
w(f"- **Coverage:** of the {nums_[0]:,} numeric tokens outside the reference list, {nums_[1]:,} are checked and {nums_[2]:,} are excluded as labels (section, table and figure numbers, years, dates and the like) by stated rules; {'none' if nums_[3] == 0 else nums_[3]} is left uncovered (section 8.1).")
w("- **Build:** `build_tex.py` regenerates `paper.tex` byte for byte; tectonic 0.17 compiles it to a 34-page PDF with no errors, no missing glyphs and no undefined references; "
  "`build_docx.sh` writes a DOCX with all nine figures. Neither built file is missing any number of the source.")
w("- **Figures:** every figure script runs; all eight regenerated PNGs are byte-identical to the shipped ones and the PDFs differ only in their `/CreationDate`. "
  "Figure 6, which needs the licensed export, cannot be redrawn; its shipped file prints +0.18 and +0.75, as the text does. The hard-coded figure data agree with the released data (14 of 14 checks).")
w("- **Stamped protocol:** all 7 SHA-256 digests in `protocols/protocols_manifest.txt` match the released files. Its OpenTimestamps proof commits to the manifest and attests Bitcoin block 971,506, "
  "whose merkle root (7bdc6025...59a3) and time (04:05:42 UTC, 15 October 2026) a block explorer confirms.")
w("")
w("## 3. Problems found, most important first")
w("")
w("1. **`protocols/reread_compare.py` cannot run from the bundle (FAILED).** It reads `HERE.parents[1] / \"03_DATA/instrument_divergence_ahrefs_prefixes_2026-10-12.csv\"`, a project path two folders above "
  "`protocols/`; the bundle holds the same data as `data/ahrefs_prefixes_2026-10-12.csv`. Run as its docstring says (`python3 reread_compare.py`), it stops with `FileNotFoundError` before it reads the sheet. "
  "This is the comparer for the third-party re-read of Table 4 and the day-37 row that Section 14 calls the one check that would change the paper's standing, and its SHA-256 is fixed by the stamped manifest, "
  "so it cannot be corrected without breaking the stamp. A re-reader using the bundle must recreate the project layout (`03_DATA/` with the project file names) two levels above `protocols/`. "
  "The protocol's analysis step has a milder form of the same issue: it says to run `analyze.py` and `instrument_extra.py` \"on the new files unchanged\", but both read fixed file names "
  "(`ahrefs_prefixes_2026-10-12.csv`, `semrush_prefixes_2026-10-12.csv`), so new reads must be saved under the old names.")
w("2. **Rounding at exact halves follows no single rule (observation, not a mismatch).** Five quoted values sit exactly on a rounding boundary (table in section 8.3). Each quoted value is a valid rounding of the exact value, "
  "but round-half-up would change four of them (82% to 83%, 5.2 to 5.3, 405.6 to 405.7, 2.1 to 2.2), round-half-even one (2.1 to 2.2), and Python's float formatting, which the scripts use, one (+0.74 to +0.73). "
  "The paper takes Python's printed value in four places and rounds the printed 0.735 up by hand in the fifth.")
w(f"3. **{circ} of the matches cannot fail.** The monthly and checkpoint series (Tables 2, 3 and 5, and the text that quotes them) are released only as CSVs that `instrument_extra.py` writes by parsing the manuscript's own tables, "
  "and as constants in the figure scripts, typed from the same tables. The paper says so (Section 14). Their arithmetic (ratios, derived row, intervals, rates) is a real check; the read values themselves are not.")
w(f"4. **{st['CANNOT RUN']} values rest on inputs the bundle does not contain** (section 8.2): the licensed review export (Section 6), the raw Brand Radar exports (Section 7 sensitivities, the pilot, company dominance), "
  "the `ufi` repository (the parameter lock, the example's 924 queries and 4/5 and 70.4%, the commit counts) and the author's own records (cost, export times, page fetches). "
  "This is disclosed. Where the author shipped the output of the script that prints a value, the paper agrees with it in every case.")
w("5. **Small documentation gaps.** `README.txt` says the edit scripts run from `edit_v49*.py` to `edit_v52m.py`; the bundle also holds `edit_v52n.py` to `edit_v52s.py`. "
  "The `ai_citation_cross_sector` README says the three raw-export scripts \"stop with a message\"; `cross_sector_sensitivity2.py` first prints its variance block (identical to the shipped output's first 760 bytes) and then stops. "
  "The proof `framework_test_r1/framework_retro_test_381_amendment_2026-10-15.md.ots` carries only pending calendar attestations, so the amendment's date cannot yet be checked against Bitcoin from the bundle (the paper says only that it was \"stamped separately\").")
w("")
w("## 4. Scripts")
w("")
w("Each script was run from its own folder exactly as its README or docstring says, from `run/` (or `build/`), with the bundle's files only. \"Byte-identical\" means `cmp` found no difference with the output file shipped beside the script.")
w("")
w("| # | Script | How run (folder: command) | Status | Comparison with the shipped output |")
w("|---|---|---|---|---|")
S = [
    ("data/analyze.py", "data/: `python3 analyze.py`", "RAN", "No shipped output file. Every printed value equals an independent recomputation from the two prefix CSVs."),
    ("instrument_divergence_extra/instrument_extra.py", "instrument_divergence_extra/: `python3 instrument_extra.py`", "RAN", "stdout byte-identical to `instrument_extra_output.txt` (4,840 bytes); the four `instrument_series_table*.csv` it rewrites are byte-identical."),
    ("protocols/instrument_extra_as_stamped.py", "protocols/: `python3 instrument_extra_as_stamped.py`", "RAN", "No shipped output. Its stdout equals sections 1 to 6 of the current script's, as `protocols/README.md` says; the four CSVs it writes into `protocols/` equal the released ones."),
    ("protocols/reread_compare.py", "protocols/: `python3 reread_compare.py`", "FAILED", "`FileNotFoundError: .../run/03_DATA/instrument_divergence_ahrefs_prefixes_2026-10-12.csv` (project path, not in the bundle). Its input, a filled re-read sheet, does not exist yet either (`reread_sheet.csv` is empty by design)."),
    ("review_demand/m2_from_counts.py", "review_demand/: `python3 m2_from_counts.py`", "RAN", "Byte-identical (2,465 bytes)."),
    ("review_demand/r2_link_check.py", "review_demand/: `python3 r2_link_check.py`", "RAN", "Byte-identical (1,997 bytes). It reads two population sizes from the shipped outputs of scripts that cannot run (46,517 links; 924 of 6,620)."),
    ("review_demand/analyze_reviews.py", "review_demand/: `python3 analyze_reviews.py`", "CANNOT RUN", "Stops: `FileNotFoundError: Telecom_reviews_and_responses.xlsx` (licensed DataForSEO export, withheld; also needs `Telecom_classification.xlsx`). Shipped output used only to note agreement."),
    ("review_demand/supplement_r10.py", "review_demand/: `python3 supplement_r10.py`", "CANNOT RUN", "Same missing export, and `Telecom_keywords_full.csv.gz` and a private carrier-name file."),
    ("review_demand/r2_link_sample.py", "review_demand/: `python3 r2_link_sample.py`", "CANNOT RUN", "Same missing export."),
    ("review_demand/make_fig_reviews_v50.py", "review_demand/: `python3 make_fig_reviews_v50.py`", "CANNOT RUN", "Stops: `out/label_demand_aggregates.csv` not found (written from the licensed export)."),
    ("stakes/vendor_reliance.py", "stakes/: `python3 vendor_reliance.py --offline` (as the README says)", "RAN", "Byte-identical (470 bytes). The online mode, which queries OpenAlex and rewrites the list, was not run."),
    ("stakes/stakes_screen_check.py", "stakes/: `python3 stakes_screen_check.py`", "RAN", "Byte-identical (600 bytes)."),
    ("stakes/stakes_screen_sample.py", "not run", "CANNOT RUN", "Needs the live OpenAlex API for titles and abstracts (not released) and writes outside the bundle. Its seeded draw (`random.Random(20261015).sample` of the 456 works), replayed offline, gives exactly the 120 ids in `stakes_screen_ids.csv`."),
    ("ai_citation_cross_sector/scripts/section7_from_aggregates.py", "scripts/: `python3 section7_from_aggregates.py`", "RAN", "Byte-identical (6,873 bytes)."),
    ("ai_citation_cross_sector/scripts/make_tables_sector_surface.py", "scripts/: `python3 make_tables_sector_surface.py`", "RAN", "Byte-identical (3,007 bytes); Tables C3 and C4 of the paper equal its output cell for cell."),
    ("ai_citation_cross_sector/scripts/make_fig_sources.py", "scripts/: `python3 make_fig_sources.py`", "RAN", "Writes `fig10_sources.png` (byte-identical to the shipped one) and `.pdf` (identical except `/CreationDate`) beside itself."),
    ("ai_citation_cross_sector/scripts/make_brand_radar_urls.py", "scripts/: `python3 make_brand_radar_urls.py`", "RAN", "Rewrites `design/cross_sector_report_urls.json` byte-identical; stdout (11 sectors, 9 companies in XLC) has no shipped copy."),
    ("ai_citation_cross_sector/scripts/cross_sector.py", "scripts/: `python3 cross_sector.py`", "CANNOT RUN", "Stops with its own message: the raw Brand Radar exports are not released."),
    ("ai_citation_cross_sector/scripts/cross_sector_sensitivity.py", "scripts/: `python3 cross_sector_sensitivity.py`", "CANNOT RUN", "Same message."),
    ("ai_citation_cross_sector/scripts/cross_sector_sensitivity2.py", "scripts/: `python3 cross_sector_sensitivity2.py`", "CANNOT RUN", "Prints its first block from the aggregates (byte-identical to the first 760 bytes of the shipped output), then stops on the raw exports."),
    ("make_figs_v4.py", "top folder: `python3 make_figs_v4.py`", "RAN", "Six figures: PNG byte-identical; PDF identical except `/CreationDate`."),
    ("make_fig0.py", "top folder: `python3 make_fig0.py`", "RAN", "PNG byte-identical; PDF identical except `/CreationDate`."),
    ("build_tex.py", "`build/` copy, top folder: `python3 build_tex.py`", "RAN", "`build/paper.tex` byte-identical to the shipped `paper.tex` (199,354 bytes)."),
    ("(tectonic on build/paper.tex)", "build/: `tectonic --keep-logs paper.tex`", "RAN", "34 pages, exit 0; only box warnings (5 overfull, at most 3.98 pt; 77 underfull). No shipped PDF to compare."),
    ("build_docx.sh", "top folder: `./build_docx.sh`", "RAN", "`build/paper.docx` with 9 embedded figures; no shipped DOCX to compare."),
    ("edit_v49.py, edit_v49_r9.py, edit_v49_r9b.py, edit_v49_r9c.py, edit_v50.py (5)", "`editrun/` copy: `python3 <script>`, in order", "CANNOT RUN", "Read `manuscript_v49.md` (the v4.8 to v5.0 source), which is not in the bundle: `FileNotFoundError`."),
    ("edit_v50b.py to edit_v52s.py (23)", "same", "CANNOT RUN", "Each refuses (`REFUSE: 0 matches` or `already applied`) and leaves `manuscript_v50.md` unchanged, as expected for a record of edits already applied; the chain cannot be replayed without the v4.8 source."),
    ("08_REVIEW/*/checks/* (28 files)", "not run", "not a paper script", "Tooling of the three earlier reproductions; some carry absolute paths of their own work folders. Out of scope."),
]
for i, (a, b, c, d) in enumerate(S, 1):
    w(f"| {i} | `{a}` | {b} | {c} | {d} |" if " " not in a else f"| {i} | {a} | {b} | {c} | {d} |")
w("")
w("Tally: RAN 15 scripts (rows 1 to 3, 5, 6, 11, 12, 14 to 17, 21 to 23, 25) plus the compile; FAILED 1; CANNOT RUN 36 (8 data or API, 28 edit scripts).")
w("")
w("## 5. Build and figures")
w("")
w("- `paper.tex`: regenerated byte for byte by `build_tex.py` (pandoc 3.9.0.2). The compile used tectonic because XeLaTeX is not installed; `build_tex.py` itself falls back to tectonic for its table-measuring pass, which succeeded.")
mvb = rd("md_vs_built.txt")
pdf_n = re.search(r"PDF: (\d+) numeric tokens in the source, (\d+) in the built text; (\d+) distinct", mvb).groups()
docx_n = re.search(r"DOCX: (\d+) numeric tokens in the source, (\d+) in the built text; (\d+) distinct", mvb).groups()
w("- Built PDF: 34 pages, letter size, all 20 fonts embedded (`outputs/built_paper_pdffonts.txt`), no `Missing character` lines, no undefined references or citations. "
  f"Every number in the source occurs at least as often in the built PDF's text ({int(pdf_n[1]):,} numeric tokens against {int(pdf_n[0]):,}; the surplus is page numbers, running heads and figure text; "
  f"{pdf_n[2]} numbers short) and in the DOCX's text ({int(docx_n[1]):,} against {int(docx_n[0]):,}; {docx_n[2]} short) (`outputs/md_vs_built.txt`).")
w("- Figure comparison (`outputs/compare_figures.txt`):")
for x in rd("compare_figures.txt").splitlines():
    m = re.match(r"(\S+) \((\S+)\): (.*)", x)
    if m:
        w(f"  - `{m.group(1)}` ({m.group(2)}): " + ("PNG byte-identical; PDF identical except the creation timestamp" if "IDENTICAL" in x and "PNG bytes IDENTICAL" in x and "masked: IDENTICAL" in x else clean(m.group(3), 200)))
w("  - `fig9_reviews` (Figure 6): not regenerable (`make_fig_reviews_v50.py` needs the licensed export); its shipped PDF prints \"1,008 taxonomy labels, Spearman +0.18\" and \"(nine of 17), Spearman +0.75\", as the paper does.")
w("- Figure data against released data (`outputs/figure_check.txt`): " + rd("figure_check.txt").strip().splitlines()[-1] + ".")
w("")
w("## 6. Stamped protocol and timestamps")
w("")
for x in rd("manifest_check.txt").strip().splitlines():
    w("    " + x)
w("")
w("OpenTimestamps proofs, parsed offline (`check_scripts/ots_parse.py`, `outputs/ots_parse.txt`):")
w("")
w("- `protocols/protocols_manifest.txt.ots`: commits to SHA-256 `e52d0565...d67a`, which is the manifest's; one Bitcoin attestation, block 971,506, merkle root (explorer byte order) "
  "`7bdc60257b41068f09d1157f28005268d7430ba65143d263243a5d46a24659a3`, plus four pending calendar attestations.")
w("- `framework_test_r1/framework_retro_test_381_manifest.txt.ots`: commits to the manifest's SHA-256; same block and merkle root.")
w("- `framework_test_r1/framework_retro_test_381_amendment_2026-10-15.md.ots`: commits to the amendment's SHA-256; pending calendar attestations only.")
bx = rd("block_explorer_check.txt")
w("- Block explorer (blockstream.info, the check `protocols/README.md` prescribes): block 971,506 has merkle root " + re.search(r"merkle_root (\w+)", bx).group(1)
  + (" (equal to the proofs')" if "proofs commit to: True" in bx else " (DIFFERENT from the proofs')") + " and block time " + re.search(r"(\d{4}-\d\d-\d\dT[\d:]+)", bx).group(1).replace("T", " ") + " UTC (`outputs/block_explorer_check.txt`).")
w("- The manifests were written at 03:45 and 03:48 UTC; the block was mined at 04:05:42 UTC. The Study R1 files themselves are held back, so only the manifest can be checked.")
w("")
w("## 7. Other checks")
w("")
w("- `arxiv_abstract.txt`: 1,907 characters, under the 1,920 that `README.txt` states; every number in it appears in the manuscript's abstract (it omits −0.11 and the read date).")
w("- `UFI_Metrics_and_Evaluation_Protocol_v1.0.pdf` against its `.md`: the same numbers (the one apparent difference, a DOI `30.1-2.81`, is a line-break hyphen that text extraction drops).")
w("- `ai_citation_cross_sector/README.md`'s note on YouTube's rank where it is not cited (825 for Utilities on ChatGPT): confirmed in the aggregates; the ChatGPT and Copilot medians (151, 161) are the same under either reading.")
w("- Rerun outputs written into the run copy, and nothing else: figure files, the four protocol CSVs, `fig10_sources.*` beside its script, and an empty `review_demand/out/` made by `analyze_reviews.py` before it stopped.")
w("")
w("## 8. Numbers")
w("")
w("### 8.1 Method")
w("")
w("`check_scripts/check_numbers.py` holds one entry for every number the paper quotes from its own study, line by line through the manuscript (`manuscript_v50.md`, the bundle's source of truth), "
  "including Tables 2 to 7, C1 and C2 cell by cell and counts written in words (\"nineteen\", \"one fifth\"). Each value was compared at the precision the paper prints with the most precise value available: "
  "an independent recomputation from the released data where possible (prefix CSVs, aggregates, anonymized label counts, judgment CSVs, the single-read and code-list files), the rerun script's output otherwise, "
  "and the full-precision value wherever the script's printed value ends in 5 at the next digit (`check_scripts/m2_precise.py`, `m2_boundary.py`). A value matches when it equals the full-precision value rounded half-up; "
  "a value exactly on the boundary is accepted either way and flagged. `check_scripts/coverage.py` then extracts every numeric token from the manuscript (the reference list excepted) and requires each to be checked or excluded by a stated rule:")
w("")
w("    " + cov)
w("    " + covlab)
w("")
w("The excluded tokens are section, table and figure numbers, citation years, dates and day numbers used as names, times, enumerations, confidence levels (\"95%\"), position-band names and \"S&P 500\"; "
  "`outputs/label_audit.txt` lists every date, day, band, time and enumeration exclusion for review, and none hides a quantity. "
  "The checker was tested: on known cases (`outputs/mutation_unit_test.txt`, 12 of 12) and on a copy of the manuscript with five numbers altered, all five were caught "
  "(`outputs/mutation_end_to_end.txt`: four as MISMATCH, the fifth by the coverage check).")
w("")
w("### 8.2 Tally")
w("")
w("| Section | MATCH | MISMATCH | CANNOT RUN |")
w("|---|---|---|---|")
for s_, c in by_sec.items():
    w(f"| {s_} | {c.get('MATCH', 0)} | {c.get('MISMATCH', 0)} | {c.get('CANNOT RUN', 0)} |")
w(f"| **All** | **{st['MATCH']:,}** | **{st.get('MISMATCH', 0)}** | **{st['CANNOT RUN']}** |")
w("")
w("CANNOT RUN, by missing input:")
w("")
for k, v in cr_reason.most_common():
    w(f"- {v}: {k}")
w("")
w(f"Of the {st['MATCH']:,} matches, {circ} rest only on records transcribed from the manuscript itself (problem 3).")
w("")
w("### 8.3 Values on a rounding boundary")
w("")
w("Exact values from `outputs/rounding_boundaries.txt` (computed with rational arithmetic from the released data):")
w("")
w("| Where | Exact value | Quoted | Half-up | Half-even | Python format |")
w("|---|---|---|---|---|---|")
for where, exact, quoted, hu, he, pf in (
        ("Section 1 and Table D1: screen sample using vendor figures, annotator 1 (99/120)", "82.5%", "82%", "83%", "82%", "82%"),
        ("Table 4: /device-compare/ keyword ratio (12,600 / 2,400)", "5.25", "5.2", "5.3", "5.2", "5.2"),
        ("Table C2: Information Technology, Copilot (405,650 incidences, in thousands)", "405.65", "405.6", "405.7", "405.6", "405.6"),
        ("Table C2: Real Estate, Gemini (2,150 incidences, in thousands)", "2.15", "2.1", "2.2", "2.2", "2.1"),
        ("Section 6: lower end of the multi-word branch-level interval (Sxy/sqrt(Sxx Syy) = 294/400)", "0.735", "+0.74", "0.74", "0.74", "0.73")):
    w(f"| {where} | {exact} | {quoted} | {hu} | {he} | {pf} |")
w("")
w("### 8.4 Figures cited from other works (not checked)")
w("")
w("| # | Line | Quoted | Source cited |")
w("|---|---|---|---|")
for r in ext:
    w(f"| {r['id']} | {r['line']} | {clean(r['token'])} | {clean(r['note'], 110)} |")
w("")
w("### 8.5 Every checked number")
w("")
w("Line numbers refer to `manuscript_v50.md` in the bundle; `outputs/numbers_table.tsv` has the same rows with the surrounding text. \"Obtained\" is the full-precision value in the unit the paper prints "
  "(percent values as percentages). Sources: `rerun` a script run here; `data` a released file; `arith` arithmetic on released files; `shipped` an output the author shipped for a script that cannot run.")
w("")
w("| # | Line | Section | Quoted | Status | Obtained | Source | Note |")
w("|---|---|---|---|---|---|---|---|")
for r in study:
    w(f"| {r['id']} | {r['line']} | {clean(r['section'], 28)} | {clean(r['token'], 70)} | {r['status']} | {clean(r['computed'], 40)} | {short_basis(r['basis'])} | {clean(r['note'], 110)} |")
w("")
w("### 8.6 Entries judged not to be quantitative claims")
w("")
w("| # | Line | Quoted | Why |")
w("|---|---|---|---|")
for r in lab:
    w(f"| {r['id']} | {r['line']} | {clean(r['token'], 50)} | {clean(r['note'], 80)} |")
w("")
w("## 9. Files in this folder")
w("")
w("- `check_scripts/`: `logrun.sh` (command logger), `run_one.sh` (script runner), `compare_outputs.py`, `compare_figures.py`, `check_numbers.py`, `m2_precise.py`, `m2_boundary.py`, `tokens.py`, "
  "`coverage.py`, `label_audit.py`, `ots_parse.py`, `manifest_check.py`, `figure_check.py`, `md_vs_built.py`, `make_report.py`.")
w("- `outputs/`: every script's stdout and stderr (`*_stdout.txt`, `*_stderr.txt`), `run_status.tsv`, the comparisons, `numbers_table.tsv`, the coverage and mutation tests, the OTS and block-explorer checks, "
  "SHA-256 lists of the pristine copy before and after, and `built_artifacts/` (the built `paper.pdf` and `paper.docx`).")
w("- `command_log.txt`: every command, with its exit status; reproduced below.")
w("")
w("## 10. Command log")
w("")
w("```")
w((RV / "command_log.txt").read_text(encoding="utf-8").rstrip())
w("```")
(RV / "reproduction_report.md").write_text("\n".join(L) + "\n", encoding="utf-8")
print(f"wrote reproduction_report.md: {len(L)} lines, {sum(len(x) + 1 for x in L):,} bytes; study numbers {len(study)}: {dict(st)}")
