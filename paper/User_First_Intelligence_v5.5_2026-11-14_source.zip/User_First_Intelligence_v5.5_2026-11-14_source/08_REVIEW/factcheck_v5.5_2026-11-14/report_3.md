# Fact-check report 3 of 3 (manuscript v5.5, checked 14 November 2026)

References R66 to R97 ("Rasool 2026" to "Zobel 1998"), from `worklist_3.md`, against `06_MANUSCRIPT/src/manuscript_v50.md`. This report verifies; it does not edit the manuscript.

## 1. Scope

- **Checked:** 32 reference entries (R66 to R97); 40 citing sentences (one row each below, including the narrative citation of Ripoll et al. at L89 that the extractor missed); 4 quoted strings from the two vendors' terms of service (manuscript Section 14, worklist-era L522); 3 paraphrases of Semrush knowledge-base pages (no quotation marks in the manuscript, checked against the live pages).
- **Completeness of the citing-sentence list:** a search of the manuscript body for every author name in this range found no citing sentence beyond those in the worklist plus the Ripoll sentence.
- **The manuscript changed while this check ran.** The file was modified at 16:41 on 14 November (uncommitted; 954 lines, was 952). A paragraph was inserted near L185, so every line after it moved down by two. The cited sentences themselves are unchanged. Line numbers below are the worklist's, with the current number in parentheses where it differs: L210 (212), L468 (470), L522 (524), L768 (770), L782 (784), L886 (888), L933 (935).
- **Not checked:** the manuscript's own arithmetic (for example the 12.6% to 20.0% Wilson interval at L886, which is the paper's computation, not a statement attributed to Wilson); references outside R66 to R97 that share a sentence with one of these (Keet & Ławrynowicz 2016, Hölzl et al. 2025, Alibudbud 2023, Allaham & Diakopoulos 2026 and others); the candidate-generating scripts `verify_claims.py` and `check_manuscript.py` were not run because the worklist already fixed the scope.
- **Basis of each verdict** is stated in the evidence column: full text, publisher abstract, or live web page. Where only an abstract could be opened, the row says so.

## 2. Verification table: one row per citing sentence

Verdicts: SUPPORTED, PARTLY, NOT SUPPORTED, COULD NOT VERIFY.

| # | Ref | Line | Claim attributed to the source | Verdict | Evidence (quote and where from) |
|---|---|---|---|---|---|
| 1 | R66 Rasool 2026 | L77 | On 50 open-access repositories SimilarWeb and Semrush differed significantly in level, about 4% for visits and for visitors, with Spearman 0.997 on total visits | SUPPORTED | "Semrush estimated 3.88% higher total visits ... whereas SimilarWeb reported 4.09% higher unique visitors"; "total visits (rs = 0.997)"; "50 repositories selected from OpenDOAR". Publisher abstract in the Crossref record. Full text paywalled (Emerald, HTTP 403). |
| 2 | R66 Rasool 2026 | L91 | A comparison of estimators with one another across many established sites at one time | SUPPORTED | "comparing the web analytics metrics reported by SimilarWeb and Semrush" for "50 prominent global repositories"; limitations call for "longitudinal analyses" in future work. Abstract only; the collection date is not in the abstract. |
| 3 | R67 Razniewski 2024 | L89 | Study of completeness in open-world knowledge bases | SUPPORTED | "we discuss how knowledge about completeness, recall, and negation in KBs can be expressed, extracted, and inferred". Abstract, Crossref. |
| 4 | R67 Razniewski 2024 | L768 (770) | Completeness estimators measure what a knowledge base lacks | SUPPORTED | "the first problem is arguably to know whether and where the KB is incomplete in the first place, and to which degree"; covers "the estimation of this information via statistical patterns". Abstract. The mapping to the score's coverage term is the manuscript's own. |
| 5 | R68 Razniewski 2016 | L89 | Study of completeness in open-world knowledge bases | SUPPORTED | "little is known about how much is unknown ... We envision that KBs become annotated with information about their recall on specific topics". Full text, ACL Anthology W16-1308; it has a paragraph headed "Open World Assumption". |
| 6 | R69 Redi 2020 | L89 | Gap discovery for encyclopedias | SUPPORTED | "we describe, group and classify knowledge gaps into a structured framework", from evidence of "knowledge gaps in readership, contributorship, and content of Wikimedia projects". arXiv abstract. See caveat C2. |
| 7 | R70 Ren 2014 | L67 | Competency questions written against an ontology | SUPPORTED | "we employ the linguistic notion of presupposition to describe the ontology requirements implied by competency questions, and show that these requirements can be tested automatically". Abstract, Springer page. |
| 8 | R71 Reyes-Lillo 2023 | L77 | Domain-authority scores of Moz, Semrush and Ahrefs compared with one another | SUPPORTED | "the domain authority scores provided by three leading platforms ...: Moz's Domain Authority, Semrush's Authority Score, and Ahrefs' Domain Rating". Abstract, journal page. |
| 9 | R72 Rijo 2026a | L468 (470) | Google has served altered result pages to suspected rank trackers since September 2026, social and forum sites replacing tracked ones; 8.0% of one tracker's pages since 13 September | SUPPORTED | "Nozzle ... counted 8.0% of the pages it collected since September 13 as "poisoned," against 0.17% before"; findings listed include "social sites and forums fill the gap". Live page, 14 Nov 2026. |
| 10 | R73 Rijo 2026b | L468 (470) | 5% to 20% by Ahrefs' account, depending on the provider; Ahrefs cleaning up past results; Semrush dating the problem to late summer | SUPPORTED | "put the share of affected results at between 5% and 20%, depending on the data provider"; "cleaning up past results that may have been affected"; "Semrush's "since late summer"". Live page. See caveat C6. |
| 11 | R74 Ripoll 2025 | L89 | Gives the most recent typology of content gaps for a collaborative knowledge base | PARTLY | Supported: "We propose a typology of gaps based on prior research" for Wikidata, "a collaborative knowledge graph" (arXiv abstract; Section 4, "Content gap typology"). Not supported: "the most recent"; the source does not say it and cannot establish it. |
| 12 | R75 Romero Ramos 2026 | L81 | A scoping review of 23 studies, mostly preprints, maps how presence and citation are measured | SUPPORTED | "Twenty-three primary studies were included (2023-2026), mostly preprints"; aim of "mapping how the emerging literature ... measures the presence, visibility, and citation of sources and brands". Abstract, Crossref and journal page. |
| 13 | R76 Scheitle 2018 | L77 | Major top-site lists disagree on most of their entries and churn by up to half of their domains a day | SUPPORTED | "low intersections between various lists (<30%)"; "revealing daily churn of up to 50% of domains". Full text, arXiv:1805.11506v2, Section 1. |
| 14 | R77 Schultheiß 2023 | L87 | Studies of search increasingly sample their queries, and the queries' volumes, from keyword research tools | PARTLY | Supported: the paper develops "an approach (query sampler) to sample queries from commercial search engines, using keyword research tools" with query volume, and notes "Other studies use keyword research tools, such as Google Keyword Planner." Not supported: "increasingly". The source says "query sets are developed rather unsystematically". Full text, Europe PMC PMC10280501. |
| 15 | R77 Schultheiß 2023 | L91 | Keyword tools as a source of queries and volumes | SUPPORTED | "generate large numbers of queries related to a given topic and derive information on how often each keyword is searched for, that is, the query volume". Abstract. |
| 16 | R78 Semrush n.d.-a | L768 (770) | Competitor gap analysis lists the keywords competitors rank for and a site does not | SUPPORTED | "You will be able to see the keywords that your competitors are ranking for that you're not." Live page, 14 Nov 2026. |
| 17 | R79 Semrush n.d.-b | L141 | Semrush describes its figure as the estimated number of visitors a domain receives from unpaid search results each month | SUPPORTED | "Organic search traffic is the estimated number of visitors the domain receives from unpaid search results each month." Live page, 14 Nov 2026. The paraphrase is word for word apart from "a" for "the". |
| 18 | R80 Semrush n.d.-c | L141 | Computed for its domain rankings from the click-through rate at the domain's positions and each keyword's monthly volume | SUPPORTED | "This is calculated by multiplying the average click-through rate (CTR) for the domain's positions by the monthly search volume of each keyword." Live page (definition of SE Traffic in the Semrush Rank article). |
| 19 | R81 Shao 2024 | L89 | Gap discovery for encyclopedias | NOT SUPPORTED | The source is about writing articles, not finding gaps: "We study how to apply large language models to write grounded and organized long-form articles from scratch, with comparable breadth and depth to Wikipedia pages." Full text, ACL Anthology 2024.naacl-long.347. |
| 20 | R82 Soulo 2022 | L77 | 1,635 sites against Google Search Console; median deviation 49.5% (Ahrefs) and 68.4% (Semrush); correlation 0.76 and 0.74 | SUPPORTED | "the median deviation turned out to be 49.52%"; "for SEMrush, and it turned out to be 68.36%"; "correlated with that of Ahrefs' at 0.76 (Pearson's)"; "As for SEMRush, theirs was 0.74". Live page. Rounding is correct. |
| 21 | R83 Taylor 1968 | L85 | The gap between the unit a user has in mind and the unit a retrieval system indexes is old ground | SUPPORTED | "At the fourth level the question is recast in anticipation of what the files can deliver. The searcher must think in terms of the organization of particular files and of the discrete packages available". Full text, p. 182. |
| 22 | R84 Thelwall 2008 | L91 | Treats search-engine hit counts as an instrument whose settings, access dates and handling of crawlers and redirects must be reported | PARTLY | Supported: hit counts treated as research data to be validated: "quantitative results from the three search engines are mostly consistent but with unexpected types of inconsistency that users should be aware of" (abstract). Not found: any statement that settings or access dates must be reported; nearest is "search engine algorithms change frequently and so it is not known for how long the results will be valid" (author's preprint). Crawlers and redirects are not discussed. |
| 23 | R84 Thelwall 2008 | L933 (935) | The design of comparing engines on one query set | SUPPORTED | "we compare the applications programming interfaces of Google, Yahoo!, and Live Search for 1,587 single word searches". Abstract, Crossref. |
| 24 | R85 Tinuiti 2026 | L81 | Social sources 31% of Perplexity's citations against about 7% of ChatGPT's, in nine categories it chose, January 2026 | SUPPORTED | "Perplexity stands out ... with 31% of all January citations coming from social media"; "nearly 7% of all ChatGPT citations were attributed to social media in January"; "The nine categories tracked are apparel, beauty, ...". Live page. |
| 25 | R86 Vállez 2020 | L77 | SEO tools used to compare the visibility of university library sites with that of their universities | SUPPORTED | "explores whether a correlation exists between the web visibility of libraries and of their respective universities ... a search engine optimization (SEO) tool called Sistrix Toolbox was used". Abstract (Semantic Scholar record of the DOI). |
| 26 | R87 Vaughan 2013 | L77 | Traffic-ranking services compared as proxies for organizational performance | SUPPORTED | "collected their Web traffic data from three sources: Alexa Internet, Google Trends for Websites, and Compete"; "compared their usefulness. We found that Alexa Internet outperformed the others." Abstract (RePEc record). |
| 27 | R88 Webber 2009 | L79 | The bias a pooled universe imposes on a new system can be estimated and adjusted | SUPPORTED | "we propose to estimate the degree of bias against an unpooled system, and to adjust the system's score accordingly". Abstract (OpenAlex record of the DOI). |
| 28 | R89 White 2015 | L85 | People phrase questions differently from queries | SUPPORTED | "While the average length of keyword queries with a question-answering intent is 3.80 words, questions averaged 7.39 words"; in about 70% of cases a question intent "is formulated as a keyword query". Full text, pp. 135-136. |
| 29 | R90 Wilson 1927 | L210 (212) | The interval used is Wilson's | SUPPORTED | The paper derives the interval p = (p0 + t/2)/(1 + t) ± sqrt(p0 q0 t + t²/4)/(1 + t), with t = λ²/n. Pages 209 to 210, read as page images of the JSTOR scan. |
| 30 | R90 Wilson 1927 | L886 (888) | The interval used is Wilson's | SUPPORTED | As row 29. The 12.6% to 20.0% values are the manuscript's own arithmetic and were not recomputed here. |
| 31 | R91 Wiśniewski 2019 | L69 | Competency questions as questions over the ontology, compiled to SPARQL along property paths | SUPPORTED | "a set of 234 CQs and their translations to SPARQL-OWL" (arXiv v1 abstract); published abstract: "234 competency questions and their SPARQL-OWL queries". See caveat C3. |
| 32 | R91 Wiśniewski 2019 | L782 (784) | Test-driven ontology development tests a question against the ontology's vocabulary and separately against its instances | PARTLY | Supported (vocabulary half): "131 out of 234 competency questions can be translated ... The reason why some CQs are not translated is due to missing vocabulary in the ontology". Not found (instances half): the source sets an instance-level question aside ("is a instance-level question and thus we did not translate it") and names test-driven development only in related work. arXiv v1 full text and published abstract. |
| 33 | R92 Wulczyn 2016 | L89 | Gap discovery for encyclopedias | SUPPORTED | "an approach to filling gaps in article coverage across different Wikipedia editions ... identifying missing articles, ranking the missing articles according to their importance". Abstract. |
| 34 | R92 Wulczyn 2016 | L768 (770) | Ranks missing articles by importance; controlled experiment with 12,000 French Wikipedia editors; recommending an article raised its chance of creation by a factor of 3.2 | SUPPORTED | "a controlled experiment involving 12,000 French Wikipedia editors ... recommending articles increases their chance of being created by a factor of 3.2". Abstract; same in full text (arXiv:1604.03235). |
| 35 | R93 Xu 2026 | L81 | Audit of 55,393 queries; nearly 30% of the domains cited by AI Overviews did not appear on the first page shown with them | SUPPORTED | "issuing 55,393 trending queries"; "29.8% of AIO reference domains do not appear anywhere on the corresponding first page". arXiv v2 full text. |
| 36 | R94 Yang 2025 | L22 | Which sources AI answer engines cite has been audited on public-interest, news and real search queries | PARTLY | Supported: an audit of cited sources across providers on real usage: "examine the citation patterns of AI search systems in real-world usage scenarios". Not supported if "news" is the query type meant for this study: the queries were unrestricted arena conversations; "news" is the kind of source ("Among the over 366,000 citations ..., 9% reference news sources"). Full text. |
| 37 | R94 Yang 2025 | L81 | OpenAI, Perplexity and Google models on 366,000 citations from a public comparison arena, which cite distinct news sources | SUPPORTED | "models across three major providers: OpenAI, Perplexity, and Google. Among the over 366,000 citations ..."; "models from different providers cite distinct news sources". Abstract. Exact count in the full text: 366,087. |
| 38 | R95 Yext 2025 | L81 | Brand-managed sources are 86% of the citations of three engines in four industries | SUPPORTED | "86% of citations come from sources brands already control"; "across ChatGPT (OpenAI), Gemini (Google), and Perplexity"; "across four industries: retail, financial services, healthcare, and food service". Live page. |
| 39 | R96 Zhao 2025 | L77 | A decline of about 7% in weekly visits within six weeks of blocking generative-AI crawlers, measured by SimilarWeb or by Semrush | SUPPORTED | "We find a 7% post-blocking decline in weekly visits measured by SimilarWeb or Semrush within the 6 weeks after blocking." arXiv v4 full text, Introduction, p. 3. Table 2: ATT -0.074 (SimilarWeb), -0.069 (Semrush), -0.065 (Comscore). This settles the open item. See caveat C5. |
| 40 | R97 Zobel 1998 | L79 | Pooled relevance judgments are incomplete; systems that did not contribute to the pool are scored on a universe they did not help define | SUPPORTED | "it is likely that at best 50%–70% of the relevant documents have been discovered"; "a technique that did not have an opportunity to contribute to the pool may have its effectiveness underestimated". Full text. See caveat C4. |

### Vendor terms quoted in the manuscript (worklist-era L522, now L524)

These terms pages are not entries in the reference list; they are checked here because the manuscript quotes them.

| # | Quoted string in the manuscript | Clause cited | Verdict | Source text (live page, 14 Nov 2026) |
|---|---|---|---|---|
| T1 | "through an automated means" | Ahrefs 4.4(j) | VERBATIM | "j) except through Ahrefs API, use Ahrefs Services through an automated means;" under "4.4. You agree that you will not, and will not use Agents to (where applicable)". https://ahrefs.com/legal/terms (https://ahrefs.com/terms redirects there). Page states "Last modified: September 14, 2026". |
| T2 | "engine, software, tool, agent, device or mechanism" | Ahrefs 4.4(i) | VERBATIM | "i) except through the software or search agents provided by Ahrefs Services, search, crawl, scrape or harvest data or information from Ahrefs Services through the use of any engine, software, tool, agent, device or mechanism;" |
| T3 | "any automated system" | Semrush 3.3(k) | VERBATIM | "(k) use or launch any automated system, including, “robots,” “spiders,” or “offline readers,” that sends more request messages to our servers in a given period of time than a human can reasonably produce in the same period by using a conventional browser;" https://www.semrush.com/company/legal/terms-of-service/. Page states "Last Updated: August 25, 2026". |
| T4 | "harvest or scrape any content of the Services" | Semrush 3.3(p) | VERBATIM | "(p) harvest or scrape any content of the Services or any related system or service;" |

Notes on the terms. The manuscript's paraphrases around the quotations match the clauses (the Ahrefs exception for its API and for its own software; the Semrush test of more requests than a human can reasonably produce). The Semrush page prints no section numerals in its text; they come from nested numbered lists. The restrictions are the third sub-item ("Restrictions") of the third top-level item ("USE OF SERVICES"), which is section 3.3 as the manuscript says. Both pages were last changed before every read date the manuscript gives (13 October, 15 October and 3 November 2026), so the text read then is the text live now.

## 3. Entry check: one row per reference

Tier: A = peer-reviewed literature; B = institutional or agency report; C = preprint, vendor material, press release or trade press (bottom tier, to be labelled where used).

| Ref | Identifier resolved | Record compared | Tier | Entry verdict |
|---|---|---|---|---|
| R66 Rasool 2026 | doi:10.1108/pmm-07-2026-0065 | Crossref (online 15 Sep 2026, pp. 1-19, no volume yet) | A | RESOLVED |
| R67 Razniewski 2024 | doi:10.1145/3639563 | Crossref; article number 150 confirmed on two university portal records | A | RESOLVED |
| R68 Razniewski 2016 | doi:10.18653/v1/W16-1308 (found by search) | Crossref, ACL Anthology PDF | A (workshop) | RESOLVED |
| R69 Redi 2020 | arXiv:2008.12314 | arXiv API | C (preprint, Wikimedia Foundation research draft) | RESOLVED, title differs (see Section 6) |
| R70 Ren 2014 | doi:10.1007/978-3-319-07443-6_50 | Crossref, Springer page | A | RESOLVED |
| R71 Reyes-Lillo 2023 | doi:10.3145/epi.2023.jul.03 | Crossref, journal page | A | RESOLVED, volume and issue missing (see Section 6) |
| R72 Rijo 2026a | URL | Live page (published 19 Oct 2026) | C (trade press) | RESOLVED |
| R73 Rijo 2026b | URL | Live page (published 22 Oct 2026) | C (trade press) | RESOLVED |
| R74 Ripoll 2025 | arXiv:2505.16383 | arXiv API (v2, 10 Jun 2025) | C (preprint) | RESOLVED |
| R75 Romero Ramos 2026 | doi:10.55946/latitude.v2i24.295 | Crossref, journal page | A (small institutional journal) | RESOLVED |
| R76 Scheitle 2018 | doi:10.1145/3278532.3278574 (found by search) | Crossref, arXiv:1805.11506 | A | RESOLVED |
| R77 Schultheiß 2023 | doi:10.7717/peerj-cs.1421 | Crossref, Europe PMC | A | RESOLVED |
| R78 Semrush n.d.-a | URL | Live page, title "How to use Keyword Gap?" | C (vendor documentation) | RESOLVED |
| R79 Semrush n.d.-b | URL | Live page, title "Overview report" | C (vendor documentation) | RESOLVED |
| R80 Semrush n.d.-c | URL | Live page, title "Semrush Rank" | C (vendor documentation) | RESOLVED, URL redirects (see Section 6) |
| R81 Shao 2024 | doi:10.18653/v1/2024.naacl-long.347 (found by search) | Crossref, ACL Anthology PDF | A | RESOLVED |
| R82 Soulo 2022 | URL | Live page (published 3 May 2022, modified 20 Oct 2022) | C (vendor study of itself and a competitor) | RESOLVED |
| R83 Taylor 1968 | doi:10.5860/crl_29_03_178 (found by search) | Crossref, journal page and PDF | A | RESOLVED |
| R84 Thelwall 2008 | doi:10.1002/asi.20834 | Crossref | A | RESOLVED |
| R85 Tinuiti 2026 | URL | Live page (published 25 Feb 2026, modified 26 Aug 2026) | C (agency report on a vendor tool) | RESOLVED |
| R86 Vállez 2020 | doi:10.1016/j.acalib.2020.102171 | Crossref | A | RESOLVED |
| R87 Vaughan 2013 | doi:10.1016/j.joi.2013.04.005 (found by search) | Crossref, RePEc | A | RESOLVED |
| R88 Webber 2009 | doi:10.1145/1571941.1572018 (found by search) | Crossref | A | RESOLVED |
| R89 White 2015 | doi:10.1145/2740908.2742769 | Crossref, IW3C2 archive PDF | A (two-page poster paper) | RESOLVED |
| R90 Wilson 1927 | doi:10.1080/01621459.1927.10502953 | Crossref, JSTOR scan cover | A | RESOLVED |
| R91 Wiśniewski 2019 | doi:10.1016/j.websem.2019.100534 | Crossref | A | RESOLVED |
| R92 Wulczyn 2016 | doi:10.1145/2872427.2883077 (found by search) | Crossref, arXiv:1604.03235 | A | RESOLVED, publisher differs (see Section 6) |
| R93 Xu 2026 | arXiv:2605.14021 | arXiv API (v2, 1 Oct 2026); Crossref doi:10.1145/3777912.3839818 | A now (was C) | RESOLVED, published version now exists (see Section 6) |
| R94 Yang 2025 | arXiv:2507.05301 | arXiv API (v1, 7 Jul 2025) | C (preprint) | RESOLVED |
| R95 Yext 2025 | URL | Live page (9 Oct 2025) | C (vendor press release) | RESOLVED |
| R96 Zhao 2025 | arXiv:2512.24968 | arXiv API (v4, 15 Apr 2026, the latest) | C (preprint) | RESOLVED |
| R97 Zobel 1998 | doi:10.1145/290941.291014 (found by search) | Crossref | A | RESOLVED |

Tier note. The manuscript labels its bottom-tier sources where it uses them for Soulo ("A vendor study ... the vendor reporting on itself and on a competitor"), Tinuiti and Yext ("Other vendor reports, built on their own tools") and Rijo ("Trade press reports ... These are secondary reports"). The four arXiv preprints (Redi, Ripoll, Yang, Zhao & Berman) are marked as preprints in the reference list only, not in the sentences that cite them; Zhao & Berman carries a number (about 7%).

## 4. Verdict counts

| Verdict | Citing sentences |
|---|---|
| SUPPORTED | 34 |
| PARTLY | 5 |
| NOT SUPPORTED | 1 |
| COULD NOT VERIFY | 0 |
| Total | 40 |

Quotations from vendor terms: 4 checked, 4 VERBATIM. References: 32 checked, 32 RESOLVED, of which 5 have an entry-level difference and 1 is out of date (Section 6).

## 5. Caveats on rows marked SUPPORTED

None of these changes a verdict. Each is a place where the manuscript's wording is its own gloss or where the source adds context a reader may check.

- **C1, Rasool L77.** The two gaps of about 4% run in opposite directions: Semrush is higher on total visits (3.88%), SimilarWeb higher on unique visitors (4.09%). The abstract says "50 prominent global repositories ... selected from OpenDOAR"; "open-access" rests on OpenDOAR being the Directory of Open Access Repositories. Only the abstract was readable.
- **C2, Redi L89.** The source is a taxonomy for classifying and later measuring knowledge gaps across Wikimedia projects (readers, contributors, content), not a method that discovers gaps in one encyclopedia.
- **C3, Wiśniewski L69.** The source's translation of questions to SPARQL-OWL was manual ("we manually translated them to SPARQL-OWL") and it states that "there is no automatic way to translate" a competency question. "Compiled ... along property paths" describes the manuscript's own implementation; the citation supports the practice of formalizing competency questions as SPARQL queries.
- **C4, Zobel L79.** Zobel's own conclusion is reassuring for TREC: "pooling bias does not appear to have a significant impact and the available relevance judgements provide a fair basis for measurement of new systems". The manuscript's sentence is neutral and does not contradict this.
- **C5, Zhao & Berman L77.** The 7% is the source's own rounding of log-point estimates. In its Table 2 the Semrush estimate's interval includes zero ([-0.145, 0.007], marked at the 10% level); the SimilarWeb interval does not ([-0.141, -0.007]). The abstract confines the finding to large publishers.
- **C6, Rijo L468.** The Semrush statement ("since late summer") is quoted in full in Rijo 2026a; Rijo 2026b, which the manuscript cites for it, refers back to it. Both articles carry it.
- **C7, Soulo L77.** The study compares United States Search Console traffic with United States estimates; the manuscript does not say so.
- **C8, Yang L81.** The source says "over 366,000" (366,087); the manuscript prints 366,000 without "over".

## 6. Entry-level differences

Each item gives the printed element, what the source's own record says, and the correct value.

1. **R71 Reyes-Lillo et al. 2023: volume and issue are missing.** Printed: "*El Profesional de la Información*, e320403." The journal's page for the article gives volume 32, issue 4 ("Vol. 32 Núm. 4 (2023)"; metadata `citation_volume = 32`, `citation_issue = 4`). Correct: *Profesional de la información, 32*(4), e320403. On the title: the journal's site now styles itself "Profesional de la información" (no "El"); Crossref's container title is "El Profesional de la información". Either is traceable; the printed capital in "Información" matches neither.
2. **R80 Semrush n.d.-c: the printed URL redirects.** Printed: https://www.semrush.com/kb/semrush-reports-tools/domain-analytics/ranks/traffic-ranks/. It returns the right page ("Semrush Rank") only after a redirect to https://www.semrush.com/kb/27-rank, which is the page's own canonical address. Correct URL: https://www.semrush.com/kb/27-rank.
3. **R93 Xu, Iqbal & Montgomery 2026: a published version now exists.** Printed as an arXiv preprint only. arXiv's record (v2, 1 October 2026) and Crossref give: *Proceedings of the 2026 ACM Internet Measurement Conference (IMC '26)*, pp. 529–546, ACM, published 12 October 2026, https://doi.org/10.1145/3777912.3839818. Title and authors are the same. The entry is not wrong, but it is out of date.
4. **R69 Redi et al. 2020: the title omits the draft designation.** arXiv's titles are "A Taxonomy of Knowledge Gaps for Wikimedia Projects (First Draft)" for v1 (27 August 2020) and "... (Second Draft)" for v2 (29 January 2021), the current version. The entry prints neither and gives no version. Correct, if the 2020 version is meant: *A taxonomy of knowledge gaps for Wikimedia projects (First draft).* arXiv:2008.12314v1; if the current text was read, it is the Second Draft, revised 29 January 2021.
5. **R92 Wulczyn et al. 2016: publisher.** Printed: "In *WWW '16* (pp. 975–985). ACM." Crossref gives the publisher as International World Wide Web Conferences Steering Committee, the proceedings title as *Proceedings of the 25th International Conference on World Wide Web*, and the DOI as 10.1145/2872427.2883077. Pages match.
6. **R95 Yext 2025: host name.** The printed URL (https://yext.com/about/news-media/ai-citations-release) redirects to https://www.yext.com/about/news-media/ai-citations-release. Same page; trivial.
7. **R85 Tinuiti 2026: date.** The page's metadata gives a publication date of 25 February 2026 and a modification date of 26 August 2026. The entry gives the year only and no retrieval date, unlike the other web entries.

**No difference found** (every printed element matches the source's record): R66, R67, R68, R70, R72, R73, R74, R75, R76, R77, R78, R79, R81, R82, R83, R84, R86, R87, R88, R89, R90, R91, R94, R96, R97.

**Omissions, not errors** (elements the record holds and the entry does not print): R68 DOI 10.18653/v1/W16-1308 and the full title *Proceedings of the 5th Workshop on Automated Knowledge Base Construction*; R70 LNCS volume 8465; R76 pages 478–493 and DOI 10.1145/3278532.3278574; R81 pages 6252–6278, DOI 10.18653/v1/2024.naacl-long.347 and the full proceedings title; R83 DOI 10.5860/crl_29_03_178; R87 DOI 10.1016/j.joi.2013.04.005; R88 DOI 10.1145/1571941.1572018; R97 DOI 10.1145/290941.291014.

## 7. Everything not SUPPORTED

Ordered by how far the manuscript's wording departs from the source. Proposed wordings are the smallest change the source supports; none alters the paper's argument.

### 7.1 Shao et al. 2024, L89: NOT SUPPORTED

**Manuscript sentence:** "Appendix B's scoring function draws on the study of completeness in open-world knowledge bases [Razniewski et al. 2016; Galárraga et al. 2017; Balaraman et al. 2018; Luggen et al. 2019; Razniewski et al. 2024], on demand-weighted completeness [Hopkinson et al. 2018], and on gap discovery for encyclopedias [Wulczyn et al. 2016; Piccardi et al. 2018; Redi et al. 2020; Shao et al. 2024], with Ripoll et al. [2025] giving the most recent typology of content gaps for a collaborative knowledge base."

**What the source says:** "We study how to apply large language models to write grounded and organized long-form articles from scratch, with comparable breadth and depth to Wikipedia pages." The system (STORM) researches a given topic by asking questions from several perspectives and drafts an outline and article. It does not find gaps in an existing encyclopedia.

**Proposed wording:** "... and on gap discovery for encyclopedias [Wulczyn et al. 2016; Piccardi et al. 2018; Redi et al. 2020] and the question-driven drafting of encyclopedia articles from scratch [Shao et al. 2024], ..."

### 7.2 Schultheiß et al. 2023, L87: PARTLY

**Manuscript sentence:** "Studies of search increasingly sample their queries, and the queries' volumes, from keyword research tools [Schultheiß et al. 2023]."

**What the source says:** It proposes the practice and reports a few earlier uses; it does not report a rising trend. "We address this problem by developing an approach (query sampler) to sample queries from commercial search engines, using keyword research tools". On existing practice: "In the literature, we find that query sets are developed rather unsystematically", and "studies similar to the pre-2016 studies using Google Keyword Planner could not be conducted anymore, at least not with accurate search volume data."

**Proposed wording:** "Some studies of search sample their queries, and the queries' volumes, from keyword research tools, and a systematic method for doing so has been proposed [Schultheiß et al. 2023]."

### 7.3 Thelwall 2008, L91: PARTLY

**Manuscript sentence:** "For Measurement 2: aspect mining of reviews [Hu & Liu 2004] and keyword tools as a source of queries and volumes [Schultheiß et al. 2023]; this paper places the two signals on one taxonomy and compares the topics each ranks; its second comparison (Section 6.2) follows the work that treats search-engine hit counts [Thelwall 2008], Google Trends [Hölzl, Keusch & Sajons 2025] and Wikipedia page views [Alibudbud 2023] as instruments whose settings, access dates and handling of crawlers and redirects must be reported, and checks one such count against a vendor's volume on a fixed class of entities."

**What the source says:** It treats hit counts as research data whose consistency must be tested: "quantitative results from the three search engines are mostly consistent but with unexpected types of inconsistency that users should be aware of." It does not say that settings or access dates must be reported, and it does not discuss crawlers or redirects. Its nearest remark is "search engine algorithms change frequently and so it is not known for how long the results will be valid." Basis: published abstract and the author's preprint; the published full text is paywalled.

**Proposed wording:** "... follows the work that treats search-engine hit counts as an instrument whose consistency must be checked before use [Thelwall 2008], and Google Trends [Hölzl, Keusch & Sajons 2025] and Wikipedia page views [Alibudbud 2023] as instruments whose settings, access dates and handling of crawlers and redirects must be reported, ..." (The second half depends on the two other sources, which are outside this worklist.)

### 7.4 Wiśniewski et al. 2019, L782 (now L784): PARTLY

**Manuscript sentence:** "The implementation reports competency-question performance as two separate rates, because they fail for different reasons, as in test-driven ontology development, which tests a question against the ontology's vocabulary and separately against its instances [Keet & Ławrynowicz 2016; Wiśniewski et al. 2019]: a schema rate, the share of questions the ontology can express (a property-path check, plus questions the author declares unsupported), and an instance coverage rate, the mean over expressible questions of the share of subjects for which the graph returns an answer."

**What the source says:** It supports the vocabulary half only. "In total, 131 out of 234 competency questions can be translated into a SPARQL-OWL form. ... The reason why some CQs are not translated is due to missing vocabulary in the ontology to construct expected query or expressing the CQ in a too vague way." It does not test questions against instances: one question "is a instance-level question and thus we did not translate it". Test-driven development appears only in its related work. Basis: arXiv v1 full text (titled "Competency Questions and SPARQL-OWL Queries Dataset and Analysis") and the published abstract; the journal full text was not opened.

**Proposed wording:** "..., as in test-driven ontology development, which tests a question against the ontology's vocabulary and separately against its instances [Keet & Ławrynowicz 2016], and as in the finding that many published competency questions cannot be expressed for want of vocabulary in the ontology [Wiśniewski et al. 2019]: a schema rate, ..." (This assumes Keet & Ławrynowicz 2016 carries the vocabulary and instances split; that source is outside this worklist.)

### 7.5 Ripoll et al. 2025, L89: PARTLY (one word)

**Manuscript sentence:** the same sentence as 7.1, in its last clause: "with Ripoll et al. [2025] giving the most recent typology of content gaps for a collaborative knowledge base."

**What the source says:** "We propose a typology of gaps based on prior research and contribute a theoretical framework intended to conceptualise gaps and support their measurement." It concerns Wikidata, "a collaborative knowledge graph". It does not claim to be the most recent, and no source could settle that. This check did not search systematically for later typologies.

**Proposed wording:** "with Ripoll et al. [2025] giving a recent typology of content gaps for a collaborative knowledge base."

### 7.6 Yang 2025, L22: PARTLY (one phrase)

**Manuscript sentence:** "Which sources different AI answer engines cite has been audited on public-interest, news and real search queries [Li & Sinnamon 2024; Yang 2025; Huang et al. 2026; Allaham & Diakopoulos 2026]; this paper adds a comparison of eight vendor-collected answer surfaces across a sector frame fixed by an external rule."

**What the source says:** The study audits which news sources are cited, on unrestricted real conversations from a public arena; its queries are not news queries. "The dataset comprises over 24,000 conversations and 65,000 responses ... Among the over 366,000 citations embedded in these responses, 9% reference news sources." If "news" in the manuscript's list is meant for another of the four studies, this sentence stands for Yang under "real search queries"; the manuscript's own longer description at L81 ("which cite distinct news sources") suggests "news" is meant for Yang.

**Proposed wording:** "Which sources different AI answer engines cite has been audited on public-interest queries, for news sources, and on real search queries [Li & Sinnamon 2024; Yang 2025; Huang et al. 2026; Allaham & Diakopoulos 2026]; ..."

## 8. Control tests run

| Endpoint | Control | Result |
|---|---|---|
| Crossref by DOI | Known-good 10.1038/s41586-021-03819-2 | HTTP 200, "Highly accurate protein structure prediction with AlphaFold", Nature |
| Crossref by DOI | Invented 10.1038/s41586-099-99999-9 | HTTP 404 |
| arXiv API | 1706.03762 | "Attention Is All You Need", 8 authors |
| OpenAlex by DOI | 10.1038/s41586-021-03819-2 | HTTP 200, correct record (before the daily budget ran out) |
| Crossref bibliographic search | Title and first author of R77 | Correct record returned, ranked second behind a "Peer Review #1 of ..." record; titles were compared, the count was ignored |
| Europe PMC | DOI of R77 | PMC10280501 found, full text retrieved |
| OpenAlex title search | "Attention Is All You Need" | FAILED, HTTP 429 ("Insufficient budget" for keyless requests from this network). No OpenAlex title-search result is used in this report |
| DBLP search | "Attention is All you Need Vaswani" | FAILED, HTTP 202 with empty body, then HTTP 429. No DBLP result is used in this report |

## 9. Not verified, and why

- **Published full texts not opened** (paywall or bot block); the verdict rests on the publisher's abstract, which carried the claim: Rasool 2026 (Emerald, HTTP 403), Razniewski 2024, Ren 2014, Vállez & Ventura 2020, Vaughan & Yang 2013, Webber & Park 2009, Reyes-Lillo 2023 and Romero Ramos 2026 (both open, abstract sufficient).
- **A substitute copy was read instead of the publisher's:** Thelwall 2008 (author's preprint from his university page, retrieved through the Internet Archive snapshot of 20 November 2024 because the host refused connections; plus the published abstract); Wiśniewski 2019 (arXiv v1 of November 2018 under an earlier title; plus the published abstract); Zobel 1998 (a university course copy of the paper, the ACM PDF returning HTTP 403); Wilson 1927 (a third-party copy of the JSTOR scan, pages read as images); Schultheiß 2023 (Europe PMC, the PeerJ page returning HTTP 403); White 2015 (the conference's own archive). A reviewer with library access could confirm the two PARTLY verdicts that rest on preprints (7.3 and 7.4) against the journal texts.
- **Published versions of the four preprints** (Redi, Ripoll, Yang, Zhao & Berman): a Crossref title and author search, with a passing control, found none. The OpenAlex title search that would double-check this failed its control. arXiv's own records list no journal reference for Ripoll, Yang or Zhao & Berman.
- **Retrieval and read dates** printed in the entries and in Section 14 (12 October, 13 October, 15 October and 3 November 2026) cannot be checked from outside. All pages were read live on 14 November 2026 and say what the manuscript reports.
- **Rijo 2026a and 2026b** are secondary reports. The underlying vendor posts (Nozzle, Ahrefs, Semrush's statement) were not opened; the check is that the manuscript reports the articles correctly, which it does.

## 10. Do not assert

- RESOLVED means the reference exists and its printed metadata matches the source's record. It does not mean the source's findings are correct.
- SUPPORTED means the source says what the manuscript attributes to it. It does not mean the manuscript's use of the source in its argument is sound.
- Rows resting on an abstract are supported at the level of the abstract only.
- This report covers R66 to R97. It says nothing about R1 to R65, nor about the co-cited sources named in Section 1 as outside this worklist.
- The line numbers were correct for the file as it stood when the worklist was built and are given with their current values; the file was still being edited during the check.
