# Fact-check report 1 of 3: references R1 to R33 (manuscript v5.5, 14 November 2026)

Returned as text by the checking agent, whose harness could not write files; saved here unedited.

**The report file was not written.** My harness forbids writing report `.md` files, so per your fallback the full report is returned here as text; nothing was created at `/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/factcheck_v5.5_2026-11-14/report_1.md`. The project was not modified by me.

**Line numbers shifted during the check.** Another process edited `manuscript_v50.md` at about 16:41 and inserted two lines after L184. All 48 citing sentences are still present verbatim, but every worklist line above 184 is now two higher (L301 is L303, L933 is L935). I use worklist numbers below.

## Counts

- References checked: 33 of 33, all RESOLVED (none MISMATCH, UNRESOLVABLE or FABRICATED-SUSPECT).
- Citing sentences checked: 48.
  - SUPPORTED: 41
  - PARTLY: 6
  - NOT SUPPORTED: 0
  - COULD NOT VERIFY: 1
- Two further worklist rows are not citations of the reference they are filed under: R26 L136 and R26 L468 (neither contains `[Google 2026]`; only L155 does).
- The worklist missed no citing sentence: a search of the manuscript for every key returned the same 48 key-and-line pairs.

## Entry-level differences

No entry points to the wrong work. The differences below are ordered by how much they matter.

1. **R28 Grossman 2026: a version of record exists, so "[Preprint]" is out of date.**
   - Published as: *Proceedings of the 49th International ACM SIGIR Conference on Research and Development in Information Retrieval (SIGIR '26)*, pp. 448–459, ACM, https://doi.org/10.1145/3805712.3809667 (Crossref, published 19 July 2026).
   - The arXiv record carries the comment "Paper Accepted to ACM SIGIR 2026".
   - Authors, order, title, year and arXiv id match.

2. **R19 Eloundou 2025: two author names differ between the paper and the landing page the entry cites.**
   - Paper PDF byline and arXiv 2410.19803v2: "David G. Robinson" and "Keren Gu-Lemberg".
   - ICLR proceedings page: "David Robinson" and "Keren Gu", which the entry follows ("Robinson, D.", "Gu, K.").
   - To match the paper itself: "Robinson, D. G." and "Gu-Lemberg, K.". All other elements match.

3. **R20 Font-Julián 2026: surname accent.** The version of record prints "Cristina I. Font-Julian" without the accent (publisher PDF byline and Crossref). Everything else matches: author order, title, *Journal of Information Science* 52(4), 1075–1088, DOI, and the open copy at riunet is live and is this paper.

4. **R21 Font-Julián 2025: fourth author's initial.** The preprint PDF, Crossref and OSF all give "Isidro Aguillo" with no middle initial; the entry prints "Aguillo, I. F.". The first author is "Font-Julián" in Crossref and OSF but "Font-Julian" in the PDF byline. Version 1 is the latest version; posted 22 October 2025.

5. **R11 Carroll 2005: page range missing.** Pages are 613–622 (Crossref gives first page 613; Semantic Scholar gives 613-622). Other proceedings entries print pages.

6. **R3 Ahrefs 2026b: date treatment inconsistent with R2.** Both help pages display "September 3, 2026" as last updated (R2 at 2026-09-03T10:44:50Z, R3 at 2026-09-03T13:04:57Z). R2 prints the date; R3 prints only the year and a retrieval date. Both pages also carry individual bylines ("Constance Tan", "Anna"); corporate authorship is a style choice.

7. **R26 Google 2026: the title is descriptive, not the page's own.** The page is titled "History for Ranking | Google Search Status Dashboard", with the heading "All incidents reported for Ranking". The bracketed dates are correct. The incident has its own page: https://status.search.google.com/incidents/LEubPCm2octf2uMqCFKE.

8. **R31 Hendricks 2026: concept DOI and resource type.**
   - 10.5281/zenodo.22242102 is the concept DOI for all versions: v2026.09.1 (issued 1 September 2026, DOI ending 22242103) and v2026.09.2 (issued 4 October 2026, DOI ending 23132107).
   - Zenodo types the record as Dataset only. The report is a separate web page, https://hendricks.ai/research/the-answer-index.
   - Creator, title, publisher and year match.

9. **R7 Bek 2026: metadata date later than the displayed one.** The page shows "Updated: February 26, 2026", as the entry says. Its embedded metadata gives datePublished 2025-10-29 and dateModified 2026-06-16. Informational only; the page as fetched today contains every figure the manuscript reports.

10. **R12 Chapekis & Lieb 2025 and R25 Golebiewski & boyd 2018: no URL printed.**
    - Pew: https://www.pewresearch.org/short-reads/2025/07/22/google-users-are-less-likely-to-click-on-links-when-an-ai-summary-appears-in-the-results/ (headline, byline and 22 July 2025 match).
    - Data & Society: https://datasociety.net/library/data-voids-where-missing-data-can-easily-be-exploited/ (published 11 May 2018).

11. **R32 Hölzl 2025: title punctuation.** The journal prints "... in the social sciences - A systematic review, critique, and recommendations"; the entry uses a colon. Conventional, no change needed.

12. **Style only: abbreviated venues and omitted DOIs.**
    - R22, R24, R30 and R33 abbreviate the venue ("WSDM '17", "WSDM '10", "WWW '02", "NAACL-HLT 2018, Industry Papers") where other entries give full proceedings titles.
    - DOIs exist for entries printed without one:

    | Entry | DOI |
    |---|---|
    | R6 | 10.1145/3184558.3191641 |
    | R8 | 10.1108/eb026722 |
    | R9 | 10.1145/792550.792552 |
    | R10 | 10.1145/1008992.1009000 |
    | R15 | 10.1007/978-3-031-02294-4 (the 2015 Morgan & Claypool DOI redirects here) |
    | R22 | 10.1145/3018661.3018739 |
    | R24 | 10.1145/1718487.1718513 |
    | R29 | 10.1145/2488388.2488435 |
    | R30 | 10.1145/511446.511513 |
    | R33 | 10.18653/v1/N18-3025 |

No differences were found in R1, R2, R4, R5, R6, R8, R9, R10, R13, R14, R15, R16, R17, R18, R22, R23, R24, R27, R29, R30 or R33 beyond the style points in item 12.

## Everything not SUPPORTED

Seven items, ordered by risk. None is a fabricated or mismatched source.

**1. R29 Hannak 2013, L496. PARTLY.**
- Manuscript: "The question is whether the answer and its citations vary with who is asking, which classic web search audits found only weakly for demographic attributes [Hannak et al. 2013], which has been measured for chatbot responses [Eloundou et al. 2025], and which, to the author's knowledge, has not been measured for the sources AI answer surfaces cite."
- Source (WWW 2013 full text): "We do not observe personalization based on gender in our experiments. Similarly, we do not observe personalization based on profile age". Also: "All other attributes do not result in level of personalization beyond the baseline noise level."
- Supported: no substantial demographic personalization. Not supported: that a weak effect was found; the audit reports none. The sentence also says "audits" but cites one. L83 already states this accurately ("producing no substantial effect"), so the two lines disagree.
- Proposed: "..., which a classic web search audit did not find for demographic attributes such as gender and age [Hannak et al. 2013], ..."

**2. R20 Font-Julián 2026, L91. PARTLY.**
- Manuscript: "For Measurement 1: comparisons of estimators with first-party analytics or with one another, across many established sites at one time [Jansen, Jung & Salminen 2022; Rasool, Thakur & Nabi 2026; Font-Julián et al. 2026]; this paper holds one site fixed, reads back two instruments' stored histories of one section to its first month, in a single retrospective read, and compares twelve sections of the site on one date."
- Source: "The performance of each tool was checked using two domain names"; "all data were downloaded simultaneously on 5 July 2024".
- Supported for this source: tools compared with one another, on established sites, at one time. Not supported: "many"; this study uses two domains (MDPI and Frontiers), as L77 itself says.
- Proposed: "... with first-party analytics or with one another, on established sites at one time [...]".

**3. R20 Font-Julián 2026, L77. PARTLY.**
- Manuscript: "... and the organic keyword counts, keyword search volumes and URL-level traffic that Ahrefs, Semrush, Serpstat and Ubersuggest report for two academic publishers' domains, which overlapped so little that the choice of tool determined the findings [Font-Julián et al. 2026], ..."
- Source: abstract, "a low overlap in organic keywords and URL-based web traffic across tools, suggesting that tool selection significantly determines findings". On search volumes, Section 4.1.3: "The average CV is 0.43 ... indicating a narrow distribution and low variability between the tools".
- Supported: the four tools, the three metrics, the two publishers, low overlap of keyword and URL sets, tool choice shaping findings. Not supported: that search volumes overlapped little; the paper found them the most stable of the three.
- Proposed: "... report for two academic publishers' domains, where the keywords and URLs the tools returned overlapped so little that the choice of tool determined the findings [Font-Julián et al. 2026], ..."

**4. R4 Alibudbud 2023, L301. PARTLY.**
- Manuscript: "The items a review of page-view studies asks authors to state, the pages, the language, the dates, the agent type and whether crawlers and redirects were included [Alibudbud 2023], are fixed in the plan."
- Source (Table 1, seven items): "1. Precise Wikipedia page or pages of study 2. Language of the Wikipedia page 3. Dates of data collection 4. Dates explored 5. Type of data (e.g., monthly or daily) 6. Whether page views were limited to Internet users 7. Whether web crawlers and redirects to the Wikipedia page were included".
- Supported: pages, language, dates (two items merged), crawlers and redirects; "agent type" stands for item 6. Not supported: the list reads as complete but omits item 5, type of data.
- Proposed, smallest: "Of the items a review of page-view studies asks authors to state [Alibudbud 2023], the pages, the language, the dates, the agent type and whether crawlers and redirects were included are fixed in the plan."
- Proposed, complete: "..., the pages, the language, the collection dates and the period covered, the type of data (monthly), the agent type and whether crawlers and redirects were included [Alibudbud 2023], are fixed in the plan." The plan at `/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/02_DESIGN/wikipedia_demand_372.md` does specify monthly counts, so this stays true.

**5. R20 Font-Julián 2026, L933. PARTLY.**
- Manuscript: "Guidance on these tools does exist, and the search record passed over it: an empirical comparison of four SEO tools closes with methodological recommendations [Font-Julián et al. 2026, Section 5.2], to use several tools where possible, to prefer what several detect, to read traffic as relative rather than precise, and to report the tool, the extraction date, the market settings and each metric's definition."
- Source: Section 5.2 is "Methodological recommendations for the use of SEO tools in quantitative research" and holds five recommendations. It is followed by Section 5.3 "Limitations" and Section 6 "Conclusion". The third recommendation, not listed in the manuscript: "Third, search volume indicators appear to be more stable than traffic estimates."
- Supported: all four listed recommendations, each matching the source closely, and the next sentence's remark that the source advises averaging traffic across tools. Not supported: "closes with", and the list reading as complete when it gives four of five.
- Proposed: "... an empirical comparison of four SEO tools sets out five methodological recommendations in its discussion [Font-Julián et al. 2026, Section 5.2], among them to use several tools where possible, ..."

**6. R20 Font-Julián 2026, L22. PARTLY.**
- Manuscript: "A third search, on 31 October, looked for reporting guidelines for such figures and found no checklist; the nearest guidance is the set of recommendations closing one empirical comparison of the tools [Font-Julián et al. 2026], which Appendix E credits."
- Source: as in item 5; the recommendations sit in the middle of the discussion.
- Supported: that the paper is an empirical comparison containing a set of recommendations. Not supported: "closing".
- Proposed: "... the nearest guidance is the set of recommendations in the discussion of one empirical comparison of the tools [Font-Julián et al. 2026], ..."

**7. R8 Belkin, Oddy & Brooks 1982, L85. COULD NOT VERIFY.**
- Manuscript: "The gap between the unit a user has in mind and the unit a retrieval system indexes is old ground [Belkin, Oddy & Brooks 1982; Taylor 1968], as is the observation that aggregate demand concentrates differently from individual demand [Goel et al. 2010]."
- Opened: the publisher-deposited abstract in Crossref. Not opened: the full text (Emerald paywall; the repository copies at Syracuse SURFACE and CORE refused automated access).
- Abstract: "information needs are not in principle precisely specifiable", and of thirty-five subjects "only two had ASKs for which traditional 'best match' retrieval would be intuitively appropriate".
- The abstract is consistent with a gap between a user's need and what a retrieval system can match. It says nothing about units or about what a system indexes.
- Wording the abstract supports: "The gap between the need a user has in mind and the request a retrieval system can match is old ground [Belkin, Oddy & Brooks 1982; Taylor 1968], ...". Reading pp. 61–71 through a library, or the Syracuse copy in a browser, would settle whether the "unit" framing can stand.

## Remainder of the report (what would have been in the file)

### Scope

- Checked: 33 reference entries, 48 citing sentences, and every number in those sentences that is attributed to one of these sources.
- Not checked: co-cited sources belonging to the other two worklists (Taylor 1968, Thelwall 2008, Nuti 2014, Semrush, Motley Fool, Rijo and others), and the manuscript's own measurements.
- Tiers: T1 regulatory or official; T2 peer-reviewed; T3 institutional report; T4 vendor material, preprint or self-published.
- `check_manuscript.py` was run; it produced only format-driven candidates because the manuscript uses bracketed keys.

### Table A. Reference entries

| # | Reference | Identifier used | Tier | Verdict | Evidence |
|---|---|---|---|---|---|
| R1 | Aggarwal 2024 | Crossref 10.1145/3637528.3671900; arXiv 2311.09735v3 | T2 | RESOLVED | Six authors in order, title, KDD '24, pp. 5–16 |
| R2 | Ahrefs 2026a | help.ahrefs.com article 9025740, HTTP 200 | T4 vendor | RESOLVED | Title matches; page shows September 3, 2026 |
| R3 | Ahrefs 2026b | help.ahrefs.com article 1863206, HTTP 200 | T4 vendor | RESOLVED | Title matches; see difference 6 |
| R4 | Alibudbud 2023 | Crossref 10.3389/fdata.2023.1199060 | T2 | RESOLVED | Vol. 6, article 1199060, 4 July 2023 |
| R5 | Allaham 2026 | Crossref 10.1609/aies.v9i1.43129; OJS page | T2 | RESOLVED | 9(1), 142–154, 11 October 2026 |
| R6 | Balaraman 2018 | Crossref 10.1145/3184558.3191641 | T2 | RESOLVED | Three authors, pp. 1787–1792 |
| R7 | Bek 2026 | ahrefs.com/blog/brand-radar-methodology/, HTTP 200 | T4 vendor, labelled in text | RESOLVED | "By Rebekah Bek", "Updated: February 26, 2026" |
| R8 | Belkin 1982 | Crossref 10.1108/eb026722 | T2 | RESOLVED | 38(2), 61–71 |
| R9 | Broder 2002 | Crossref 10.1145/792550.792552 | T2, edited forum | RESOLVED | SIGIR Forum 36(2), 3–10 |
| R10 | Buckley 2004 | Crossref 10.1145/1008992.1009000 | T2 | RESOLVED | SIGIR 27th, pp. 25–32 |
| R11 | Carroll 2005 | Crossref 10.1145/1060745.1060835 | T2 | RESOLVED | Four authors, WWW '05; see difference 5 |
| R12 | Chapekis 2025 | pewresearch.org short-reads page, HTTP 200 | T3 | RESOLVED | Headline, byline, 22 July 2025 |
| R13 | Chen 2025 | arXiv 2509.08919v1 | T4 preprint, unlabelled at L81 | RESOLVED | Four authors, title; no published version in OpenAlex |
| R14 | Choi 2012 | Crossref 10.1111/j.1475-4932.2012.00809.x | T2 | RESOLVED | 88(s1), 2–9 |
| R15 | Chuklin 2015 | Crossref 10.2200/S00654ED1V01Y201507ICR043, redirects to Springer | T2 monograph | RESOLVED | Three authors, series, 2015 |
| R16 | Cohen 1968 | Crossref 10.1037/h0026256 | T2 | RESOLVED | 70(4), 213–220 |
| R17 | Cook 2025 | Crossref 10.2139/ssrn.5698748 | T4, unread and labelled so | RESOLVED | Author, title, 2025; SSRN page returned 403 |
| R18 | Costco 2026 | Company release PDF on s201.q4cdn.com; investor page via WebFetch | T1 | RESOLVED | Title and 24 September 2026 match |
| R19 | Eloundou 2025 | proceedings.iclr.cc page and PDF; arXiv 2410.19803v2 | T2; authors assess their employer's models | RESOLVED | Ten authors in order; see difference 2 |
| R20 | Font-Julián 2026 | Crossref 10.1177/01655515261445903; riunet handle | T2 | RESOLVED | 52(4), 1075–1088; open copy live |
| R21 | Font-Julián 2025 | Crossref 10.31235/osf.io/j4ryx_v1; OSF API | T4 preprint | RESOLVED | Order, title; see difference 4 |
| R22 | Galárraga 2017 | Crossref 10.1145/3018661.3018739 | T2 | RESOLVED | Four authors, pp. 375–383 |
| R23 | Gienapp 2024 | Crossref 10.1145/3626772.3657849 | T2 | RESOLVED | Twelve authors in order, pp. 1916–1929 |
| R24 | Goel 2010 | Crossref 10.1145/1718487.1718513 | T2 | RESOLVED | Four authors, pp. 201–210 |
| R25 | Golebiewski 2018 | datasociety.net page and PDF | T3 | RESOLVED | Two authors, May 2018 |
| R26 | Google 2026 | status.search.google.com history and incident pages | T4 by scheme; authoritative for its own incident dates | RESOLVED | See difference 7 |
| R27 | Gottfried 2025 | pewresearch.org page, HTTP 200 | T3 | RESOLVED | Title, byline, 20 November 2025 |
| R28 | Grossman 2026 | arXiv 2604.27790v1; Crossref 10.1145/3805712.3809667 | Cited as T4; T2 version exists | RESOLVED | See difference 1 |
| R29 | Hannak 2013 | Crossref 10.1145/2488388.2488435; author-hosted PDF | T2 | RESOLVED | Seven authors in order, pp. 527–538 |
| R30 | Haveliwala 2002 | Crossref 10.1145/511446.511513 | T2 | RESOLVED | pp. 517–526 |
| R31 | Hendricks 2026 | DataCite 10.5281/zenodo.22242102 | T4 self-published, unlabelled at L81 | RESOLVED | See difference 8 |
| R32 | Hölzl 2025 | Crossref 10.1016/j.ssresearch.2024.103099; MADOC PDF | T2 | RESOLVED | 126, 103099 |
| R33 | Hopkinson 2018 | ACL Anthology N18-3025 | T2 industry track | RESOLVED | Four authors, pp. 200–207 |

### Table B. Citing sentences

"Abstract only" means the full text was not read; in each such row the abstract states the claim directly.

| Ref | Line | Claim | Verdict | Evidence |
|---|---|---|---|---|
| R1 | L20 | GEO is the term for optimizing for AI answer engines | SUPPORTED | arXiv abstract: "we introduce Generative Engine Optimization (GEO), the first novel paradigm to aid content creators in improving their content visibility in generative engine responses" |
| R1 | L81 | GEO introduced to raise a source's visibility in generated answers | SUPPORTED | Same passage |
| R2 | L768 | Gap analysis lists keywords competitors rank for and a site does not | SUPPORTED | Help page: "check what organic keywords that other websites rank for, that your target website does not rank for" |
| R3 | L141 | Ahrefs metric: monthly Google clicks, summed over keywords from position, volume and estimated CTR | SUPPORTED | Help page: "based on its ranking position, monthly search volume, and our estimated CTR for that position"; "We sum up the traffic estimations of each keyword" |
| R4 | L91 | Page views treated as an instrument whose settings, dates, crawlers and redirects are reported | SUPPORTED | Table 1, "Recommended checklist of methodological considerations", items 3 and 7 |
| R4 | L301 | The items the review asks authors to state | PARTLY | Table 1 has seven items; item 5, type of data, is omitted. See item 4 above |
| R4 | L933 | Reporting items for page views; name no SEO or web-analytics tool | SUPPORTED | Table 1 names no tool. The body mentions "Google Analytics" once as a data source in reviewed studies |
| R5 | L22 | Audit of which sources engines cite, on real public-interest queries | SUPPORTED | Full text: "712 real-world human-generated queries spanning domains of public importance" |
| R5 | L81 | Four engines, 712 queries, about 16% of cited sources AI-generated | SUPPORTED | Full text: "approximately 16% of unique cited sources across all providers" |
| R6 | L89 | A study of knowledge-base completeness | SUPPORTED | Abstract only: "an approach towards measuring Relative Completeness in Wikidata by comparison with data present for similar entities" |
| R7 | L321 | Query sources; 282M, 24M, 13 to 15M a month; monthly over 90 days, Google continuous | SUPPORTED | Page: AI Overviews 282 million, AI Mode 24 million, assistants 13 to 14.6 million; "refreshed monthly, using a 90-day reporting window"; "update continuously" |
| R8 | L85 | Gap between the user's unit and the indexed unit is old ground | COULD NOT VERIFY | Abstract only. See item 7 above |
| R9 | L85 | Taxonomy distinguishes intent, not granularity | SUPPORTED | Abstract only: "it might be navigational (give me the url of the site I want to reach) or transactional" |
| R10 | L79 | Measures robust to incomplete judgments were proposed | SUPPORTED | Abstract only: "A new measure is introduced that is ... more robust to incomplete judgment sets." |
| R11 | L68 | Statements carry provenance, in the spirit of named graphs | SUPPORTED | Abstract only: "This enables RDF statements that describe graphs" |
| R12 | L81 | Click inside an AI summary in 1% of visits | SUPPORTED | Page: "This occurred in just 1% of all visits to pages with such a summary." Also 8% against 15% for result links |
| R12 | L83 | Behavioral evidence on AI summaries concerns clicks | SUPPORTED | Same page; it measures clicks and session endings |
| R13 | L81 | Controlled experiments across verticals; AI search favors earned media, unlike Google | SUPPORTED | Abstract: "overwhelming bias towards Earned media ... over Brand-owned and Social content, a stark contrast to Google's more balanced mix" |
| R14 | L87 | Search volume used to nowcast economic indicators | SUPPORTED | Abstract only: "how to use search engine data to forecast near-term values of economic indicators" |
| R15 | L24 | Click models are studied in information retrieval | SUPPORTED | Publisher description only: "attention of the information retrieval community" |
| R16 | L908 | Weighted kappa | SUPPORTED | Abstract only: "A generalization to weighted kappa (Kw) is presented." |
| R17 | L81 | A working paper on 80 global brands in LLM answers, unread | SUPPORTED | Title in the DOI record. Content not opened; the manuscript claims nothing about content |
| R18 | L508 | Quarter net sales $93.9 billion, up 11.2% | SUPPORTED | Release PDF: "Net sales for the quarter increased 11.2 percent, to $93.9 billion, from $84.4 billion last year." |
| R19 | L83 | Chatbot responses vary with users' demographic attributes | SUPPORTED | Abstract: "demographic differences in chatbot responses". See precision note 1 |
| R19 | L496 | Measured for chatbot responses | SUPPORTED | Same |
| R20 | L22 | Recommendations "closing" a tool comparison | PARTLY | See item 6 above |
| R20 | L77 | Three metrics "overlapped so little" | PARTLY | See item 3 above |
| R20 | L91 | Comparison "across many established sites" | PARTLY | See item 2 above |
| R20 | L933 | "Closes with" recommendations; four listed | PARTLY | See item 5 above |
| R21 | L77 | Traffic at global and country level for the same two publishers | SUPPORTED | Abstract: "using MDPI and Frontiers as case studies"; full text: "both global and country-level" |
| R22 | L89 | A study of knowledge-base completeness | SUPPORTED | Abstract only: "much less is known about their completeness" |
| R22 | L768 | Estimators measure what a knowledge base lacks | SUPPORTED | Abstract only: "allows us to predict where facts may be missing" |
| R23 | L81 | Evaluation reframed for systems that generate rather than rank | SUPPORTED | Abstract only: "Instead of a traditional document ranking, generative retrieval systems often directly return a grounded generated text" |
| R24 | L83 | Demand spread across rare items, in web search among others | SUPPORTED | Full text: "the tail, in aggregate, is nevertheless relatively heavy"; data cover "movies, music, Web search, and Web browsing" |
| R24 | L85 | Aggregate demand concentrates differently from individual demand | SUPPORTED | Abstract: "everyone is a bit eccentric, consuming both popular and specialty products". A paraphrase |
| R25 | L112 | Data void: thin or absent authoritative content that the first arrival fills | SUPPORTED | Report: "available relevant data is limited, non-existent, or deeply problematic"; "it would not be hard to fill the data void" |
| R26 | L155 | August 2026 spam update ran 18 to 21 August, days 23 to 26 | SUPPORTED | Incident page: "began at 2026-08-18 09:27 and ended at 2026-08-21 01:49 (all times are US/Pacific)". Day numbers recomputed from 26 July |
| R26 | L136, L468 | Not citations of Google 2026 | Not applicable | Neither line contains the key |
| R27 | L504 | TikTok 21% to 37%, Reddit 18% to 26%, YouTube and Facebook steady | SUPPORTED | Page: "up from 21% in 2021"; "26% today report using Reddit, compared with 18% four years ago"; "remained relatively stable in recent years" |
| R28 | L81 | 11,500 queries; Jaccard below 0.2; generative systems favor Google-owned content | SUPPORTED | Abstract: "(<0.2 average Jaccard similarity)"; "significantly more likely to retrieve Google-owned content". Full text gives 0.11 to 0.18 |
| R29 | L83 | 11.7% differed; login and location the drivers; gender and age no effect | SUPPORTED | Abstract: "on average, 11.7% of results show differences due to personalization"; full text as quoted in item 1 |
| R29 | L496 | Audits found variation "only weakly" for demographics | PARTLY | See item 1 above |
| R30 | L774 | Topic-sensitive PageRank with a teleport set | SUPPORTED | Abstract only: "computing a set of PageRank vectors, biased using a set of representative topics" |
| R31 | L81 | 480 questions, eight industries, four engines | SUPPORTED | DataCite abstract: "a fixed panel of 480 questions, spanning eight industries and ten question types" |
| R31 | L91 | Comparison in industries the author chose | SUPPORTED | Same |
| R32 | L91 | Google Trends treated as an instrument whose settings and access dates are reported | SUPPORTED | Table 5: "Provide the date(s) of last accessing Google Trends"; "State the full search input". It has no crawler or redirect item |
| R32 | L933 | Documentation checklist for Google Trends; names no SEO or web-analytics tool | SUPPORTED | Table 5 caption: "Checklist - Recommendations on using Google Trends for research." The body mentions Google Ads and cites Statcounter in passing |
| R33 | L89 | Demand-weighted completeness | SUPPORTED | Abstract: "we introduce the notion of Demand-Weighted Completeness" |
| R33 | L768 | Completeness relative to use; predicts required relations per class from usage data | SUPPORTED | Abstract: "we employ usage data to predict the distribution over relations for that entity"; full text confirms the usage data is the system's own |

### Precision notes on SUPPORTED rows (optional tightenings, not counted as defects)

1. **R19 L83.** The study varies the stored user name: "user name bias, meaning differences in chatbot responses as the stored user's name varies". It covers two genders and four races, and average harmful-stereotype rates are "a fraction of 1%". Exact form: "vary with the gender and race associated with a user's name".
2. **R29 L83.** 11.7% is the average extra likelihood that a real user's result differs from a control account's, above the noise floor between controls.
3. **R7 L321.** The page lists five assistants at 13 to 14.6 million (ChatGPT 14.5, Perplexity 14.6, Gemini 14.6, Copilot 13.3, Grok 13). The monthly-refresh statement names four of them.
4. **R5 L81.** The 16% is of unique cited sources, as classified by an AI-text detector, and the authors present it as a lower bound.
5. **R10 L79.** The source introduces one measure; the manuscript says "measures".
6. **R25 L112.** "Authoritative" and "whoever arrives first" are the manuscript's words; the source speaks of "high-quality content".
7. **R4 and R32 L91.** Both sources recommend rather than require. The crawler and redirect item comes from Alibudbud only.
8. **R18.** From the rounded figures, 93.9 / 84.4 = 1.1126; the release's 11.2% is computed from unrounded sales.

### Adjacent uncited statements checked against the same sources

- **L155**, "The September 2026 spam update began on 24 September, day 60": the dashboard gives 2026-09-24 09:15 to 2026-10-08, US/Pacific, and 24 September is day 60.
- **L141**, "Neither vendor states an uncertainty for its estimates": true of the cited Ahrefs page, which says estimates "can have discrepancy" but gives no figure. Other Ahrefs documentation was not read.
- **L321**, "model versions and search settings are not documented": the Bek page gives no model versions and does not say the surfaces share one query set. It does state that prompts run through "the free, publicly available web interfaces" and that locale mirrors its keyword database, which is some documentation of settings.
- **L933**, "Items 1, 2, 9 and 10 share their access-date, parameter, access-path and data-sharing items": consistent with Hölzl's Table 5. Alibudbud's Table 1 has dates and parameters only.
- **L22, L291, L293** report plain Cohen's kappa with no citation. The only Cohen entry in the list is the 1968 weighted-kappa paper, cited at L908 for a planned analysis.

### Tier notes

- Chen 2025 (arXiv preprint) and Hendricks 2026 (self-published first-party data set) carry findings at L81 with no label at point of use. OtterlyAI in the same sentence is labelled a vendor index.
- Grossman 2026 can be upgraded to its peer-reviewed version.
- Eloundou 2025 is peer-reviewed, but its authors evaluate their employer's own models.

### Control tests run

| Lookup | Known-good result | Negative control |
|---|---|---|
| Crossref by DOI | 10.1038/s41586-021-03819-2 returned the AlphaFold record | Invented DOI returned 404 |
| arXiv by id | 1706.03762 returned "Attention Is All You Need" | Not run |
| OpenAlex title search | "Attention Is All You Need" ranked first of 182 | Invented title returned 0 |
| DataCite by DOI | Zenodo DOIs returned records | Invented DOI returned 404 |
| Full-text absence searches | Same pattern found "Google Analytics" in Alibudbud and "Google Ads" and "Statcounter" in Hölzl | A first pattern silently missed line-start matches and was replaced |

### NOT VERIFIED

- Belkin 1982 full text (item 7 above).
- Cook 2025 content: SSRN returned 403. No content claim depends on it.
- The SEC copy of the Costco release returned 403; the figures were read from the company's own PDF.
- Font-Julián 2026 was read in the publisher-formatted PDF from the repository, paginated 1–14. I did not open the issue-paginated version; the section structure should be identical.
- Whether the Ahrefs and Bek pages read the same on the manuscript's access dates as today. No archive comparison was made.
- DBLP and the ACM Digital Library were not used; DBLP returned a bot challenge. Crossref, OpenAlex and Semantic Scholar stood in.

### DO NOT ASSERT

- RESOLVED means the entry exists and its metadata matches, not that the source's findings are correct.
- SUPPORTED on "abstract only" rows means the abstract states the claim; the full text was not read for those.
- COULD NOT VERIFY is not a pass.
- This report covers R1 to R33 only and says nothing about the other 64 references.

Downloaded source copies are in `/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad`.

Sources:
- [Costco fourth quarter and fiscal year 2026 results (company PDF)](https://s201.q4cdn.com/287523651/files/doc_news/Costco-Wholesale-Corporation-Reports-Fourth-Quarter-and-Fiscal-Year-2026-Operating-Results-2026.pdf)
- [Costco Form 8-K exhibit (found by search, not opened: 403)](https://www.sec.gov/Archives/edgar/data/0000909832/000090983226000084/costex9918-k92426.htm)
- [Belkin, Oddy & Brooks repository record (found by search, not opened)](https://surface.syr.edu/istpub/150)
- [Font-Julián et al. 2026 open copy](https://riunet.upv.es/handle/10251/236956)
- [Grossman et al., SIGIR '26 version of record](https://doi.org/10.1145/3805712.3809667)
- [Google Search Status Dashboard, August 2026 spam update](https://status.search.google.com/incidents/LEubPCm2octf2uMqCFKE)
- [Pew, AI summaries and clicks](https://www.pewresearch.org/short-reads/2025/07/22/google-users-are-less-likely-to-click-on-links-when-an-ai-summary-appears-in-the-results/)
- [Pew, Americans' Social Media Use 2025](https://www.pewresearch.org/internet/2025/11/20/americans-social-media-use-2025/)
- [Data & Society, Data Voids](https://datasociety.net/library/data-voids-where-missing-data-can-easily-be-exploited/)
- [Hannak et al. 2013, author-hosted PDF](https://www.ccs.neu.edu/home/cbw/static/pdf/fp039-hannak.pdf)
- [Hölzl et al. 2025, MADOC copy](https://madoc.bib.uni-mannheim.de/68637/1/1-s2.0-S0049089X24001212-main.pdf)
- [Alibudbud 2023, Frontiers full text](https://www.frontiersin.org/journals/big-data/articles/10.3389/fdata.2023.1199060/full)
- [Allaham & Diakopoulos 2026, AIES](https://ojs.aaai.org/index.php/AIES/article/view/43129)
- [Hendricks, The Answer Index](https://hendricks.ai/research/the-answer-index)
- [Ahrefs Brand Radar methodology](https://ahrefs.com/blog/brand-radar-methodology/)
