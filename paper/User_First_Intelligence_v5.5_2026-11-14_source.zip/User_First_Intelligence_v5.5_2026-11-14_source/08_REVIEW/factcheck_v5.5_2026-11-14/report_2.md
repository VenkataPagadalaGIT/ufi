# Fact-check report 2 of 3: references R34 to R65 (manuscript v5.5, 14 November 2026)

Returned as text by the checking agent, whose harness could not write files; saved here unedited.

**`report_2.md` was not written.** My harness bars me from writing report files, so the full report is returned here as text, as your fallback allows. Nothing in the project was modified by me.

Two things to know first:
- **The manuscript changed while I worked.** `manuscript_v50.md` was edited at 16:41 (two lines inserted at 185–186), so every worklist line above 184 is now +2 (L349 is now 351, L353 is 355, L508 is 510, L768 is 770, L782 is 784, L884 is 886, L908 is 910, L933 is 935). I confirmed all 17 citing lines and the reference block are textually unchanged. Line numbers below are the worklist's.
- **One entry now has a peer-reviewed version.** Huang et al. 2026 is cited as an arXiv preprint but was published in Findings of EMNLP 2026 in October.

## Counts

- References checked: 32 (R34 to R65). All 32 resolve to live sources; no entry is fabricated or mismatched.
- Citing sentences checked: 45.
  - SUPPORTED: 34
  - PARTLY: 9
  - NOT SUPPORTED: 0
  - COULD NOT VERIFY: 2
- Entries with at least one printed element differing from the source record: 16 (all minor; 16 entries have no difference).

## Entry-level differences

1. **R35 Huang 2026.** The entry cites arXiv:2603.16138. The paper is now published.
   - Correct value: *Findings of the Association for Computational Linguistics: EMNLP 2026*, pp. 147–162, DOI 10.18653/2026.findings-emnlp.8, https://aclanthology.org/2026.findings-emnlp.8/ (dated 2026/10).
   - The DOI has no "v1/" segment; the "v1" form returns 404 at Crossref.
   - Authors, title, year and abstract are identical to arXiv v2 (28 Aug 2026).
2. **R38 Kakimov 2026.** Author order differs between the PMLR index page and the PDF.
   - Entry and PMLR page/BibTeX: Kakimov, Tan, Gillham, Bejtic.
   - PDF byline: Kakimov, Gillham, Bejtic, Tan.
   - Volume 318 and pp. 224–235 match.
3. **R40 Keet 2016.** LNCS volume number is omitted (it is 9678). Springer's book title is "The Semantic Web. Latest Advances and New Domains" (full stop, not colon). Pages and DOI match.
4. **R44 Kirsten 2026.** No change needed. The PDF byline reads "Jost Grosse Perdekamp", as printed. ACL Anthology and Crossref record him as "Jost Große Perdekamp", filed under family name "Perdekamp".
5. **R45 Kostygina 2023.** Crossref and PubMed Central give the bylines as "Zachary Seeskin" and "Felicia LeClere", without the middle initials "Z. H." and "F. B." that the entry prints.
   - The initials appear only on OpenAlex author profiles; the SAGE page returned 403, so I did not see the typeset byline.
   - The article number 20563051231216947 is omitted (the journal has no page numbers).
6. **R47 Langridge 2016.** The printed URL redirects to https://www.screamingfrog.co.uk/blog/how-accurate-are-website-traffic-estimators/ (the "/blog/" segment is missing). Date, author and title match.
7. **R49 Le Pochat 2019.** No DOI is printed; it is 10.14722/ndss.2019.23386. Crossref's container is "Proceedings 2019 Network and Distributed System Security Symposium" (the 26th). Authors, title and year match.
8. **R50 Lee 2026.** 10.5281/zenodo.18653093 is a Zenodo concept DOI covering eight versions. It currently resolves to version 6 (record 19831300, DOI 10.5281/zenodo.19831300, issued 27 April 2026). Author, title and year match.
9. **R52 Linehan 2025.** The page byline and structured data name only Louise Linehan as author. Xibeijia Guan is listed under "Contributors", not as co-author. Date, title and URL match.
10. **R54 Liu 2012.** Subtitle omitted. Full title: "When web search fails, searchers become askers: understanding the transition".
11. **R55 Luggen 2019.** No DOI is printed; it is 10.1007/978-3-030-30793-6_26. The container is abbreviated; in full it is "The Semantic Web – ISWC 2019" (LNCS). Crossref joins the subtitle with an em dash (U+2014) where the entry has a colon. Pages match.
12. **R57 Morris 2010.** Subtitle omitted. Full title: "What do people ask their social networks, and why? A survey study of status message Q&A behavior".
13. **R59 OtterlyAI 2026.** The page names an individual author, Rick Tousseyn.
    - Page title: "The AI Search Index: What ChatGPT, Gemini, Perplexity and Google Actually Cite in 17 Industries"; the entry's "AI search index" is a shortening.
    - 8 September 2026 is both the publication and the last-modified date.
14. **R62 Pagadala 2026b.** No change needed. Page metadata gives publication and modification date 14 November 2026, the same day as the entry's retrieval date. The page's own suggested citation uses the entry's title.
15. **R63 Piccardi 2018.** No DOI is printed; it is 10.1145/3209978.3209984. The venue in full is "The 41st International ACM SIGIR Conference on Research & Development in Information Retrieval". Pages match.
16. **R65 Punturo 2026.** The printed URL redirects to https://www.tryprofound.com/blog/enhanced-citation-categories (adds "www."). Authors, date and title match.

Not entry errors, but worth seeing:
- **R61 Pagadala 2026a (the page, not the entry).** The page's source list dates the Motley Fool transcript "September 24, 2026". The transcript was published 29 September 2026; the call was 24 September. The manuscript's R60 entry has both dates right.
- **In-text key style.** "Lebo et al. 2013" and "Punturo et al. 2026" are three-name sources keyed with "et al.". Other three-author sources are keyed in full (for example "Jansen, Jung & Salminen 2022").

No difference found: R34, R36, R37, R39, R41, R42, R43, R46, R48, R51, R53, R56, R58, R60, R61, R64.

## Everything not SUPPORTED

Ordered by how far the sentence departs from the source. There are no NOT SUPPORTED items.

**1. R38 Kakimov 2026, L81: PARTLY**
- Manuscript: "and Google's AI Overviews on "your money or your life" queries drawn from MS MARCO Web Search, which cited AI-generated documents more often than human-authored ones at the same retrieval rank [Kakimov et al. 2026]."
- Supported: the system, the query class, the dataset, and the direction of the finding. The abstract says AI-generated documents "are cited more frequently than human-authored documents even after controlling for retrieval rank".
- Not supported: "at the same retrieval rank". The paper compares within cumulative top-k cutoffs, not rank by rank.
  - At rank 1 the order is reversed: "at k = 1, the probability is slightly higher for Human documents than for AI documents (59.57% vs. 58.02%)".
  - Beyond about the top 50 the two converge.
  - Among retrieved documents overall, "retrieved citation probabilities are nearly identical for AI and Human documents"; the gap is "driven primarily by non-retrieved citation events".
- Proposed wording: "which cited AI-generated documents more often than human-authored ones even after controlling for retrieval rank".
- Tier note: two of the four authors are at Originality.ai Inc., whose detector supplies the "AI-generated" label. The manuscript does not flag this.

**2. R52 Linehan 2025, L81: PARTLY**
- Manuscript: "vendor measurement across 15,000 prompts reports that only 12% of URLs cited by ChatGPT, Gemini and Copilot rank in Google's top ten for the same prompt, with Perplexity at 28.6% [Linehan & Guan 2025]."
- Supported: every number is on the page, and the page's summary says "only 12% of links cited by ChatGPT, Gemini, and Copilot appear in Google's top 10 results for the same prompt".
- Not supported: the page's own arithmetic shows the 12% already includes Perplexity: "((28.6 + 8 + 6.1 + 8.6 + 8.2) / 5) = 11.9%". For the others, "that number hovers around 8%". Setting 12% for the three beside 28.6% for Perplexity counts Perplexity twice.
- Proposed wording: "vendor measurement across 15,000 prompts reports that on average only 12% of the URLs cited by ChatGPT, Gemini, Copilot and Perplexity rank in Google's top ten for the same prompt: 28.6% for Perplexity and about 8% for the others".

**3. R35 Huang 2026, L81: PARTLY**
- Manuscript: "five systems including Google AI Overviews on 11,000 real queries, with Wikipedia over-represented and social media under-represented among cited sources [Huang et al. 2026];"
- Supported: five systems, Google AI Overviews, 11,000 real queries.
- Not supported as worded: the over- and under-representation is about how much of a cited source's content reaches the generated summary, not its share of citations.
  - The paper says "Wikipedia is both the most-cited and most over-represented source".
  - The social-media result is reported for Google AI Overviews only: "social media and forum sources (Reddit, Quora) are under-covered by 22.1pp in Google AIO".
  - Search GPT and Perplexity cite almost no social sources (0.1% and 0.0% of cited domains), so no estimate is given for them.
- Proposed wording: "five systems including Google AI Overviews on 11,000 real queries, with Wikipedia the most-cited domain and over-represented in the generated summaries, and cited social media under-represented in the summaries of Google's AI Overviews".

**4. R40 Keet 2016, L782: PARTLY** (Keet's part only; Wiśniewski et al. 2019 is in another worklist)
- Manuscript: "as in test-driven ontology development, which tests a question against the ontology's vocabulary and separately against its instances [Keet & Ławrynowicz 2016; Wiśniewski et al. 2019]"
- Supported: a separate vocabulary check. Step 3 of the procedure is "check the vocabulary elements of x are in ontology O (itself a TDD test)".
- Not supported: a separate test against the ontology's instances. The paper offers two alternative routes for the same axiom test: "a test at the TBox-level or always using individuals explicitly asserted in the ABox". The individuals are temporary mock individuals, created for the test and then deleted.
- Proposed wording: "as in test-driven ontology development, which first checks that a question's vocabulary is present in the ontology and then tests whether the ontology entails the answer, at the schema level or through individuals".

**5. R64 Prantl 2018, L77: PARTLY** (abstract only; Emerald returned 403)
- Manuscript: "Comparisons of estimators with first-party analytics have found large and variable errors: Compete and Quantcast underestimated traffic for 18 sites, with occasional overestimates [Kamerer 2013], and neither Alexa nor SimilarWeb ranked Czech websites accurately, although both indicated their approximate size [Prantl & Prantl 2018]."
- Supported by the abstract: "neither tool can accurately determine the ranking of websites on the internet. However, it is possible to approximately determine the significance of a particular website."
- Not confirmed: that the baseline was first-party analytics. The abstract says only "accurate traffic data values". Jansen et al. 2022 describe the baseline as NetMonitor, which "uses a combination of site and user-centric measures".
- The source's word is "significance", not "size".
- Proposed wording: see item 6, which covers the same sentence.

**6. R39 Kamerer 2013, L77: PARTLY** (same sentence as item 5)
- Supported: an 18-site panel, underestimates by both services, occasional overestimates.
- Not supported: "for 18 sites" as applied to Quantcast. The full text says "conclusions should be tentative, since Quantcast measured only eight of 18 Web sites". Compete covered 18, 17 and 16 sites in the three months.
- Proposed wording for the whole sentence: "Comparisons of estimators with first-party analytics or reference traffic data have found large and variable errors: Compete and Quantcast underestimated traffic in a panel of 18 sites (Quantcast reported on eight of them), with occasional overestimates [Kamerer 2013], and neither Alexa nor SimilarWeb ranked Czech websites accurately, although both indicated a site's approximate significance [Prantl & Prantl 2018]."

**7. R65 Punturo 2026, L81: PARTLY**
- Manuscript: "19.4% against 5.3% across 15 industries [Punturo et al. 2026]"
- Supported: "Perplexity cites social at 19.4% compared to ChatGPT at 5.3%."
- Not supported: "across 15 industries". The page has a separate table with 15 industry rows, but never says the platform figures are computed across those 15 or that the data are limited to them.
- The page describes its data as "27 million citations across ChatGPT, Gemini, and AI Overviews", which does not name Perplexity although the table reports it.
- Proposed wording: "19.4% against 5.3% in a report that also breaks citations down for 15 industries". Alternatively, drop "across 15 industries".

**8. R50 Lee 2026, L81: PARTLY** (minor)
- Manuscript: "query intent and Google rank as predictors of citation across four chat assistants and eight verticals [Lee 2026];"
- Supported: four assistants (ChatGPT, Claude, Perplexity, Gemini), and eight verticals for the intent study: "n = 19,556 queries across 8 verticals".
- Not supported: eight verticals for the Google-rank analysis. The full text (v6) says "We selected 120 queries across 10 commercial verticals", a different set, and that study used ChatGPT and Perplexity only.
- Proposed wording: "query intent and Google rank as predictors of citation across four chat assistants, with intent classified in eight verticals and rank tested in ten".

**9. R62 Pagadala 2026b, L349: PARTLY**
- Manuscript: "The author analysed and published the collection, with different source categories, before it was read for this paper [Pagadala 2026b], so nothing here was predicted and this subsection is a replication read after the fact."
- Supported: the page is live and publishes an analysis of the same collection (3,724,208 answers, 13 countries, 44 export files, 17 August to 14 November 2026, 1,492 France answers missing). It uses its own source kinds (Video, Education sites, Government, Schools and universities, Wikipedia, Social, Forums and Q&A, Reference, Other websites).
- Not verifiable from the page: "before it was read for this paper". The page is dated 14 November 2026 with no time of day, the same day as the retrieval date. The repository's commit order is consistent with the claim (study pulled in at 14:55, Section 7.7 added at 15:27), but that is internal evidence.
- Proposed wording: "The author analysed and published the collection, with different source categories, on 14 November 2026 [Pagadala 2026b], before it was read for this paper, so nothing here was predicted".

**10. R64 Prantl 2018, L22: COULD NOT VERIFY**
- Manuscript: "a practice the validity studies in Section 2 caution against [Kamerer 2013; Prantl & Prantl 2018; Jansen, Jung & Salminen 2022]."
- Opened: the abstract only (Crossref, OpenAlex). Emerald returned 403, and the University of West Bohemia repository record has no file.
- The abstract is consistent: "it is still not possible to accurately estimate website traffic of any website in the world". It contains no explicit caution about single-vendor figures or uncertainty. Kamerer and Jansen do contain one (full text read).
- Proposed wording if the full text cannot be checked: "a practice the validity studies in Section 2 caution against [Kamerer 2013; Jansen, Jung & Salminen 2022] or show to be unreliable [Prantl & Prantl 2018]".

**11. R41 Kendall 1938, L884: COULD NOT VERIFY**
- Manuscript (table row): "Spearman and Kendall [Kendall 1938] between the two instruments' visits".
- Opened: the Crossref record only (title "A new measure of rank correlation", Biometrika 30(1–2), 81–93). OUP returned 403 and no open abstract exists.
- The attribution is consistent with the title and with MathWorld's Kendall tau entry, which gives this paper as its reference. No wording change proposed.

## Rest of the report (what would have been in the file)

### Scope

- Checked: 32 entries, 45 citing sentences, and the figures the manuscript takes from the two author pages. Accessed 14 November 2026.
- I searched the manuscript for every author name and found no citing sentence the worklist missed.
- No direct quotations from these sources appear in the 45 sentences, so there was nothing to check verbatim beyond numbers.
- Not checked: co-cited sources outside R34 to R65 (for example Wiśniewski, Scheitle, Tinuiti, Costco's press release).

### Verification table

Tier: T2 peer-reviewed; T3 standards body; T4 preprint, vendor, trade press or self-published.

| Ref | Line | Claim | Verdict | Evidence | Tier |
|---|---|---|---|---|---|
| R34 Hu & Liu 2004 | L87 | Reviews mined for aspects and opinions | SUPPORTED | Abstract only: "we only mine the features of the product on which the customers have expressed their opinions and whether the opinions are positive or negative". | T2 |
| R34 | L91 | Aspect mining of reviews | SUPPORTED | Abstract: "mining product features that have been commented on by customers". | T2 |
| R35 Huang 2026 | L22 | Audited on real search queries | SUPPORTED | Abstract: "We examine responses to 11,000 real search queries across five systems". | T2 (entry cites preprint) |
| R35 | L81 | Wikipedia over-, social under-represented among cited sources | PARTLY | Full text. See item 3. | T2 |
| R35 | L91 | Cited sources compared on an author-chosen query set | SUPPORTED | Full text, Section 3: "we randomly sampled 1,000 queries per topic, yielding a balanced set of 11,000 queries". | T2 |
| R36 Jansen 2022 | L22 | Cautions against point figures from one vendor | SUPPORTED | Full text: values "should not be viewed necessarily as 'truth.' Rather, the values are reported measures with some error rates (+/-)". | T2 |
| R36 | L77 | 86 sites: level differences, correlated ranks, systematic gaps | SUPPORTED | Abstract: "website rankings ... for all metrics are significantly correlated"; "the differences ... are systematic". | T2 |
| R36 | L91 | Estimator vs first-party analytics, many sites, one time | SUPPORTED | Abstract: "one year's average monthly data for 86 websites". The "one time" is a 12-month window averaged into one cross-section. | T2 |
| R37 Järvelin 2002 | L908 | nDCG at k | SUPPORTED | Abstract only: "The third one computes the relative-to-the-ideal performance of IR techniques". The acronym is not in the abstract. | T2 |
| R38 Kakimov 2026 | L81 | AI-generated cited more at the same rank | PARTLY | Full text. See item 1. | T2 (two vendor authors) |
| R39 Kamerer 2013 | L22 | Cautions against the practice | SUPPORTED | Full text: "Competitive analysis tools demand that you interpret with caution. Triangulate with other data sources or time periods." | T2 |
| R39 | L77 | Compete and Quantcast underestimated for 18 sites | PARTLY | Full text. See item 6. | T2 |
| R40 Keet 2016 | L67 | Competency questions written against an ontology | SUPPORTED | Chapter text on Springer: procedure begins "input: CQ into axiom, axiom, or template into axiom". | T2 |
| R40 | L782 | Tests against vocabulary and separately instances | PARTLY | Chapter text. See item 4. | T2 |
| R41 Kendall 1938 | L884 | Kendall rank correlation | COULD NOT VERIFY | See item 11. | T2 |
| R42 Khosravi 2026 | L77 | Processing can shrink, inflate or reverse an effect | SUPPORTED | Abstract and full text: "this error can attenuate, amplify, or reverse estimated treatment effects". | T4 preprint |
| R43 Kim 2016 | L933 | Reporting standard, commercial intermediaries, no SEO tool named | SUPPORTED | Full text (PMC4788740): "we propose a checklist"; data "from Gnip, Inc., licensed to provide access to the full stream". No SEO or web-analytics tool found by search. | T2 |
| R44 Kirsten 2026 | L81 | Five systems, three providers, comparable coverage | SUPPORTED | Section 5.3.2: "Across datasets, generative engines achieve coverage comparable to Organic search". | T2 |
| R45 Kostygina 2023 | L933 | Disclosure standards, intermediaries, no SEO tool named | SUPPORTED | Full text (PMC10795517, author manuscript): "A checklist of disclosure elements to meet minimal reporting standards is proposed". Names CrowdTangle, PowerTrack, ChatGPT, Google Trends only. | T2 |
| R46 Kumar 2026 | L81 | 100,000+ responses, 100+ brands, 78% corporate, YouTube leads | SUPPORTED | Abstract: "about 78% go to corporate websites; among non-corporate sources YouTube leads, ahead of Reddit, editorial media, and Wikipedia". | T4 (author co-founded the tool) |
| R47 Langridge 2016 | L77 | 25 sites; two tools below GA by 17% and 30% | SUPPORTED | Page: Ahrefs "underestimating total traffic for all sites by 17%"; "SEMRush underestimated total traffic for all sites by 30%". UK organic traffic only. | T4 agency |
| R48 Lebo 2013 | L68 | Provenance-typed statements | SUPPORTED | W3C abstract: "a set of classes, properties, and restrictions that can be used to represent and interchange provenance information". | T3 |
| R49 Le Pochat 2019 | L77 | Ranking built to be stable and hard to manipulate | SUPPORTED | Full text (arXiv 1806.01156v3): "it varies only by 0.6% daily and requires at least the quadrupled manipulation effort". Motivation is credited to its own analysis. | T2 |
| R50 Lee 2026 | L81 | Four assistants and eight verticals | PARTLY | Full text v6. See item 8. | T4 preprint |
| R50 | L91 | Author-chosen industries | SUPPORTED | Full text: "We assembled a corpus of 19,556 queries across 8 commercial verticals". | T4 |
| R51 Li 2024 | L22 | Audited on public-interest queries | SUPPORTED | Abstract only: "establish authority for topics of public importance". | T2 |
| R51 | L81 | ChatGPT, Bing Chat, Perplexity; sources classified | SUPPORTED | Abstract: "sentiment analysis, inductive coding, and source classification". | T2 |
| R52 Linehan 2025 | L81 | 12% for three assistants, Perplexity 28.6% | PARTLY | Page. See item 2. | T4 vendor (labelled) |
| R53 Liu 2023 | L81 | Citations audited for support | SUPPORTED | Abstract: "only 74.5% of citations support their associated sentence". | T2 |
| R54 Liu 2012 | L85 | Questions go to Q&A sites when search fails | SUPPORTED | Abstract only: "trace the transformation of a large number of failed searches into questions posted on a popular CQA site". | T2 |
| R55 Luggen 2019 | L89 | Study of knowledge-base completeness | SUPPORTED | arXiv 1909.01109 abstract: "Our method is able to estimate the completeness of a class". | T2 |
| R55 | L768 | Estimators measure what a KB lacks | SUPPORTED | Same abstract: "statistical techniques for class cardinality estimation". | T2 |
| R56 Martinez 2026 | L81 | 45 studies; gains establish neither; two levers | SUPPORTED | Abstract and full text: "they establish neither organic discoverability nor durable traffic effects". | T4 preprint |
| R57 Morris 2010 | L85 | People take questions to social networks | SUPPORTED | Abstract only: "We conducted a survey of 624 people". | T2 |
| R58 Nuti 2014 | L933 | Google Trends checklist; no SEO tool named | SUPPORTED | Full text: "we developed a checklist to improve the quality and reproducibility of studies that use Google Trends". | T2 |
| R59 OtterlyAI 2026 | L81 | 6,095,520 citations, seven engines, 17 undefined industries | SUPPORTED | Page: "That produced 6,095,520 citations". It names 16 industries in passing and defines none. The linked interactive report was not opened. | T4 vendor (labelled) |
| R60 Motley Fool 2026 | L508 | CFO: triple digits, second quarter, low base | SUPPORTED | Transcript: "Traffic to our site from AI search grew triple digits for the second consecutive quarter". | T4 transcript |
| R61 Pagadala 2026a | L508 | Author's reading: a measured sales channel | SUPPORTED | Page live (HTTP 200), dated October 1, 2026: "AI answers are now a sales channel that a retailer of Costco's size measures". | T4 author's page |
| R62 Pagadala 2026b | L349 | Published before being read for the paper | PARTLY | Page live. See item 9. | T4 author's page |
| R62 | L353 | Roughly one answer in ten off-topic | SUPPORTED | Page: "So roughly one answer in ten is not about education." Sample of 5,136 answers, labelled by AI models (12.3% and 8.8%). | T4 |
| R63 Piccardi 2018 | L89 | Gap discovery for encyclopedias | SUPPORTED | arXiv 1804.05995 abstract: "recommending what sections to add to already existing or newly created Wikipedia articles". | T2 |
| R63 | L768 | Sections from similar articles; about 80% precision | SUPPORTED | Abstract: "achieving precision@10 of about 80% in the human evaluation". The metric is precision@10. | T2 |
| R64 Prantl 2018 | L22 | Cautions against the practice | COULD NOT VERIFY | See item 10. | T2 |
| R64 | L77 | Neither ranked Czech sites accurately | PARTLY | Abstract. See item 5. | T2 |
| R65 Punturo 2026 | L81 | 19.4% vs 5.3% across 15 industries | PARTLY | Page. See item 7. | T4 vendor (labelled) |

### Source-tier notes

- Vendor and agency sources are labelled at point of use in the manuscript (Langridge, Linehan, OtterlyAI, Punturo, Kumar).
- Three preprints carry findings without a "preprint" label in the sentence: Khosravi, Martinez, and Lee. Lee's PDF says "Not yet peer-reviewed" and its author is at a consultancy.
- Kakimov is peer-reviewed, but its key label comes from a co-author's commercial detector (item 1).

### Control tests run

- **Crossref:** 10.1038/s41586-021-03819-2 returned HTTP 200 with the AlphaFold record; an invented DOI returned 404.
- **arXiv:** 1706.03762 returned "Attention Is All You Need" in the same call as the four cited ids.
- **DataCite:** an existing Zenodo DOI returned 200; an invented one returned 404.
- **OpenAlex title search:** a known title ranked first; an invented title returned count 0.
- **Fetch failures and workarounds:**
  - w3.org and proceedings.mlr.press failed once and succeeded on retry.
  - jmir.org returned an empty HTTP 202, so Kim was read from Europe PMC.
  - Europe PMC returned 503 for Kostygina, so it was read through NCBI efetch.
  - SAGE, Emerald and OUP returned 403.

### NOT VERIFIED

- Kendall 1938 and Prantl 2018 full texts (paywalled). Library access to the PDFs would settle both.
- Hu & Liu 2004, Järvelin 2002, Liu 2012, Morris 2010, Li & Sinnamon 2024: verdicts rest on abstracts; publisher full texts were not opened.
- Kostygina 2023: read as the NIH author manuscript, not SAGE's version of record.
- OtterlyAI's interactive industry report (a vendor dashboard, out of bounds by your rules): whether it defines the 17 industries.
- Ahrefs chart images: which of 8.6% and 8.2% is Gemini and which is Copilot.
- The time of day the education page went live on 14 November.

### DO NOT ASSERT

- SUPPORTED means the source says what the sentence attributes to it, not that the source's finding is correct.
- An abstract-only SUPPORTED could still be qualified by the full text, as happened with Kamerer, Lee and Kakimov.
- COULD NOT VERIFY is not a pass.
- This report covers R34 to R65 only.

### Files

- Worklist: `/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/factcheck_v5.5_2026-11-14/worklist_2.md`
- Manuscript (modified by someone else at 16:41 during this check): `/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/06_MANUSCRIPT/src/manuscript_v50.md`
- Intended report path, not written: `/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/factcheck_v5.5_2026-11-14/report_2.md`
- Downloaded source texts and API responses: `/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad`

Sources:
- [ACL Anthology: Answer Bubbles (Findings of EMNLP 2026)](https://aclanthology.org/2026.findings-emnlp.8/)
- [PMLR v318: Kakimov et al.](https://proceedings.mlr.press/v318/kakimov26a.html)
- [Ahrefs: Only 12% of AI cited URLs rank in Google's top 10](https://ahrefs.com/blog/ai-search-overlap/)
- [Profound: Enhanced citation categories](https://www.tryprofound.com/blog/enhanced-citation-categories)
- [First Monday: Kamerer 2013](https://firstmonday.org/ojs/index.php/fm/article/view/3986)
- [Springer: Keet and Ławrynowicz 2016](https://link.springer.com/chapter/10.1007/978-3-319-34129-3_39)
- [Zenodo: Lee 2026, version 6](https://zenodo.org/records/19831300)
- [PLOS ONE: Jansen, Jung and Salminen 2022](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0268212)
- [MathWorld: Kendall Tau](https://mathworld.wolfram.com/KendallTau.html)
- [arXiv: Tranco, 1806.01156](https://arxiv.org/abs/1806.01156)
