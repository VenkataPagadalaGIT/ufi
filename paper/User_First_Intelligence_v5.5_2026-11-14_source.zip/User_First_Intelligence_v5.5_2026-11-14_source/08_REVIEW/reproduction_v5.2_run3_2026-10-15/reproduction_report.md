# Independent reproduction, run 3: User First Intelligence v5.2 source bundle

Reproducer: a separate AI agent working only from the released bundle, 15 October 2026. Report folder: `08_REVIEW/reproduction_v5.2_run3_2026-10-15/` (check scripts in `checks/`, every output in `outputs/`, the command log in `command_log.txt`). The run-1 and run-2 reports, in the working project and inside the bundle, were not read; the bundle's run-2 tally was opened only to check the figures Section 14 quotes from it.

## 1. Environment and bundle

**Environment:** Python 3.13.2 (`/opt/homebrew/opt/python@3.13/bin/python3.13`), numpy 2.4.1, scipy 1.17.1, pandas 3.0.0, matplotlib 3.11.1, openpyxl 3.1.5; tectonic 0.17.0; pandoc 3.9.0.2; poppler `pdftotext` and `pdfinfo`; macOS (Darwin 24.4.0, arm64). `xelatex` is not installed, so `build_tex.py` used tectonic, as its code provides. The OpenTimestamps client `ots` is not installed. A `ufi` package happens to be installed in this machine's user site-packages. The three review scripts imported it before stopping on the missing licensed export; no result in this report depends on it.

**Bundle:** `User_First_Intelligence_v5.2_2026-10-15_source.zip`, SHA-256 `a23d25be9ea3cd5022232ad87e9ed5ca8dfba1beabd30d9d10219eee11aa33c5`. This matches the hash the caller gave, on the original and on the copy. The bundle holds 212 files.

**Procedure:** I copied the zip into a fresh scratch folder and extracted it three times:

- `bundle/`: pristine, never written. Its SHA-256 manifest was identical before and after the run (`outputs/pristine_sha256.txt`, `outputs/pristine_sha256_after.txt`).
- `run/`: every script ran here.
- `build_run/`: the paper build, from an untouched copy.

Each edit record ran in its own throwaway copy. Nothing came from the author's working project. My own check scripts (in `checks/`) ran with `python3 -I` (`-P` where they needed the user-site pypdf or python-docx), with paths passed as arguments.

At the end of the run the bundle zip in `06_MANUSCRIPT/` still had the same SHA-256. `git status` showed other uncommitted changes in the working project, made during this run but not by it: `src/manuscript_v50.md`, `03_DATA/instrument_series_table2_visits_by_month.csv`, `arxiv_abstract.txt`, new `edit_v52p.py` and `edit_v52q.py`, measurement files and `09_SUBMISSION/` files. This reproduction wrote only into its own report folder and the scratch folder, and it describes the bundle with the hash above, not the current working files.

```
/Users/venkatapagadala/.pyenv/shims/python3
Python 3.13.2
numpy 2.4.1 scipy 1.17.1 pandas 3.0.0 matplotlib 3.11.1
openpyxl 3.1.5
ufi importable at /Users/venkatapagadala/Library/Python/3.13/lib/python/site-packages/ufi/__init__.py
/opt/homebrew/bin/tectonic
Tectonic 0.17.0
xelatex: not found
/opt/homebrew/bin/pandoc
pandoc 3.9.0.2
ots: not found
Darwin Venkatas-MacBook-Pro.local 24.4.0 Darwin Kernel Version 24.4.0: Fri Apr 11 18:33:40 PDT 2025; root:xnu-11417.101.15~117/RELEASE_ARM64_T6031 arm64
/opt/homebrew/opt/python@3.13/bin/python3.13
numpy 2.4.1 /opt/homebrew/lib/python3.13/site-packages/numpy/__init__.py
scipy 1.17.1 /opt/homebrew/lib/python3.13/site-packages/scipy/__init__.py
pandas 3.0.0 /opt/homebrew/lib/python3.13/site-packages/pandas/__init__.py
matplotlib 3.11.1 /opt/homebrew/lib/python3.13/site-packages/matplotlib/__init__.py
```

## 2. Findings

1. **Everything that can run on the released files ran, and all but one output with a shipped counterpart reproduced byte for byte.** The exception is the Table 2 series CSV (finding 3). The figure PDFs differ only in their `/CreationDate` stamp; every PNG is identical.
2. **The paper builds from the bundle.**
    - `build_tex.py` writes a `build/paper.tex` byte-identical to the shipped `paper.tex` (SHA-256 `5771787136...a183b047`).
    - tectonic compiles it to a 33-page PDF with no errors.
    - `build_docx.sh` writes a DOCX with all nine figures and twelve tables.
    - The built PDF and DOCX carry the manuscript's values, including the corrected Table 2 day count.
3. **Numbers:** 1,696 quoted values were checked: 1,555 MATCH, 7 MISMATCH, 134 CANNOT RUN. The seven mismatches are three problems:
    - **The topic-level correlation is quoted as +0.19; the released data give +0.18.** This is the Spearman correlation over the 1,008 mentioned labels. It is quoted as +0.19 in the Abstract, Section 6 (paragraph 2), Section 15, Table D1, and the title of Figure 6(a); `arxiv_abstract.txt` says 0.19. The released per-label counts give 0.184869. `m2_from_counts.py` prints this as +0.185, and to two decimals it is **+0.18**. The +0.19 is a double rounding (0.18487 to 0.185 to 0.19), and it is also hard-coded in the title string of `make_fig_reviews_v50.py`.
    - **The all-labels interval is quoted as +0.26 to +0.29; its upper end is +0.28.** In Section 6 (paragraph 2), "+0.27 (+0.26 to +0.29)": the upper end is 0.284982, printed +0.285, which is **+0.28** to two decimals. Same double rounding.
    - **The released Table 2 CSV is stale.** `instrument_divergence_extra/instrument_series_table2_visits_by_month.csv` still gives October's days-live as "11 (77 cumulative)". The manuscript's Table 2, corrected by `edit_v52n.py` after run 2, reads "11 (78 in all, days 0 to 77)". Rerunning `instrument_extra.py` regenerates the CSV from the manuscript with the corrected text, so the shipped file was not refreshed after the last edit. Section 14 calls this item "now corrected": it is corrected in the paper, but not in the released CSV the same section describes.
    - None of the three changes a conclusion.
4. **Values that could not be checked:**
    - **109 come only from the saved outputs of scripts that need withheld inputs.** These are the licensed DataForSEO review export (`analyze_reviews.py`, `supplement_r10.py`, `r2_link_sample.py`), the raw Ahrefs Brand Radar exports (`cross_sector_sensitivity.py`, `cross_sector_sensitivity2.py`) and the unreleased pilot section. The paper agrees with every one of those saved outputs.
    - **25 rest on material that is not in the bundle.** This covers the `ufi` repository and package (the 4/5 and 70.4% rates, digests, commit facts, rubric grades and the 0.22 tie value), the numbering-plan registry, the held-back Study R1 files, the second-domain protocol and the Bitcoin block time.
    - **One dashboard read is in no released file:** zero live referring domains "through 31 July" (Section 10). README.txt and Appendix A say every quoted single dashboard read is in a released data file.
5. **Smaller observations:**
    - README.txt describes the edit records as running "to edit_v52m.py", but the bundle also holds `edit_v52n.py` and `edit_v52o.py`.
    - The build log has one overfull line of 67.7 pt in Section 13: the long file name `02_DESIGN/framework_retro_test_381_amendment_2026-10-15.md` runs into the margin.
    - **Study R1 timestamps:**
        - The manifest's OpenTimestamps proof commits to the released manifest. It is anchored in Bitcoin block 971,506 with the merkle root the folder README quotes. A public block explorer gives that block's header time as 04:05:42 UTC on 15 October 2026 (an external check, outside the bundle).
        - The amendment's proof commits to the released amendment but holds only pending calendar attestations, with no Bitcoin attestation yet.
    - The bundle carries absolute paths from the author's machine, in `review_demand/r2_annotation_protocol.md` and in run 2's command log and environment file.
    - `make_fig_sources.py` writes Figure 7 into `ai_citation_cross_sector/scripts/`, but `build_tex.py` takes figures from the bundle's top folder. A regenerated Figure 7 therefore has to be copied up by hand before a build uses it. The regenerated file is identical to the shipped one.
    - Two values sit exactly on a rounding boundary, and both are counted as matches:
        - Table 4's /device-compare/ keyword ratio is exactly 5.25 (12,600 / 2,400). The paper gives 5.2, which is how Python's round-half-even prints it in `instrument_extra.py`; round-half-up would give 5.3.
        - The multi-word branch interval's lower end is 0.735 to machine precision. The paper gives +0.74, which is the conventional rounding.
    - Section 5.5 quotes p = 0.10 without the area-code section. That is the t-approximation; the permutation p printed beside it is 0.11.

## 3. Scripts

"Identical" means byte for byte against the output file shipped beside the script. Scripts ran in their own folder, as README.txt, the folder READMEs or their docstrings say.

| Script | How it was run | Result | Comparison with the shipped output |
|---|---|---|---|
| data/analyze.py | `cd data && python3 analyze.py` | RAN | No output file is shipped beside it. Every printed value was checked against the paper (section 4). |
| instrument_divergence_extra/instrument_extra.py | `cd instrument_divergence_extra && python3 instrument_extra.py` | RAN (25 s) | stdout is identical to `instrument_extra_output.txt`. The script rewrites the four series CSVs from the manuscript: Tables 3, 5 and 6 are identical; Table 2 differs on one line (shipped: `11 (77 cumulative)`; regenerated: `11 (78 in all, days 0 to 77)`). |
| review_demand/r2_link_check.py | `cd review_demand && python3 r2_link_check.py` | RAN | Identical to `r2_link_check_output.txt`. |
| review_demand/m2_from_counts.py | `cd review_demand && python3 m2_from_counts.py` | RAN (29 s) | Identical to `m2_from_counts_output.txt`. |
| review_demand/analyze_reviews.py | `cd review_demand && python3 analyze_reviews.py` | CANNOT RUN | Missing: `Telecom_reviews_and_responses.xlsx` and `Telecom_classification.xlsx` (the licensed DataForSEO export, withheld). The script also imports `ufi`, which is not in the bundle. It stops with FileNotFoundError. The saved output was used in the number check. |
| review_demand/supplement_r10.py | `cd review_demand && python3 supplement_r10.py` | CANNOT RUN | Same missing inputs; same stop. |
| review_demand/r2_link_sample.py | `cd review_demand && python3 r2_link_sample.py` | CANNOT RUN | Same missing inputs; same stop. Nothing was written. |
| review_demand/make_fig_reviews.py | `cd review_demand && python3 make_fig_reviews.py` | CANNOT RUN | Missing: `out/label_demand_aggregates.csv` and `out/branch_shares.csv`, which are written from the withheld export. |
| review_demand/make_fig_reviews_v50.py | `cd review_demand && python3 make_fig_reviews_v50.py` | CANNOT RUN | Missing: `out/label_demand_aggregates.csv` and `out/branch_shares_corrected.csv`. Instead, the text of the shipped `fig9_reviews.pdf` was read and checked. |
| ai_citation_cross_sector/scripts/section7_from_aggregates.py | `cd ai_citation_cross_sector/scripts && python3 section7_from_aggregates.py` | RAN (57 s) | Identical to `section7_from_aggregates_output.txt`. |
| ai_citation_cross_sector/scripts/make_tables_sector_surface.py | `cd ai_citation_cross_sector/scripts && python3 make_tables_sector_surface.py` | RAN | Identical to `make_tables_sector_surface_output.txt`. |
| ai_citation_cross_sector/scripts/make_fig_sources.py | `cd ai_citation_cross_sector/scripts && python3 make_fig_sources.py` | RAN | `fig10_sources.png` is identical. `fig10_sources.pdf` is identical except for `/CreationDate`. |
| ai_citation_cross_sector/scripts/make_brand_radar_urls.py | `cd ai_citation_cross_sector/scripts && python3 make_brand_radar_urls.py` | RAN | It rewrites `design/cross_sector_report_urls.json`, which comes out identical. No stdout file is shipped. |
| ai_citation_cross_sector/scripts/cross_sector.py | `cd ai_citation_cross_sector/scripts && python3 cross_sector.py` | CANNOT RUN | Missing: the raw Brand Radar exports (withheld under the vendor's terms). The script stops with its documented message. |
| ai_citation_cross_sector/scripts/cross_sector_sensitivity.py | `cd ai_citation_cross_sector/scripts && python3 cross_sector_sensitivity.py` | CANNOT RUN | Missing: the raw exports; same documented stop. |
| ai_citation_cross_sector/scripts/cross_sector_sensitivity2.py | `cd ai_citation_cross_sector/scripts && python3 cross_sector_sensitivity2.py` | CANNOT RUN | Missing: the raw exports. Before stopping, it prints its first section from the aggregates, and those 760 bytes are an exact prefix of the saved output. |
| stakes/vendor_reliance.py | `cd stakes && python3 vendor_reliance.py --offline` | RAN | Identical to `vendor_reliance_output.txt`, and the works list was not rewritten. Online mode was not run: it queries OpenAlex and rewrites the list, and the README gives `--offline` for recounting. |
| make_figs_v4.py | `python3 make_figs_v4.py` (bundle top) | RAN | Six PNGs identical; six PDFs identical except for `/CreationDate`. |
| make_fig0.py | `python3 make_fig0.py` (bundle top) | RAN | PNG identical; PDF identical except for `/CreationDate`. |
| build_tex.py | `python3 build_tex.py` (fresh copy, bundle top) | RAN | `build/paper.tex` is identical to the shipped `paper.tex`. |
| (build) tectonic | `cd build && tectonic --keep-logs paper.tex` | RAN | 33-page `paper.pdf`, no errors; 68 underfull and 4 overfull boxes (the largest is 67.7 pt). No shipped PDF to compare. |
| build_docx.sh | `zsh ./build_docx.sh` (bundle top) | RAN | `build/paper.docx` (1.24 MB): 9 figures, 12 tables. No shipped DOCX to compare. |
| edit_v49.py, edit_v49_r9.py, edit_v49_r9b.py, edit_v49_r9c.py, edit_v50.py | `python3 <script>`, each in its own throwaway copy | CANNOT RUN | Missing: `manuscript_v49.md`, the earlier manuscript these records edit. Each stops with FileNotFoundError and changes nothing. |
| edit_v50b.py to edit_v52o.py (19 scripts) | `python3 <script>`, each in its own throwaway copy | CANNOT RUN | Missing: the pre-edit states of `manuscript_v50.md`. On the released manuscript each refuses ("REFUSE: 0 matches" or "REFUSE: already applied") and changes no file (`outputs/edit_scripts_attempts.txt`). |
| framework_test_r1: `ots verify` | not available (`ots` not installed) | CANNOT RUN | Checked offline with `checks/ots_parse.py`. The manifest proof commits to SHA-256 `003311...e4b9` of the released manifest and attests block 971,506 with merkle root `7bdc6025...59a3`. The amendment proof commits to `304297...e1dd`, pending attestations only. The held-back plan, predictors and script cannot be checked against the manifest. |

**Tally:** the bundle holds 45 scripts that belong to the paper (21 analysis, figure and build scripts plus 24 edit records). 13 RAN, 0 FAILED, and 32 CANNOT RUN: 8 need withheld data and 24 edit records need earlier, unreleased manuscript states. The tectonic compile also ran. The check scripts inside the bundle's `08_REVIEW/` folders belong to the two earlier reproductions and were not run.

## 4. Numbers

**Method:** `checks/check_numbers.py` finds each quoted value in `manuscript_v50.md` by its surrounding text, obtains the value from the named source, and compares the two at the paper's precision (a difference of at most half a unit in the paper's last digit). Text values are compared exactly. The source kinds are:

- `rerun`: printed by a bundle script rerun here.
- `data`: computed from a released data file.
- `arith`: arithmetic on figures the paper itself quotes, or on the released table CSVs.
- `figure`: a value drawn by a figure script, compared with the released data.
- `shipped`: only in the saved output of a script that cannot run here; status CANNOT RUN, with a note saying whether the paper agrees with that output.
- `none`: no released source; status CANNOT RUN.

The four Section 6 values whose printed form sits on a rounding boundary were settled at full precision by `checks/m2_precise.py`. That script reads the released counts and follows the documented seed and resampling order.

**Totals:** 1,696 values: CANNOT RUN 134, MATCH 1,555, MISMATCH 7.

By source kind:

| Source kind | MATCH | MISMATCH | CANNOT RUN |
|---|---|---|---|
| rerun | 813 | 5 | 0 |
| data | 461 | 1 | 0 |
| arith | 158 | 0 | 0 |
| figure | 123 | 1 | 0 |
| shipped | 0 | 0 | 109 |
| none | 0 | 0 | 25 |

**Coverage:** `checks/coverage.py` lists every numeric token outside the reference list that no check quotes (`outputs/coverage_uncovered.txt`). None of what remains is printed by a bundle script or held in a released data file. It falls into these groups:

- figures from the literature (Section 2, Appendix B), vendor documentation (Section 7.2), Pew and Costco (Section 13.1);
- Table 7's costs, which are the author's reconstruction;
- model and software version names, and the history of earlier versions;
- structural labels: day numbers, position bands, item numbers, formula constants and confidence levels.

### 4.1 MISMATCH

| id | Location | Value quoted | Source | Obtained | Note |
|---|---|---|---|---|---|
| 17 | Abstract | +0.19 | rerun:m2_from_counts.py (full precision via checks/m2_precise.py) | 0.184869 | prints +0.185; the full value 0.184869 is +0.18 to two decimals (double rounding) |
| 110 | Table 2, row 'October 2026 (run-rate)', column 'Days live' | 11 (78 in all, days 0 to 77) | data:released CSV of Table 2 (instrument_divergence_extra/) | 11 (77 cumulative) | the released CSV was not regenerated after edit_v52n.py corrected the manuscript |
| 680 | §6 para 2 | +0.19 | rerun:m2_from_counts.py (full precision via checks/m2_precise.py) | 0.184869 | prints +0.185; the full value 0.184869 is +0.18 to two decimals (double rounding) |
| 687 | §6 para 2 | +0.29 | rerun:m2_from_counts.py (full precision via checks/m2_precise.py) | 0.284982 | prints +0.285; the full value 0.284982 is +0.28 to two decimals (double rounding) |
| 1048 | §15 | +0.19 | rerun:m2_from_counts.py (full precision via checks/m2_precise.py) | 0.184869 | prints +0.185; the full value 0.184869 is +0.18 to two decimals (double rounding) |
| 1504 | Appendix D Table D1 | +0.19 | rerun:m2_from_counts.py (full precision via checks/m2_precise.py) | 0.184869 | prints +0.185; the full value 0.184869 is +0.18 to two decimals (double rounding) |
| 1653 | Figure 6 (fig9_reviews), panel (a) title | +0.19 | figure:fig9_reviews.pdf as shipped (make_fig_reviews_v50.py cannot run) | 0.184869 | title hard-coded as +0.19; full value 0.184869 is +0.18 (double rounding) |

### 4.2 CANNOT RUN with no released source

| id | Location | Value quoted | Reason | Note |
|---|---|---|---|---|
| 51 | §1.4 item 1 | 13 | ufi repository and package not in the bundle | make_fig0.py draws 13 types (10 + 3), consistent |
| 60 | §3 | 6; 451 (15 Sep 2026) | numbering-plan registry not released (the released list holds only codes with pages) |  |
| 951 | §10 | 0 through 31 July | daily referring-domain series not released (Table 5 gives 0 at day 0 only) |  |
| 1014 | §13 | 924; 66; f05ce279942be5f8 | ufi repository and package not in the bundle |  |
| 1015 | §13 | α 0.5, β 0.5, damping 0.85, 3 phrasings, mean; 7290a2235d8de05f | ufi repository and package not in the bundle |  |
| 1018 | §13 | 04:05 UTC, 15 Oct 2026 | block time is not in the bundle | external check (blockstream.info): block 971,506 header time 2026-10-15T04:05:42Z, merkle root as in the proof |
| 1019 | §13 | committed 14 Oct 2026 | the plan, predictors and script are held back; the manifest gives commit hashes only | the manifest says it was written 2026-10-15 03:45 UTC (14 Oct, 23:45 US Eastern) |
| 1023 | §13 | same block (971,506) | the second-domain protocol and its proof are not in the bundle |  |
| 1025 | §14 | 149994a; 22 commits (21 + 1); version 0.2.0 | ufi repository and package not in the bundle |  |
| 1073 | Appendix B | 0.22 | ufi repository and package not in the bundle |  |
| 1074 | Appendix B | 7290a2235d8de05f; 02:00 UTC | ufi repository and package not in the bundle |  |
| 1075 | Appendix B | 03:45 UTC; 02d7588 | ufi repository and package not in the bundle |  |
| 1076 | Appendix B | 0.8 | ufi repository and package not in the bundle |  |
| 1077 | Appendix B | 4/5 | ufi repository and package not in the bundle |  |
| 1078 | Appendix B | 70.4% | ufi repository and package not in the bundle |  |
| 1079 | Appendix B | 2 of 4 | ufi repository and package not in the bundle |  |
| 1534 | Appendix D Table D1 | 4/5 | ufi repository and package not in the bundle |  |
| 1535 | Appendix D Table D1 | 70.4% | ufi repository and package not in the bundle |  |
| 1683 | §9.1 | 1.0 and 0.5 | ufi repository and package not in the bundle |  |
| 1688 | §14 | 924 | ufi repository and package not in the bundle |  |
| 1689 | §14 | 22; 21; 1 | ufi repository and package not in the bundle |  |
| 1690 | §14 | 3.10 | ufi repository and package not in the bundle |  |
| 1694 | Appendix B | 1.0, 0.5, 0 | ufi repository and package not in the bundle |  |
| 1695 | Appendix B | 1.0, 0.5, 0 | ufi repository and package not in the bundle |  |
| 1696 | Appendix B | 0.5, 0.5, 0.85 | ufi repository and package not in the bundle |  |

### 4.3 CANNOT RUN from the saved outputs of scripts that need withheld data

| Saved output | Values | Paper agrees with the saved output |
|---|---|---|
| `analyze_reviews_output.txt` | 30 | 30 of 30 |
| `cross_sector_sensitivity2_output.txt` | 10 | 10 of 10 |
| `cross_sector_sensitivity_output.txt` | 33 | 33 of 33 |
| `pilot_section_output.txt` | 8 | 8 of 8 |
| `supplement_r10_output.txt` | 28 | 28 of 28 |

### 4.4 Every value checked

The same table, with the full quoted text, is in `outputs/numbers_table.tsv`.

| id | Location | Value quoted | Quoted text (first 70 characters) | Source | Obtained | Status | Note |
|---|---|---|---|---|---|---|---|
| 1 | Abstract | 7.5x | differed on estimated monthly visits by 7.5x to 27.1x | arith:Table 2 (released CSV values) | 7.46965 | MATCH |  |
| 2 | Abstract | 27.1x | differed on estimated monthly visits by 7.5x to 27.1x | arith:Table 2 (released CSV values) | 27.1414 | MATCH |  |
| 3 | Abstract | 8.6x | and by 8.6x to 29.9x with both read worldwide | arith:Table 2 (released CSV values) | 8.62011 | MATCH |  |
| 4 | Abstract | 29.9x | and by 8.6x to 29.9x with both read worldwide | arith:Table 2 (released CSV values) | 29.8608 | MATCH |  |
| 5 | Abstract | 0.20x | the ratio ran from 0.20x to 7.24x | rerun:analyze.py | 0.20 | MATCH |  |
| 6 | Abstract | 7.24x | the ratio ran from 0.20x to 7.24x | rerun:analyze.py | 7.24 | MATCH |  |
| 7 | Abstract | −0.11 | (Spearman −0.11, a test of low power | rerun:analyze.py | -0.11 | MATCH |  |
| 8 | Abstract | 60 | is larger in 60 of 66 pairs | rerun:analyze.py | 60 | MATCH |  |
| 9 | Abstract | 66 | is larger in 60 of 66 pairs | rerun:analyze.py | 66 | MATCH |  |
| 10 | Abstract | 9 | in only 9 of the 15 pairs within a factor of three | rerun:instrument_extra.py | 9 | MATCH |  |
| 11 | Abstract | 15 | in only 9 of the 15 pairs within a factor of three | rerun:instrument_extra.py | 15 | MATCH |  |
| 12 | Abstract | 37,193 | On 37,193 reviews of 378 telecom stores | shipped:analyze_reviews_output.txt | 37193 | CANNOT RUN | paper agrees with the saved output |
| 13 | Abstract | 378 | On 37,193 reviews of 378 telecom stores | shipped:analyze_reviews_output.txt | 378 | CANNOT RUN | paper agrees with the saved output |
| 14 | Abstract | 42,994 | linked to a 42,994-node keyword taxonomy | shipped:supplement_r10_output.txt | 42994 | CANNOT RUN | paper agrees with the saved output |
| 15 | Abstract | +0.47 | (Spearman +0.47 to +0.75, depending on how labels are attributed to... | rerun:m2_from_counts.py | +0.468 | MATCH |  |
| 16 | Abstract | +0.75 | (Spearman +0.47 to +0.75, depending on how labels are attributed to... | rerun:m2_from_counts.py | +0.748 | MATCH |  |
| 17 | Abstract | +0.19 | barely on topics (+0.19) | rerun:m2_from_counts.py (full precision via checks/m2_precise.py) | 0.184869 | MISMATCH | prints +0.185; the full value 0.184869 is +0.18 to two decimals (double rounding) |
| 18 | Abstract | about two-thirds | judged about two-thirds correct | rerun:r2_link_check.py | 65.0% to 66.8% | MATCH |  |
| 19 | Abstract | 1 held, 1 in direction only, 2 failed | four predictions written before collection yielded one held, one he... | rerun:section7_from_aggregates.py | 1 held, 1 held in direction only, 2 failed | MATCH |  |
| 20 | Abstract | 21% | took a median 21% of citation incidences | rerun:section7_from_aggregates.py | 21.3 | MATCH |  |
| 21 | Abstract | 0.6% | against 0.6% to 9.2% on ChatGPT, Copilot, Perplexity and Gemini | rerun:section7_from_aggregates.py | 0.6 | MATCH |  |
| 22 | Abstract | 9.2% | against 0.6% to 9.2% on ChatGPT, Copilot, Perplexity and Gemini | rerun:section7_from_aggregates.py | 9.2 | MATCH |  |
| 23 | Abstract | 11 of 11 | with the lowest Google figure above the highest of the other four i... | rerun:section7_from_aggregates.py | 11/11 | MATCH |  |
| 24 | §1 para 3 | 456 | in OpenAlex, 456 works name Ahrefs | rerun:vendor_reliance.py --offline | 456 | MATCH |  |
| 25 | §1 para 3 | 27 | 27 of them published in 2020 | rerun:vendor_reliance.py --offline | 27 | MATCH |  |
| 26 | §1 para 3 | 87 | 87 in 2025 and 110 in 2026 | rerun:vendor_reliance.py --offline | 87 | MATCH |  |
| 27 | §1 para 3 | 110 | 87 in 2025 and 110 in 2026 | rerun:vendor_reliance.py --offline | 110 | MATCH |  |
| 28 | §1 para 3 | 86% | and 86% name only one of the three | rerun:vendor_reliance.py --offline | 86 | MATCH |  |
| 29 | §1.1 | 381 | 381 code pages plus hubs under a single prefix | data:section_code_pages_2026-10-14.csv | 381 | MATCH |  |
| 30 | §1.1 | 77 | and observed for 77 days | arith:dates (26 Jul to 11 Oct 2026) | 77 | MATCH |  |
| 31 | §1.1 | 7 | the other quantities at seven checkpoints | data:instrument_series_table5 CSV | 7 | MATCH | Table 5 columns after day 0 |
| 32 | §1.2 | about 30 | up to about 30 times worldwide | arith:Table 2 (released CSV values) | 29.9 | MATCH |  |
| 33 | §1.2 | 33 | (33 times US to US, estimated) | arith:Table 2 x 81.5% (single read) | 33.3024 | MATCH |  |
| 34 | §1.2 item 1 | 7.5x | differ on estimated visits by 7.5x to 27.1x (8.6x to 29.9x worldwid... | arith:Table 2 (released CSV values) | 7.46965 | MATCH |  |
| 35 | §1.2 item 1 | 27.1x | differ on estimated visits by 7.5x to 27.1x (8.6x to 29.9x worldwid... | arith:Table 2 (released CSV values) | 27.1414 | MATCH |  |
| 36 | §1.2 item 1 | 8.6x | differ on estimated visits by 7.5x to 27.1x (8.6x to 29.9x worldwid... | arith:Table 2 (released CSV values) | 8.62011 | MATCH |  |
| 37 | §1.2 item 1 | 29.9x | differ on estimated visits by 7.5x to 27.1x (8.6x to 29.9x worldwid... | arith:Table 2 (released CSV values) | 29.8608 | MATCH |  |
| 38 | §1.2 item 1 | 0.20x | the ratio spans 0.20x to 7.24x | rerun:analyze.py | 0.20 | MATCH |  |
| 39 | §1.2 item 1 | 7.24x | the ratio spans 0.20x to 7.24x | rerun:analyze.py | 7.24 | MATCH |  |
| 40 | §1.2 item 1 | 60 of 66 | the ordering of sections in 60 of 66 pairs | rerun:analyze.py | 60 of 66 | MATCH |  |
| 41 | §1.2 item 2 | 37,193 | On 37,193 business reviews linked to a 42,994-node keyword taxonomy | shipped:analyze_reviews_output.txt | 37193 | CANNOT RUN | paper agrees with the saved output |
| 42 | §1.2 item 2 | 42,994 | On 37,193 business reviews linked to a 42,994-node keyword taxonomy | shipped:supplement_r10_output.txt | 42994 | CANNOT RUN | paper agrees with the saved output |
| 43 | §1.2 item 3 | 21.3% | (21.3% against 2.1%) | rerun:section7_from_aggregates.py | 21.3 | MATCH |  |
| 44 | §1.2 item 3 | 2.1% | (21.3% against 2.1%) | rerun:section7_from_aggregates.py | 2.1 | MATCH |  |
| 45 | §1.2 item 3 | about ten times | about ten times their pooled median share | rerun:section7_from_aggregates.py | 10.1 | MATCH |  |
| 46 | §1.2 item 5 | 1.2 | (1.2 to 2.0 times the most-cited one) | arith:single reads (Figure 8 values) | 1.23529 | MATCH |  |
| 47 | §1.2 item 5 | 2.0 | (1.2 to 2.0 times the most-cited one) | arith:single reads (Figure 8 values) | 1.9916 | MATCH |  |
| 48 | §1.2 item 5 | 77 | a 77-day series | arith:dates (26 Jul to 11 Oct 2026) | 77 | MATCH |  |
| 49 | §1.3 | 90 | an Ahrefs Domain Rating of 90 and a Semrush Authority Score of 86 | data:single_reads_2026-10.csv | 90 | MATCH |  |
| 50 | §1.3 | 86 | an Ahrefs Domain Rating of 90 and a Semrush Authority Score of 86 | data:single_reads_2026-10.csv | 86 | MATCH |  |
| 51 | §1.4 item 1 | 13 | The implementation declares thirteen surface types | none:ufi repository and package not in the bundle |  | CANNOT RUN | make_fig0.py draws 13 types (10 + 3), consistent |
| 52 | §3 | 52 | fetching every code page linked from the section's 52 state hubs | data:section_code_pages_2026-10-14.csv | 52 | MATCH | the hub list itself is not released; the released code list has 52 registry locations, which the paper equates with the hubs |
| 53 | §3 | 381 | the section holds 381 code pages** | data:section_code_pages_2026-10-14.csv | 381 | MATCH |  |
| 54 | §3 | 374 | 374 for geographic codes assigned to US states | data:section_code_pages_2026-10-14.csv | 374 | MATCH |  |
| 55 | §3 | 372 | (all 372 in service and two assigned but not yet in service) | data:section_code_pages_2026-10-14.csv | 372 | MATCH |  |
| 56 | §3 | 2 | (all 372 in service and two assigned but not yet in service) | data:section_code_pages_2026-10-14.csv | 2 | MATCH |  |
| 57 | §3 | 7 | and 7 for toll-free codes | data:section_code_pages_2026-10-14.csv | 7 | MATCH |  |
| 58 | §3 | 52 | which takes 52 values | data:section_code_pages_2026-10-14.csv | 52 | MATCH |  |
| 59 | §3 | 381 | found the same 381 and matched them | data:section_code_pages_2026-10-14.csv | 381 | MATCH |  |
| 60 | §3 | 6; 451 (15 Sep 2026) | are the six assigned to US territories and 451 | none:numbering-plan registry not released (the released list holds ... |  | CANNOT RUN |  |
| 61 | §3 | 210, 365, 391, 414, 440 | (210, 365, 391, 414, 440) | data:instrument_series_table5 CSV | 210, 365, 391, 414, 440 | MATCH |  |
| 62 | §3 | 434 | a fixed set of 434 URLs | arith:381 code pages + 53 hubs | 434 | MATCH |  |
| 63 | §3 | 441 | **441** is the number of URLs under the prefix | data:instrument_series_table5 CSV | 441 | MATCH |  |
| 64 | §3 | 7 | it exceeds 381 plus the 53 hub pages by seven | arith:441 - 434 | 7 | MATCH |  |
| 65 | §3 | 455 | Brand Radar's count of 455 distinct cited pages | data:single_reads_2026-10.csv | 455 | MATCH |  |
| 66 | §3 | 21 | exceeds 434 by 21 | arith:455 - 434 | 21 | MATCH |  |
| 67 | §3.1 item 4 | 90 | Ahrefs Domain Rating 90, Semrush Authority Score 86 | data:single_reads_2026-10.csv | 90 | MATCH |  |
| 68 | §3.1 item 4 | 86 | Ahrefs Domain Rating 90, Semrush Authority Score 86 | data:single_reads_2026-10.csv | 86 | MATCH |  |
| 69 | §3.1 item 5 | 87 and 91 | Two carriers at Domain Rating 87 and 91 | data:single_reads_2026-10.csv | 87 and 91 | MATCH |  |
| 70 | §3.1 item 6 | 13 to 83 | voice vendors at Domain Rating 13 to 83 | data:single_reads_2026-10.csv | 13 to 83 | MATCH |  |
| 71 | §4.1 | 105 | The section ranks in 105 countries | data:single_reads_2026-10.csv | 105 | MATCH |  |
| 72 | §4.1 | 18.5% | with 18.5% of Ahrefs' estimated visits from outside the US | data:single_reads_2026-10.csv | 18.5% | MATCH |  |
| 73 | §4.1 | 18.6% | (18.6% in the 12 October read of Table 4) | data:ahrefs/semrush_prefixes_2026-10-12.csv | 18.6 | MATCH |  |
| 74 | §4.1 | 7.5 | is nonetheless between 7.5 and 27.1 times larger | arith:Table 2 (released CSV values) | 7.46965 | MATCH |  |
| 75 | §4.1 | 27.1 | is nonetheless between 7.5 and 27.1 times larger | arith:Table 2 (released CSV values) | 27.1414 | MATCH |  |
| 76 | §4.1 | 8.6x | worldwide over worldwide (8.6x to 29.9x) | arith:Table 2 (released CSV values) | 8.62011 | MATCH |  |
| 77 | §4.1 | 29.9x | worldwide over worldwide (8.6x to 29.9x) | arith:Table 2 (released CSV values) | 29.8608 | MATCH |  |
| 78 | §4.1 | 9.2x | and US over US (9.2x to 33.3x) | arith:Table 2 x 81.5% (single read) | 9.16521 | MATCH |  |
| 79 | §4.1 | 33.3x | and US over US (9.2x to 33.3x) | arith:Table 2 x 81.5% (single read) | 33.3024 | MATCH |  |
| 80 | §4.1 | 81.5% | Ahrefs' US share of its own visits, 81.5% | data:single_reads_2026-10.csv | 81.5% | MATCH |  |
| 81 | §4.1 Table 1 | 11 Oct; 10 Oct; 12 Oct | \| Ranking keywords \| distinct keywords on which any URL under the... | data:single_reads_2026-10.csv | 11 Oct; 10 Oct; 12 Oct | MATCH |  |
| 82 | §4.3 | day 60 = 24 Sep | began on 24 September, day 60 | arith:dates | 26 Jul + 60 days = 24 Sep | MATCH |  |
| 83 | §4.3 | day 65 = 29 Sep | Ahrefs posted a notice on 29 September, day 65 | arith:dates | 26 Jul + 65 days = 29 Sep | MATCH |  |
| 84 | §4.3 | day 37 = 1 Sep | **Day 37 (1 September 2026) is the primary checkpoint** | arith:dates | 26 Jul + 37 days = 1 Sep | MATCH |  |
| 85 | §4.3 | 4 of 9 | the 11 October read gives four of the nine quantities for it | data:instrument_series_table5 CSV | 4 of 9 | MATCH |  |
| 86 | Table 2, row 'June 2026', column 'Days live' | 0 | 0 | data:released CSV of Table 2 (instrument_divergence_extra/) | 0 | MATCH |  |
| 87 | Table 2, row 'June 2026', column 'Ahrefs, worldwide' | 0 | 0 | data:released CSV of Table 2 (instrument_divergence_extra/) | 0 | MATCH |  |
| 88 | Table 2, row 'June 2026', column 'Semrush, US (worldwide)' | 0 (0) | 0 (0) | data:released CSV of Table 2 (instrument_divergence_extra/) | 0 (0) | MATCH |  |
| 89 | Table 2, row 'June 2026', column 'Semrush US / Ahrefs worldwide' | n/a | n/a | data:released CSV of Table 2 (instrument_divergence_extra/) | n/a | MATCH |  |
| 90 | Table 2, row 'June 2026', column 'Worldwide vs worldwide' | n/a | n/a | data:released CSV of Table 2 (instrument_divergence_extra/) | n/a | MATCH |  |
| 91 | Table 2, row 'June 2026', column 'US vs US (estimated)' | n/a | n/a | data:released CSV of Table 2 (instrument_divergence_extra/) | n/a | MATCH |  |
| 92 | Table 2, row 'July 2026 (total)', column 'Days live' | 6 | 6 | data:released CSV of Table 2 (instrument_divergence_extra/) | 6 | MATCH |  |
| 93 | Table 2, row 'July 2026 (total)', column 'Ahrefs, worldwide' | 3,862 | 3,862 | data:released CSV of Table 2 (instrument_divergence_extra/) | 3,862 | MATCH |  |
| 94 | Table 2, row 'July 2026 (total)', column 'Semrush, US (worldwide)' | 100,012 (103,045) | 100,012 (103,045) | data:released CSV of Table 2 (instrument_divergence_extra/) | 100,012 (103,045) | MATCH |  |
| 95 | Table 2, row 'July 2026 (total)', column 'Semrush US / Ahrefs worldwide' | 25.9x | 25.9x | data:released CSV of Table 2 (instrument_divergence_extra/) | 25.9x | MATCH |  |
| 96 | Table 2, row 'July 2026 (total)', column 'Worldwide vs worldwide' | 26.7x | 26.7x | data:released CSV of Table 2 (instrument_divergence_extra/) | 26.7x | MATCH |  |
| 97 | Table 2, row 'July 2026 (total)', column 'US vs US (estimated)' | 31.8x | 31.8x | data:released CSV of Table 2 (instrument_divergence_extra/) | 31.8x | MATCH |  |
| 98 | Table 2, row 'August 2026 (total)', column 'Days live' | 31 | 31 | data:released CSV of Table 2 (instrument_divergence_extra/) | 31 | MATCH |  |
| 99 | Table 2, row 'August 2026 (total)', column 'Ahrefs, worldwide' | 32,281 | 32,281 | data:released CSV of Table 2 (instrument_divergence_extra/) | 32,281 | MATCH |  |
| 100 | Table 2, row 'August 2026 (total)', column 'Semrush, US (worldwide)' | 876,153 (963,937) | 876,153 (963,937) | data:released CSV of Table 2 (instrument_divergence_extra/) | 876,153 (963,937) | MATCH |  |
| 101 | Table 2, row 'August 2026 (total)', column 'Semrush US / Ahrefs worldwide' | 27.1x | 27.1x | data:released CSV of Table 2 (instrument_divergence_extra/) | 27.1x | MATCH |  |
| 102 | Table 2, row 'August 2026 (total)', column 'Worldwide vs worldwide' | 29.9x | 29.9x | data:released CSV of Table 2 (instrument_divergence_extra/) | 29.9x | MATCH |  |
| 103 | Table 2, row 'August 2026 (total)', column 'US vs US (estimated)' | 33.3x | 33.3x | data:released CSV of Table 2 (instrument_divergence_extra/) | 33.3x | MATCH |  |
| 104 | Table 2, row 'September 2026 (total)', column 'Days live' | 30 | 30 | data:released CSV of Table 2 (instrument_divergence_extra/) | 30 | MATCH |  |
| 105 | Table 2, row 'September 2026 (total)', column 'Ahrefs, worldwide' | 150,113 | 150,113 | data:released CSV of Table 2 (instrument_divergence_extra/) | 150,113 | MATCH |  |
| 106 | Table 2, row 'September 2026 (total)', column 'Semrush, US (worldwide)' | 1,534,362 (1,765,077) | 1,534,362 (1,765,077) | data:released CSV of Table 2 (instrument_divergence_extra/) | 1,534,362 (1,765,077) | MATCH |  |
| 107 | Table 2, row 'September 2026 (total)', column 'Semrush US / Ahrefs worldwide' | 10.2x | 10.2x | data:released CSV of Table 2 (instrument_divergence_extra/) | 10.2x | MATCH |  |
| 108 | Table 2, row 'September 2026 (total)', column 'Worldwide vs worldwide' | 11.8x | 11.8x | data:released CSV of Table 2 (instrument_divergence_extra/) | 11.8x | MATCH |  |
| 109 | Table 2, row 'September 2026 (total)', column 'US vs US (estimated)' | 12.5x | 12.5x | data:released CSV of Table 2 (instrument_divergence_extra/) | 12.5x | MATCH |  |
| 110 | Table 2, row 'October 2026 (run-rate)', column 'Days live' | 11 (78 in all, days 0 to 77) | 11 (78 in all, days 0 to 77) | data:released CSV of Table 2 (instrument_divergence_extra/) | 11 (77 cumulative) | MISMATCH | the released CSV was not regenerated after edit_v52n.py corrected the manuscript |
| 111 | Table 2, row 'October 2026 (run-rate)', column 'Ahrefs, worldwide' | 215,577 | 215,577 | data:released CSV of Table 2 (instrument_divergence_extra/) | 215,577 | MATCH |  |
| 112 | Table 2, row 'October 2026 (run-rate)', column 'Semrush, US (worldwide)' | 1,610,284 (1,858,297) | 1,610,284 (1,858,297) | data:released CSV of Table 2 (instrument_divergence_extra/) | 1,610,284 (1,858,297) | MATCH |  |
| 113 | Table 2, row 'October 2026 (run-rate)', column 'Semrush US / Ahrefs worldwide' | 7.5x | 7.5x | data:released CSV of Table 2 (instrument_divergence_extra/) | 7.5x | MATCH |  |
| 114 | Table 2, row 'October 2026 (run-rate)', column 'Worldwide vs worldwide' | 8.6x | 8.6x | data:released CSV of Table 2 (instrument_divergence_extra/) | 8.6x | MATCH |  |
| 115 | Table 2, row 'October 2026 (run-rate)', column 'US vs US (estimated)' | 9.2x | 9.2x | data:released CSV of Table 2 (instrument_divergence_extra/) | 9.2x | MATCH |  |
| 116 | Table 3, row 'July 2026', column '(a) Ahrefs: cited / all AIO keywords' | 47 of 284 | 47 of 284 | data:released CSV of Table 3 (instrument_divergence_extra/) | 47 of 284 | MATCH |  |
| 117 | Table 3, row 'July 2026', column '(a) as %, 95% Wilson CI' | 16.5% [12.7, 21.3] | 16.5% [12.7, 21.3] | data:released CSV of Table 3 (instrument_divergence_extra/) | 16.5% [12.7, 21.3] | MATCH |  |
| 118 | Table 3, row 'July 2026', column '(b) Semrush count' | 138 | 138 | data:released CSV of Table 3 (instrument_divergence_extra/) | 138 | MATCH |  |
| 119 | Table 3, row 'July 2026', column '(b) / (a) numerator' | 2.94x | 2.94x | data:released CSV of Table 3 (instrument_divergence_extra/) | 2.94x | MATCH |  |
| 120 | Table 3, row 'August 2026', column '(a) Ahrefs: cited / all AIO keywords' | 851 of 6,749 | 851 of 6,749 | data:released CSV of Table 3 (instrument_divergence_extra/) | 851 of 6,749 | MATCH |  |
| 121 | Table 3, row 'August 2026', column '(a) as %, 95% Wilson CI' | 12.6% [11.8, 13.4] | 12.6% [11.8, 13.4] | data:released CSV of Table 3 (instrument_divergence_extra/) | 12.6% [11.8, 13.4] | MATCH |  |
| 122 | Table 3, row 'August 2026', column '(b) Semrush count' | 2,221 | 2,221 | data:released CSV of Table 3 (instrument_divergence_extra/) | 2,221 | MATCH |  |
| 123 | Table 3, row 'August 2026', column '(b) / (a) numerator' | 2.61x | 2.61x | data:released CSV of Table 3 (instrument_divergence_extra/) | 2.61x | MATCH |  |
| 124 | Table 3, row 'September 2026', column '(a) Ahrefs: cited / all AIO keywords' | 3,380 of 22,665 | 3,380 of 22,665 | data:released CSV of Table 3 (instrument_divergence_extra/) | 3,380 of 22,665 | MATCH |  |
| 125 | Table 3, row 'September 2026', column '(a) as %, 95% Wilson CI' | 14.9% [14.5, 15.4] | 14.9% [14.5, 15.4] | data:released CSV of Table 3 (instrument_divergence_extra/) | 14.9% [14.5, 15.4] | MATCH |  |
| 126 | Table 3, row 'September 2026', column '(b) Semrush count' | 8,187 | 8,187 | data:released CSV of Table 3 (instrument_divergence_extra/) | 8,187 | MATCH |  |
| 127 | Table 3, row 'September 2026', column '(b) / (a) numerator' | 2.42x | 2.42x | data:released CSV of Table 3 (instrument_divergence_extra/) | 2.42x | MATCH |  |
| 128 | Table 3, row 'October 2026 (run-rate)', column '(a) Ahrefs: cited / all AIO k... | 7,455 of 37,238 | 7,455 of 37,238 | data:released CSV of Table 3 (instrument_divergence_extra/) | 7,455 of 37,238 | MATCH |  |
| 129 | Table 3, row 'October 2026 (run-rate)', column '(a) as %, 95% Wilson CI' | 20.0% [19.6, 20.4] | 20.0% [19.6, 20.4] | data:released CSV of Table 3 (instrument_divergence_extra/) | 20.0% [19.6, 20.4] | MATCH |  |
| 130 | Table 3, row 'October 2026 (run-rate)', column '(b) Semrush count' | 10,018 | 10,018 | data:released CSV of Table 3 (instrument_divergence_extra/) | 10,018 | MATCH |  |
| 131 | Table 3, row 'October 2026 (run-rate)', column '(b) / (a) numerator' | 1.34x | 1.34x | data:released CSV of Table 3 (instrument_divergence_extra/) | 1.34x | MATCH |  |
| 132 | Table 5, row 'Pages holding a position', column 'Day 0 (26 Jul)' | 2 | 2 | data:released CSV of Table 5 (instrument_divergence_extra/) | 2 | MATCH |  |
| 133 | Table 5, row 'Pages holding a position', column 'Day 15 (10 Aug)' | 210 | 210 | data:released CSV of Table 5 (instrument_divergence_extra/) | 210 | MATCH |  |
| 134 | Table 5, row 'Pages holding a position', column 'Day 30 (25 Aug)' | 365 | 365 | data:released CSV of Table 5 (instrument_divergence_extra/) | 365 | MATCH |  |
| 135 | Table 5, row 'Pages holding a position', column 'Day 37 (1 Sep)' | n/r | **n/r** | data:released CSV of Table 5 (instrument_divergence_extra/) | n/r | MATCH |  |
| 136 | Table 5, row 'Pages holding a position', column 'Day 45 (9 Sep)' | 391 | 391 | data:released CSV of Table 5 (instrument_divergence_extra/) | 391 | MATCH |  |
| 137 | Table 5, row 'Pages holding a position', column 'Day 60 (24 Sep)' | 414 | 414 | data:released CSV of Table 5 (instrument_divergence_extra/) | 414 | MATCH |  |
| 138 | Table 5, row 'Pages holding a position', column 'Day 75 (9 Oct)' | 440 | 440 | data:released CSV of Table 5 (instrument_divergence_extra/) | 440 | MATCH |  |
| 139 | Table 5, row 'Pages holding a position', column 'Day 77 (11 Oct)' | 441 | 441 | data:released CSV of Table 5 (instrument_divergence_extra/) | 441 | MATCH |  |
| 140 | Table 5, row 'Ranking positions, all', column 'Day 0 (26 Jul)' | 2 | 2 | data:released CSV of Table 5 (instrument_divergence_extra/) | 2 | MATCH |  |
| 141 | Table 5, row 'Ranking positions, all', column 'Day 15 (10 Aug)' | 3,385 | 3,385 | data:released CSV of Table 5 (instrument_divergence_extra/) | 3,385 | MATCH |  |
| 142 | Table 5, row 'Ranking positions, all', column 'Day 30 (25 Aug)' | 14,905 | 14,905 | data:released CSV of Table 5 (instrument_divergence_extra/) | 14,905 | MATCH |  |
| 143 | Table 5, row 'Ranking positions, all', column 'Day 37 (1 Sep)' | 15,830 | **15,830** | data:released CSV of Table 5 (instrument_divergence_extra/) | 15,830 | MATCH |  |
| 144 | Table 5, row 'Ranking positions, all', column 'Day 45 (9 Sep)' | 20,326 | 20,326 | data:released CSV of Table 5 (instrument_divergence_extra/) | 20,326 | MATCH |  |
| 145 | Table 5, row 'Ranking positions, all', column 'Day 60 (24 Sep)' | 37,141 | 37,141 | data:released CSV of Table 5 (instrument_divergence_extra/) | 37,141 | MATCH |  |
| 146 | Table 5, row 'Ranking positions, all', column 'Day 75 (9 Oct)' | 43,302 | 43,302 | data:released CSV of Table 5 (instrument_divergence_extra/) | 43,302 | MATCH |  |
| 147 | Table 5, row 'Ranking positions, all', column 'Day 77 (11 Oct)' | 43,980 | 43,980 | data:released CSV of Table 5 (instrument_divergence_extra/) | 43,980 | MATCH |  |
| 148 | Table 5, row 'Positions 1–3', column 'Day 0 (26 Jul)' | 0 | 0 | data:released CSV of Table 5 (instrument_divergence_extra/) | 0 | MATCH |  |
| 149 | Table 5, row 'Positions 1–3', column 'Day 15 (10 Aug)' | 727 | 727 | data:released CSV of Table 5 (instrument_divergence_extra/) | 727 | MATCH |  |
| 150 | Table 5, row 'Positions 1–3', column 'Day 30 (25 Aug)' | 1,801 | 1,801 | data:released CSV of Table 5 (instrument_divergence_extra/) | 1,801 | MATCH |  |
| 151 | Table 5, row 'Positions 1–3', column 'Day 37 (1 Sep)' | 1,874 | **1,874** | data:released CSV of Table 5 (instrument_divergence_extra/) | 1,874 | MATCH |  |
| 152 | Table 5, row 'Positions 1–3', column 'Day 45 (9 Sep)' | 2,649 | 2,649 | data:released CSV of Table 5 (instrument_divergence_extra/) | 2,649 | MATCH |  |
| 153 | Table 5, row 'Positions 1–3', column 'Day 60 (24 Sep)' | 5,822 | 5,822 | data:released CSV of Table 5 (instrument_divergence_extra/) | 5,822 | MATCH |  |
| 154 | Table 5, row 'Positions 1–3', column 'Day 75 (9 Oct)' | 8,753 | 8,753 | data:released CSV of Table 5 (instrument_divergence_extra/) | 8,753 | MATCH |  |
| 155 | Table 5, row 'Positions 1–3', column 'Day 77 (11 Oct)' | 9,239 | 9,239 | data:released CSV of Table 5 (instrument_divergence_extra/) | 9,239 | MATCH |  |
| 156 | Table 5, row 'Positions 4–10', column 'Day 0 (26 Jul)' | 1 | 1 | data:released CSV of Table 5 (instrument_divergence_extra/) | 1 | MATCH |  |
| 157 | Table 5, row 'Positions 4–10', column 'Day 15 (10 Aug)' | 1,494 | 1,494 | data:released CSV of Table 5 (instrument_divergence_extra/) | 1,494 | MATCH |  |
| 158 | Table 5, row 'Positions 4–10', column 'Day 30 (25 Aug)' | 10,151 | 10,151 | data:released CSV of Table 5 (instrument_divergence_extra/) | 10,151 | MATCH |  |
| 159 | Table 5, row 'Positions 4–10', column 'Day 37 (1 Sep)' | n/r | **n/r** | data:released CSV of Table 5 (instrument_divergence_extra/) | n/r | MATCH |  |
| 160 | Table 5, row 'Positions 4–10', column 'Day 45 (9 Sep)' | 15,104 | 15,104 | data:released CSV of Table 5 (instrument_divergence_extra/) | 15,104 | MATCH |  |
| 161 | Table 5, row 'Positions 4–10', column 'Day 60 (24 Sep)' | 28,733 | 28,733 | data:released CSV of Table 5 (instrument_divergence_extra/) | 28,733 | MATCH |  |
| 162 | Table 5, row 'Positions 4–10', column 'Day 75 (9 Oct)' | 33,203 | 33,203 | data:released CSV of Table 5 (instrument_divergence_extra/) | 33,203 | MATCH |  |
| 163 | Table 5, row 'Positions 4–10', column 'Day 77 (11 Oct)' | 33,560 | 33,560 | data:released CSV of Table 5 (instrument_divergence_extra/) | 33,560 | MATCH |  |
| 164 | Table 5, row 'Positions 11–20', column 'Day 0 (26 Jul)' | 0 | 0 | data:released CSV of Table 5 (instrument_divergence_extra/) | 0 | MATCH |  |
| 165 | Table 5, row 'Positions 11–20', column 'Day 15 (10 Aug)' | 909 | 909 | data:released CSV of Table 5 (instrument_divergence_extra/) | 909 | MATCH |  |
| 166 | Table 5, row 'Positions 11–20', column 'Day 30 (25 Aug)' | 2,639 | 2,639 | data:released CSV of Table 5 (instrument_divergence_extra/) | 2,639 | MATCH |  |
| 167 | Table 5, row 'Positions 11–20', column 'Day 37 (1 Sep)' | n/r | **n/r** | data:released CSV of Table 5 (instrument_divergence_extra/) | n/r | MATCH |  |
| 168 | Table 5, row 'Positions 11–20', column 'Day 45 (9 Sep)' | 2,331 | 2,331 | data:released CSV of Table 5 (instrument_divergence_extra/) | 2,331 | MATCH |  |
| 169 | Table 5, row 'Positions 11–20', column 'Day 60 (24 Sep)' | 2,336 | 2,336 | data:released CSV of Table 5 (instrument_divergence_extra/) | 2,336 | MATCH |  |
| 170 | Table 5, row 'Positions 11–20', column 'Day 75 (9 Oct)' | 1,276 | 1,276 | data:released CSV of Table 5 (instrument_divergence_extra/) | 1,276 | MATCH |  |
| 171 | Table 5, row 'Positions 11–20', column 'Day 77 (11 Oct)' | n/r | n/r | data:released CSV of Table 5 (instrument_divergence_extra/) | n/r | MATCH |  |
| 172 | Table 5, row 'Positions 21–100 (derived)', column 'Day 0 (26 Jul)' | 1 | 1 | data:released CSV of Table 5 (instrument_divergence_extra/) | 1 | MATCH |  |
| 173 | Table 5, row 'Positions 21–100 (derived)', column 'Day 15 (10 Aug)' | 255 | 255 | data:released CSV of Table 5 (instrument_divergence_extra/) | 255 | MATCH |  |
| 174 | Table 5, row 'Positions 21–100 (derived)', column 'Day 30 (25 Aug)' | 314 | 314 | data:released CSV of Table 5 (instrument_divergence_extra/) | 314 | MATCH |  |
| 175 | Table 5, row 'Positions 21–100 (derived)', column 'Day 37 (1 Sep)' | n/r | **n/r** | data:released CSV of Table 5 (instrument_divergence_extra/) | n/r | MATCH |  |
| 176 | Table 5, row 'Positions 21–100 (derived)', column 'Day 45 (9 Sep)' | 242 | 242 | data:released CSV of Table 5 (instrument_divergence_extra/) | 242 | MATCH |  |
| 177 | Table 5, row 'Positions 21–100 (derived)', column 'Day 60 (24 Sep)' | 250 | 250 | data:released CSV of Table 5 (instrument_divergence_extra/) | 250 | MATCH |  |
| 178 | Table 5, row 'Positions 21–100 (derived)', column 'Day 75 (9 Oct)' | 70 | 70 | data:released CSV of Table 5 (instrument_divergence_extra/) | 70 | MATCH |  |
| 179 | Table 5, row 'Positions 21–100 (derived)', column 'Day 77 (11 Oct)' | n/r | n/r | data:released CSV of Table 5 (instrument_divergence_extra/) | n/r | MATCH |  |
| 180 | Table 5, row 'Estimated visits (Ahrefs)', column 'Day 0 (26 Jul)' | 2 | 2 | data:released CSV of Table 5 (instrument_divergence_extra/) | 2 | MATCH |  |
| 181 | Table 5, row 'Estimated visits (Ahrefs)', column 'Day 15 (10 Aug)' | 22,016 | 22,016 | data:released CSV of Table 5 (instrument_divergence_extra/) | 22,016 | MATCH |  |
| 182 | Table 5, row 'Estimated visits (Ahrefs)', column 'Day 30 (25 Aug)' | 51,517 | 51,517 | data:released CSV of Table 5 (instrument_divergence_extra/) | 51,517 | MATCH |  |
| 183 | Table 5, row 'Estimated visits (Ahrefs)', column 'Day 37 (1 Sep)' | ≈51,800 | **≈51,800** | data:released CSV of Table 5 (instrument_divergence_extra/) | ≈51,800 | MATCH |  |
| 184 | Table 5, row 'Estimated visits (Ahrefs)', column 'Day 45 (9 Sep)' | 92,897 | 92,897 | data:released CSV of Table 5 (instrument_divergence_extra/) | 92,897 | MATCH |  |
| 185 | Table 5, row 'Estimated visits (Ahrefs)', column 'Day 60 (24 Sep)' | 244,041 | 244,041 | data:released CSV of Table 5 (instrument_divergence_extra/) | 244,041 | MATCH |  |
| 186 | Table 5, row 'Estimated visits (Ahrefs)', column 'Day 75 (9 Oct)' | 221,933 | 221,933 | data:released CSV of Table 5 (instrument_divergence_extra/) | 221,933 | MATCH |  |
| 187 | Table 5, row 'Estimated visits (Ahrefs)', column 'Day 77 (11 Oct)' | n/r | n/r | data:released CSV of Table 5 (instrument_divergence_extra/) | n/r | MATCH |  |
| 188 | Table 5, row 'Live referring domains', column 'Day 0 (26 Jul)' | 0 | 0 | data:released CSV of Table 5 (instrument_divergence_extra/) | 0 | MATCH |  |
| 189 | Table 5, row 'Live referring domains', column 'Day 15 (10 Aug)' | 1 | 1 | data:released CSV of Table 5 (instrument_divergence_extra/) | 1 | MATCH |  |
| 190 | Table 5, row 'Live referring domains', column 'Day 30 (25 Aug)' | 19 | 19 | data:released CSV of Table 5 (instrument_divergence_extra/) | 19 | MATCH |  |
| 191 | Table 5, row 'Live referring domains', column 'Day 37 (1 Sep)' | 19 | **19** | data:released CSV of Table 5 (instrument_divergence_extra/) | 19 | MATCH |  |
| 192 | Table 5, row 'Live referring domains', column 'Day 45 (9 Sep)' | 415 | 415 | data:released CSV of Table 5 (instrument_divergence_extra/) | 415 | MATCH |  |
| 193 | Table 5, row 'Live referring domains', column 'Day 60 (24 Sep)' | 828 | 828 | data:released CSV of Table 5 (instrument_divergence_extra/) | 828 | MATCH |  |
| 194 | Table 5, row 'Live referring domains', column 'Day 75 (9 Oct)' | 909 | 909 | data:released CSV of Table 5 (instrument_divergence_extra/) | 909 | MATCH |  |
| 195 | Table 5, row 'Live referring domains', column 'Day 77 (11 Oct)' | 913 | 913 | data:released CSV of Table 5 (instrument_divergence_extra/) | 913 | MATCH |  |
| 196 | Table 5, row 'AI answers citing the section', column 'Day 0 (26 Jul)' | 0 | 0 | data:released CSV of Table 5 (instrument_divergence_extra/) | 0 | MATCH |  |
| 197 | Table 5, row 'AI answers citing the section', column 'Day 15 (10 Aug)' | 1,603 | 1,603 | data:released CSV of Table 5 (instrument_divergence_extra/) | 1,603 | MATCH |  |
| 198 | Table 5, row 'AI answers citing the section', column 'Day 30 (25 Aug)' | 3,725 | 3,725 | data:released CSV of Table 5 (instrument_divergence_extra/) | 3,725 | MATCH |  |
| 199 | Table 5, row 'AI answers citing the section', column 'Day 37 (1 Sep)' | n/r | **n/r** | data:released CSV of Table 5 (instrument_divergence_extra/) | n/r | MATCH |  |
| 200 | Table 5, row 'AI answers citing the section', column 'Day 45 (9 Sep)' | 6,390 | 6,390 | data:released CSV of Table 5 (instrument_divergence_extra/) | 6,390 | MATCH |  |
| 201 | Table 5, row 'AI answers citing the section', column 'Day 60 (24 Sep)' | 10,266 | 10,266 | data:released CSV of Table 5 (instrument_divergence_extra/) | 10,266 | MATCH |  |
| 202 | Table 5, row 'AI answers citing the section', column 'Day 75 (9 Oct)' | 14,823 | 14,823 | data:released CSV of Table 5 (instrument_divergence_extra/) | 14,823 | MATCH |  |
| 203 | Table 5, row 'AI answers citing the section', column 'Day 77 (11 Oct)' | 17,206 | 17,206 | data:released CSV of Table 5 (instrument_divergence_extra/) | 17,206 | MATCH |  |
| 204 | Table 6, row 'Day 0 to 15', column 'Referring domains' | 0 to 1 | 0 to 1 | data:released CSV of Table 6 (instrument_divergence_extra/) | 0 to 1 | MATCH |  |
| 205 | Table 6, row 'Day 0 to 15', column 'Domains gained' | 1 | 1 | data:released CSV of Table 6 (instrument_divergence_extra/) | 1 | MATCH |  |
| 206 | Table 6, row 'Day 0 to 15', column 'Positions gained' | 3,383 | 3,383 | data:released CSV of Table 6 (instrument_divergence_extra/) | 3,383 | MATCH |  |
| 207 | Table 6, row 'Day 0 to 15', column 'Rate' | 226 / day | 226 / day | data:released CSV of Table 6 (instrument_divergence_extra/) | 226 / day | MATCH |  |
| 208 | Table 6, row 'Day 0 to 15', column 'Link status' | clean | clean | data:released CSV of Table 6 (instrument_divergence_extra/) | clean | MATCH |  |
| 209 | Table 6, row 'Day 15 to 30', column 'Referring domains' | 1 to 19 | 1 to 19 | data:released CSV of Table 6 (instrument_divergence_extra/) | 1 to 19 | MATCH |  |
| 210 | Table 6, row 'Day 15 to 30', column 'Domains gained' | 18 | 18 | data:released CSV of Table 6 (instrument_divergence_extra/) | 18 | MATCH |  |
| 211 | Table 6, row 'Day 15 to 30', column 'Positions gained' | 11,520 | 11,520 | data:released CSV of Table 6 (instrument_divergence_extra/) | 11,520 | MATCH |  |
| 212 | Table 6, row 'Day 15 to 30', column 'Rate' | 768 / day | 768 / day | data:released CSV of Table 6 (instrument_divergence_extra/) | 768 / day | MATCH |  |
| 213 | Table 6, row 'Day 15 to 30', column 'Link status' | clean | clean | data:released CSV of Table 6 (instrument_divergence_extra/) | clean | MATCH |  |
| 214 | Table 6, row 'Day 30 to 37', column 'Referring domains' | 19 to 19 | 19 to 19 | data:released CSV of Table 6 (instrument_divergence_extra/) | 19 to 19 | MATCH |  |
| 215 | Table 6, row 'Day 30 to 37', column 'Domains gained' | 0 | 0 | data:released CSV of Table 6 (instrument_divergence_extra/) | 0 | MATCH |  |
| 216 | Table 6, row 'Day 30 to 37', column 'Positions gained' | 925 | 925 | data:released CSV of Table 6 (instrument_divergence_extra/) | 925 | MATCH |  |
| 217 | Table 6, row 'Day 30 to 37', column 'Rate' | 132 / day | 132 / day | data:released CSV of Table 6 (instrument_divergence_extra/) | 132 / day | MATCH |  |
| 218 | Table 6, row 'Day 30 to 37', column 'Link status' | clean | clean | data:released CSV of Table 6 (instrument_divergence_extra/) | clean | MATCH |  |
| 219 | Table 6, row 'Day 37 to 45', column 'Referring domains' | 19 to 415 | 19 to 415 | data:released CSV of Table 6 (instrument_divergence_extra/) | 19 to 415 | MATCH |  |
| 220 | Table 6, row 'Day 37 to 45', column 'Domains gained' | 396 | 396 | data:released CSV of Table 6 (instrument_divergence_extra/) | 396 | MATCH |  |
| 221 | Table 6, row 'Day 37 to 45', column 'Positions gained' | 4,496 | 4,496 | data:released CSV of Table 6 (instrument_divergence_extra/) | 4,496 | MATCH |  |
| 222 | Table 6, row 'Day 37 to 45', column 'Rate' | 562 / day | 562 / day | data:released CSV of Table 6 (instrument_divergence_extra/) | 562 / day | MATCH |  |
| 223 | Table 6, row 'Day 37 to 45', column 'Link status' | network arriving | network arriving | data:released CSV of Table 6 (instrument_divergence_extra/) | network arriving | MATCH |  |
| 224 | Table 6, row 'Day 45 to 60', column 'Referring domains' | 415 to 828 | 415 to 828 | data:released CSV of Table 6 (instrument_divergence_extra/) | 415 to 828 | MATCH |  |
| 225 | Table 6, row 'Day 45 to 60', column 'Domains gained' | 413 | 413 | data:released CSV of Table 6 (instrument_divergence_extra/) | 413 | MATCH |  |
| 226 | Table 6, row 'Day 45 to 60', column 'Positions gained' | 16,815 | 16,815 | data:released CSV of Table 6 (instrument_divergence_extra/) | 16,815 | MATCH |  |
| 227 | Table 6, row 'Day 45 to 60', column 'Rate' | 1,121 / day | 1,121 / day | data:released CSV of Table 6 (instrument_divergence_extra/) | 1,121 / day | MATCH |  |
| 228 | Table 6, row 'Day 45 to 60', column 'Link status' | network present | network present | data:released CSV of Table 6 (instrument_divergence_extra/) | network present | MATCH |  |
| 229 | Table 6, row 'Day 60 to 75', column 'Referring domains' | 828 to 909 | 828 to 909 | data:released CSV of Table 6 (instrument_divergence_extra/) | 828 to 909 | MATCH |  |
| 230 | Table 6, row 'Day 60 to 75', column 'Domains gained' | 81 | 81 | data:released CSV of Table 6 (instrument_divergence_extra/) | 81 | MATCH |  |
| 231 | Table 6, row 'Day 60 to 75', column 'Positions gained' | 6,161 | 6,161 | data:released CSV of Table 6 (instrument_divergence_extra/) | 6,161 | MATCH |  |
| 232 | Table 6, row 'Day 60 to 75', column 'Rate' | 411 / day | 411 / day | data:released CSV of Table 6 (instrument_divergence_extra/) | 411 / day | MATCH |  |
| 233 | Table 6, row 'Day 60 to 75', column 'Link status' | network present, data notice | network present, data notice | data:released CSV of Table 6 (instrument_divergence_extra/) | network present, data notice | MATCH |  |
| 234 | Table 2, July, Semrush US / Ahrefs worldwide | 25.9x | 25.9x | arith:Table 2 values | 25.8964 | MATCH |  |
| 235 | Table 2, July, worldwide vs worldwide | 26.7x | 26.7x | arith:Table 2 values | 26.6818 | MATCH |  |
| 236 | Table 2, July, US vs US (estimated) | 31.8x | 31.8x | arith:Table 2 values x 81.5% | 31.7748 | MATCH |  |
| 237 | Table 2, August, Semrush US / Ahrefs worldwide | 27.1x | 27.1x | arith:Table 2 values | 27.1414 | MATCH |  |
| 238 | Table 2, August, worldwide vs worldwide | 29.9x | 29.9x | arith:Table 2 values | 29.8608 | MATCH |  |
| 239 | Table 2, August, US vs US (estimated) | 33.3x | 33.3x | arith:Table 2 values x 81.5% | 33.3024 | MATCH |  |
| 240 | Table 2, September, Semrush US / Ahrefs worldwide | 10.2x | 10.2x | arith:Table 2 values | 10.2214 | MATCH |  |
| 241 | Table 2, September, worldwide vs worldwide | 11.8x | 11.8x | arith:Table 2 values | 11.7583 | MATCH |  |
| 242 | Table 2, September, US vs US (estimated) | 12.5x | 12.5x | arith:Table 2 values x 81.5% | 12.5416 | MATCH |  |
| 243 | Table 2, October, Semrush US / Ahrefs worldwide | 7.5x | 7.5x | arith:Table 2 values | 7.46965 | MATCH |  |
| 244 | Table 2, October, worldwide vs worldwide | 8.6x | 8.6x | arith:Table 2 values | 8.62011 | MATCH |  |
| 245 | Table 2, October, US vs US (estimated) | 9.2x | 9.2x | arith:Table 2 values x 81.5% | 9.16521 | MATCH |  |
| 246 | Table 2, days-live column | 78 | 11 (78 in all, days 0 to 77) | arith:Table 2 days-live column | 78 | MATCH |  |
| 247 | Table 2 caption | 81.5% | times 81.5%, Ahrefs' US share read on 11 October | data:single_reads_2026-10.csv | 81.5% | MATCH |  |
| 248 | Table 3, July, share | 16.5% | 16.5% [12.7, 21.3] | arith:Table 3 counts | 16.5493 | MATCH |  |
| 249 | Table 3, July, Wilson lower | 12.7 | 16.5% [12.7, 21.3] | arith:Wilson on Table 3 counts | 12.6794 | MATCH |  |
| 250 | Table 3, July, Wilson upper | 21.3 | 16.5% [12.7, 21.3] | arith:Wilson on Table 3 counts | 21.3121 | MATCH |  |
| 251 | Table 3, July, (b)/(a) | 2.94x | 2.94x | arith:Table 3 counts | 2.93617 | MATCH |  |
| 252 | Table 3, August, share | 12.6% | 12.6% [11.8, 13.4] | arith:Table 3 counts | 12.6093 | MATCH |  |
| 253 | Table 3, August, Wilson lower | 11.8 | 12.6% [11.8, 13.4] | arith:Wilson on Table 3 counts | 11.8385 | MATCH |  |
| 254 | Table 3, August, Wilson upper | 13.4 | 12.6% [11.8, 13.4] | arith:Wilson on Table 3 counts | 13.4226 | MATCH |  |
| 255 | Table 3, August, (b)/(a) | 2.61x | 2.61x | arith:Table 3 counts | 2.60987 | MATCH |  |
| 256 | Table 3, September, share | 14.9% | 14.9% [14.5, 15.4] | arith:Table 3 counts | 14.9129 | MATCH |  |
| 257 | Table 3, September, Wilson lower | 14.5 | 14.9% [14.5, 15.4] | arith:Wilson on Table 3 counts | 14.4551 | MATCH |  |
| 258 | Table 3, September, Wilson upper | 15.4 | 14.9% [14.5, 15.4] | arith:Wilson on Table 3 counts | 15.3826 | MATCH |  |
| 259 | Table 3, September, (b)/(a) | 2.42x | 2.42x | arith:Table 3 counts | 2.42219 | MATCH |  |
| 260 | Table 3, October, share | 20.0% | 20.0% [19.6, 20.4] | arith:Table 3 counts | 20.0199 | MATCH |  |
| 261 | Table 3, October, Wilson lower | 19.6 | 20.0% [19.6, 20.4] | arith:Wilson on Table 3 counts | 19.6165 | MATCH |  |
| 262 | Table 3, October, Wilson upper | 20.4 | 20.0% [19.6, 20.4] | arith:Wilson on Table 3 counts | 20.4294 | MATCH |  |
| 263 | Table 3, October, (b)/(a) | 1.34x | 1.34x | arith:Table 3 counts | 1.3438 | MATCH |  |
| 264 | §5.1 | 8.4x | (8.4x on Ahrefs, 8.8x on Semrush US) | rerun:instrument_extra.py | 8.36 | MATCH |  |
| 265 | §5.1 | 8.8x | (8.4x on Ahrefs, 8.8x on Semrush US) | rerun:instrument_extra.py | 8.76 | MATCH |  |
| 266 | §5.1 | 4.65x | Ahrefs' estimate grew 4.65x and Semrush's 1.75x | rerun:instrument_extra.py | 4.65 | MATCH |  |
| 267 | §5.1 | 1.75x | Ahrefs' estimate grew 4.65x and Semrush's 1.75x | rerun:instrument_extra.py | 1.75 | MATCH |  |
| 268 | §5.1 | 1.44x | into October's run-rate 1.44x against 1.05x | rerun:instrument_extra.py | 1.44 | MATCH |  |
| 269 | §5.1 | 1.05x | into October's run-rate 1.44x against 1.05x | rerun:instrument_extra.py | 1.05 | MATCH |  |
| 270 | §5.1 | more than 2 | by a factor of more than two | rerun:instrument_extra.py | 2.66 | MATCH |  |
| 271 | §5.1 | 18.5% | the section draws 18.5% of its Ahrefs-estimated visits from outside... | data:single_reads_2026-10.csv | 18.5% | MATCH |  |
| 272 | §5.1 | 8.6x | worldwide against worldwide it runs from 8.6x to 29.9x | arith:Table 2 values | 8.62011 | MATCH |  |
| 273 | §5.1 | 29.9x | worldwide against worldwide it runs from 8.6x to 29.9x | arith:Table 2 values | 29.8608 | MATCH |  |
| 274 | §5.1 | 9.2x | and US against US, estimated, from 9.2x to 33.3x | arith:Table 2 values x 81.5% | 9.16521 | MATCH |  |
| 275 | §5.1 | 33.3x | and US against US, estimated, from 9.2x to 33.3x | arith:Table 2 values x 81.5% | 33.3024 | MATCH |  |
| 276 | §5.1 | 27.1x | from 27.1x to 10.2x to 7.5x | arith:Table 2 values | 27.1414 | MATCH |  |
| 277 | §5.1 | 10.2x | from 27.1x to 10.2x to 7.5x | arith:Table 2 values | 10.2214 | MATCH |  |
| 278 | §5.1 | 7.5x | from 27.1x to 10.2x to 7.5x | arith:Table 2 values | 7.46965 | MATCH |  |
| 279 | §5.2 | 29,000 | Ahrefs reports 29,000 for all locations | data:single_reads_2026-10.csv | 29,000 | MATCH |  |
| 280 | §5.2 | 58,586 | Semrush 58,586 for the US database | data:single_reads_2026-10.csv | 58,586 | MATCH |  |
| 281 | §5.2 | 2.0 | a factor of 2.0, again with the larger figure | arith:58,586 / 29,000 | 2.02021 | MATCH |  |
| 282 | §5.2 | 92.3K | is 92.3K (the interface rounds to the hundred) | data:single_reads_2026-10.csv | 92.3K | MATCH |  |
| 283 | §5.2 | 3.2 | 3.2 times Ahrefs' 28,900 for all locations | arith:92,300 / 28,900 | 3.19377 | MATCH |  |
| 284 | §5.2 | 28,900 | 3.2 times Ahrefs' 28,900 for all locations | data:ahrefs/semrush_prefixes_2026-10-12.csv | 28900 | MATCH |  |
| 285 | §5.2 | 441 | Pages holding at least one position are 441 in Ahrefs | data:instrument_series_table5 CSV | 441 | MATCH |  |
| 286 | §5.3 | 17,206 | Brand Radar's 17,206 stored answers citing the section | data:instrument_series_table5 CSV | 17,206 | MATCH |  |
| 287 | §5.3 | 158,100 | Semrush's 158,100 mentions read on 10 October | data:single_reads_2026-10.csv | 158,100 | MATCH |  |
| 288 | §5.3 | 9.2 | differ by a factor of 9.2 | arith:158,100 / 17,206 | 9.18866 | MATCH |  |
| 289 | §5.3 | 29,600 | companion count of 29,600 cited pages | data:single_reads_2026-10.csv | 29,600 | MATCH |  |
| 290 | §5.3 | 68 | is 68 times the 434 URLs the section holds | arith:29,600 / 434 | 68.2028 | MATCH |  |
| 291 | §5.3 | 17,206 | The Ahrefs figure of 17,206 stored answers | data:instrument_series_table5 CSV | 17,206 | MATCH |  |
| 292 | §5.3 Figure 3 caption | 284 | the denominators grow from 284 to 37,238 | data:instrument_series_table3 CSV | 284 | MATCH |  |
| 293 | §5.3 Figure 3 caption | 37,238 | the denominators grow from 284 to 37,238 | data:instrument_series_table3 CSV | 37238 | MATCH |  |
| 294 | §5.3 | 2.94 | falls from 2.94 to 1.34 over four months | arith:Table 3 counts | 2.93617 | MATCH |  |
| 295 | §5.3 | 1.34 | falls from 2.94 to 1.34 over four months | arith:Table 3 counts | 1.3438 | MATCH |  |
| 296 | §5.3 | 47 | The July row rests on 47 events over six days live | data:instrument_series_table3 CSV | 47 | MATCH |  |
| 297 | §5.3 | 6 | The July row rests on 47 events over six days live | data:instrument_series_table2 CSV | 6 | MATCH |  |
| 298 | §5.3 | two orders of magnitude | two orders of magnitude across the series, from 284 to 37,238 | arith:37,238 / 284 | 131x | MATCH |  |
| 299 | §5.4 | 913 | Ahrefs reports 913 referring domains to the prefix | data:single_reads_2026-10.csv | 913 | MATCH |  |
| 300 | §5.4 | 80 | Semrush Backlink Analytics indexes 80 for the subfolder | data:single_reads_2026-10.csv | 80 | MATCH |  |
| 301 | §5.4 | 11.4 | 80 for the subfolder: a factor of 11.4 | arith:913 / 80 | 11.4125 | MATCH |  |
| 302 | §5.4 | 61.9% | Ahrefs puts 61.9% on .info | data:single_reads_2026-10.csv | 61.9% | MATCH |  |
| 303 | §5.4 | 26.4% | 26.4% on .asia | data:single_reads_2026-10.csv | 26.4% | MATCH |  |
| 304 | §5.4 | 10.2% | and 10.2% on .xyz | data:single_reads_2026-10.csv | 10.2% | MATCH |  |
| 305 | §5.4 | 75% | Semrush puts 75% on .xyz | data:single_reads_2026-10.csv | 75% | MATCH |  |
| 306 | §5.4 | 88% | and 88% at Authority Score 0 to 10 | data:single_reads_2026-10.csv | 88% | MATCH |  |
| 307 | §5.4 Figure 4 caption | 913 | Ahrefs: 913 domains; Semrush Backlink Analytics: 80 domains | data:single_reads_2026-10.csv | 913 | MATCH |  |
| 308 | §5.4 Figure 4 caption | 80 | Ahrefs: 913 domains; Semrush Backlink Analytics: 80 domains | data:single_reads_2026-10.csv | 80 | MATCH |  |
| 309 | §5.4 Figure 4 caption | 75% | the instrument reports 75% on .xyz | data:single_reads_2026-10.csv | 75% | MATCH |  |
| 310 | §5.4 | 909 | its daily series gives 909 at day 75 | data:instrument_series_table5 CSV | 909 | MATCH |  |
| 311 | §5.4 | 913 | against 913 on 11 October | data:instrument_series_table5 CSV | 913 | MATCH |  |
| 312 | §5.4 | 917 | gives 917 new against 95 lost | data:single_reads_2026-10.csv | 917 | MATCH |  |
| 313 | §5.4 | 95 | gives 917 new against 95 lost | data:single_reads_2026-10.csv | 95 | MATCH |  |
| 314 | §5.4 | 19 | which with nineteen at day 37 implies about 841 | data:instrument_series_table5 CSV | 19 | MATCH |  |
| 315 | §5.4 | 841 | which with nineteen at day 37 implies about 841 | arith:19 + 917 - 95 | 841 | MATCH |  |
| 316 | Table 4, /local/area-codes/, Age (mo) | 3 | 3 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 3 | MATCH |  |
| 317 | Table 4, /local/area-codes/, Ahrefs visits | 221,000 | 221,000 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 221000 | MATCH |  |
| 318 | Table 4, /local/area-codes/, Semrush visits (US) | 1,600,000 | 1,600,000 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.6e+06 | MATCH |  |
| 319 | Table 4, /local/area-codes/, Ratio, unmatched | 7.24 | **7.24** | data:ahrefs/semrush_prefixes_2026-10-12.csv | 7.23982 | MATCH |  |
| 320 | Table 4, /local/area-codes/, US share | 81.4% | 81.4% | data:ahrefs/semrush_prefixes_2026-10-12.csv | 81.4 | MATCH |  |
| 321 | Table 4, /local/area-codes/, Ratio, matched | 8.89 | **8.89** | data:ahrefs/semrush_prefixes_2026-10-12.csv | 8.89413 | MATCH |  |
| 322 | Table 4, /local/area-codes/, Ahrefs kw | 28,900 | 28,900 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 28900 | MATCH |  |
| 323 | Table 4, /local/area-codes/, Semrush kw | 59,000 | 59,000 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 59000 | MATCH |  |
| 324 | Table 4, /local/area-codes/, Kw ratio | 2.0 | 2.0 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 2.04152 | MATCH |  |
| 325 | Table 4, /local/area-codes/, Ahrefs RD | 913 | 913 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 913 | MATCH |  |
| 326 | Table 4, /local/area-codes/, Semrush RD | 81 | 81 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 81 | MATCH |  |
| 327 | Table 4, /local/area-codes/, RD ratio | 11.3 | **11.3** | data:ahrefs/semrush_prefixes_2026-10-12.csv | 11.2716 | MATCH |  |
| 328 | Table 4, /local/area-codes/, Age (mo) (as printed by instrument_extra.py) | 3 | 3 | rerun:instrument_extra.py | 3 | MATCH |  |
| 329 | Table 4, /local/area-codes/, Ratio, unmatched (as printed by instrument_extra... | 7.24 | **7.24** | rerun:instrument_extra.py | 7.24 | MATCH |  |
| 330 | Table 4, /local/area-codes/, US share (as printed by instrument_extra.py) | 81.4% | 81.4% | rerun:instrument_extra.py | 81.4 | MATCH |  |
| 331 | Table 4, /local/area-codes/, Ratio, matched (as printed by instrument_extra.py) | 8.89 | **8.89** | rerun:instrument_extra.py | 8.89 | MATCH |  |
| 332 | Table 4, /local/area-codes/, Kw ratio (as printed by instrument_extra.py) | 2.0 | 2.0 | rerun:instrument_extra.py | 2.0 | MATCH |  |
| 333 | Table 4, /local/area-codes/, RD ratio (as printed by instrument_extra.py) | 11.3 | **11.3** | rerun:instrument_extra.py | 11.3 | MATCH |  |
| 334 | Table 4, /product-compare/, Age (mo) | 21 | 21 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 21 | MATCH |  |
| 335 | Table 4, /product-compare/, Ahrefs visits | 5,500 | 5,500 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 5500 | MATCH |  |
| 336 | Table 4, /product-compare/, Semrush visits (US) | 4,100 | 4,100 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 4100 | MATCH |  |
| 337 | Table 4, /product-compare/, Ratio, unmatched | 0.75 | 0.75 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 0.745455 | MATCH |  |
| 338 | Table 4, /product-compare/, US share | 69.6% | 69.6% | data:ahrefs/semrush_prefixes_2026-10-12.csv | 69.6 | MATCH |  |
| 339 | Table 4, /product-compare/, Ratio, matched | 1.07 | 1.07 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.07106 | MATCH |  |
| 340 | Table 4, /product-compare/, Ahrefs kw | 716 | 716 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 716 | MATCH |  |
| 341 | Table 4, /product-compare/, Semrush kw | 2,300 | 2,300 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 2300 | MATCH |  |
| 342 | Table 4, /product-compare/, Kw ratio | 3.2 | 3.2 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 3.21229 | MATCH |  |
| 343 | Table 4, /product-compare/, Ahrefs RD | 187 | 187 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 187 | MATCH |  |
| 344 | Table 4, /product-compare/, Semrush RD | 41 | 41 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 41 | MATCH |  |
| 345 | Table 4, /product-compare/, RD ratio | 4.6 | 4.6 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 4.56098 | MATCH |  |
| 346 | Table 4, /product-compare/, Age (mo) (as printed by instrument_extra.py) | 21 | 21 | rerun:instrument_extra.py | 21 | MATCH |  |
| 347 | Table 4, /product-compare/, Ratio, unmatched (as printed by instrument_extra.py) | 0.75 | 0.75 | rerun:instrument_extra.py | 0.75 | MATCH |  |
| 348 | Table 4, /product-compare/, US share (as printed by instrument_extra.py) | 69.6% | 69.6% | rerun:instrument_extra.py | 69.6 | MATCH |  |
| 349 | Table 4, /product-compare/, Ratio, matched (as printed by instrument_extra.py) | 1.07 | 1.07 | rerun:instrument_extra.py | 1.07 | MATCH |  |
| 350 | Table 4, /product-compare/, Kw ratio (as printed by instrument_extra.py) | 3.2 | 3.2 | rerun:instrument_extra.py | 3.2 | MATCH |  |
| 351 | Table 4, /product-compare/, RD ratio (as printed by instrument_extra.py) | 4.6 | 4.6 | rerun:instrument_extra.py | 4.6 | MATCH |  |
| 352 | Table 4, /local/bundles/, Age (mo) | 36 | 36 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 36 | MATCH |  |
| 353 | Table 4, /local/bundles/, Ahrefs visits | 25,600 | 25,600 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 25600 | MATCH |  |
| 354 | Table 4, /local/bundles/, Semrush visits (US) | 5,200 | 5,200 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 5200 | MATCH |  |
| 355 | Table 4, /local/bundles/, Ratio, unmatched | 0.20 | 0.20 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 0.203125 | MATCH |  |
| 356 | Table 4, /local/bundles/, US share | 99.2% | 99.2% | data:ahrefs/semrush_prefixes_2026-10-12.csv | 99.2 | MATCH |  |
| 357 | Table 4, /local/bundles/, Ratio, matched | 0.20 | 0.20 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 0.204763 | MATCH |  |
| 358 | Table 4, /local/bundles/, Ahrefs kw | 2,100 | 2,100 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 2100 | MATCH |  |
| 359 | Table 4, /local/bundles/, Semrush kw | 33,800 | 33,800 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 33800 | MATCH |  |
| 360 | Table 4, /local/bundles/, Kw ratio | 16.1 | 16.1 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 16.0952 | MATCH |  |
| 361 | Table 4, /local/bundles/, Ahrefs RD | 115 | 115 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 115 | MATCH |  |
| 362 | Table 4, /local/bundles/, Semrush RD | 194 | 194 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 194 | MATCH |  |
| 363 | Table 4, /local/bundles/, RD ratio | 0.6 | 0.6 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 0.592784 | MATCH |  |
| 364 | Table 4, /local/bundles/, Age (mo) (as printed by instrument_extra.py) | 36 | 36 | rerun:instrument_extra.py | 36 | MATCH |  |
| 365 | Table 4, /local/bundles/, Ratio, unmatched (as printed by instrument_extra.py) | 0.20 | 0.20 | rerun:instrument_extra.py | 0.20 | MATCH |  |
| 366 | Table 4, /local/bundles/, US share (as printed by instrument_extra.py) | 99.2% | 99.2% | rerun:instrument_extra.py | 99.2 | MATCH |  |
| 367 | Table 4, /local/bundles/, Ratio, matched (as printed by instrument_extra.py) | 0.20 | 0.20 | rerun:instrument_extra.py | 0.20 | MATCH |  |
| 368 | Table 4, /local/bundles/, Kw ratio (as printed by instrument_extra.py) | 16.1 | 16.1 | rerun:instrument_extra.py | 16.1 | MATCH |  |
| 369 | Table 4, /local/bundles/, RD ratio (as printed by instrument_extra.py) | 0.6 | 0.6 | rerun:instrument_extra.py | 0.6 | MATCH |  |
| 370 | Table 4, /device-compare/, Age (mo) | 39 | 39 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 39 | MATCH |  |
| 371 | Table 4, /device-compare/, Ahrefs visits | 26,700 | 26,700 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 26700 | MATCH |  |
| 372 | Table 4, /device-compare/, Semrush visits (US) | 26,400 | 26,400 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 26400 | MATCH |  |
| 373 | Table 4, /device-compare/, Ratio, unmatched | 0.99 | 0.99 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 0.988764 | MATCH |  |
| 374 | Table 4, /device-compare/, US share | 82.6% | 82.6% | data:ahrefs/semrush_prefixes_2026-10-12.csv | 82.6 | MATCH |  |
| 375 | Table 4, /device-compare/, Ratio, matched | 1.20 | 1.20 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.19705 | MATCH |  |
| 376 | Table 4, /device-compare/, Ahrefs kw | 2,400 | 2,400 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 2400 | MATCH |  |
| 377 | Table 4, /device-compare/, Semrush kw | 12,600 | 12,600 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 12600 | MATCH |  |
| 378 | Table 4, /device-compare/, Kw ratio | 5.2 | 5.2 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 5.25 | MATCH |  |
| 379 | Table 4, /device-compare/, Ahrefs RD | 47 | 47 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 47 | MATCH |  |
| 380 | Table 4, /device-compare/, Semrush RD | 45 | 45 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 45 | MATCH |  |
| 381 | Table 4, /device-compare/, RD ratio | 1.0 | 1.0 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.04444 | MATCH |  |
| 382 | Table 4, /device-compare/, Age (mo) (as printed by instrument_extra.py) | 39 | 39 | rerun:instrument_extra.py | 39 | MATCH |  |
| 383 | Table 4, /device-compare/, Ratio, unmatched (as printed by instrument_extra.py) | 0.99 | 0.99 | rerun:instrument_extra.py | 0.99 | MATCH |  |
| 384 | Table 4, /device-compare/, US share (as printed by instrument_extra.py) | 82.6% | 82.6% | rerun:instrument_extra.py | 82.6 | MATCH |  |
| 385 | Table 4, /device-compare/, Ratio, matched (as printed by instrument_extra.py) | 1.20 | 1.20 | rerun:instrument_extra.py | 1.20 | MATCH |  |
| 386 | Table 4, /device-compare/, Kw ratio (as printed by instrument_extra.py) | 5.2 | 5.2 | rerun:instrument_extra.py | 5.2 | MATCH |  |
| 387 | Table 4, /device-compare/, RD ratio (as printed by instrument_extra.py) | 1.0 | 1.0 | rerun:instrument_extra.py | 1.0 | MATCH |  |
| 388 | Table 4, /local/cell-phones/, Age (mo) | 57 | 57 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 57 | MATCH |  |
| 389 | Table 4, /local/cell-phones/, Ahrefs visits | 37,300 | 37,300 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 37300 | MATCH |  |
| 390 | Table 4, /local/cell-phones/, Semrush visits (US) | 135,100 | 135,100 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 135100 | MATCH |  |
| 391 | Table 4, /local/cell-phones/, Ratio, unmatched | 3.62 | 3.62 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 3.62198 | MATCH |  |
| 392 | Table 4, /local/cell-phones/, US share | 98.8% | 98.8% | data:ahrefs/semrush_prefixes_2026-10-12.csv | 98.8 | MATCH |  |
| 393 | Table 4, /local/cell-phones/, Ratio, matched | 3.67 | 3.67 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 3.66598 | MATCH |  |
| 394 | Table 4, /local/cell-phones/, Ahrefs kw | 3,600 | 3,600 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 3600 | MATCH |  |
| 395 | Table 4, /local/cell-phones/, Semrush kw | 37,500 | 37,500 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 37500 | MATCH |  |
| 396 | Table 4, /local/cell-phones/, Kw ratio | 10.4 | 10.4 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 10.4167 | MATCH |  |
| 397 | Table 4, /local/cell-phones/, Ahrefs RD | 144 | 144 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 144 | MATCH |  |
| 398 | Table 4, /local/cell-phones/, Semrush RD | 225 | 225 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 225 | MATCH |  |
| 399 | Table 4, /local/cell-phones/, RD ratio | 0.6 | 0.6 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 0.64 | MATCH |  |
| 400 | Table 4, /local/cell-phones/, Age (mo) (as printed by instrument_extra.py) | 57 | 57 | rerun:instrument_extra.py | 57 | MATCH |  |
| 401 | Table 4, /local/cell-phones/, Ratio, unmatched (as printed by instrument_extr... | 3.62 | 3.62 | rerun:instrument_extra.py | 3.62 | MATCH |  |
| 402 | Table 4, /local/cell-phones/, US share (as printed by instrument_extra.py) | 98.8% | 98.8% | rerun:instrument_extra.py | 98.8 | MATCH |  |
| 403 | Table 4, /local/cell-phones/, Ratio, matched (as printed by instrument_extra.py) | 3.67 | 3.67 | rerun:instrument_extra.py | 3.67 | MATCH |  |
| 404 | Table 4, /local/cell-phones/, Kw ratio (as printed by instrument_extra.py) | 10.4 | 10.4 | rerun:instrument_extra.py | 10.4 | MATCH |  |
| 405 | Table 4, /local/cell-phones/, RD ratio (as printed by instrument_extra.py) | 0.6 | 0.6 | rerun:instrument_extra.py | 0.6 | MATCH |  |
| 406 | Table 4, /support/, Age (mo) | 93 | 93 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 93 | MATCH |  |
| 407 | Table 4, /support/, Ahrefs visits | 1,900,000 | 1,900,000 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.9e+06 | MATCH |  |
| 408 | Table 4, /support/, Semrush visits (US) | 1,957,880 | 1,957,880 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.95788e+06 | MATCH |  |
| 409 | Table 4, /support/, Ratio, unmatched | 1.03 | 1.03 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.03046 | MATCH |  |
| 410 | Table 4, /support/, US share | 98.7% | 98.7% | data:ahrefs/semrush_prefixes_2026-10-12.csv | 98.7 | MATCH |  |
| 411 | Table 4, /support/, Ratio, matched | 1.04 | 1.04 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.04404 | MATCH |  |
| 412 | Table 4, /support/, Ahrefs kw | 38,700 | 38,700 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 38700 | MATCH |  |
| 413 | Table 4, /support/, Semrush kw | 351,854 | 351,854 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 351854 | MATCH |  |
| 414 | Table 4, /support/, Kw ratio | 9.1 | 9.1 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 9.09183 | MATCH |  |
| 415 | Table 4, /support/, Ahrefs RD | 10,600 | 10,600 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 10600 | MATCH |  |
| 416 | Table 4, /support/, Semrush RD | 7,056 | 7,056 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 7056 | MATCH |  |
| 417 | Table 4, /support/, RD ratio | 1.5 | 1.5 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.50227 | MATCH |  |
| 418 | Table 4, /support/, Age (mo) (as printed by instrument_extra.py) | 93 | 93 | rerun:instrument_extra.py | 93 | MATCH |  |
| 419 | Table 4, /support/, Ratio, unmatched (as printed by instrument_extra.py) | 1.03 | 1.03 | rerun:instrument_extra.py | 1.03 | MATCH |  |
| 420 | Table 4, /support/, US share (as printed by instrument_extra.py) | 98.7% | 98.7% | rerun:instrument_extra.py | 98.7 | MATCH |  |
| 421 | Table 4, /support/, Ratio, matched (as printed by instrument_extra.py) | 1.04 | 1.04 | rerun:instrument_extra.py | 1.04 | MATCH |  |
| 422 | Table 4, /support/, Kw ratio (as printed by instrument_extra.py) | 9.1 | 9.1 | rerun:instrument_extra.py | 9.1 | MATCH |  |
| 423 | Table 4, /support/, RD ratio (as printed by instrument_extra.py) | 1.5 | 1.5 | rerun:instrument_extra.py | 1.5 | MATCH |  |
| 424 | Table 4, /local/fiber/, Age (mo) | 95 | 95 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 95 | MATCH |  |
| 425 | Table 4, /local/fiber/, Ahrefs visits | 102,000 | 102,000 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 102000 | MATCH |  |
| 426 | Table 4, /local/fiber/, Semrush visits (US) | 47,300 | 47,300 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 47300 | MATCH |  |
| 427 | Table 4, /local/fiber/, Ratio, unmatched | 0.46 | 0.46 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 0.463725 | MATCH |  |
| 428 | Table 4, /local/fiber/, US share | 99.8% | 99.8% | data:ahrefs/semrush_prefixes_2026-10-12.csv | 99.8 | MATCH |  |
| 429 | Table 4, /local/fiber/, Ratio, matched | 0.46 | 0.46 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 0.464655 | MATCH |  |
| 430 | Table 4, /local/fiber/, Ahrefs kw | 5,400 | 5,400 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 5400 | MATCH |  |
| 431 | Table 4, /local/fiber/, Semrush kw | 31,900 | 31,900 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 31900 | MATCH |  |
| 432 | Table 4, /local/fiber/, Kw ratio | 5.9 | 5.9 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 5.90741 | MATCH |  |
| 433 | Table 4, /local/fiber/, Ahrefs RD | 258 | 258 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 258 | MATCH |  |
| 434 | Table 4, /local/fiber/, Semrush RD | 245 | 245 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 245 | MATCH |  |
| 435 | Table 4, /local/fiber/, RD ratio | 1.1 | 1.1 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.05306 | MATCH |  |
| 436 | Table 4, /local/fiber/, Age (mo) (as printed by instrument_extra.py) | 95 | 95 | rerun:instrument_extra.py | 95 | MATCH |  |
| 437 | Table 4, /local/fiber/, Ratio, unmatched (as printed by instrument_extra.py) | 0.46 | 0.46 | rerun:instrument_extra.py | 0.46 | MATCH |  |
| 438 | Table 4, /local/fiber/, US share (as printed by instrument_extra.py) | 99.8% | 99.8% | rerun:instrument_extra.py | 99.8 | MATCH |  |
| 439 | Table 4, /local/fiber/, Ratio, matched (as printed by instrument_extra.py) | 0.46 | 0.46 | rerun:instrument_extra.py | 0.46 | MATCH |  |
| 440 | Table 4, /local/fiber/, Kw ratio (as printed by instrument_extra.py) | 5.9 | 5.9 | rerun:instrument_extra.py | 5.9 | MATCH |  |
| 441 | Table 4, /local/fiber/, RD ratio (as printed by instrument_extra.py) | 1.1 | 1.1 | rerun:instrument_extra.py | 1.1 | MATCH |  |
| 442 | Table 4, /buy/, Age (mo) | 95 | 95 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 95 | MATCH |  |
| 443 | Table 4, /buy/, Ahrefs visits | 644,000 | 644,000 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 644000 | MATCH |  |
| 444 | Table 4, /buy/, Semrush visits (US) | 1,014,124 | 1,014,124 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.01412e+06 | MATCH |  |
| 445 | Table 4, /buy/, Ratio, unmatched | 1.57 | 1.57 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.57473 | MATCH |  |
| 446 | Table 4, /buy/, US share | 98.5% | 98.5% | data:ahrefs/semrush_prefixes_2026-10-12.csv | 98.5 | MATCH |  |
| 447 | Table 4, /buy/, Ratio, matched | 1.60 | 1.60 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.59871 | MATCH |  |
| 448 | Table 4, /buy/, Ahrefs kw | 19,800 | 19,800 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 19800 | MATCH |  |
| 449 | Table 4, /buy/, Semrush kw | 206,365 | 206,365 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 206365 | MATCH |  |
| 450 | Table 4, /buy/, Kw ratio | 10.4 | 10.4 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 10.4225 | MATCH |  |
| 451 | Table 4, /buy/, Ahrefs RD | 7,400 | 7,400 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 7400 | MATCH |  |
| 452 | Table 4, /buy/, Semrush RD | 3,246 | 3,246 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 3246 | MATCH |  |
| 453 | Table 4, /buy/, RD ratio | 2.3 | 2.3 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 2.27973 | MATCH |  |
| 454 | Table 4, /buy/, Age (mo) (as printed by instrument_extra.py) | 95 | 95 | rerun:instrument_extra.py | 95 | MATCH |  |
| 455 | Table 4, /buy/, Ratio, unmatched (as printed by instrument_extra.py) | 1.57 | 1.57 | rerun:instrument_extra.py | 1.57 | MATCH |  |
| 456 | Table 4, /buy/, US share (as printed by instrument_extra.py) | 98.5% | 98.5% | rerun:instrument_extra.py | 98.5 | MATCH |  |
| 457 | Table 4, /buy/, Ratio, matched (as printed by instrument_extra.py) | 1.60 | 1.60 | rerun:instrument_extra.py | 1.60 | MATCH |  |
| 458 | Table 4, /buy/, Kw ratio (as printed by instrument_extra.py) | 10.4 | 10.4 | rerun:instrument_extra.py | 10.4 | MATCH |  |
| 459 | Table 4, /buy/, RD ratio (as printed by instrument_extra.py) | 2.3 | 2.3 | rerun:instrument_extra.py | 2.3 | MATCH |  |
| 460 | Table 4, /local/internet/, Age (mo) | 114 | 114 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 114 | MATCH |  |
| 461 | Table 4, /local/internet/, Ahrefs visits | 243,000 | 243,000 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 243000 | MATCH |  |
| 462 | Table 4, /local/internet/, Semrush visits (US) | 220,600 | 220,600 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 220600 | MATCH |  |
| 463 | Table 4, /local/internet/, Ratio, unmatched | 0.91 | 0.91 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 0.907819 | MATCH |  |
| 464 | Table 4, /local/internet/, US share | 93.6% | 93.6% | data:ahrefs/semrush_prefixes_2026-10-12.csv | 93.6 | MATCH |  |
| 465 | Table 4, /local/internet/, Ratio, matched | 0.97 | 0.97 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 0.969892 | MATCH |  |
| 466 | Table 4, /local/internet/, Ahrefs kw | 13,300 | 13,300 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 13300 | MATCH |  |
| 467 | Table 4, /local/internet/, Semrush kw | 79,700 | 79,700 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 79700 | MATCH |  |
| 468 | Table 4, /local/internet/, Kw ratio | 6.0 | 6.0 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 5.99248 | MATCH |  |
| 469 | Table 4, /local/internet/, Ahrefs RD | 1,700 | 1,700 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1700 | MATCH |  |
| 470 | Table 4, /local/internet/, Semrush RD | 516 | 516 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 516 | MATCH |  |
| 471 | Table 4, /local/internet/, RD ratio | 3.3 | 3.3 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 3.29457 | MATCH |  |
| 472 | Table 4, /local/internet/, Age (mo) (as printed by instrument_extra.py) | 114 | 114 | rerun:instrument_extra.py | 114 | MATCH |  |
| 473 | Table 4, /local/internet/, Ratio, unmatched (as printed by instrument_extra.py) | 0.91 | 0.91 | rerun:instrument_extra.py | 0.91 | MATCH |  |
| 474 | Table 4, /local/internet/, US share (as printed by instrument_extra.py) | 93.6% | 93.6% | rerun:instrument_extra.py | 93.6 | MATCH |  |
| 475 | Table 4, /local/internet/, Ratio, matched (as printed by instrument_extra.py) | 0.97 | 0.97 | rerun:instrument_extra.py | 0.97 | MATCH |  |
| 476 | Table 4, /local/internet/, Kw ratio (as printed by instrument_extra.py) | 6.0 | 6.0 | rerun:instrument_extra.py | 6.0 | MATCH |  |
| 477 | Table 4, /local/internet/, RD ratio (as printed by instrument_extra.py) | 3.3 | 3.3 | rerun:instrument_extra.py | 3.3 | MATCH |  |
| 478 | Table 4, /stores/, Age (mo) | 129 | 129 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 129 | MATCH |  |
| 479 | Table 4, /stores/, Ahrefs visits | 312,000 | 312,000 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 312000 | MATCH |  |
| 480 | Table 4, /stores/, Semrush visits (US) | 2,051,269 | 2,051,269 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 2.05127e+06 | MATCH |  |
| 481 | Table 4, /stores/, Ratio, unmatched | 6.57 | 6.57 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 6.57458 | MATCH |  |
| 482 | Table 4, /stores/, US share | 99.4% | 99.4% | data:ahrefs/semrush_prefixes_2026-10-12.csv | 99.4 | MATCH |  |
| 483 | Table 4, /stores/, Ratio, matched | 6.61 | 6.61 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 6.61427 | MATCH |  |
| 484 | Table 4, /stores/, Ahrefs kw | 14,700 | 14,700 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 14700 | MATCH |  |
| 485 | Table 4, /stores/, Semrush kw | 306,952 | 306,952 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 306952 | MATCH |  |
| 486 | Table 4, /stores/, Kw ratio | 20.9 | 20.9 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 20.8811 | MATCH |  |
| 487 | Table 4, /stores/, Ahrefs RD | 4,100 | 4,100 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 4100 | MATCH |  |
| 488 | Table 4, /stores/, Semrush RD | 3,527 | 3,527 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 3527 | MATCH |  |
| 489 | Table 4, /stores/, RD ratio | 1.2 | 1.2 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.16246 | MATCH |  |
| 490 | Table 4, /stores/, Age (mo) (as printed by instrument_extra.py) | 129 | 129 | rerun:instrument_extra.py | 129 | MATCH |  |
| 491 | Table 4, /stores/, Ratio, unmatched (as printed by instrument_extra.py) | 6.57 | 6.57 | rerun:instrument_extra.py | 6.57 | MATCH |  |
| 492 | Table 4, /stores/, US share (as printed by instrument_extra.py) | 99.4% | 99.4% | rerun:instrument_extra.py | 99.4 | MATCH |  |
| 493 | Table 4, /stores/, Ratio, matched (as printed by instrument_extra.py) | 6.61 | 6.61 | rerun:instrument_extra.py | 6.61 | MATCH |  |
| 494 | Table 4, /stores/, Kw ratio (as printed by instrument_extra.py) | 20.9 | 20.9 | rerun:instrument_extra.py | 20.9 | MATCH |  |
| 495 | Table 4, /stores/, RD ratio (as printed by instrument_extra.py) | 1.2 | 1.2 | rerun:instrument_extra.py | 1.2 | MATCH |  |
| 496 | Table 4, /deals/, Age (mo) | 132 | 132 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 132 | MATCH |  |
| 497 | Table 4, /deals/, Ahrefs visits | 214,000 | 214,000 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 214000 | MATCH |  |
| 498 | Table 4, /deals/, Semrush visits (US) | 219,600 | 219,600 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 219600 | MATCH |  |
| 499 | Table 4, /deals/, Ratio, unmatched | 1.03 | 1.03 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.02617 | MATCH |  |
| 500 | Table 4, /deals/, US share | 99.3% | 99.3% | data:ahrefs/semrush_prefixes_2026-10-12.csv | 99.3 | MATCH |  |
| 501 | Table 4, /deals/, Ratio, matched | 1.03 | 1.03 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1.0334 | MATCH |  |
| 502 | Table 4, /deals/, Ahrefs kw | 5,300 | 5,300 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 5300 | MATCH |  |
| 503 | Table 4, /deals/, Semrush kw | 32,000 | 32,000 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 32000 | MATCH |  |
| 504 | Table 4, /deals/, Kw ratio | 6.0 | 6.0 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 6.03774 | MATCH |  |
| 505 | Table 4, /deals/, Ahrefs RD | 1,600 | 1,600 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1600 | MATCH |  |
| 506 | Table 4, /deals/, Semrush RD | 2,042 | 2,042 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 2042 | MATCH |  |
| 507 | Table 4, /deals/, RD ratio | 0.8 | 0.8 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 0.783546 | MATCH |  |
| 508 | Table 4, /deals/, Age (mo) (as printed by instrument_extra.py) | 132 | 132 | rerun:instrument_extra.py | 132 | MATCH |  |
| 509 | Table 4, /deals/, Ratio, unmatched (as printed by instrument_extra.py) | 1.03 | 1.03 | rerun:instrument_extra.py | 1.03 | MATCH |  |
| 510 | Table 4, /deals/, US share (as printed by instrument_extra.py) | 99.3% | 99.3% | rerun:instrument_extra.py | 99.3 | MATCH |  |
| 511 | Table 4, /deals/, Ratio, matched (as printed by instrument_extra.py) | 1.03 | 1.03 | rerun:instrument_extra.py | 1.03 | MATCH |  |
| 512 | Table 4, /deals/, Kw ratio (as printed by instrument_extra.py) | 6.0 | 6.0 | rerun:instrument_extra.py | 6.0 | MATCH |  |
| 513 | Table 4, /deals/, RD ratio (as printed by instrument_extra.py) | 0.8 | 0.8 | rerun:instrument_extra.py | 0.8 | MATCH |  |
| 514 | Table 4, /es-us/local/, Age (mo) | 133 | 133 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 133 | MATCH |  |
| 515 | Table 4, /es-us/local/, Ahrefs visits | 8,900 | 8,900 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 8900 | MATCH |  |
| 516 | Table 4, /es-us/local/, Semrush visits (US) | 2,200 | 2,200 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 2200 | MATCH |  |
| 517 | Table 4, /es-us/local/, Ratio, unmatched | 0.25 | 0.25 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 0.247191 | MATCH |  |
| 518 | Table 4, /es-us/local/, US share | 42.6% | 42.6% | data:ahrefs/semrush_prefixes_2026-10-12.csv | 42.6 | MATCH |  |
| 519 | Table 4, /es-us/local/, Ratio, matched | 0.58 | 0.58 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 0.580261 | MATCH |  |
| 520 | Table 4, /es-us/local/, Ahrefs kw | 1,300 | 1,300 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1300 | MATCH |  |
| 521 | Table 4, /es-us/local/, Semrush kw | 4,800 | 4,800 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 4800 | MATCH |  |
| 522 | Table 4, /es-us/local/, Kw ratio | 3.7 | 3.7 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 3.69231 | MATCH |  |
| 523 | Table 4, /es-us/local/, Ahrefs RD | 284 | 284 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 284 | MATCH |  |
| 524 | Table 4, /es-us/local/, Semrush RD | 62 | 62 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 62 | MATCH |  |
| 525 | Table 4, /es-us/local/, RD ratio | 4.6 | 4.6 | data:ahrefs/semrush_prefixes_2026-10-12.csv | 4.58065 | MATCH |  |
| 526 | Table 4, /es-us/local/, Age (mo) (as printed by instrument_extra.py) | 133 | 133 | rerun:instrument_extra.py | 133 | MATCH |  |
| 527 | Table 4, /es-us/local/, Ratio, unmatched (as printed by instrument_extra.py) | 0.25 | 0.25 | rerun:instrument_extra.py | 0.25 | MATCH |  |
| 528 | Table 4, /es-us/local/, US share (as printed by instrument_extra.py) | 42.6% | 42.6% | rerun:instrument_extra.py | 42.6 | MATCH |  |
| 529 | Table 4, /es-us/local/, Ratio, matched (as printed by instrument_extra.py) | 0.58 | 0.58 | rerun:instrument_extra.py | 0.58 | MATCH |  |
| 530 | Table 4, /es-us/local/, Kw ratio (as printed by instrument_extra.py) | 3.7 | 3.7 | rerun:instrument_extra.py | 3.7 | MATCH |  |
| 531 | Table 4, /es-us/local/, RD ratio (as printed by instrument_extra.py) | 4.6 | 4.6 | rerun:instrument_extra.py | 4.6 | MATCH |  |
| 532 | Table 4 caption | within four months | and the next two lie within four months of it | data:ahrefs/semrush_prefixes_2026-10-12.csv | 1 and 4 months | MATCH |  |
| 533 | Table 4 caption | 29,000 | (29,000 and 58,586 keywords; 80 Semrush domains, 11.4x) | data:single_reads_2026-10.csv | 29,000 | MATCH |  |
| 534 | Table 4 caption | 58,586 | (29,000 and 58,586 keywords; 80 Semrush domains, 11.4x) | data:single_reads_2026-10.csv | 58,586 | MATCH |  |
| 535 | Table 4 caption | 80 | (29,000 and 58,586 keywords; 80 Semrush domains, 11.4x) | data:single_reads_2026-10.csv | 80 | MATCH |  |
| 536 | Table 4 caption | 11.4x | (29,000 and 58,586 keywords; 80 Semrush domains, 11.4x) | arith:913 / 80 | 11.4125 | MATCH |  |
| 537 | §5.5 Figure 5 caption | 12 prefixes | (a) The Semrush over Ahrefs ratio | data:ahrefs/semrush_prefixes_2026-10-12.csv | 12 | MATCH |  |
| 538 | §5.5 para 'no detectable relationship' | −0.11 | and the unmatched visits ratio is −0.11 over twelve prefixes | rerun:analyze.py | -0.11 | MATCH |  |
| 539 | §5.5 para 'no detectable relationship' | −0.64 | with a Fisher 95% interval of −0.64 to +0.49 | rerun:analyze.py | -0.64 | MATCH |  |
| 540 | §5.5 para 'no detectable relationship' | +0.49 | with a Fisher 95% interval of −0.64 to +0.49 | rerun:analyze.py | +0.49 | MATCH |  |
| 541 | §5.5 para 'no detectable relationship' | 0.73 | and a permutation p of 0.73 | rerun:analyze.py | 0.73 | MATCH |  |
| 542 | §5.5 para 'no detectable relationship' | −0.28 | territory-matched it is −0.28 | rerun:analyze.py | -0.28 | MATCH |  |
| 543 | §5.5 para 'no detectable relationship' | +0.15 | excluding the area-code section it is +0.15 | rerun:analyze.py | +0.15 | MATCH |  |
| 544 | §5.5 para 'no detectable relationship' | 38% | Twelve prefixes give about 38% power | rerun:instrument_extra.py | 37.8 | MATCH |  |
| 545 | §5.5 para 'no detectable relationship' | 37.8% | (37.8% by the Fisher approximation) | rerun:instrument_extra.py | 37.8 | MATCH |  |
| 546 | §5.5 para 'no detectable relationship' | 7 | the seven sections aged between seven and eleven years | rerun:instrument_extra.py | 7 | MATCH |  |
| 547 | §5.5 para 'no detectable relationship' | 0.25x | sit anywhere from 0.25x to 6.57x unmatched | rerun:instrument_extra.py | 0.25 | MATCH |  |
| 548 | §5.5 para 'no detectable relationship' | 6.57x | sit anywhere from 0.25x to 6.57x unmatched | rerun:instrument_extra.py | 6.57 | MATCH |  |
| 549 | §5.5 para 'no detectable relationship' | 0.46x | (0.46x to 6.61x matched) | rerun:instrument_extra.py | 0.46 | MATCH |  |
| 550 | §5.5 para 'no detectable relationship' | 6.61x | (0.46x to 6.61x matched) | rerun:instrument_extra.py | 6.61 | MATCH |  |
| 551 | §5.5 para 'no detectable relationship' | 27.1x | from 27.1x to 7.5x over three months | arith:Table 2 values | 27.1414 | MATCH |  |
| 552 | §5.5 para 'no detectable relationship' | 7.5x | from 27.1x to 7.5x over three months | arith:Table 2 values | 7.46965 | MATCH |  |
| 553 | §5.5 para 'no detectable relationship' | 1 | Only one prefix in the cross-section is under twenty-one months old | rerun:instrument_extra.py | 1 | MATCH |  |
| 554 | §5.5 para 'prefix-specific' | 0.20x | one fifth of Ahrefs' (/local/bundles/, 0.20x) | rerun:analyze.py | 0.20 | MATCH |  |
| 555 | §5.5 para 'prefix-specific' | 7.24x | to seven times it (/local/area-codes/, 7.24x) | rerun:analyze.py | 7.24 | MATCH |  |
| 556 | §5.5 para 'prefix-specific' | 1.55 | a spread of 1.55 orders of magnitude | rerun:analyze.py | 1.55 | MATCH |  |
| 557 | §5.5 para 'prefix-specific' | 1.01 | with a median of 1.01 | rerun:analyze.py | 1.01 | MATCH |  |
| 558 | §5.5 para 'prefix-specific' | 6 | and six of twelve prefixes below one | rerun:analyze.py | 6 | MATCH |  |
| 559 | §5.5 para 'prefix-specific' | 0.20x | Matched for territory the spread is wider (0.20x to 8.89x) | rerun:analyze.py | 0.20 | MATCH |  |
| 560 | §5.5 para 'prefix-specific' | 8.89x | Matched for territory the spread is wider (0.20x to 8.89x) | rerun:analyze.py | 8.89 | MATCH |  |
| 561 | §5.5 para 'prefix-specific' | 1.06 | the median is 1.06 | rerun:analyze.py | 1.06 | MATCH |  |
| 562 | §5.5 para 'prefix-specific' | 4 | and four of twelve are below one | rerun:analyze.py | 4 | MATCH |  |
| 563 | §5.5 para 'prefix-specific' | 2 | two of the six sub-one prefixes cross one | rerun:analyze.py | 2 | MATCH |  |
| 564 | §5.5 para 'prefix-specific' | 69.6% | /product-compare/, 69.6% US | rerun:instrument_extra.py | 69.6 | MATCH |  |
| 565 | §5.5 para 'prefix-specific' | 0.75x | from 0.75x to 1.07x | rerun:instrument_extra.py | 0.75 | MATCH |  |
| 566 | §5.5 para 'prefix-specific' | 1.07x | from 0.75x to 1.07x | rerun:instrument_extra.py | 1.07 | MATCH |  |
| 567 | §5.5 para 'prefix-specific' | 82.6% | /device-compare/, 82.6% US | rerun:instrument_extra.py | 82.6 | MATCH |  |
| 568 | §5.5 para 'prefix-specific' | 0.99x | from 0.99x to 1.20x | rerun:instrument_extra.py | 0.99 | MATCH |  |
| 569 | §5.5 para 'prefix-specific' | 1.20x | from 0.99x to 1.20x | rerun:instrument_extra.py | 1.20 | MATCH |  |
| 570 | §5.5 para 'prefix-specific' | 42.6% | /es-us/local/, at 42.6% US, moves from 0.25x to 0.58x | rerun:instrument_extra.py | 42.6 | MATCH |  |
| 571 | §5.5 para 'prefix-specific' | 0.25x | from 0.25x to 0.58x | rerun:instrument_extra.py | 0.25 | MATCH |  |
| 572 | §5.5 para 'prefix-specific' | 0.58x | from 0.25x to 0.58x | rerun:instrument_extra.py | 0.58 | MATCH |  |
| 573 | §5.5 para 'prefix-specific' | 1.13 | has a geometric mean of 1.13 | rerun:instrument_extra.py | 1.13 | MATCH |  |
| 574 | §5.5 para 'prefix-specific' | 0.62 | (bootstrap 95% interval 0.62 to 2.12) | rerun:instrument_extra.py | 0.62 | MATCH |  |
| 575 | §5.5 para 'prefix-specific' | 2.12 | (bootstrap 95% interval 0.62 to 2.12) | rerun:instrument_extra.py | 2.12 | MATCH |  |
| 576 | §5.5 para 'prefix-specific' | 3.1 | a geometric standard deviation of 3.1 (1.9 to 4.1) | rerun:instrument_extra.py | 3.13 | MATCH |  |
| 577 | §5.5 para 'prefix-specific' | 1.9 | a geometric standard deviation of 3.1 (1.9 to 4.1) | rerun:instrument_extra.py | 1.92 | MATCH |  |
| 578 | §5.5 para 'prefix-specific' | 4.1 | a geometric standard deviation of 3.1 (1.9 to 4.1) | rerun:instrument_extra.py | 4.14 | MATCH |  |
| 579 | §5.5 para 'prefix-specific' | 0.12x | a normal range on the log scale of about 0.12x to 10.6x | rerun:instrument_extra.py | 0.12 | MATCH |  |
| 580 | §5.5 para 'prefix-specific' | 10.6x | a normal range on the log scale of about 0.12x to 10.6x | rerun:instrument_extra.py | 10.61 | MATCH |  |
| 581 | §5.5 para 'ordering' | +0.94 | visit estimates is +0.94 (bootstrap 95% interval over prefixes +0.7... | rerun:instrument_extra.py | +0.94 | MATCH |  |
| 582 | §5.5 para 'ordering' | +0.70 | visit estimates is +0.94 (bootstrap 95% interval over prefixes +0.7... | rerun:instrument_extra.py | +0.70 | MATCH |  |
| 583 | §5.5 para 'ordering' | +1.00 | visit estimates is +0.94 (bootstrap 95% interval over prefixes +0.7... | rerun:instrument_extra.py | +1.00 | MATCH |  |
| 584 | §5.5 para 'ordering' | p < 0.001 | p < 0.001; Kendall's tau +0.82 | rerun:instrument_extra.py | 7e-06 | MATCH |  |
| 585 | §5.5 para 'ordering' | +0.82 | p < 0.001; Kendall's tau +0.82 | rerun:instrument_extra.py | +0.82 | MATCH |  |
| 586 | §5.5 para 'ordering' | +0.57 | interval +0.57 to +1.00; 60 of 66 pairs concordant | rerun:instrument_extra.py | +0.57 | MATCH |  |
| 587 | §5.5 para 'ordering' | +1.00 | interval +0.57 to +1.00; 60 of 66 pairs concordant | rerun:instrument_extra.py | +1.00 | MATCH |  |
| 588 | §5.5 para 'ordering' | 60 of 66 | interval +0.57 to +1.00; 60 of 66 pairs concordant | rerun:analyze.py | 60 of 66 | MATCH |  |
| 589 | §5.5 para 'ordering' | 60 of 66 | The vendors agree on which section is larger in 60 of 66 pairs | rerun:analyze.py | 60 of 66 | MATCH |  |
| 590 | §5.5 para 'ordering' | 51 | differ by more than a factor of three, all 51 are ordered alike | rerun:instrument_extra.py | 51 | MATCH | 19 of 19 (3x to 10x) + 32 of 32 (over 10x) |
| 591 | §5.5 para 'ordering' | all | differ by more than a factor of three, all 51 are ordered alike | rerun:instrument_extra.py | 51 of 51 | MATCH |  |
| 592 | §5.5 para 'ordering' | 15 | of the 15 pairs within a factor of three, 9 are | rerun:instrument_extra.py | 15 | MATCH |  |
| 593 | §5.5 para 'ordering' | 9 | of the 15 pairs within a factor of three, 9 are | rerun:instrument_extra.py | 9 | MATCH |  |
| 594 | §5.5 para 'keyword universes' | 2.0x | by between 2.0x and 20.9x | rerun:analyze.py | 2.0 | MATCH |  |
| 595 | §5.5 para 'keyword universes' | 20.9x | by between 2.0x and 20.9x | rerun:analyze.py | 20.9 | MATCH |  |
| 596 | §5.5 para 'keyword universes' | every prefix | Semrush reports more ranking keywords than Ahrefs on every prefix | rerun:analyze.py | all above one | MATCH |  |
| 597 | §5.5 para 'keyword universes' | +0.17 | the visits ratio is +0.17 over all twelve | rerun:analyze.py | +0.17 | MATCH |  |
| 598 | §5.5 para 'keyword universes' | +0.52 | and +0.52 with the area-code section excluded | rerun:analyze.py | +0.52 | MATCH |  |
| 599 | §5.5 para 'keyword universes' | 16.1x | /local/bundles/ has the second-largest keyword ratio (16.1x) | rerun:instrument_extra.py | 16.1 | MATCH |  |
| 600 | §5.5 para 'keyword universes' | second-largest | /local/bundles/ has the second-largest keyword ratio (16.1x) | rerun:instrument_extra.py | second | MATCH |  |
| 601 | §5.5 para 'keyword universes' | 0.20x | and the smallest visits ratio (0.20x) | rerun:analyze.py | 0.20 | MATCH |  |
| 602 | §5.5 para 'keyword universes' | 0.60 | (two-sided p = 0.60 over all twelve | rerun:instrument_extra.py | 0.60 | MATCH |  |
| 603 | §5.5 para 'keyword universes' | 0.10 | and 0.10 without the area-code section | rerun:instrument_extra.py | 0.10 | MATCH | t approximation; the permutation p printed beside it is 0.11 |
| 604 | §5.5 para 'studied section' | 7.24x | It has the highest visits ratio (7.24x unmatched, 8.89x matched | rerun:analyze.py | 7.24 | MATCH |  |
| 605 | §5.5 para 'studied section' | 8.89x | It has the highest visits ratio (7.24x unmatched, 8.89x matched | rerun:analyze.py | 8.89 | MATCH |  |
| 606 | §5.5 para 'studied section' | 6.57x | /stores/ is next at 6.57x | rerun:analyze.py | 6.57 | MATCH |  |
| 607 | §5.5 para 'studied section' | 11.3x | and the highest referring-domain ratio (11.3x) | rerun:instrument_extra.py | 11.3 | MATCH |  |
| 608 | §5.5 para 'studied section' | 158.3K | Semrush's AI-visibility panel reported 158.3K mentions and 29.5K ci... | data:single_reads_2026-10.csv | 158.3K | MATCH |  |
| 609 | §5.5 para 'studied section' | 29.5K | Semrush's AI-visibility panel reported 158.3K mentions and 29.5K ci... | data:single_reads_2026-10.csv | 29.5K | MATCH |  |
| 610 | §5.5 para 'studied section' | 158,100 | (Section 5.3 quotes the 10 October read of 158,100 and 29,600) | data:single_reads_2026-10.csv | 158,100 | MATCH |  |
| 611 | §5.5 para 'studied section' | 29,600 | (Section 5.3 quotes the 10 October read of 158,100 and 29,600) | data:single_reads_2026-10.csv | 29,600 | MATCH |  |
| 612 | §5.6 | 27.1x | At the August ratio of 27.1x | arith:Table 2 values | 27.1414 | MATCH |  |
| 613 | §5.6 | 5.2 | within a factor of 5.2, the square root of 27.1 | arith:sqrt of the August ratio | 5.20975 | MATCH |  |
| 614 | §5.6 | 13 | the larger of the two errors is at least 13 times the smaller reading | arith:(876,153 - 32,281) / 2 / 32,281 | 13.0707 | MATCH |  |
| 615 | §5.6 | 27.1 | The ratio falls 27.1 → 10.2 → 7.5 over three months | arith:Table 2 values | 27.1414 | MATCH |  |
| 616 | §5.6 | 10.2 | The ratio falls 27.1 → 10.2 → 7.5 over three months | arith:Table 2 values | 10.2214 | MATCH |  |
| 617 | §5.6 | 7.5 | The ratio falls 27.1 → 10.2 → 7.5 over three months | arith:Table 2 values | 7.46965 | MATCH |  |
| 618 | §5.6 | 7.47x | 7.47x = 2.02x (keyword universe) × 3.70x (estimated visits per rank... | rerun:instrument_extra.py | 7.47 | MATCH |  |
| 619 | §5.6 | 2.02x | 7.47x = 2.02x (keyword universe) × 3.70x (estimated visits per rank... | rerun:instrument_extra.py | 2.02 | MATCH |  |
| 620 | §5.6 | 3.70x | 7.47x = 2.02x (keyword universe) × 3.70x (estimated visits per rank... | rerun:instrument_extra.py | 3.70 | MATCH |  |
| 621 | §5.6 | 35% | accounts for about 35% of the divergence in log terms | rerun:instrument_extra.py | 35 | MATCH |  |
| 622 | §5.6 | 8.62x | it is 8.62x = 3.19x (keyword universe) × 2.70x (per keyword) | rerun:instrument_extra.py | 8.62 | MATCH |  |
| 623 | §5.6 | 3.19x | it is 8.62x = 3.19x (keyword universe) × 2.70x (per keyword) | rerun:instrument_extra.py | 3.19 | MATCH |  |
| 624 | §5.6 | 2.70x | it is 8.62x = 3.19x (keyword universe) × 2.70x (per keyword) | rerun:instrument_extra.py | 2.70 | MATCH |  |
| 625 | §5.6 | 54% | and the keyword universe accounts for about 54% | rerun:instrument_extra.py | 54 | MATCH |  |
| 626 | §5.6 | 8.62x | Matching worldwide to worldwide gives 8.62x for October | arith:Table 2 values | 8.62011 | MATCH |  |
| 627 | §5.6 | 26.7x | and 26.7x to 29.9x in the first two months | arith:Table 2 values | 26.6818 | MATCH |  |
| 628 | §5.6 | 29.9x | and 26.7x to 29.9x in the first two months | arith:Table 2 values | 29.8608 | MATCH |  |
| 629 | §5.6 | 18.5% | deflating the Ahrefs figure by the 18.5% non-US share | data:single_reads_2026-10.csv | 18.5% | MATCH |  |
| 630 | §5.6 | 9.17x | gives **9.17x** for October | arith:Table 2 values x 81.5% | 9.16521 | MATCH |  |
| 631 | §5.6 | 7.5x | for October against the 7.5x unmatched | arith:Table 2 values | 7.46965 | MATCH |  |
| 632 | §5.6 | 31.8x | gives 31.8x, 33.3x and 12.5x (Table 2) | arith:Table 2 values x 81.5% | 31.7748 | MATCH |  |
| 633 | §5.6 | 33.3x | gives 31.8x, 33.3x and 12.5x (Table 2) | arith:Table 2 values x 81.5% | 33.3024 | MATCH |  |
| 634 | §5.6 | 12.5x | gives 31.8x, 33.3x and 12.5x (Table 2) | arith:Table 2 values x 81.5% | 12.5416 | MATCH |  |
| 635 | §5.6 | 0.20x | spans 0.20x to 7.24x (0.20x to 8.89x territory-matched) | rerun:analyze.py | 0.20 | MATCH |  |
| 636 | §5.6 | 7.24x | spans 0.20x to 7.24x (0.20x to 8.89x territory-matched) | rerun:analyze.py | 7.24 | MATCH |  |
| 637 | §5.6 | 8.89x | spans 0.20x to 7.24x (0.20x to 8.89x territory-matched) | rerun:analyze.py | 8.89 | MATCH |  |
| 638 | §5.6 | 60 of 66 | which of two sections is larger in 60 of 66 pairs | rerun:analyze.py | 60 of 66 | MATCH |  |
| 639 | §5.6 | 9 of 15 | within a factor of three (9 of 15 pairs) | rerun:instrument_extra.py | 9 of 15 | MATCH |  |
| 640 | §5.6 | two pairs, 6x to 7x apart | two pairs six to seven times apart were ordered the other way on th... | rerun:instrument_extra.py | 2 pairs: 7.3x, 6.1x | MATCH |  |
| 641 | §5.6 | five below | can differ by a factor of five below to nearly nine above | rerun:analyze.py | 1/0.20 = 5.0 | MATCH |  |
| 642 | §5.6 | nearly nine above | can differ by a factor of five below to nearly nine above | rerun:analyze.py | 8.89 | MATCH |  |
| 643 | §5.6 | 2.7 | also differed, by a factor of 2.7 in one month | rerun:instrument_extra.py | 2.66 | MATCH |  |
| 644 | §5.6 limits | five below to nearly nine above | from a factor of five below to nearly nine above, that no relationship | rerun:analyze.py | 0.20x to 8.89x | MATCH |  |
| 645 | §5.6 limits | 1 | only one of them under twenty-one months old | rerun:instrument_extra.py | 1 | MATCH |  |
| 646 | §6 para 1 | 47,485 | It holds 47,485 Google reviews of 379 retail locations | shipped:supplement_r10_output.txt | 47485 | CANNOT RUN | paper agrees with the saved output |
| 647 | §6 para 1 | 379 | It holds 47,485 Google reviews of 379 retail locations | shipped:supplement_r10_output.txt | 379 | CANNOT RUN | paper agrees with the saved output |
| 648 | §6 para 1 | 37,193 | of which 37,193 carry text, at 378 of the locations | shipped:supplement_r10_output.txt | 37193 | CANNOT RUN | paper agrees with the saved output |
| 649 | §6 para 1 | 378 | of which 37,193 carry text, at 378 of the locations | shipped:supplement_r10_output.txt | 378 | CANNOT RUN | paper agrees with the saved output |
| 650 | §6 para 1 | 1 | between 1 and 201 reviews per location (median 145) | shipped:supplement_r10_output.txt | 1 | CANNOT RUN | paper agrees with the saved output |
| 651 | §6 para 1 | 201 | between 1 and 201 reviews per location (median 145) | shipped:supplement_r10_output.txt | 201 | CANNOT RUN | paper agrees with the saved output |
| 652 | §6 para 1 | 145 | between 1 and 201 reviews per location (median 145) | shipped:supplement_r10_output.txt | 145 | CANNOT RUN | paper agrees with the saved output |
| 653 | §6 para 1 | 26 | at 26 locations, they name five different carriers | shipped:supplement_r10_output.txt | 26 | CANNOT RUN | paper agrees with the saved output |
| 654 | §6 para 1 | 5 | at 26 locations, they name five different carriers | shipped:supplement_r10_output.txt | 5 | CANNOT RUN | paper agrees with the saved output |
| 655 | §6 para 1 | 42,994 | a 42,994-node telecom taxonomy | shipped:supplement_r10_output.txt | 42994 | CANNOT RUN | paper agrees with the saved output |
| 656 | §6 para 1 | 1,898,584 | from 1,898,584 keywords | shipped:supplement_r10_output.txt | 1898584 | CANNOT RUN | paper agrees with the saved output |
| 657 | §6 para 1 | 37,193 | Of the 37,193 reviews, 20,663 (55.6%) linked | shipped:analyze_reviews_output.txt | 37193 | CANNOT RUN | paper agrees with the saved output |
| 658 | §6 para 1 | 20,663 | Of the 37,193 reviews, 20,663 (55.6%) linked | shipped:analyze_reviews_output.txt | 20663 | CANNOT RUN | paper agrees with the saved output |
| 659 | §6 para 1 | 55.6% | Of the 37,193 reviews, 20,663 (55.6%) linked | shipped:analyze_reviews_output.txt | 55.6 | CANNOT RUN | paper agrees with the saved output |
| 660 | §6 para 1 | 27,817 | linked to at least one of 27,817 linkable labels | rerun:m2_from_counts.py | 27817 | MATCH |  |
| 661 | §6 para 1 | 2.25 | at 2.25 labels per linked review | shipped:analyze_reviews_output.txt | 2.25 | CANNOT RUN | paper agrees with the saved output |
| 662 | §6 para 1 | 1,008 | and 1,008 labels were mentioned at least once | rerun:m2_from_counts.py | 1008 | MATCH |  |
| 663 | §6 para 2 | 17 | At the level of the taxonomy's 17 top-level branches | rerun:m2_from_counts.py | 17 | MATCH |  |
| 664 | §6 para 2 | +0.75 | is then +0.75 (bootstrap 95% interval over branches +0.44 to +0.90;... | rerun:m2_from_counts.py | +0.748 | MATCH |  |
| 665 | §6 para 2 | +0.44 | is then +0.75 (bootstrap 95% interval over branches +0.44 to +0.90;... | rerun:m2_from_counts.py | +0.443 | MATCH |  |
| 666 | §6 para 2 | +0.90 | is then +0.75 (bootstrap 95% interval over branches +0.44 to +0.90;... | rerun:m2_from_counts.py | +0.900 | MATCH |  |
| 667 | §6 para 2 | p < 0.001 | is then +0.75 (bootstrap 95% interval over branches +0.44 to +0.90;... | rerun:m2_from_counts.py | 0.00056 | MATCH |  |
| 668 | §6 para 2 | +0.47 | and +0.47 (+0.01 to +0.78; p = 0.06) | rerun:m2_from_counts.py | +0.468 | MATCH |  |
| 669 | §6 para 2 | +0.01 | and +0.47 (+0.01 to +0.78; p = 0.06) | rerun:m2_from_counts.py | +0.006 | MATCH |  |
| 670 | §6 para 2 | +0.78 | and +0.47 (+0.01 to +0.78; p = 0.06) | rerun:m2_from_counts.py | +0.783 | MATCH |  |
| 671 | §6 para 2 | 0.06 | and +0.47 (+0.01 to +0.78; p = 0.06) | rerun:m2_from_counts.py | 0.058 | MATCH |  |
| 672 | §6 para 2 | +0.78 | An earlier computation gave +0.78 | shipped:analyze_reviews_output.txt | +0.777 | CANNOT RUN | paper agrees with the saved output |
| 673 | §6 para 2 | 66.8% | carriers draw 66.8% of review mentions and 14.9% of search volume | rerun:m2_from_counts.py | 66.8 | MATCH |  |
| 674 | §6 para 2 | 14.9% | carriers draw 66.8% of review mentions and 14.9% of search volume | rerun:m2_from_counts.py | 14.9 | MATCH |  |
| 675 | §6 para 2 | 11.0% | devices 11.0% and 32.7% | rerun:m2_from_counts.py | 11.0 | MATCH |  |
| 676 | §6 para 2 | 32.7% | devices 11.0% and 32.7% | rerun:m2_from_counts.py | 32.7 | MATCH |  |
| 677 | §6 para 2 | 4.0% | broadband 4.0% and 18.1% | rerun:m2_from_counts.py | 4.0 | MATCH |  |
| 678 | §6 para 2 | 18.1% | broadband 4.0% and 18.1% | rerun:m2_from_counts.py | 18.1 | MATCH |  |
| 679 | §6 para 2 | 1,008 | Across the 1,008 labels that at least one review mentions | rerun:m2_from_counts.py | 1008 | MATCH |  |
| 680 | §6 para 2 | +0.19 | and monthly volume is +0.19 (bootstrap 95% interval over labels +0.... | rerun:m2_from_counts.py (full precision via checks/m2_precise.py) | 0.184869 | MISMATCH | prints +0.185; the full value 0.184869 is +0.18 to two decimals (double rounding) |
| 681 | §6 para 2 | +0.12 | and monthly volume is +0.19 (bootstrap 95% interval over labels +0.... | rerun:m2_from_counts.py (full precision via checks/m2_precise.py) | 0.124023 | MATCH |  |
| 682 | §6 para 2 | +0.25 | and monthly volume is +0.19 (bootstrap 95% interval over labels +0.... | rerun:m2_from_counts.py (full precision via checks/m2_precise.py) | 0.245035 | MATCH | prints +0.245; full value 0.245035 |
| 683 | §6 para 2 | +0.13 | Kendall's tau +0.13) | shipped:analyze_reviews_output.txt | +0.132 | CANNOT RUN | paper agrees with the saved output |
| 684 | §6 para 2 | 26,809 | counting the 26,809 linkable labels that no review mentions as zero | rerun:m2_from_counts.py | 26809 | MATCH |  |
| 685 | §6 para 2 | +0.27 | it is +0.27 (+0.26 to +0.29) | rerun:m2_from_counts.py | +0.273 | MATCH |  |
| 686 | §6 para 2 | +0.26 | it is +0.27 (+0.26 to +0.29) | rerun:m2_from_counts.py (full precision via checks/m2_precise.py) | 0.260054 | MATCH |  |
| 687 | §6 para 2 | +0.29 | it is +0.27 (+0.26 to +0.29) | rerun:m2_from_counts.py (full precision via checks/m2_precise.py) | 0.284982 | MISMATCH | prints +0.285; the full value 0.284982 is +0.28 to two decimals (double rounding) |
| 688 | §6 para 2 | +0.28 | It is +0.28 among the 213 labels with at least twenty mentions | shipped:analyze_reviews_output.txt | +0.282 | CANNOT RUN | paper agrees with the saved output |
| 689 | §6 para 2 | 213 | It is +0.28 among the 213 labels with at least twenty mentions | shipped:analyze_reviews_output.txt | 213 | CANNOT RUN | paper agrees with the saved output |
| 690 | §6 para 2 | +0.16 | and +0.16 among the 106 labels mentioned at least twenty times | shipped:analyze_reviews_output.txt | +0.160 | CANNOT RUN | paper agrees with the saved output |
| 691 | §6 para 2 | 106 | and +0.16 among the 106 labels mentioned at least twenty times | shipped:analyze_reviews_output.txt | 106 | CANNOT RUN | paper agrees with the saved output |
| 692 | §6 para 2 | below 0.001 | the p-values below 0.001 the scripts print | rerun:m2_from_counts.py | 0, 3.4e-09 | MATCH |  |
| 693 | §6 para 2 | section 12 | (`supplement_r10.py`, section 12) | shipped:supplement_r10_output.txt | == 12. Bootstraps over reviews | CANNOT RUN | paper agrees with the saved output |
| 694 | §6 para 2 | 367 | Of the 1,008 labels, 367 (36.4%) carry under 1,000 monthly searches | shipped:analyze_reviews_output.txt | 367 | CANNOT RUN | paper agrees with the saved output |
| 695 | §6 para 2 | 36.4% | Of the 1,008 labels, 367 (36.4%) carry under 1,000 monthly searches | shipped:analyze_reviews_output.txt | 36.4 | CANNOT RUN | paper agrees with the saved output |
| 696 | §6 para 2 | 106 | and 106 (10.5%) carry none | shipped:analyze_reviews_output.txt | 106 | CANNOT RUN | paper agrees with the saved output |
| 697 | §6 para 2 | 10.5% | and 106 (10.5%) carry none | shipped:analyze_reviews_output.txt | 10.5 | CANNOT RUN | paper agrees with the saved output |
| 698 | §6 para 2 | +0.16 | the two label-level correlations are +0.16 and +0.26 | rerun:m2_from_counts.py | +0.162 | MATCH |  |
| 699 | §6 para 2 | +0.26 | the two label-level correlations are +0.16 and +0.26 | rerun:m2_from_counts.py | +0.258 | MATCH |  |
| 700 | §6 para 'How good the links are' | 200 | judged 200 links drawn uniformly from the 46,517 | rerun:r2_link_check.py | 200 | MATCH |  |
| 701 | §6 para 'How good the links are' | 46,517 | judged 200 links drawn uniformly from the 46,517 | rerun:r2_link_check.py | 46,517 | MATCH | r2_link_check.py reads it from r2_link_sample_output.txt (shipped; r2_link_sample.py needs the withheld export) |
| 702 | §6 para 'How good the links are' | 65% | 65% to 67% are correct | rerun:r2_link_check.py | 65 | MATCH |  |
| 703 | §6 para 'How good the links are' | 67% | 65% to 67% are correct | rerun:r2_link_check.py | 66.8 | MATCH |  |
| 704 | §6 para 'How good the links are' | 58% | (Wilson 95% intervals about 58% to 73%) | rerun:r2_link_check.py | 58.2 | MATCH |  |
| 705 | §6 para 'How good the links are' | 73% | (Wilson 95% intervals about 58% to 73%) | rerun:r2_link_check.py | 73 | MATCH |  |
| 706 | §6 para 'How good the links are' | 95.5% | the two agree on 95.5% of the items (Cohen's kappa 0.90) | rerun:r2_link_check.py | 95.5 | MATCH |  |
| 707 | §6 para 'How good the links are' | 0.90 | the two agree on 95.5% of the items (Cohen's kappa 0.90) | rerun:r2_link_check.py | 0.90 | MATCH |  |
| 708 | §6 para 'How good the links are' | about half | which are right about half the time | rerun:r2_link_check.py | 50.0% and 48.0% | MATCH |  |
| 709 | §6 para 'How good the links are' | 95% | while multi-word labels are 95% to 96% right | rerun:r2_link_check.py | 94.5 | MATCH |  |
| 710 | §6 para 'How good the links are' | 96% | while multi-word labels are 95% to 96% right | rerun:r2_link_check.py | 95.8 | MATCH |  |
| 711 | §6 para 'How good the links are' | +0.91 | the branch-level correlation is +0.91 (bootstrap 95% interval +0.74... | rerun:m2_from_counts.py | +0.914 | MATCH |  |
| 712 | §6 para 'How good the links are' | +0.74 | the branch-level correlation is +0.91 (bootstrap 95% interval +0.74... | rerun:m2_from_counts.py (full precision via checks/m2_precise.py) | 0.735 | MATCH | prints +0.735; the full value is 0.735 to machine precision, so +0.74 is the conventional rounding (Python's float formatting gives 0.73) |
| 713 | §6 para 'How good the links are' | +0.98 | the branch-level correlation is +0.91 (bootstrap 95% interval +0.74... | rerun:m2_from_counts.py | +0.983 | MATCH |  |
| 714 | §6 para 'How good the links are' | +0.65 | and +0.65 with modal attribution | rerun:m2_from_counts.py | +0.649 | MATCH |  |
| 715 | §6 para 'How good the links are' | +0.24 | the label-level correlation over mentioned labels is +0.24 (+0.16 t... | rerun:m2_from_counts.py | +0.243 | MATCH |  |
| 716 | §6 para 'How good the links are' | +0.16 | the label-level correlation over mentioned labels is +0.24 (+0.16 t... | rerun:m2_from_counts.py | +0.158 | MATCH |  |
| 717 | §6 para 'How good the links are' | +0.33 | the label-level correlation over mentioned labels is +0.24 (+0.16 t... | rerun:m2_from_counts.py | +0.326 | MATCH |  |
| 718 | §6 para 'How good the links are' | 56% | carriers still draw 56% of review mentions against 15% of search vo... | rerun:m2_from_counts.py | 56.1 | MATCH |  |
| 719 | §6 para 'How good the links are' | 15% | carriers still draw 56% of review mentions against 15% of search vo... | rerun:m2_from_counts.py | 14.9 | MATCH |  |
| 720 | §6 para 'waiting' | 6,620 | Of 6,620 one- and two-star reviews, 924 (14.0% | shipped:analyze_reviews_output.txt | 6620 | CANNOT RUN | paper agrees with the saved output |
| 721 | §6 para 'waiting' | 924 | Of 6,620 one- and two-star reviews, 924 (14.0% | shipped:analyze_reviews_output.txt | 924 | CANNOT RUN | paper agrees with the saved output |
| 722 | §6 para 'waiting' | 14.0% | Of 6,620 one- and two-star reviews, 924 (14.0% | arith:924 / 6,620 | 13.9577 | MATCH |  |
| 723 | §6 para 'waiting' | 13.1% | Wilson 95% interval 13.1% to 14.8% | arith:Wilson on 924 / 6,620 | 13.1438 | MATCH |  |
| 724 | §6 para 'waiting' | 14.8% | Wilson 95% interval 13.1% to 14.8% | arith:Wilson on 924 / 6,620 | 14.8134 | MATCH |  |
| 725 | §6 para 'waiting' | 1.9% | against 1.9% (1.8% to 2.1%) of five-star reviews | shipped:analyze_reviews_output.txt | 1.9 | CANNOT RUN | paper agrees with the saved output |
| 726 | §6 para 'waiting' | 1.8% | against 1.9% (1.8% to 2.1%) of five-star reviews | shipped:supplement_r10_output.txt | 1.8 | CANNOT RUN | paper agrees with the saved output; Wilson on 564 / 29,225 from the same output agrees |
| 727 | §6 para 'waiting' | 2.1% | against 1.9% (1.8% to 2.1%) of five-star reviews | shipped:supplement_r10_output.txt | 2.1 | CANNOT RUN | paper agrees with the saved output |
| 728 | §6 para 'waiting' | 100 | The same annotators judged 100 of the 924 matches | rerun:r2_link_check.py | 100 | MATCH |  |
| 729 | §6 para 'waiting' | 924 | The same annotators judged 100 of the 924 matches | rerun:r2_link_check.py | 924 | MATCH | read from r2_link_sample_output.txt (shipped) |
| 730 | §6 para 'waiting' | 83% | 83% to 85% are complaints about waiting (Cohen's kappa 0.93) | rerun:r2_link_check.py | 83 | MATCH |  |
| 731 | §6 para 'waiting' | 85% | 83% to 85% are complaints about waiting (Cohen's kappa 0.93) | rerun:r2_link_check.py | 84.8 | MATCH |  |
| 732 | §6 para 'waiting' | 0.93 | 83% to 85% are complaints about waiting (Cohen's kappa 0.93) | rerun:r2_link_check.py | 0.93 | MATCH |  |
| 733 | §6 para 'waiting' | about 90% | about nine in ten of those concern waiting in the store | rerun:r2_link_check.py | 90.5% and 89.2% | MATCH |  |
| 734 | §6 para 'waiting' | 12% | so roughly 12% of one- and two-star reviews complain about a wait | rerun:r2_link_check.py | 11.9% and 11.6% | MATCH |  |
| 735 | §6 para 'waiting' | 1.9 million | The whole taxonomy, built from 1.9 million keywords | shipped:supplement_r10_output.txt | 1898584 | CANNOT RUN | paper agrees with the saved output |
| 736 | §6 para 'waiting' | 11 | holds 11 labels containing "wait" | shipped:supplement_r10_output.txt | 11 | CANNOT RUN | paper agrees with the saved output |
| 737 | §6 para 'waiting' | 622 | with 622 searches a month between them | shipped:supplement_r10_output.txt | 622 | CANNOT RUN | paper agrees with the saved output |
| 738 | §6 para 'waiting' | 1 | the one that reviews mention carries 12 | shipped:analyze_reviews_output.txt | 1 | CANNOT RUN | paper agrees with the saved output |
| 739 | §6 para 'waiting' | 12 | the one that reviews mention carries 12 | shipped:analyze_reviews_output.txt | 12 | CANNOT RUN | paper agrees with the saved output |
| 740 | §6 para 'waiting' | 8 | Eight labels name a remedy, appointments, queues or callbacks | shipped:supplement_r10_output.txt | 8 | CANNOT RUN | paper agrees with the saved output |
| 741 | §6 para 'waiting' | 13,170 | with 13,170 searches a month between them | shipped:supplement_r10_output.txt | 13170 | CANNOT RUN | paper agrees with the saved output |
| 742 | §6 para 'waiting' | most | most of it for appointment reminders | shipped:supplement_r10_output.txt | 9387 of 13170 | CANNOT RUN | paper agrees with the saved output |
| 743 | §6 para 'waiting' | 0 | the label for scheduling a store appointment carries none | shipped:supplement_r10_output.txt | 0 | CANNOT RUN | paper agrees with the saved output |
| 744 | §6 para 'waiting' | 0 | and no label concerns check-in | shipped:supplement_r10_output.txt | 0 | CANNOT RUN | paper agrees with the saved output |
| 745 | §6 Figure 6 caption | 37,193 | 37,193 Google reviews of 378 retail locations | shipped:analyze_reviews_output.txt | 37193 | CANNOT RUN | paper agrees with the saved output |
| 746 | §6 Figure 6 caption | 378 | 37,193 Google reviews of 378 retail locations | shipped:analyze_reviews_output.txt | 378 | CANNOT RUN | paper agrees with the saved output |
| 747 | §6 Figure 6 caption | 42,994 | linked to a 42,994-node taxonomy carrying | shipped:supplement_r10_output.txt | 42994 | CANNOT RUN | paper agrees with the saved output |
| 748 | §6 Figure 6 caption | 1,008 | Each marker is one of the 1,008 taxonomy labels | rerun:m2_from_counts.py | 1008 | MATCH |  |
| 749 | §6 Figure 6 caption | 17 | for the nine largest of the 17 top-level branches | rerun:m2_from_counts.py | 17 | MATCH |  |
| 750 | §6 last para | about two in three | exact-match links of which about two in three are correct | rerun:r2_link_check.py | 65.0% to 66.8% | MATCH |  |
| 751 | §7.1 | 22:21 to 22:26 | made on 12 October between 22:21 and 22:26 | shipped:pilot_section_output.txt | 22:21 to 22:26 | CANNOT RUN | paper agrees with the saved output |
| 752 | §7.1 | 1 on all four | youtube.com was the most-cited non-brand domain on all four Google ... | shipped:pilot_section_output.txt | ranks 1, 1, 1, 1 | CANNOT RUN | paper agrees with the saved output |
| 753 | §7.1 | 28 | ranked 28th on ChatGPT, 4th on Perplexity, 5th on Gemini and 9th on... | shipped:pilot_section_output.txt | 28 | CANNOT RUN | paper agrees with the saved output |
| 754 | §7.1 | 4 | ranked 28th on ChatGPT, 4th on Perplexity, 5th on Gemini and 9th on... | shipped:pilot_section_output.txt | 4 | CANNOT RUN | paper agrees with the saved output |
| 755 | §7.1 | 5 | ranked 28th on ChatGPT, 4th on Perplexity, 5th on Gemini and 9th on... | shipped:pilot_section_output.txt | 5 | CANNOT RUN | paper agrees with the saved output |
| 756 | §7.1 | 9 | ranked 28th on ChatGPT, 4th on Perplexity, 5th on Gemini and 9th on... | shipped:pilot_section_output.txt | 9 | CANNOT RUN | paper agrees with the saved output |
| 757 | §7.1 | top three except Copilot | reddit.com was in the top three on every surface except Copilot (24... | shipped:pilot_section_output.txt | 3, 2, 2, 2, 3, 3, 1, 240 | CANNOT RUN | paper agrees with the saved output |
| 758 | §7.1 | 240 | reddit.com was in the top three on every surface except Copilot (24... | shipped:pilot_section_output.txt | 240 | CANNOT RUN | paper agrees with the saved output |
| 759 | §7.2 | 8 | set aside eight exports that repeated a view or mixed two platforms | data:design file (amendment A2) | Eight exports | MATCH |  |
| 760 | §7.2 | 14 of 88 | the prompt-level sample was stopped after 14 of 88 exports | data:design file (amendment A3) | after 14 of 88 exports | MATCH |  |
| 761 | §7.2 | 109 | (holdings as of 9 October 2026): 109 companies | data:cross_sector_companies.csv | 109 | MATCH |  |
| 762 | §7.2 | 9 companies in Communication Services | because Communication Services counts one issuer, Alphabet, through... | rerun:make_brand_radar_urls.py | 9 | MATCH |  |
| 763 | §7.2 | 760 | which reduce to 760 to 975 registrable domains | rerun:section7_from_aggregates.py | 760 | MATCH |  |
| 764 | §7.2 | 975 | which reduce to 760 to 975 registrable domains | rerun:section7_from_aggregates.py | 975 | MATCH |  |
| 765 | §7.2 | 88 | the 88 exports are analyzed | rerun:section7_from_aggregates.py | 88 | MATCH |  |
| 766 | §7.2 | 20,389,967 | Summed over sectors it holds 20,389,967 answer records | rerun:section7_from_aggregates.py | 20,389,967 | MATCH |  |
| 767 | §7.2 | 18,763 | from 18,763 (Utilities) to 7,766,466 (Consumer Discretionary) | rerun:section7_from_aggregates.py | 18,763 | MATCH |  |
| 768 | §7.2 | 7,766,466 | from 18,763 (Utilities) to 7,766,466 (Consumer Discretionary) | rerun:section7_from_aggregates.py | 7,766,466 | MATCH |  |
| 769 | §7.2 Figure 7 caption | 9 | (nine companies in Communication Services) | rerun:make_brand_radar_urls.py | 9 | MATCH |  |
| 770 | §7.3 Descriptive | 11 of 11 | In every one of the eleven sectors, the lowest of the four Google v... | rerun:section7_from_aggregates.py | 11/11 | MATCH |  |
| 771 | §7.3 Descriptive | 21.3% | the median share was 21.3% on the Google views (range 8.1% to 35.8% | rerun:section7_from_aggregates.py | 21.3 | MATCH |  |
| 772 | §7.3 Descriptive | 8.1% | the median share was 21.3% on the Google views (range 8.1% to 35.8% | rerun:section7_from_aggregates.py | 8.1 | MATCH |  |
| 773 | §7.3 Descriptive | 35.8% | the median share was 21.3% on the Google views (range 8.1% to 35.8% | rerun:section7_from_aggregates.py | 35.8 | MATCH |  |
| 774 | §7.3 Descriptive | 17.2% | 95% bootstrap interval over sectors 17.2% to 26.7%) | rerun:section7_from_aggregates.py | 17.2 | MATCH |  |
| 775 | §7.3 Descriptive | 26.7% | 95% bootstrap interval over sectors 17.2% to 26.7%) | rerun:section7_from_aggregates.py | 26.7 | MATCH |  |
| 776 | §7.3 Descriptive | 2.1% | against 2.1% on the other four (range 0.3% to 16.7%; interval 1.7% ... | rerun:section7_from_aggregates.py | 2.1 | MATCH |  |
| 777 | §7.3 Descriptive | 0.3% | against 2.1% on the other four (range 0.3% to 16.7%; interval 1.7% ... | rerun:section7_from_aggregates.py | 0.3 | MATCH |  |
| 778 | §7.3 Descriptive | 16.7% | against 2.1% on the other four (range 0.3% to 16.7%; interval 1.7% ... | rerun:section7_from_aggregates.py | 16.7 | MATCH |  |
| 779 | §7.3 Descriptive | 1.7% | against 2.1% on the other four (range 0.3% to 16.7%; interval 1.7% ... | rerun:section7_from_aggregates.py | 1.7 | MATCH |  |
| 780 | §7.3 Descriptive | 2.7% | against 2.1% on the other four (range 0.3% to 16.7%; interval 1.7% ... | rerun:section7_from_aggregates.py | 2.7 | MATCH |  |
| 781 | §7.3 Descriptive | 0.6% | by surface 0.6% on Copilot, 0.9% on ChatGPT, 4.6% on Perplexity and... | rerun:section7_from_aggregates.py | 0.6 | MATCH |  |
| 782 | §7.3 Descriptive | 0.9% | by surface 0.6% on Copilot, 0.9% on ChatGPT, 4.6% on Perplexity and... | rerun:section7_from_aggregates.py | 0.9 | MATCH |  |
| 783 | §7.3 Descriptive | 4.6% | by surface 0.6% on Copilot, 0.9% on ChatGPT, 4.6% on Perplexity and... | rerun:section7_from_aggregates.py | 4.6 | MATCH |  |
| 784 | §7.3 Descriptive | 9.2% | by surface 0.6% on Copilot, 0.9% on ChatGPT, 4.6% on Perplexity and... | rerun:section7_from_aggregates.py | 9.2 | MATCH |  |
| 785 | §7.3 Descriptive | 24.6% | the Google median is 24.6% | rerun:section7_from_aggregates.py | 24.6 | MATCH |  |
| 786 | §7.3 Descriptive | 38 | in 38 of the 44 sector-by-Google-view cells and in none of the 44 o... | rerun:section7_from_aggregates.py | 38 | MATCH |  |
| 787 | §7.3 Descriptive | 0 | in 38 of the 44 sector-by-Google-view cells and in none of the 44 o... | rerun:section7_from_aggregates.py | 0 | MATCH |  |
| 788 | §7.3 Descriptive | 1 | its median rank was 1 on AI Overviews, 2 on AI Mode, 7 on Perplexit... | rerun:section7_from_aggregates.py | 1 | MATCH | surface aio_searchqueries |
| 789 | §7.3 Descriptive | 1 | its median rank was 1 on AI Overviews, 2 on AI Mode, 7 on Perplexit... | rerun:section7_from_aggregates.py | 1 | MATCH | surface aio_prompts |
| 790 | §7.3 Descriptive | 2 | its median rank was 1 on AI Overviews, 2 on AI Mode, 7 on Perplexit... | rerun:section7_from_aggregates.py | 2 | MATCH | surface aimode_searchqueries |
| 791 | §7.3 Descriptive | 2 | its median rank was 1 on AI Overviews, 2 on AI Mode, 7 on Perplexit... | rerun:section7_from_aggregates.py | 2 | MATCH | surface aimode_prompts |
| 792 | §7.3 Descriptive | 7 | its median rank was 1 on AI Overviews, 2 on AI Mode, 7 on Perplexit... | rerun:section7_from_aggregates.py | 7 | MATCH | surface perplexity |
| 793 | §7.3 Descriptive | 7 | its median rank was 1 on AI Overviews, 2 on AI Mode, 7 on Perplexit... | rerun:section7_from_aggregates.py | 7 | MATCH | surface gemini |
| 794 | §7.3 Descriptive | 151 | its median rank was 1 on AI Overviews, 2 on AI Mode, 7 on Perplexit... | rerun:section7_from_aggregates.py | 151 | MATCH | surface chatgpt |
| 795 | §7.3 Descriptive | 161 | its median rank was 1 on AI Overviews, 2 on AI Mode, 7 on Perplexit... | rerun:section7_from_aggregates.py | 161 | MATCH | surface copilot |
| 796 | §7.3 Descriptive | 12.7% | without it, the medians are 12.7% and 1.6% | rerun:section7_from_aggregates.py | 12.7 | MATCH |  |
| 797 | §7.3 Descriptive | 1.6% | without it, the medians are 12.7% and 1.6% | rerun:section7_from_aggregates.py | 1.6 | MATCH |  |
| 798 | §7.3 Descriptive | 7 | the lowest Google view exceeds the highest other surface in 7 of 11... | rerun:section7_from_aggregates.py | 7 | MATCH |  |
| 799 | §7.3 Source types | 2.7% | the median reference share was 2.7% on the other four surfaces agai... | rerun:section7_from_aggregates.py | 2.7 | MATCH |  |
| 800 | §7.3 Source types | 3.2% | the median reference share was 2.7% on the other four surfaces agai... | rerun:section7_from_aggregates.py | 3.2 | MATCH |  |
| 801 | §7.3 Source types | 1.1% | and forum sites 1.1% against 5.7% | rerun:section7_from_aggregates.py | 1.1 | MATCH |  |
| 802 | §7.3 Source types | 5.7% | and forum sites 1.1% against 5.7% | rerun:section7_from_aggregates.py | 5.7 | MATCH |  |
| 803 | §7.3 Source types | 14.1% | the sector's own company domains (median 14.1%) | rerun:section7_from_aggregates.py | 14.1 | MATCH |  |
| 804 | §7.3 Source types | 61% | held a median 61% of incidences on the Google views and 72% on the ... | rerun:section7_from_aggregates.py | 61.1 | MATCH |  |
| 805 | §7.3 Source types | 72% | held a median 61% of incidences on the Google views and 72% on the ... | rerun:section7_from_aggregates.py | 71.7 | MATCH |  |
| 806 | §7.3 Source types | 90% | held a median 61% of incidences on the Google views and 72% on the ... | rerun:section7_from_aggregates.py | 89.9 | MATCH |  |
| 807 | §7.3 Source types | 17 | the share going to seventeen named video and community platforms | data:cross_sector.py TYPES (released script) | 17 | MATCH | 18 domains; x.com and twitter.com are one platform (X) |
| 808 | §7.3 Source types | 77% | Across the 88 cells, answer surface explains 77% of the variance | rerun:section7_from_aggregates.py | 77 | MATCH |  |
| 809 | §7.3 Source types | 70% | (bootstrap 95% interval over sectors 70% to 91%) | rerun:section7_from_aggregates.py | 70 | MATCH |  |
| 810 | §7.3 Source types | 91% | (bootstrap 95% interval over sectors 70% to 91%) | rerun:section7_from_aggregates.py | 91 | MATCH |  |
| 811 | §7.3 Source types | 14% | and sector 14% (5% to 20%) | rerun:section7_from_aggregates.py | 14 | MATCH |  |
| 812 | §7.3 Source types | 5% | and sector 14% (5% to 20%) | rerun:section7_from_aggregates.py | 5 | MATCH |  |
| 813 | §7.3 Source types | 20% | and sector 14% (5% to 20%) | rerun:section7_from_aggregates.py | 20 | MATCH |  |
| 814 | §7.3 Source types | 12% | for news (12% against 73%) | rerun:section7_from_aggregates.py | 12 | MATCH |  |
| 815 | §7.3 Source types | 73% | for news (12% against 73%) | rerun:section7_from_aggregates.py | 73 | MATCH |  |
| 816 | §7.3 Source types | 26% | government (26% against 49%) | rerun:section7_from_aggregates.py | 26 | MATCH |  |
| 817 | §7.3 Source types | 49% | government (26% against 49%) | rerun:section7_from_aggregates.py | 49 | MATCH |  |
| 818 | §7.3 Source types | 40% | the companies' own domains (40% against 45%) | rerun:section7_from_aggregates.py | 40 | MATCH |  |
| 819 | §7.3 Source types | 45% | the companies' own domains (40% against 45%) | rerun:section7_from_aggregates.py | 45 | MATCH |  |
| 820 | §7.3 By sector | Information Technology: google | a search engine (Information Technology) | rerun:make_tables_sector_surface.py | Information Technology: google | MATCH | ChatGPT column of Table C3 as printed |
| 821 | §7.3 By sector | Health Care: fda.gov | the Food and Drug Administration (Health Care) | rerun:make_tables_sector_surface.py | Health Care: fda.gov | MATCH | ChatGPT column of Table C3 as printed |
| 822 | §7.3 By sector | Financials: nerdwallet | a personal-finance publisher (Financials) | rerun:make_tables_sector_surface.py | Financials: nerdwallet | MATCH | ChatGPT column of Table C3 as printed |
| 823 | §7.3 By sector | Consumer Discretionary: justwatch | a streaming guide (Consumer Discretionary) | rerun:make_tables_sector_surface.py | Consumer Discretionary: justwatch | MATCH | ChatGPT column of Table C3 as printed |
| 824 | §7.3 By sector | Communication Services: go† | a Disney property (Communication Services) | rerun:make_tables_sector_surface.py | Communication Services: go† | MATCH | ChatGPT column of Table C3 as printed |
| 825 | §7.3 By sector | Industrials: nvidia | a graphics-card maker (Industrials | rerun:make_tables_sector_surface.py | Industrials: nvidia | MATCH | ChatGPT column of Table C3 as printed |
| 826 | §7.3 By sector | Consumer Staples: reddit | reddit.com (Consumer Staples) | rerun:make_tables_sector_surface.py | Consumer Staples: reddit | MATCH | ChatGPT column of Table C3 as printed |
| 827 | §7.3 By sector | Energy: sec.gov | the Securities and Exchange Commission (Energy, Utilities and Real ... | rerun:make_tables_sector_surface.py | Energy: sec.gov | MATCH | ChatGPT column of Table C3 as printed |
| 828 | §7.3 By sector | Utilities: sec.gov | the Securities and Exchange Commission (Energy, Utilities and Real ... | rerun:make_tables_sector_surface.py | Utilities: sec.gov | MATCH | ChatGPT column of Table C3 as printed |
| 829 | §7.3 By sector | Real Estate: sec.gov | the Securities and Exchange Commission (Energy, Utilities and Real ... | rerun:make_tables_sector_surface.py | Real Estate: sec.gov | MATCH | ChatGPT column of Table C3 as printed |
| 830 | §7.3 By sector | Materials: benjaminmoore | and a paint maker (Materials) | rerun:make_tables_sector_surface.py | Materials: benjaminmoore | MATCH | ChatGPT column of Table C3 as printed |
| 831 | §7.3 By sector | 0.36 | (mean pairwise Jaccard 0.36 to 0.40 across the 55 sector pairs) | rerun:section7_from_aggregates.py | 0.36 | MATCH |  |
| 832 | §7.3 By sector | 0.40 | (mean pairwise Jaccard 0.36 to 0.40 across the 55 sector pairs) | rerun:section7_from_aggregates.py | 0.4 | MATCH |  |
| 833 | §7.3 By sector | 55 | (mean pairwise Jaccard 0.36 to 0.40 across the 55 sector pairs) | rerun:section7_from_aggregates.py | 55 sector pairs | MATCH |  |
| 834 | §7.3 By sector | 0.08 | than on the other four (0.08 to 0.23) | rerun:section7_from_aggregates.py | 0.08 | MATCH |  |
| 835 | §7.3 By sector | 0.23 | than on the other four (0.08 to 0.23) | rerun:section7_from_aggregates.py | 0.23 | MATCH |  |
| 836 | §7.3 By sector | 22.5% | its direction reversed on search queries (22.5% against 24.2%) | shipped:cross_sector_sensitivity2_output.txt | 22.5 | CANNOT RUN | paper agrees with the saved output |
| 837 | §7.3 By sector | 24.2% | its direction reversed on search queries (22.5% against 24.2%) | shipped:cross_sector_sensitivity2_output.txt | 24.2 | CANNOT RUN | paper agrees with the saved output |
| 838 | §7.3 By sector | 0.23 | in no check did it approach significance (p = 0.23 to 0.63) | shipped:cross_sector_sensitivity2_output.txt | 0.23 | CANNOT RUN | paper agrees with the saved output |
| 839 | §7.3 By sector | 0.63 | in no check did it approach significance (p = 0.23 to 0.63) | shipped:cross_sector_sensitivity2_output.txt | 0.63 | CANNOT RUN | paper agrees with the saved output |
| 840 | §7.3 By sector | Sherwin-Williams 94% | Sherwin-Williams holds 94% of Materials | shipped:cross_sector_sensitivity_output.txt | Sherwin-Williams 93.9% | CANNOT RUN | paper agrees with the saved output |
| 841 | §7.3 By sector | Amazon 75% | Amazon 75% of Consumer Discretionary | shipped:cross_sector_sensitivity_output.txt | Amazon 75.4% | CANNOT RUN | paper agrees with the saved output |
| 842 | §7.3 By sector | Walmart 65% | Walmart 65% of Consumer Staples | shipped:cross_sector_sensitivity_output.txt | Walmart 65.4% | CANNOT RUN | paper agrees with the saved output |
| 843 | §7.3 By sector | Apple 62% | Apple 62% of Information Technology | shipped:cross_sector_sensitivity_output.txt | Apple 62.2% | CANNOT RUN | paper agrees with the saved output |
| 844 | §7.3 By sector | Uber 55% | Uber 55% of Industrials | shipped:cross_sector_sensitivity_output.txt | Uber 54.8% | CANNOT RUN | paper agrees with the saved output |
| 845 | §7.3 By sector | go.com | such as go.com, chase.com and mobil.com among ChatGPT's top three | rerun:make_tables_sector_surface.py | go†, justwatch, wikipedia.org | MATCH |  |
| 846 | §7.3 By sector | chase.com | such as go.com, chase.com and mobil.com among ChatGPT's top three | rerun:make_tables_sector_surface.py | nerdwallet, chase†, capitalone | MATCH |  |
| 847 | §7.3 By sector | mobil.com | such as go.com, chase.com and mobil.com among ChatGPT's top three | rerun:make_tables_sector_surface.py | sec.gov, chevronlubricants†, mobil† | MATCH |  |
| 848 | §7.4 | 9 | it held on AI Overviews (9 of 11 sectors on search queries, 8 of 11... | rerun:section7_from_aggregates.py | 9 | MATCH |  |
| 849 | §7.4 | 8 | it held on AI Overviews (9 of 11 sectors on search queries, 8 of 11... | rerun:section7_from_aggregates.py | 8 | MATCH |  |
| 850 | §7.4 | 2 | and not on AI Mode (2 of 11 on each) | rerun:section7_from_aggregates.py | 2 | MATCH |  |
| 851 | §7.4 | 2 | and not on AI Mode (2 of 11 on each) | rerun:section7_from_aggregates.py | 2 | MATCH |  |
| 852 | §7.4 | fails | P1, that youtube.com is the most-cited non-company domain on AI Ove... | rerun:section7_from_aggregates.py | fails | MATCH |  |
| 853 | §7.4 | 93% | (median 93% and 98% of its incidences on the two views) | shipped:cross_sector_sensitivity2_output.txt | 93 | CANNOT RUN | paper agrees with the saved output |
| 854 | §7.4 | 98% | (median 93% and 98% of its incidences on the two views) | shipped:cross_sector_sensitivity2_output.txt | 98 | CANNOT RUN | paper agrees with the saved output |
| 855 | §7.4 | 9 | it would hold (9 of 11) if google.com | shipped:cross_sector_sensitivity_output.txt | 9 | CANNOT RUN | paper agrees with the saved output |
| 856 | §7.4 | fails under every reduction | It fails under every domain reduction tried | shipped:cross_sector_sensitivity_output.txt | 4, 4, 5 | CANNOT RUN | paper agrees with the saved output |
| 857 | §7.4 | 11 | held on all three (11, 6 and 11 of 11) | rerun:section7_from_aggregates.py | 11 | MATCH |  |
| 858 | §7.4 | 6 | held on all three (11, 6 and 11 of 11) | rerun:section7_from_aggregates.py | 6 | MATCH |  |
| 859 | §7.4 | 11 | held on all three (11, 6 and 11 of 11) | rerun:section7_from_aggregates.py | 11 | MATCH |  |
| 860 | §7.4 | 3 | failed: it held in 3 of 11 | rerun:section7_from_aggregates.py | 3 | MATCH |  |
| 861 | §7.4 | 8 of 8 | ChatGPT was a failing surface in all eight sectors where it did not... | rerun:section7_from_aggregates.py | 8 of the 8 | MATCH |  |
| 862 | §7.4 | Financials in neither group | (Financials is in neither group) | data:cross_sector.py CONSUMER/NONCONSUMER | xlf absent | MATCH |  |
| 863 | §7.4 | 26.9% | held in direction (26.9% against 24.2% on search queries | rerun:section7_from_aggregates.py | 26.9 | MATCH |  |
| 864 | §7.4 | 24.2% | held in direction (26.9% against 24.2% on search queries | rerun:section7_from_aggregates.py | 24.2 | MATCH |  |
| 865 | §7.4 | 29.6% | 29.6% against 24.4% on prompts) | rerun:section7_from_aggregates.py | 29.6 | MATCH |  |
| 866 | §7.4 | 24.4% | 29.6% against 24.4% on prompts) | rerun:section7_from_aggregates.py | 24.4 | MATCH |  |
| 867 | §7.4 | 0.27 | (exact one-sided permutation p = 0.27 and 0.21) | rerun:section7_from_aggregates.py | 0.274 | MATCH |  |
| 868 | §7.4 | 0.21 | (exact one-sided permutation p = 0.27 and 0.21) | rerun:section7_from_aggregates.py | 0.210 | MATCH |  |
| 869 | §7.4 | 1, 1, 2 | Of the four, one held, one held in direction only and two failed | rerun:section7_from_aggregates.py | 1 held, 1 held in direction only, 2 failed | MATCH |  |
| 870 | §7.5 | 21.5% | (Google median 21.5%, other four 3.3%; lowest Google view above the... | shipped:cross_sector_sensitivity_output.txt | 21.5 | CANNOT RUN | paper agrees with the saved output |
| 871 | §7.5 | 3.3% | (Google median 21.5%, other four 3.3%; lowest Google view above the... | shipped:cross_sector_sensitivity_output.txt | 3.3 | CANNOT RUN | paper agrees with the saved output |
| 872 | §7.5 | 11 | (Google median 21.5%, other four 3.3%; lowest Google view above the... | shipped:cross_sector_sensitivity_output.txt | 11 | CANNOT RUN | paper agrees with the saved output |
| 873 | §7.5 | 22.0% | (22.0%, 2.4%, 11 of 11) | shipped:cross_sector_sensitivity_output.txt | 22.0 | CANNOT RUN | paper agrees with the saved output |
| 874 | §7.5 | 2.4% | (22.0%, 2.4%, 11 of 11) | shipped:cross_sector_sensitivity_output.txt | 2.4 | CANNOT RUN | paper agrees with the saved output |
| 875 | §7.5 | 11 | (22.0%, 2.4%, 11 of 11) | shipped:cross_sector_sensitivity_output.txt | 11 | CANNOT RUN | paper agrees with the saved output |
| 876 | §7.5 | 19.8% | (19.8%, 2.1%, 10 of 11) | shipped:cross_sector_sensitivity_output.txt | 19.8 | CANNOT RUN | paper agrees with the saved output |
| 877 | §7.5 | 2.1% | (19.8%, 2.1%, 10 of 11) | shipped:cross_sector_sensitivity_output.txt | 2.1 | CANNOT RUN | paper agrees with the saved output |
| 878 | §7.5 | 10 | (19.8%, 2.1%, 10 of 11) | shipped:cross_sector_sensitivity_output.txt | 10 | CANNOT RUN | paper agrees with the saved output |
| 879 | §7.5 | 64 | and with 64 properties of the sector's companies | data:cross_sector_company_properties.csv | 64 | MATCH |  |
| 880 | §7.5 | 20.2% | the Google views fall from 20.2% to 32.4% to 5.9% to 12.7% | shipped:cross_sector_sensitivity_output.txt | 20.2 | CANNOT RUN | paper agrees with the saved output |
| 881 | §7.5 | 32.4% | the Google views fall from 20.2% to 32.4% to 5.9% to 12.7% | shipped:cross_sector_sensitivity_output.txt | 32.4 | CANNOT RUN | paper agrees with the saved output |
| 882 | §7.5 | 5.9% | the Google views fall from 20.2% to 32.4% to 5.9% to 12.7% | shipped:cross_sector_sensitivity_output.txt | 5.9 | CANNOT RUN | paper agrees with the saved output |
| 883 | §7.5 | 12.7% | the Google views fall from 20.2% to 32.4% to 5.9% to 12.7% | shipped:cross_sector_sensitivity_output.txt | 12.7 | CANNOT RUN | paper agrees with the saved output |
| 884 | §7.5 | 9.2% | and Gemini's 9.2% exceeds AI Mode on search queries | shipped:cross_sector_sensitivity_output.txt | 9.2 | CANNOT RUN | paper agrees with the saved output |
| 885 | §7.5 | exceeds | and Gemini's 9.2% exceeds AI Mode on search queries | shipped:cross_sector_sensitivity_output.txt | Gemini 9.2% > AI Mode search queries 5.9% | CANNOT RUN | paper agrees with the saved output |
| 886 | §7.5 | 30.6% | gives Google medians of 30.6%, 26.3% and 23.3% against 3.0%, 2.6% a... | shipped:cross_sector_sensitivity_output.txt | 30.6 | CANNOT RUN | paper agrees with the saved output |
| 887 | §7.5 | 3.0% | gives Google medians of 30.6%, 26.3% and 23.3% against 3.0%, 2.6% a... | shipped:cross_sector_sensitivity_output.txt | 3.0 | CANNOT RUN | paper agrees with the saved output |
| 888 | §7.5 | 26.3% | gives Google medians of 30.6%, 26.3% and 23.3% against 3.0%, 2.6% a... | shipped:cross_sector_sensitivity_output.txt | 26.3 | CANNOT RUN | paper agrees with the saved output |
| 889 | §7.5 | 2.6% | gives Google medians of 30.6%, 26.3% and 23.3% against 3.0%, 2.6% a... | shipped:cross_sector_sensitivity_output.txt | 2.6 | CANNOT RUN | paper agrees with the saved output |
| 890 | §7.5 | 23.3% | gives Google medians of 30.6%, 26.3% and 23.3% against 3.0%, 2.6% a... | shipped:cross_sector_sensitivity_output.txt | 23.3 | CANNOT RUN | paper agrees with the saved output |
| 891 | §7.5 | 2.3% | gives Google medians of 30.6%, 26.3% and 23.3% against 3.0%, 2.6% a... | shipped:cross_sector_sensitivity_output.txt | 2.3 | CANNOT RUN | paper agrees with the saved output |
| 892 | §7.5 | near ten | while the ratio between the two groups stays near ten | arith:quoted medians | 10.2, 10.1, 10.1, 10.1 | MATCH |  |
| 893 | §7.5 | 7.6% | Ranks 501 to 1,000 carry a median 7.6% to 13.8% | rerun:section7_from_aggregates.py | 7.6 | MATCH |  |
| 894 | §7.5 | 13.8% | Ranks 501 to 1,000 carry a median 7.6% to 13.8% | rerun:section7_from_aggregates.py | 13.8 | MATCH |  |
| 895 | §7.6 | 31.3% | (video and community share 31.3% to 30.1% on AI Overviews search qu... | rerun:section7_from_aggregates.py | 31.3 | MATCH |  |
| 896 | §7.6 | 30.1% | (video and community share 31.3% to 30.1% on AI Overviews search qu... | rerun:section7_from_aggregates.py | 30.1 | MATCH |  |
| 897 | §7.6 | 1 -> 1 (both views) | YouTube's rank stayed 1 on AI Overviews | rerun:section7_from_aggregates.py | 1->1, 1->1 | MATCH |  |
| 898 | §7.6 | 2 -> 1 | and moved from 2 to 1 on AI Mode prompts | rerun:section7_from_aggregates.py | 2 -> 1 | MATCH |  |
| 899 | §7.6 | 6.2% | moved Perplexity from 6.2% to 5.5% and Gemini from 15.0% to 13.4% | rerun:section7_from_aggregates.py | 6.2 | MATCH |  |
| 900 | §7.6 | 5.5% | moved Perplexity from 6.2% to 5.5% and Gemini from 15.0% to 13.4% | rerun:section7_from_aggregates.py | 5.5 | MATCH |  |
| 901 | §7.6 | 15.0% | moved Perplexity from 6.2% to 5.5% and Gemini from 15.0% to 13.4% | rerun:section7_from_aggregates.py | 15.0 | MATCH |  |
| 902 | §7.6 | 13.4% | moved Perplexity from 6.2% to 5.5% and Gemini from 15.0% to 13.4% | rerun:section7_from_aggregates.py | 13.4 | MATCH |  |
| 903 | §7.6 | amazon.com -> a flight-route site | changed Copilot's top non-company domain from amazon.com to a fligh... | rerun:section7_from_aggregates.py | amazon.com -> flightconnections.com | MATCH |  |
| 904 | §7.6 | 0.8% | without Industrials the ChatGPT median is 0.8% | shipped:cross_sector_sensitivity_output.txt | 0.8 | CANNOT RUN | paper agrees with the saved output |
| 905 | §7.6 | 10 | P2 holds on ChatGPT and Copilot in 10 of 10 sectors | shipped:cross_sector_sensitivity2_output.txt | 10 | CANNOT RUN | paper agrees with the saved output |
| 906 | §7.6 | 10 | P2 holds on ChatGPT and Copilot in 10 of 10 sectors | shipped:cross_sector_sensitivity2_output.txt | 10 | CANNOT RUN | paper agrees with the saved output |
| 907 | §7.6 | 6 | and on Perplexity in 6 of 10 | shipped:cross_sector_sensitivity2_output.txt | 6 | CANNOT RUN | paper agrees with the saved output |
| 908 | §7.6 | 3 | and P3 holds in 3 of 10 | shipped:cross_sector_sensitivity2_output.txt | 3 | CANNOT RUN | paper agrees with the saved output |
| 909 | §7.6 | 2.2% | hold up to 2.2% of a Financials surface's incidences | shipped:cross_sector_sensitivity_output.txt | 2.2 | CANNOT RUN | paper agrees with the saved output |
| 910 | §7.6 | 25 | by reading each sector's 25 most-cited non-company domains | data:design file (amendment A3) | 25 most-cited | MATCH |  |
| 911 | §7.6 | 860 | cells range from 860 to 18,381,848 incidences | rerun:section7_from_aggregates.py | 860 | MATCH |  |
| 912 | §7.6 | 18,381,848 | cells range from 860 to 18,381,848 incidences | rerun:section7_from_aggregates.py | 18,381,848 | MATCH |  |
| 913 | §7.6 What Measurement 3 establishes | about ten times | about ten times the pooled median share of the other four surfaces | rerun:section7_from_aggregates.py | 10.1 | MATCH |  |
| 914 | §7.6 What Measurement 3 establishes | more than twice | and more than twice Gemini's | rerun:section7_from_aggregates.py | 2.32 | MATCH |  |
| 915 | §8 | derived row | The 21–100 row is derived as the total less the three reported bands | arith:Table 5 | 1.0; 255.0; 314.0; 242.0; 250.0; 70.0 | MATCH |  |
| 916 | §8 | peak at day 60 | The estimated-visits peak at day 60 coincides with that day | data:instrument_series_table5 CSV | 60 | MATCH |  |
| 917 | §8 primary checkpoint | 15,830 | the section held 15,830 ranking positions | data:instrument_series_table5 CSV | 15,830 | MATCH |  |
| 918 | §8 primary checkpoint | 1,874 | 1,874 of them in positions 1 to 3 | data:instrument_series_table5 CSV | 1,874 | MATCH |  |
| 919 | §8 primary checkpoint | 51,800 | with an estimated 51,800 monthly visits | data:instrument_series_table5 CSV | 51,800 | MATCH |  |
| 920 | §8 primary checkpoint | 19 | and nineteen referring domains | data:instrument_series_table5 CSV | 19 | MATCH |  |
| 921 | §8 primary checkpoint | 43,980 | By day 77 it held 43,980 positions across 441 URLs | data:instrument_series_table5 CSV | 43,980 | MATCH |  |
| 922 | §8 primary checkpoint | 441 | By day 77 it held 43,980 positions across 441 URLs | data:instrument_series_table5 CSV | 441 | MATCH |  |
| 923 | §8 primary checkpoint | 17,206 | and appeared in 17,206 stored AI answers | data:instrument_series_table5 CSV | 17,206 | MATCH |  |
| 924 | §8 primary checkpoint | 29,000 | ranked for 29,000 keywords in one instrument and 58,586 in the other | data:single_reads_2026-10.csv | 29,000 | MATCH |  |
| 925 | §8 primary checkpoint | 58,586 | ranked for 29,000 keywords in one instrument and 58,586 in the other | data:single_reads_2026-10.csv | 58,586 | MATCH |  |
| 926 | §8 primary checkpoint | 7,455 | was recorded as a cited source in Google AI Overviews on 7,455 keyw... | data:instrument_series_table3 CSV | 7455 | MATCH |  |
| 927 | §8 concentration | 22.8% | the ten highest-traffic carry 22.8% of estimated visits | data:single_reads_2026-10.csv | 22.8% | MATCH |  |
| 928 | §8 concentration | 64.9% | and the top 50 carry 64.9% | data:single_reads_2026-10.csv | 64.9% | MATCH |  |
| 929 | §8 concentration | 11% | Fifty of 441 is 11% of the pages | arith:50 / 441 | 11.3379 | MATCH |  |
| 930 | §8 concentration | about two thirds | carrying about two thirds of the estimated traffic | data:single_reads_2026-10.csv | 64.9% | MATCH |  |
| 931 | §8 demand | 58,586 | Among the 58,586 US keywords | data:single_reads_2026-10.csv | 58,586 | MATCH |  |
| 932 | §8 demand | 40 to 170, or none | with 40 to 170 reported searches a month or none at all | data:single_reads_2026-10.csv | 40 to 170, or none | MATCH |  |
| 933 | §8 demand | 105 | The section ranks in 105 countries, with 18.5% | data:single_reads_2026-10.csv | 105 | MATCH |  |
| 934 | §8 demand | 18.5% | The section ranks in 105 countries, with 18.5% | data:single_reads_2026-10.csv | 18.5% | MATCH |  |
| 935 | §9.1 | 474 | New York 474 answers | data:single_reads_2026-10.csv | 474 | MATCH |  |
| 936 | §9.1 | 337 | California 337 | data:single_reads_2026-10.csv | 337 | MATCH |  |
| 937 | §9.1 | 322 | Texas 322 | data:single_reads_2026-10.csv | 322 | MATCH |  |
| 938 | §9.1 | 304 | Florida 304 | data:single_reads_2026-10.csv | 304 | MATCH |  |
| 939 | §9.1 | 294 | and the national hub 294 | data:single_reads_2026-10.csv | 294 | MATCH |  |
| 940 | §9.1 | 238 | 214 Dallas 238 | data:single_reads_2026-10.csv | 238 | MATCH |  |
| 941 | §9.1 | 228 | 786 Miami 228 | data:single_reads_2026-10.csv | 228 | MATCH |  |
| 942 | §9.1 | 218 | 404 Atlanta 218 | data:single_reads_2026-10.csv | 218 | MATCH |  |
| 943 | §9.1 | less often | per code it lists, a state hub is cited less often than the most-ci... | data:single reads and code list | NY 20.6, CA 8.2, TX 11.1, FL 13.2 per code against 218 | MATCH |  |
| 944 | §9.1 Figure 8 caption | 8 | The eight pages under the prefix most often cited | data:single_reads_2026-10.csv | 8 | MATCH |  |
| 945 | §9.2 | 13 and 83 | at Domain Ratings between 13 and 83 | data:single_reads_2026-10.csv | 13 and 83 | MATCH |  |
| 946 | §9.2 | 97 | Wikipedia, at 97, is co-cited in roughly 11,000 | data:single_reads_2026-10.csv | 97 | MATCH |  |
| 947 | §9.2 | 11,000 | Wikipedia, at 97, is co-cited in roughly 11,000 | data:single_reads_2026-10.csv | 11,000 | MATCH |  |
| 948 | §9.2 | 9 | are co-cited 9 times (Domain Rating 91) and 240 times (Domain Ratin... | data:single_reads_2026-10.csv | 9 | MATCH |  |
| 949 | §9.2 | 240 | are co-cited 9 times (Domain Rating 91) and 240 times (Domain Ratin... | data:single_reads_2026-10.csv | 240 | MATCH |  |
| 950 | §9.2 | 17,206 | against the section's 17,206 | data:instrument_series_table5 CSV | 17,206 | MATCH |  |
| 951 | §10 | 0 through 31 July | The section had zero live referring domains through 31 July | none:daily referring-domain series not released (Table 5 gives 0 at... |  | CANNOT RUN |  |
| 952 | §10 | 1 | one on 10 August | data:instrument_series_table5 CSV | 1 | MATCH |  |
| 953 | §10 | 19 | and nineteen on 25 August and still nineteen on 1 September | data:instrument_series_table5 CSV | 19 | MATCH |  |
| 954 | §10 | 19 | and nineteen on 25 August and still nineteen on 1 September | data:instrument_series_table5 CSV | 19 | MATCH |  |
| 955 | §10 | 15,830 | by which date it already held 15,830 ranking positions | data:instrument_series_table5 CSV | 15,830 | MATCH |  |
| 956 | §10 | 913 | is reported by the instrument as 913 | data:single_reads_2026-10.csv | 913 | MATCH |  |
| 957 | §10 | 909 | daily series gives 909 at day 75 | data:instrument_series_table5 CSV | 909 | MATCH |  |
| 958 | §10 | 917 | September gives 917 new against 95 lost | data:single_reads_2026-10.csv | 917 | MATCH |  |
| 959 | §10 | 95 | September gives 917 new against 95 lost | data:single_reads_2026-10.csv | 95 | MATCH |  |
| 960 | §10 | 841 | which with nineteen at day 37 implies about 841 | arith:19 + 917 - 95 | 841 | MATCH |  |
| 961 | §10 | roughly 900 | roughly nine hundred by day 75 | data:instrument_series_table5 CSV | 909 | MATCH |  |
| 962 | §10 | 61.9% | They are automated networks: 61.9% .info, 26.4% .asia, 10.2% .xyz | data:single_reads_2026-10.csv | 61.9% | MATCH |  |
| 963 | §10 | 26.4% | They are automated networks: 61.9% .info, 26.4% .asia, 10.2% .xyz | data:single_reads_2026-10.csv | 26.4% | MATCH |  |
| 964 | §10 | 10.2% | They are automated networks: 61.9% .info, 26.4% .asia, 10.2% .xyz | data:single_reads_2026-10.csv | 10.2% | MATCH |  |
| 965 | §10 | below 10 | every linking page at URL Rating below 10 | data:single_reads_2026-10.csv | every linking page below 10 | MATCH |  |
| 966 | §10 | 80 | The second instrument indexes 80 referring domains | data:single_reads_2026-10.csv | 80 | MATCH |  |
| 967 | §10 | 88% | 88% from domains at Authority Score 0–10 and 75% on .xyz | data:single_reads_2026-10.csv | 88% | MATCH |  |
| 968 | §10 | 75% | 88% from domains at Authority Score 0–10 and 75% on .xyz | data:single_reads_2026-10.csv | 75% | MATCH |  |
| 969 | Table 6, Day 0 to 15, domains gained | 1 | 1 | arith:Table 5 | 1 | MATCH |  |
| 970 | Table 6, Day 0 to 15, positions gained | 3,383 | 3,383 | arith:Table 5 | 3383 | MATCH |  |
| 971 | Table 6, Day 0 to 15, rate | 226 | 226 / day | arith:Table 5 | 225.533 | MATCH |  |
| 972 | Table 6, Day 15 to 30, domains gained | 18 | 18 | arith:Table 5 | 18 | MATCH |  |
| 973 | Table 6, Day 15 to 30, positions gained | 11,520 | 11,520 | arith:Table 5 | 11520 | MATCH |  |
| 974 | Table 6, Day 15 to 30, rate | 768 | 768 / day | arith:Table 5 | 768 | MATCH |  |
| 975 | Table 6, Day 30 to 37, domains gained | 0 | 0 | arith:Table 5 | 0 | MATCH |  |
| 976 | Table 6, Day 30 to 37, positions gained | 925 | 925 | arith:Table 5 | 925 | MATCH |  |
| 977 | Table 6, Day 30 to 37, rate | 132 | 132 / day | arith:Table 5 | 132.143 | MATCH |  |
| 978 | Table 6, Day 37 to 45, domains gained | 396 | 396 | arith:Table 5 | 396 | MATCH |  |
| 979 | Table 6, Day 37 to 45, positions gained | 4,496 | 4,496 | arith:Table 5 | 4496 | MATCH |  |
| 980 | Table 6, Day 37 to 45, rate | 562 | 562 / day | arith:Table 5 | 562 | MATCH |  |
| 981 | Table 6, Day 45 to 60, domains gained | 413 | 413 | arith:Table 5 | 413 | MATCH |  |
| 982 | Table 6, Day 45 to 60, positions gained | 16,815 | 16,815 | arith:Table 5 | 16815 | MATCH |  |
| 983 | Table 6, Day 45 to 60, rate | 1,121 | 1,121 / day | arith:Table 5 | 1121 | MATCH |  |
| 984 | Table 6, Day 60 to 75, domains gained | 81 | 81 | arith:Table 5 | 81 | MATCH |  |
| 985 | Table 6, Day 60 to 75, positions gained | 6,161 | 6,161 | arith:Table 5 | 6161 | MATCH |  |
| 986 | Table 6, Day 60 to 75, rate | 411 | 411 / day | arith:Table 5 | 410.733 | MATCH |  |
| 987 | §10.1 | 43,302 | Of the 43,302 positions held at day 75, 15,830 (36.6%) | data:instrument_series_table5 CSV | 43302 | MATCH |  |
| 988 | §10.1 | 36.6% | Of the 43,302 positions held at day 75, 15,830 (36.6%) | arith:Table 5 | 36.5572 | MATCH |  |
| 989 | §10.1 | 27,472 | and 27,472 (63.4%) were acquired after | arith:Table 5 | 27472 | MATCH |  |
| 990 | §10.1 | 63.4% | and 27,472 (63.4%) were acquired after | arith:Table 5 | 63.4428 | MATCH |  |
| 991 | §10.1 | 53.1% | that share is itself bounded rather than exact: 53.1% to 63.4% | arith:Table 5 | 53.0599 | MATCH |  |
| 992 | §10.1 | 63.4% | that share is itself bounded rather than exact: 53.1% to 63.4% | arith:Table 5 | 63.4428 | MATCH |  |
| 993 | §10.1 | 56.9% | the corresponding share is bounded 56.9% to 74.9% | arith:Table 5 | 56.8913 | MATCH |  |
| 994 | §10.1 | 74.9% | the corresponding share is bounded 56.9% to 74.9% | arith:Table 5 | 74.8701 | MATCH |  |
| 995 | §10.1 | 8 | dated only to an eight-day interval | arith:days 37 to 45 | 8 | MATCH |  |
| 996 | §10.1 | 15,830 | A result of 15,830 ranking positions and 1,874 top-three positions | data:instrument_series_table5 CSV | 15,830 | MATCH |  |
| 997 | §10.1 | 1,874 | A result of 15,830 ranking positions and 1,874 top-three positions | data:instrument_series_table5 CSV | 1,874 | MATCH |  |
| 998 | §10.1 | unchanged | with nineteen referring domains, a count unchanged for the precedin... | data:instrument_series_table5 CSV | 19 at day 30, 19 at day 37 | MATCH |  |
| 999 | §10.1 | 768 | The fastest clean interval, 768 a day across days 15 to 30 | data:instrument_series_table6 CSV | 768 | MATCH |  |
| 1000 | §10.1 | 37% | is 37% faster than the 562 a day of the arrival interval | arith:Table 6 rates | 36.6548 | MATCH |  |
| 1001 | §10.1 | 562 | is 37% faster than the 562 a day of the arrival interval | data:instrument_series_table6 CSV | 562 | MATCH |  |
| 1002 | §10.1 | 132 | Reading the 132-a-day trough | data:instrument_series_table6 CSV | 132 | MATCH |  |
| 1003 | §10.1 | 441 | A 441-page section entering an index | data:instrument_series_table5 CSV | 441 | MATCH |  |
| 1004 | §10.1 Figure 9 caption | 984 | day 6 (984 positions, 186 in 1–3) | data:single_reads_2026-10.csv | 984 | MATCH |  |
| 1005 | §10.1 Figure 9 caption | 186 | day 6 (984 positions, 186 in 1–3) | data:single_reads_2026-10.csv | 186 | MATCH |  |
| 1006 | §10.1 Figure 9 caption | 38,801 | and day 67 (38,801 and 6,942) | data:single_reads_2026-10.csv | 38,801 | MATCH |  |
| 1007 | §10.1 Figure 9 caption | 6,942 | and day 67 (38,801 and 6,942) | data:single_reads_2026-10.csv | 6,942 | MATCH |  |
| 1008 | §12 M1 | 2.94 | which differ by a factor that falls from 2.94 to 1.34 | arith:Table 3 counts | 2.93617 | MATCH |  |
| 1009 | §12 M1 | 1.34 | which differ by a factor that falls from 2.94 to 1.34 | arith:Table 3 counts | 1.3438 | MATCH |  |
| 1010 | §12 deployment | 53.1% | between 53.1% and 63.4% of day-75 positions postdate its arrival | arith:Table 5 | 53.0599 | MATCH |  |
| 1011 | §12 deployment | 63.4% | between 53.1% and 63.4% of day-75 positions postdate its arrival | arith:Table 5 | 63.4428 | MATCH |  |
| 1012 | §13 | 1.2 | (1.2 to 2.0 times the most-cited code page) | arith:single reads (Figure 8 values) | 1.23529 | MATCH |  |
| 1013 | §13 | 2.0 | (1.2 to 2.0 times the most-cited code page) | arith:single reads (Figure 8 values) | 1.9916 | MATCH |  |
| 1014 | §13 | 924; 66; f05ce279942be5f8 | The example ships a 924-query demonstration over the 66 codes in it... | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1015 | §13 | α 0.5, β 0.5, damping 0.85, 3 phrasings, mean; 7290a2235d... | lock digest `7290a2235d8de05f`, locked 12 October 2026 | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1016 | §13 | 372 | Every one of the 372 geographic codes in service received a page | data:section_code_pages_2026-10-14.csv | 372 | MATCH |  |
| 1017 | §13 | 971,506 | the stamp is anchored in Bitcoin block 971,506 | data:framework_test_r1 .ots proof (checks/ots_parse.py) | 971,506 | MATCH | the proof commits to the released manifest's SHA-256 and attests this height with merkle root 7bdc6025...59a3, as the folder README states |
| 1018 | §13 | 04:05 UTC, 15 Oct 2026 | mined at 04:05 UTC on 15 October 2026 | none:block time is not in the bundle |  | CANNOT RUN | external check (blockstream.info): block 971,506 header time 2026-10-15T04:05:42Z, merkle root as in the proof |
| 1019 | §13 | committed 14 Oct 2026 | were committed on 14 October 2026 and stamped with OpenTimestamps | none:the plan, predictors and script are held back; the manifest gi... |  | CANNOT RUN | the manifest says it was written 2026-10-15 03:45 UTC (14 Oct, 23:45 US Eastern) |
| 1020 | §13 | 14 of 88 | (14 of 88 exports, 44,463 answers) | data:design file (amendment A3) | after 14 of 88 exports | MATCH |  |
| 1021 | §13 | 44,463 | (14 of 88 exports, 44,463 answers) | data:design file (amendment A3) | 44,463 rows | MATCH | the design file calls them rows |
| 1022 | §13 | 10,000 | Amendment A1 fixed a sampling rule of the 10,000 highest-volume pro... | data:design file (amendment A1) | 10,000 | MATCH |  |
| 1023 | §13 | same block (971,506) | was stamped with OpenTimestamps before any reading under it, in the... | none:the second-domain protocol and its proof are not in the bundle |  | CANNOT RUN |  |
| 1024 | §13.1 | Costco among the 109 | Costco is one of the 109 companies of Section 7 | data:cross_sector_companies.csv | Costco | MATCH |  |
| 1025 | §14 | 149994a; 22 commits (21 + 1); version 0.2.0 | cited here as commit `149994a` of 12 October 2026 | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1026 | §14 | 14,823 | moved from 14,823 (9 October) to 17,206 (11 October) and 17,400 (12... | data:instrument_series_table5 CSV | 14,823 | MATCH |  |
| 1027 | §14 | 17,206 | moved from 14,823 (9 October) to 17,206 (11 October) and 17,400 (12... | data:instrument_series_table5 CSV | 17,206 | MATCH |  |
| 1028 | §14 | 17,400 | moved from 14,823 (9 October) to 17,206 (11 October) and 17,400 (12... | data:ahrefs/semrush_prefixes_2026-10-12.csv | 17400 | MATCH |  |
| 1029 | §14 | 1,910,867 | the October run-rate had moved by about 3% (worldwide 1,910,867, US... | data:single_reads_2026-10.csv | 1,910,867 | MATCH |  |
| 1030 | §14 | 1,659,636 | the October run-rate had moved by about 3% (worldwide 1,910,867, US... | data:single_reads_2026-10.csv | 1,659,636 | MATCH |  |
| 1031 | §14 | about 3% | the October run-rate had moved by about 3% (worldwide 1,910,867, US... | arith:re-read against Table 2 | 2.8% and 3.1% | MATCH |  |
| 1032 | §14 Use of AI tools | 1,056 | of 1,056 numbers the paper quotes, 899 matched | data:08_REVIEW/reproduction_v5.2_run2_2026-10-15/outputs/tally.txt | 1056 | MATCH |  |
| 1033 | §14 Use of AI tools | 899 | of 1,056 numbers the paper quotes, 899 matched | data:08_REVIEW/reproduction_v5.2_run2_2026-10-15/outputs/tally.txt | 899 | MATCH |  |
| 1034 | §14 Use of AI tools | 1 | of 1,056 numbers the paper quotes, 899 matched | data:08_REVIEW/reproduction_v5.2_run2_2026-10-15/outputs/tally.txt | 1 | MATCH |  |
| 1035 | §14 Use of AI tools | 156 | of 1,056 numbers the paper quotes, 899 matched | data:08_REVIEW/reproduction_v5.2_run2_2026-10-15/outputs/tally.txt | 156 | MATCH |  |
| 1036 | §14 Use of AI tools | corrected | one differed (Table 2's day count, now corrected) | arith:Table 2 days-live column (manuscript) | 11 (78 in all, days 0 to 77) | MATCH | corrected in the manuscript; the released Table 2 CSV still reads '11 (77 cumulative)' (counted once, at the Table 2 cell) |
| 1037 | §15 | 7.5 | by factors of 7.5 to 27.1 over four months | arith:Table 2 values | 7.46965 | MATCH |  |
| 1038 | §15 | 27.1 | by factors of 7.5 to 27.1 over four months | arith:Table 2 values | 27.1414 | MATCH |  |
| 1039 | §15 | 8.6 | (8.6 to 29.9 with both read worldwide) | arith:Table 2 values | 8.62011 | MATCH |  |
| 1040 | §15 | 29.9 | (8.6 to 29.9 with both read worldwide) | arith:Table 2 values | 29.8608 | MATCH |  |
| 1041 | §15 | 2.7 | about its growth by a factor of 2.7 in one month | rerun:instrument_extra.py | 2.66 | MATCH |  |
| 1042 | §15 | 11 | about its referring domains by a factor of eleven | arith:913 / 80 | 11.4125 | MATCH |  |
| 1043 | §15 | one fifth to seven | their ratio on estimated visits ran from one fifth to seven times | rerun:analyze.py | 0.20x to 7.24x | MATCH |  |
| 1044 | §15 | 60 of 66 | which of two sections was larger in 60 of 66 pairs | rerun:analyze.py | 60 of 66 | MATCH |  |
| 1045 | §15 | 37,193 | On 37,193 business reviews, the two agreed | shipped:analyze_reviews_output.txt | 37193 | CANNOT RUN | paper agrees with the saved output |
| 1046 | §15 | +0.47 | (+0.47 to +0.75, depending on attribution) | rerun:m2_from_counts.py | +0.468 | MATCH |  |
| 1047 | §15 | +0.75 | (+0.47 to +0.75, depending on attribution) | rerun:m2_from_counts.py | +0.748 | MATCH |  |
| 1048 | §15 | +0.19 | (+0.19, or +0.27 counting labels no review mentions) | rerun:m2_from_counts.py (full precision via checks/m2_precise.py) | 0.184869 | MISMATCH | prints +0.185; the full value 0.184869 is +0.18 to two decimals (double rounding) |
| 1049 | §15 | +0.27 | (+0.19, or +0.27 counting labels no review mentions) | rerun:m2_from_counts.py | +0.273 | MATCH |  |
| 1050 | §15 | one in seven | one in seven unhappy reviews matched a waiting pattern | arith:924 / 6,620 | 1 in 7.16 | MATCH |  |
| 1051 | §15 | 11 | the whole taxonomy holds 11 labels mentioning waiting | shipped:supplement_r10_output.txt | 11 | CANNOT RUN | paper agrees with the saved output |
| 1052 | §15 | 622 | with 622 searches a month | shipped:supplement_r10_output.txt | 622 | CANNOT RUN | paper agrees with the saved output |
| 1053 | §15 | 21% | a median 21% on Google's AI Overviews and AI Mode against 0.6% to 9.2% | rerun:section7_from_aggregates.py | 21.3 | MATCH |  |
| 1054 | §15 | 0.6% | a median 21% on Google's AI Overviews and AI Mode against 0.6% to 9.2% | rerun:section7_from_aggregates.py | 0.6 | MATCH |  |
| 1055 | §15 | 9.2% | a median 21% on Google's AI Overviews and AI Mode against 0.6% to 9.2% | rerun:section7_from_aggregates.py | 9.2 | MATCH |  |
| 1056 | §15 | 11 of 11 | higher on every Google view than on every other surface in every se... | rerun:section7_from_aggregates.py | 11/11 | MATCH |  |
| 1057 | §15 | 2 failed | two of four predictions written before collection failed | rerun:section7_from_aggregates.py | 1 held, 1 held in direction only, 2 failed | MATCH |  |
| 1058 | §15 | 15,830 | the section held 15,830 ranking positions with nineteen referring d... | data:instrument_series_table5 CSV | 15,830 | MATCH |  |
| 1059 | §15 | 19 | the section held 15,830 ranking positions with nineteen referring d... | data:instrument_series_table5 CSV | 19 | MATCH |  |
| 1060 | §15 | 17,206 | and by day 77 appeared in 17,206 recorded AI answers | data:instrument_series_table5 CSV | 17,206 | MATCH |  |
| 1061 | Appendix A | 381 | The page count is 381, not 290 | data:section_code_pages_2026-10-14.csv | 381 | MATCH |  |
| 1062 | Appendix A | 9.2x | A 9.2x AI-answer comparison was withdrawn | arith:158,100 / 17,206 | 9.18866 | MATCH |  |
| 1063 | Appendix A | 78 | its days-live column sums to 78 (days 0 to 77) | arith:Table 2 days-live column (manuscript) | 78 | MATCH |  |
| 1064 | Appendix A | 5.2 | by a factor of 5.2 at 27.1x, not 13 times | arith:sqrt of 27.1 | 5.20975 | MATCH |  |
| 1065 | Appendix A | −0.11 in Figure 5 | a stale copy of Figure 5 that printed −0.09 for −0.11 was replaced | figure:make_figs_v4.py (regenerated fig4_prefixes) | Spearman ρ = −0.11 | MATCH |  |
| 1066 | Appendix A | +0.47 | Branch agreement is +0.47 to +0.75 depending on how labels are attr... | rerun:m2_from_counts.py | +0.468 | MATCH |  |
| 1067 | Appendix A | +0.75 | Branch agreement is +0.47 to +0.75 depending on how labels are attr... | rerun:m2_from_counts.py | +0.748 | MATCH |  |
| 1068 | Appendix A | +0.78 | replacing an earlier +0.78 computed on review-mentioned labels only | shipped:analyze_reviews_output.txt | +0.777 | CANNOT RUN | paper agrees with the saved output |
| 1069 | Appendix A | 11 | the taxonomy holds 11 labels containing "wait", not one | shipped:supplement_r10_output.txt | 11 | CANNOT RUN | paper agrees with the saved output |
| 1070 | Appendix A | 456 | the count of works naming the vendor tools is 456, not 459 | rerun:vendor_reliance.py --offline | 456 | MATCH |  |
| 1071 | Appendix A | 459 | the count of works naming the vendor tools is 456, not 459 | data:vendor_reliance_works.csv (rows before de-duplication) | 459 | MATCH |  |
| 1072 | Appendix A | 3 | (three works were counted twice) | rerun:vendor_reliance.py --offline | 3 | MATCH |  |
| 1073 | Appendix B | 0.22 | (about 0.22 when 30 of 66 entities have none) | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1074 | Appendix B | 7290a2235d8de05f; 02:00 UTC | (digest `7290a2235d8de05f`, set at 02:00 UTC on 12 October 2026) | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1075 | Appendix B | 03:45 UTC; 02d7588 | The scoring code changed at 03:45 UTC the same day (commit `02d7588` | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1076 | Appendix B | 0.8 | Its `rel` term correlates with node degree at roughly 0.8 in the re... | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1077 | Appendix B | 4/5 | On the released example these are 4/5 and 70.4% | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1078 | Appendix B | 70.4% | On the released example these are 4/5 and 70.4% | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1079 | Appendix B | 2 of 4 | with two of the four expressible questions answered for every subject | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1080 | Table C1, AI Overviews, search queries, Video and community, median | 25.8 | 25.8% (14.3–34.3) | rerun:section7_from_aggregates.py | 25.8 | MATCH |  |
| 1081 | Table C1, AI Overviews, search queries, Video and community, min | 14.3 | 25.8% (14.3–34.3) | rerun:section7_from_aggregates.py | 14.3 | MATCH |  |
| 1082 | Table C1, AI Overviews, search queries, Video and community, max | 34.3 | 25.8% (14.3–34.3) | rerun:section7_from_aggregates.py | 34.3 | MATCH |  |
| 1083 | Table C1, AI Overviews, search queries, Reference, median | 4.3 | 4.3% (1.3–8.1) | rerun:section7_from_aggregates.py | 4.3 | MATCH |  |
| 1084 | Table C1, AI Overviews, search queries, Reference, min | 1.3 | 4.3% (1.3–8.1) | rerun:section7_from_aggregates.py | 1.3 | MATCH |  |
| 1085 | Table C1, AI Overviews, search queries, Reference, max | 8.1 | 4.3% (1.3–8.1) | rerun:section7_from_aggregates.py | 8.1 | MATCH |  |
| 1086 | Table C1, AI Overviews, search queries, News, median | 0.7 | 0.7% (0.2–2.8) | rerun:section7_from_aggregates.py | 0.7 | MATCH |  |
| 1087 | Table C1, AI Overviews, search queries, News, min | 0.2 | 0.7% (0.2–2.8) | rerun:section7_from_aggregates.py | 0.2 | MATCH |  |
| 1088 | Table C1, AI Overviews, search queries, News, max | 2.8 | 0.7% (0.2–2.8) | rerun:section7_from_aggregates.py | 2.8 | MATCH |  |
| 1089 | Table C1, AI Overviews, search queries, Government, median | 0.4 | 0.4% (0.2–8.6) | rerun:section7_from_aggregates.py | 0.4 | MATCH |  |
| 1090 | Table C1, AI Overviews, search queries, Government, min | 0.2 | 0.4% (0.2–8.6) | rerun:section7_from_aggregates.py | 0.2 | MATCH |  |
| 1091 | Table C1, AI Overviews, search queries, Government, max | 8.6 | 0.4% (0.2–8.6) | rerun:section7_from_aggregates.py | 8.6 | MATCH |  |
| 1092 | Table C1, AI Overviews, search queries, Sector's companies, median | 11.9 | 11.9% (6.1–23.5) | rerun:section7_from_aggregates.py | 11.9 | MATCH |  |
| 1093 | Table C1, AI Overviews, search queries, Sector's companies, min | 6.1 | 11.9% (6.1–23.5) | rerun:section7_from_aggregates.py | 6.1 | MATCH |  |
| 1094 | Table C1, AI Overviews, search queries, Sector's companies, max | 23.5 | 11.9% (6.1–23.5) | rerun:section7_from_aggregates.py | 23.5 | MATCH |  |
| 1095 | Table C1, AI Overviews, search queries, Other web, median | 55.6 | 55.6% (41.1–62.0) | rerun:section7_from_aggregates.py | 55.6 | MATCH |  |
| 1096 | Table C1, AI Overviews, search queries, Other web, min | 41.1 | 55.6% (41.1–62.0) | rerun:section7_from_aggregates.py | 41.1 | MATCH |  |
| 1097 | Table C1, AI Overviews, search queries, Other web, max | 62.0 | 55.6% (41.1–62.0) | rerun:section7_from_aggregates.py | 62.0 | MATCH |  |
| 1098 | Table C1, AI Overviews, prompts, Video and community, median | 32.4 | 32.4% (13.4–35.8) | rerun:section7_from_aggregates.py | 32.4 | MATCH |  |
| 1099 | Table C1, AI Overviews, prompts, Video and community, min | 13.4 | 32.4% (13.4–35.8) | rerun:section7_from_aggregates.py | 13.4 | MATCH |  |
| 1100 | Table C1, AI Overviews, prompts, Video and community, max | 35.8 | 32.4% (13.4–35.8) | rerun:section7_from_aggregates.py | 35.8 | MATCH |  |
| 1101 | Table C1, AI Overviews, prompts, Reference, median | 2.6 | 2.6% (0.7–3.9) | rerun:section7_from_aggregates.py | 2.6 | MATCH |  |
| 1102 | Table C1, AI Overviews, prompts, Reference, min | 0.7 | 2.6% (0.7–3.9) | rerun:section7_from_aggregates.py | 0.7 | MATCH |  |
| 1103 | Table C1, AI Overviews, prompts, Reference, max | 3.9 | 2.6% (0.7–3.9) | rerun:section7_from_aggregates.py | 3.9 | MATCH |  |
| 1104 | Table C1, AI Overviews, prompts, News, median | 1.0 | 1.0% (0.1–5.8) | rerun:section7_from_aggregates.py | 1.0 | MATCH |  |
| 1105 | Table C1, AI Overviews, prompts, News, min | 0.1 | 1.0% (0.1–5.8) | rerun:section7_from_aggregates.py | 0.1 | MATCH |  |
| 1106 | Table C1, AI Overviews, prompts, News, max | 5.8 | 1.0% (0.1–5.8) | rerun:section7_from_aggregates.py | 5.8 | MATCH |  |
| 1107 | Table C1, AI Overviews, prompts, Government, median | 0.3 | 0.3% (0.1–3.8) | rerun:section7_from_aggregates.py | 0.3 | MATCH |  |
| 1108 | Table C1, AI Overviews, prompts, Government, min | 0.1 | 0.3% (0.1–3.8) | rerun:section7_from_aggregates.py | 0.1 | MATCH |  |
| 1109 | Table C1, AI Overviews, prompts, Government, max | 3.8 | 0.3% (0.1–3.8) | rerun:section7_from_aggregates.py | 3.8 | MATCH |  |
| 1110 | Table C1, AI Overviews, prompts, Sector's companies, median | 8.1 | 8.1% (2.7–20.5) | rerun:section7_from_aggregates.py | 8.1 | MATCH |  |
| 1111 | Table C1, AI Overviews, prompts, Sector's companies, min | 2.7 | 8.1% (2.7–20.5) | rerun:section7_from_aggregates.py | 2.7 | MATCH |  |
| 1112 | Table C1, AI Overviews, prompts, Sector's companies, max | 20.5 | 8.1% (2.7–20.5) | rerun:section7_from_aggregates.py | 20.5 | MATCH |  |
| 1113 | Table C1, AI Overviews, prompts, Other web, median | 59.0 | 59.0% (42.0–75.3) | rerun:section7_from_aggregates.py | 59.0 | MATCH |  |
| 1114 | Table C1, AI Overviews, prompts, Other web, min | 42.0 | 59.0% (42.0–75.3) | rerun:section7_from_aggregates.py | 42.0 | MATCH |  |
| 1115 | Table C1, AI Overviews, prompts, Other web, max | 75.3 | 59.0% (42.0–75.3) | rerun:section7_from_aggregates.py | 75.3 | MATCH |  |
| 1116 | Table C1, AI Mode, search queries, Video and community, median | 17.8 | 17.8% (9.0–23.8) | rerun:section7_from_aggregates.py | 17.8 | MATCH |  |
| 1117 | Table C1, AI Mode, search queries, Video and community, min | 9.0 | 17.8% (9.0–23.8) | rerun:section7_from_aggregates.py | 9.0 | MATCH |  |
| 1118 | Table C1, AI Mode, search queries, Video and community, max | 23.8 | 17.8% (9.0–23.8) | rerun:section7_from_aggregates.py | 23.8 | MATCH |  |
| 1119 | Table C1, AI Mode, search queries, Reference, median | 4.2 | 4.2% (2.2–10.4) | rerun:section7_from_aggregates.py | 4.2 | MATCH |  |
| 1120 | Table C1, AI Mode, search queries, Reference, min | 2.2 | 4.2% (2.2–10.4) | rerun:section7_from_aggregates.py | 2.2 | MATCH |  |
| 1121 | Table C1, AI Mode, search queries, Reference, max | 10.4 | 4.2% (2.2–10.4) | rerun:section7_from_aggregates.py | 10.4 | MATCH |  |
| 1122 | Table C1, AI Mode, search queries, News, median | 1.0 | 1.0% (0.3–4.2) | rerun:section7_from_aggregates.py | 1.0 | MATCH |  |
| 1123 | Table C1, AI Mode, search queries, News, min | 0.3 | 1.0% (0.3–4.2) | rerun:section7_from_aggregates.py | 0.3 | MATCH |  |
| 1124 | Table C1, AI Mode, search queries, News, max | 4.2 | 1.0% (0.3–4.2) | rerun:section7_from_aggregates.py | 4.2 | MATCH |  |
| 1125 | Table C1, AI Mode, search queries, Government, median | 0.4 | 0.4% (0.1–8.6) | rerun:section7_from_aggregates.py | 0.4 | MATCH |  |
| 1126 | Table C1, AI Mode, search queries, Government, min | 0.1 | 0.4% (0.1–8.6) | rerun:section7_from_aggregates.py | 0.1 | MATCH |  |
| 1127 | Table C1, AI Mode, search queries, Government, max | 8.6 | 0.4% (0.1–8.6) | rerun:section7_from_aggregates.py | 8.6 | MATCH |  |
| 1128 | Table C1, AI Mode, search queries, Sector's companies, median | 10.8 | 10.8% (5.1–17.6) | rerun:section7_from_aggregates.py | 10.8 | MATCH |  |
| 1129 | Table C1, AI Mode, search queries, Sector's companies, min | 5.1 | 10.8% (5.1–17.6) | rerun:section7_from_aggregates.py | 5.1 | MATCH |  |
| 1130 | Table C1, AI Mode, search queries, Sector's companies, max | 17.6 | 10.8% (5.1–17.6) | rerun:section7_from_aggregates.py | 17.6 | MATCH |  |
| 1131 | Table C1, AI Mode, search queries, Other web, median | 65.3 | 65.3% (53.1–71.4) | rerun:section7_from_aggregates.py | 65.3 | MATCH |  |
| 1132 | Table C1, AI Mode, search queries, Other web, min | 53.1 | 65.3% (53.1–71.4) | rerun:section7_from_aggregates.py | 53.1 | MATCH |  |
| 1133 | Table C1, AI Mode, search queries, Other web, max | 71.4 | 65.3% (53.1–71.4) | rerun:section7_from_aggregates.py | 71.4 | MATCH |  |
| 1134 | Table C1, AI Mode, prompts, Video and community, median | 24.1 | 24.1% (8.1–28.3) | rerun:section7_from_aggregates.py | 24.1 | MATCH |  |
| 1135 | Table C1, AI Mode, prompts, Video and community, min | 8.1 | 24.1% (8.1–28.3) | rerun:section7_from_aggregates.py | 8.1 | MATCH |  |
| 1136 | Table C1, AI Mode, prompts, Video and community, max | 28.3 | 24.1% (8.1–28.3) | rerun:section7_from_aggregates.py | 28.3 | MATCH |  |
| 1137 | Table C1, AI Mode, prompts, Reference, median | 2.7 | 2.7% (0.9–4.5) | rerun:section7_from_aggregates.py | 2.7 | MATCH |  |
| 1138 | Table C1, AI Mode, prompts, Reference, min | 0.9 | 2.7% (0.9–4.5) | rerun:section7_from_aggregates.py | 0.9 | MATCH |  |
| 1139 | Table C1, AI Mode, prompts, Reference, max | 4.5 | 2.7% (0.9–4.5) | rerun:section7_from_aggregates.py | 4.5 | MATCH |  |
| 1140 | Table C1, AI Mode, prompts, News, median | 1.4 | 1.4% (0.3–5.6) | rerun:section7_from_aggregates.py | 1.4 | MATCH |  |
| 1141 | Table C1, AI Mode, prompts, News, min | 0.3 | 1.4% (0.3–5.6) | rerun:section7_from_aggregates.py | 0.3 | MATCH |  |
| 1142 | Table C1, AI Mode, prompts, News, max | 5.6 | 1.4% (0.3–5.6) | rerun:section7_from_aggregates.py | 5.6 | MATCH |  |
| 1143 | Table C1, AI Mode, prompts, Government, median | 0.4 | 0.4% (0.1–5.0) | rerun:section7_from_aggregates.py | 0.4 | MATCH |  |
| 1144 | Table C1, AI Mode, prompts, Government, min | 0.1 | 0.4% (0.1–5.0) | rerun:section7_from_aggregates.py | 0.1 | MATCH |  |
| 1145 | Table C1, AI Mode, prompts, Government, max | 5.0 | 0.4% (0.1–5.0) | rerun:section7_from_aggregates.py | 5.0 | MATCH |  |
| 1146 | Table C1, AI Mode, prompts, Sector's companies, median | 9.5 | 9.5% (2.7–19.3) | rerun:section7_from_aggregates.py | 9.5 | MATCH |  |
| 1147 | Table C1, AI Mode, prompts, Sector's companies, min | 2.7 | 9.5% (2.7–19.3) | rerun:section7_from_aggregates.py | 2.7 | MATCH |  |
| 1148 | Table C1, AI Mode, prompts, Sector's companies, max | 19.3 | 9.5% (2.7–19.3) | rerun:section7_from_aggregates.py | 19.3 | MATCH |  |
| 1149 | Table C1, AI Mode, prompts, Other web, median | 65.1 | 65.1% (50.1–79.3) | rerun:section7_from_aggregates.py | 65.1 | MATCH |  |
| 1150 | Table C1, AI Mode, prompts, Other web, min | 50.1 | 65.1% (50.1–79.3) | rerun:section7_from_aggregates.py | 50.1 | MATCH |  |
| 1151 | Table C1, AI Mode, prompts, Other web, max | 79.3 | 65.1% (50.1–79.3) | rerun:section7_from_aggregates.py | 79.3 | MATCH |  |
| 1152 | Table C1, ChatGPT, Video and community, median | 0.9 | 0.9% (0.3–2.5) | rerun:section7_from_aggregates.py | 0.9 | MATCH |  |
| 1153 | Table C1, ChatGPT, Video and community, min | 0.3 | 0.9% (0.3–2.5) | rerun:section7_from_aggregates.py | 0.3 | MATCH |  |
| 1154 | Table C1, ChatGPT, Video and community, max | 2.5 | 0.9% (0.3–2.5) | rerun:section7_from_aggregates.py | 2.5 | MATCH |  |
| 1155 | Table C1, ChatGPT, Reference, median | 1.7 | 1.7% (0.5–3.4) | rerun:section7_from_aggregates.py | 1.7 | MATCH |  |
| 1156 | Table C1, ChatGPT, Reference, min | 0.5 | 1.7% (0.5–3.4) | rerun:section7_from_aggregates.py | 0.5 | MATCH |  |
| 1157 | Table C1, ChatGPT, Reference, max | 3.4 | 1.7% (0.5–3.4) | rerun:section7_from_aggregates.py | 3.4 | MATCH |  |
| 1158 | Table C1, ChatGPT, News, median | 1.7 | 1.7% (0.7–5.2) | rerun:section7_from_aggregates.py | 1.7 | MATCH |  |
| 1159 | Table C1, ChatGPT, News, min | 0.7 | 1.7% (0.7–5.2) | rerun:section7_from_aggregates.py | 0.7 | MATCH |  |
| 1160 | Table C1, ChatGPT, News, max | 5.2 | 1.7% (0.7–5.2) | rerun:section7_from_aggregates.py | 5.2 | MATCH |  |
| 1161 | Table C1, ChatGPT, Government, median | 3.0 | 3.0% (1.6–18.2) | rerun:section7_from_aggregates.py | 3.0 | MATCH |  |
| 1162 | Table C1, ChatGPT, Government, min | 1.6 | 3.0% (1.6–18.2) | rerun:section7_from_aggregates.py | 1.6 | MATCH |  |
| 1163 | Table C1, ChatGPT, Government, max | 18.2 | 3.0% (1.6–18.2) | rerun:section7_from_aggregates.py | 18.2 | MATCH |  |
| 1164 | Table C1, ChatGPT, Sector's companies, median | 27.4 | 27.4% (13.5–38.2) | rerun:section7_from_aggregates.py | 27.4 | MATCH |  |
| 1165 | Table C1, ChatGPT, Sector's companies, min | 13.5 | 27.4% (13.5–38.2) | rerun:section7_from_aggregates.py | 13.5 | MATCH |  |
| 1166 | Table C1, ChatGPT, Sector's companies, max | 38.2 | 27.4% (13.5–38.2) | rerun:section7_from_aggregates.py | 38.2 | MATCH |  |
| 1167 | Table C1, ChatGPT, Other web, median | 61.5 | 61.5% (51.2–76.1) | rerun:section7_from_aggregates.py | 61.5 | MATCH |  |
| 1168 | Table C1, ChatGPT, Other web, min | 51.2 | 61.5% (51.2–76.1) | rerun:section7_from_aggregates.py | 51.2 | MATCH |  |
| 1169 | Table C1, ChatGPT, Other web, max | 76.1 | 61.5% (51.2–76.1) | rerun:section7_from_aggregates.py | 76.1 | MATCH |  |
| 1170 | Table C1, Perplexity, Video and community, median | 4.6 | 4.6% (1.8–7.7) | rerun:section7_from_aggregates.py | 4.6 | MATCH |  |
| 1171 | Table C1, Perplexity, Video and community, min | 1.8 | 4.6% (1.8–7.7) | rerun:section7_from_aggregates.py | 1.8 | MATCH |  |
| 1172 | Table C1, Perplexity, Video and community, max | 7.7 | 4.6% (1.8–7.7) | rerun:section7_from_aggregates.py | 7.7 | MATCH |  |
| 1173 | Table C1, Perplexity, Reference, median | 5.9 | 5.9% (2.8–10.7) | rerun:section7_from_aggregates.py | 5.9 | MATCH |  |
| 1174 | Table C1, Perplexity, Reference, min | 2.8 | 5.9% (2.8–10.7) | rerun:section7_from_aggregates.py | 2.8 | MATCH |  |
| 1175 | Table C1, Perplexity, Reference, max | 10.7 | 5.9% (2.8–10.7) | rerun:section7_from_aggregates.py | 10.7 | MATCH |  |
| 1176 | Table C1, Perplexity, News, median | 1.5 | 1.5% (0.3–7.9) | rerun:section7_from_aggregates.py | 1.5 | MATCH |  |
| 1177 | Table C1, Perplexity, News, min | 0.3 | 1.5% (0.3–7.9) | rerun:section7_from_aggregates.py | 0.3 | MATCH |  |
| 1178 | Table C1, Perplexity, News, max | 7.9 | 1.5% (0.3–7.9) | rerun:section7_from_aggregates.py | 7.9 | MATCH |  |
| 1179 | Table C1, Perplexity, Government, median | 0.8 | 0.8% (0.1–12.0) | rerun:section7_from_aggregates.py | 0.8 | MATCH |  |
| 1180 | Table C1, Perplexity, Government, min | 0.1 | 0.8% (0.1–12.0) | rerun:section7_from_aggregates.py | 0.1 | MATCH |  |
| 1181 | Table C1, Perplexity, Government, max | 12.0 | 0.8% (0.1–12.0) | rerun:section7_from_aggregates.py | 12.0 | MATCH |  |
| 1182 | Table C1, Perplexity, Sector's companies, median | 15.6 | 15.6% (8.2–29.8) | rerun:section7_from_aggregates.py | 15.6 | MATCH |  |
| 1183 | Table C1, Perplexity, Sector's companies, min | 8.2 | 15.6% (8.2–29.8) | rerun:section7_from_aggregates.py | 8.2 | MATCH |  |
| 1184 | Table C1, Perplexity, Sector's companies, max | 29.8 | 15.6% (8.2–29.8) | rerun:section7_from_aggregates.py | 29.8 | MATCH |  |
| 1185 | Table C1, Perplexity, Other web, median | 67.8 | 67.8% (56.4–73.9) | rerun:section7_from_aggregates.py | 67.8 | MATCH |  |
| 1186 | Table C1, Perplexity, Other web, min | 56.4 | 67.8% (56.4–73.9) | rerun:section7_from_aggregates.py | 56.4 | MATCH |  |
| 1187 | Table C1, Perplexity, Other web, max | 73.9 | 67.8% (56.4–73.9) | rerun:section7_from_aggregates.py | 73.9 | MATCH |  |
| 1188 | Table C1, Gemini, Video and community, median | 9.2 | 9.2% (2.9–16.7) | rerun:section7_from_aggregates.py | 9.2 | MATCH |  |
| 1189 | Table C1, Gemini, Video and community, min | 2.9 | 9.2% (2.9–16.7) | rerun:section7_from_aggregates.py | 2.9 | MATCH |  |
| 1190 | Table C1, Gemini, Video and community, max | 16.7 | 9.2% (2.9–16.7) | rerun:section7_from_aggregates.py | 16.7 | MATCH |  |
| 1191 | Table C1, Gemini, Reference, median | 3.7 | 3.7% (1.2–6.9) | rerun:section7_from_aggregates.py | 3.7 | MATCH |  |
| 1192 | Table C1, Gemini, Reference, min | 1.2 | 3.7% (1.2–6.9) | rerun:section7_from_aggregates.py | 1.2 | MATCH |  |
| 1193 | Table C1, Gemini, Reference, max | 6.9 | 3.7% (1.2–6.9) | rerun:section7_from_aggregates.py | 6.9 | MATCH |  |
| 1194 | Table C1, Gemini, News, median | 0.5 | 0.5% (0.1–3.8) | rerun:section7_from_aggregates.py | 0.5 | MATCH |  |
| 1195 | Table C1, Gemini, News, min | 0.1 | 0.5% (0.1–3.8) | rerun:section7_from_aggregates.py | 0.1 | MATCH |  |
| 1196 | Table C1, Gemini, News, max | 3.8 | 0.5% (0.1–3.8) | rerun:section7_from_aggregates.py | 3.8 | MATCH |  |
| 1197 | Table C1, Gemini, Government, median | 0.3 | 0.3% (0.1–2.4) | rerun:section7_from_aggregates.py | 0.3 | MATCH |  |
| 1198 | Table C1, Gemini, Government, min | 0.1 | 0.3% (0.1–2.4) | rerun:section7_from_aggregates.py | 0.1 | MATCH |  |
| 1199 | Table C1, Gemini, Government, max | 2.4 | 0.3% (0.1–2.4) | rerun:section7_from_aggregates.py | 2.4 | MATCH |  |
| 1200 | Table C1, Gemini, Sector's companies, median | 8.3 | 8.3% (3.2–33.2) | rerun:section7_from_aggregates.py | 8.3 | MATCH |  |
| 1201 | Table C1, Gemini, Sector's companies, min | 3.2 | 8.3% (3.2–33.2) | rerun:section7_from_aggregates.py | 3.2 | MATCH |  |
| 1202 | Table C1, Gemini, Sector's companies, max | 33.2 | 8.3% (3.2–33.2) | rerun:section7_from_aggregates.py | 33.2 | MATCH |  |
| 1203 | Table C1, Gemini, Other web, median | 75.2 | 75.2% (49.5–85.3) | rerun:section7_from_aggregates.py | 75.2 | MATCH |  |
| 1204 | Table C1, Gemini, Other web, min | 49.5 | 75.2% (49.5–85.3) | rerun:section7_from_aggregates.py | 49.5 | MATCH |  |
| 1205 | Table C1, Gemini, Other web, max | 85.3 | 75.2% (49.5–85.3) | rerun:section7_from_aggregates.py | 85.3 | MATCH |  |
| 1206 | Table C1, Copilot, Video and community, median | 0.6 | 0.6% (0.3–1.0) | rerun:section7_from_aggregates.py | 0.6 | MATCH |  |
| 1207 | Table C1, Copilot, Video and community, min | 0.3 | 0.6% (0.3–1.0) | rerun:section7_from_aggregates.py | 0.3 | MATCH |  |
| 1208 | Table C1, Copilot, Video and community, max | 1.0 | 0.6% (0.3–1.0) | rerun:section7_from_aggregates.py | 1.0 | MATCH |  |
| 1209 | Table C1, Copilot, Reference, median | 1.6 | 1.6% (0.3–2.7) | rerun:section7_from_aggregates.py | 1.6 | MATCH |  |
| 1210 | Table C1, Copilot, Reference, min | 0.3 | 1.6% (0.3–2.7) | rerun:section7_from_aggregates.py | 0.3 | MATCH |  |
| 1211 | Table C1, Copilot, Reference, max | 2.7 | 1.6% (0.3–2.7) | rerun:section7_from_aggregates.py | 2.7 | MATCH |  |
| 1212 | Table C1, Copilot, News, median | 0.9 | 0.9% (0.2–5.2) | rerun:section7_from_aggregates.py | 0.9 | MATCH |  |
| 1213 | Table C1, Copilot, News, min | 0.2 | 0.9% (0.2–5.2) | rerun:section7_from_aggregates.py | 0.2 | MATCH |  |
| 1214 | Table C1, Copilot, News, max | 5.2 | 0.9% (0.2–5.2) | rerun:section7_from_aggregates.py | 5.2 | MATCH |  |
| 1215 | Table C1, Copilot, Government, median | 0.1 | 0.1% (0.0–2.2) | rerun:section7_from_aggregates.py | 0.1 | MATCH |  |
| 1216 | Table C1, Copilot, Government, min | 0.0 | 0.1% (0.0–2.2) | rerun:section7_from_aggregates.py | 0.0 | MATCH |  |
| 1217 | Table C1, Copilot, Government, max | 2.2 | 0.1% (0.0–2.2) | rerun:section7_from_aggregates.py | 2.2 | MATCH |  |
| 1218 | Table C1, Copilot, Sector's companies, median | 4.5 | 4.5% (1.6–27.0) | rerun:section7_from_aggregates.py | 4.5 | MATCH |  |
| 1219 | Table C1, Copilot, Sector's companies, min | 1.6 | 4.5% (1.6–27.0) | rerun:section7_from_aggregates.py | 1.6 | MATCH |  |
| 1220 | Table C1, Copilot, Sector's companies, max | 27.0 | 4.5% (1.6–27.0) | rerun:section7_from_aggregates.py | 27.0 | MATCH |  |
| 1221 | Table C1, Copilot, Other web, median | 89.9 | 89.9% (71.6–94.6) | rerun:section7_from_aggregates.py | 89.9 | MATCH |  |
| 1222 | Table C1, Copilot, Other web, min | 71.6 | 89.9% (71.6–94.6) | rerun:section7_from_aggregates.py | 71.6 | MATCH |  |
| 1223 | Table C1, Copilot, Other web, max | 94.6 | 89.9% (71.6–94.6) | rerun:section7_from_aggregates.py | 94.6 | MATCH |  |
| 1224 | Table C2, Information Technology, AIO search | 10,891.5 | 10,891.5 | rerun:section7_from_aggregates.py | 10,891.5 | MATCH |  |
| 1225 | Table C2, Information Technology, AIO prompt | 294.3 | 294.3 | rerun:section7_from_aggregates.py | 294.3 | MATCH |  |
| 1226 | Table C2, Information Technology, AIM search | 1,128.4 | 1,128.4 | rerun:section7_from_aggregates.py | 1,128.4 | MATCH |  |
| 1227 | Table C2, Information Technology, AIM prompt | 352.4 | 352.4 | rerun:section7_from_aggregates.py | 352.4 | MATCH |  |
| 1228 | Table C2, Information Technology, ChatGPT | 317.5 | 317.5 | rerun:section7_from_aggregates.py | 317.5 | MATCH |  |
| 1229 | Table C2, Information Technology, Perplexity | 186.8 | 186.8 | rerun:section7_from_aggregates.py | 186.8 | MATCH |  |
| 1230 | Table C2, Information Technology, Gemini | 147.9 | 147.9 | rerun:section7_from_aggregates.py | 147.9 | MATCH |  |
| 1231 | Table C2, Information Technology, Copilot | 405.6 | 405.6 | rerun:section7_from_aggregates.py | 405.6 | MATCH |  |
| 1232 | Table C2, Health Care, AIO search | 604.2 | 604.2 | rerun:section7_from_aggregates.py | 604.2 | MATCH |  |
| 1233 | Table C2, Health Care, AIO prompt | 10.1 | 10.1 | rerun:section7_from_aggregates.py | 10.1 | MATCH |  |
| 1234 | Table C2, Health Care, AIM search | 69.8 | 69.8 | rerun:section7_from_aggregates.py | 69.8 | MATCH |  |
| 1235 | Table C2, Health Care, AIM prompt | 16.5 | 16.5 | rerun:section7_from_aggregates.py | 16.5 | MATCH |  |
| 1236 | Table C2, Health Care, ChatGPT | 13.9 | 13.9 | rerun:section7_from_aggregates.py | 13.9 | MATCH |  |
| 1237 | Table C2, Health Care, Perplexity | 8.5 | 8.5 | rerun:section7_from_aggregates.py | 8.5 | MATCH |  |
| 1238 | Table C2, Health Care, Gemini | 7.4 | 7.4 | rerun:section7_from_aggregates.py | 7.4 | MATCH |  |
| 1239 | Table C2, Health Care, Copilot | 20.9 | 20.9 | rerun:section7_from_aggregates.py | 20.9 | MATCH |  |
| 1240 | Table C2, Financials, AIO search | 1,776.8 | 1,776.8 | rerun:section7_from_aggregates.py | 1,776.8 | MATCH |  |
| 1241 | Table C2, Financials, AIO prompt | 78.8 | 78.8 | rerun:section7_from_aggregates.py | 78.8 | MATCH |  |
| 1242 | Table C2, Financials, AIM search | 173.5 | 173.5 | rerun:section7_from_aggregates.py | 173.5 | MATCH |  |
| 1243 | Table C2, Financials, AIM prompt | 97.5 | 97.5 | rerun:section7_from_aggregates.py | 97.5 | MATCH |  |
| 1244 | Table C2, Financials, ChatGPT | 64.4 | 64.4 | rerun:section7_from_aggregates.py | 64.4 | MATCH |  |
| 1245 | Table C2, Financials, Perplexity | 37.4 | 37.4 | rerun:section7_from_aggregates.py | 37.4 | MATCH |  |
| 1246 | Table C2, Financials, Gemini | 45.3 | 45.3 | rerun:section7_from_aggregates.py | 45.3 | MATCH |  |
| 1247 | Table C2, Financials, Copilot | 85.9 | 85.9 | rerun:section7_from_aggregates.py | 85.9 | MATCH |  |
| 1248 | Table C2, Consumer Discretionary, AIO search | 18,381.8 | 18,381.8 | rerun:section7_from_aggregates.py | 18,381.8 | MATCH |  |
| 1249 | Table C2, Consumer Discretionary, AIO prompt | 790.0 | 790.0 | rerun:section7_from_aggregates.py | 790.0 | MATCH |  |
| 1250 | Table C2, Consumer Discretionary, AIM search | 1,752.1 | 1,752.1 | rerun:section7_from_aggregates.py | 1,752.1 | MATCH |  |
| 1251 | Table C2, Consumer Discretionary, AIM prompt | 660.9 | 660.9 | rerun:section7_from_aggregates.py | 660.9 | MATCH |  |
| 1252 | Table C2, Consumer Discretionary, ChatGPT | 347.0 | 347.0 | rerun:section7_from_aggregates.py | 347.0 | MATCH |  |
| 1253 | Table C2, Consumer Discretionary, Perplexity | 441.7 | 441.7 | rerun:section7_from_aggregates.py | 441.7 | MATCH |  |
| 1254 | Table C2, Consumer Discretionary, Gemini | 128.8 | 128.8 | rerun:section7_from_aggregates.py | 128.8 | MATCH |  |
| 1255 | Table C2, Consumer Discretionary, Copilot | 1,581.3 | 1,581.3 | rerun:section7_from_aggregates.py | 1,581.3 | MATCH |  |
| 1256 | Table C2, Communication Services, AIO search | 4,350.7 | 4,350.7 | rerun:section7_from_aggregates.py | 4,350.7 | MATCH |  |
| 1257 | Table C2, Communication Services, AIO prompt | 134.3 | 134.3 | rerun:section7_from_aggregates.py | 134.3 | MATCH |  |
| 1258 | Table C2, Communication Services, AIM search | 591.5 | 591.5 | rerun:section7_from_aggregates.py | 591.5 | MATCH |  |
| 1259 | Table C2, Communication Services, AIM prompt | 163.5 | 163.5 | rerun:section7_from_aggregates.py | 163.5 | MATCH |  |
| 1260 | Table C2, Communication Services, ChatGPT | 150.1 | 150.1 | rerun:section7_from_aggregates.py | 150.1 | MATCH |  |
| 1261 | Table C2, Communication Services, Perplexity | 71.8 | 71.8 | rerun:section7_from_aggregates.py | 71.8 | MATCH |  |
| 1262 | Table C2, Communication Services, Gemini | 76.0 | 76.0 | rerun:section7_from_aggregates.py | 76.0 | MATCH |  |
| 1263 | Table C2, Communication Services, Copilot | 197.9 | 197.9 | rerun:section7_from_aggregates.py | 197.9 | MATCH |  |
| 1264 | Table C2, Industrials, AIO search | 1,223.2 | 1,223.2 | rerun:section7_from_aggregates.py | 1,223.2 | MATCH |  |
| 1265 | Table C2, Industrials, AIO prompt | 52.6 | 52.6 | rerun:section7_from_aggregates.py | 52.6 | MATCH |  |
| 1266 | Table C2, Industrials, AIM search | 112.9 | 112.9 | rerun:section7_from_aggregates.py | 112.9 | MATCH |  |
| 1267 | Table C2, Industrials, AIM prompt | 60.2 | 60.2 | rerun:section7_from_aggregates.py | 60.2 | MATCH |  |
| 1268 | Table C2, Industrials, ChatGPT | 52.6 | 52.6 | rerun:section7_from_aggregates.py | 52.6 | MATCH |  |
| 1269 | Table C2, Industrials, Perplexity | 21.7 | 21.7 | rerun:section7_from_aggregates.py | 21.7 | MATCH |  |
| 1270 | Table C2, Industrials, Gemini | 27.2 | 27.2 | rerun:section7_from_aggregates.py | 27.2 | MATCH |  |
| 1271 | Table C2, Industrials, Copilot | 79.3 | 79.3 | rerun:section7_from_aggregates.py | 79.3 | MATCH |  |
| 1272 | Table C2, Consumer Staples, AIO search | 8,832.0 | 8,832.0 | rerun:section7_from_aggregates.py | 8,832.0 | MATCH |  |
| 1273 | Table C2, Consumer Staples, AIO prompt | 395.4 | 395.4 | rerun:section7_from_aggregates.py | 395.4 | MATCH |  |
| 1274 | Table C2, Consumer Staples, AIM search | 982.3 | 982.3 | rerun:section7_from_aggregates.py | 982.3 | MATCH |  |
| 1275 | Table C2, Consumer Staples, AIM prompt | 446.6 | 446.6 | rerun:section7_from_aggregates.py | 446.6 | MATCH |  |
| 1276 | Table C2, Consumer Staples, ChatGPT | 351.7 | 351.7 | rerun:section7_from_aggregates.py | 351.7 | MATCH |  |
| 1277 | Table C2, Consumer Staples, Perplexity | 215.6 | 215.6 | rerun:section7_from_aggregates.py | 215.6 | MATCH |  |
| 1278 | Table C2, Consumer Staples, Gemini | 149.8 | 149.8 | rerun:section7_from_aggregates.py | 149.8 | MATCH |  |
| 1279 | Table C2, Consumer Staples, Copilot | 1,295.6 | 1,295.6 | rerun:section7_from_aggregates.py | 1,295.6 | MATCH |  |
| 1280 | Table C2, Energy, AIO search | 103.6 | 103.6 | rerun:section7_from_aggregates.py | 103.6 | MATCH |  |
| 1281 | Table C2, Energy, AIO prompt | 3.8 | 3.8 | rerun:section7_from_aggregates.py | 3.8 | MATCH |  |
| 1282 | Table C2, Energy, AIM search | 14.8 | 14.8 | rerun:section7_from_aggregates.py | 14.8 | MATCH |  |
| 1283 | Table C2, Energy, AIM prompt | 5.5 | 5.5 | rerun:section7_from_aggregates.py | 5.5 | MATCH |  |
| 1284 | Table C2, Energy, ChatGPT | 5.1 | 5.1 | rerun:section7_from_aggregates.py | 5.1 | MATCH |  |
| 1285 | Table C2, Energy, Perplexity | 2.0 | 2.0 | rerun:section7_from_aggregates.py | 2.0 | MATCH |  |
| 1286 | Table C2, Energy, Gemini | 2.9 | 2.9 | rerun:section7_from_aggregates.py | 2.9 | MATCH |  |
| 1287 | Table C2, Energy, Copilot | 9.0 | 9.0 | rerun:section7_from_aggregates.py | 9.0 | MATCH |  |
| 1288 | Table C2, Utilities, AIO search | 50.3 | 50.3 | rerun:section7_from_aggregates.py | 50.3 | MATCH |  |
| 1289 | Table C2, Utilities, AIO prompt | 2.1 | 2.1 | rerun:section7_from_aggregates.py | 2.1 | MATCH |  |
| 1290 | Table C2, Utilities, AIM search | 7.2 | 7.2 | rerun:section7_from_aggregates.py | 7.2 | MATCH |  |
| 1291 | Table C2, Utilities, AIM prompt | 2.6 | 2.6 | rerun:section7_from_aggregates.py | 2.6 | MATCH |  |
| 1292 | Table C2, Utilities, ChatGPT | 2.1 | 2.1 | rerun:section7_from_aggregates.py | 2.1 | MATCH |  |
| 1293 | Table C2, Utilities, Perplexity | 0.9 | 0.9 | rerun:section7_from_aggregates.py | 0.9 | MATCH |  |
| 1294 | Table C2, Utilities, Gemini | 1.5 | 1.5 | rerun:section7_from_aggregates.py | 1.5 | MATCH |  |
| 1295 | Table C2, Utilities, Copilot | 3.2 | 3.2 | rerun:section7_from_aggregates.py | 3.2 | MATCH |  |
| 1296 | Table C2, Real Estate, AIO search | 77.9 | 77.9 | rerun:section7_from_aggregates.py | 77.9 | MATCH |  |
| 1297 | Table C2, Real Estate, AIO prompt | 6.4 | 6.4 | rerun:section7_from_aggregates.py | 6.4 | MATCH |  |
| 1298 | Table C2, Real Estate, AIM search | 22.1 | 22.1 | rerun:section7_from_aggregates.py | 22.1 | MATCH |  |
| 1299 | Table C2, Real Estate, AIM prompt | 6.8 | 6.8 | rerun:section7_from_aggregates.py | 6.8 | MATCH |  |
| 1300 | Table C2, Real Estate, ChatGPT | 6.8 | 6.8 | rerun:section7_from_aggregates.py | 6.8 | MATCH |  |
| 1301 | Table C2, Real Estate, Perplexity | 4.4 | 4.4 | rerun:section7_from_aggregates.py | 4.4 | MATCH |  |
| 1302 | Table C2, Real Estate, Gemini | 2.1 | 2.1 | rerun:section7_from_aggregates.py | 2.1 | MATCH |  |
| 1303 | Table C2, Real Estate, Copilot | 6.8 | 6.8 | rerun:section7_from_aggregates.py | 6.8 | MATCH |  |
| 1304 | Table C2, Materials, AIO search | 337.5 | 337.5 | rerun:section7_from_aggregates.py | 337.5 | MATCH |  |
| 1305 | Table C2, Materials, AIO prompt | 15.6 | 15.6 | rerun:section7_from_aggregates.py | 15.6 | MATCH |  |
| 1306 | Table C2, Materials, AIM search | 24.3 | 24.3 | rerun:section7_from_aggregates.py | 24.3 | MATCH |  |
| 1307 | Table C2, Materials, AIM prompt | 17.5 | 17.5 | rerun:section7_from_aggregates.py | 17.5 | MATCH |  |
| 1308 | Table C2, Materials, ChatGPT | 18.5 | 18.5 | rerun:section7_from_aggregates.py | 18.5 | MATCH |  |
| 1309 | Table C2, Materials, Perplexity | 5.6 | 5.6 | rerun:section7_from_aggregates.py | 5.6 | MATCH |  |
| 1310 | Table C2, Materials, Gemini | 6.5 | 6.5 | rerun:section7_from_aggregates.py | 6.5 | MATCH |  |
| 1311 | Table C2, Materials, Copilot | 18.7 | 18.7 | rerun:section7_from_aggregates.py | 18.7 | MATCH |  |
| 1312 | Table C3, Information Technology, AIO search | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1313 | Table C3, Information Technology, AIO prompt | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1314 | Table C3, Information Technology, AIM search | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1315 | Table C3, Information Technology, AIM prompt | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1316 | Table C3, Information Technology, ChatGPT | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1317 | Table C3, Information Technology, Perplexity | wikipedia.org | wikipedia.org | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1318 | Table C3, Information Technology, Gemini | reddit | reddit | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1319 | Table C3, Information Technology, Copilot | walmart | walmart | rerun:make_tables_sector_surface.py | walmart | MATCH |  |
| 1320 | Table C3, Health Care, AIO search | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1321 | Table C3, Health Care, AIO prompt | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1322 | Table C3, Health Care, AIM search | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1323 | Table C3, Health Care, AIM prompt | goodrx | goodrx | rerun:make_tables_sector_surface.py | goodrx | MATCH |  |
| 1324 | Table C3, Health Care, ChatGPT | fda.gov | fda.gov | rerun:make_tables_sector_surface.py | fda.gov | MATCH |  |
| 1325 | Table C3, Health Care, Perplexity | nih.gov | nih.gov | rerun:make_tables_sector_surface.py | nih.gov | MATCH |  |
| 1326 | Table C3, Health Care, Gemini | goodrx | goodrx | rerun:make_tables_sector_surface.py | goodrx | MATCH |  |
| 1327 | Table C3, Health Care, Copilot | msn | msn | rerun:make_tables_sector_surface.py | msn | MATCH |  |
| 1328 | Table C3, Financials, AIO search | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1329 | Table C3, Financials, AIO prompt | reddit | reddit | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1330 | Table C3, Financials, AIM search | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1331 | Table C3, Financials, AIM prompt | nerdwallet | nerdwallet | rerun:make_tables_sector_surface.py | nerdwallet | MATCH |  |
| 1332 | Table C3, Financials, ChatGPT | nerdwallet | nerdwallet | rerun:make_tables_sector_surface.py | nerdwallet | MATCH |  |
| 1333 | Table C3, Financials, Perplexity | nerdwallet | nerdwallet | rerun:make_tables_sector_surface.py | nerdwallet | MATCH |  |
| 1334 | Table C3, Financials, Gemini | wallethub | wallethub | rerun:make_tables_sector_surface.py | wallethub | MATCH |  |
| 1335 | Table C3, Financials, Copilot | wallethub | wallethub | rerun:make_tables_sector_surface.py | wallethub | MATCH |  |
| 1336 | Table C3, Consumer Discretionary, AIO search | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1337 | Table C3, Consumer Discretionary, AIO prompt | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1338 | Table C3, Consumer Discretionary, AIM search | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1339 | Table C3, Consumer Discretionary, AIM prompt | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1340 | Table C3, Consumer Discretionary, ChatGPT | justwatch | justwatch | rerun:make_tables_sector_surface.py | justwatch | MATCH |  |
| 1341 | Table C3, Consumer Discretionary, Perplexity | wikipedia.org | wikipedia.org | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1342 | Table C3, Consumer Discretionary, Gemini | reddit | reddit | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1343 | Table C3, Consumer Discretionary, Copilot | walmart | walmart | rerun:make_tables_sector_surface.py | walmart | MATCH |  |
| 1344 | Table C3, Communication Services, AIO search | youtube† | youtube† | rerun:make_tables_sector_surface.py | youtube† | MATCH |  |
| 1345 | Table C3, Communication Services, AIO prompt | youtube† | youtube† | rerun:make_tables_sector_surface.py | youtube† | MATCH |  |
| 1346 | Table C3, Communication Services, AIM search | google† | google† | rerun:make_tables_sector_surface.py | google† | MATCH |  |
| 1347 | Table C3, Communication Services, AIM prompt | google† | google† | rerun:make_tables_sector_surface.py | google† | MATCH |  |
| 1348 | Table C3, Communication Services, ChatGPT | go† | go† | rerun:make_tables_sector_surface.py | go† | MATCH |  |
| 1349 | Table C3, Communication Services, Perplexity | wikipedia.org | wikipedia.org | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1350 | Table C3, Communication Services, Gemini | reddit | reddit | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1351 | Table C3, Communication Services, Copilot | walmart | walmart | rerun:make_tables_sector_surface.py | walmart | MATCH |  |
| 1352 | Table C3, Industrials, AIO search | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1353 | Table C3, Industrials, AIO prompt | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1354 | Table C3, Industrials, AIM search | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1355 | Table C3, Industrials, AIM prompt | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1356 | Table C3, Industrials, ChatGPT | nvidia | nvidia | rerun:make_tables_sector_surface.py | nvidia | MATCH |  |
| 1357 | Table C3, Industrials, Perplexity | wikipedia.org | wikipedia.org | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1358 | Table C3, Industrials, Gemini | reddit | reddit | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1359 | Table C3, Industrials, Copilot | amazon | amazon | rerun:make_tables_sector_surface.py | amazon | MATCH |  |
| 1360 | Table C3, Consumer Staples, AIO search | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1361 | Table C3, Consumer Staples, AIO prompt | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1362 | Table C3, Consumer Staples, AIM search | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1363 | Table C3, Consumer Staples, AIM prompt | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1364 | Table C3, Consumer Staples, ChatGPT | reddit | reddit | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1365 | Table C3, Consumer Staples, Perplexity | amazon | amazon | rerun:make_tables_sector_surface.py | amazon | MATCH |  |
| 1366 | Table C3, Consumer Staples, Gemini | reddit | reddit | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1367 | Table C3, Consumer Staples, Copilot | amazon | amazon | rerun:make_tables_sector_surface.py | amazon | MATCH |  |
| 1368 | Table C3, Energy, AIO search | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1369 | Table C3, Energy, AIO prompt | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1370 | Table C3, Energy, AIM search | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1371 | Table C3, Energy, AIM prompt | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1372 | Table C3, Energy, ChatGPT | sec.gov | sec.gov | rerun:make_tables_sector_surface.py | sec.gov | MATCH |  |
| 1373 | Table C3, Energy, Perplexity | wikipedia.org | wikipedia.org | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1374 | Table C3, Energy, Gemini | reddit | reddit | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1375 | Table C3, Energy, Copilot | walmart | walmart | rerun:make_tables_sector_surface.py | walmart | MATCH |  |
| 1376 | Table C3, Utilities, AIO search | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1377 | Table C3, Utilities, AIO prompt | reddit | reddit | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1378 | Table C3, Utilities, AIM search | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1379 | Table C3, Utilities, AIM prompt | yahoo | yahoo | rerun:make_tables_sector_surface.py | yahoo | MATCH |  |
| 1380 | Table C3, Utilities, ChatGPT | sec.gov | sec.gov | rerun:make_tables_sector_surface.py | sec.gov | MATCH |  |
| 1381 | Table C3, Utilities, Perplexity | wikipedia.org | wikipedia.org | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1382 | Table C3, Utilities, Gemini | wikipedia.org | wikipedia.org | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1383 | Table C3, Utilities, Copilot | msn | msn | rerun:make_tables_sector_surface.py | msn | MATCH |  |
| 1384 | Table C3, Real Estate, AIO search | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1385 | Table C3, Real Estate, AIO prompt | extraspace | extraspace | rerun:make_tables_sector_surface.py | extraspace | MATCH |  |
| 1386 | Table C3, Real Estate, AIM search | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1387 | Table C3, Real Estate, AIM prompt | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1388 | Table C3, Real Estate, ChatGPT | sec.gov | sec.gov | rerun:make_tables_sector_surface.py | sec.gov | MATCH |  |
| 1389 | Table C3, Real Estate, Perplexity | wikipedia.org | wikipedia.org | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1390 | Table C3, Real Estate, Gemini | wikipedia.org | wikipedia.org | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1391 | Table C3, Real Estate, Copilot | extraspace | extraspace | rerun:make_tables_sector_surface.py | extraspace | MATCH |  |
| 1392 | Table C3, Materials, AIO search | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1393 | Table C3, Materials, AIO prompt | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1394 | Table C3, Materials, AIM search | google | google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1395 | Table C3, Materials, AIM prompt | youtube | youtube | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1396 | Table C3, Materials, ChatGPT | benjaminmoore | benjaminmoore | rerun:make_tables_sector_surface.py | benjaminmoore | MATCH |  |
| 1397 | Table C3, Materials, Perplexity | kylieminteriors.ca | kylieminteriors.ca | rerun:make_tables_sector_surface.py | kylieminteriors.ca | MATCH |  |
| 1398 | Table C3, Materials, Gemini | facadecolorizer | facadecolorizer | rerun:make_tables_sector_surface.py | facadecolorizer | MATCH |  |
| 1399 | Table C3, Materials, Copilot | facadecolorizer | facadecolorizer | rerun:make_tables_sector_surface.py | facadecolorizer | MATCH |  |
| 1400 | Table C4, Information Technology, AI Overviews (search queries), rank 1 | youtube | youtube, reddit, google | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1401 | Table C4, Information Technology, AI Overviews (search queries), rank 2 | reddit | youtube, reddit, google | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1402 | Table C4, Information Technology, AI Overviews (search queries), rank 3 | google | youtube, reddit, google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1403 | Table C4, Information Technology, ChatGPT, rank 1 | google | google, wikipedia.org, justwatch | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1404 | Table C4, Information Technology, ChatGPT, rank 2 | wikipedia.org | google, wikipedia.org, justwatch | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1405 | Table C4, Information Technology, ChatGPT, rank 3 | justwatch | google, wikipedia.org, justwatch | rerun:make_tables_sector_surface.py | justwatch | MATCH |  |
| 1406 | Table C4, Health Care, AI Overviews (search queries), rank 1 | youtube | youtube, nih.gov, wikipedia.org | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1407 | Table C4, Health Care, AI Overviews (search queries), rank 2 | nih.gov | youtube, nih.gov, wikipedia.org | rerun:make_tables_sector_surface.py | nih.gov | MATCH |  |
| 1408 | Table C4, Health Care, AI Overviews (search queries), rank 3 | wikipedia.org | youtube, nih.gov, wikipedia.org | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1409 | Table C4, Health Care, ChatGPT, rank 1 | fda.gov | fda.gov, nih.gov, sec.gov | rerun:make_tables_sector_surface.py | fda.gov | MATCH |  |
| 1410 | Table C4, Health Care, ChatGPT, rank 2 | nih.gov | fda.gov, nih.gov, sec.gov | rerun:make_tables_sector_surface.py | nih.gov | MATCH |  |
| 1411 | Table C4, Health Care, ChatGPT, rank 3 | sec.gov | fda.gov, nih.gov, sec.gov | rerun:make_tables_sector_surface.py | sec.gov | MATCH |  |
| 1412 | Table C4, Financials, AI Overviews (search queries), rank 1 | youtube | youtube, reddit, nerdwallet | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1413 | Table C4, Financials, AI Overviews (search queries), rank 2 | reddit | youtube, reddit, nerdwallet | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1414 | Table C4, Financials, AI Overviews (search queries), rank 3 | nerdwallet | youtube, reddit, nerdwallet | rerun:make_tables_sector_surface.py | nerdwallet | MATCH |  |
| 1415 | Table C4, Financials, ChatGPT, rank 1 | nerdwallet | nerdwallet, chase†, capitalone | rerun:make_tables_sector_surface.py | nerdwallet | MATCH |  |
| 1416 | Table C4, Financials, ChatGPT, rank 2 | chase† | nerdwallet, chase†, capitalone | rerun:make_tables_sector_surface.py | chase† | MATCH |  |
| 1417 | Table C4, Financials, ChatGPT, rank 3 | capitalone | nerdwallet, chase†, capitalone | rerun:make_tables_sector_surface.py | capitalone | MATCH |  |
| 1418 | Table C4, Consumer Discretionary, AI Overviews (search queries), rank 1 | google | google, youtube, reddit | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1419 | Table C4, Consumer Discretionary, AI Overviews (search queries), rank 2 | youtube | google, youtube, reddit | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1420 | Table C4, Consumer Discretionary, AI Overviews (search queries), rank 3 | reddit | google, youtube, reddit | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1421 | Table C4, Consumer Discretionary, ChatGPT, rank 1 | justwatch | justwatch, consumerreports.org, aboutamazon† | rerun:make_tables_sector_surface.py | justwatch | MATCH |  |
| 1422 | Table C4, Consumer Discretionary, ChatGPT, rank 2 | consumerreports.org | justwatch, consumerreports.org, aboutamazon† | rerun:make_tables_sector_surface.py | consumerreports.org | MATCH |  |
| 1423 | Table C4, Consumer Discretionary, ChatGPT, rank 3 | aboutamazon† | justwatch, consumerreports.org, aboutamazon† | rerun:make_tables_sector_surface.py | aboutamazon† | MATCH |  |
| 1424 | Table C4, Communication Services, AI Overviews (search queries), rank 1 | youtube† | youtube†, wikipedia.org, reddit | rerun:make_tables_sector_surface.py | youtube† | MATCH |  |
| 1425 | Table C4, Communication Services, AI Overviews (search queries), rank 2 | wikipedia.org | youtube†, wikipedia.org, reddit | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1426 | Table C4, Communication Services, AI Overviews (search queries), rank 3 | reddit | youtube†, wikipedia.org, reddit | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1427 | Table C4, Communication Services, ChatGPT, rank 1 | go† | go†, justwatch, wikipedia.org | rerun:make_tables_sector_surface.py | go† | MATCH |  |
| 1428 | Table C4, Communication Services, ChatGPT, rank 2 | justwatch | go†, justwatch, wikipedia.org | rerun:make_tables_sector_surface.py | justwatch | MATCH |  |
| 1429 | Table C4, Communication Services, ChatGPT, rank 3 | wikipedia.org | go†, justwatch, wikipedia.org | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1430 | Table C4, Industrials, AI Overviews (search queries), rank 1 | youtube | youtube, reddit, google | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1431 | Table C4, Industrials, AI Overviews (search queries), rank 2 | reddit | youtube, reddit, google | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1432 | Table C4, Industrials, AI Overviews (search queries), rank 3 | google | youtube, reddit, google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1433 | Table C4, Industrials, ChatGPT, rank 1 | nvidia | nvidia, tomshardware, techspot | rerun:make_tables_sector_surface.py | nvidia | MATCH |  |
| 1434 | Table C4, Industrials, ChatGPT, rank 2 | tomshardware | nvidia, tomshardware, techspot | rerun:make_tables_sector_surface.py | tomshardware | MATCH |  |
| 1435 | Table C4, Industrials, ChatGPT, rank 3 | techspot | nvidia, tomshardware, techspot | rerun:make_tables_sector_surface.py | techspot | MATCH |  |
| 1436 | Table C4, Consumer Staples, AI Overviews (search queries), rank 1 | google | google, youtube, amazon | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1437 | Table C4, Consumer Staples, AI Overviews (search queries), rank 2 | youtube | google, youtube, amazon | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1438 | Table C4, Consumer Staples, AI Overviews (search queries), rank 3 | amazon | google, youtube, amazon | rerun:make_tables_sector_surface.py | amazon | MATCH |  |
| 1439 | Table C4, Consumer Staples, ChatGPT, rank 1 | reddit | reddit, wikipedia.org, consumerreports.org | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1440 | Table C4, Consumer Staples, ChatGPT, rank 2 | wikipedia.org | reddit, wikipedia.org, consumerreports.org | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1441 | Table C4, Consumer Staples, ChatGPT, rank 3 | consumerreports.org | reddit, wikipedia.org, consumerreports.org | rerun:make_tables_sector_surface.py | consumerreports.org | MATCH |  |
| 1442 | Table C4, Energy, AI Overviews (search queries), rank 1 | youtube | youtube, wikipedia.org, google | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1443 | Table C4, Energy, AI Overviews (search queries), rank 2 | wikipedia.org | youtube, wikipedia.org, google | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1444 | Table C4, Energy, AI Overviews (search queries), rank 3 | google | youtube, wikipedia.org, google | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1445 | Table C4, Energy, ChatGPT, rank 1 | sec.gov | sec.gov, chevronlubricants†, mobil† | rerun:make_tables_sector_surface.py | sec.gov | MATCH |  |
| 1446 | Table C4, Energy, ChatGPT, rank 2 | chevronlubricants† | sec.gov, chevronlubricants†, mobil† | rerun:make_tables_sector_surface.py | chevronlubricants† | MATCH |  |
| 1447 | Table C4, Energy, ChatGPT, rank 3 | mobil† | sec.gov, chevronlubricants†, mobil† | rerun:make_tables_sector_surface.py | mobil† | MATCH |  |
| 1448 | Table C4, Utilities, AI Overviews (search queries), rank 1 | youtube | youtube, wikipedia.org, reddit | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1449 | Table C4, Utilities, AI Overviews (search queries), rank 2 | wikipedia.org | youtube, wikipedia.org, reddit | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1450 | Table C4, Utilities, AI Overviews (search queries), rank 3 | reddit | youtube, wikipedia.org, reddit | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1451 | Table C4, Utilities, ChatGPT, rank 1 | sec.gov | sec.gov, reuters, stockanalysis | rerun:make_tables_sector_surface.py | sec.gov | MATCH |  |
| 1452 | Table C4, Utilities, ChatGPT, rank 2 | reuters | sec.gov, reuters, stockanalysis | rerun:make_tables_sector_surface.py | reuters | MATCH |  |
| 1453 | Table C4, Utilities, ChatGPT, rank 3 | stockanalysis | sec.gov, reuters, stockanalysis | rerun:make_tables_sector_surface.py | stockanalysis | MATCH |  |
| 1454 | Table C4, Real Estate, AI Overviews (search queries), rank 1 | youtube | youtube, google, wikipedia.org | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1455 | Table C4, Real Estate, AI Overviews (search queries), rank 2 | google | youtube, google, wikipedia.org | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1456 | Table C4, Real Estate, AI Overviews (search queries), rank 3 | wikipedia.org | youtube, google, wikipedia.org | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1457 | Table C4, Real Estate, ChatGPT, rank 1 | sec.gov | sec.gov, extraspace, wikipedia.org | rerun:make_tables_sector_surface.py | sec.gov | MATCH |  |
| 1458 | Table C4, Real Estate, ChatGPT, rank 2 | extraspace | sec.gov, extraspace, wikipedia.org | rerun:make_tables_sector_surface.py | extraspace | MATCH |  |
| 1459 | Table C4, Real Estate, ChatGPT, rank 3 | wikipedia.org | sec.gov, extraspace, wikipedia.org | rerun:make_tables_sector_surface.py | wikipedia.org | MATCH |  |
| 1460 | Table C4, Materials, AI Overviews (search queries), rank 1 | youtube | youtube, google, reddit | rerun:make_tables_sector_surface.py | youtube | MATCH |  |
| 1461 | Table C4, Materials, AI Overviews (search queries), rank 2 | google | youtube, google, reddit | rerun:make_tables_sector_surface.py | google | MATCH |  |
| 1462 | Table C4, Materials, AI Overviews (search queries), rank 3 | reddit | youtube, google, reddit | rerun:make_tables_sector_surface.py | reddit | MATCH |  |
| 1463 | Table C4, Materials, ChatGPT, rank 1 | benjaminmoore | benjaminmoore, behr, plan-home | rerun:make_tables_sector_surface.py | benjaminmoore | MATCH |  |
| 1464 | Table C4, Materials, ChatGPT, rank 2 | behr | benjaminmoore, behr, plan-home | rerun:make_tables_sector_surface.py | behr | MATCH |  |
| 1465 | Table C4, Materials, ChatGPT, rank 3 | plan-home | benjaminmoore, behr, plan-home | rerun:make_tables_sector_surface.py | plan-home | MATCH |  |
| 1466 | Appendix C after Table C4 | 38 | the top source is youtube.com or google.com in 38 of the 44 sector-... | rerun:make_tables_sector_surface.py | 38 | MATCH |  |
| 1467 | Appendix C after Table C4 | 4 | four of them Alphabet's own properties in Communication Services | rerun:make_tables_sector_surface.py | 4 | MATCH |  |
| 1468 | Appendix C after Table C4 | 15 | On Perplexity and Gemini it is wikipedia.org or reddit.com in 15 of 22 | rerun:make_tables_sector_surface.py | 15 | MATCH |  |
| 1469 | Appendix C after Table C4 | 4 | on ChatGPT a government domain in 4 of 11 sectors | rerun:make_tables_sector_surface.py | 4 | MATCH |  |
| 1470 | Appendix C after Table C4 | 6 | and on Copilot a retailer (walmart.com or amazon.com) in 6 of 11 | rerun:make_tables_sector_surface.py | 6 | MATCH |  |
| 1471 | Appendix D Table D1 | 456 | \| 456; 86% (read 14 October 2026) \| `vendor_reliance` \| | rerun:vendor_reliance.py --offline | 456 | MATCH |  |
| 1472 | Appendix D Table D1 | 86% | \| 456; 86% (read 14 October 2026) \| `vendor_reliance` \| | rerun:vendor_reliance.py --offline | 86 | MATCH |  |
| 1473 | Appendix D Table D1 | 7.5x | \| 7.5x to 27.1x; 8.6x to 29.9x; 9.2x to 33.3x \| arithmetic on Tab... | arith:Table 2 values | 7.46965 | MATCH |  |
| 1474 | Appendix D Table D1 | 27.1x | \| 7.5x to 27.1x; 8.6x to 29.9x; 9.2x to 33.3x \| arithmetic on Tab... | arith:Table 2 values | 27.1414 | MATCH |  |
| 1475 | Appendix D Table D1 | 8.6x | \| 7.5x to 27.1x; 8.6x to 29.9x; 9.2x to 33.3x \| arithmetic on Tab... | arith:Table 2 values | 8.62011 | MATCH |  |
| 1476 | Appendix D Table D1 | 29.9x | \| 7.5x to 27.1x; 8.6x to 29.9x; 9.2x to 33.3x \| arithmetic on Tab... | arith:Table 2 values | 29.8608 | MATCH |  |
| 1477 | Appendix D Table D1 | 9.2x | \| 7.5x to 27.1x; 8.6x to 29.9x; 9.2x to 33.3x \| arithmetic on Tab... | arith:Table 2 values | 9.16521 | MATCH |  |
| 1478 | Appendix D Table D1 | 33.3x | \| 7.5x to 27.1x; 8.6x to 29.9x; 9.2x to 33.3x \| arithmetic on Tab... | arith:Table 2 values | 33.3024 | MATCH |  |
| 1479 | Appendix D Table D1 | 0.95 | \| 0.95, 2.66, 1.37 \| `instrument_extra` \| | rerun:instrument_extra.py | 0.95 | MATCH |  |
| 1480 | Appendix D Table D1 | 2.66 | \| 0.95, 2.66, 1.37 \| `instrument_extra` \| | rerun:instrument_extra.py | 2.66 | MATCH |  |
| 1481 | Appendix D Table D1 | 1.37 | \| 0.95, 2.66, 1.37 \| `instrument_extra` \| | rerun:instrument_extra.py | 1.37 | MATCH |  |
| 1482 | Appendix D Table D1 | 5.2 | \| 5.2 at 27.1x \| arithmetic on Table 2 \| | arith:Table 2 values | 5.20975 | MATCH |  |
| 1483 | Appendix D Table D1 | 35% | \| 35% (US pairing), 54% (worldwide) \| `instrument_extra` \| | rerun:instrument_extra.py | 35 | MATCH |  |
| 1484 | Appendix D Table D1 | 54% | \| 35% (US pairing), 54% (worldwide) \| `instrument_extra` \| | rerun:instrument_extra.py | 54 | MATCH |  |
| 1485 | Appendix D Table D1 | 0.20x | \| 0.20x to 7.24x (8.89x matched); median 1.01 \| `analyze` \| | rerun:analyze.py | 0.20 | MATCH |  |
| 1486 | Appendix D Table D1 | 7.24x | \| 0.20x to 7.24x (8.89x matched); median 1.01 \| `analyze` \| | rerun:analyze.py | 7.24 | MATCH |  |
| 1487 | Appendix D Table D1 | 8.89x | \| 0.20x to 7.24x (8.89x matched); median 1.01 \| `analyze` \| | rerun:analyze.py | 8.89 | MATCH |  |
| 1488 | Appendix D Table D1 | 1.01 | \| 0.20x to 7.24x (8.89x matched); median 1.01 \| `analyze` \| | rerun:analyze.py | 1.01 | MATCH |  |
| 1489 | Appendix D Table D1 | −0.11 | \| −0.11 [−0.64, +0.49], p = 0.73 \| `analyze` \| | rerun:analyze.py | -0.11 | MATCH |  |
| 1490 | Appendix D Table D1 | −0.64 | \| −0.11 [−0.64, +0.49], p = 0.73 \| `analyze` \| | rerun:analyze.py | -0.64 | MATCH |  |
| 1491 | Appendix D Table D1 | +0.49 | \| −0.11 [−0.64, +0.49], p = 0.73 \| `analyze` \| | rerun:analyze.py | +0.49 | MATCH |  |
| 1492 | Appendix D Table D1 | 0.73 | \| −0.11 [−0.64, +0.49], p = 0.73 \| `analyze` \| | rerun:analyze.py | 0.73 | MATCH |  |
| 1493 | Appendix D Table D1 | +0.94 | \| +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within \| | rerun:analyze.py | +0.94 | MATCH |  |
| 1494 | Appendix D Table D1 | +0.82 | \| +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within \| | rerun:analyze.py | +0.82 | MATCH |  |
| 1495 | Appendix D Table D1 | 60 of 66 | \| +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within \| | rerun:analyze.py | 60 of 66 | MATCH |  |
| 1496 | Appendix D Table D1 | 51 of 51 | \| +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within \| | rerun:instrument_extra.py | 51 of 51 | MATCH |  |
| 1497 | Appendix D Table D1 | 9 of 15 | \| +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within \| | rerun:instrument_extra.py | 9 of 15 | MATCH |  |
| 1498 | Appendix D Table D1 | 1.13 | \| 1.13 and 3.1 \| `instrument_extra` \| | rerun:instrument_extra.py | 1.13 | MATCH |  |
| 1499 | Appendix D Table D1 | 3.1 | \| 1.13 and 3.1 \| `instrument_extra` \| | rerun:instrument_extra.py | 3.13 | MATCH |  |
| 1500 | Appendix D Table D1 | 12.6% | \| 12.6% to 20.0% \| arithmetic on Table 3 \| | arith:Table 3 counts | 12.6093 | MATCH |  |
| 1501 | Appendix D Table D1 | 20.0% | \| 12.6% to 20.0% \| arithmetic on Table 3 \| | arith:Table 3 counts | 20.0199 | MATCH |  |
| 1502 | Appendix D Table D1 | 55.6% | \| 55.6%; 2.25 \| `analyze_reviews` \| | shipped:analyze_reviews_output.txt | 55.6 | CANNOT RUN | paper agrees with the saved output |
| 1503 | Appendix D Table D1 | 2.25 | \| 55.6%; 2.25 \| `analyze_reviews` \| | shipped:analyze_reviews_output.txt | 2.25 | CANNOT RUN | paper agrees with the saved output |
| 1504 | Appendix D Table D1 | +0.19 | \| +0.19 (mentioned), +0.27 (all linkable) \| | rerun:m2_from_counts.py (full precision via checks/m2_precise.py) | 0.184869 | MISMATCH | prints +0.185; the full value 0.184869 is +0.18 to two decimals (double rounding) |
| 1505 | Appendix D Table D1 | +0.27 | \| +0.19 (mentioned), +0.27 (all linkable) \| | rerun:m2_from_counts.py | +0.273 | MATCH |  |
| 1506 | Appendix D Table D1 | +0.47 | \| +0.47 (modal), +0.75 (split) \| | rerun:m2_from_counts.py | +0.468 | MATCH |  |
| 1507 | Appendix D Table D1 | +0.75 | \| +0.47 (modal), +0.75 (split) \| | rerun:m2_from_counts.py | +0.748 | MATCH |  |
| 1508 | Appendix D Table D1 | 14.0% | \| 14.0% against 1.9% \| `analyze_reviews` \| | shipped:analyze_reviews_output.txt | 14.0 | CANNOT RUN | paper agrees with the saved output |
| 1509 | Appendix D Table D1 | 1.9% | \| 14.0% against 1.9% \| `analyze_reviews` \| | shipped:analyze_reviews_output.txt | 1.9 | CANNOT RUN | paper agrees with the saved output |
| 1510 | Appendix D Table D1 | 65% | \| 65% to 67%; kappa 0.90 (single-word labels about 50%, multi-word... | rerun:r2_link_check.py | 65 | MATCH |  |
| 1511 | Appendix D Table D1 | 67% | \| 65% to 67%; kappa 0.90 (single-word labels about 50%, multi-word... | rerun:r2_link_check.py | 66.8 | MATCH |  |
| 1512 | Appendix D Table D1 | 0.90 | \| 65% to 67%; kappa 0.90 (single-word labels about 50%, multi-word... | rerun:r2_link_check.py | 0.90 | MATCH |  |
| 1513 | Appendix D Table D1 | about 50% | \| 65% to 67%; kappa 0.90 (single-word labels about 50%, multi-word... | rerun:r2_link_check.py | 50.0% and 48.0% | MATCH |  |
| 1514 | Appendix D Table D1 | 95% | \| 65% to 67%; kappa 0.90 (single-word labels about 50%, multi-word... | rerun:r2_link_check.py | 94.5 | MATCH |  |
| 1515 | Appendix D Table D1 | 96% | \| 65% to 67%; kappa 0.90 (single-word labels about 50%, multi-word... | rerun:r2_link_check.py | 95.8 | MATCH |  |
| 1516 | Appendix D Table D1 | 83% | \| 83% to 85%, kappa 0.93; about 90% in store \| | rerun:r2_link_check.py | 83 | MATCH |  |
| 1517 | Appendix D Table D1 | 85% | \| 83% to 85%, kappa 0.93; about 90% in store \| | rerun:r2_link_check.py | 84.8 | MATCH |  |
| 1518 | Appendix D Table D1 | 0.93 | \| 83% to 85%, kappa 0.93; about 90% in store \| | rerun:r2_link_check.py | 0.93 | MATCH |  |
| 1519 | Appendix D Table D1 | about 90% | \| 83% to 85%, kappa 0.93; about 90% in store \| | rerun:r2_link_check.py | 90.5% and 89.2% | MATCH |  |
| 1520 | Appendix D Table D1 | 21.3% | \| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) \| `cross_sector_... | rerun:section7_from_aggregates.py | 21.3 | MATCH | also in cross_sector_sensitivity_output.txt (shipped) |
| 1521 | Appendix D Table D1 | 17.2 | \| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) \| `cross_sector_... | rerun:section7_from_aggregates.py | 17.2 | MATCH |  |
| 1522 | Appendix D Table D1 | 26.7 | \| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) \| `cross_sector_... | rerun:section7_from_aggregates.py | 26.7 | MATCH |  |
| 1523 | Appendix D Table D1 | 2.1% | \| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) \| `cross_sector_... | rerun:section7_from_aggregates.py | 2.1 | MATCH |  |
| 1524 | Appendix D Table D1 | 1.7 | \| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) \| `cross_sector_... | rerun:section7_from_aggregates.py | 1.7 | MATCH |  |
| 1525 | Appendix D Table D1 | 2.7 | \| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) \| `cross_sector_... | rerun:section7_from_aggregates.py | 2.7 | MATCH |  |
| 1526 | Appendix D Table D1 | 11 of 11 | \| 11 of 11 \| `cross_sector_sensitivity` \| | rerun:section7_from_aggregates.py | 11/11 | MATCH |  |
| 1527 | Appendix D Table D1 | 0.36 | \| 0.36 to 0.40 against 0.08 to 0.23 \| `cross_sector` \| | rerun:section7_from_aggregates.py | 0.36 | MATCH |  |
| 1528 | Appendix D Table D1 | 0.40 | \| 0.36 to 0.40 against 0.08 to 0.23 \| `cross_sector` \| | rerun:section7_from_aggregates.py | 0.4 | MATCH |  |
| 1529 | Appendix D Table D1 | 0.08 | \| 0.36 to 0.40 against 0.08 to 0.23 \| `cross_sector` \| | rerun:section7_from_aggregates.py | 0.08 | MATCH |  |
| 1530 | Appendix D Table D1 | 0.23 | \| 0.36 to 0.40 against 0.08 to 0.23 \| `cross_sector` \| | rerun:section7_from_aggregates.py | 0.23 | MATCH |  |
| 1531 | Appendix D Table D1 | 77% | \| 77% against 14% (video and community) \| `cross_sector_sensitivi... | rerun:section7_from_aggregates.py | 77 | MATCH |  |
| 1532 | Appendix D Table D1 | 14% | \| 77% against 14% (video and community) \| `cross_sector_sensitivi... | rerun:section7_from_aggregates.py | 14 | MATCH |  |
| 1533 | Appendix D Table D1 | 1, 1, 2 | \| one held, one in direction, two failed \| `cross_sector` \| | rerun:section7_from_aggregates.py | 1 held, 1 held in direction only, 2 failed | MATCH |  |
| 1534 | Appendix D Table D1 | 4/5 | \| 4/5 (released example) \| `ufi cq` \| | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1535 | Appendix D Table D1 | 70.4% | \| 70.4% (released example) \| `ufi cq` \| | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1536 | Figure 2 (fig1_divergence), July, Ahrefs | 3,862 | ![Figure 2. | figure:make_figs_v4.py | 3862 | MATCH | drawn value against the released Table 2 CSV |
| 1537 | Figure 2 (fig1_divergence), July, Semrush US | 100,012 | ![Figure 2. | figure:make_figs_v4.py | 100012 | MATCH |  |
| 1538 | Figure 2 (fig1_divergence), July, Semrush worldwide | 103,045 | ![Figure 2. | figure:make_figs_v4.py | 103045 | MATCH |  |
| 1539 | Figure 2 (fig1_divergence), August, Ahrefs | 32,281 | ![Figure 2. | figure:make_figs_v4.py | 32281 | MATCH | drawn value against the released Table 2 CSV |
| 1540 | Figure 2 (fig1_divergence), August, Semrush US | 876,153 | ![Figure 2. | figure:make_figs_v4.py | 876153 | MATCH |  |
| 1541 | Figure 2 (fig1_divergence), August, Semrush worldwide | 963,937 | ![Figure 2. | figure:make_figs_v4.py | 963937 | MATCH |  |
| 1542 | Figure 2 (fig1_divergence), September, Ahrefs | 150,113 | ![Figure 2. | figure:make_figs_v4.py | 150113 | MATCH | drawn value against the released Table 2 CSV |
| 1543 | Figure 2 (fig1_divergence), September, Semrush US | 1,534,362 | ![Figure 2. | figure:make_figs_v4.py | 1.53436e+06 | MATCH |  |
| 1544 | Figure 2 (fig1_divergence), September, Semrush worldwide | 1,765,077 | ![Figure 2. | figure:make_figs_v4.py | 1.76508e+06 | MATCH |  |
| 1545 | Figure 2 (fig1_divergence), October, Ahrefs | 215,577 | ![Figure 2. | figure:make_figs_v4.py | 215577 | MATCH | drawn value against the released Table 2 CSV |
| 1546 | Figure 2 (fig1_divergence), October, Semrush US | 1,610,284 | ![Figure 2. | figure:make_figs_v4.py | 1.61028e+06 | MATCH |  |
| 1547 | Figure 2 (fig1_divergence), October, Semrush worldwide | 1,858,297 | ![Figure 2. | figure:make_figs_v4.py | 1.8583e+06 | MATCH |  |
| 1548 | Figure 2 (fig1_divergence), July, ratio label | 25.9x | ![Figure 2. | figure:make_figs_v4.py | 25.8964 | MATCH |  |
| 1549 | Figure 2 (fig1_divergence), August, ratio label | 27.1x | ![Figure 2. | figure:make_figs_v4.py | 27.1414 | MATCH |  |
| 1550 | Figure 2 (fig1_divergence), September, ratio label | 10.2x | ![Figure 2. | figure:make_figs_v4.py | 10.2214 | MATCH |  |
| 1551 | Figure 2 (fig1_divergence), October, ratio label | 7.5x | ![Figure 2. | figure:make_figs_v4.py | 7.46965 | MATCH |  |
| 1552 | Figure 3 (fig2_aio), July, numerator | 47 | ![Figure 3. | figure:make_figs_v4.py | 47 | MATCH |  |
| 1553 | Figure 3 (fig2_aio), July, denominator | 284 | ![Figure 3. | figure:make_figs_v4.py | 284 | MATCH |  |
| 1554 | Figure 3 (fig2_aio), July, Semrush count | 138 | ![Figure 3. | figure:make_figs_v4.py | 138 | MATCH |  |
| 1555 | Figure 3 (fig2_aio), August, numerator | 851 | ![Figure 3. | figure:make_figs_v4.py | 851 | MATCH |  |
| 1556 | Figure 3 (fig2_aio), August, denominator | 6,749 | ![Figure 3. | figure:make_figs_v4.py | 6749 | MATCH |  |
| 1557 | Figure 3 (fig2_aio), August, Semrush count | 2,221 | ![Figure 3. | figure:make_figs_v4.py | 2221 | MATCH |  |
| 1558 | Figure 3 (fig2_aio), September, numerator | 3,380 | ![Figure 3. | figure:make_figs_v4.py | 3380 | MATCH |  |
| 1559 | Figure 3 (fig2_aio), September, denominator | 22,665 | ![Figure 3. | figure:make_figs_v4.py | 22665 | MATCH |  |
| 1560 | Figure 3 (fig2_aio), September, Semrush count | 8,187 | ![Figure 3. | figure:make_figs_v4.py | 8187 | MATCH |  |
| 1561 | Figure 3 (fig2_aio), October, numerator | 7,455 | ![Figure 3. | figure:make_figs_v4.py | 7455 | MATCH |  |
| 1562 | Figure 3 (fig2_aio), October, denominator | 37,238 | ![Figure 3. | figure:make_figs_v4.py | 37238 | MATCH |  |
| 1563 | Figure 3 (fig2_aio), October, Semrush count | 10,018 | ![Figure 3. | figure:make_figs_v4.py | 10018 | MATCH |  |
| 1564 | Figure 3 (fig2_aio), July, ratio label | 2.94x | ![Figure 3. | figure:make_figs_v4.py | 2.93617 | MATCH |  |
| 1565 | Figure 3 (fig2_aio), August, ratio label | 2.61x | ![Figure 3. | figure:make_figs_v4.py | 2.60987 | MATCH |  |
| 1566 | Figure 3 (fig2_aio), September, ratio label | 2.42x | ![Figure 3. | figure:make_figs_v4.py | 2.42219 | MATCH |  |
| 1567 | Figure 3 (fig2_aio), October, ratio label | 1.34x | ![Figure 3. | figure:make_figs_v4.py | 1.3438 | MATCH |  |
| 1568 | Figure 4 (fig3_refdomains), Ahrefs domains | 913 | ![Figure 4. | figure:make_figs_v4.py | 913 | MATCH |  |
| 1569 | Figure 4 (fig3_refdomains), Semrush domains | 80 | ![Figure 4. | figure:make_figs_v4.py | 80 | MATCH |  |
| 1570 | Figure 4 (fig3_refdomains), Ahrefs .info | 61.9% | ![Figure 4. | figure:make_figs_v4.py | 61.9% | MATCH |  |
| 1571 | Figure 4 (fig3_refdomains), Ahrefs .asia | 26.4% | ![Figure 4. | figure:make_figs_v4.py | 26.4% | MATCH |  |
| 1572 | Figure 4 (fig3_refdomains), Ahrefs .xyz | 10.2% | ![Figure 4. | figure:make_figs_v4.py | 10.2% | MATCH |  |
| 1573 | Figure 4 (fig3_refdomains), Ahrefs other | 1.5% | ![Figure 4. | figure:make_figs_v4.py | 1.5 | MATCH | remainder of the three read shares |
| 1574 | Figure 4 (fig3_refdomains), Semrush .xyz | 75.0% | ![Figure 4. | figure:make_figs_v4.py | 75% | MATCH |  |
| 1575 | Figure 5 (fig4_prefixes), /local/area-codes/, age | 3 | ![Figure 5. | figure:make_figs_v4.py | 3 | MATCH |  |
| 1576 | Figure 5 (fig4_prefixes), /local/area-codes/, visits ratio | 7.24 | ![Figure 5. | figure:make_figs_v4.py | 7.23982 | MATCH |  |
| 1577 | Figure 5 (fig4_prefixes), /local/area-codes/, keyword ratio | 2.0 | ![Figure 5. | figure:make_figs_v4.py | 2.04152 | MATCH |  |
| 1578 | Figure 5 (fig4_prefixes), /product-compare/, age | 21 | ![Figure 5. | figure:make_figs_v4.py | 21 | MATCH |  |
| 1579 | Figure 5 (fig4_prefixes), /product-compare/, visits ratio | 0.75 | ![Figure 5. | figure:make_figs_v4.py | 0.745455 | MATCH |  |
| 1580 | Figure 5 (fig4_prefixes), /product-compare/, keyword ratio | 3.2 | ![Figure 5. | figure:make_figs_v4.py | 3.21229 | MATCH |  |
| 1581 | Figure 5 (fig4_prefixes), /local/bundles/, age | 36 | ![Figure 5. | figure:make_figs_v4.py | 36 | MATCH |  |
| 1582 | Figure 5 (fig4_prefixes), /local/bundles/, visits ratio | 0.20 | ![Figure 5. | figure:make_figs_v4.py | 0.203125 | MATCH |  |
| 1583 | Figure 5 (fig4_prefixes), /local/bundles/, keyword ratio | 16.1 | ![Figure 5. | figure:make_figs_v4.py | 16.0952 | MATCH |  |
| 1584 | Figure 5 (fig4_prefixes), /device-compare/, age | 39 | ![Figure 5. | figure:make_figs_v4.py | 39 | MATCH |  |
| 1585 | Figure 5 (fig4_prefixes), /device-compare/, visits ratio | 0.99 | ![Figure 5. | figure:make_figs_v4.py | 0.988764 | MATCH |  |
| 1586 | Figure 5 (fig4_prefixes), /device-compare/, keyword ratio | 5.2 | ![Figure 5. | figure:make_figs_v4.py | 5.25 | MATCH |  |
| 1587 | Figure 5 (fig4_prefixes), /local/cell-phones/, age | 57 | ![Figure 5. | figure:make_figs_v4.py | 57 | MATCH |  |
| 1588 | Figure 5 (fig4_prefixes), /local/cell-phones/, visits ratio | 3.62 | ![Figure 5. | figure:make_figs_v4.py | 3.62198 | MATCH |  |
| 1589 | Figure 5 (fig4_prefixes), /local/cell-phones/, keyword ratio | 10.4 | ![Figure 5. | figure:make_figs_v4.py | 10.4167 | MATCH |  |
| 1590 | Figure 5 (fig4_prefixes), /support/, age | 93 | ![Figure 5. | figure:make_figs_v4.py | 93 | MATCH |  |
| 1591 | Figure 5 (fig4_prefixes), /support/, visits ratio | 1.03 | ![Figure 5. | figure:make_figs_v4.py | 1.03046 | MATCH |  |
| 1592 | Figure 5 (fig4_prefixes), /support/, keyword ratio | 9.1 | ![Figure 5. | figure:make_figs_v4.py | 9.09183 | MATCH |  |
| 1593 | Figure 5 (fig4_prefixes), /local/fiber/, age | 95 | ![Figure 5. | figure:make_figs_v4.py | 95 | MATCH |  |
| 1594 | Figure 5 (fig4_prefixes), /local/fiber/, visits ratio | 0.46 | ![Figure 5. | figure:make_figs_v4.py | 0.463725 | MATCH |  |
| 1595 | Figure 5 (fig4_prefixes), /local/fiber/, keyword ratio | 5.9 | ![Figure 5. | figure:make_figs_v4.py | 5.90741 | MATCH |  |
| 1596 | Figure 5 (fig4_prefixes), /buy/, age | 95 | ![Figure 5. | figure:make_figs_v4.py | 95 | MATCH |  |
| 1597 | Figure 5 (fig4_prefixes), /buy/, visits ratio | 1.57 | ![Figure 5. | figure:make_figs_v4.py | 1.57473 | MATCH |  |
| 1598 | Figure 5 (fig4_prefixes), /buy/, keyword ratio | 10.4 | ![Figure 5. | figure:make_figs_v4.py | 10.4225 | MATCH |  |
| 1599 | Figure 5 (fig4_prefixes), /local/internet/, age | 114 | ![Figure 5. | figure:make_figs_v4.py | 114 | MATCH |  |
| 1600 | Figure 5 (fig4_prefixes), /local/internet/, visits ratio | 0.91 | ![Figure 5. | figure:make_figs_v4.py | 0.907819 | MATCH |  |
| 1601 | Figure 5 (fig4_prefixes), /local/internet/, keyword ratio | 6.0 | ![Figure 5. | figure:make_figs_v4.py | 5.99248 | MATCH |  |
| 1602 | Figure 5 (fig4_prefixes), /stores/, age | 129 | ![Figure 5. | figure:make_figs_v4.py | 129 | MATCH |  |
| 1603 | Figure 5 (fig4_prefixes), /stores/, visits ratio | 6.57 | ![Figure 5. | figure:make_figs_v4.py | 6.57458 | MATCH |  |
| 1604 | Figure 5 (fig4_prefixes), /stores/, keyword ratio | 20.9 | ![Figure 5. | figure:make_figs_v4.py | 20.8811 | MATCH |  |
| 1605 | Figure 5 (fig4_prefixes), /deals/, age | 132 | ![Figure 5. | figure:make_figs_v4.py | 132 | MATCH |  |
| 1606 | Figure 5 (fig4_prefixes), /deals/, visits ratio | 1.03 | ![Figure 5. | figure:make_figs_v4.py | 1.02617 | MATCH |  |
| 1607 | Figure 5 (fig4_prefixes), /deals/, keyword ratio | 6.0 | ![Figure 5. | figure:make_figs_v4.py | 6.03774 | MATCH |  |
| 1608 | Figure 5 (fig4_prefixes), /es-us/local/, age | 133 | ![Figure 5. | figure:make_figs_v4.py | 133 | MATCH |  |
| 1609 | Figure 5 (fig4_prefixes), /es-us/local/, visits ratio | 0.25 | ![Figure 5. | figure:make_figs_v4.py | 0.247191 | MATCH |  |
| 1610 | Figure 5 (fig4_prefixes), /es-us/local/, keyword ratio | 3.7 | ![Figure 5. | figure:make_figs_v4.py | 3.69231 | MATCH |  |
| 1611 | Figure 5 (fig4_prefixes), panel (a) title | −0.11 | ![Figure 5. | figure:make_figs_v4.py | -0.11 | MATCH | title text 'Spearman ρ = −0.11' |
| 1612 | Figure 8 (fig5_cited), New York hub | 474 | ![Figure 8. | figure:make_figs_v4.py | 474 | MATCH |  |
| 1613 | Figure 8 (fig5_cited), California hub | 337 | ![Figure 8. | figure:make_figs_v4.py | 337 | MATCH |  |
| 1614 | Figure 8 (fig5_cited), Texas hub | 322 | ![Figure 8. | figure:make_figs_v4.py | 322 | MATCH |  |
| 1615 | Figure 8 (fig5_cited), Florida hub | 304 | ![Figure 8. | figure:make_figs_v4.py | 304 | MATCH |  |
| 1616 | Figure 8 (fig5_cited), national hub | 294 | ![Figure 8. | figure:make_figs_v4.py | 294 | MATCH |  |
| 1617 | Figure 8 (fig5_cited), 214 (Dallas) code page | 238 | ![Figure 8. | figure:make_figs_v4.py | 238 | MATCH |  |
| 1618 | Figure 8 (fig5_cited), 786 (Miami) code page | 228 | ![Figure 8. | figure:make_figs_v4.py | 228 | MATCH |  |
| 1619 | Figure 8 (fig5_cited), 404 (Atlanta) code page | 218 | ![Figure 8. | figure:make_figs_v4.py | 218 | MATCH |  |
| 1620 | Figure 9 (fig6_positions), day 0, positions | 2 | ![Figure 9. | figure:make_figs_v4.py | 2 | MATCH |  |
| 1621 | Figure 9 (fig6_positions), day 0, positions 1-3 | 0 | ![Figure 9. | figure:make_figs_v4.py | 0 | MATCH |  |
| 1622 | Figure 9 (fig6_positions), day 6, positions | 984 | ![Figure 9. | figure:make_figs_v4.py | 984 | MATCH |  |
| 1623 | Figure 9 (fig6_positions), day 6, positions 1-3 | 186 | ![Figure 9. | figure:make_figs_v4.py | 186 | MATCH |  |
| 1624 | Figure 9 (fig6_positions), day 15, positions | 3,385 | ![Figure 9. | figure:make_figs_v4.py | 3,385 | MATCH |  |
| 1625 | Figure 9 (fig6_positions), day 15, positions 1-3 | 727 | ![Figure 9. | figure:make_figs_v4.py | 727 | MATCH |  |
| 1626 | Figure 9 (fig6_positions), day 30, positions | 14,905 | ![Figure 9. | figure:make_figs_v4.py | 14,905 | MATCH |  |
| 1627 | Figure 9 (fig6_positions), day 30, positions 1-3 | 1,801 | ![Figure 9. | figure:make_figs_v4.py | 1,801 | MATCH |  |
| 1628 | Figure 9 (fig6_positions), day 37, positions | 15,830 | ![Figure 9. | figure:make_figs_v4.py | 15,830 | MATCH |  |
| 1629 | Figure 9 (fig6_positions), day 37, positions 1-3 | 1,874 | ![Figure 9. | figure:make_figs_v4.py | 1,874 | MATCH |  |
| 1630 | Figure 9 (fig6_positions), day 45, positions | 20,326 | ![Figure 9. | figure:make_figs_v4.py | 20,326 | MATCH |  |
| 1631 | Figure 9 (fig6_positions), day 45, positions 1-3 | 2,649 | ![Figure 9. | figure:make_figs_v4.py | 2,649 | MATCH |  |
| 1632 | Figure 9 (fig6_positions), day 60, positions | 37,141 | ![Figure 9. | figure:make_figs_v4.py | 37,141 | MATCH |  |
| 1633 | Figure 9 (fig6_positions), day 60, positions 1-3 | 5,822 | ![Figure 9. | figure:make_figs_v4.py | 5,822 | MATCH |  |
| 1634 | Figure 9 (fig6_positions), day 67, positions | 38,801 | ![Figure 9. | figure:make_figs_v4.py | 38,801 | MATCH |  |
| 1635 | Figure 9 (fig6_positions), day 67, positions 1-3 | 6,942 | ![Figure 9. | figure:make_figs_v4.py | 6,942 | MATCH |  |
| 1636 | Figure 9 (fig6_positions), day 75, positions | 43,302 | ![Figure 9. | figure:make_figs_v4.py | 43,302 | MATCH |  |
| 1637 | Figure 9 (fig6_positions), day 75, positions 1-3 | 8,753 | ![Figure 9. | figure:make_figs_v4.py | 8,753 | MATCH |  |
| 1638 | Figure 9 (fig6_positions), day 77, positions | 43,980 | ![Figure 9. | figure:make_figs_v4.py | 43,980 | MATCH |  |
| 1639 | Figure 9 (fig6_positions), day 77, positions 1-3 | 9,239 | ![Figure 9. | figure:make_figs_v4.py | 9,239 | MATCH |  |
| 1640 | Figure 9 (fig6_positions), referring domains at day 30 | 19 | ![Figure 9. | figure:make_figs_v4.py | 19 | MATCH |  |
| 1641 | Figure 9 (fig6_positions), referring domains at day 37 | 19 | ![Figure 9. | figure:make_figs_v4.py | 19 | MATCH |  |
| 1642 | Figure 9 (fig6_positions), referring domains at day 45 | 415 | ![Figure 9. | figure:make_figs_v4.py | 415 | MATCH |  |
| 1643 | Figure 9 (fig6_positions), referring domains at day 60 | 828 | ![Figure 9. | figure:make_figs_v4.py | 828 | MATCH |  |
| 1644 | Figure 9 (fig6_positions), referring domains at day 75 | 909 | ![Figure 9. | figure:make_figs_v4.py | 909 | MATCH |  |
| 1645 | Figure 9 (fig6_positions), rate days 0 to 15 | 226 | ![Figure 9. | figure:make_figs_v4.py | 226 | MATCH |  |
| 1646 | Figure 9 (fig6_positions), rate days 15 to 30 | 768 | ![Figure 9. | figure:make_figs_v4.py | 768 | MATCH |  |
| 1647 | Figure 9 (fig6_positions), rate days 30 to 37 | 132 | ![Figure 9. | figure:make_figs_v4.py | 132 | MATCH |  |
| 1648 | Figure 9 (fig6_positions), rate days 37 to 45 | 562 | ![Figure 9. | figure:make_figs_v4.py | 562 | MATCH |  |
| 1649 | Figure 9 (fig6_positions), rate days 45 to 60 | 1121 | ![Figure 9. | figure:make_figs_v4.py | 1121 | MATCH |  |
| 1650 | Figure 9 (fig6_positions), rate days 60 to 75 | 411 | ![Figure 9. | figure:make_figs_v4.py | 411 | MATCH |  |
| 1651 | Figure 1 (fig0_framework), panel (b) | 60 of 66 pairs | ![Figure 1. | figure:make_fig0.py | 60 of 66 | MATCH |  |
| 1652 | Figure 1 (fig0_framework), panel (b) | 0.20x to 7.24x | ![Figure 1. | figure:make_fig0.py | 0.20x to 7.24x | MATCH |  |
| 1653 | Figure 6 (fig9_reviews), panel (a) title | +0.19 | ![Figure 6. | figure:fig9_reviews.pdf as shipped (make_fig_reviews_v50.py cannot ... | 0.184869 | MISMATCH | title hard-coded as +0.19; full value 0.184869 is +0.18 (double rounding) |
| 1654 | Figure 6 (fig9_reviews), panel (b) title | +0.75 | ![Figure 6. | figure:fig9_reviews.pdf as shipped (make_fig_reviews_v50.py cannot ... | +0.748 | MATCH |  |
| 1655 | Figure 6 (fig9_reviews), panel (b) branches | the nine largest by review share | ![Figure 6. | figure:fig9_reviews.pdf as shipped | same nine, same order as m2_from_counts.py | MATCH |  |
| 1656 | Abstract | 381 | On 381 area-code pages of a large US telecommunications provider | data:section_code_pages_2026-10-14.csv | 381 | MATCH |  |
| 1657 | §2 (information needs) | 381 | (the 381 code pages rank for 29,000 keywords on one instrument) | data:section_code_pages_2026-10-14.csv | 381 | MATCH |  |
| 1658 | §2 (information needs) | 29,000 | (the 381 code pages rank for 29,000 keywords on one instrument) | data:single_reads_2026-10.csv | 29,000 | MATCH |  |
| 1659 | §3 | 381 | All 381 return HTTP 200, are canonical, and are full pages | data:section_code_pages_2026-10-14.csv | 381 | MATCH | the count only; HTTP status and canonical tags are not in the released list |
| 1660 | §3 | 50 | the 50 states, the District, and the plan-wide toll-free codes | data:section_code_pages_2026-10-14.csv | 50 | MATCH |  |
| 1661 | §3 | 381 | **381** is the number of code pages the section holds | data:section_code_pages_2026-10-14.csv | 381 | MATCH |  |
| 1662 | §5.5 para 'no detectable relationship' | 0.5 | give about 38% power to detect a correlation of 0.5 | rerun:instrument_extra.py | 0.5 | MATCH |  |
| 1663 | §5.6 limits | 77 | the longitudinal series is one prefix over 77 days | arith:dates (26 Jul to 11 Oct 2026) | 77 | MATCH |  |
| 1664 | §7.2 | 1,000 | Each export holds the 1,000 domains found in the most answers, the ... | data:cross_sector.py docstring (released script) | 1,000 rows | MATCH |  |
| 1665 | §7.3 Source types | 88 | the share of the total sum of squares of the 88 cell shares | rerun:section7_from_aggregates.py | 88 | MATCH |  |
| 1666 | §7.5 | 100 | Restricting each export to its first 100, 250 or 500 rows | shipped:cross_sector_sensitivity_output.txt | first 100 export rows | CANNOT RUN | paper agrees with the saved output |
| 1667 | §7.5 | 250 | Restricting each export to its first 100, 250 or 500 rows | shipped:cross_sector_sensitivity_output.txt | first 250 export rows | CANNOT RUN | paper agrees with the saved output |
| 1668 | §7.5 | 500 | Restricting each export to its first 100, 250 or 500 rows | shipped:cross_sector_sensitivity_output.txt | first 500 export rows | CANNOT RUN | paper agrees with the saved output |
| 1669 | §8 | 381 | following the publication of 381 code pages and their hubs | data:section_code_pages_2026-10-14.csv | 381 | MATCH |  |
| 1670 | Table 5 header, day 0 | 26 Jul | Day 0 (26 Jul) | arith:dates (day 0 = 26 Jul 2026) | 26 Jul | MATCH |  |
| 1671 | Table 5 header, day 15 | 10 Aug | Day 15 (10 Aug) | arith:dates (day 0 = 26 Jul 2026) | 10 Aug | MATCH |  |
| 1672 | Table 5 header, day 30 | 25 Aug | Day 30 (25 Aug) | arith:dates (day 0 = 26 Jul 2026) | 25 Aug | MATCH |  |
| 1673 | Table 5 header, day 37 | 1 Sep | Day 37 (1 Sep) | arith:dates (day 0 = 26 Jul 2026) | 1 Sep | MATCH |  |
| 1674 | Table 5 header, day 45 | 9 Sep | Day 45 (9 Sep) | arith:dates (day 0 = 26 Jul 2026) | 9 Sep | MATCH |  |
| 1675 | Table 5 header, day 60 | 24 Sep | Day 60 (24 Sep) | arith:dates (day 0 = 26 Jul 2026) | 24 Sep | MATCH |  |
| 1676 | Table 5 header, day 75 | 9 Oct | Day 75 (9 Oct) | arith:dates (day 0 = 26 Jul 2026) | 9 Oct | MATCH |  |
| 1677 | Table 5 header, day 77 | 11 Oct | Day 77 (11 Oct) | arith:dates (day 0 = 26 Jul 2026) | 11 Oct | MATCH |  |
| 1678 | §8 | n/r at day 77 | positions 11–20 were not captured that day | data:instrument_series_table5 CSV | n/r | MATCH |  |
| 1679 | §8 | n/r at day 77 | so the 21–100 row cannot be derived for it | data:instrument_series_table5 CSV | n/r | MATCH |  |
| 1680 | §8 | n/r at day 77 | the daily visits series was read only to day 75 | data:instrument_series_table5 CSV | n/r | MATCH |  |
| 1681 | §8 | day 75 within days 65 to 75 | Day 75 falls inside the window the Ahrefs data notice covers | arith:dates | 65 <= 75 <= 75 | MATCH |  |
| 1682 | §8 concentration | 441 | Of the 441 URLs holding a position on 11 October | data:instrument_series_table5 CSV | 441 | MATCH |  |
| 1683 | §9.1 | 1.0 and 0.5 | it grades a dedicated page about an entity 1.0 and a list or sectio... | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1684 | §10.1 Figure 9 caption | day 37 | the vertical rules mark the primary checkpoint (day 37), the Septem... | figure:make_figs_v4.py | axvline(37) | MATCH |  |
| 1685 | §10.1 Figure 9 caption | day 60 | the vertical rules mark the primary checkpoint (day 37), the Septem... | figure:make_figs_v4.py | axvline(60) | MATCH |  |
| 1686 | §10.1 Figure 9 caption | day 65 | the vertical rules mark the primary checkpoint (day 37), the Septem... | figure:make_figs_v4.py | axvline(65) | MATCH |  |
| 1687 | §13 | 10,000 | the exports took the first 10,000 rows in the vendor's default order | data:design file (amendments A1 and A2) | 10,000 | MATCH |  |
| 1688 | §14 | 924 | The frozen 924-query set, the parameter lock and the run manifest a... | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1689 | §14 | 22; 21; 1 | all 22 commits at that point are AI-assisted: 21 carry the assistan... | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1690 | §14 | 3.10 | the package declares Python 3.10 or later | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1691 | §14 | 109 | the 109-company list with its source | data:cross_sector_companies.csv | 109 | MATCH |  |
| 1692 | §14 competitive effects | 13 to 83 | mostly specialist directories at Domain Rating 13 to 83 | data:single_reads_2026-10.csv | 13 to 83 | MATCH |  |
| 1693 | §14 conflicts | 109 | that organization is also one of the 109 companies in Section 7 | data:cross_sector_companies.csv | 109 | MATCH |  |
| 1694 | Appendix B | 1.0, 0.5, 0 | The coverage rubric grades 1.0 for a dedicated page about *e* | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1695 | Appendix B | 1.0, 0.5, 0 | The answerability rubric grades 1.0 for an answer present | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |
| 1696 | Appendix B | 0.5, 0.5, 0.85 | Five parameters are locked: α = 0.5, β = 0.5, damping = 0.85 | none:ufi repository and package not in the bundle |  | CANNOT RUN |  |

## 5. Command log

Copied verbatim from `command_log.txt`. Commands ran through `checks/logrun.sh`, which records each command line and its exit code. Lines marked "recorded manually" are steps that did not go through the logger: file reads, and edits to my own check scripts. The last command line is the generation of this report; its exit code is not in this copy.

```
# Command log, independent reproduction run 3 of User_First_Intelligence_v5.2_2026-10-15_source.zip
# Every command below was run through checks/logrun.sh, which writes the command line and its exit code.
# Fresh working folder: /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh
# Report and check scripts folder: /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15

[2026-10-15 02:12:32] $ mkdir -p /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/zip /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle && cp /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/06_MANUSCRIPT/User_First_Intelligence_v5.2_2026-10-15_source.zip /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/zip/ && shasum -a 256 /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/zip/User_First_Intelligence_v5.2_2026-10-15_source.zip /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/06_MANUSCRIPT/User_First_Intelligence_v5.2_2026-10-15_source.zip
[2026-10-15 02:12:32] exit 0
[2026-10-15 02:12:32] $ unzip -l /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/zip/User_First_Intelligence_v5.2_2026-10-15_source.zip
[2026-10-15 02:12:32] exit 0
[2026-10-15 02:12:43] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle && unzip -q /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/zip/User_First_Intelligence_v5.2_2026-10-15_source.zip && ls
[2026-10-15 02:12:43] exit 0
[2026-10-15 02:12:43] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source && find . -type f | LC_ALL=C sort | xargs shasum -a 256 > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/pristine_sha256.txt && wc -l /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/pristine_sha256.txt
[2026-10-15 02:12:43] exit 0
[2026-10-15 02:12:43] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source && find . -type f -o -type l | wc -l && find . -type l
[2026-10-15 02:12:43] exit 0
[2026-10-15 02:12 recorded manually, run before the logger existed] $ ls -la <bundle zip>; ls -la 08_REVIEW/; ls -la <scratchpad>   (orientation only; nothing from 08_REVIEW of the working project was read)
[2026-10-15 02:12 recorded manually] $ mkdir -p <report folder>/checks <report folder>/outputs <fresh folder>; wrote checks/logrun.sh and the header of this log
[2026-10-15 02:13 recorded manually] $ cat <tool result of unzip -l> | sed | awk   (compact listing of the archive)
[2026-10-15 02:14 recorded manually, zsh, not through logger] $ cat README.txt data/README.md ai_citation_cross_sector/README.md framework_test_r1/README.md build_docx.sh   (failed after README.txt on a zsh '=====' expansion; re-run below through the logger)
[2026-10-15 02:12:55] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source && for f in data/README.md ai_citation_cross_sector/README.md framework_test_r1/README.md build_docx.sh; do echo "----- $f"; cat $f; done
[2026-10-15 02:12:55] exit 0
[2026-10-15 02:13:42] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/review_demand && sed -n '1,60p' supplement_r10.py && echo '-----make_fig_reviews.py' && cat make_fig_reviews.py && echo '-----make_fig_reviews_v50.py' && cat make_fig_reviews_v50.py
[2026-10-15 02:13:42] exit 0
[2026-10-15 02:14:03] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/scripts && sed -n '1,45p' cross_sector_sensitivity.py && echo '-----s2' && sed -n '1,40p' cross_sector_sensitivity2.py && echo '----- stakes' && cat /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/stakes/vendor_reliance.py
[2026-10-15 02:14:03] exit 0
[2026-10-15 02:14:12] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source && for f in edit_v49.py edit_v49_r9.py edit_v49_r9b.py edit_v49_r9c.py edit_v50.py edit_v50b.py edit_v50c.py edit_v51.py edit_v51b.py edit_v52.py edit_v52b.py edit_v52c.py edit_v52d.py edit_v52e.py edit_v52f.py edit_v52g.py edit_v52h.py edit_v52i.py edit_v52j.py edit_v52k.py edit_v52l.py edit_v52m.py edit_v52n.py edit_v52o.py; do echo "===== $f"; sed -n '1,25p' $f | grep -v '^$' | head -22; grep -n 'manuscript_v\|open(\|read_text\|write_text\|sys.argv\|Path(' $f | head -8; done
[2026-10-15 02:14:12] exit 0
[2026-10-15 02:14:32] $ wc -l -c /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/manuscript_v50.md && grep -n '^#' /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/manuscript_v50.md
[2026-10-15 02:14:32] exit 0
[2026-10-15 02:16:26] $ sed -n '532,686p' /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/manuscript_v50.md | grep -n -i 'pagadala\|motley\|costco\|bek 2026\|gottfried\|soulo\|langridge\|otterly\|hendricks\|kumar\|linehan' | cut -c1-400
[2026-10-15 02:16:26] exit 0
[2026-10-15 02:16:32] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source && cat data/ahrefs_prefixes_2026-10-12.csv && echo ---- && cat data/semrush_prefixes_2026-10-12.csv && echo ---- && for f in instrument_divergence_extra/instrument_series_table*.csv; do echo "== $f"; cat $f; done
[2026-10-15 02:16:32] exit 0
[2026-10-15 02:16:44] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/instrument_divergence_extra && cat single_reads_2026-10.csv && echo ---- && head -5 section_code_pages_2026-10-14.csv && wc -l section_code_pages_2026-10-14.csv
[2026-10-15 02:16:44] exit 0
[2026-10-15 02:17:04] $ { which python3; python3 --version; python3 -c 'import numpy, scipy, pandas, matplotlib; print("numpy", numpy.__version__, "scipy", scipy.__version__, "pandas", pandas.__version__, "matplotlib", matplotlib.__version__)'; python3 -c 'import openpyxl; print("openpyxl", openpyxl.__version__)' 2>&1 | tail -1; python3 -c 'import ufi; print("ufi importable at", ufi.__file__)' 2>&1 | tail -1; which tectonic && tectonic --version; which xelatex || echo 'xelatex: not found'; which pandoc && pandoc --version | head -1; which ots || echo 'ots: not found'; uname -a; } > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/environment.txt 2>&1; cat /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/environment.txt
[2026-10-15 02:17:05] exit 0
[2026-10-15 02:17:12] $ mkdir -p /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run && cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run && unzip -q /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/zip/User_First_Intelligence_v5.2_2026-10-15_source.zip && ls /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run && ls -d /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/05_FIGURES /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/05_FIGURES /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/03_DATA 2>&1
[2026-10-15 02:17:12] exit 1
[2026-10-15 02:17:18] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/data && python3 analyze.py > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/analyze_stdout.txt 2> /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/analyze_stderr.txt; echo exit=$?
[2026-10-15 02:17:18] exit 0
[2026-10-15 02:17:26] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/instrument_divergence_extra && time python3 instrument_extra.py > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/instrument_extra_stdout.txt 2> /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/instrument_extra_stderr.txt; echo exit=$?
[2026-10-15 02:17:50] exit 0
[2026-10-15 02:18:03] $ cmp /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/instrument_extra_stdout.txt /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/instrument_divergence_extra/instrument_extra_output.txt && echo 'instrument_extra_output.txt: IDENTICAL'; diff /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/instrument_divergence_extra/instrument_extra_output.txt /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/instrument_extra_stdout.txt
[2026-10-15 02:18:03] exit 0
[2026-10-15 02:18:03] $ for f in instrument_series_table2_visits_by_month.csv instrument_series_table3_ai_overview_citation_by_month.csv instrument_series_table5_checkpoints.csv instrument_series_table6_intervals.csv; do if cmp -s /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/instrument_divergence_extra/$f /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/instrument_divergence_extra/$f; then echo "$f: IDENTICAL"; else echo "$f: DIFFERS"; diff /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/instrument_divergence_extra/$f /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/instrument_divergence_extra/$f; fi; done
[2026-10-15 02:18:03] exit 0
[2026-10-15 02:18:14] $ mkdir -p /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/regenerated_files && cp /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/instrument_divergence_extra/instrument_series_table*.csv /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/regenerated_files/
[2026-10-15 02:18:14] exit 0
[2026-10-15 02:18:14] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/review_demand && python3 r2_link_check.py > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/r2_link_check_stdout.txt 2> /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/r2_link_check_stderr.txt; echo exit=$?; cmp /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/r2_link_check_stdout.txt /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/review_demand/r2_link_check_output.txt && echo 'r2_link_check_output.txt: IDENTICAL'
[2026-10-15 02:18:14] exit 0
[2026-10-15 02:18:26] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/review_demand && time python3 m2_from_counts.py > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/m2_from_counts_stdout.txt 2> /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/m2_from_counts_stderr.txt; echo exit=$?; cmp /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/m2_from_counts_stdout.txt /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/review_demand/m2_from_counts_output.txt && echo 'm2_from_counts_output.txt: IDENTICAL'
[2026-10-15 02:18:55] exit 0
[2026-10-15 02:19:10] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/scripts && time python3 section7_from_aggregates.py > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/section7_from_aggregates_stdout.txt 2> /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/section7_from_aggregates_stderr.txt; echo exit=$?; cmp /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/section7_from_aggregates_stdout.txt /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/scripts/section7_from_aggregates_output.txt && echo 'section7_from_aggregates_output.txt: IDENTICAL'
[2026-10-15 02:20:08] exit 0
[2026-10-15 02:20:26] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/scripts && python3 make_tables_sector_surface.py > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/make_tables_sector_surface_stdout.txt 2> /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/make_tables_sector_surface_stderr.txt; echo exit=$?; cmp /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/make_tables_sector_surface_stdout.txt /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/scripts/make_tables_sector_surface_output.txt && echo 'make_tables_sector_surface_output.txt: IDENTICAL'
[2026-10-15 02:20:26] exit 0
[2026-10-15 02:20:26] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/scripts && python3 make_brand_radar_urls.py > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/make_brand_radar_urls_stdout.txt 2> /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/make_brand_radar_urls_stderr.txt; echo exit=$?; cmp /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/design/cross_sector_report_urls.json /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/design/cross_sector_report_urls.json && echo 'cross_sector_report_urls.json: IDENTICAL'
[2026-10-15 02:20:26] exit 0
[2026-10-15 02:20:36] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/scripts && python3 make_fig_sources.py > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/make_fig_sources_stdout.txt 2> /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/make_fig_sources_stderr.txt; echo exit=$?; ls -la /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/scripts/fig10_sources.* /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/fig10_sources.*; for e in pdf png; do cmp -s /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/scripts/fig10_sources.$e /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/fig10_sources.$e && echo "fig10_sources.$e: IDENTICAL" || echo "fig10_sources.$e: bytes differ"; done
[2026-10-15 02:20:37] exit 0
[2026-10-15 02:20:55] $ python3 -I /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks/pdf_compare.py /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/fig10_sources.pdf /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/scripts/fig10_sources.pdf fig10_sources.pdf | tee /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/figcompare_fig10.txt
[2026-10-15 02:20:55] exit 0
[2026-10-15 02:21:04] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/stakes && python3 vendor_reliance.py --offline > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/vendor_reliance_offline_stdout.txt 2> /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/vendor_reliance_offline_stderr.txt; echo exit=$?; cmp /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/vendor_reliance_offline_stdout.txt /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/stakes/vendor_reliance_output.txt && echo 'vendor_reliance_output.txt: IDENTICAL'; diff /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/stakes/vendor_reliance_output.txt /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/vendor_reliance_offline_stdout.txt; cmp /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/stakes/vendor_reliance_works.csv /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/stakes/vendor_reliance_works.csv && echo 'works list untouched'
[2026-10-15 02:21:04] exit 0
[2026-10-15 02:21:17] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/scripts && for s in cross_sector.py cross_sector_sensitivity.py cross_sector_sensitivity2.py; do python3 $s > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/${s%.py}_rerun_stdout.txt 2> /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/${s%.py}_rerun_stderr.txt; echo "$s exit=$?"; echo '  stdout:'; head -c 600 /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/${s%.py}_rerun_stdout.txt; echo '  stderr:'; tail -c 600 /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/${s%.py}_rerun_stderr.txt; echo; done
[2026-10-15 02:21:17] exit 0
[2026-10-15 02:21:25] $ python3 -I -c 'import sys; a=open(sys.argv[1],"rb").read(); b=open(sys.argv[2],"rb").read(); print("partial rerun is %d bytes; shipped %d bytes; partial is an exact prefix of shipped: %s" % (len(b), len(a), a.startswith(b)))' /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/scripts/cross_sector_sensitivity2_output.txt /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/cross_sector_sensitivity2_rerun_stdout.txt
[2026-10-15 02:21:25] exit 0
[2026-10-15 02:21:31] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/review_demand && for s in analyze_reviews.py supplement_r10.py r2_link_sample.py make_fig_reviews.py make_fig_reviews_v50.py; do python3 $s > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/${s%.py}_rerun_stdout.txt 2> /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/${s%.py}_rerun_stderr.txt; echo "$s exit=$?"; echo '  stdout:'; head -c 400 /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/${s%.py}_rerun_stdout.txt; echo '  stderr (last line):'; tail -n 1 /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/${s%.py}_rerun_stderr.txt; done; ls -la /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/review_demand
[2026-10-15 02:21:35] exit 0
[2026-10-15 02:21:46] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source && python3 make_figs_v4.py > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/make_figs_v4_stdout.txt 2> /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/make_figs_v4_stderr.txt; echo make_figs_v4 exit=$?; python3 make_fig0.py > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/make_fig0_stdout.txt 2> /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/make_fig0_stderr.txt; echo make_fig0 exit=$?
[2026-10-15 02:21:48] exit 0
[2026-10-15 02:21:48] $ for f in fig0_framework fig1_divergence fig2_aio fig3_refdomains fig4_prefixes fig5_cited fig6_positions; do for e in png pdf; do python3 -I /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks/pdf_compare.py /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/$f.$e /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/$f.$e $f.$e; done; done | tee /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/figcompare_top_level.txt
[2026-10-15 02:21:49] exit 0
[2026-10-15 02:22:05] $ which pdftotext mutool qpdf gs 2>&1; python3 -c 'import pypdf; print("pypdf", pypdf.__version__)' 2>&1 | tail -1; python3 -c 'import fitz; print("pymupdf", fitz.__doc__)' 2>&1 | tail -1; python3 -c 'import pdfminer; print("pdfminer", pdfminer.__version__)' 2>&1 | tail -1; python3 -c 'import docx; print("python-docx ok")' 2>&1 | tail -1
[2026-10-15 02:22:05] exit 0
[2026-10-15 02:22:12] $ for f in fig9_reviews fig0_framework fig4_prefixes; do echo "===== $f"; pdftotext -layout /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/$f.pdf - 2>&1 | grep -v '^\s*$' | head -40; done > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/figure_text_fig9_fig0_fig4.txt; cat /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/figure_text_fig9_fig0_fig4.txt
[2026-10-15 02:22:12] exit 0
[2026-10-15 02:22:26] $ mkdir -p /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run && cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run && unzip -q /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/zip/User_First_Intelligence_v5.2_2026-10-15_source.zip && cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source && time python3 build_tex.py > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/build_tex_stdout.txt 2> /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/build_tex_stderr.txt; echo build_tex exit=$?
[2026-10-15 02:22:29] exit 0
[2026-10-15 02:22:36] $ ls -la /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build/ && cmp /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build/paper.tex /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/paper.tex && echo 'build/paper.tex vs shipped paper.tex: IDENTICAL'; shasum -a 256 /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build/paper.tex /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/paper.tex
[2026-10-15 02:22:36] exit 0
[2026-10-15 02:22:43] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build && time tectonic --keep-logs paper.tex > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/tectonic_stdout.txt 2>&1; echo tectonic exit=$?; ls -la /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build/paper.pdf /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build/paper.log
[2026-10-15 02:22:45] exit 0
[2026-10-15 02:22:53] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build && echo 'warning kinds:' && grep -o 'Underfull\|Overfull\|Missing character[^!]*\|undefined\|Font Warning[^.]*\|error' paper.log | sort | uniq -c; echo 'Overfull lines:'; grep -n 'Overfull' paper.log; python3 -I -c 'import sys,pypdf; r=pypdf.PdfReader(sys.argv[1]); print("pages:", len(r.pages))' paper.pdf; cp paper.log /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/tectonic_paper.log
[2026-10-15 02:22:53] exit 0
[2026-10-15 02:23:03] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build && grep -n -i 'error' paper.log | head; echo ----; sed -n '1143,1150p' paper.log; echo ----; sed -n '618,619p' paper.tex | cut -c1-600; which pdfinfo && pdfinfo paper.pdf | grep -i 'pages\|producer\|creator'
[2026-10-15 02:23:03] exit 0
[2026-10-15 02:23:11] $ ls -la /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build_docx.sh; cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source && zsh ./build_docx.sh > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/build_docx_stdout.txt 2> /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/build_docx_stderr.txt; echo build_docx exit=$?; ls -la /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build/paper.docx /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build/manuscript_docx.md
[2026-10-15 02:23:12] exit 0
[2026-10-15 02:23:19] $ unzip -l /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build/paper.docx | grep -i 'media' ; grep -c 'fig[0-9]*_[a-z]*\.png' /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build/manuscript_docx.md; grep -o '](fig[0-9]*_[a-z]*\.p[a-z]*)' /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build/manuscript_docx.md
[2026-10-15 02:23:19] exit 0
[2026-10-15 02:23:27] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source && sed -n '1,30p' edit_v51.py && sed -n '125,160p' edit_v51.py && echo ---- && grep -n 'parents\|\.\./\|write_text\|open(.*w' edit_v*.py | grep -v 'P.write_text(s)'
[2026-10-15 02:23:27] exit 0
[2026-10-15 02:23:48] $ bash /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks/run_edit_scripts.sh /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/edits > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/edit_scripts_attempts.txt 2>&1; echo exit=$?
[2026-10-15 02:23:54] exit 0
[2026-10-15 02:24:01] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source && sed -n '1,12p' edit_v52n.py; echo ----; sed -n '1,12p' edit_v52o.py; echo ----; grep -n 'Table 2\|77 cumulative\|78 in all' edit_v52n.py edit_v52o.py | cut -c1-300
[2026-10-15 02:24:01] exit 0
[2026-10-15 02:24:45] $ python3 -I /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks/ots_parse.py /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/framework_test_r1/framework_retro_test_381_manifest.txt /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/framework_test_r1/framework_retro_test_381_manifest.txt.ots /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/framework_test_r1/framework_retro_test_381_amendment_2026-10-15.md /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/framework_test_r1/framework_retro_test_381_amendment_2026-10-15.md.ots > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/ots_parse.txt 2>&1; echo exit=$?
[2026-10-15 02:24:45] exit 0
[2026-10-15 02:25:02] $ H=$(curl -s --max-time 20 https://blockstream.info/api/block-height/971506); echo "block hash at height 971506: $H"; if [ -n "$H" ]; then curl -s --max-time 20 https://blockstream.info/api/block/$H | python3 -I -c 'import json,sys,datetime; d=json.load(sys.stdin); print("height", d["height"], "merkle_root", d["merkle_root"], "timestamp", d["timestamp"], datetime.datetime.fromtimestamp(d["timestamp"], datetime.timezone.utc).isoformat())'; fi
[2026-10-15 02:25:03] exit 0
[2026-10-15 02:25:21] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/review_demand && for f in analyze_reviews_output.txt r2_link_sample_output.txt supplement_r10_output.txt; do echo "===== $f"; cat $f; done
[2026-10-15 02:25:21] exit 0
[2026-10-15 02:25:43] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/scripts && for f in cross_sector_output.txt pilot_section_output.txt; do echo "===== $f"; cat $f; done
[2026-10-15 02:25:43] exit 0
[2026-10-15 02:25:51] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/scripts && for f in cross_sector_sensitivity_output.txt cross_sector_sensitivity2_output.txt; do echo "===== $f"; cat $f; done
[2026-10-15 02:25:51] exit 0
[2026-10-15 02:26:10] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/design && echo 'property rows:' $(tail -n +2 cross_sector_company_properties.csv | grep -c .) && head -3 cross_sector_company_properties.csv && echo 'company rows:' $(tail -n +2 cross_sector_companies.csv | grep -c .) && head -2 cross_sector_companies.csv && grep -n -i '14 of 88\|44,463\|44463\|eight exports\|set aside\|A1\b\|A2\b\|A3\b\|A4\b\|^## \|^### ' cross_sector_ai_citation_study.md | cut -c1-260
[2026-10-15 02:26:10] exit 0
[2026-10-15 02:26:20] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source && cat arxiv_abstract.txt && echo && python3 -I -c 'import sys; t=open(sys.argv[1],encoding="utf-8").read(); print("characters:", len(t), "stripped:", len(t.strip()), "bytes:", len(t.encode()))' arxiv_abstract.txt
[2026-10-15 02:26:20] exit 0
[2026-10-15 02:26:27] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source && grep -n -o '[^|]*\(459\|+0\.78\|0\.78\|77 cumulative\|13,520\|−0\.09\|-0\.09\|90%\|0\.38\|456\|60 of 66\|9 of 15\|21\.3%\|2\.1%\|0\.94\|65%\|kappa\)[^|]*' UFI_Metrics_and_Evaluation_Protocol_v1.0.md | cut -c1-240
[2026-10-15 02:26:27] exit 0
[2026-10-15 02:26:36] $ pdftotext -layout /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/UFI_Metrics_and_Evaluation_Protocol_v1.0.pdf /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/protocol_pdf_text.txt; pdfinfo /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/UFI_Metrics_and_Evaluation_Protocol_v1.0.pdf | grep -i 'pages\|creationdate\|moddate'; for pat in '0.78' '13,520' '13,170' '459' '456' '72 labels' '37.8' '9 of 15' '51 of 51' '+0.70' '0.57' '15 labels' '8 labels' '1.13' '3.1'; do printf '%-8s md:%s pdf:%s\n' "$pat" $(grep -c -F -- "$pat" /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/UFI_Metrics_and_Evaluation_Protocol_v1.0.md) $(grep -c -F -- "$pat" /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/protocol_pdf_text.txt); done
[2026-10-15 02:26:36] exit 0
[2026-10-15 02:26:43] $ grep -n -F '459' /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/UFI_Metrics_and_Evaluation_Protocol_v1.0.md | cut -c1-400; grep -n -F '459' /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/protocol_pdf_text.txt | cut -c1-300; grep -n -i 'openalex\|vendor_reliance\|stakes' /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/UFI_Metrics_and_Evaluation_Protocol_v1.0.md | cut -c1-300
[2026-10-15 02:26:43] exit 0
[2026-10-15 02:29:02] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source && python3 -I -c '
import csv, collections, sys
rows = list(csv.DictReader(open(sys.argv[1])))
print("rows", len(rows))
print("group", collections.Counter(r["group"] for r in rows))
print("registry_use", collections.Counter(r["registry_use"] for r in rows))
print("in_service", collections.Counter((r["registry_use"], r["in_service"]) for r in rows))
locs = collections.Counter(r["location"] for r in rows)
print("distinct locations", len(locs), sorted(locs)[:60])
print("codes per NY CA TX FL", locs["NY"], locs["CA"], locs["TX"], locs["FL"])
print("not in service", [(r["code"], r["location"], r["assigned_date"]) for r in rows if r["in_service"] != "Y"])
' instrument_divergence_extra/section_code_pages_2026-10-14.csv; cat 08_REVIEW/reproduction_v5.2_run2_2026-10-15/outputs/tally.txt; python3 -I -c '
import csv, sys, collections
rows = list(csv.DictReader(open(sys.argv[1])))
ids = collections.Counter(r["id"] for r in rows)
d = [i for i, c in ids.items() if c > 1]
print("rows", len(rows), "duplicate ids", len(d), [ (i, [r["n_tools"] for r in rows if r["id"] == i]) for i in d])
print("matched rows including duplicates", sum(int(r["n_tools"]) >= 1 for r in rows))
' stakes/vendor_reliance_works.csv
[2026-10-15 02:29:02] exit 0
[2026-10-15 02:29:22] $ python3 -I -c 'import scipy, numpy; print("scipy under -I:", scipy.__version__, scipy.__file__)'; python3 -I -c 'import pypdf' 2>&1 | tail -1; python3 -P -c 'import pypdf, docx; print("pypdf and python-docx under -P ok")'
[2026-10-15 02:29:23] exit 0
[2026-10-15 02:29:29] $ python3 -c 'import sys, numpy, scipy, pandas, matplotlib; print(sys.executable); [print(m.__name__, m.__version__, m.__file__) for m in (numpy, scipy, pandas, matplotlib)]' | tee -a /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/environment.txt
[2026-10-15 02:29:30] exit 0
[2026-10-15 02:29:59] $ cd /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks && python3 -I m2_precise.py /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/review_demand > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/m2_precise.txt 2>&1; echo exit=$?
[2026-10-15 02:30:28] exit 0
[2026-10-15 02:31:02 recorded manually] edited my own checks/m2_precise.py to also print repr() of rho_m and the multi-word split interval
[2026-10-15 02:31:02] $ cd /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks && python3 -I m2_precise.py /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/review_demand > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/m2_precise.txt 2>&1; echo exit=$?
[2026-10-15 02:31:30] exit 0
[2026-10-15 02:42:15 recorded manually] removed an unused line from my own checks/check_numbers.py
[2026-10-15 02:42:15] $ cd /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks && python3 -I check_numbers.py /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/numbers_table.tsv > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/check_numbers_stdout.txt 2>&1; echo exit=$?
[2026-10-15 02:42:16] exit 0
[2026-10-15 02:42:24 recorded manually] patched sr() in my own checks/check_numbers.py to prefer an exact quantity match
[2026-10-15 02:42:24] $ cd /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks && python3 -I check_numbers.py /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/numbers_table.tsv > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/check_numbers_stdout.txt 2>&1; echo exit=$?
[2026-10-15 02:42:25] exit 0
[2026-10-15 02:43:00 recorded manually] fixed four rows of my own checks/check_numbers.py (URL Rating text, 1.9 million parse, Table 2 day count counted once)
[2026-10-15 02:43:00] $ cd /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks && python3 -I check_numbers.py /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/numbers_table.tsv > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/check_numbers_stdout.txt 2>&1; echo exit=$?
[2026-10-15 02:43:00] exit 0
[2026-10-15 02:43:08 recorded manually] viewed rows of outputs/numbers_table.tsv with awk for review
[2026-10-15 02:43:38 recorded manually] clarified the displayed value of one row in my own checks/check_numbers.py
[2026-10-15 02:43:38] $ cd /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks && python3 -I check_numbers.py /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/numbers_table.tsv > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/check_numbers_stdout.txt 2>&1; echo exit=$?
[2026-10-15 02:43:39] exit 0
[2026-10-15 02:44:13] $ pdftotext -layout /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build/paper.pdf /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/built_paper_pdf_text.txt && cd /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks && python3 -P -c '
import sys, re, docx
pdf = re.sub(r"\s+", " ", open(sys.argv[1], encoding="utf-8").read())
d = docx.Document(sys.argv[2])
dt = " ".join(p.text for p in d.paragraphs) + " " + " ".join(c.text for t in d.tables for r in t.rows for c in r.cells)
dt = re.sub(r"\s+", " ", dt)
for s in ["7.5x to 27.1x", "8.6x to 29.9x", "0.20x to 7.24x", "60 of 66 pairs", "9 of the 15 pairs", "(+0.19)", "+0.26 to +0.29", "21.3%", "11 (78 in all, days 0 to 77)", "77 cumulative", "20,389,967", "456 works", "971,506", "1,056 numbers"]:
    print(f"{s!r}: built PDF {s in pdf}; built DOCX {s in dt}")
print("DOCX tables:", len(d.tables), "inline images:", len(d.inline_shapes))
' /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/built_paper_pdf_text.txt /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build/paper.docx | tee /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/built_pdf_docx_spotcheck.txt
[2026-10-15 02:44:14] exit 0
[2026-10-15 02:44:20] $ grep -n '78 in all\|in all, days\|days 0 to 77\|0\.29\|+0.26' /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/built_paper_pdf_text.txt | cut -c1-200; grep -n -B2 -A3 'October 2026 (run-rate)' /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/built_paper_pdf_text.txt | head -20
[2026-10-15 02:44:20] exit 0
[2026-10-15 02:44:31 recorded manually] appended a note to outputs/built_pdf_docx_spotcheck.txt
[2026-10-15 02:44:31] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source && find . -type f | LC_ALL=C sort | xargs shasum -a 256 > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/pristine_sha256_after.txt && cmp /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/pristine_sha256.txt /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/pristine_sha256_after.txt && echo 'pristine extraction unchanged (212 files)'; shasum -a 256 /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/zip/User_First_Intelligence_v5.2_2026-10-15_source.zip
[2026-10-15 02:44:31] exit 0
[2026-10-15 02:44:31] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source && find . -type f | LC_ALL=C sort | xargs shasum -a 256 > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/run_copy_sha256_after.txt; diff <(awk '{print $2, $1}' /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/pristine_sha256.txt) <(awk '{print $2, $1}' /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/run_copy_sha256_after.txt) | grep '^[<>]' | awk '{print $1, $2}' | sort -k2 | uniq -f1 -c | awk '{print $3, ($1==2 ? "changed" : ($2==">" ? "added" : "removed"))}'
[2026-10-15 02:44:31] exit 0
[2026-10-15 02:45:28] $ cp /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build/paper.tex /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build/paper.pdf /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/build_run/User_First_Intelligence_v5.2_2026-10-15_source/build/paper.docx /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/regenerated_files/ && cp /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/run/User_First_Intelligence_v5.2_2026-10-15_source/ai_citation_cross_sector/scripts/fig10_sources.png /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/regenerated_files/ && ls -la /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/regenerated_files/
[2026-10-15 02:45:28] exit 0
[2026-10-15 02:45:28] $ cd /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source && echo 'files containing an absolute /Users/ path:' && grep -rl '/Users/' . | sort && echo 'occurrences:' && grep -rho '/Users/[A-Za-z0-9._-]*' . | sort | uniq -c
[2026-10-15 02:45:28] exit 0
[2026-10-15 02:45:34] $ grep -n '/Users/' /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/review_demand/r2_annotation_protocol.md | cut -c1-260
[2026-10-15 02:45:34] exit 0
[2026-10-15 02:45:54] $ cd /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks && python3 -I coverage.py /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/manuscript_v50.md /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/numbers_table.tsv > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/coverage_uncovered.txt 2>&1; echo exit=$?
[2026-10-15 02:45:54] exit 0
[2026-10-15 02:46:23] $ cd /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks && python3 -I coverage.py /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/manuscript_v50.md /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/numbers_table.tsv > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/coverage_uncovered.txt 2>&1; echo exit=$?
[2026-10-15 02:46:23] exit 0
[2026-10-15 02:47:34 recorded manually] added coverage rows to my own checks/check_numbers.py and fixed the trailing-comma regex in checks/coverage.py
[2026-10-15 02:47:34] $ cd /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks && python3 -I check_numbers.py /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/numbers_table.tsv > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/check_numbers_stdout.txt 2>&1; echo exit=$?; python3 -I coverage.py /private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/run3_fresh/bundle/User_First_Intelligence_v5.2_2026-10-15_source/manuscript_v50.md /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/numbers_table.tsv > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/coverage_uncovered.txt 2>&1; echo exit=$?
[2026-10-15 02:47:35] exit 0
[2026-10-15 02:47:40 recorded manually] viewed outputs/coverage_uncovered.txt (lines outside Related Work) with awk
[2026-10-15 02:48:01] $ cd /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks && python3 -I boundary_scan.py /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/numbers_table.tsv > /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/outputs/boundary_scan.txt 2>&1; echo exit=$?
[2026-10-15 02:48:02] exit 0
[2026-10-15 02:49:25 recorded manually] counted ERROR rows and statuses in outputs/numbers_table.tsv with awk
[2026-10-15 02:49:37 recorded manually] counted em dashes in numbers_table.tsv, command_log.txt and environment.txt with grep
[2026-10-15 02:50:57 recorded manually] corrected finding 1 in my own checks/make_report.py (the Table 2 CSV is the one output that did not reproduce)
[2026-10-15 02:50:57] $ cd /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks && python3 -I make_report.py /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15
[2026-10-15 02:50:57] exit 0
[2026-10-15 02:51:07 recorded manually] viewed parts of reproduction_report.md with sed and tail
[2026-10-15 02:51:22 recorded manually] refined two sentences in my own checks/make_report.py (thousands separators; the review scripts imported the installed ufi before stopping)
[2026-10-15 02:51:22] $ cd /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks && python3 -I make_report.py /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15
[2026-10-15 02:51:22] exit 0
[2026-10-15 02:51:27] $ cd /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence && git status --porcelain --untracked-files=normal
[2026-10-15 02:51:27] exit 0
[2026-10-15 02:51:42] $ shasum -a 256 /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/06_MANUSCRIPT/User_First_Intelligence_v5.2_2026-10-15_source.zip; ls -la /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/06_MANUSCRIPT/User_First_Intelligence_v5.2_2026-10-15_source.zip
[2026-10-15 02:51:42] exit 0
[2026-10-15 02:51:53 recorded manually] added a note on concurrent working-project changes to my own checks/make_report.py
[2026-10-15 02:51:53] $ cd /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks && python3 -I make_report.py /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15
```
