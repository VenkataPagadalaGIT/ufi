"""Compare two PDF (or any) files byte for byte; if they differ, show where, and say whether the only
differences sit inside a /CreationDate or /ModDate string (matplotlib and XeTeX stamp the build time there).

Usage: python3 -I pdf_compare.py <shipped file> <regenerated file> [<label>]
"""
import re
import sys

a_path, b_path = sys.argv[1], sys.argv[2]
label = sys.argv[3] if len(sys.argv) > 3 else b_path.rsplit("/", 1)[-1]
a, b = open(a_path, "rb").read(), open(b_path, "rb").read()
if a == b:
    print(f"{label}: IDENTICAL ({len(a)} bytes)")
    sys.exit(0)

DATE = re.compile(rb"/(CreationDate|ModDate)\s*\(D:[^)]*\)")
na, nb = DATE.sub(b"/DATE()", a), DATE.sub(b"/DATE()", b)
diffs = [i for i in range(min(len(a), len(b))) if a[i] != b[i]]
print(f"{label}: bytes differ (shipped {len(a)} bytes, regenerated {len(b)} bytes, {len(diffs)} differing positions"
      f"{'' if len(a) == len(b) else ', lengths differ'})")
for m in DATE.finditer(a):
    print(f"  shipped   {m.group(0).decode('latin-1')}")
for m in DATE.finditer(b):
    print(f"  regenerated {m.group(0).decode('latin-1')}")
if na == nb:
    print(f"{label}: IDENTICAL once the /CreationDate and /ModDate strings are masked")
else:
    # show the first few differing regions outside the date strings
    shown, i = 0, 0
    while i < min(len(na), len(nb)) and shown < 5:
        if na[i] != nb[i]:
            s = max(0, i - 40)
            print(f"  differs at masked offset {i}: shipped {na[s:i + 60]!r}")
            print(f"  {' ' * (len(str(i)) + 20)}regenerated {nb[s:i + 60]!r}")
            shown += 1
            i += 200
        else:
            i += 1
    print(f"{label}: DIFFERENT beyond the date strings")
