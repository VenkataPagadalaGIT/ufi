"""Write reproduction_report.md for run 3 from the outputs of this reproduction: the narrative below, the scripts table,
the numbers table generated from outputs/numbers_table.tsv, and the command log copied verbatim.

Usage: python3 -I make_report.py <report folder>
"""
import csv
import sys
from pathlib import Path

R = Path(sys.argv[1])
O = R / "outputs"
rows = list(csv.DictReader((O / "numbers_table.tsv").open(encoding="utf-8"), delimiter="\t"))
env = (O / "environment.txt").read_text(encoding="utf-8")
log = (R / "command_log.txt").read_text(encoding="utf-8")


def cell(s, n=None):
    s = (s or "").replace("|", "\\|").replace("\n", " ")
    return s if n is None or len(s) <= n else s[: n - 3] + "..."


status = {}
for r in rows:
    status[r["status"]] = status.get(r["status"], 0) + 1
kind = {}
for r in rows:
    k = (r["source"].split(":")[0], r["status"])
    kind[k] = kind.get(k, 0) + 1

out = []
w = out.append
w("# Independent reproduction, run 3: User First Intelligence v5.2 source bundle")
w("")
w("Reproducer: a separate AI agent working only from the released bundle, 15 October 2026. Report folder: "
  "`08_REVIEW/reproduction_v5.2_run3_2026-10-15/` (check scripts in `checks/`, every output in `outputs/`, "
  "the command log in `command_log.txt`). The run-1 and run-2 reports, in the working project and inside the bundle, "
  "were not read; the bundle's run-2 tally was opened only to check the figures Section 14 quotes from it.")
w("")
w("## 1. Environment and bundle")
w("")
w("**Environment:** Python 3.13.2 (`/opt/homebrew/opt/python@3.13/bin/python3.13`), numpy 2.4.1, scipy 1.17.1, pandas 3.0.0, "
  "matplotlib 3.11.1, openpyxl 3.1.5; tectonic 0.17.0; pandoc 3.9.0.2; poppler `pdftotext` and `pdfinfo`; macOS (Darwin 24.4.0, arm64). "
  "`xelatex` is not installed, so `build_tex.py` used tectonic, as its code provides. The OpenTimestamps client `ots` is not installed. "
  "A `ufi` package happens to be installed in this machine's user site-packages. The three review scripts imported it before "
  "stopping on the missing licensed export; no result in this report depends on it.")
w("")
w("**Bundle:** `User_First_Intelligence_v5.2_2026-10-15_source.zip`, SHA-256 "
  "`a23d25be9ea3cd5022232ad87e9ed5ca8dfba1beabd30d9d10219eee11aa33c5`. This matches the hash the caller gave, on the original "
  "and on the copy. The bundle holds 212 files.")
w("")
w("**Procedure:** I copied the zip into a fresh scratch folder and extracted it three times:")
w("")
w("- `bundle/`: pristine, never written. Its SHA-256 manifest was identical before and after the run "
  "(`outputs/pristine_sha256.txt`, `outputs/pristine_sha256_after.txt`).")
w("- `run/`: every script ran here.")
w("- `build_run/`: the paper build, from an untouched copy.")
w("")
w("Each edit record ran in its own throwaway copy. Nothing came from the author's working project. My own check scripts "
  "(in `checks/`) ran with `python3 -I` (`-P` where they needed the user-site pypdf or python-docx), with paths passed as arguments.")
w("")
w("At the end of the run the bundle zip in `06_MANUSCRIPT/` still had the same SHA-256. `git status` showed other "
  "uncommitted changes in the working project, made during this run but not by it: `src/manuscript_v50.md`, "
  "`03_DATA/instrument_series_table2_visits_by_month.csv`, `arxiv_abstract.txt`, new `edit_v52p.py` and `edit_v52q.py`, "
  "measurement files and `09_SUBMISSION/` files. This reproduction wrote only into its own report folder and the "
  "scratch folder, and it describes the bundle with the hash above, not the current working files.")
w("")
w("```")
w(env.strip())
w("```")
w("")
w("## 2. Findings")
w("")
w("1. **Everything that can run on the released files ran, and all but one output with a shipped counterpart reproduced byte for byte.** "
  "The exception is the Table 2 series CSV (finding 3). The figure PDFs differ only in their `/CreationDate` stamp; every PNG is identical.")
w("2. **The paper builds from the bundle.**")
w("    - `build_tex.py` writes a `build/paper.tex` byte-identical to the shipped `paper.tex` (SHA-256 `5771787136...a183b047`).")
w("    - tectonic compiles it to a 33-page PDF with no errors.")
w("    - `build_docx.sh` writes a DOCX with all nine figures and twelve tables.")
w("    - The built PDF and DOCX carry the manuscript's values, including the corrected Table 2 day count.")
w(f"3. **Numbers:** {len(rows):,} quoted values were checked: {status.get('MATCH', 0):,} MATCH, "
  f"{status.get('MISMATCH', 0)} MISMATCH, {status.get('CANNOT RUN', 0)} CANNOT RUN. The seven mismatches are three problems:")
w("    - **The topic-level correlation is quoted as +0.19; the released data give +0.18.** This is the Spearman correlation over "
  "the 1,008 mentioned labels. It is quoted as +0.19 in the Abstract, Section 6 (paragraph 2), Section 15, Table D1, and "
  "the title of Figure 6(a); `arxiv_abstract.txt` says 0.19. The released per-label counts give 0.184869. "
  "`m2_from_counts.py` prints this as +0.185, and to two decimals it is **+0.18**. The +0.19 is a double rounding "
  "(0.18487 to 0.185 to 0.19), and it is also hard-coded in the title string of `make_fig_reviews_v50.py`.")
w("    - **The all-labels interval is quoted as +0.26 to +0.29; its upper end is +0.28.** In Section 6 (paragraph 2), "
  "\"+0.27 (+0.26 to +0.29)\": the upper end is 0.284982, printed +0.285, which is **+0.28** to two decimals. Same double rounding.")
w("    - **The released Table 2 CSV is stale.** `instrument_divergence_extra/instrument_series_table2_visits_by_month.csv` "
  "still gives October's days-live as \"11 (77 cumulative)\". The manuscript's Table 2, corrected by `edit_v52n.py` after run 2, "
  "reads \"11 (78 in all, days 0 to 77)\". Rerunning `instrument_extra.py` regenerates the CSV from the manuscript with the "
  "corrected text, so the shipped file was not refreshed after the last edit. Section 14 calls this item \"now corrected\": "
  "it is corrected in the paper, but not in the released CSV the same section describes.")
w("    - None of the three changes a conclusion.")
w("4. **Values that could not be checked:**")
w("    - **109 come only from the saved outputs of scripts that need withheld inputs.** These are the licensed DataForSEO review "
  "export (`analyze_reviews.py`, `supplement_r10.py`, `r2_link_sample.py`), the raw Ahrefs Brand Radar exports "
  "(`cross_sector_sensitivity.py`, `cross_sector_sensitivity2.py`) and the unreleased pilot section. The paper agrees with "
  "every one of those saved outputs.")
w("    - **25 rest on material that is not in the bundle.** This covers the `ufi` repository and package (the 4/5 and 70.4% "
  "rates, digests, commit facts, rubric grades and the 0.22 tie value), the numbering-plan registry, the held-back Study R1 "
  "files, the second-domain protocol and the Bitcoin block time.")
w("    - **One dashboard read is in no released file:** zero live referring domains \"through 31 July\" (Section 10). "
  "README.txt and Appendix A say every quoted single dashboard read is in a released data file.")
w("5. **Smaller observations:**")
w("    - README.txt describes the edit records as running \"to edit_v52m.py\", but the bundle also holds `edit_v52n.py` "
  "and `edit_v52o.py`.")
w("    - The build log has one overfull line of 67.7 pt in Section 13: the long file name "
  "`02_DESIGN/framework_retro_test_381_amendment_2026-10-15.md` runs into the margin.")
w("    - **Study R1 timestamps:**")
w("        - The manifest's OpenTimestamps proof commits to the released manifest. It is anchored in Bitcoin block 971,506 "
  "with the merkle root the folder README quotes. A public block explorer gives that block's header time as 04:05:42 UTC "
  "on 15 October 2026 (an external check, outside the bundle).")
w("        - The amendment's proof commits to the released amendment but holds only pending calendar attestations, "
  "with no Bitcoin attestation yet.")
w("    - The bundle carries absolute paths from the author's machine, in `review_demand/r2_annotation_protocol.md` and in "
  "run 2's command log and environment file.")
w("    - `make_fig_sources.py` writes Figure 7 into `ai_citation_cross_sector/scripts/`, but `build_tex.py` takes figures "
  "from the bundle's top folder. A regenerated Figure 7 therefore has to be copied up by hand before a build uses it. "
  "The regenerated file is identical to the shipped one.")
w("    - Two values sit exactly on a rounding boundary, and both are counted as matches:")
w("        - Table 4's /device-compare/ keyword ratio is exactly 5.25 (12,600 / 2,400). The paper gives 5.2, which is how "
  "Python's round-half-even prints it in `instrument_extra.py`; round-half-up would give 5.3.")
w("        - The multi-word branch interval's lower end is 0.735 to machine precision. The paper gives +0.74, which is "
  "the conventional rounding.")
w("    - Section 5.5 quotes p = 0.10 without the area-code section. That is the t-approximation; the permutation p printed "
  "beside it is 0.11.")
w("")
w("## 3. Scripts")
w("")
w("\"Identical\" means byte for byte against the output file shipped beside the script. Scripts ran in their own folder, as "
  "README.txt, the folder READMEs or their docstrings say.")
w("")
w("| Script | How it was run | Result | Comparison with the shipped output |")
w("|---|---|---|---|")
S = [
    ("data/analyze.py", "`cd data && python3 analyze.py`", "RAN", "No output file is shipped beside it. Every printed value was checked against the paper (section 4)."),
    ("instrument_divergence_extra/instrument_extra.py", "`cd instrument_divergence_extra && python3 instrument_extra.py`", "RAN (25 s)",
     "stdout is identical to `instrument_extra_output.txt`. The script rewrites the four series CSVs from the manuscript: Tables 3, 5 and 6 are identical; Table 2 differs on one line (shipped: `11 (77 cumulative)`; regenerated: `11 (78 in all, days 0 to 77)`)."),
    ("review_demand/r2_link_check.py", "`cd review_demand && python3 r2_link_check.py`", "RAN", "Identical to `r2_link_check_output.txt`."),
    ("review_demand/m2_from_counts.py", "`cd review_demand && python3 m2_from_counts.py`", "RAN (29 s)", "Identical to `m2_from_counts_output.txt`."),
    ("review_demand/analyze_reviews.py", "`cd review_demand && python3 analyze_reviews.py`", "CANNOT RUN",
     "Missing: `Telecom_reviews_and_responses.xlsx` and `Telecom_classification.xlsx` (the licensed DataForSEO export, withheld). The script also imports `ufi`, which is not in the bundle. It stops with FileNotFoundError. The saved output was used in the number check."),
    ("review_demand/supplement_r10.py", "`cd review_demand && python3 supplement_r10.py`", "CANNOT RUN", "Same missing inputs; same stop."),
    ("review_demand/r2_link_sample.py", "`cd review_demand && python3 r2_link_sample.py`", "CANNOT RUN", "Same missing inputs; same stop. Nothing was written."),
    ("review_demand/make_fig_reviews.py", "`cd review_demand && python3 make_fig_reviews.py`", "CANNOT RUN", "Missing: `out/label_demand_aggregates.csv` and `out/branch_shares.csv`, which are written from the withheld export."),
    ("review_demand/make_fig_reviews_v50.py", "`cd review_demand && python3 make_fig_reviews_v50.py`", "CANNOT RUN",
     "Missing: `out/label_demand_aggregates.csv` and `out/branch_shares_corrected.csv`. Instead, the text of the shipped `fig9_reviews.pdf` was read and checked."),
    ("ai_citation_cross_sector/scripts/section7_from_aggregates.py", "`cd ai_citation_cross_sector/scripts && python3 section7_from_aggregates.py`", "RAN (57 s)", "Identical to `section7_from_aggregates_output.txt`."),
    ("ai_citation_cross_sector/scripts/make_tables_sector_surface.py", "`cd ai_citation_cross_sector/scripts && python3 make_tables_sector_surface.py`", "RAN", "Identical to `make_tables_sector_surface_output.txt`."),
    ("ai_citation_cross_sector/scripts/make_fig_sources.py", "`cd ai_citation_cross_sector/scripts && python3 make_fig_sources.py`", "RAN", "`fig10_sources.png` is identical. `fig10_sources.pdf` is identical except for `/CreationDate`."),
    ("ai_citation_cross_sector/scripts/make_brand_radar_urls.py", "`cd ai_citation_cross_sector/scripts && python3 make_brand_radar_urls.py`", "RAN", "It rewrites `design/cross_sector_report_urls.json`, which comes out identical. No stdout file is shipped."),
    ("ai_citation_cross_sector/scripts/cross_sector.py", "`cd ai_citation_cross_sector/scripts && python3 cross_sector.py`", "CANNOT RUN", "Missing: the raw Brand Radar exports (withheld under the vendor's terms). The script stops with its documented message."),
    ("ai_citation_cross_sector/scripts/cross_sector_sensitivity.py", "`cd ai_citation_cross_sector/scripts && python3 cross_sector_sensitivity.py`", "CANNOT RUN", "Missing: the raw exports; same documented stop."),
    ("ai_citation_cross_sector/scripts/cross_sector_sensitivity2.py", "`cd ai_citation_cross_sector/scripts && python3 cross_sector_sensitivity2.py`", "CANNOT RUN",
     "Missing: the raw exports. Before stopping, it prints its first section from the aggregates, and those 760 bytes are an exact prefix of the saved output."),
    ("stakes/vendor_reliance.py", "`cd stakes && python3 vendor_reliance.py --offline`", "RAN",
     "Identical to `vendor_reliance_output.txt`, and the works list was not rewritten. Online mode was not run: it queries OpenAlex and rewrites the list, and the README gives `--offline` for recounting."),
    ("make_figs_v4.py", "`python3 make_figs_v4.py` (bundle top)", "RAN", "Six PNGs identical; six PDFs identical except for `/CreationDate`."),
    ("make_fig0.py", "`python3 make_fig0.py` (bundle top)", "RAN", "PNG identical; PDF identical except for `/CreationDate`."),
    ("build_tex.py", "`python3 build_tex.py` (fresh copy, bundle top)", "RAN", "`build/paper.tex` is identical to the shipped `paper.tex`."),
    ("(build) tectonic", "`cd build && tectonic --keep-logs paper.tex`", "RAN", "33-page `paper.pdf`, no errors; 68 underfull and 4 overfull boxes (the largest is 67.7 pt). No shipped PDF to compare."),
    ("build_docx.sh", "`zsh ./build_docx.sh` (bundle top)", "RAN", "`build/paper.docx` (1.24 MB): 9 figures, 12 tables. No shipped DOCX to compare."),
    ("edit_v49.py, edit_v49_r9.py, edit_v49_r9b.py, edit_v49_r9c.py, edit_v50.py", "`python3 <script>`, each in its own throwaway copy", "CANNOT RUN",
     "Missing: `manuscript_v49.md`, the earlier manuscript these records edit. Each stops with FileNotFoundError and changes nothing."),
    ("edit_v50b.py to edit_v52o.py (19 scripts)", "`python3 <script>`, each in its own throwaway copy", "CANNOT RUN",
     "Missing: the pre-edit states of `manuscript_v50.md`. On the released manuscript each refuses (\"REFUSE: 0 matches\" or \"REFUSE: already applied\") and changes no file (`outputs/edit_scripts_attempts.txt`)."),
    ("framework_test_r1: `ots verify`", "not available (`ots` not installed)", "CANNOT RUN",
     "Checked offline with `checks/ots_parse.py`. The manifest proof commits to SHA-256 `003311...e4b9` of the released manifest and attests block 971,506 with merkle root `7bdc6025...59a3`. The amendment proof commits to `304297...e1dd`, pending attestations only. The held-back plan, predictors and script cannot be checked against the manifest."),
]
for s in S:
    w("| " + " | ".join(cell(x) for x in s) + " |")
w("")
w("**Tally:** the bundle holds 45 scripts that belong to the paper (21 analysis, figure and build scripts plus 24 edit records). "
  "13 RAN, 0 FAILED, and 32 CANNOT RUN: 8 need withheld data and 24 edit records need earlier, unreleased manuscript states. "
  "The tectonic compile also ran. The check scripts inside the bundle's `08_REVIEW/` folders belong to the two earlier "
  "reproductions and were not run.")
w("")
w("## 4. Numbers")
w("")
w("**Method:** `checks/check_numbers.py` finds each quoted value in `manuscript_v50.md` by its surrounding text, obtains the "
  "value from the named source, and compares the two at the paper's precision (a difference of at most half a unit in the "
  "paper's last digit). Text values are compared exactly. The source kinds are:")
w("")
w("- `rerun`: printed by a bundle script rerun here.")
w("- `data`: computed from a released data file.")
w("- `arith`: arithmetic on figures the paper itself quotes, or on the released table CSVs.")
w("- `figure`: a value drawn by a figure script, compared with the released data.")
w("- `shipped`: only in the saved output of a script that cannot run here; status CANNOT RUN, with a note saying whether the paper agrees with that output.")
w("- `none`: no released source; status CANNOT RUN.")
w("")
w("The four Section 6 values whose printed form sits on a rounding boundary were settled at full precision by "
  "`checks/m2_precise.py`. That script reads the released counts and follows the documented seed and resampling order.")
w("")
w(f"**Totals:** {len(rows):,} values: " + ", ".join(f"{k} {v:,}" for k, v in sorted(status.items())) + ".")
w("")
w("By source kind:")
w("")
w("| Source kind | MATCH | MISMATCH | CANNOT RUN |")
w("|---|---|---|---|")
for k in ("rerun", "data", "arith", "figure", "shipped", "none"):
    w(f"| {k} | {kind.get((k, 'MATCH'), 0)} | {kind.get((k, 'MISMATCH'), 0)} | {kind.get((k, 'CANNOT RUN'), 0)} |")
w("")
w("**Coverage:** `checks/coverage.py` lists every numeric token outside the reference list that no check quotes "
  "(`outputs/coverage_uncovered.txt`). None of what remains is printed by a bundle script or held in a released data file. It falls into these groups:")
w("")
w("- figures from the literature (Section 2, Appendix B), vendor documentation (Section 7.2), Pew and Costco (Section 13.1);")
w("- Table 7's costs, which are the author's reconstruction;")
w("- model and software version names, and the history of earlier versions;")
w("- structural labels: day numbers, position bands, item numbers, formula constants and confidence levels.")
w("")
w("### 4.1 MISMATCH")
w("")
w("| id | Location | Value quoted | Source | Obtained | Note |")
w("|---|---|---|---|---|---|")
for r in rows:
    if r["status"] == "MISMATCH":
        w(f"| {r['id']} | {cell(r['location in the paper'])} | {cell(r['value quoted'])} | {cell(r['source'])} | {cell(r['obtained'])} | {cell(r['note'])} |")
w("")
w("### 4.2 CANNOT RUN with no released source")
w("")
w("| id | Location | Value quoted | Reason | Note |")
w("|---|---|---|---|---|")
for r in rows:
    if r["status"] == "CANNOT RUN" and r["source"].startswith("none"):
        w(f"| {r['id']} | {cell(r['location in the paper'])} | {cell(r['value quoted'])} | {cell(r['source'][5:])} | {cell(r['note'])} |")
w("")
w("### 4.3 CANNOT RUN from the saved outputs of scripts that need withheld data")
w("")
w("| Saved output | Values | Paper agrees with the saved output |")
w("|---|---|---|")
sh = {}
for r in rows:
    if r["status"] == "CANNOT RUN" and r["source"].startswith("shipped"):
        k = r["source"][8:]
        a, b = sh.get(k, (0, 0))
        sh[k] = (a + 1, b + (1 if r["note"].startswith("paper agrees") else 0))
for k, (a, b) in sorted(sh.items()):
    w(f"| `{k}` | {a} | {b} of {a} |")
w("")
w("### 4.4 Every value checked")
w("")
w("The same table, with the full quoted text, is in `outputs/numbers_table.tsv`.")
w("")
w("| id | Location | Value quoted | Quoted text (first 70 characters) | Source | Obtained | Status | Note |")
w("|---|---|---|---|---|---|---|---|")
for r in rows:
    w(f"| {r['id']} | {cell(r['location in the paper'], 80)} | {cell(r['value quoted'], 60)} | {cell(r['quoted text (first 140 characters)'], 70)} | "
      f"{cell(r['source'], 70)} | {cell(r['obtained'], 60)} | {r['status']} | {cell(r['note'], 160)} |")
w("")
w("## 5. Command log")
w("")
w("Copied verbatim from `command_log.txt`. Commands ran through `checks/logrun.sh`, which records each command line and "
  "its exit code. Lines marked \"recorded manually\" are steps that did not go through the logger: file reads, and edits "
  "to my own check scripts. The last command line is the generation of this report; its exit code is not in this copy.")
w("")
w("```")
w(log.rstrip())
w("```")
(R / "reproduction_report.md").write_text("\n".join(out) + "\n", encoding="utf-8")
print(f"wrote {R / 'reproduction_report.md'}: {len(out)} lines")
