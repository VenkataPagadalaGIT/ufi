"""Find checks whose obtained value, as printed, sits exactly on a rounding boundary of the paper's precision (for
example a printed 0.185 against a quoted 0.19). Such a match depends on the unprinted digits; each one listed here
needs the full-precision value before it can be called a match.

Usage: python3 -I boundary_scan.py <numbers_table.tsv>
"""
import csv
import re
import sys

rows = list(csv.DictReader(open(sys.argv[1], encoding="utf-8"), delimiter="\t"))


def parse(s):
    s = s.strip().replace("−", "-").replace(",", "").replace("%", "").replace("+", "").replace("x", "").replace("**", "")
    return float(s)


def dec(s):
    m = re.search(r"\d+(?:\.(\d+))?", s.replace(",", ""))
    return len(m.group(1)) if m and m.group(1) else 0


hits = 0
for r in rows:
    try:
        p, o = parse(r["value quoted"]), parse(r["obtained"])
    except ValueError:
        continue
    dp, do = dec(r["value quoted"]), dec(r["obtained"])
    if do > dp and abs(abs(o - p) - 0.5 * 10 ** (-dp)) < 1e-9:
        hits += 1
        print(f"{r['id']}\t{r['location in the paper']}\tquoted {r['value quoted']}\tobtained {r['obtained']}\t{r['source']}\t{r['status']}")
print(f"boundary cases: {hits}")
