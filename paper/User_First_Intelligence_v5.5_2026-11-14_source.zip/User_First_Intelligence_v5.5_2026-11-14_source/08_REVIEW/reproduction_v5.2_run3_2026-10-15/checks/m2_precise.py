"""Full-precision values for the Section 6 statistics whose printed three-decimal values sit exactly on a rounding
boundary for the paper's two decimals (0.185, 0.245, 0.285, 0.735). Written independently for this reproduction:
it reads the released m2_label_counts.csv and m2_branches.csv and follows the documented definitions, seed and order
of resampling of m2_from_counts.py (rank correlations; percentile bootstrap, random.Random(20261015), the four
section-10 resamplings and then the two section-11 ones, in that order), printing six decimals.

Usage: python3 -I m2_precise.py <review_demand folder>
"""
import csv
import random
import sys
from pathlib import Path

from scipy.stats import spearmanr

D = Path(sys.argv[1])
L = list(csv.DictReader((D / "m2_label_counts.csv").open()))
BR = list(csv.DictReader((D / "m2_branches.csv").open()))
bv = {b["branch_id"]: float(b["own_volume_share"]) for b in BR}
ment = [int(x["mentions"]) for x in L]
vrank = [float(x["volume_rank"]) for x in L]
nodes = [{k: int(c) for k, c in (p.split(":") for p in x["branch_nodes"].split(";"))} for x in L]
multi = [int(x["words"]) >= 2 for x in L]


def split_(counts, rows):
    out = {}
    for k in rows:
        if counts[k]:
            tot = sum(nodes[k].values())
            for b, c in nodes[k].items():
                out[b] = out.get(b, 0) + counts[k] * c / tot
    return out


def modal(counts, rows):
    out = {}
    for k in rows:
        if counts[k]:
            b = max(nodes[k].items(), key=lambda bc: bc[1])[0]
            out[b] = out.get(b, 0) + counts[k]
    return out


def shares(d):
    tot = sum(d.get(b, 0) for b in bv)
    return [d.get(b, 0) / tot for b in bv]


rng = random.Random(20261015)


def boot(xs, ys, reps):
    n, out = len(xs), []
    for _ in range(reps):
        idx = [rng.randrange(n) for _ in range(n)]
        r = spearmanr([xs[i] for i in idx], [ys[i] for i in idx]).statistic
        if r == r:
            out.append(r)
    out.sort()
    return out[int(0.025 * len(out))], out[int(0.975 * len(out)) - 1]


mi = [k for k in range(len(L)) if ment[k] > 0]
rho_m = spearmanr([ment[k] for k in mi], [vrank[k] for k in mi]).statistic
rho_all = spearmanr(ment, vrank).statistic
vs = [bv[b] / sum(bv.values()) for b in bv]
B = sorted(zip(bv, shares(split_(ment, range(len(L)))), vs), key=lambda t: -t[1])
rb = spearmanr([t[1] for t in B], [t[2] for t in B]).statistic
r2v = shares(modal(ment, range(len(L))))
r2 = spearmanr(r2v, vs).statistic
print(f"label-level, mentioned labels: rho {rho_m:.6f}")
print(f"label-level, all linkable labels: rho {rho_all:.6f}")
print(f"branch-level split: rho {rb:.6f}; modal: rho {r2:.6f}")
lo, hi = boot([ment[k] for k in mi], [vrank[k] for k in mi], 10_000)
print(f"interval, mentioned labels: [{lo:.6f}, {hi:.6f}]")
lo, hi = boot(ment, vrank, 2_000)
print(f"interval, all linkable labels: [{lo:.6f}, {hi:.6f}]")
lo, hi = boot([t[1] for t in B], [t[2] for t in B], 10_000)
print(f"interval, branch split: [{lo:.6f}, {hi:.6f}]")
lo, hi = boot(r2v, vs, 10_000)
print(f"interval, branch modal: [{lo:.6f}, {hi:.6f}]")
mw = sorted((k for k in range(len(L)) if multi[k]), key=lambda k: int(L[k]["multiword_order"]))
cm = {k: int(L[k]["mentions_multiword_linker"]) for k in mw}
mmw = [k for k in mw if cm[k] > 0]
rm_ = spearmanr([cm[k] for k in mmw], [vrank[k] for k in mmw]).statistic
lo1, hi1 = boot([cm[k] for k in mmw], [vrank[k] for k in mmw], 10_000)
cnt = [cm.get(k, 0) for k in range(len(L))]
Bm = shares(split_(cnt, mw))
rbm = spearmanr(Bm, vs).statistic
lo2, hi2 = boot(Bm, vs, 10_000)
rbmm = spearmanr(shares(modal(cnt, mw)), vs).statistic
print(f"multi-word, mentioned labels: rho {rm_:.6f} [{lo1:.6f}, {hi1:.6f}]")
print(f"multi-word, branch split: rho {rbm:.6f} [{lo2:.6f}, {hi2:.6f}]; modal rho {rbmm:.6f}")
print(f"full repr: rho_m {rho_m!r}; multi-word branch split interval lower {lo2!r}, upper {hi2!r}")
