#!/bin/bash
# Logging wrapper: records the command, its time and its exit code in command_log.txt, then runs it.
LOG=/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/08_REVIEW/reproduction_v5.2_run3_2026-10-15/command_log.txt
printf '[%s] $ %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG"
bash -c "$*"
rc=$?
printf '[%s] exit %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$rc" >> "$LOG"
exit $rc
