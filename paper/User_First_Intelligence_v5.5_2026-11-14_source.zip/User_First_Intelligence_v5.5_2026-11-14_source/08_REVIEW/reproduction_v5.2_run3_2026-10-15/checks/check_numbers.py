"""Every number the paper (manuscript_v50.md) quotes from a script or a released data file, checked one by one.

For each quoted value the script (1) confirms the quoted text is in the manuscript, (2) obtains the value from the
source the paper names or implies, and (3) compares them at the paper's precision (a difference of at most half a unit
in the paper's last digit). Sources:
  rerun:<script>    stdout of the bundle script rerun in this reproduction (outputs/), or of a check script written here
  data:<file>       computed from a released data file in the bundle
  arith:<what>      arithmetic on figures the paper itself quotes (or on the released table CSVs)
  figure:<script>   a value hard-coded in a figure script, compared with the released data
  shipped:<file>    the saved output of a script that cannot run on the bundle (withheld input): CANNOT RUN, with a
                    note saying whether the paper agrees with the saved output
  none:<reason>     no released source: CANNOT RUN
Writes numbers_table.tsv and prints a tally.

Usage: python3 -I check_numbers.py <pristine bundle folder> <outputs folder> <tsv to write>
"""
import ast
import csv
import math
import re
import sys
from pathlib import Path

B, O, TSV = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
MS = (B / "manuscript_v50.md").read_text(encoding="utf-8")
MSN = re.sub(r"\s+", " ", MS)


def rd(p):
    return Path(p).read_text(encoding="utf-8")


A = rd(O / "analyze_stdout.txt")
IE = rd(O / "instrument_extra_stdout.txt")
LC = rd(O / "r2_link_check_stdout.txt")
M2 = rd(O / "m2_from_counts_stdout.txt")
S7 = rd(O / "section7_from_aggregates_stdout.txt")
MT = rd(O / "make_tables_sector_surface_stdout.txt")
VR = rd(O / "vendor_reliance_offline_stdout.txt")
URLS = rd(O / "make_brand_radar_urls_stdout.txt")
MP = rd(O / "m2_precise.txt")
OTS = rd(O / "ots_parse.txt")
FIGTXT = rd(O / "figure_text_fig9_fig0_fig4.txt")
AR = rd(B / "review_demand/analyze_reviews_output.txt")
SUP = rd(B / "review_demand/supplement_r10_output.txt")
LS = rd(B / "review_demand/r2_link_sample_output.txt")
CSO = rd(B / "ai_citation_cross_sector/scripts/cross_sector_output.txt")
SE = rd(B / "ai_citation_cross_sector/scripts/cross_sector_sensitivity_output.txt")
SE2 = rd(B / "ai_citation_cross_sector/scripts/cross_sector_sensitivity2_output.txt")
PI = rd(B / "ai_citation_cross_sector/scripts/pilot_section_output.txt")
DESIGN = rd(B / "ai_citation_cross_sector/design/cross_sector_ai_citation_study.md")
RUN2 = rd(B / "08_REVIEW/reproduction_v5.2_run2_2026-10-15/outputs/tally.txt")
CSPY = rd(B / "ai_citation_cross_sector/scripts/cross_sector.py")
FIGPY = rd(B / "make_figs_v4.py")
FIG0PY = rd(B / "make_fig0.py")


def g(text, pat, grp=1):
    m = re.search(pat, text, re.S)
    if not m:
        raise KeyError(f"pattern not found: {pat}")
    return m.group(grp)


def csvrows(p):
    return list(csv.reader((B / p).open(encoding="utf-8")))


def dictrows(p):
    return list(csv.DictReader((B / p).open(encoding="utf-8")))


# ---------------------------------------------------------------- released data
AH = {r["prefix"]: r for r in dictrows("data/ahrefs_prefixes_2026-10-12.csv")}
SM = {r["prefix"]: r for r in dictrows("data/semrush_prefixes_2026-10-12.csv")}
SRR = dictrows("instrument_divergence_extra/single_reads_2026-10.csv")
CP = dictrows("instrument_divergence_extra/section_code_pages_2026-10-14.csv")
T2 = csvrows("instrument_divergence_extra/instrument_series_table2_visits_by_month.csv")
T3 = csvrows("instrument_divergence_extra/instrument_series_table3_ai_overview_citation_by_month.csv")
T5 = csvrows("instrument_divergence_extra/instrument_series_table5_checkpoints.csv")
T6 = csvrows("instrument_divergence_extra/instrument_series_table6_intervals.csv")
PROPS = dictrows("ai_citation_cross_sector/design/cross_sector_company_properties.csv")
COMP = dictrows("ai_citation_cross_sector/design/cross_sector_companies.csv")
WORKS = dictrows("stakes/vendor_reliance_works.csv")


def sr(sub, date=None):
    m = [r for r in SRR if sub in r["quantity"] and (date is None or r["read date as stated in the paper"].startswith(date))]
    if len(m) > 1 and any(r["quantity"] == sub for r in m):
        m = [r for r in m if r["quantity"] == sub]
    if len(m) != 1:
        raise KeyError(f"single read {sub!r}: {len(m)} rows")
    return m[0]["value"]


def n_(s):
    return float(str(s).replace(",", ""))


def age(p):
    y, m = map(int, AH[p]["ahrefs_first_traffic_month"].split("-"))
    return (2026 - y) * 12 + (10 - m)


at = {p: n_(AH[p]["ahrefs_organic_traffic"]) for p in AH}
st = {p: n_(SM[p]["semrush_organic_traffic_us"]) for p in AH}
us = {p: n_(AH[p]["ahrefs_us_share"]) for p in AH}
akw = {p: n_(AH[p]["ahrefs_organic_keywords"]) for p in AH}
skw = {p: n_(SM[p]["semrush_organic_keywords_us"]) for p in AH}
ard = {p: n_(AH[p]["ahrefs_ref_domains"]) for p in AH}
srd = {p: n_(SM[p]["semrush_ref_domains"]) for p in AH}

# Table 2 series from the released CSV
T2V = {}
for r in T2[1:]:
    m = re.match(r"([\d,]+) \(([\d,]+)\)", r[3])
    T2V[r[0].split(" ")[0]] = dict(days=r[1], a=n_(r[2]), us=n_(m.group(1)), ww=n_(m.group(2)))
MONTHS = ["July", "August", "September", "October"]
T3V = {}
for r in T3[1:]:
    k, n = re.match(r"([\d,]+) of ([\d,]+)", r[1]).groups()
    T3V[r[0].split(" ")[0]] = dict(k=n_(k), n=n_(n), b=n_(r[3]))
T5V = {r[0]: r[1:] for r in T5[1:]}
T5D = [0, 15, 30, 37, 45, 60, 75, 77]


def t5(metric, day):
    v = T5V[metric][T5D.index(day)]
    return v


def wilson(k, n, z=1.96):
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return c - h, c + h


# ---------------------------------------------------------------- comparison
def num(s):
    s = str(s).strip().replace("−", "-").replace(",", "").replace("≈", "").replace("%", "").replace("+", "")
    s = s.replace("**", "").strip()
    if s.endswith("x"):
        s = s[:-1]
    return float(s)


def decimals(s):
    s = str(s).replace("**", "")
    m = re.search(r"\d+(?:\.(\d+))?", s.replace(",", ""))
    return len(m.group(1)) if m and m.group(1) else 0


def norm(s):
    return re.sub(r"\s+", " ", str(s)).strip().lower()


ROWS = []


def add(loc, quote, paper, src, got, note="", tol=None, exact=False):
    ROWS.append(dict(loc=loc, quote=quote, paper=paper, src=src, got=got, note=note, tol=tol, exact=exact))


def same(paper, got, tol, exact):
    if isinstance(got, bool):
        return got
    if exact:
        return norm(paper) == norm(got)
    try:
        p = num(paper)
        o = num(got) if isinstance(got, str) else float(got)
    except (ValueError, TypeError):
        return norm(paper) == norm(got)
    t = tol if tol is not None else 0.5 * 10 ** (-decimals(paper)) + 1e-9
    return abs(o - p) <= t


# =============================================================================================== claims
# Shorthand source labels
sA, sIE, sLC, sM2 = "rerun:analyze.py", "rerun:instrument_extra.py", "rerun:r2_link_check.py", "rerun:m2_from_counts.py"
sS7, sMT, sVR = "rerun:section7_from_aggregates.py", "rerun:make_tables_sector_surface.py", "rerun:vendor_reliance.py --offline"
sMP = "rerun:m2_from_counts.py (full precision via checks/m2_precise.py)"
dSR, dCP, dT2 = "data:single_reads_2026-10.csv", "data:section_code_pages_2026-10-14.csv", "data:instrument_series_table2 CSV"
dT3, dT5, dT6 = "data:instrument_series_table3 CSV", "data:instrument_series_table5 CSV", "data:instrument_series_table6 CSV"
dPX = "data:ahrefs/semrush_prefixes_2026-10-12.csv"
xAR, xSUP, xLS = "shipped:analyze_reviews_output.txt", "shipped:supplement_r10_output.txt", "shipped:r2_link_sample_output.txt"
xCS, xSE, xSE2 = "shipped:cross_sector_output.txt", "shipped:cross_sector_sensitivity_output.txt", "shipped:cross_sector_sensitivity2_output.txt"
xPI = "shipped:pilot_section_output.txt"
nUFI = "none:ufi repository and package not in the bundle"

# frequently used obtained values
an_min, an_max = g(A, r"min ([\d.]+)x \(/local/bundles/\)"), g(A, r"max ([\d.]+)x \(/local/area-codes/\)")
an_rho = g(A, r"rho\(age, visits ratio\) = ([+-][\d.]+)")
an_conc, an_pairs = g(A, r"(\d+) of (\d+) pairs concordant", 1), g(A, r"(\d+) of (\d+) pairs concordant", 2)
an_mmax = g(A, r"TERRITORY-MATCHED.*?max ([\d.]+)x")
ie_w3, ie_w3n = g(IE, r"within 3x: (\d+) of (\d+)", 1), g(IE, r"within 3x: (\d+) of (\d+)", 2)
ie_310 = g(IE, r"3x to 10x: (\d+) of (\d+)", 2)
ie_o10 = g(IE, r"over 10x: (\d+) of (\d+)", 2)
ie_o10a, ie_310a = g(IE, r"over 10x: (\d+) of", 1), g(IE, r"3x to 10x: (\d+) of", 1)
ie_g = re.findall(r"Ahrefs growth / Semrush US growth ([\d.]+)", IE)
ie_ga = re.findall(r"Ahrefs worldwide ([\d.]+)x; Semrush US ([\d.]+)x", IE)
mp_rho_m = float(g(MP, r"mentioned labels: rho ([\d.]+)"))
mp_int_m = [float(x) for x in re.search(r"interval, mentioned labels: \[([\d.]+), ([\d.]+)\]", MP).groups()]
mp_int_a = [float(x) for x in re.search(r"interval, all linkable labels: \[([\d.]+), ([\d.]+)\]", MP).groups()]
mp_mw = [float(x) for x in re.search(r"multi-word, branch split: rho ([\d.]+) \[([\d.]+), ([\d.]+)\]", MP).groups()]
s7_g = g(S7, r"Google views median ([\d.]+)%")
s7_c = g(S7, r"other four median ([\d.]+)%")
s7_surf = dict(re.findall(r"(\w+) ([\d.]+)%", g(S7, r"per surface: ([^\n]+)")))
s7_every = g(S7, r"highest other surface: (\d+)/11")
ratio_unm = {m: T2V[m]["us"] / T2V[m]["a"] for m in MONTHS}
ratio_ww = {m: T2V[m]["ww"] / T2V[m]["a"] for m in MONTHS}
US_SHARE = num(sr("Ahrefs' US share of its own visits")) / 100
ratio_uu = {m: T2V[m]["us"] / (T2V[m]["a"] * US_SHARE) for m in MONTHS}


def predictions_tally():
    p1 = "fails" in g(S7, r"P1 .*?-> (\w+)", 0)
    p2 = g(S7, r"P2 .*?-> (\w+)") == "holds"
    p3 = g(S7, r"P3 .*?-> (\w+)") == "holds"
    p4 = re.findall(r"P4 \w+: consumer ([\d.]+)% against other ([\d.]+)%; exact one-sided p ([\d.]+)", S7)
    p4_dir = all(float(a) > float(b) for a, b, _ in p4)
    p4_sig = any(float(p) < 0.05 for _, _, p in p4)
    held = int(p2) + int(p3)
    direction = int(p4_dir and not p4_sig)
    failed = int(p1) + int(not p3)
    return f"{held} held, {direction} held in direction only, {failed} failed", (held, direction, failed) == (1, 1, 2)


pt_str, pt_ok = predictions_tally()

# ---------------------------------------------------------------- Abstract
add("Abstract", "differed on estimated monthly visits by 7.5x to 27.1x", "7.5x", "arith:Table 2 (released CSV values)", min(ratio_unm.values()))
add("Abstract", "differed on estimated monthly visits by 7.5x to 27.1x", "27.1x", "arith:Table 2 (released CSV values)", max(ratio_unm.values()))
add("Abstract", "and by 8.6x to 29.9x with both read worldwide", "8.6x", "arith:Table 2 (released CSV values)", min(ratio_ww.values()))
add("Abstract", "and by 8.6x to 29.9x with both read worldwide", "29.9x", "arith:Table 2 (released CSV values)", max(ratio_ww.values()))
add("Abstract", "the ratio ran from 0.20x to 7.24x", "0.20x", sA, an_min)
add("Abstract", "the ratio ran from 0.20x to 7.24x", "7.24x", sA, an_max)
add("Abstract", "(Spearman −0.11, a test of low power", "−0.11", sA, an_rho)
add("Abstract", "is larger in 60 of 66 pairs", "60", sA, an_conc)
add("Abstract", "is larger in 60 of 66 pairs", "66", sA, an_pairs)
add("Abstract", "in only 9 of the 15 pairs within a factor of three", "9", sIE, ie_w3)
add("Abstract", "in only 9 of the 15 pairs within a factor of three", "15", sIE, ie_w3n)
add("Abstract", "On 37,193 reviews of 378 telecom stores", "37,193", xAR, g(AR, r"reviews with text: (\d+)"))
add("Abstract", "On 37,193 reviews of 378 telecom stores", "378", xAR, g(AR, r"businesses: (\d+)"))
add("Abstract", "linked to a 42,994-node keyword taxonomy", "42,994", xSUP, g(SUP, r"taxonomy nodes: (\d+)"))
add("Abstract", "(Spearman +0.47 to +0.75, depending on how labels are attributed to branches)", "+0.47", sM2, g(M2, r"modal attribution: rho=([+-][\d.]+)"))
add("Abstract", "(Spearman +0.47 to +0.75, depending on how labels are attributed to branches)", "+0.75", sM2, g(M2, r"split mentions: rho=([+-][\d.]+)"))
add("Abstract", "barely on topics (+0.19)", "+0.19", sMP, mp_rho_m,
    "prints +0.185; the full value 0.184869 is +0.18 to two decimals (double rounding)")
add("Abstract", "judged about two-thirds correct", "about two-thirds", sLC,
    (lambda v: (f"{min(v)}% to {max(v)}%", 60 <= min(v) and max(v) <= 70))([float(x) for x in re.findall(r"precision \d+/\d+ = ([\d.]+)%", g(LC, r"== A\.(.*?)items the two"))]))
add("Abstract", "four predictions written before collection yielded one held, one held in direction only and two failed",
    "1 held, 1 in direction only, 2 failed", sS7, (pt_str, pt_ok))
add("Abstract", "took a median 21% of citation incidences", "21%", sS7, s7_g)
add("Abstract", "against 0.6% to 9.2% on ChatGPT, Copilot, Perplexity and Gemini", "0.6%", sS7, min(float(s7_surf[p]) for p in ("chatgpt", "perplexity", "gemini", "copilot")))
add("Abstract", "against 0.6% to 9.2% on ChatGPT, Copilot, Perplexity and Gemini", "9.2%", sS7, max(float(s7_surf[p]) for p in ("chatgpt", "perplexity", "gemini", "copilot")))
add("Abstract", "with the lowest Google figure above the highest of the other four in every sector", "11 of 11", sS7, (f"{s7_every}/11", s7_every == "11"))

# ---------------------------------------------------------------- Section 1
add("§1 para 3", "in OpenAlex, 456 works name Ahrefs", "456", sVR, g(VR, r"; (\d+) name at least one tool"))
yr = dict(x.split(": ") for x in g(VR, r"by year: ([^\n]+)").split(", "))
add("§1 para 3", "27 of them published in 2020", "27", sVR, yr["2020"])
add("§1 para 3", "87 in 2025 and 110 in 2026", "87", sVR, yr["2025"])
add("§1 para 3", "87 in 2025 and 110 in 2026", "110", sVR, yr["2026"])
add("§1 para 3", "and 86% name only one of the three", "86%", sVR, g(VR, r"of \d+ \((\d+)%\); two or more"))
add("§1.1", "381 code pages plus hubs under a single prefix", "381", dCP, len(CP))
add("§1.1", "and observed for 77 days", "77", "arith:dates (26 Jul to 11 Oct 2026)", (31 - 26) + 31 + 30 + 11)
add("§1.1", "the other quantities at seven checkpoints", "7", dT5, (str(len(T5[0]) - 2), len(T5[0]) - 2 == 7), "Table 5 columns after day 0")
add("§1.2", "up to about 30 times worldwide", "about 30", "arith:Table 2 (released CSV values)", (f"{max(ratio_ww.values()):.1f}", round(max(ratio_ww.values())) == 30))
add("§1.2", "(33 times US to US, estimated)", "33", "arith:Table 2 x 81.5% (single read)", max(ratio_uu.values()))
add("§1.2 item 1", "differ on estimated visits by 7.5x to 27.1x (8.6x to 29.9x worldwide against worldwide)", "7.5x", "arith:Table 2 (released CSV values)", min(ratio_unm.values()))
add("§1.2 item 1", "differ on estimated visits by 7.5x to 27.1x (8.6x to 29.9x worldwide against worldwide)", "27.1x", "arith:Table 2 (released CSV values)", max(ratio_unm.values()))
add("§1.2 item 1", "differ on estimated visits by 7.5x to 27.1x (8.6x to 29.9x worldwide against worldwide)", "8.6x", "arith:Table 2 (released CSV values)", min(ratio_ww.values()))
add("§1.2 item 1", "differ on estimated visits by 7.5x to 27.1x (8.6x to 29.9x worldwide against worldwide)", "29.9x", "arith:Table 2 (released CSV values)", max(ratio_ww.values()))
add("§1.2 item 1", "the ratio spans 0.20x to 7.24x", "0.20x", sA, an_min)
add("§1.2 item 1", "the ratio spans 0.20x to 7.24x", "7.24x", sA, an_max)
add("§1.2 item 1", "the ordering of sections in 60 of 66 pairs", "60 of 66", sA, (f"{an_conc} of {an_pairs}", (an_conc, an_pairs) == ("60", "66")))
add("§1.2 item 2", "On 37,193 business reviews linked to a 42,994-node keyword taxonomy", "37,193", xAR, g(AR, r"reviews with text: (\d+)"))
add("§1.2 item 2", "On 37,193 business reviews linked to a 42,994-node keyword taxonomy", "42,994", xSUP, g(SUP, r"taxonomy nodes: (\d+)"))
add("§1.2 item 3", "(21.3% against 2.1%)", "21.3%", sS7, s7_g)
add("§1.2 item 3", "(21.3% against 2.1%)", "2.1%", sS7, s7_c)
add("§1.2 item 3", "about ten times their pooled median share", "about ten times", sS7, (f"{float(s7_g) / float(s7_c):.1f}", round(float(s7_g) / float(s7_c)) == 10))
hub = {k: n_(sr(f"stored AI answers citing the page: {k}")) for k in ("New York state hub", "California state hub", "Texas state hub", "Florida state hub", "national hub", "214 (Dallas) code page", "786 (Miami) code page", "404 (Atlanta) code page")}
hubs = [hub[k] for k in hub if "hub" in k]
top_code = max(hub[k] for k in hub if "code page" in k)
add("§1.2 item 5", "(1.2 to 2.0 times the most-cited one)", "1.2", "arith:single reads (Figure 8 values)", min(hubs) / top_code)
add("§1.2 item 5", "(1.2 to 2.0 times the most-cited one)", "2.0", "arith:single reads (Figure 8 values)", max(hubs) / top_code)
add("§1.2 item 5", "a 77-day series", "77", "arith:dates (26 Jul to 11 Oct 2026)", 77)
add("§1.3", "an Ahrefs Domain Rating of 90 and a Semrush Authority Score of 86", "90", dSR, sr("Domain Rating of the domain"))
add("§1.3", "an Ahrefs Domain Rating of 90 and a Semrush Authority Score of 86", "86", dSR, sr("Authority Score of the domain"))
add("§1.4 item 1", "The implementation declares thirteen surface types", "13", nUFI, None, "make_fig0.py draws 13 types (10 + 3), consistent")

# ---------------------------------------------------------------- Section 3
geo = [r for r in CP if r["registry_use"] == "G"]
add("§3", "fetching every code page linked from the section's 52 state hubs", "52", dCP, len({r["location"] for r in CP}),
    "the hub list itself is not released; the released code list has 52 registry locations, which the paper equates with the hubs")
add("§3", "the section holds 381 code pages**", "381", dCP, len(CP))
add("§3", "374 for geographic codes assigned to US states", "374", dCP, len(geo))
add("§3", "(all 372 in service and two assigned but not yet in service)", "372", dCP, sum(r["in_service"] == "Y" for r in geo))
add("§3", "(all 372 in service and two assigned but not yet in service)", "2", dCP, sum(r["in_service"] != "Y" for r in geo))
add("§3", "and 7 for toll-free codes", "7", dCP, sum(r["registry_use"] == "N" for r in CP))
add("§3", "which takes 52 values", "52", dCP, len({r["location"] for r in CP}))
add("§3", "found the same 381 and matched them", "381", dCP, len(CP))
add("§3", "are the six assigned to US territories and 451", "6; 451 (15 Sep 2026)", "none:numbering-plan registry not released (the released list holds only codes with pages)", None)
add("§3", "(210, 365, 391, 414, 440)", "210, 365, 391, 414, 440", dT5, ", ".join(T5V["Pages holding a position"][1:3] + T5V["Pages holding a position"][4:7]), exact=True)
add("§3", "a fixed set of 434 URLs", "434", "arith:381 code pages + 53 hubs", len(CP) + 53)
add("§3", "**441** is the number of URLs under the prefix", "441", dT5, t5("Pages holding a position", 77))
add("§3", "it exceeds 381 plus the 53 hub pages by seven", "7", "arith:441 - 434", n_(t5("Pages holding a position", 77)) - (len(CP) + 53))
add("§3", "Brand Radar's count of 455 distinct cited pages", "455", dSR, sr("distinct pages under the prefix cited"))
add("§3", "exceeds 434 by 21", "21", "arith:455 - 434", n_(sr("distinct pages under the prefix cited")) - 434)
add("§3.1 item 4", "Ahrefs Domain Rating 90, Semrush Authority Score 86", "90", dSR, sr("Domain Rating of the domain"))
add("§3.1 item 4", "Ahrefs Domain Rating 90, Semrush Authority Score 86", "86", dSR, sr("Authority Score of the domain"))
add("§3.1 item 5", "Two carriers at Domain Rating 87 and 91", "87 and 91", dSR, sr("Domain Ratings of the two national carriers"), exact=True)
add("§3.1 item 6", "voice vendors at Domain Rating 13 to 83", "13 to 83", dSR, sr("Domain Rating of the five domains"), exact=True)

# ---------------------------------------------------------------- Section 4
add("§4.1", "The section ranks in 105 countries", "105", dSR, sr("countries in which the section ranks"))
add("§4.1", "with 18.5% of Ahrefs' estimated visits from outside the US", "18.5%", dSR, sr("share of Ahrefs-estimated visits from outside the US"))
add("§4.1", "(18.6% in the 12 October read of Table 4)", "18.6%", dPX, 100 * (1 - us["/local/area-codes/"]))
add("§4.1", "is nonetheless between 7.5 and 27.1 times larger", "7.5", "arith:Table 2 (released CSV values)", min(ratio_unm.values()))
add("§4.1", "is nonetheless between 7.5 and 27.1 times larger", "27.1", "arith:Table 2 (released CSV values)", max(ratio_unm.values()))
add("§4.1", "worldwide over worldwide (8.6x to 29.9x)", "8.6x", "arith:Table 2 (released CSV values)", min(ratio_ww.values()))
add("§4.1", "worldwide over worldwide (8.6x to 29.9x)", "29.9x", "arith:Table 2 (released CSV values)", max(ratio_ww.values()))
add("§4.1", "and US over US (9.2x to 33.3x)", "9.2x", "arith:Table 2 x 81.5% (single read)", min(ratio_uu.values()))
add("§4.1", "and US over US (9.2x to 33.3x)", "33.3x", "arith:Table 2 x 81.5% (single read)", max(ratio_uu.values()))
add("§4.1", "Ahrefs' US share of its own visits, 81.5%", "81.5%", dSR, sr("Ahrefs' US share of its own visits"))
add("§4.1 Table 1", "| Ranking keywords | distinct keywords on which any URL under the prefix ranks 1–100 | Ahrefs (all locations); Semrush (US database, and worldwide) | 11 Oct; 10 Oct (worldwide 12 Oct) 2026 |",
    "11 Oct; 10 Oct; 12 Oct", dSR, "; ".join(x[8:10].lstrip("0") + " Oct" for x in (
        [r["read date as stated in the paper"] for r in SRR if r["quantity"].startswith("distinct keywords") and "all locations" in r["quantity"]] +
        [r["read date as stated in the paper"] for r in SRR if r["quantity"].startswith("distinct keywords") and "US database" in r["quantity"]] +
        [r["read date as stated in the paper"] for r in SRR if r["quantity"].startswith("distinct keywords") and "worldwide" in r["quantity"]])), exact=True)
add("§4.3", "began on 24 September, day 60", "day 60 = 24 Sep", "arith:dates", ("26 Jul + 60 days = 24 Sep", (31 - 26) + 31 + 24 == 60))
add("§4.3", "Ahrefs posted a notice on 29 September, day 65", "day 65 = 29 Sep", "arith:dates", ("26 Jul + 65 days = 29 Sep", (31 - 26) + 31 + 29 == 65))
add("§4.3", "**Day 37 (1 September 2026) is the primary checkpoint**", "day 37 = 1 Sep", "arith:dates", ("26 Jul + 37 days = 1 Sep", (31 - 26) + 31 + 1 == 37))
add("§4.3", "the 11 October read gives four of the nine quantities for it", "4 of 9", dT5,
    (lambda col: (f"{sum(v != 'n/r' for v in col)} of {len(col)}", (sum(v != 'n/r' for v in col), len(col)) == (4, 9)))([T5V[k][3] for k in T5V]))

# ---------------------------------------------------------------- Table 2: manuscript cells against the released CSV
def md_table(caption_start):
    i = MS.index(caption_start)
    block = MS[i:].split("\n\n")[1]
    return [[c.strip() for c in ln.strip().strip("|").split("|")] for ln in block.splitlines()
            if ln.startswith("|") and not ln.startswith("|---")]


for label, md, rel in (("Table 2", md_table("*Table 2."), T2), ("Table 3", md_table("*Table 3."), T3),
                       ("Table 5", md_table("*Table 5."), T5), ("Table 6", md_table("*Table 6."), T6)):
    for i, (mr, cr) in enumerate(zip(md[1:], rel[1:])):
        for j, (mc, cc) in enumerate(zip(mr[1:], cr[1:]), start=1):
            mcs = mc.replace("**", "")
            add(f"{label}, row '{mr[0].replace('**', '')}', column '{md[0][j].replace('**', '')}'", mc, mcs,
                f"data:released CSV of {label} (instrument_divergence_extra/)", cc, exact=True,
                note="" if mcs == cc else "the released CSV was not regenerated after edit_v52n.py corrected the manuscript")
# Table 2 ratio columns recomputed from the CSV values
for m in MONTHS:
    row = [r for r in md_table("*Table 2.") if r[0].startswith(m)][0]
    add(f"Table 2, {m}, Semrush US / Ahrefs worldwide", row[4], row[4], "arith:Table 2 values", ratio_unm[m])
    add(f"Table 2, {m}, worldwide vs worldwide", row[5], row[5], "arith:Table 2 values", ratio_ww[m])
    add(f"Table 2, {m}, US vs US (estimated)", row[6], row[6], "arith:Table 2 values x 81.5%", ratio_uu[m])
add("Table 2, days-live column", "11 (78 in all, days 0 to 77)", "78", "arith:Table 2 days-live column", sum(int(T2V[k]["days"].split()[0]) for k in T2V))
add("Table 2 caption", "times 81.5%, Ahrefs' US share read on 11 October", "81.5%", dSR, sr("Ahrefs' US share of its own visits"))
# Table 3 arithmetic
for m in MONTHS:
    row = [r for r in md_table("*Table 3.") if r[0].startswith(m)][0]
    k, n, b = T3V[m]["k"], T3V[m]["n"], T3V[m]["b"]
    pct, lo, hi = re.match(r"([\d.]+)% \[([\d.]+), ([\d.]+)\]", row[2]).groups()
    lo_, hi_ = wilson(k, n)
    add(f"Table 3, {m}, share", row[2], pct + "%", "arith:Table 3 counts", 100 * k / n)
    add(f"Table 3, {m}, Wilson lower", row[2], lo, "arith:Wilson on Table 3 counts", 100 * lo_)
    add(f"Table 3, {m}, Wilson upper", row[2], hi, "arith:Wilson on Table 3 counts", 100 * hi_)
    add(f"Table 3, {m}, (b)/(a)", row[4], row[4], "arith:Table 3 counts", b / k)

# ---------------------------------------------------------------- Section 5.1 to 5.4
add("§5.1", "(8.4x on Ahrefs, 8.8x on Semrush US)", "8.4x", sIE, ie_ga[0][0])
add("§5.1", "(8.4x on Ahrefs, 8.8x on Semrush US)", "8.8x", sIE, ie_ga[0][1])
add("§5.1", "Ahrefs' estimate grew 4.65x and Semrush's 1.75x", "4.65x", sIE, ie_ga[1][0])
add("§5.1", "Ahrefs' estimate grew 4.65x and Semrush's 1.75x", "1.75x", sIE, ie_ga[1][1])
add("§5.1", "into October's run-rate 1.44x against 1.05x", "1.44x", sIE, ie_ga[2][0])
add("§5.1", "into October's run-rate 1.44x against 1.05x", "1.05x", sIE, ie_ga[2][1])
add("§5.1", "by a factor of more than two", "more than 2", sIE, (ie_g[1], float(ie_g[1]) > 2))
add("§5.1", "the section draws 18.5% of its Ahrefs-estimated visits from outside the US", "18.5%", dSR, sr("share of Ahrefs-estimated visits from outside the US"))
add("§5.1", "worldwide against worldwide it runs from 8.6x to 29.9x", "8.6x", "arith:Table 2 values", min(ratio_ww.values()))
add("§5.1", "worldwide against worldwide it runs from 8.6x to 29.9x", "29.9x", "arith:Table 2 values", max(ratio_ww.values()))
add("§5.1", "and US against US, estimated, from 9.2x to 33.3x", "9.2x", "arith:Table 2 values x 81.5%", min(ratio_uu.values()))
add("§5.1", "and US against US, estimated, from 9.2x to 33.3x", "33.3x", "arith:Table 2 values x 81.5%", max(ratio_uu.values()))
for v, m in (("27.1x", "August"), ("10.2x", "September"), ("7.5x", "October")):
    add("§5.1", "from 27.1x to 10.2x to 7.5x", v, "arith:Table 2 values", ratio_unm[m])
add("§5.2", "Ahrefs reports 29,000 for all locations", "29,000", dSR, sr("ranks 1 to 100 (all locations)"))
add("§5.2", "Semrush 58,586 for the US database", "58,586", dSR, sr("ranks 1 to 100 (US database)"))
add("§5.2", "a factor of 2.0, again with the larger figure", "2.0", "arith:58,586 / 29,000", 58586 / 29000)
add("§5.2", "is 92.3K (the interface rounds to the hundred)", "92.3K", dSR, sr("ranks 1 to 100 (worldwide)"), exact=True)
add("§5.2", "3.2 times Ahrefs' 28,900 for all locations", "3.2", "arith:92,300 / 28,900", 92300 / akw["/local/area-codes/"])
add("§5.2", "3.2 times Ahrefs' 28,900 for all locations", "28,900", dPX, akw["/local/area-codes/"])
add("§5.2", "Pages holding at least one position are 441 in Ahrefs", "441", dT5, t5("Pages holding a position", 77))
add("§5.3", "Brand Radar's 17,206 stored answers citing the section", "17,206", dT5, t5("AI answers citing the section", 77))
add("§5.3", "Semrush's 158,100 mentions read on 10 October", "158,100", dSR, sr("mentions in the AI-visibility panel", "2026-10-10"))
add("§5.3", "differ by a factor of 9.2", "9.2", "arith:158,100 / 17,206", 158100 / 17206)
add("§5.3", "companion count of 29,600 cited pages", "29,600", dSR, sr("cited pages in the AI-visibility panel", "2026-10-10"))
add("§5.3", "is 68 times the 434 URLs the section holds", "68", "arith:29,600 / 434", 29600 / 434)
add("§5.3", "The Ahrefs figure of 17,206 stored answers", "17,206", dT5, t5("AI answers citing the section", 77))
add("§5.3 Figure 3 caption", "the denominators grow from 284 to 37,238", "284", dT3, T3V["July"]["n"])
add("§5.3 Figure 3 caption", "the denominators grow from 284 to 37,238", "37,238", dT3, T3V["October"]["n"])
add("§5.3", "falls from 2.94 to 1.34 over four months", "2.94", "arith:Table 3 counts", T3V["July"]["b"] / T3V["July"]["k"])
add("§5.3", "falls from 2.94 to 1.34 over four months", "1.34", "arith:Table 3 counts", T3V["October"]["b"] / T3V["October"]["k"])
add("§5.3", "The July row rests on 47 events over six days live", "47", dT3, T3V["July"]["k"])
add("§5.3", "The July row rests on 47 events over six days live", "6", dT2, T2V["July"]["days"])
add("§5.3", "two orders of magnitude across the series, from 284 to 37,238", "two orders of magnitude", "arith:37,238 / 284",
    (f"{T3V['October']['n'] / T3V['July']['n']:.0f}x", 100 <= T3V["October"]["n"] / T3V["July"]["n"] < 1000))
add("§5.4", "Ahrefs reports 913 referring domains to the prefix", "913", dSR, sr("live referring domains to the prefix"))
add("§5.4", "Semrush Backlink Analytics indexes 80 for the subfolder", "80", dSR, sr("referring domains to the subfolder"))
add("§5.4", "80 for the subfolder: a factor of 11.4", "11.4", "arith:913 / 80", 913 / 80)
add("§5.4", "Ahrefs puts 61.9% on .info", "61.9%", dSR, sr("share of those referring domains on .info"))
add("§5.4", "26.4% on .asia", "26.4%", dSR, sr("share of those referring domains on .asia"))
add("§5.4", "and 10.2% on .xyz", "10.2%", dSR, [r["value"] for r in SRR if r["quantity"] == "share of those referring domains on .xyz" and r["instrument"] == "Ahrefs Site Explorer"][0])
add("§5.4", "Semrush puts 75% on .xyz", "75%", dSR, [r["value"] for r in SRR if r["quantity"] == "share of those referring domains on .xyz" and r["instrument"].startswith("Semrush")][0])
add("§5.4", "and 88% at Authority Score 0 to 10", "88%", dSR, sr("Authority Score 0 to 10"))
add("§5.4 Figure 4 caption", "Ahrefs: 913 domains; Semrush Backlink Analytics: 80 domains", "913", dSR, sr("live referring domains to the prefix"))
add("§5.4 Figure 4 caption", "Ahrefs: 913 domains; Semrush Backlink Analytics: 80 domains", "80", dSR, sr("referring domains to the subfolder"))
add("§5.4 Figure 4 caption", "the instrument reports 75% on .xyz", "75%", dSR, [r["value"] for r in SRR if r["quantity"] == "share of those referring domains on .xyz" and r["instrument"].startswith("Semrush")][0])
add("§5.4", "its daily series gives 909 at day 75", "909", dT5, t5("Live referring domains", 75))
add("§5.4", "against 913 on 11 October", "913", dT5, t5("Live referring domains", 77))
add("§5.4", "gives 917 new against 95 lost", "917", dSR, sr("new referring domains in September"))
add("§5.4", "gives 917 new against 95 lost", "95", dSR, sr("lost referring domains in September"))
add("§5.4", "which with nineteen at day 37 implies about 841", "19", dT5, t5("Live referring domains", 37))
add("§5.4", "which with nineteen at day 37 implies about 841", "841", "arith:19 + 917 - 95", 19 + 917 - 95)

# ---------------------------------------------------------------- Section 5.5: Table 4 against the released prefix data
T4 = md_table("*Table 4.")
ie_t4 = {m.group(1): m.groups() for m in re.finditer(r"  (/\S+)\s+(\d+)\s+([\d.]+)%\s+([\d.]+)x\s+([\d.]+)x\s+([\d.]+)x\s+([\d.]+)x", IE)}
for row in T4[1:]:
    p = row[0]
    calc = [age(p), at[p], st[p], st[p] / at[p], 100 * us[p], st[p] / (at[p] * us[p]), akw[p], skw[p], skw[p] / akw[p], ard[p], srd[p], ard[p] / srd[p]]
    for j, (cell, v) in enumerate(zip(row[1:], calc), start=1):
        add(f"Table 4, {p}, {T4[0][j]}", cell, cell.replace("**", ""), dPX, v)
    # the same row as instrument_extra.py prints it
    if p in ie_t4:
        _, a_, u_, vr_, mt_, kr_, rd_ = ie_t4[p]
        for j, v in ((1, a_), (4, vr_), (5, u_), (6, mt_), (9, kr_), (12, rd_)):
            add(f"Table 4, {p}, {T4[0][j]} (as printed by instrument_extra.py)", row[j], row[j].replace("**", ""), sIE, v)
add("Table 4 caption", "and the next two lie within four months of it", "within four months", dPX,
    (f"{age('/es-us/local/') - age('/deals/')} and {age('/es-us/local/') - age('/stores/')} months", max(age("/es-us/local/") - age(p) for p in ("/deals/", "/stores/")) <= 4))
for v, src_, got in (("29,000", dSR, sr("ranks 1 to 100 (all locations)")), ("58,586", dSR, sr("ranks 1 to 100 (US database)")),
                     ("80", dSR, sr("referring domains to the subfolder")), ("11.4x", "arith:913 / 80", 913 / 80)):
    add("Table 4 caption", "(29,000 and 58,586 keywords; 80 Semrush domains, 11.4x)", v, src_, got)
add("§5.5 Figure 5 caption", "(a) The Semrush over Ahrefs ratio", "12 prefixes", dPX, (str(len(AH)), len(AH) == 12))
P55 = "§5.5 para 'no detectable relationship'"
add(P55, "and the unmatched visits ratio is −0.11 over twelve prefixes", "−0.11", sA, an_rho)
add(P55, "with a Fisher 95% interval of −0.64 to +0.49", "−0.64", sA, g(A, r"Fisher 95% CI \[([+-][\d.]+),"))
add(P55, "with a Fisher 95% interval of −0.64 to +0.49", "+0.49", sA, g(A, r"Fisher 95% CI \[[+-][\d.]+, ([+-][\d.]+)\]"))
add(P55, "and a permutation p of 0.73", "0.73", sA, g(A, r"permutation p = ([\d.]+)"))
add(P55, "territory-matched it is −0.28", "−0.28", sA, g(A, r"rho\(age, ratio\) = ([+-][\d.]+)"))
add(P55, "excluding the area-code section it is +0.15", "+0.15", sA, g(A, r"excluding the area-code section: rho = ([+-][\d.]+)"))
add(P55, "Twelve prefixes give about 38% power", "38%", sIE, g(IE, r"\(Fisher approximation\): ([\d.]+)%"))
add(P55, "(37.8% by the Fisher approximation)", "37.8%", sIE, g(IE, r"\(Fisher approximation\): ([\d.]+)%"))
add(P55, "the seven sections aged between seven and eleven years", "7", sIE, g(IE, r"seven to eleven years: (\d+)"))
add(P55, "sit anywhere from 0.25x to 6.57x unmatched", "0.25x", sIE, g(IE, r"unmatched ratio ([\d.]+)x to [\d.]+x; matched"))
add(P55, "sit anywhere from 0.25x to 6.57x unmatched", "6.57x", sIE, g(IE, r"unmatched ratio [\d.]+x to ([\d.]+)x; matched"))
add(P55, "(0.46x to 6.61x matched)", "0.46x", sIE, g(IE, r"; matched ([\d.]+)x to"))
add(P55, "(0.46x to 6.61x matched)", "6.61x", sIE, g(IE, r"; matched [\d.]+x to ([\d.]+)x"))
add(P55, "from 27.1x to 7.5x over three months", "27.1x", "arith:Table 2 values", ratio_unm["August"])
add(P55, "from 27.1x to 7.5x over three months", "7.5x", "arith:Table 2 values", ratio_unm["October"])
add(P55, "Only one prefix in the cross-section is under twenty-one months old", "1", sIE, g(IE, r"under twenty-one months old: (\d+)"))
P55b = "§5.5 para 'prefix-specific'"
add(P55b, "one fifth of Ahrefs' (/local/bundles/, 0.20x)", "0.20x", sA, an_min)
add(P55b, "to seven times it (/local/area-codes/, 7.24x)", "7.24x", sA, an_max)
add(P55b, "a spread of 1.55 orders of magnitude", "1.55", sA, g(A, r"spread ([\d.]+) decades"))
add(P55b, "with a median of 1.01", "1.01", sA, g(A, r"median ([\d.]+), spread"))
add(P55b, "and six of twelve prefixes below one", "6", sA, g(A, r"below one: (\d+) of"))
add(P55b, "Matched for territory the spread is wider (0.20x to 8.89x)", "0.20x", sA, g(A, r"TERRITORY-MATCHED[^:]*: min ([\d.]+)x"))
add(P55b, "Matched for territory the spread is wider (0.20x to 8.89x)", "8.89x", sA, an_mmax)
add(P55b, "the median is 1.06", "1.06", sA, g(A, r"TERRITORY-MATCHED.*?median ([\d.]+)"))
add(P55b, "and four of twelve are below one", "4", sA, g(A, r"below one (\d+) of 12; rho"))
add(P55b, "two of the six sub-one prefixes cross one", "2", sA, int(g(A, r"below one: (\d+) of")) - int(g(A, r"below one (\d+) of 12; rho")))
for p, u_, a1, a2 in (("/product-compare/", "69.6%", "0.75x", "1.07x"), ("/device-compare/", "82.6%", "0.99x", "1.20x"), ("/es-us/local/", "42.6%", "0.25x", "0.58x")):
    add(P55b, f"{p}, {u_} US" if p != "/es-us/local/" else "/es-us/local/, at 42.6% US, moves from 0.25x to 0.58x", u_, sIE, ie_t4[p][2])
    add(P55b, f"from {a1} to {a2}", a1, sIE, ie_t4[p][3])
    add(P55b, f"from {a1} to {a2}", a2, sIE, ie_t4[p][4])
add(P55b, "has a geometric mean of 1.13", "1.13", sIE, g(IE, r"geometric mean of the ratio ([\d.]+)x"))
add(P55b, "(bootstrap 95% interval 0.62 to 2.12)", "0.62", sIE, g(IE, r"geometric mean of the ratio [\d.]+x \[([\d.]+)x"))
add(P55b, "(bootstrap 95% interval 0.62 to 2.12)", "2.12", sIE, g(IE, r"geometric mean of the ratio [\d.]+x \[[\d.]+x, ([\d.]+)x\]"))
add(P55b, "a geometric standard deviation of 3.1 (1.9 to 4.1)", "3.1", sIE, g(IE, r"geometric SD ([\d.]+) \["))
add(P55b, "a geometric standard deviation of 3.1 (1.9 to 4.1)", "1.9", sIE, g(IE, r"geometric SD [\d.]+ \[([\d.]+),"))
add(P55b, "a geometric standard deviation of 3.1 (1.9 to 4.1)", "4.1", sIE, g(IE, r"geometric SD [\d.]+ \[[\d.]+, ([\d.]+)\]"))
add(P55b, "a normal range on the log scale of about 0.12x to 10.6x", "0.12x", sIE, g(IE, r"not a prediction\) ([\d.]+)x to"))
add(P55b, "a normal range on the log scale of about 0.12x to 10.6x", "10.6x", sIE, g(IE, r"not a prediction\) [\d.]+x to ([\d.]+)x"))
P55c = "§5.5 para 'ordering'"
add(P55c, "visit estimates is +0.94 (bootstrap 95% interval over prefixes +0.70 to +1.00", "+0.94", sIE, g(IE, r"Spearman \(ordering\) ([+-][\d.]+)"))
add(P55c, "visit estimates is +0.94 (bootstrap 95% interval over prefixes +0.70 to +1.00", "+0.70", sIE, g(IE, r"Spearman \(ordering\) [+-][\d.]+ \[([+-][\d.]+),"))
add(P55c, "visit estimates is +0.94 (bootstrap 95% interval over prefixes +0.70 to +1.00", "+1.00", sIE, g(IE, r"Spearman \(ordering\) [+-][\d.]+ \[[+-][\d.]+, ([+-][\d.]+)\]"))
add(P55c, "p < 0.001; Kendall's tau +0.82", "p < 0.001", sIE, (g(IE, r"Spearman \+0\.937 \(p=([\d.e-]+)\)"), float(g(IE, r"Spearman \+0\.937 \(p=([\d.e-]+)\)")) < 0.001))
add(P55c, "p < 0.001; Kendall's tau +0.82", "+0.82", sIE, g(IE, r"Kendall ([+-][\d.]+) \[[+-]"))
add(P55c, "interval +0.57 to +1.00; 60 of 66 pairs concordant", "+0.57", sIE, g(IE, r"Kendall [+-][\d.]+ \[([+-][\d.]+),"))
add(P55c, "interval +0.57 to +1.00; 60 of 66 pairs concordant", "+1.00", sIE, g(IE, r"Kendall [+-][\d.]+ \[[+-][\d.]+, ([+-][\d.]+)\]"))
add(P55c, "interval +0.57 to +1.00; 60 of 66 pairs concordant", "60 of 66", sA, (f"{an_conc} of {an_pairs}", (an_conc, an_pairs) == ("60", "66")))
add(P55c, "The vendors agree on which section is larger in 60 of 66 pairs", "60 of 66", sA, (f"{an_conc} of {an_pairs}", (an_conc, an_pairs) == ("60", "66")))
add(P55c, "differ by more than a factor of three, all 51 are ordered alike", "51", sIE, int(ie_310) + int(ie_o10), "19 of 19 (3x to 10x) + 32 of 32 (over 10x)")
add(P55c, "differ by more than a factor of three, all 51 are ordered alike", "all", sIE, (f"{int(ie_310a) + int(ie_o10a)} of {int(ie_310) + int(ie_o10)}", ie_310a == ie_310 and ie_o10a == ie_o10))
add(P55c, "of the 15 pairs within a factor of three, 9 are", "15", sIE, ie_w3n)
add(P55c, "of the 15 pairs within a factor of three, 9 are", "9", sIE, ie_w3)
P55d = "§5.5 para 'keyword universes'"
add(P55d, "by between 2.0x and 20.9x", "2.0x", sA, g(A, r"keyword ratio Semrush/Ahrefs: min ([\d.]+)x"))
add(P55d, "by between 2.0x and 20.9x", "20.9x", sA, g(A, r"keyword ratio Semrush/Ahrefs: min [\d.]+x, max ([\d.]+)x"))
add(P55d, "Semrush reports more ranking keywords than Ahrefs on every prefix", "every prefix", sA, ("all above one" , "all above one" in A))
add(P55d, "the visits ratio is +0.17 over all twelve", "+0.17", sA, g(A, r"rho\(keyword ratio, visits ratio\) = ([+-][\d.]+)"))
add(P55d, "and +0.52 with the area-code section excluded", "+0.52", sA, g(A, r"excluding area-codes ([+-][\d.]+)"))
add(P55d, "/local/bundles/ has the second-largest keyword ratio (16.1x)", "16.1x", sIE, g(IE, r"largest two: /stores/ [\d.]+x, /local/bundles/ ([\d.]+)x"))
add(P55d, "/local/bundles/ has the second-largest keyword ratio (16.1x)", "second-largest", sIE, ("second", "/local/bundles/" in g(IE, r"keyword ratio, largest two: \S+ [\d.]+x, (\S+)")))
add(P55d, "and the smallest visits ratio (0.20x)", "0.20x", sA, g(A, r"min ([\d.]+)x \((/local/bundles/)\)"))
add(P55d, "(two-sided p = 0.60 over all twelve", "0.60", sIE, g(IE, r"all twelve prefixes \(n=12\): Spearman [+-][\d.]+; two-sided p ([\d.]+) \(t"))
add(P55d, "and 0.10 without the area-code section", "0.10", sIE, g(IE, r"without /local/area-codes/ \(n=11\): Spearman [+-][\d.]+; two-sided p ([\d.]+) \(t"),
    "t approximation; the permutation p printed beside it is 0.11")
P55e = "§5.5 para 'studied section'"
add(P55e, "It has the highest visits ratio (7.24x unmatched, 8.89x matched", "7.24x", sA, an_max)
add(P55e, "It has the highest visits ratio (7.24x unmatched, 8.89x matched", "8.89x", sA, an_mmax)
add(P55e, "/stores/ is next at 6.57x", "6.57x", sA, g(A, r"second ([\d.]+)x \(/stores/\)"))
add(P55e, "and the highest referring-domain ratio (11.3x)", "11.3x", sIE, g(IE, r"largest two: /local/area-codes/ ([\d.]+)x"))
add(P55e, "Semrush's AI-visibility panel reported 158.3K mentions and 29.5K cited pages", "158.3K", dSR, sr("mentions in the AI-visibility panel (identical"), exact=True)
add(P55e, "Semrush's AI-visibility panel reported 158.3K mentions and 29.5K cited pages", "29.5K", dSR, sr("cited pages in the AI-visibility panel (identical"), exact=True)
add(P55e, "(Section 5.3 quotes the 10 October read of 158,100 and 29,600)", "158,100", dSR, sr("mentions in the AI-visibility panel", "2026-10-10"))
add(P55e, "(Section 5.3 quotes the 10 October read of 158,100 and 29,600)", "29,600", dSR, sr("cited pages in the AI-visibility panel", "2026-10-10"))

# ---------------------------------------------------------------- Section 5.6
add("§5.6", "At the August ratio of 27.1x", "27.1x", "arith:Table 2 values", ratio_unm["August"])
add("§5.6", "within a factor of 5.2, the square root of 27.1", "5.2", "arith:sqrt of the August ratio", math.sqrt(ratio_unm["August"]))
add("§5.6", "the larger of the two errors is at least 13 times the smaller reading", "13", "arith:(876,153 - 32,281) / 2 / 32,281", (T2V["August"]["us"] - T2V["August"]["a"]) / 2 / T2V["August"]["a"], tol=0.5)
for v, m in (("27.1", "August"), ("10.2", "September"), ("7.5", "October")):
    add("§5.6", "The ratio falls 27.1 → 10.2 → 7.5 over three months", v, "arith:Table 2 values", ratio_unm[m])
dec = re.search(r"visits ([\d.]+)x = keywords ([\d.]+)x x per-keyword ([\d.]+)x; keyword share of log ratio (\d+)%", IE).groups()
dec2 = re.findall(r"visits ([\d.]+)x = keywords ([\d.]+)x x per-keyword ([\d.]+)x; keyword share of log ratio (\d+)%", IE)[1]
for v, o in zip(("7.47x", "2.02x", "3.70x"), dec[:3]):
    add("§5.6", "7.47x = 2.02x (keyword universe) × 3.70x (estimated visits per ranking keyword)", v, sIE, o)
add("§5.6", "accounts for about 35% of the divergence in log terms", "35%", sIE, dec[3])
for v, o in zip(("8.62x", "3.19x", "2.70x"), dec2[:3]):
    add("§5.6", "it is 8.62x = 3.19x (keyword universe) × 2.70x (per keyword)", v, sIE, o)
add("§5.6", "and the keyword universe accounts for about 54%", "54%", sIE, dec2[3])
add("§5.6", "Matching worldwide to worldwide gives 8.62x for October", "8.62x", "arith:Table 2 values", ratio_ww["October"])
add("§5.6", "and 26.7x to 29.9x in the first two months", "26.7x", "arith:Table 2 values", ratio_ww["July"])
add("§5.6", "and 26.7x to 29.9x in the first two months", "29.9x", "arith:Table 2 values", ratio_ww["August"])
add("§5.6", "deflating the Ahrefs figure by the 18.5% non-US share", "18.5%", dSR, sr("share of Ahrefs-estimated visits from outside the US"))
add("§5.6", "gives **9.17x** for October", "9.17x", "arith:Table 2 values x 81.5%", ratio_uu["October"])
add("§5.6", "for October against the 7.5x unmatched", "7.5x", "arith:Table 2 values", ratio_unm["October"])
for v, m in (("31.8x", "July"), ("33.3x", "August"), ("12.5x", "September")):
    add("§5.6", "gives 31.8x, 33.3x and 12.5x (Table 2)", v, "arith:Table 2 values x 81.5%", ratio_uu[m])
add("§5.6", "spans 0.20x to 7.24x (0.20x to 8.89x territory-matched)", "0.20x", sA, an_min)
add("§5.6", "spans 0.20x to 7.24x (0.20x to 8.89x territory-matched)", "7.24x", sA, an_max)
add("§5.6", "spans 0.20x to 7.24x (0.20x to 8.89x territory-matched)", "8.89x", sA, an_mmax)
add("§5.6", "which of two sections is larger in 60 of 66 pairs", "60 of 66", sA, (f"{an_conc} of {an_pairs}", (an_conc, an_pairs) == ("60", "66")))
add("§5.6", "within a factor of three (9 of 15 pairs)", "9 of 15", sIE, (f"{ie_w3} of {ie_w3n}", (ie_w3, ie_w3n) == ("9", "15")))
opp = re.findall(r"ordered oppositely: .*?\(([\d.]+)x\); Semrush .*?\(([\d.]+)x\); three or more times apart", IE)
add("§5.6", "two pairs six to seven times apart were ordered the other way on the second", "two pairs, 6x to 7x apart", sIE,
    (f"{len(opp)} pairs: " + ", ".join(f"{max(map(float, x)):.1f}x" for x in opp), len(opp) == 2 and all(6 <= max(map(float, x)) < 8 for x in opp)))
add("§5.6", "can differ by a factor of five below to nearly nine above", "five below", sA, (f"1/{an_min} = {1 / float(an_min):.1f}", round(1 / float(an_min)) == 5))
add("§5.6", "can differ by a factor of five below to nearly nine above", "nearly nine above", sA, (an_mmax, 8.5 <= float(an_mmax) < 9))
add("§5.6", "also differed, by a factor of 2.7 in one month", "2.7", sIE, ie_g[1])
add("§5.6 limits", "from a factor of five below to nearly nine above, that no relationship", "five below to nearly nine above", sA, (f"{an_min}x to {an_mmax}x", round(1 / float(an_min)) == 5 and 8.5 <= float(an_mmax) < 9))
add("§5.6 limits", "only one of them under twenty-one months old", "1", sIE, g(IE, r"under twenty-one months old: (\d+)"))

# ---------------------------------------------------------------- Section 6
P6 = "§6 para 1"
add(P6, "It holds 47,485 Google reviews of 379 retail locations", "47,485", xSUP, g(SUP, r"review rows (\d+)"))
add(P6, "It holds 47,485 Google reviews of 379 retail locations", "379", xSUP, g(SUP, r"locations in the export (\d+)"))
add(P6, "of which 37,193 carry text, at 378 of the locations", "37,193", xSUP, g(SUP, r"with text (\d+);"))
add(P6, "of which 37,193 carry text, at 378 of the locations", "378", xSUP, g(SUP, r"with at least one text review (\d+)"))
add(P6, "between 1 and 201 reviews per location (median 145)", "1", xSUP, g(SUP, r"reviews per location min (\d+)"))
add(P6, "between 1 and 201 reviews per location (median 145)", "201", xSUP, g(SUP, r"max (\d+); reviews with an absolute"))
add(P6, "between 1 and 201 reviews per location (median 145)", "145", xSUP, g(SUP, r"median (\d+), max"))
add(P6, "at 26 locations, they name five different carriers", "26", xSUP, g(SUP, r"name a carrier (\d+)"))
add(P6, "at 26 locations, they name five different carriers", "5", xSUP, g(SUP, r"naming (\d+) different carriers"))
add(P6, "a 42,994-node telecom taxonomy", "42,994", xSUP, g(SUP, r"taxonomy nodes (\d+)"))
add(P6, "from 1,898,584 keywords", "1,898,584", xSUP, g(SUP, r"built from (\d+)"))
add(P6, "Of the 37,193 reviews, 20,663 (55.6%) linked", "37,193", xAR, g(AR, r"reviews with text: (\d+)"))
add(P6, "Of the 37,193 reviews, 20,663 (55.6%) linked", "20,663", xAR, g(AR, r"at least one label: (\d+)"))
add(P6, "Of the 37,193 reviews, 20,663 (55.6%) linked", "55.6%", xAR, g(AR, r"at least one label: \d+ \(([\d.]+)%\)"))
add(P6, "linked to at least one of 27,817 linkable labels", "27,817", sM2, g(M2, r"linkable labels: (\d+);"))
add(P6, "at 2.25 labels per linked review", "2.25", xAR, g(AR, r"labels per linked review ([\d.]+)"))
add(P6, "and 1,008 labels were mentioned at least once", "1,008", sM2, g(M2, r"mentioned: (\d+)"))
P6b = "§6 para 2"
add(P6b, "At the level of the taxonomy's 17 top-level branches", "17", sM2, g(M2, r"over (\d+) branches"))
add(P6b, "is then +0.75 (bootstrap 95% interval over branches +0.44 to +0.90; p < 0.001, 17 branches", "+0.75", sM2, g(M2, r"split mentions: rho=([+-][\d.]+)"))
add(P6b, "is then +0.75 (bootstrap 95% interval over branches +0.44 to +0.90; p < 0.001, 17 branches", "+0.44", sM2, g(M2, r"split attribution: [+-][\d.]+ \[95% ([+-][\d.]+),"))
add(P6b, "is then +0.75 (bootstrap 95% interval over branches +0.44 to +0.90; p < 0.001, 17 branches", "+0.90", sM2, g(M2, r"split attribution: [+-][\d.]+ \[95% [+-][\d.]+, ([+-][\d.]+)\]"))
add(P6b, "is then +0.75 (bootstrap 95% interval over branches +0.44 to +0.90; p < 0.001, 17 branches", "p < 0.001", sM2, (g(M2, r"split mentions: rho=[+-][\d.]+ p=([\d.e-]+)"), float(g(M2, r"split mentions: rho=[+-][\d.]+ p=([\d.e-]+)")) < 0.001))
add(P6b, "and +0.47 (+0.01 to +0.78; p = 0.06)", "+0.47", sM2, g(M2, r"modal attribution: rho=([+-][\d.]+)"))
add(P6b, "and +0.47 (+0.01 to +0.78; p = 0.06)", "+0.01", sM2, g(M2, r"modal attribution: [+-][\d.]+ \[95% ([+-][\d.]+),"))
add(P6b, "and +0.47 (+0.01 to +0.78; p = 0.06)", "+0.78", sM2, g(M2, r"modal attribution: [+-][\d.]+ \[95% [+-][\d.]+, ([+-][\d.]+)\]"))
add(P6b, "and +0.47 (+0.01 to +0.78; p = 0.06)", "0.06", sM2, g(M2, r"modal attribution: rho=[+-][\d.]+ p=([\d.]+)"))
add(P6b, "An earlier computation gave +0.78", "+0.78", xAR, g(AR, r"branch-level Spearman: rho=([+-][\d.]+)"))
for lab, rv, vv in (("Mobile & Wireless Carriers", "66.8%", "14.9%"), ("Devices & Hardware", "11.0%", "32.7%"), ("Internet & Broadband (ISP)", "4.0%", "18.1%")):
    m = re.search(re.escape(lab) + r"\s+([\d.]+)%\s+([\d.]+)%", M2)
    q = {"Mobile & Wireless Carriers": "carriers draw 66.8% of review mentions and 14.9% of search volume",
         "Devices & Hardware": "devices 11.0% and 32.7%", "Internet & Broadband (ISP)": "broadband 4.0% and 18.1%"}[lab]
    add(P6b, q, rv, sM2, m.group(1))
    add(P6b, q, vv, sM2, m.group(2))
add(P6b, "Across the 1,008 labels that at least one review mentions", "1,008", sM2, g(M2, r"mentioned: (\d+)"))
add(P6b, "and monthly volume is +0.19 (bootstrap 95% interval over labels +0.12 to +0.25", "+0.19", sMP, mp_rho_m,
    "prints +0.185; the full value 0.184869 is +0.18 to two decimals (double rounding)")
add(P6b, "and monthly volume is +0.19 (bootstrap 95% interval over labels +0.12 to +0.25", "+0.12", sMP, mp_int_m[0])
add(P6b, "and monthly volume is +0.19 (bootstrap 95% interval over labels +0.12 to +0.25", "+0.25", sMP, mp_int_m[1], "prints +0.245; full value 0.245035")
add(P6b, "Kendall's tau +0.13)", "+0.13", xAR, g(AR, r"Kendall tau=([+-][\d.]+)"))
add(P6b, "counting the 26,809 linkable labels that no review mentions as zero", "26,809", sM2, int(g(M2, r"linkable labels: (\d+);")) - int(g(M2, r"mentioned: (\d+)")))
add(P6b, "it is +0.27 (+0.26 to +0.29)", "+0.27", sM2, g(M2, r"unmentioned = 0\): ([+-][\d.]+)"))
add(P6b, "it is +0.27 (+0.26 to +0.29)", "+0.26", sMP, mp_int_a[0])
add(P6b, "it is +0.27 (+0.26 to +0.29)", "+0.29", sMP, mp_int_a[1], "prints +0.285; the full value 0.284982 is +0.28 to two decimals (double rounding)")
add(P6b, "It is +0.28 among the 213 labels with at least twenty mentions", "+0.28", xAR, g(AR, r"labels with >=20 mentions \(\d+\): rho=([+-][\d.]+)"))
add(P6b, "It is +0.28 among the 213 labels with at least twenty mentions", "213", xAR, g(AR, r"labels with >=20 mentions \((\d+)\)"))
add(P6b, "and +0.16 among the 106 labels mentioned at least twenty times", "+0.16", xAR, g(AR, r"rho\(neg mentions, volume\)=([+-][\d.]+)"))
add(P6b, "and +0.16 among the 106 labels mentioned at least twenty times", "106", xAR, g(AR, r"1-2 star reviews, (\d+)\)"))
add(P6b, "the p-values below 0.001 the scripts print", "below 0.001", sM2, (", ".join(re.findall(r"\(p=([\d.e-]+)\)", M2)[:2]), all(float(x) < 0.001 for x in re.findall(r"\(p=([\d.e-]+)\)", M2)[:2])))
add(P6b, "(`supplement_r10.py`, section 12)", "section 12", xSUP, ("== 12. Bootstraps over reviews", "== 12. Bootstraps over reviews" in SUP))
add(P6b, "Of the 1,008 labels, 367 (36.4%) carry under 1,000 monthly searches", "367", xAR, g(AR, r"<1,000 monthly volume: (\d+)"))
add(P6b, "Of the 1,008 labels, 367 (36.4%) carry under 1,000 monthly searches", "36.4%", xAR, g(AR, r"<1,000 monthly volume: \d+ \(([\d.]+)%\)"))
add(P6b, "and 106 (10.5%) carry none", "106", xAR, g(AR, r"ZERO monthly volume: (\d+)"))
add(P6b, "and 106 (10.5%) carry none", "10.5%", xAR, g(AR, r"ZERO monthly volume: \d+ \(([\d.]+)%\)"))
add(P6b, "the two label-level correlations are +0.16 and +0.26", "+0.16", sM2, g(M2, r"mentioned labels ([+-][\d.]+) \(p=2"))
add(P6b, "the two label-level correlations are +0.16 and +0.26", "+0.26", sM2, g(M2, r"all linkable labels ([+-][\d.]+) \(p=0\)\n\n== 10"))
P6c = "§6 para 'How good the links are'"
add(P6c, "judged 200 links drawn uniformly from the 46,517", "200", sLC, g(LC, r"== A\. Review-to-label links \((\d+) sampled"))
add(P6c, "judged 200 links drawn uniformly from the 46,517", "46,517", sLC, g(LC, r"sampled uniformly from ([\d,]+) links"), "r2_link_check.py reads it from r2_link_sample_output.txt (shipped; r2_link_sample.py needs the withheld export)")
prec = [float(x) for x in re.findall(r"precision \d+/\d+ = ([\d.]+)%", g(LC, r"== A\.(.*?)items the two"))]
add(P6c, "65% to 67% are correct", "65%", sLC, min(prec))
add(P6c, "65% to 67% are correct", "67%", sLC, max(prec))
wl = [float(x) for x in re.findall(r"\[(?:Wilson 95% )?([\d.]+)%, ([\d.]+)%\]", g(LC, r"== A\.(.*?)items the two")) for x in x]
add(P6c, "(Wilson 95% intervals about 58% to 73%)", "58%", sLC, min(wl))
add(P6c, "(Wilson 95% intervals about 58% to 73%)", "73%", sLC, max(wl))
add(P6c, "the two agree on 95.5% of the items (Cohen's kappa 0.90)", "95.5%", sLC, g(LC, r"agreement: ([\d.]+)% of 200"))
add(P6c, "the two agree on 95.5% of the items (Cohen's kappa 0.90)", "0.90", sLC, g(LC, r"of 200 items; Cohen's kappa ([\d.]+)"))
sw = [float(x) for x in re.findall(r"single-word labels: \d+/\d+ = ([\d.]+)%", LC)]
mw = [float(x) for x in re.findall(r"multi-word labels: \d+/\d+ = ([\d.]+)%", LC)]
add(P6c, "which are right about half the time", "about half", sLC, (" and ".join(f"{x}%" for x in sw), all(45 <= x <= 55 for x in sw)))
add(P6c, "while multi-word labels are 95% to 96% right", "95%", sLC, min(mw))
add(P6c, "while multi-word labels are 95% to 96% right", "96%", sLC, max(mw))
add(P6c, "the branch-level correlation is +0.91 (bootstrap 95% interval +0.74 to +0.98)", "+0.91", sM2, g(M2, r"split ([+-][\d.]+) \[95%"))
add(P6c, "the branch-level correlation is +0.91 (bootstrap 95% interval +0.74 to +0.98)", "+0.74", sMP, mp_mw[1],
    "prints +0.735; the full value is 0.735 to machine precision, so +0.74 is the conventional rounding (Python's float formatting gives 0.73)", tol=0.005 + 1e-6)
add(P6c, "the branch-level correlation is +0.91 (bootstrap 95% interval +0.74 to +0.98)", "+0.98", sM2, g(M2, r"split [+-][\d.]+ \[95% [+-][\d.]+, ([+-][\d.]+)\]"))
add(P6c, "and +0.65 with modal attribution", "+0.65", sM2, g(M2, r"modal ([+-][\d.]+) \(p=0\.0048\)"))
add(P6c, "the label-level correlation over mentioned labels is +0.24 (+0.16 to +0.33)", "+0.24", sM2, g(M2, r"mentioned labels ([+-][\d.]+) \[95%"))
add(P6c, "the label-level correlation over mentioned labels is +0.24 (+0.16 to +0.33)", "+0.16", sM2, g(M2, r"mentioned labels [+-][\d.]+ \[95% ([+-][\d.]+),"))
add(P6c, "the label-level correlation over mentioned labels is +0.24 (+0.16 to +0.33)", "+0.33", sM2, g(M2, r"mentioned labels [+-][\d.]+ \[95% [+-][\d.]+, ([+-][\d.]+)\]"))
add(P6c, "carriers still draw 56% of review mentions against 15% of search volume", "56%", sM2, g(M2, r"Mobile & Wireless Carriers ([\d.]+)% of mentions"))
add(P6c, "carriers still draw 56% of review mentions against 15% of search volume", "15%", sM2, g(M2, r"Mobile & Wireless Carriers [\d.]+% of mentions, ([\d.]+)% of volume"))
P6d = "§6 para 'waiting'"
add(P6d, "Of 6,620 one- and two-star reviews, 924 (14.0%", "6,620", xAR, g(AR, r"1-2 star reviews: (\d+)"))
add(P6d, "Of 6,620 one- and two-star reviews, 924 (14.0%", "924", xAR, g(AR, r"mentioning waiting: (\d+)"))
add(P6d, "Of 6,620 one- and two-star reviews, 924 (14.0%", "14.0%", "arith:924 / 6,620", 100 * 924 / 6620)
lo_, hi_ = wilson(924, 6620)
add(P6d, "Wilson 95% interval 13.1% to 14.8%", "13.1%", "arith:Wilson on 924 / 6,620", 100 * lo_)
add(P6d, "Wilson 95% interval 13.1% to 14.8%", "14.8%", "arith:Wilson on 924 / 6,620", 100 * hi_)
add(P6d, "against 1.9% (1.8% to 2.1%) of five-star reviews", "1.9%", xAR, g(AR, r"in 5-star reviews: ([\d.]+)%"))
add(P6d, "against 1.9% (1.8% to 2.1%) of five-star reviews", "1.8%", xSUP, g(SUP, r"five-star \d+/\d+ = [\d.]+% \[([\d.]+)%"), "Wilson on 564 / 29,225 from the same output agrees")
add(P6d, "against 1.9% (1.8% to 2.1%) of five-star reviews", "2.1%", xSUP, g(SUP, r"five-star \d+/\d+ = [\d.]+% \[[\d.]+%, ([\d.]+)%\]"))
add(P6d, "The same annotators judged 100 of the 924 matches", "100", sLC, g(LC, r"== B\. Waiting-pattern matches \((\d+) sampled"))
add(P6d, "The same annotators judged 100 of the 924 matches", "924", sLC, g(LC, r"from the (\d+) one- and two-star matches"), "read from r2_link_sample_output.txt (shipped)")
pb = [float(x) for x in re.findall(r"precision \d+/\d+ = ([\d.]+)%", g(LC, r"== B\.(.*?)agreement"))]
add(P6d, "83% to 85% are complaints about waiting (Cohen's kappa 0.93)", "83%", sLC, min(pb))
add(P6d, "83% to 85% are complaints about waiting (Cohen's kappa 0.93)", "85%", sLC, max(pb))
add(P6d, "83% to 85% are complaints about waiting (Cohen's kappa 0.93)", "0.93", sLC, g(LC, r"of 100 items; Cohen's kappa ([\d.]+)"))
instore = [float(x) for x in re.findall(r"in store \d+/\d+ = ([\d.]+)%", LC)]
add(P6d, "about nine in ten of those concern waiting in the store", "about 90%", sLC, (" and ".join(f"{x}%" for x in instore), all(85 <= x <= 95 for x in instore)))
impl = [float(x) for x in re.findall(r"= ([\d.]+)%\n", g(LC, r"(implied share.*?)== C"))]
add(P6d, "so roughly 12% of one- and two-star reviews complain about a wait", "12%", sLC, (" and ".join(f"{x}%" for x in impl), all(round(x) == 12 for x in impl)))
add(P6d, "The whole taxonomy, built from 1.9 million keywords", "1.9 million", xSUP, (g(SUP, r"built from (\d+)"), round(int(g(SUP, r"built from (\d+)")) / 1e6, 1) == 1.9))
add(P6d, "holds 11 labels containing \"wait\"", "11", xSUP, g(SUP, r"distinct such labels: (\d+)"))
add(P6d, "with 622 searches a month between them", "622", xSUP, g(SUP, r"their monthly volume: (\d+)"))
add(P6d, "the one that reviews mention carries 12", "1", xAR, g(AR, r"contain 'wait' .*?: (\d+) \|"))
add(P6d, "the one that reviews mention carries 12", "12", xAR, g(AR, r"total monthly volume on them: (\d+)"))
add(P6d, "Eight labels name a remedy, appointments, queues or callbacks", "8", xSUP, g(SUP, r"appointments, queues or callbacks: (\d+) labels"))
add(P6d, "with 13,170 searches a month between them", "13,170", xSUP, g(SUP, r"callbacks: \d+ labels, (\d+) searches"))
add(P6d, "most of it for appointment reminders", "most", xSUP, (f"{g(SUP, r'Appointment Reminders: (\d+)')} of 13170", int(g(SUP, r"Appointment Reminders: (\d+)")) > 13170 / 2))
add(P6d, "the label for scheduling a store appointment carries none", "0", xSUP, g(SUP, r"Scheduling a Store Appointment for Tech Help: (\d+)"))
add(P6d, "and no label concerns check-in", "0", xSUP, g(SUP, r"naming check-in: (\d+)"))
add("§6 Figure 6 caption", "37,193 Google reviews of 378 retail locations", "37,193", xAR, g(AR, r"reviews with text: (\d+)"))
add("§6 Figure 6 caption", "37,193 Google reviews of 378 retail locations", "378", xAR, g(AR, r"businesses: (\d+)"))
add("§6 Figure 6 caption", "linked to a 42,994-node taxonomy carrying", "42,994", xSUP, g(SUP, r"taxonomy nodes: (\d+)"))
add("§6 Figure 6 caption", "Each marker is one of the 1,008 taxonomy labels", "1,008", sM2, g(M2, r"mentioned: (\d+)"))
add("§6 Figure 6 caption", "for the nine largest of the 17 top-level branches", "17", sM2, g(M2, r"over (\d+) branches"))
add("§6 last para", "exact-match links of which about two in three are correct", "about two in three", sLC, (f"{min(prec)}% to {max(prec)}%", 60 <= min(prec) and max(prec) <= 70))

# ---------------------------------------------------------------- Section 7
P7a = "§7.1"
add(P7a, "made on 12 October between 22:21 and 22:26", "22:21 to 22:26", xPI, g(PI, r"\(12 Oct ([\d:]+-[\d:]+)\)").replace("-", " to "), exact=True)
pil = dict(re.findall(r"  (AI Overviews \(search queries\)|AI Overviews \(prompts\)|AI Mode \(search queries\)|AI Mode \(prompts\)|ChatGPT|Perplexity|Gemini|Copilot)\s+YouTube non-brand rank (\d+)", PI))
pir = dict(re.findall(r"  (AI Overviews \(search queries\)|AI Overviews \(prompts\)|AI Mode \(search queries\)|AI Mode \(prompts\)|ChatGPT|Perplexity|Gemini|Copilot)\s+YouTube non-brand rank \d+; Reddit (\d+)", PI))
add(P7a, "youtube.com was the most-cited non-brand domain on all four Google views", "1 on all four", xPI, ("ranks " + ", ".join(pil[k] for k in list(pil)[:4]), all(pil[k] == "1" for k in list(pil)[:4])))
for k, v in (("ChatGPT", "28"), ("Perplexity", "4"), ("Gemini", "5"), ("Copilot", "9")):
    add(P7a, "ranked 28th on ChatGPT, 4th on Perplexity, 5th on Gemini and 9th on Copilot", v, xPI, pil[k])
add(P7a, "reddit.com was in the top three on every surface except Copilot (240th)", "top three except Copilot", xPI, (", ".join(pir.values()), all(int(v) <= 3 for k, v in pir.items() if k != "Copilot")))
add(P7a, "reddit.com was in the top three on every surface except Copilot (240th)", "240", xPI, pir["Copilot"])
P7b = "§7.2"
add(P7b, "set aside eight exports that repeated a view or mixed two platforms", "8", "data:design file (amendment A2)", ("Eight exports", "Eight exports that repeated an earlier view or mixed two platforms" in DESIGN))
add(P7b, "the prompt-level sample was stopped after 14 of 88 exports", "14 of 88", "data:design file (amendment A3)", ("after 14 of 88 exports", "after 14 of 88 exports" in DESIGN))
add(P7b, "(holdings as of 9 October 2026): 109 companies", "109", "data:cross_sector_companies.csv", len(COMP))
add(P7b, "because Communication Services counts one issuer, Alphabet, through two share classes", "9 companies in Communication Services", "rerun:make_brand_radar_urls.py", (g(URLS, r"'xlc': (\d+)"), g(URLS, r"'xlc': (\d+)") == "9"))
add(P7b, "which reduce to 760 to 975 registrable domains", "760", sS7, g(S7, r"registrable domains per export (\d+) to"))
add(P7b, "which reduce to 760 to 975 registrable domains", "975", sS7, g(S7, r"registrable domains per export \d+ to (\d+)"))
add(P7b, "the 88 exports are analyzed", "88", sS7, g(S7, r"(\d+) cells; summed"))
add(P7b, "Summed over sectors it holds 20,389,967 answer records", "20,389,967", sS7, g(S7, r"summed over sectors ([\d,]+)"))
add(P7b, "from 18,763 (Utilities) to 7,766,466 (Consumer Discretionary)", "18,763", sS7, g(S7, r"range ([\d,]+) \(xlu\)"))
add(P7b, "from 18,763 (Utilities) to 7,766,466 (Consumer Discretionary)", "7,766,466", sS7, g(S7, r"to ([\d,]+) \(xly\)"))
add("§7.2 Figure 7 caption", "(nine companies in Communication Services)", "9", "rerun:make_brand_radar_urls.py", g(URLS, r"'xlc': (\d+)"))
P7c = "§7.3 Descriptive"
add(P7c, "In every one of the eleven sectors, the lowest of the four Google views", "11 of 11", sS7, (f"{s7_every}/11", s7_every == "11"))
add(P7c, "the median share was 21.3% on the Google views (range 8.1% to 35.8%", "21.3%", sS7, s7_g)
add(P7c, "the median share was 21.3% on the Google views (range 8.1% to 35.8%", "8.1%", sS7, g(S7, r"Google views median [\d.]+% \(range ([\d.]+)%"))
add(P7c, "the median share was 21.3% on the Google views (range 8.1% to 35.8%", "35.8%", sS7, g(S7, r"Google views median [\d.]+% \(range [\d.]+% to ([\d.]+)%"))
add(P7c, "95% bootstrap interval over sectors 17.2% to 26.7%)", "17.2%", sS7, g(S7, r"median: Google ([\d.]+)% to"))
add(P7c, "95% bootstrap interval over sectors 17.2% to 26.7%)", "26.7%", sS7, g(S7, r"median: Google [\d.]+% to ([\d.]+)%"))
add(P7c, "against 2.1% on the other four (range 0.3% to 16.7%; interval 1.7% to 2.7%)", "2.1%", sS7, s7_c)
add(P7c, "against 2.1% on the other four (range 0.3% to 16.7%; interval 1.7% to 2.7%)", "0.3%", sS7, g(S7, r"other four median [\d.]+% \(range ([\d.]+)%"))
add(P7c, "against 2.1% on the other four (range 0.3% to 16.7%; interval 1.7% to 2.7%)", "16.7%", sS7, g(S7, r"other four median [\d.]+% \(range [\d.]+% to ([\d.]+)%"))
add(P7c, "against 2.1% on the other four (range 0.3% to 16.7%; interval 1.7% to 2.7%)", "1.7%", sS7, g(S7, r"other four ([\d.]+)% to [\d.]+%\n"))
add(P7c, "against 2.1% on the other four (range 0.3% to 16.7%; interval 1.7% to 2.7%)", "2.7%", sS7, g(S7, r"other four [\d.]+% to ([\d.]+)%\n"))
for k, v in (("copilot", "0.6%"), ("chatgpt", "0.9%"), ("perplexity", "4.6%"), ("gemini", "9.2%")):
    add(P7c, "by surface 0.6% on Copilot, 0.9% on ChatGPT, 4.6% on Perplexity and 9.2% on Gemini", v, sS7, s7_surf[k])
add(P7c, "the Google median is 24.6%", "24.6%", sS7, g(S7, r"Google prompt views only: median ([\d.]+)%"))
add(P7c, "in 38 of the 44 sector-by-Google-view cells and in none of the 44 others", "38", sS7, g(S7, r"top three on Google views (\d+)/44"))
add(P7c, "in 38 of the 44 sector-by-Google-view cells and in none of the 44 others", "0", sS7, g(S7, r"on the other four (\d+)/44"))
ymed = dict(re.findall(r"  (\w+)\s+median rank\s+(\d+);", S7))
for v, ks in (("1", ("aio_searchqueries", "aio_prompts")), ("2", ("aimode_searchqueries", "aimode_prompts")), ("7", ("perplexity", "gemini")), ("151", ("chatgpt",)), ("161", ("copilot",))):
    for k in ks:
        add(P7c, "its median rank was 1 on AI Overviews, 2 on AI Mode, 7 on Perplexity and Gemini, 151 on ChatGPT and 161 on Copilot", v, sS7, ymed[k], f"surface {k}")
add(P7c, "without it, the medians are 12.7% and 1.6%", "12.7%", sS7, g(S7, r"without YouTube: Google median ([\d.]+)%"))
add(P7c, "without it, the medians are 12.7% and 1.6%", "1.6%", sS7, g(S7, r"without YouTube: Google median [\d.]+%, other four ([\d.]+)%"))
add(P7c, "the lowest Google view exceeds the highest other surface in 7 of 11 sectors", "7", sS7, g(S7, r"lowest Google view above highest other in (\d+)/11"))
P7d = "§7.3 Source types"
oth = {m.group(1): m.groups()[1:] for m in re.finditer(r"  (\w+)\s+Google ([\d.]+)%; other four ([\d.]+)%; Copilot ([\d.]+)%", S7)}
add(P7d, "the median reference share was 2.7% on the other four surfaces against 3.2% on the Google views", "2.7%", sS7, oth["reference"][1])
add(P7d, "the median reference share was 2.7% on the other four surfaces against 3.2% on the Google views", "3.2%", sS7, oth["reference"][0])
add(P7d, "and forum sites 1.1% against 5.7%", "1.1%", sS7, oth["forum"][1])
add(P7d, "and forum sites 1.1% against 5.7%", "5.7%", sS7, oth["forum"][0])
add(P7d, "the sector's own company domains (median 14.1%)", "14.1%", sS7, oth["report_brands"][1])
add(P7d, "held a median 61% of incidences on the Google views and 72% on the other four (90% on Copilot)", "61%", sS7, oth["other_web"][0])
add(P7d, "held a median 61% of incidences on the Google views and 72% on the other four (90% on Copilot)", "72%", sS7, oth["other_web"][1])
add(P7d, "held a median 61% of incidences on the Google views and 72% on the other four (90% on Copilot)", "90%", sS7, oth["other_web"][2])
types = ast.literal_eval(re.search(r"TYPES = (\{.*?\n\})", CSPY, re.S).group(1))
comm = [d for k in ("video", "forum", "social", "user_publishing") for d in sorted(types[k])]
plat = len(comm) - (("x.com" in comm) and ("twitter.com" in comm))
add(P7d, "the share going to seventeen named video and community platforms", "17", "data:cross_sector.py TYPES (released script)", plat,
    f"{len(comm)} domains; x.com and twitter.com are one platform (X)")
vs_ = {m.group(1): m.groups()[1:] for m in re.finditer(r"  (\w+)\s+surface (\d+)%  sector (\d+)%", S7)}
add(P7d, "Across the 88 cells, answer surface explains 77% of the variance", "77%", sS7, vs_["video_community"][0])
add(P7d, "(bootstrap 95% interval over sectors 70% to 91%)", "70%", sS7, g(S7, r"bootstrap video_community\s+surface \[(\d+)%"))
add(P7d, "(bootstrap 95% interval over sectors 70% to 91%)", "91%", sS7, g(S7, r"bootstrap video_community\s+surface \[\d+%, (\d+)%\]"))
add(P7d, "and sector 14% (5% to 20%)", "14%", sS7, vs_["video_community"][1])
add(P7d, "and sector 14% (5% to 20%)", "5%", sS7, g(S7, r"bootstrap video_community\s+surface \[\d+%, \d+%\]\s+sector \[(\d+)%"))
add(P7d, "and sector 14% (5% to 20%)", "20%", sS7, g(S7, r"bootstrap video_community\s+surface \[\d+%, \d+%\]\s+sector \[\d+%, (\d+)%\]"))
for k, a_, b_ in (("news", "12%", "73%"), ("government", "26%", "49%"), ("report_brands", "40%", "45%")):
    q = {"news": "for news (12% against 73%)", "government": "government (26% against 49%)", "report_brands": "the companies' own domains (40% against 45%)"}[k]
    add(P7d, q, a_, sS7, vs_[k][0])
    add(P7d, q, b_, sS7, vs_[k][1])
P7e = "§7.3 By sector"
c3 = {}
for ln in MT.splitlines():
    if ln.startswith("| ") and not ln.startswith("| Sector"):
        cells = [c.strip() for c in ln.strip("|").split("|")]
        if len(cells) == 9:
            c3[cells[0]] = cells[1:]
desc = (("Information Technology", "a search engine (Information Technology)", "google"), ("Health Care", "the Food and Drug Administration (Health Care)", "fda.gov"),
        ("Financials", "a personal-finance publisher (Financials)", "nerdwallet"), ("Consumer Discretionary", "a streaming guide (Consumer Discretionary)", "justwatch"),
        ("Communication Services", "a Disney property (Communication Services)", "go†"), ("Industrials", "a graphics-card maker (Industrials", "nvidia"),
        ("Consumer Staples", "reddit.com (Consumer Staples)", "reddit"), ("Energy", "the Securities and Exchange Commission (Energy, Utilities and Real Estate)", "sec.gov"),
        ("Utilities", "the Securities and Exchange Commission (Energy, Utilities and Real Estate)", "sec.gov"), ("Real Estate", "the Securities and Exchange Commission (Energy, Utilities and Real Estate)", "sec.gov"),
        ("Materials", "and a paint maker (Materials)", "benjaminmoore"))
for sec, q, dom in desc:
    add(P7e, q, f"{sec}: {dom}", sMT, f"{sec}: {c3[sec][4]}", "ChatGPT column of Table C3 as printed", exact=True)
jac = dict(re.findall(r"(\w+) ([\d.]+)", g(S7, r"55 sector pairs\n  ([^\n]+)")))
add(P7e, "(mean pairwise Jaccard 0.36 to 0.40 across the 55 sector pairs)", "0.36", sS7, min(float(jac[p]) for p in ("aio_searchqueries", "aio_prompts", "aimode_searchqueries", "aimode_prompts")))
add(P7e, "(mean pairwise Jaccard 0.36 to 0.40 across the 55 sector pairs)", "0.40", sS7, max(float(jac[p]) for p in ("aio_searchqueries", "aio_prompts", "aimode_searchqueries", "aimode_prompts")))
add(P7e, "(mean pairwise Jaccard 0.36 to 0.40 across the 55 sector pairs)", "55", sS7, ("55 sector pairs", "55 sector pairs" in S7))
add(P7e, "than on the other four (0.08 to 0.23)", "0.08", sS7, min(float(jac[p]) for p in ("chatgpt", "perplexity", "gemini", "copilot")))
add(P7e, "than on the other four (0.08 to 0.23)", "0.23", sS7, max(float(jac[p]) for p in ("chatgpt", "perplexity", "gemini", "copilot")))
add(P7e, "its direction reversed on search queries (22.5% against 24.2%)", "22.5%", xSE2, g(SE2, r"company properties\s+AI Overviews \(search queries\)\s+([\d.]+)% vs"))
add(P7e, "its direction reversed on search queries (22.5% against 24.2%)", "24.2%", xSE2, g(SE2, r"company properties\s+AI Overviews \(search queries\)\s+[\d.]+% vs ([\d.]+)%"))
p4s = [float(x) for x in re.findall(r"vs [\d.]+%, p ([\d.]+)", SE2)]
add(P7e, "in no check did it approach significance (p = 0.23 to 0.63)", "0.23", xSE2, min(p4s))
add(P7e, "in no check did it approach significance (p = 0.23 to 0.63)", "0.63", xSE2, max(p4s))
dom_ = {m.group(1).strip(): (m.group(2).strip(), m.group(3)) for m in re.finditer(r"  (Information Technology|Health Care|Financials|Consumer Discretionary|Communication Services|Industrials|Consumer Staples|Energy|Utilities|Real Estate|Materials)\s+(.+?)\s+([\d.]+)%\n", SE)}
for sec, name, v in (("Materials", "Sherwin-Williams", "94%"), ("Consumer Discretionary", "Amazon", "75%"), ("Consumer Staples", "Walmart", "65%"),
                     ("Information Technology", "Apple", "62%"), ("Industrials", "Uber", "55%")):
    add(P7e, f"{name} holds 94% of Materials" if name == "Sherwin-Williams" else f"{name} {v} of {sec}", f"{name} {v}", xSE, (f"{dom_[sec][0]} {dom_[sec][1]}%", dom_[sec][0] == name and same(v, dom_[sec][1], None, False)))
c4 = {}
for ln in MT.splitlines():
    if ln.startswith("| ") and ln.count("|") == 4 and not ln.startswith("| Sector"):
        cells = [c.strip() for c in ln.strip("|").split("|")]
        c4[cells[0]] = cells[1:]
for d, sec in (("go†", "Communication Services"), ("chase†", "Financials"), ("mobil†", "Energy")):
    add(P7e, "such as go.com, chase.com and mobil.com among ChatGPT's top three", d.rstrip("†") + ".com", sMT, (c4[sec][1], d in [x.strip() for x in c4[sec][1].split(",")]))
P7f = "§7.4"
p1 = ast.literal_eval(g(S7, r"P1 sectors with YouTube first, per view (\{[^}]*\})"))
add(P7f, "it held on AI Overviews (9 of 11 sectors on search queries, 8 of 11 on prompts)", "9", sS7, p1["aio_searchqueries"])
add(P7f, "it held on AI Overviews (9 of 11 sectors on search queries, 8 of 11 on prompts)", "8", sS7, p1["aio_prompts"])
add(P7f, "and not on AI Mode (2 of 11 on each)", "2", sS7, p1["aimode_searchqueries"])
add(P7f, "and not on AI Mode (2 of 11 on each)", "2", sS7, p1["aimode_prompts"])
add(P7f, "P1, that youtube.com is the most-cited non-company domain on AI Overviews and AI Mode in a majority of sectors, failed as written", "fails", sS7, ("fails", "-> fails" in g(S7, r"(P1 sectors.*?)\n")))
add(P7f, "(median 93% and 98% of its incidences on the two views)", "93%", xSE2, g(SE2, r"AI Mode \(search queries\)\s+www\.google\.com (\d+)%"))
add(P7f, "(median 93% and 98% of its incidences on the two views)", "98%", xSE2, g(SE2, r"AI Mode \(prompts\)\s+www\.google\.com (\d+)%"))
add(P7f, "it would hold (9 of 11) if google.com", "9", xSE, g(SE, r"P1 with google\.com set aside: .*? both products (\d+)"))
add(P7f, "It fails under every domain reduction tried", "fails under every reduction", xSE, (", ".join(re.findall(r"both products (\d+)/11", SE)), all(int(x) < 6 for x in re.findall(r"both products (\d+)/11", SE))))
p2 = ast.literal_eval(g(S7, r"P2 sectors with YouTube outside the top five (\{[^}]*\})"))
for k, v in (("chatgpt", "11"), ("perplexity", "6"), ("copilot", "11")):
    add(P7f, "held on all three (11, 6 and 11 of 11)", v, sS7, p2[k])
add(P7f, "failed: it held in 3 of 11", "3", sS7, g(S7, r"every surface but Copilot (\d+)/11"))
add(P7f, "ChatGPT was a failing surface in all eight sectors where it did not hold", "8 of 8", sS7, (g(S7, r"ChatGPT fails in (\d+ of the \d+) others"), g(S7, r"ChatGPT fails in (\d+ of the \d+) others") == "8 of the 8"))
add(P7f, "(Financials is in neither group)", "Financials in neither group", "data:cross_sector.py CONSUMER/NONCONSUMER", ("xlf absent", "xlf" not in re.search(r"CONSUMER = (\[.*?\])", CSPY).group(1) + re.search(r"NONCONSUMER = (\[.*?\])", CSPY).group(1)))
p4 = re.findall(r"P4 (\w+): consumer ([\d.]+)% against other ([\d.]+)%; exact one-sided p ([\d.]+)", S7)
add(P7f, "held in direction (26.9% against 24.2% on search queries", "26.9%", sS7, p4[0][1])
add(P7f, "held in direction (26.9% against 24.2% on search queries", "24.2%", sS7, p4[0][2])
add(P7f, "29.6% against 24.4% on prompts)", "29.6%", sS7, p4[1][1])
add(P7f, "29.6% against 24.4% on prompts)", "24.4%", sS7, p4[1][2])
add(P7f, "(exact one-sided permutation p = 0.27 and 0.21)", "0.27", sS7, p4[0][3])
add(P7f, "(exact one-sided permutation p = 0.27 and 0.21)", "0.21", sS7, p4[1][3])
add(P7f, "Of the four, one held, one held in direction only and two failed", "1, 1, 2", sS7, (pt_str, pt_ok))
P7g = "§7.5"
sen = {}
for m in re.finditer(r"\n(YouTube removed from numerator|'Found in' instead of 'Cited in'|largest single host instead of summed hosts|company properties counted as company domains|first 100 export rows only|first 250 export rows only|first 500 export rows only): Google median ([\d.]+)%, other four median ([\d.]+)%;.*?in (\d+)/11 sectors", SE):
    sen[m.group(1)] = m.groups()[1:]
for key, q, vals in (("'Found in' instead of 'Cited in'", "(Google median 21.5%, other four 3.3%; lowest Google view above the highest other surface in 11 of 11 sectors)", ("21.5%", "3.3%", "11")),
                     ("largest single host instead of summed hosts", "(22.0%, 2.4%, 11 of 11)", ("22.0%", "2.4%", "11")),
                     ("company properties counted as company domains", "(19.8%, 2.1%, 10 of 11)", ("19.8%", "2.1%", "10"))):
    for v, o in zip(vals, sen[key]):
        add(P7g, q, v, xSE, o)
add(P7g, "and with 64 properties of the sector's companies", "64", "data:cross_sector_company_properties.csv", len(PROPS))
csx = dict(re.findall(r"(AI Overviews \(search queries\)|AI Overviews \(prompts\)|AI Mode \(search queries\)|AI Mode \(prompts\)|Gemini) ([\d.]+% -> [\d.]+%)", g(SE, r"Communication Services, entered domains -> with Alphabet and Meta properties as company: ([^\n]+)")))
before = [float(v.split("%")[0]) for k, v in csx.items() if k != "Gemini"]
after = [float(v.split("-> ")[1].rstrip("%")) for k, v in csx.items() if k != "Gemini"]
add(P7g, "the Google views fall from 20.2% to 32.4% to 5.9% to 12.7%", "20.2%", xSE, min(before))
add(P7g, "the Google views fall from 20.2% to 32.4% to 5.9% to 12.7%", "32.4%", xSE, max(before))
add(P7g, "the Google views fall from 20.2% to 32.4% to 5.9% to 12.7%", "5.9%", xSE, min(after))
add(P7g, "the Google views fall from 20.2% to 32.4% to 5.9% to 12.7%", "12.7%", xSE, max(after))
gem_after = float(csx["Gemini"].split("-> ")[1].rstrip("%"))
add(P7g, "and Gemini's 9.2% exceeds AI Mode on search queries", "9.2%", xSE, gem_after)
add(P7g, "and Gemini's 9.2% exceeds AI Mode on search queries", "exceeds", xSE, (f"Gemini {gem_after}% > AI Mode search queries {csx['AI Mode (search queries)'].split('-> ')[1]}", gem_after > float(csx["AI Mode (search queries)"].split("-> ")[1].rstrip("%"))))
for key, gv, cv in (("first 100 export rows only", "30.6%", "3.0%"), ("first 250 export rows only", "26.3%", "2.6%"), ("first 500 export rows only", "23.3%", "2.3%")):
    add(P7g, "gives Google medians of 30.6%, 26.3% and 23.3% against 3.0%, 2.6% and 2.3%", gv, xSE, sen[key][0])
    add(P7g, "gives Google medians of 30.6%, 26.3% and 23.3% against 3.0%, 2.6% and 2.3%", cv, xSE, sen[key][1])
add(P7g, "while the ratio between the two groups stays near ten", "near ten", "arith:quoted medians", (", ".join(f"{a / b:.1f}" for a, b in ((30.6, 3.0), (26.3, 2.6), (23.3, 2.3), (21.3, 2.1))), all(9 <= a / b <= 11 for a, b in ((30.6, 3.0), (26.3, 2.6), (23.3, 2.3), (21.3, 2.1)))))
add(P7g, "Ranks 501 to 1,000 carry a median 7.6% to 13.8%", "7.6%", sS7, g(S7, r"range of medians ([\d.]+)% to"))
add(P7g, "Ranks 501 to 1,000 carry a median 7.6% to 13.8%", "13.8%", sS7, g(S7, r"range of medians [\d.]+% to ([\d.]+)%"))
P7h = "§7.6"
rtx = {m.group(1): m.groups()[1:] for m in re.finditer(r"  (\w+)\s+video and community ([\d.]+)% -> ([\d.]+)%; YouTube rank (\S+) -> (\S+); top non-company (\S+) -> (\S+)", S7)}
add(P7h, "(video and community share 31.3% to 30.1% on AI Overviews search queries", "31.3%", sS7, rtx["aio_searchqueries"][0])
add(P7h, "(video and community share 31.3% to 30.1% on AI Overviews search queries", "30.1%", sS7, rtx["aio_searchqueries"][1])
add(P7h, "YouTube's rank stayed 1 on AI Overviews", "1 -> 1 (both views)", sS7, (f"{rtx['aio_searchqueries'][2]}->{rtx['aio_searchqueries'][3]}, {rtx['aio_prompts'][2]}->{rtx['aio_prompts'][3]}", rtx["aio_searchqueries"][2:4] == ("1;", "1;") or (rtx["aio_searchqueries"][2].rstrip(";"), rtx["aio_searchqueries"][3].rstrip(";"), rtx["aio_prompts"][2].rstrip(";"), rtx["aio_prompts"][3].rstrip(";")) == ("1", "1", "1", "1")))
add(P7h, "and moved from 2 to 1 on AI Mode prompts", "2 -> 1", sS7, (f"{rtx['aimode_prompts'][2].rstrip(';')} -> {rtx['aimode_prompts'][3].rstrip(';')}", (rtx["aimode_prompts"][2].rstrip(";"), rtx["aimode_prompts"][3].rstrip(";")) == ("2", "1")))
add(P7h, "moved Perplexity from 6.2% to 5.5% and Gemini from 15.0% to 13.4%", "6.2%", sS7, rtx["perplexity"][0])
add(P7h, "moved Perplexity from 6.2% to 5.5% and Gemini from 15.0% to 13.4%", "5.5%", sS7, rtx["perplexity"][1])
add(P7h, "moved Perplexity from 6.2% to 5.5% and Gemini from 15.0% to 13.4%", "15.0%", sS7, rtx["gemini"][0])
add(P7h, "moved Perplexity from 6.2% to 5.5% and Gemini from 15.0% to 13.4%", "13.4%", sS7, rtx["gemini"][1])
add(P7h, "changed Copilot's top non-company domain from amazon.com to a flight-route site", "amazon.com -> a flight-route site", sS7, (f"{rtx['copilot'][4].rstrip(';')} -> {rtx['copilot'][5]}", rtx["copilot"][4].rstrip(";") == "amazon.com" and "flight" in rtx["copilot"][5]))
add(P7h, "without Industrials the ChatGPT median is 0.8%", "0.8%", xSE, g(SE, r"ChatGPT without Industrials \(RTX\): comm\+video median ([\d.]+)%"))
wo = dict(re.findall(r"  P2 (\w+)\s+(\d+)/10", SE2))
add(P7h, "P2 holds on ChatGPT and Copilot in 10 of 10 sectors", "10", xSE2, wo["ChatGPT"])
add(P7h, "P2 holds on ChatGPT and Copilot in 10 of 10 sectors", "10", xSE2, wo["Copilot"])
add(P7h, "and on Perplexity in 6 of 10", "6", xSE2, wo["Perplexity"])
add(P7h, "and P3 holds in 3 of 10", "3", xSE2, g(SE2, r"  P3 (\d+)/10"))
add(P7h, "hold up to 2.2% of a Financials surface's incidences", "2.2%", xSE, max(float(x) for x in re.findall(r"state\.gov\+uscis\.gov\+cbp\.gov\+dhs\.gov ([\d.]+)%", SE)))
add(P7h, "by reading each sector's 25 most-cited non-company domains", "25", "data:design file (amendment A3)", ("25 most-cited", "25 most-cited non-company domains" in DESIGN))
add(P7h, "cells range from 860 to 18,381,848 incidences", "860", sS7, g(S7, r"per cell ([\d,]+) to"))
add(P7h, "cells range from 860 to 18,381,848 incidences", "18,381,848", sS7, g(S7, r"per cell [\d,]+ to ([\d,]+)"))
add("§7.6 What Measurement 3 establishes", "about ten times the pooled median share of the other four surfaces", "about ten times", sS7, (f"{float(s7_g) / float(s7_c):.1f}", round(float(s7_g) / float(s7_c)) == 10))
add("§7.6 What Measurement 3 establishes", "and more than twice Gemini's", "more than twice", sS7, (f"{float(s7_g) / float(s7_surf['gemini']):.2f}", float(s7_g) > 2 * float(s7_surf["gemini"])))

# ---------------------------------------------------------------- Sections 8 to 10
P8 = "§8"
add(P8, "The 21–100 row is derived as the total less the three reported bands", "derived row", "arith:Table 5", (
    "; ".join(str(n_(t5("Ranking positions, all", d)) - n_(t5("Positions 1–3", d)) - n_(t5("Positions 4–10", d)) - n_(t5("Positions 11–20", d))) for d in (0, 15, 30, 45, 60, 75)),
    all(n_(t5("Ranking positions, all", d)) - n_(t5("Positions 1–3", d)) - n_(t5("Positions 4–10", d)) - n_(t5("Positions 11–20", d)) == n_(t5("Positions 21–100 (derived)", d)) for d in (0, 15, 30, 45, 60, 75))))
add(P8, "The estimated-visits peak at day 60 coincides with that day", "peak at day 60", dT5, (max(T5D[:7], key=lambda d: n_(t5("Estimated visits (Ahrefs)", d).replace("≈", ""))), max(T5D[:7], key=lambda d: n_(t5("Estimated visits (Ahrefs)", d).replace("≈", ""))) == 60))
for q, v, metric, d in (("the section held 15,830 ranking positions", "15,830", "Ranking positions, all", 37), ("1,874 of them in positions 1 to 3", "1,874", "Positions 1–3", 37),
                        ("with an estimated 51,800 monthly visits", "51,800", "Estimated visits (Ahrefs)", 37), ("and nineteen referring domains", "19", "Live referring domains", 37),
                        ("By day 77 it held 43,980 positions across 441 URLs", "43,980", "Ranking positions, all", 77), ("By day 77 it held 43,980 positions across 441 URLs", "441", "Pages holding a position", 77),
                        ("and appeared in 17,206 stored AI answers", "17,206", "AI answers citing the section", 77)):
    add(P8 + " primary checkpoint", q, v, dT5, t5(metric, d).replace("≈", ""))
add(P8 + " primary checkpoint", "ranked for 29,000 keywords in one instrument and 58,586 in the other", "29,000", dSR, sr("ranks 1 to 100 (all locations)"))
add(P8 + " primary checkpoint", "ranked for 29,000 keywords in one instrument and 58,586 in the other", "58,586", dSR, sr("ranks 1 to 100 (US database)"))
add(P8 + " primary checkpoint", "was recorded as a cited source in Google AI Overviews on 7,455 keywords", "7,455", dT3, T3V["October"]["k"])
add(P8 + " concentration", "the ten highest-traffic carry 22.8% of estimated visits", "22.8%", dSR, sr("ten highest-traffic URLs"))
add(P8 + " concentration", "and the top 50 carry 64.9%", "64.9%", dSR, sr("top 50 of the 441 URLs"))
add(P8 + " concentration", "Fifty of 441 is 11% of the pages", "11%", "arith:50 / 441", 100 * 50 / 441)
add(P8 + " concentration", "carrying about two thirds of the estimated traffic", "about two thirds", dSR, (sr("top 50 of the 441 URLs"), 60 <= num(sr("top 50 of the 441 URLs")) <= 70))
add(P8 + " demand", "Among the 58,586 US keywords", "58,586", dSR, sr("ranks 1 to 100 (US database)"))
add(P8 + " demand", "with 40 to 170 reported searches a month or none at all", "40 to 170, or none", dSR, sr("reported monthly searches of the lowest-traffic rows"), exact=True)
add(P8 + " demand", "The section ranks in 105 countries, with 18.5%", "105", dSR, sr("countries in which the section ranks"))
add(P8 + " demand", "The section ranks in 105 countries, with 18.5%", "18.5%", dSR, sr("share of Ahrefs-estimated visits from outside the US"))
P9 = "§9.1"
for q, k in (("New York 474 answers", "New York state hub"), ("California 337", "California state hub"), ("Texas 322", "Texas state hub"), ("Florida 304", "Florida state hub"),
             ("and the national hub 294", "national hub"), ("214 Dallas 238", "214 (Dallas) code page"), ("786 Miami 228", "786 (Miami) code page"), ("404 Atlanta 218", "404 (Atlanta) code page")):
    add(P9, q, q.split()[-1] if q.split()[-1].isdigit() else q.split()[-2], dSR, hub[k])
percode = {s: hub[f"{n} state hub"] / sum(r["location"] == s for r in CP) for n, s in (("New York", "NY"), ("California", "CA"), ("Texas", "TX"), ("Florida", "FL"))}
add(P9, "per code it lists, a state hub is cited less often than the most-cited code pages", "less often", "data:single reads and code list",
    (", ".join(f"{k} {v:.1f}" for k, v in percode.items()) + f" per code against {min(hub[k] for k in hub if 'code page' in k):.0f}", all(v < min(hub[k] for k in hub if "code page" in k) for v in percode.values())))
add("§9.1 Figure 8 caption", "The eight pages under the prefix most often cited", "8", dSR, sum(1 for r in SRR if r["quantity"].startswith("stored AI answers citing the page")))
P92 = "§9.2"
add(P92, "at Domain Ratings between 13 and 83", "13 and 83", dSR, sr("Domain Rating of the five domains").replace(" to ", " and "), exact=True)
add(P92, "Wikipedia, at 97, is co-cited in roughly 11,000", "97", dSR, sr("Domain Rating of wikipedia.org"))
add(P92, "Wikipedia, at 97, is co-cited in roughly 11,000", "11,000", dSR, sr("also cite wikipedia.org").replace("about ", ""))
add(P92, "are co-cited 9 times (Domain Rating 91) and 240 times (Domain Rating 87)", "9", dSR, sr("(Domain Rating 91)"))
add(P92, "are co-cited 9 times (Domain Rating 91) and 240 times (Domain Rating 87)", "240", dSR, sr("(Domain Rating 87)"))
add(P92, "against the section's 17,206", "17,206", dT5, t5("AI answers citing the section", 77))
P10 = "§10"
add(P10, "The section had zero live referring domains through 31 July", "0 through 31 July", "none:daily referring-domain series not released (Table 5 gives 0 at day 0 only)", None)
add(P10, "one on 10 August", "1", dT5, t5("Live referring domains", 15))
add(P10, "and nineteen on 25 August and still nineteen on 1 September", "19", dT5, t5("Live referring domains", 30))
add(P10, "and nineteen on 25 August and still nineteen on 1 September", "19", dT5, t5("Live referring domains", 37))
add(P10, "by which date it already held 15,830 ranking positions", "15,830", dT5, t5("Ranking positions, all", 37))
add(P10, "is reported by the instrument as 913", "913", dSR, sr("live referring domains to the prefix"))
add(P10, "daily series gives 909 at day 75", "909", dT5, t5("Live referring domains", 75))
add(P10, "September gives 917 new against 95 lost", "917", dSR, sr("new referring domains in September"))
add(P10, "September gives 917 new against 95 lost", "95", dSR, sr("lost referring domains in September"))
add(P10, "which with nineteen at day 37 implies about 841", "841", "arith:19 + 917 - 95", 19 + 917 - 95)
add(P10, "roughly nine hundred by day 75", "roughly 900", dT5, (t5("Live referring domains", 75), 850 <= n_(t5("Live referring domains", 75)) <= 950))
add(P10, "They are automated networks: 61.9% .info, 26.4% .asia, 10.2% .xyz", "61.9%", dSR, sr("share of those referring domains on .info"))
add(P10, "They are automated networks: 61.9% .info, 26.4% .asia, 10.2% .xyz", "26.4%", dSR, sr("share of those referring domains on .asia"))
add(P10, "They are automated networks: 61.9% .info, 26.4% .asia, 10.2% .xyz", "10.2%", dSR, [r["value"] for r in SRR if r["quantity"] == "share of those referring domains on .xyz" and r["instrument"] == "Ahrefs Site Explorer"][0])
add(P10, "every linking page at URL Rating below 10", "below 10", dSR, (sr("URL Rating of the linking pages"), sr("URL Rating of the linking pages") == "every linking page below 10"))
add(P10, "The second instrument indexes 80 referring domains", "80", dSR, sr("referring domains to the subfolder"))
add(P10, "88% from domains at Authority Score 0–10 and 75% on .xyz", "88%", dSR, sr("Authority Score 0 to 10"))
add(P10, "88% from domains at Authority Score 0–10 and 75% on .xyz", "75%", dSR, [r["value"] for r in SRR if r["quantity"] == "share of those referring domains on .xyz" and r["instrument"].startswith("Semrush")][0])
# Table 6 arithmetic from Table 5
T6M = md_table("*Table 6.")
for row in T6M[1:]:
    d0, d1 = map(int, re.match(r"Day (\d+) to (\d+)", row[0]).groups())
    r0, r1 = n_(t5("Live referring domains", d0)), n_(t5("Live referring domains", d1))
    p0, p1_ = n_(t5("Ranking positions, all", d0)), n_(t5("Ranking positions, all", d1))
    add(f"Table 6, {row[0]}, domains gained", row[2], row[2], "arith:Table 5", r1 - r0)
    add(f"Table 6, {row[0]}, positions gained", row[3], row[3], "arith:Table 5", p1_ - p0)
    add(f"Table 6, {row[0]}, rate", row[4], row[4].split(" /")[0], "arith:Table 5", (p1_ - p0) / (d1 - d0))
P101 = "§10.1"
p75, p37, p45 = n_(t5("Ranking positions, all", 75)), n_(t5("Ranking positions, all", 37)), n_(t5("Ranking positions, all", 45))
a75, a30, a45 = n_(t5("AI answers citing the section", 75)), n_(t5("AI answers citing the section", 30)), n_(t5("AI answers citing the section", 45))
add(P101, "Of the 43,302 positions held at day 75, 15,830 (36.6%)", "43,302", dT5, p75)
add(P101, "Of the 43,302 positions held at day 75, 15,830 (36.6%)", "36.6%", "arith:Table 5", 100 * p37 / p75)
add(P101, "and 27,472 (63.4%) were acquired after", "27,472", "arith:Table 5", p75 - p37)
add(P101, "and 27,472 (63.4%) were acquired after", "63.4%", "arith:Table 5", 100 * (p75 - p37) / p75)
add(P101, "that share is itself bounded rather than exact: 53.1% to 63.4%", "53.1%", "arith:Table 5", 100 * (p75 - p45) / p75)
add(P101, "that share is itself bounded rather than exact: 53.1% to 63.4%", "63.4%", "arith:Table 5", 100 * (p75 - p37) / p75)
add(P101, "the corresponding share is bounded 56.9% to 74.9%", "56.9%", "arith:Table 5", 100 * (a75 - a45) / a75)
add(P101, "the corresponding share is bounded 56.9% to 74.9%", "74.9%", "arith:Table 5", 100 * (a75 - a30) / a75)
add(P101, "dated only to an eight-day interval", "8", "arith:days 37 to 45", 45 - 37)
add(P101, "A result of 15,830 ranking positions and 1,874 top-three positions", "15,830", dT5, t5("Ranking positions, all", 37))
add(P101, "A result of 15,830 ranking positions and 1,874 top-three positions", "1,874", dT5, t5("Positions 1–3", 37))
add(P101, "with nineteen referring domains, a count unchanged for the preceding week", "unchanged", dT5, (f"{t5('Live referring domains', 30)} at day 30, {t5('Live referring domains', 37)} at day 37", t5("Live referring domains", 30) == t5("Live referring domains", 37) == "19"))
r_ = {re.match(r"Day (\d+) to (\d+)", r[0]).group(0): n_(r[4].split(" /")[0]) for r in T6M[1:]}
add(P101, "The fastest clean interval, 768 a day across days 15 to 30", "768", dT6, r_["Day 15 to 30"])
add(P101, "is 37% faster than the 562 a day of the arrival interval", "37%", "arith:Table 6 rates", 100 * (r_["Day 15 to 30"] / r_["Day 37 to 45"] - 1))
add(P101, "is 37% faster than the 562 a day of the arrival interval", "562", dT6, r_["Day 37 to 45"])
add(P101, "Reading the 132-a-day trough", "132", dT6, r_["Day 30 to 37"])
add(P101, "A 441-page section entering an index", "441", dT5, t5("Pages holding a position", 77))
add("§10.1 Figure 9 caption", "day 6 (984 positions, 186 in 1–3)", "984", dSR, sr("ranking positions at day 6"))
add("§10.1 Figure 9 caption", "day 6 (984 positions, 186 in 1–3)", "186", dSR, sr("positions 1 to 3 at day 6"))
add("§10.1 Figure 9 caption", "and day 67 (38,801 and 6,942)", "38,801", dSR, sr("ranking positions at day 67"))
add("§10.1 Figure 9 caption", "and day 67 (38,801 and 6,942)", "6,942", dSR, sr("positions 1 to 3 at day 67"))

# ---------------------------------------------------------------- Sections 12 to 15
add("§12 M1", "which differ by a factor that falls from 2.94 to 1.34", "2.94", "arith:Table 3 counts", T3V["July"]["b"] / T3V["July"]["k"])
add("§12 M1", "which differ by a factor that falls from 2.94 to 1.34", "1.34", "arith:Table 3 counts", T3V["October"]["b"] / T3V["October"]["k"])
add("§12 deployment", "between 53.1% and 63.4% of day-75 positions postdate its arrival", "53.1%", "arith:Table 5", 100 * (p75 - p45) / p75)
add("§12 deployment", "between 53.1% and 63.4% of day-75 positions postdate its arrival", "63.4%", "arith:Table 5", 100 * (p75 - p37) / p75)
add("§13", "(1.2 to 2.0 times the most-cited code page)", "1.2", "arith:single reads (Figure 8 values)", min(hubs) / top_code)
add("§13", "(1.2 to 2.0 times the most-cited code page)", "2.0", "arith:single reads (Figure 8 values)", max(hubs) / top_code)
add("§13", "The example ships a 924-query demonstration over the 66 codes in its registry extract, at digest `f05ce279942be5f8`", "924; 66; f05ce279942be5f8", nUFI, None)
add("§13", "lock digest `7290a2235d8de05f`, locked 12 October 2026", "α 0.5, β 0.5, damping 0.85, 3 phrasings, mean; 7290a2235d8de05f", nUFI, None)
add("§13", "Every one of the 372 geographic codes in service received a page", "372", dCP, sum(r["in_service"] == "Y" for r in geo))
add("§13", "the stamp is anchored in Bitcoin block 971,506", "971,506", "data:framework_test_r1 .ots proof (checks/ots_parse.py)", g(OTS, r"block height ([\d,]+)"),
    "the proof commits to the released manifest's SHA-256 and attests this height with merkle root 7bdc6025...59a3, as the folder README states")
add("§13", "mined at 04:05 UTC on 15 October 2026", "04:05 UTC, 15 Oct 2026", "none:block time is not in the bundle", None,
    "external check (blockstream.info): block 971,506 header time 2026-10-15T04:05:42Z, merkle root as in the proof")
add("§13", "were committed on 14 October 2026 and stamped with OpenTimestamps", "committed 14 Oct 2026", "none:the plan, predictors and script are held back; the manifest gives commit hashes only", None,
    "the manifest says it was written 2026-10-15 03:45 UTC (14 Oct, 23:45 US Eastern)")
add("§13", "(14 of 88 exports, 44,463 answers)", "14 of 88", "data:design file (amendment A3)", ("after 14 of 88 exports", "after 14 of 88 exports" in DESIGN))
add("§13", "(14 of 88 exports, 44,463 answers)", "44,463", "data:design file (amendment A3)", ("44,463 rows", "44,463 rows" in DESIGN), "the design file calls them rows")
add("§13", "Amendment A1 fixed a sampling rule of the 10,000 highest-volume prompts per sector and surface", "10,000", "data:design file (amendment A1)", ("10,000", "10,000" in DESIGN))
add("§13", "was stamped with OpenTimestamps before any reading under it, in the same Bitcoin block", "same block (971,506)", "none:the second-domain protocol and its proof are not in the bundle", None)
add("§13.1", "Costco is one of the 109 companies of Section 7", "Costco among the 109", "data:cross_sector_companies.csv", ("Costco" if any("Costco" in r["company_as_listed"] for r in COMP) else "absent", any("Costco" in r["company_as_listed"] for r in COMP)))
add("§14", "cited here as commit `149994a` of 12 October 2026", "149994a; 22 commits (21 + 1); version 0.2.0", nUFI, None)
add("§14", "moved from 14,823 (9 October) to 17,206 (11 October) and 17,400 (12 October)", "14,823", dT5, t5("AI answers citing the section", 75))
add("§14", "moved from 14,823 (9 October) to 17,206 (11 October) and 17,400 (12 October)", "17,206", dT5, t5("AI answers citing the section", 77))
add("§14", "moved from 14,823 (9 October) to 17,206 (11 October) and 17,400 (12 October)", "17,400", dPX, AH["/local/area-codes/"]["ahrefs_ai_responses"])
add("§14", "the October run-rate had moved by about 3% (worldwide 1,910,867, US 1,659,636)", "1,910,867", dSR, sr("re-read (worldwide)"))
add("§14", "the October run-rate had moved by about 3% (worldwide 1,910,867, US 1,659,636)", "1,659,636", dSR, sr("re-read (US)"))
add("§14", "the October run-rate had moved by about 3% (worldwide 1,910,867, US 1,659,636)", "about 3%", "arith:re-read against Table 2", (
    f"{100 * (1910867 / T2V['October']['ww'] - 1):.1f}% and {100 * (1659636 / T2V['October']['us'] - 1):.1f}%", all(2.5 <= 100 * (a / b - 1) <= 3.5 for a, b in ((1910867, T2V["October"]["ww"]), (1659636, T2V["October"]["us"])))))
for v, pat in (("1,056", r"numeric values: (\d+);"), ("899", r"numeric values: \d+; CANNOT RUN \d+, MATCH (\d+)"), ("1", r"numeric values: \d+; CANNOT RUN \d+, MATCH \d+, MISMATCH (\d+)"), ("156", r"numeric values: \d+; CANNOT RUN (\d+)")):
    add("§14 Use of AI tools", "of 1,056 numbers the paper quotes, 899 matched", v, "data:08_REVIEW/reproduction_v5.2_run2_2026-10-15/outputs/tally.txt", g(RUN2, pat))
add("§14 Use of AI tools", "one differed (Table 2's day count, now corrected)", "corrected", "arith:Table 2 days-live column (manuscript)", ([r for r in md_table("*Table 2.") if r[0].startswith("October")][0][1], [r for r in md_table("*Table 2.") if r[0].startswith("October")][0][1] == "11 (78 in all, days 0 to 77)"),
    "corrected in the manuscript; the released Table 2 CSV still reads '11 (77 cumulative)' (counted once, at the Table 2 cell)")
P15 = "§15"
add(P15, "by factors of 7.5 to 27.1 over four months", "7.5", "arith:Table 2 values", ratio_unm["October"])
add(P15, "by factors of 7.5 to 27.1 over four months", "27.1", "arith:Table 2 values", ratio_unm["August"])
add(P15, "(8.6 to 29.9 with both read worldwide)", "8.6", "arith:Table 2 values", ratio_ww["October"])
add(P15, "(8.6 to 29.9 with both read worldwide)", "29.9", "arith:Table 2 values", ratio_ww["August"])
add(P15, "about its growth by a factor of 2.7 in one month", "2.7", sIE, ie_g[1])
add(P15, "about its referring domains by a factor of eleven", "11", "arith:913 / 80", 913 / 80)
add(P15, "their ratio on estimated visits ran from one fifth to seven times", "one fifth to seven", sA, (f"{an_min}x to {an_max}x", round(1 / float(an_min)) == 5 and round(float(an_max)) == 7))
add(P15, "which of two sections was larger in 60 of 66 pairs", "60 of 66", sA, (f"{an_conc} of {an_pairs}", (an_conc, an_pairs) == ("60", "66")))
add(P15, "On 37,193 business reviews, the two agreed", "37,193", xAR, g(AR, r"reviews with text: (\d+)"))
add(P15, "(+0.47 to +0.75, depending on attribution)", "+0.47", sM2, g(M2, r"modal attribution: rho=([+-][\d.]+)"))
add(P15, "(+0.47 to +0.75, depending on attribution)", "+0.75", sM2, g(M2, r"split mentions: rho=([+-][\d.]+)"))
add(P15, "(+0.19, or +0.27 counting labels no review mentions)", "+0.19", sMP, mp_rho_m, "prints +0.185; the full value 0.184869 is +0.18 to two decimals (double rounding)")
add(P15, "(+0.19, or +0.27 counting labels no review mentions)", "+0.27", sM2, g(M2, r"unmentioned = 0\): ([+-][\d.]+)"))
add(P15, "one in seven unhappy reviews matched a waiting pattern", "one in seven", "arith:924 / 6,620", (f"1 in {6620 / 924:.2f}", round(6620 / 924) == 7))
add(P15, "the whole taxonomy holds 11 labels mentioning waiting", "11", xSUP, g(SUP, r"distinct such labels: (\d+)"))
add(P15, "with 622 searches a month", "622", xSUP, g(SUP, r"their monthly volume: (\d+)"))
add(P15, "a median 21% on Google's AI Overviews and AI Mode against 0.6% to 9.2%", "21%", sS7, s7_g)
add(P15, "a median 21% on Google's AI Overviews and AI Mode against 0.6% to 9.2%", "0.6%", sS7, s7_surf["copilot"])
add(P15, "a median 21% on Google's AI Overviews and AI Mode against 0.6% to 9.2%", "9.2%", sS7, s7_surf["gemini"])
add(P15, "higher on every Google view than on every other surface in every sector", "11 of 11", sS7, (f"{s7_every}/11", s7_every == "11"))
add(P15, "two of four predictions written before collection failed", "2 failed", sS7, (pt_str, pt_ok))
add(P15, "the section held 15,830 ranking positions with nineteen referring domains at day 37", "15,830", dT5, t5("Ranking positions, all", 37))
add(P15, "the section held 15,830 ranking positions with nineteen referring domains at day 37", "19", dT5, t5("Live referring domains", 37))
add(P15, "and by day 77 appeared in 17,206 recorded AI answers", "17,206", dT5, t5("AI answers citing the section", 77))

# ---------------------------------------------------------------- Appendix A and B
add("Appendix A", "The page count is 381, not 290", "381", dCP, len(CP))
add("Appendix A", "A 9.2x AI-answer comparison was withdrawn", "9.2x", "arith:158,100 / 17,206", 158100 / 17206)
add("Appendix A", "its days-live column sums to 78 (days 0 to 77)", "78", "arith:Table 2 days-live column (manuscript)", sum(int(r[1].split()[0]) for r in md_table("*Table 2.")[1:]))
add("Appendix A", "by a factor of 5.2 at 27.1x, not 13 times", "5.2", "arith:sqrt of 27.1", math.sqrt(ratio_unm["August"]))
add("Appendix A", "a stale copy of Figure 5 that printed −0.09 for −0.11 was replaced", "−0.11 in Figure 5", "figure:make_figs_v4.py (regenerated fig4_prefixes)", ("Spearman ρ = −0.11" if "Spearman ρ = −0.11" in FIGTXT else "absent", "Spearman ρ = −0.11" in FIGTXT))
add("Appendix A", "Branch agreement is +0.47 to +0.75 depending on how labels are attributed", "+0.47", sM2, g(M2, r"modal attribution: rho=([+-][\d.]+)"))
add("Appendix A", "Branch agreement is +0.47 to +0.75 depending on how labels are attributed", "+0.75", sM2, g(M2, r"split mentions: rho=([+-][\d.]+)"))
add("Appendix A", "replacing an earlier +0.78 computed on review-mentioned labels only", "+0.78", xAR, g(AR, r"branch-level Spearman: rho=([+-][\d.]+)"))
add("Appendix A", "the taxonomy holds 11 labels containing \"wait\", not one", "11", xSUP, g(SUP, r"distinct such labels: (\d+)"))
add("Appendix A", "the count of works naming the vendor tools is 456, not 459", "456", sVR, g(VR, r"; (\d+) name at least one tool"))
add("Appendix A", "the count of works naming the vendor tools is 456, not 459", "459", "data:vendor_reliance_works.csv (rows before de-duplication)", sum(int(r["n_tools"]) >= 1 for r in WORKS))
add("Appendix A", "(three works were counted twice)", "3", sVR, g(VR, r"\((\d+) duplicates dropped\)"))
add("Appendix B", "(about 0.22 when 30 of 66 entities have none)", "0.22", nUFI, None)
add("Appendix B", "(digest `7290a2235d8de05f`, set at 02:00 UTC on 12 October 2026)", "7290a2235d8de05f; 02:00 UTC", nUFI, None)
add("Appendix B", "The scoring code changed at 03:45 UTC the same day (commit `02d7588`", "03:45 UTC; 02d7588", nUFI, None)
add("Appendix B", "Its `rel` term correlates with node degree at roughly 0.8 in the released example", "0.8", nUFI, None)
add("Appendix B", "On the released example these are 4/5 and 70.4%", "4/5", nUFI, None)
add("Appendix B", "On the released example these are 4/5 and 70.4%", "70.4%", nUFI, None)
add("Appendix B", "with two of the four expressible questions answered for every subject", "2 of 4", nUFI, None)

# ---------------------------------------------------------------- Appendix C: Tables C1 to C4
C1M = md_table("*Table C1.")
SURF_NAME = {"AI Overviews, search queries": "aio_searchqueries", "AI Overviews, prompts": "aio_prompts", "AI Mode, search queries": "aimode_searchqueries",
             "AI Mode, prompts": "aimode_prompts", "ChatGPT": "chatgpt", "Perplexity": "perplexity", "Gemini": "gemini", "Copilot": "copilot"}
TYPE_ORDER = ["video_community", "reference", "news", "government", "report_brands", "other_web"]
c1 = {}
for m in re.finditer(r"  (\w+)\s+video_community ([^\n]+)", g(S7, r"== Appendix C1(.*?)== Appendix C2")):
    parts = ("video_community " + m.group(2)).split(" | ")
    c1[m.group(1)] = {p.split(" ")[0]: re.match(r"\S+ ([\d.]+)% \(([\d.]+)%-([\d.]+)%\)", p).groups() for p in parts}
for row in C1M[1:]:
    sk = SURF_NAME[row[0]]
    for j, t in enumerate(TYPE_ORDER, start=1):
        med_, lo_, hi_ = re.match(r"([\d.]+)% \(([\d.]+)–([\d.]+)\)", row[j]).groups()
        for lab, v, o in (("median", med_, c1[sk][t][0]), ("min", lo_, c1[sk][t][1]), ("max", hi_, c1[sk][t][2])):
            add(f"Table C1, {row[0]}, {C1M[0][j]}, {lab}", row[j], v, sS7, o)
C2M = md_table("*Table C2.")
ETF = {"Information Technology": "xlk", "Health Care": "xlv", "Financials": "xlf", "Consumer Discretionary": "xly", "Communication Services": "xlc",
       "Industrials": "xli", "Consumer Staples": "xlp", "Energy": "xle", "Utilities": "xlu", "Real Estate": "xlre", "Materials": "xlb"}
c2 = {m.group(1): m.group(2).split() for m in re.finditer(r"  (xl\w+)\s+([\d,. ]+)\n", g(S7, r"== Appendix C2(.*?)== Truncation"))}
for row in C2M[1:]:
    for j, v in enumerate(row[1:], start=1):
        add(f"Table C2, {row[0]}, {C2M[0][j]}", row[j], v, sS7, c2[ETF[row[0]]][j - 1], exact=True)
C3M = md_table("*Table C3.")
for row in C3M[1:]:
    for j, v in enumerate(row[1:], start=1):
        add(f"Table C3, {row[0]}, {C3M[0][j]}", row[j], v, sMT, c3[row[0]][j - 1], exact=True)
C4M = md_table("*Table C4.")
for row in C4M[1:]:
    for j in (1, 2):
        for k, v in enumerate(x.strip() for x in row[j].split(",")):
            add(f"Table C4, {row[0]}, {C4M[0][j]}, rank {k + 1}", row[j], v, sMT, [x.strip() for x in c4[row[0]][j - 1].split(",")][k], exact=True)
PC = "Appendix C after Table C4"
add(PC, "the top source is youtube.com or google.com in 38 of the 44 sector-by-view cells", "38", sMT, g(MT, r"youtube\.com or google\.com in (\d+) of 44"))
add(PC, "four of them Alphabet's own properties in Communication Services", "4", sMT, sum("†" in c3["Communication Services"][j] for j in range(4)))
add(PC, "On Perplexity and Gemini it is wikipedia.org or reddit.com in 15 of 22", "15", sMT, g(MT, r"wikipedia\.org or reddit\.com in (\d+) of 22"))
add(PC, "on ChatGPT a government domain in 4 of 11 sectors", "4", sMT, g(MT, r"a \.gov domain in (\d+) of 11"))
add(PC, "and on Copilot a retailer (walmart.com or amazon.com) in 6 of 11", "6", sMT, g(MT, r"walmart\.com or amazon\.com in (\d+) of 11"))

# ---------------------------------------------------------------- Appendix D, Table D1
PD = "Appendix D Table D1"
add(PD, "| 456; 86% (read 14 October 2026) | `vendor_reliance` |", "456", sVR, g(VR, r"; (\d+) name at least one tool"))
add(PD, "| 456; 86% (read 14 October 2026) | `vendor_reliance` |", "86%", sVR, g(VR, r"of \d+ \((\d+)%\); two or more"))
for v, o in (("7.5x", min(ratio_unm.values())), ("27.1x", max(ratio_unm.values())), ("8.6x", min(ratio_ww.values())), ("29.9x", max(ratio_ww.values())), ("9.2x", min(ratio_uu.values())), ("33.3x", max(ratio_uu.values()))):
    add(PD, "| 7.5x to 27.1x; 8.6x to 29.9x; 9.2x to 33.3x | arithmetic on Table 2 |", v, "arith:Table 2 values", o)
for v, o in zip(("0.95", "2.66", "1.37"), ie_g):
    add(PD, "| 0.95, 2.66, 1.37 | `instrument_extra` |", v, sIE, o)
add(PD, "| 5.2 at 27.1x | arithmetic on Table 2 |", "5.2", "arith:Table 2 values", math.sqrt(ratio_unm["August"]))
add(PD, "| 35% (US pairing), 54% (worldwide) | `instrument_extra` |", "35%", sIE, dec[3])
add(PD, "| 35% (US pairing), 54% (worldwide) | `instrument_extra` |", "54%", sIE, dec2[3])
add(PD, "| 0.20x to 7.24x (8.89x matched); median 1.01 | `analyze` |", "0.20x", sA, an_min)
add(PD, "| 0.20x to 7.24x (8.89x matched); median 1.01 | `analyze` |", "7.24x", sA, an_max)
add(PD, "| 0.20x to 7.24x (8.89x matched); median 1.01 | `analyze` |", "8.89x", sA, an_mmax)
add(PD, "| 0.20x to 7.24x (8.89x matched); median 1.01 | `analyze` |", "1.01", sA, g(A, r"median ([\d.]+), spread"))
add(PD, "| −0.11 [−0.64, +0.49], p = 0.73 | `analyze` |", "−0.11", sA, an_rho)
add(PD, "| −0.11 [−0.64, +0.49], p = 0.73 | `analyze` |", "−0.64", sA, g(A, r"Fisher 95% CI \[([+-][\d.]+),"))
add(PD, "| −0.11 [−0.64, +0.49], p = 0.73 | `analyze` |", "+0.49", sA, g(A, r"Fisher 95% CI \[[+-][\d.]+, ([+-][\d.]+)\]"))
add(PD, "| −0.11 [−0.64, +0.49], p = 0.73 | `analyze` |", "0.73", sA, g(A, r"permutation p = ([\d.]+)"))
add(PD, "| +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within |", "+0.94", sA, g(A, r"Spearman ([+-][\d.]+), Kendall"))
add(PD, "| +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within |", "+0.82", sA, g(A, r"Kendall tau ([+-][\d.]+)"))
add(PD, "| +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within |", "60 of 66", sA, (f"{an_conc} of {an_pairs}", (an_conc, an_pairs) == ("60", "66")))
add(PD, "| +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within |", "51 of 51", sIE, (f"{int(ie_310a) + int(ie_o10a)} of {int(ie_310) + int(ie_o10)}", int(ie_310a) + int(ie_o10a) == 51 == int(ie_310) + int(ie_o10)))
add(PD, "| +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within |", "9 of 15", sIE, (f"{ie_w3} of {ie_w3n}", (ie_w3, ie_w3n) == ("9", "15")))
add(PD, "| 1.13 and 3.1 | `instrument_extra` |", "1.13", sIE, g(IE, r"geometric mean ([\d.]+)x, geometric SD"))
add(PD, "| 1.13 and 3.1 | `instrument_extra` |", "3.1", sIE, g(IE, r"geometric SD ([\d.]+); normal"))
add(PD, "| 12.6% to 20.0% | arithmetic on Table 3 |", "12.6%", "arith:Table 3 counts", min(100 * T3V[m]["k"] / T3V[m]["n"] for m in MONTHS))
add(PD, "| 12.6% to 20.0% | arithmetic on Table 3 |", "20.0%", "arith:Table 3 counts", max(100 * T3V[m]["k"] / T3V[m]["n"] for m in MONTHS))
add(PD, "| 55.6%; 2.25 | `analyze_reviews` |", "55.6%", xAR, g(AR, r"at least one label: \d+ \(([\d.]+)%\)"))
add(PD, "| 55.6%; 2.25 | `analyze_reviews` |", "2.25", xAR, g(AR, r"labels per linked review ([\d.]+)"))
add(PD, "| +0.19 (mentioned), +0.27 (all linkable) |", "+0.19", sMP, mp_rho_m, "prints +0.185; the full value 0.184869 is +0.18 to two decimals (double rounding)")
add(PD, "| +0.19 (mentioned), +0.27 (all linkable) |", "+0.27", sM2, g(M2, r"unmentioned = 0\): ([+-][\d.]+)"))
add(PD, "| +0.47 (modal), +0.75 (split) |", "+0.47", sM2, g(M2, r"modal attribution: rho=([+-][\d.]+)"))
add(PD, "| +0.47 (modal), +0.75 (split) |", "+0.75", sM2, g(M2, r"split mentions: rho=([+-][\d.]+)"))
add(PD, "| 14.0% against 1.9% | `analyze_reviews` |", "14.0%", xAR, g(AR, r"mentioning waiting: \d+ \(([\d.]+)%\)"))
add(PD, "| 14.0% against 1.9% | `analyze_reviews` |", "1.9%", xAR, g(AR, r"in 5-star reviews: ([\d.]+)%"))
add(PD, "| 65% to 67%; kappa 0.90 (single-word labels about 50%, multi-word 95% to 96%) |", "65%", sLC, min(prec))
add(PD, "| 65% to 67%; kappa 0.90 (single-word labels about 50%, multi-word 95% to 96%) |", "67%", sLC, max(prec))
add(PD, "| 65% to 67%; kappa 0.90 (single-word labels about 50%, multi-word 95% to 96%) |", "0.90", sLC, g(LC, r"of 200 items; Cohen's kappa ([\d.]+)"))
add(PD, "| 65% to 67%; kappa 0.90 (single-word labels about 50%, multi-word 95% to 96%) |", "about 50%", sLC, (" and ".join(f"{x}%" for x in sw), all(45 <= x <= 55 for x in sw)))
add(PD, "| 65% to 67%; kappa 0.90 (single-word labels about 50%, multi-word 95% to 96%) |", "95%", sLC, min(mw))
add(PD, "| 65% to 67%; kappa 0.90 (single-word labels about 50%, multi-word 95% to 96%) |", "96%", sLC, max(mw))
add(PD, "| 83% to 85%, kappa 0.93; about 90% in store |", "83%", sLC, min(pb))
add(PD, "| 83% to 85%, kappa 0.93; about 90% in store |", "85%", sLC, max(pb))
add(PD, "| 83% to 85%, kappa 0.93; about 90% in store |", "0.93", sLC, g(LC, r"of 100 items; Cohen's kappa ([\d.]+)"))
add(PD, "| 83% to 85%, kappa 0.93; about 90% in store |", "about 90%", sLC, (" and ".join(f"{x}%" for x in instore), all(85 <= x <= 95 for x in instore)))
add(PD, "| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) | `cross_sector_sensitivity` |", "21.3%", sS7, s7_g, "also in cross_sector_sensitivity_output.txt (shipped)")
add(PD, "| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) | `cross_sector_sensitivity` |", "17.2", sS7, g(S7, r"median: Google ([\d.]+)% to"))
add(PD, "| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) | `cross_sector_sensitivity` |", "26.7", sS7, g(S7, r"median: Google [\d.]+% to ([\d.]+)%"))
add(PD, "| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) | `cross_sector_sensitivity` |", "2.1%", sS7, s7_c)
add(PD, "| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) | `cross_sector_sensitivity` |", "1.7", sS7, g(S7, r"other four ([\d.]+)% to [\d.]+%\n"))
add(PD, "| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) | `cross_sector_sensitivity` |", "2.7", sS7, g(S7, r"other four [\d.]+% to ([\d.]+)%\n"))
add(PD, "| 11 of 11 | `cross_sector_sensitivity` |", "11 of 11", sS7, (f"{s7_every}/11", s7_every == "11"))
add(PD, "| 0.36 to 0.40 against 0.08 to 0.23 | `cross_sector` |", "0.36", sS7, min(float(jac[p]) for p in ("aio_searchqueries", "aio_prompts", "aimode_searchqueries", "aimode_prompts")))
add(PD, "| 0.36 to 0.40 against 0.08 to 0.23 | `cross_sector` |", "0.40", sS7, max(float(jac[p]) for p in ("aio_searchqueries", "aio_prompts", "aimode_searchqueries", "aimode_prompts")))
add(PD, "| 0.36 to 0.40 against 0.08 to 0.23 | `cross_sector` |", "0.08", sS7, min(float(jac[p]) for p in ("chatgpt", "perplexity", "gemini", "copilot")))
add(PD, "| 0.36 to 0.40 against 0.08 to 0.23 | `cross_sector` |", "0.23", sS7, max(float(jac[p]) for p in ("chatgpt", "perplexity", "gemini", "copilot")))
add(PD, "| 77% against 14% (video and community) | `cross_sector_sensitivity2` |", "77%", sS7, vs_["video_community"][0])
add(PD, "| 77% against 14% (video and community) | `cross_sector_sensitivity2` |", "14%", sS7, vs_["video_community"][1])
add(PD, "| one held, one in direction, two failed | `cross_sector` |", "1, 1, 2", sS7, (pt_str, pt_ok))
add(PD, "| 4/5 (released example) | `ufi cq` |", "4/5", nUFI, None)
add(PD, "| 70.4% (released example) | `ufi cq` |", "70.4%", nUFI, None)

# ---------------------------------------------------------------- Figures: values drawn, against the released data
fig = {}
for node in ast.walk(ast.parse(FIGPY)):
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        try:
            fig.setdefault(node.targets[0].id, ast.literal_eval(node.value))
        except Exception:
            pass
PF = "figure:make_figs_v4.py"
for i, m in enumerate(MONTHS):
    add(f"Figure 2 (fig1_divergence), {m}, Ahrefs", "![Figure 2.", f"{fig['ahrefs'][i]:,}", PF, T2V[m]["a"], "drawn value against the released Table 2 CSV")
    add(f"Figure 2 (fig1_divergence), {m}, Semrush US", "![Figure 2.", f"{fig['sem_us'][i]:,}", PF, T2V[m]["us"])
    add(f"Figure 2 (fig1_divergence), {m}, Semrush worldwide", "![Figure 2.", f"{fig['sem_ww'][i]:,}", PF, T2V[m]["ww"])
for lab, m in zip(ast.literal_eval(re.search(r'\["25\.9x".*?\]', FIGPY).group(0)), MONTHS):
    add(f"Figure 2 (fig1_divergence), {m}, ratio label", "![Figure 2.", lab, PF, ratio_unm[m])
for i, m in enumerate(MONTHS):
    add(f"Figure 3 (fig2_aio), {m}, numerator", "![Figure 3.", f"{fig['num'][i]:,}", PF, T3V[m]["k"])
    add(f"Figure 3 (fig2_aio), {m}, denominator", "![Figure 3.", f"{fig['den'][i]:,}", PF, T3V[m]["n"])
    add(f"Figure 3 (fig2_aio), {m}, Semrush count", "![Figure 3.", f"{fig['semb'][i]:,}", PF, T3V[m]["b"])
for lab, m in zip(ast.literal_eval(re.search(r'\["2\.94x".*?\]', FIGPY).group(0)), MONTHS):
    add(f"Figure 3 (fig2_aio), {m}, ratio label", "![Figure 3.", lab, PF, T3V[m]["b"] / T3V[m]["k"])
rows_ = fig["rows"]
add("Figure 4 (fig3_refdomains), Ahrefs domains", "![Figure 4.", rows_[0][0].split("\n")[1].split()[0], PF, sr("live referring domains to the prefix"))
add("Figure 4 (fig3_refdomains), Semrush domains", "![Figure 4.", rows_[1][0].split("\n")[1].split()[0], PF, sr("referring domains to the subfolder"))
for tld, pct, *_ in rows_[0][1]:
    if tld != "other":
        add(f"Figure 4 (fig3_refdomains), Ahrefs {tld}", "![Figure 4.", f"{pct}%", PF, sr(f"share of those referring domains on {tld}") if tld != ".xyz" else [r["value"] for r in SRR if r["quantity"] == "share of those referring domains on .xyz" and r["instrument"] == "Ahrefs Site Explorer"][0])
    else:
        add("Figure 4 (fig3_refdomains), Ahrefs other", "![Figure 4.", f"{pct}%", PF, 100 - 61.9 - 26.4 - 10.2, "remainder of the three read shares")
add("Figure 4 (fig3_refdomains), Semrush .xyz", "![Figure 4.", f"{rows_[1][1][0][1]}%", PF, [r["value"] for r in SRR if r["quantity"] == "share of those referring domains on .xyz" and r["instrument"].startswith("Semrush")][0])
for name, a_, vr_, kr_ in fig["pref"]:
    add(f"Figure 5 (fig4_prefixes), {name}, age", "![Figure 5.", str(a_), PF, age(name))
    add(f"Figure 5 (fig4_prefixes), {name}, visits ratio", "![Figure 5.", f"{vr_:.2f}", PF, st[name] / at[name])
    add(f"Figure 5 (fig4_prefixes), {name}, keyword ratio", "![Figure 5.", f"{kr_:.1f}", PF, skw[name] / akw[name])
add("Figure 5 (fig4_prefixes), panel (a) title", "![Figure 5.", "−0.11", PF, an_rho, "title text 'Spearman ρ = −0.11'")
for name, n, _ in fig["pages"]:
    key = {"New York hub": "New York state hub", "California hub": "California state hub", "Texas hub": "Texas state hub", "Florida hub": "Florida state hub", "national hub": "national hub"}.get(name, name)
    add(f"Figure 8 (fig5_cited), {name}", "![Figure 8.", str(n), PF, hub[key])
for d, a_, t_ in zip(fig["days"], fig["pos_all"], fig["pos_top3"]):
    if d in T5D:
        add(f"Figure 9 (fig6_positions), day {d}, positions", "![Figure 9.", f"{a_:,}", PF, t5("Ranking positions, all", d))
        add(f"Figure 9 (fig6_positions), day {d}, positions 1-3", "![Figure 9.", f"{t_:,}", PF, t5("Positions 1–3", d))
    else:
        add(f"Figure 9 (fig6_positions), day {d}, positions", "![Figure 9.", f"{a_:,}", PF, sr(f"ranking positions at day {d}"))
        add(f"Figure 9 (fig6_positions), day {d}, positions 1-3", "![Figure 9.", f"{t_:,}", PF, sr(f"positions 1 to 3 at day {d}"))
for d, n in ast.literal_eval(re.search(r"for d, n in (\[\(30, 19\).*?\]):", FIGPY).group(1)):
    add(f"Figure 9 (fig6_positions), referring domains at day {d}", "![Figure 9.", str(n), PF, t5("Live referring domains", d))
for a_, b_, r__, stt in fig["iv"]:
    add(f"Figure 9 (fig6_positions), rate days {a_} to {b_}", "![Figure 9.", str(r__), PF, r_[f"Day {a_} to {b_}"])
add("Figure 1 (fig0_framework), panel (b)", "![Figure 1.", "60 of 66 pairs", "figure:make_fig0.py", (f"{an_conc} of {an_pairs}", "60 of 66 pairs" in FIG0PY and (an_conc, an_pairs) == ("60", "66")))
add("Figure 1 (fig0_framework), panel (b)", "![Figure 1.", "0.20x to 7.24x", "figure:make_fig0.py", (f"{an_min}x to {an_max}x", "0.20x to 7.24x apart" in FIG0PY and (an_min, an_max) == ("0.20", "7.24")))
add("Figure 6 (fig9_reviews), panel (a) title", "![Figure 6.", "+0.19", "figure:fig9_reviews.pdf as shipped (make_fig_reviews_v50.py cannot run)", mp_rho_m,
    "title hard-coded as +0.19; full value 0.184869 is +0.18 (double rounding)")
add("Figure 6 (fig9_reviews), panel (b) title", "![Figure 6.", "+0.75", "figure:fig9_reviews.pdf as shipped (make_fig_reviews_v50.py cannot run)", g(M2, r"split mentions: rho=([+-][\d.]+)"))
add("Figure 6 (fig9_reviews), panel (b) branches", "![Figure 6.", "the nine largest by review share", "figure:fig9_reviews.pdf as shipped", (
    "same nine, same order as m2_from_counts.py",
    [b.strip() for b in re.findall(r"\n  ([A-Z][^\n]*?)\s+[\d.]+%\s+[\d.]+%", M2)][:9] == [x for x in ["Mobile & Wireless Carriers", "Devices & Hardware", "Deals & Promotions", "Internet & Broadband (ISP)", "Plans & Pricing", "Support & Account", "TV & Streaming", "Business & Enterprise", "Communication Services"]]
    and all(x in FIGTXT for x in ["Mobile & Wireless Carriers", "Devices & Hardware", "Deals & Promotions", "Internet & Broadband (ISP)", "Plans & Pricing", "Support & Account", "TV & Streaming", "Business & Enterprise", "Communication Services"])))

# ---------------------------------------------------------------- coverage additions (found by checks/coverage.py)
PCA = "coverage additions"
add("Abstract", "On 381 area-code pages of a large US telecommunications provider", "381", dCP, len(CP))
add("§2 (information needs)", "(the 381 code pages rank for 29,000 keywords on one instrument)", "381", dCP, len(CP))
add("§2 (information needs)", "(the 381 code pages rank for 29,000 keywords on one instrument)", "29,000", dSR, sr("ranks 1 to 100 (all locations)"))
add("§3", "All 381 return HTTP 200, are canonical, and are full pages", "381", dCP, len(CP), "the count only; HTTP status and canonical tags are not in the released list")
add("§3", "the 50 states, the District, and the plan-wide toll-free codes", "50", dCP, len({r["location"] for r in CP} - {"DC", "NANP AREA"}))
add("§3", "**381** is the number of code pages the section holds", "381", dCP, len(CP))
add("§5.5 para 'no detectable relationship'", "give about 38% power to detect a correlation of 0.5", "0.5", sIE, ("0.5", "Spearman correlation of 0.5" in IE))
add("§5.6 limits", "the longitudinal series is one prefix over 77 days", "77", "arith:dates (26 Jul to 11 Oct 2026)", 77)
add("§7.2", "Each export holds the 1,000 domains found in the most answers, the most this table exports", "1,000", "data:cross_sector.py docstring (released script)", ("1,000 rows", "caps this table's export at 1,000 rows" in CSPY))
add("§7.3 Source types", "the share of the total sum of squares of the 88 cell shares", "88", sS7, g(S7, r"(\d+) cells; summed"))
for cut in ("100", "250", "500"):
    add("§7.5", "Restricting each export to its first 100, 250 or 500 rows", cut, xSE, (f"first {cut} export rows", f"first {cut} export rows only" in SE))
add("§8", "following the publication of 381 code pages and their hubs", "381", dCP, len(CP))
import datetime as _dt
for d in T5D:
    lab = [h for h in md_table("*Table 5.")[0] if h.replace("**", "").startswith(f"Day {d} ")][0].replace("**", "")
    shown = re.search(r"\((\d+ \w+)\)", lab).group(1)
    calc = (_dt.date(2026, 7, 26) + _dt.timedelta(days=d)).strftime("%-d %b")
    add(f"Table 5 header, day {d}", lab, shown, "arith:dates (day 0 = 26 Jul 2026)", calc, exact=True)
add("§8", "positions 11–20 were not captured that day", "n/r at day 77", dT5, (t5("Positions 11–20", 77), t5("Positions 11–20", 77) == "n/r"))
add("§8", "so the 21–100 row cannot be derived for it", "n/r at day 77", dT5, (t5("Positions 21–100 (derived)", 77), t5("Positions 21–100 (derived)", 77) == "n/r"))
add("§8", "the daily visits series was read only to day 75", "n/r at day 77", dT5, (t5("Estimated visits (Ahrefs)", 77), t5("Estimated visits (Ahrefs)", 77) == "n/r" and t5("Estimated visits (Ahrefs)", 75) != "n/r"))
add("§8", "Day 75 falls inside the window the Ahrefs data notice covers", "day 75 within days 65 to 75", "arith:dates", ("65 <= 75 <= 75", True))
add("§8 concentration", "Of the 441 URLs holding a position on 11 October", "441", dT5, t5("Pages holding a position", 77))
add("§9.1", "it grades a dedicated page about an entity 1.0 and a list or section page carrying a fact about it 0.5", "1.0 and 0.5", nUFI, None)
for d in (37, 60, 65):
    add("§10.1 Figure 9 caption", "the vertical rules mark the primary checkpoint (day 37), the September 2026 spam update (day 60) and the vendor data-reliability notice (day 65)",
        f"day {d}", "figure:make_figs_v4.py", (f"axvline({d})", f"ax.axvline({d}," in FIGPY))
add("§13", "the exports took the first 10,000 rows in the vendor's default order", "10,000", "data:design file (amendments A1 and A2)", ("10,000", "10,000" in DESIGN))
add("§14", "The frozen 924-query set, the parameter lock and the run manifest are committed in the repository", "924", nUFI, None)
add("§14", "all 22 commits at that point are AI-assisted: 21 carry the assistant as author and one as co-author", "22; 21; 1", nUFI, None)
add("§14", "the package declares Python 3.10 or later", "3.10", nUFI, None)
add("§14", "the 109-company list with its source", "109", "data:cross_sector_companies.csv", len(COMP))
add("§14 competitive effects", "mostly specialist directories at Domain Rating 13 to 83", "13 to 83", dSR, sr("Domain Rating of the five domains"), exact=True)
add("§14 conflicts", "that organization is also one of the 109 companies in Section 7", "109", "data:cross_sector_companies.csv", len(COMP))
add("Appendix B", "The coverage rubric grades 1.0 for a dedicated page about *e*", "1.0, 0.5, 0", nUFI, None)
add("Appendix B", "The answerability rubric grades 1.0 for an answer present", "1.0, 0.5, 0", nUFI, None)
add("Appendix B", "Five parameters are locked: α = 0.5, β = 0.5, damping = 0.85", "0.5, 0.5, 0.85", nUFI, None)

# =============================================================================================== evaluate
out = []
counts = {}
for i, r in enumerate(ROWS, start=1):
    present = r["quote"] in MS or re.sub(r"\s+", " ", r["quote"]) in MSN
    got = r["got"]
    ok = None
    try:
        if isinstance(got, tuple):
            got_s, ok = got
        elif got is None:
            got_s = ""
        else:
            got_s = got if isinstance(got, str) else (f"{got:.6g}" if isinstance(got, float) else str(got))
            ok = same(r["paper"], got, r["tol"], r["exact"])
    except Exception as e:  # noqa: BLE001
        got_s, ok = f"ERROR {e}", False
    kind = r["src"].split(":")[0]
    note = r["note"]
    if kind == "none":
        status = "CANNOT RUN"
    elif kind == "shipped":
        status = "CANNOT RUN"
        note = ("paper agrees with the saved output" if ok else "PAPER DISAGREES WITH THE SAVED OUTPUT") + (f"; {note}" if note else "")
    else:
        status = "MATCH" if ok else "MISMATCH"
    if not present:
        note = "QUOTE NOT FOUND IN MANUSCRIPT; " + note
    counts[status] = counts.get(status, 0) + 1
    out.append([str(i), r["loc"], r["paper"], r["quote"][:140], r["src"], got_s, status, note])

with TSV.open("w", newline="", encoding="utf-8") as f:
    w = csv.writer(f, delimiter="\t")
    w.writerow(["id", "location in the paper", "value quoted", "quoted text (first 140 characters)", "source", "obtained", "status", "note"])
    w.writerows(out)
print(f"checks: {len(out)}; " + ", ".join(f"{k} {v}" for k, v in sorted(counts.items())))
by = {}
for row in out:
    by.setdefault((row[4].split(":")[0], row[6]), 0)
    by[(row[4].split(":")[0], row[6])] += 1
print("by source kind and status: " + "; ".join(f"{k[0]} {k[1]} {v}" for k, v in sorted(by.items())))
print("MISMATCH rows:")
for row in out:
    if row[6] == "MISMATCH":
        print("  " + " | ".join(row))
print("rows whose quote was not found in the manuscript:")
for row in out:
    if row[7].startswith("QUOTE NOT FOUND"):
        print("  " + " | ".join(row[:4]))
print("CANNOT RUN rows where the paper disagrees with the saved output:")
for row in out:
    if "DISAGREES" in row[7]:
        print("  " + " | ".join(row))
