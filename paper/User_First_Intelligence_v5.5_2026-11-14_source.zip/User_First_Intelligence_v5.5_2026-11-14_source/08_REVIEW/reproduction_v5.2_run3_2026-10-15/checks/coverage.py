"""Coverage of the number check: every numeric token in the manuscript (outside the reference list) that is not inside
any quoted text of numbers_table.tsv, after setting aside tokens that are not quantities (section, table, figure,
appendix, amendment, prediction, lesson and item numbers; calendar dates, clock times, years and citation years;
version numbers). Table cells count as covered when a check quotes the cell exactly. What is left is printed with
its line, so omissions are visible and can be classified by hand.

Usage: python3 -I coverage.py <manuscript_v50.md> <numbers_table.tsv>
"""
import csv
import re
import sys

ms = open(sys.argv[1], encoding="utf-8").read().splitlines()
rows = list(csv.DictReader(open(sys.argv[2], encoding="utf-8"), delimiter="\t"))
quotes = [r["quoted text (first 140 characters)"].strip() for r in rows]
cellq = set(quotes)
NUM = re.compile(r"(?<![A-Za-z0-9_`./#-])[−+]?\d(?:[\d,]*\d)?(?:\.\d+)?(?:x|%|K)?(?![\w`])")
MONTHS = "January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec"
NOT_QTY = [
    re.compile(r"(Sections?|Tables?|Figures?|Figure|Appendix|Appendices|§|lesson|lessons|condition|conditions|item|items|Amendment|amendment|A|P|RQ|H|version|versions|v|Study|step|Steps|panel|Round|round|rounds|Measurement|Measurements|clause|section|sections)\s?$"),
]
ref_start = next(i for i, l in enumerate(ms) if l.startswith("## References"))
ref_end = next(i for i, l in enumerate(ms) if l.startswith("## Appendix A"))
left = []
for i, line in enumerate(ms):
    if ref_start <= i < ref_end or line.startswith("#"):
        continue
    spans = []
    for q in quotes:
        if len(q) >= 8:
            start = 0
            while (j := line.find(q, start)) >= 0:
                spans.append((j, j + len(q)))
                start = j + 1
    if line.startswith("|"):
        pos = 0
        for cell in line.strip().strip("|").split("|"):
            c = cell.strip()
            j = line.find(cell, pos)
            if c in cellq:
                spans.append((j, j + len(cell)))
            pos = j + len(cell)
    for m in NUM.finditer(line):
        tok = m.group(0)
        if any(a <= m.start() and m.end() <= b for a, b in spans):
            continue
        before, after = line[:m.start()], line[m.end():]
        if any(p.search(before) for p in NOT_QTY):
            continue
        if re.match(rf"\s?({MONTHS})\b", after) or re.search(rf"({MONTHS})\s$", before):
            continue  # calendar dates
        if re.fullmatch(r"(19|20)\d\d", tok) or re.match(r"^:\d\d", after) or re.search(r"\d:$", before):
            continue  # years, clock times
        if re.match(r"^\.\s", after) and (before.strip() == "" or before.endswith("\n")):
            continue  # list numbering
        if re.search(r"(Sections?|Tables?|Figures?|Appendix|and|to|,)\s$", before) and re.search(r"(Section|Table|Figure|Sections|Tables|Figures)\s[\d.,\sandto]*$", before):
            continue  # second element of a list of section or table references
        left.append((i + 1, tok, line[max(0, m.start() - 60):m.end() + 40]))
print(f"numeric tokens outside the reference list, not section/table/figure numbers, dates or years, and not inside any checked quote: {len(left)}")
for ln, tok, ctx in left:
    print(f"line {ln}: {tok!r}: ...{ctx}...")
