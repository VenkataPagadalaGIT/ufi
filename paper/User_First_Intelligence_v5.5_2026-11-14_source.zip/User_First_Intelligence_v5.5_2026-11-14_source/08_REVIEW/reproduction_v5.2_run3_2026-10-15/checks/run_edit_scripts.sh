#!/bin/bash
# Run each edit_v*.py change record in its own fresh copy of the pristine bundle (nested two folders deep, so that
# writes to the parent folders land inside the throwaway copy), then report the exit code, the last line of output,
# whether manuscript_v50.md changed, and whether any file was added or changed anywhere in the throwaway tree.
# Usage: run_edit_scripts.sh <pristine bundle folder> <scratch folder>
set -u
PRISTINE="$1"; SCRATCH="$2"
NAME=$(basename "$PRISTINE")
mkdir -p "$SCRATCH"
for script in $(cd "$PRISTINE" && ls edit_v*.py | sort -V); do
  T="$SCRATCH/${script%.py}/wrap1/wrap2"
  rm -rf "$SCRATCH/${script%.py}"
  mkdir -p "$T"
  cp -Rp "$PRISTINE" "$T/$NAME"
  (cd "$SCRATCH/${script%.py}" && find . -type f | LC_ALL=C sort | xargs shasum -a 256 > ../${script%.py}.before)
  out=$(cd "$T/$NAME" && python3 "$script" 2>&1); rc=$?
  (cd "$SCRATCH/${script%.py}" && find . -type f | LC_ALL=C sort | xargs shasum -a 256 > ../${script%.py}.after)
  if cmp -s "$PRISTINE/manuscript_v50.md" "$T/$NAME/manuscript_v50.md"; then ms="manuscript unchanged"; else ms="MANUSCRIPT CHANGED"; fi
  if cmp -s "$SCRATCH/${script%.py}.before" "$SCRATCH/${script%.py}.after"; then tree="no file added or changed"; else tree="FILES ADDED OR CHANGED: $(diff "$SCRATCH/${script%.py}.before" "$SCRATCH/${script%.py}.after" | grep '^[<>]' | awk '{print $1, $3}' | tr '\n' ' ')"; fi
  last=$(printf '%s\n' "$out" | tail -n 1 | cut -c1-170)
  printf '%s | exit %s | %s | %s | last line: %s\n' "$script" "$rc" "$ms" "$tree" "$last"
done
