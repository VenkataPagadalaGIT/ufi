"""Offline reader for OpenTimestamps proofs (.ots), written for this reproduction because the `ots` client is not
installed. For each proof it checks the file digest the proof commits to against the SHA-256 of the stamped file,
replays every operation in the proof tree, and prints each attestation with the message it attests: for a Bitcoin
block-header attestation that message is the block's merkle root (printed in the byte order block explorers show).
It does not contact any calendar or blockchain, so it cannot show that the block exists or when it was mined.

Usage: python3 -I ots_parse.py <stamped file> <its .ots proof>  [<stamped file> <proof> ...]
"""
import hashlib
import sys

MAGIC = b"\x00OpenTimestamps\x00\x00Proof\x00\xbf\x89\xe2\xe8\x84\xe8\x92\x94"
UNARY = {0x08: "sha256", 0x02: "sha1", 0x03: "ripemd160", 0x67: "keccak256", 0xf2: "reverse", 0xf3: "hexlify"}
BINARY = {0xf0: "append", 0xf1: "prepend"}
ATT = {bytes.fromhex("0588960d73d71901"): "bitcoin", bytes.fromhex("83dfe30d2ef90c8e"): "pending",
       bytes.fromhex("06869a0d73d71b45"): "litecoin"}


class Reader:
    def __init__(self, b):
        self.b, self.i = b, 0

    def byte(self):
        v = self.b[self.i]
        self.i += 1
        return v

    def bytes_(self, n):
        v = self.b[self.i:self.i + n]
        if len(v) != n:
            raise ValueError("truncated proof")
        self.i += n
        return v

    def varuint(self):
        v, shift = 0, 0
        while True:
            c = self.byte()
            v |= (c & 0x7F) << shift
            if not c & 0x80:
                return v
            shift += 7

    def varbytes(self):
        return self.bytes_(self.varuint())


def apply(op, arg, msg):
    if op == "sha256":
        return hashlib.sha256(msg).digest()
    if op == "sha1":
        return hashlib.sha1(msg).digest()
    if op == "ripemd160":
        return hashlib.new("ripemd160", msg).digest()
    if op == "reverse":
        return msg[::-1]
    if op == "hexlify":
        return msg.hex().encode()
    if op == "append":
        return msg + arg
    if op == "prepend":
        return arg + msg
    raise ValueError(f"operation {op} not supported here")


def walk(r, msg, path, out):
    def one(tag):
        if tag == 0x00:
            kind = ATT.get(r.bytes_(8), "unknown")
            payload = Reader(r.varbytes())
            if kind == "bitcoin":
                out.append(("bitcoin", payload.varuint(), msg, path))
            elif kind == "pending":
                out.append(("pending", payload.varbytes().decode("utf-8", "replace"), msg, path))
            else:
                out.append((kind, payload.b.hex(), msg, path))
        elif tag in UNARY:
            walk(r, apply(UNARY[tag], None, msg), path + [UNARY[tag]], out)
        elif tag in BINARY:
            arg = r.varbytes()
            walk(r, apply(BINARY[tag], arg, msg), path + [BINARY[tag]], out)
        else:
            raise ValueError(f"unknown tag 0x{tag:02x} at offset {r.i - 1}")

    tag = r.byte()
    while tag == 0xFF:
        one(r.byte())
        tag = r.byte()
    one(tag)


args = sys.argv[1:]
for stamped, proof in zip(args[0::2], args[1::2]):
    data, p = open(stamped, "rb").read(), open(proof, "rb").read()
    r = Reader(p)
    if r.bytes_(len(MAGIC)) != MAGIC:
        print(f"{proof}: not an OpenTimestamps proof (bad magic)")
        continue
    version = r.varuint()
    op = UNARY[r.byte()]
    digest = r.bytes_({"sha256": 32, "sha1": 20, "ripemd160": 20, "keccak256": 32}[op])
    actual = hashlib.new(op, data).digest()
    print(f"{proof.rsplit('/', 1)[-1]}: version {version}; file hash {op}; committed digest {digest.hex()}")
    print(f"  {op} of {stamped.rsplit('/', 1)[-1]} ({len(data)} bytes): {actual.hex()} -> "
          f"{'MATCHES the proof' if actual == digest else 'DOES NOT MATCH the proof'}")
    atts = []
    walk(r, digest, [], atts)
    print(f"  bytes left unread after the proof tree: {len(p) - r.i}")
    for kind, val, msg, path in atts:
        if kind == "bitcoin":
            print(f"  Bitcoin block-header attestation: block height {val:,}; attested merkle root "
                  f"(explorer byte order) {msg[::-1].hex()}; {len(path)} operations from the file digest")
        else:
            print(f"  {kind} attestation: {val}; {len(path)} operations")
