"""The value registry for the number table: every obtained value, pulled by regular expression from a rerun script's
stdout, from a shipped saved output, from a released data file or from the reproducer's recomputation, with its basis.
Bases: RUN (printed by a script rerun here), CALC (recomputed here from released files), FILE (a released data file holding
a dashboard read), CIRC (a series CSV the script parses from the manuscript's own table), SAVED (only in the saved output of a
script that cannot run here), BLOCK (public Bitcoin block data), NONE (no source in the bundle)."""
import csv
import json
import re
from pathlib import Path

R = Path(__file__).resolve().parents[1]
N = "User_First_Intelligence_v5.3_2026-11-03_source"
B = R / "pristine" / N
O = R / "outputs"
J = json.loads((R / "recomputed.json").read_text())

TXT = {
    "analyze": (O / "analyze.stdout").read_text(),
    "extra": (O / "instrument_extra.stdout").read_text(),
    "m2": (O / "m2_from_counts.stdout").read_text(),
    "r2": (O / "r2_link_check.stdout").read_text(),
    "vendor": (O / "vendor_reliance_offline.stdout").read_text(),
    "stakes": (O / "stakes_screen_check.stdout").read_text(),
    "wiki": (O / "wiki_demand_analysis.stdout").read_text(),
    "wsupp": (O / "wiki_demand_supplement.stdout").read_text(),
    "s7": (O / "section7_from_aggregates.stdout").read_text(),
    "tables": (O / "make_tables_sector_surface.stdout").read_text(),
    # saved outputs of scripts that cannot run here
    "reviews": (B / "review_demand/analyze_reviews_output.txt").read_text(),
    "sample": (B / "review_demand/r2_link_sample_output.txt").read_text(),
    "supp": (B / "review_demand/supplement_r10_output.txt").read_text(),
    "cs": (B / "ai_citation_cross_sector/scripts/cross_sector_output.txt").read_text(),
    "sens": (B / "ai_citation_cross_sector/scripts/cross_sector_sensitivity_output.txt").read_text(),
    "sens2": (B / "ai_citation_cross_sector/scripts/cross_sector_sensitivity2_output.txt").read_text(),
    "pilot": (B / "ai_citation_cross_sector/scripts/pilot_section_output.txt").read_text(),
    "wiki_shipped": (B / "wikipedia_demand/wiki_demand_analysis_output.txt").read_text(),
    "wlog": (B / "wikipedia_demand/collection_log.txt").read_text(),
    "plan": (B / "wikipedia_demand/wikipedia_demand_372.md").read_text(),
    "search": (B / "literature/checklist_search_2026-10-31/search_record.md").read_text(),
    "design": (B / "ai_citation_cross_sector/design/cross_sector_ai_citation_study.md").read_text(),
    "run3": (B / "08_REVIEW/reproduction_v5.2_run3_2026-10-15/reproduction_report.md").read_text(),
    "run4": (B / "08_REVIEW/reproduction_v5.2_run4_2026-10-15/reproduction_report.md").read_text(),
    "ots": (O / "_ots_check.log").read_text(),
}
SRC = {"analyze": "data/analyze.py", "extra": "instrument_extra.py", "m2": "m2_from_counts.py", "r2": "r2_link_check.py",
       "vendor": "vendor_reliance.py --offline", "stakes": "stakes_screen_check.py", "wiki": "wiki_demand_analysis.py",
       "wsupp": "wiki_demand_supplement.py", "s7": "section7_from_aggregates.py", "tables": "make_tables_sector_surface.py",
       "reviews": "analyze_reviews.py (saved output)", "sample": "r2_link_sample.py (saved output)", "supp": "supplement_r10.py (saved output)",
       "cs": "cross_sector.py (saved output)", "sens": "cross_sector_sensitivity.py (saved output)",
       "sens2": "cross_sector_sensitivity2.py (saved output)", "pilot": "project copy of cross_sector_sensitivity.py (saved output)",
       "wiki_shipped": "wiki_demand_analysis_output.txt (project run; the release run prints not available)",
       "wlog": "collection_log.txt", "plan": "wikipedia_demand_372.md", "search": "checklist search_record.md", "design": "cross_sector_ai_citation_study.md",
       "run3": "08_REVIEW run3 report", "run4": "08_REVIEW run4 report", "ots": "the .ots proofs, read here"}
BASIS_OF = {"analyze": "RUN", "extra": "RUN", "m2": "RUN", "r2": "RUN", "vendor": "RUN", "stakes": "RUN", "wiki": "RUN", "wsupp": "RUN",
            "s7": "RUN", "tables": "RUN", "reviews": "SAVED", "sample": "SAVED", "supp": "SAVED", "cs": "SAVED", "sens": "SAVED", "sens2": "SAVED",
            "pilot": "SAVED", "wiki_shipped": "SAVED", "wlog": "FILE", "plan": "FILE", "search": "FILE", "design": "FILE", "run3": "FILE", "run4": "FILE",
            "ots": "CALC"}
VALUES = {}


def num(s):
    return float(str(s).replace(",", "").replace("+", "").replace("−", "-").rstrip("x%"))


def v(name, obtained, basis, source, note=""):
    if name in VALUES:
        raise KeyError("duplicate value " + name)
    VALUES[name] = dict(obtained=obtained, basis=basis, source=source, note=note)


def rx(name, key, pat, group=1, cast=num, note="", basis=None):
    """Pull one value from an output by regular expression; a failure to find it stops the table."""
    m = re.search(pat, TXT[key], re.S)
    if not m:
        raise ValueError(f"{name}: pattern not found in {key}: {pat}")
    v(name, cast(m.group(group)), basis or BASIS_OF[key], SRC[key], note)


def many(key, pat, *names, cast=num):
    m = re.search(pat, TXT[key], re.S)
    if not m:
        raise ValueError(f"{names}: pattern not found in {key}: {pat}")
    for i, nm in enumerate(names, 1):
        if nm:
            v(nm, cast(m.group(i)), BASIS_OF[key], SRC[key])


def calc(name, key=None, value=None, note="", source="reproducer's recomputation (recompute.py)"):
    v(name, J[key] if key else value, "CALC", source, note)


# ---------------------------------------------------------------------------- Measurement 1, the twelve prefixes
many("analyze", r"min (\S+)x \(/local/bundles/\), max (\S+)x \(/local/area-codes/\), second (\S+)x \(/stores/\), median (\S+), spread (\S+) decades",
     "an.min", "an.max", "an.second", "an.median", "an.spread")
rx("an.below", "analyze", r"below one: (\d+) of 12")
rx("an.n", "analyze", r"n = (\d+) prefixes")
many("analyze", r"rho\(age, visits ratio\) = (\S+); Fisher 95% CI \[(\S+), (\S+)\]; permutation p = (\S+)", "an.rho", "an.lo", "an.hi", "an.perm")
rx("an.excl", "analyze", r"excluding the area-code section: rho = (\S+) ")
many("analyze", r"rho\(keyword ratio, visits ratio\) = (\S+); excluding area-codes (\S+)", "an.kw", "an.kwx")
many("analyze", r"keyword ratio Semrush/Ahrefs: min (\S+)x, max (\S+)x", "an.kwmin", "an.kwmax")
many("analyze", r"Spearman (\S+), Kendall tau (\S+), (\d+) of (\d+) pairs concordant, (\d+) discordant", "an.order", "an.tau", "an.conc", "an.pairs", "an.disc")
rx("an.power", "analyze", r"roughly (\d+)% power")
many("analyze", r"TERRITORY-MATCHED .*?: min (\S+)x, max (\S+)x, median (\S+), below one (\d+) of 12; rho\(age, ratio\) = (\S+)",
     "an.mmin", "an.mmax", "an.mmedian", "an.mbelow", "an.mrho")
for p, k in [("/product-compare/", "pc"), ("/device-compare/", "dc"), ("/es-us/local/", "es"), ("/local/area-codes/", "ac")]:
    rx(f"an.us.{k}", "analyze", re.escape(p) + r" (\d+)%")

# growth and decomposition
for key, lab in (("JA", r"July -> August"), ("AS", r"August -> September"), ("SO", r"September -> October \(run-rate\)")):
    many("extra", lab + r": Ahrefs worldwide (\S+)x; Semrush US (\S+)x; Semrush worldwide (\S+)x; Ahrefs growth / Semrush US growth (\S+)",
         f"g.{key}.a", f"g.{key}.s", f"g.{key}.w", f"g.{key}.r")
many("extra", r"Semrush US vs Ahrefs worldwide \(10-11 Oct\): visits (\S+)x = keywords (\S+)x x per-keyword (\S+)x; keyword share of log ratio (\d+)%",
     "d.us.v", "d.us.k", "d.us.p", "d.us.s")
many("extra", r"worldwide vs worldwide \(visits 10-11 Oct; keywords 12 Oct\): visits (\S+)x = keywords (\S+)x x per-keyword (\S+)x; keyword share of log ratio (\d+)%",
     "d.ww.v", "d.ww.k", "d.ww.p", "d.ww.s")
many("extra", r"differ within 3x: (\d+) of (\d+) ordered alike", "b.w3c", "b.w3n")
m_ = re.search(r"differ 3x to 10x: (\d+) of (\d+).*?differ over 10x: (\d+) of (\d+)", TXT["extra"], re.S)
v("b.beyond", int(m_[1]) + int(m_[3]), "RUN", SRC["extra"], "19 + 32 printed in two bands")
v("b.beyondn", int(m_[2]) + int(m_[4]), "RUN", SRC["extra"], "19 + 32 printed in two bands")
many("extra", r"unmatched ratio: geometric mean (\S+)x, geometric SD (\S+); normal range .*? (\S+)x to (\S+)x", "gm", "gsd", "gr.lo", "gr.hi")
many("extra", r"Spearman \(ordering\) (\S+) \[(\S+), (\S+)\]; Kendall (\S+) \[(\S+), (\S+)\]", None, "o.lo", "o.hi", None, "t.lo", "t.hi")
many("extra", r"geometric mean of the ratio \S+x \[(\S+)x, (\S+)x\]; geometric SD \S+ \[(\S+), (\S+)\]", "gm.lo", "gm.hi", "gsd.lo", "gsd.hi")
many("extra", r"sections aged seven to eleven years: (\d+); unmatched ratio (\S+)x to (\S+)x; matched (\S+)x to (\S+)x", "s7y.n", "s7y.ulo", "s7y.uhi", "s7y.mlo", "s7y.mhi")
rx("young", "extra", r"prefixes under twenty-one months old: (\d+)")
rx("kw2", "extra", r"keyword ratio, largest two: /stores/ \S+x, /local/bundles/ (\S+)x")
rx("rd.top", "extra", r"referring-domain ratio \(Ahrefs over Semrush\), largest two: /local/area-codes/ (\S+)x")
rx("power", "extra", r"\(Fisher approximation\): (\S+)%")
many("extra", r"all twelve prefixes \(n=12\): Spearman \S+; two-sided p (\S+) .*?without /local/area-codes/ \(n=11\): Spearman \S+; two-sided p (\S+) ", "kw.p", "kwx.p")
many("extra", r"more than 3x apart on both instruments: (\d+) of (\d+)", "f.both", "f.bothn")
many("extra", r"more than 3x apart on exactly one instrument: (\d+) of (\d+)", "f.one", "f.onen")
many("extra", r"within 3x on both instruments: (\d+) of (\d+)", "f.none", "f.nonen")
rx("f.subone", "extra", r"smallest keyword ratio among them (\S+)x")
many("extra", r"reversed: /local/area-codes/ and /local/internet/: \S+x apart on Ahrefs, (\S+)x on Semrush.*?reversed: /stores/ and /support/: (\S+)x apart on Ahrefs", "rev.a", "rev.b")
rx("rho.order.p", "extra", r"Spearman \+0\.937 \(p=(\S+)\)")
calc("A.conc", "A.concordant")
calc("t.err", "B.err_factor")
calc("t.err13", "B.err_abs_times")
for m in ("July", "August", "September", "October"):
    k = m[:3]
    calc(f"t2.{k}.us", f"B.t2.{m}.us_ww", source="arithmetic on Table 2 / its released CSV")
    calc(f"t2.{k}.ww", f"B.t2.{m}.ww_ww", source="arithmetic on Table 2 / its released CSV")
    calc(f"t2.{k}.uu", f"B.t2.{m}.us_us", source="arithmetic on Table 2 / its released CSV")
    calc(f"t3.{k}.pct", value=J[f"B.t3.{m}"]["pct"], source="arithmetic on Table 3 / its released CSV")
    calc(f"t3.{k}.lo", value=J[f"B.t3.{m}"]["lo"], source="Wilson interval on Table 3's counts")
    calc(f"t3.{k}.hi", value=J[f"B.t3.{m}"]["hi"], source="Wilson interval on Table 3's counts")
    calc(f"t3.{k}.r", value=J[f"B.t3.{m}"]["ratio"], source="arithmetic on Table 3 / its released CSV")
for nm, key in [("share.d37", "B.share_d37"), ("share.after", "B.share_after"), ("share.d45", "B.share_after_d45"), ("ai.lo", "B.ai_lo"), ("ai.hi", "B.ai_hi"),
                ("fast", "B.fastest_vs_arrival"), ("impl", "B.implied_end_sep"), ("ai.scope", "B.ai_scope"), ("cited.x", "B.cited_pages_times"), ("rd.x", "B.rd_ratio"),
                ("kw.x", "B.kw_us"), ("kw.ww", "B.kw_ww"), ("fifty", "B.fifty_of_441"), ("reread.us", "B.reread_oct_us"), ("reread.ww", "B.reread_oct_ww")]:
    calc(nm, key, source="arithmetic on the paper's own counts")
calc("hub.lo", value=J["B.hub_range"][0], source="arithmetic on Section 9.1's counts")
calc("hub.hi", value=J["B.hub_range"][1], source="arithmetic on Section 9.1's counts")

# the code pages list
g_ = J["C.groups"]
v("pages.all", J["C.rows"], "FILE", "section_code_pages_2026-10-14.csv")
v("pages.geo", J["C.registry_use"]["G"], "FILE", "section_code_pages_2026-10-14.csv")
v("pages.in", g_["geographic, in service"], "FILE", "section_code_pages_2026-10-14.csv")
v("pages.notin", g_["geographic, assigned, not in service"], "FILE", "section_code_pages_2026-10-14.csv")
v("pages.toll", g_["toll-free"], "FILE", "section_code_pages_2026-10-14.csv")
v("pages.loc", J["C.locations"], "FILE", "section_code_pages_2026-10-14.csv")

# single reads
SR = {}
for r in csv.DictReader((B / "instrument_divergence_extra/single_reads_2026-10.csv").open()):
    SR[(r["quantity"], r["read date as stated in the paper"][:10])] = r["value"]
    SR[(r["quantity"], r["instrument"])] = r["value"]
    SR[r["quantity"]] = r["value"]
Kv = lambda s: float(s.rstrip("K").replace(",", "")) * (1000 if s.endswith("K") else 1)


def sr(name, q, cast=num):
    m = SR[q]
    v(name, cast(m), "FILE", "single_reads_2026-10.csv", "dashboard read, not archived")


sr("sr.455", "distinct pages under the prefix cited in stored AI answers")
v("sr.mentions12", Kv(SR["mentions in the AI-visibility panel (identical for all twelve subfolders)"]), "FILE", "single_reads_2026-10.csv (158.3K)", "dashboard read, not archived")
v("sr.cited12", Kv(SR["cited pages in the AI-visibility panel (identical for all twelve subfolders)"]), "FILE", "single_reads_2026-10.csv (29.5K)", "dashboard read, not archived")
v("sr.mentions10", Kv(SR["mentions in the AI-visibility panel"]), "FILE", "single_reads_2026-10.csv", "dashboard read, not archived")
v("sr.cited10", Kv(SR["cited pages in the AI-visibility panel"]), "FILE", "single_reads_2026-10.csv", "dashboard read, not archived")
sr("sr.105", "countries in which the section ranks")
sr("sr.nonus", "share of Ahrefs-estimated visits from outside the US")
sr("sr.us", "Ahrefs' US share of its own visits used for the US-to-US ratios")
v("sr.11000", Kv(SR["answers citing the section that also cite wikipedia.org"].replace("about ", "")), "FILE", "single_reads_2026-10.csv (about 11,000)", "dashboard read, not archived")
sr("sr.c91", "answers citing the section that also cite a national carrier (Domain Rating 91)")
sr("sr.c87", "answers citing the section that also cite a national carrier (Domain Rating 87)")
sr("sr.d6", "ranking positions at day 6")
sr("sr.d6t", "positions 1 to 3 at day 6")
sr("sr.d67", "ranking positions at day 67")
sr("sr.d67t", "positions 1 to 3 at day 67")
sr("sr.top10", "share of estimated visits carried by the ten highest-traffic URLs of the 441 holding a position")
sr("sr.top50", "share of estimated visits carried by the top 50 of the 441 URLs")
sr("sr.rrww", "October run-rate visits on the Semrush re-read (worldwide)")
sr("sr.rrus", "October run-rate visits on the Semrush re-read (US)")
sr("sr.913", "live referring domains to the prefix")
sr("sr.info", "share of those referring domains on .info")
sr("sr.asia", "share of those referring domains on .asia")
v("sr.axyz", num(SR[("share of those referring domains on .xyz", "Ahrefs Site Explorer")]), "FILE", "single_reads_2026-10.csv", "dashboard read, not archived")
sr("sr.917", "new referring domains in September (new-and-lost report)")
sr("sr.95", "lost referring domains in September (new-and-lost report)")
sr("sr.80", "referring domains to the subfolder")
v("sr.sxyz", num(SR[("share of those referring domains on .xyz", "Semrush Backlink Analytics")]), "FILE", "single_reads_2026-10.csv", "dashboard read, not archived")
sr("sr.88", "share of those referring domains at Authority Score 0 to 10")
for nm, q in [("ny", "New York state hub"), ("ca", "California state hub"), ("tx", "Texas state hub"), ("fl", "Florida state hub"), ("nat", "national hub"),
              ("c214", "214 (Dallas) code page"), ("c786", "786 (Miami) code page"), ("c404", "404 (Atlanta) code page")]:
    sr("sr." + nm, "stored AI answers citing the page: " + q)
sr("sr.dr", "Domain Rating of the domain")
sr("sr.as", "Authority Score of the domain")
sr("sr.29000", "distinct keywords on which a URL under the prefix ranks 1 to 100 (all locations)")
sr("sr.58586", "distinct keywords on which a URL under the prefix ranks 1 to 100 (US database)")
v("sr.92k", Kv(SR["distinct keywords on which a URL under the prefix ranks 1 to 100 (worldwide)"]), "FILE", "single_reads_2026-10.csv (92.3K)", "read by the author; dashboard read, not archived")
sr("sr.17400", "stored AI answers citing the section")
sr("sr.wp", "Domain Rating of wikipedia.org")

# ---------------------------------------------------------------------------- Stakes
many("vendor", r"(\d+) name at least one tool", "st.456")
for y, n in (("2020", "st.2020"), ("2025", "st.2025"), ("2026", "st.2026")):
    rx(n, "vendor", y + r": (\d+)")
many("stakes", r"annotator 1: .*?= (\d+)% \[Wilson 95% (\d+)%, (\d+)%\]; of those, one vendor only \d+/\d+ = (\d+)% .*?compare vendors (\d+)", "st.a1", "st.a1lo", "st.a1hi", "st.a1one", "st.a1cmp")
many("stakes", r"annotator 2: .*?= (\d+)% \[Wilson 95% (\d+)%, (\d+)%\]; of those, one vendor only \d+/\d+ = (\d+)% .*?compare vendors (\d+)", "st.a2", "st.a2lo", "st.a2hi", "st.a2one", "st.a2cmp")
rx("st.kappa", "stakes", r"Cohen's kappa (\S+);")
rx("st.n", "stakes", r"judged by both annotators: (\d+)")

# ---------------------------------------------------------------------------- Section 6.1
rx("m2.rhom", "m2", r"Spearman over mentioned labels only \(published\): (\S+) ")
calc("m2.rhom.x", "D.rho_mentioned_exact", source="m2_label_counts.csv, to five decimals")
many("m2", r"mentioned labels: \S+ \[95% (\S+), (\S+)\] \(1008", "m2.rhom.lo", "m2.rhom.hi")
rx("m2.rhoa", "m2", r"Spearman over all linkable labels \(unmentioned = 0\): (\S+) ")
many("m2", r"all linkable labels: \S+ \[95% (\S+), (\S+)\] \(27817", "m2.rhoa.lo", "m2.rhoa.hi")
calc("m2.rhoa.hi.x", value=J["D.ci_all"][1], source="same seeded resampling as m2_from_counts.py, five decimals")
many("m2", r"split attribution: (\S+) \[95% (\S+), (\S+)\]", "m2.split", "m2.split.lo", "m2.split.hi")
many("m2", r"modal attribution: (\S+) \[95% (\S+), (\S+)\]", "m2.modal", "m2.modal.lo", "m2.modal.hi")
rx("m2.modal.p", "m2", r"modal attribution: rho=\S+ p=(\S+)")
rx("m2.split.p", "m2", r"split mentions: rho=\S+ p=(\S+) ")
rx("m2.nb", "m2", r"over (\d+) branches")
for lab, k in (("Mobile & Wireless Carriers", "car"), ("Devices & Hardware", "dev"), (r"Internet & Broadband \(ISP\)", "isp")):
    many("m2", lab + r"\s+(\S+)%\s+(\S+)%", f"m2.{k}.r", f"m2.{k}.v")
many("m2", r"own \(non-nested\) volumes: mentioned labels (\S+) \(p=\S+\); all linkable labels (\S+) ", "m2.ownm", "m2.owna")
many("m2", r"linkable labels (\d+); labels mentioned (\d+)", "m2.mwl", "m2.mwm")
many("m2", r"Multi-word.*?mentioned labels (\S+) \[95% (\S+), (\S+)\]", "mw.m", "mw.m.lo", "mw.m.hi")
many("m2", r"own volumes: split (\S+) \[95% (\S+), (\S+)\] \(p=\S+\); modal (\S+) ", "mw.s", "mw.s.lo", "mw.s.hi", "mw.mod")
many("m2", r"three largest branches by review share: Mobile & Wireless Carriers (\S+)% of mentions, (\S+)% of volume", "mw.car.r", "mw.car.v")
many("m2", r"linkable labels: (\d+); mentioned: (\d+)", "m2.link", "m2.ment")
calc("m2.unment", "D.unmentioned", source="m2_label_counts.csv")
calc("m2.ge20n", "D.n_ge20", source="m2_label_counts.csv")
calc("m2.ge20", "D.rho_ge20_exact", source="m2_label_counts.csv (ranks are enough for this correlation)")
calc("m2.tau", "D.tau_mentioned_exact", source="m2_label_counts.csv")
calc("m2.zero", "D.n_zero_volume_mentioned", source="m2_label_counts.csv: mentioned labels at the lowest volume rank")
calc("m2.zero.p", "D.arith_105", source="106 / 1008")
calc("m2.lt1000.p", "D.arith_36", source="367 / 1008")
calc("m2.linkrate", "D.arith_link_rate", source="20,663 / 37,193")
calc("m2.perlink", "D.arith_labels_per", source="46,517 / 20,663")
calc("w.neg.lo", value=J["D.wilson_neg"][0], source="Wilson on saved counts 924 of 6,620")
calc("w.neg.hi", value=J["D.wilson_neg"][1], source="Wilson on saved counts 924 of 6,620")
calc("w.5.lo", value=J["D.wilson_5star"][0], source="Wilson on saved counts 564 of 29,225")
calc("w.5.hi", value=J["D.wilson_5star"][1], source="Wilson on saved counts 564 of 29,225")
# saved only
rx("sv.reviews", "supp", r"review rows (\d+), with text")
rx("sv.text", "supp", r"with text (\d+);")
rx("sv.loc", "supp", r"locations in the export (\d+)")
rx("sv.loctext", "supp", r"with at least one text review (\d+)")
many("supp", r"reviews per location min (\d+), median (\d+), max (\d+)", "sv.rmin", "sv.rmed", "sv.rmax")
many("supp", r"owner responses name a carrier (\d+), naming (\d+) different", "sv.car", "sv.carn")
rx("sv.nodes", "supp", r"taxonomy nodes (\d+)")
rx("sv.kws", "supp", r"built from (\d+)")
rx("sv.linked", "reviews", r"reviews linked to at least one label: (\d+)")
rx("sv.linkedp", "reviews", r"reviews linked to at least one label: \d+ \((\S+)%\)")
rx("sv.perlink", "reviews", r"mean labels per linked review (\S+)")
rx("sv.links", "sample", r"links: (\d+) over")
rx("sv.ge20", "reviews", r"labels with >=20 mentions \((\d+)\): rho=(\S+)", 1)
rx("sv.ge20r", "reviews", r"labels with >=20 mentions \((\d+)\): rho=(\S+)", 2)
rx("sv.neg", "reviews", r"complaint labels \(>=20 mentions in 1-2 star reviews, (\d+)\): rho\(neg mentions, volume\)=(\S+)", 1)
rx("sv.negr", "reviews", r"complaint labels \(>=20 mentions in 1-2 star reviews, (\d+)\): rho\(neg mentions, volume\)=(\S+)", 2)
rx("sv.lt1000", "reviews", r"<1,000 monthly volume: (\d+)")
rx("sv.lt1000p", "reviews", r"<1,000 monthly volume: \d+ \((\S+)%\)")
rx("sv.tau", "reviews", r"Kendall tau=(\S+)")
rx("sv.12", "reviews", r"total monthly volume on them: (\d+)")
many("reviews", r"1-2 star reviews: (\d+); mentioning waiting: (\d+) \((\S+)%\); in 5-star reviews: (\S+)%", "sv.neg_n", "sv.wait", "sv.waitp", "sv.5")
many("supp", r"waiting pattern: one- and two-star \d+/\d+ = \S+ \[Wilson 95% (\S+)%, (\S+)%\]; five-star \d+/\d+ = \S+ \[(\S+)%, (\S+)%\]", "sv.w.lo", "sv.w.hi", "sv.5.lo", "sv.5.hi")
many("supp", r"nodes whose label contains 'wait': (\d+); distinct such labels: (\d+); their keywords: \d+; their monthly volume: (\d+)", "sv.w11", None, "sv.w622")
many("supp", r"naming appointments, queues or callbacks: (\d+) labels, (\d+) searches", "sv.a8", "sv.a13170")
rx("sv.mw", "supp", r"reviews linked (\d+) of 37193")
# link check
many("r2", r"annotator 1: \{'correct'.*?precision \d+/\d+ = (\S+)% \[Wilson 95% (\S+)%, (\S+)%\] excluding unclear; \d+/\d+ = (\S+)% \[(\S+)%, (\S+)%\]", "r2.a1", "r2.a1lo", "r2.a1hi", "r2.a1u", "r2.a1ulo", "r2.a1uhi")
many("r2", r"annotator 2: \{'correct'.*?precision \d+/\d+ = (\S+)% \[Wilson 95% (\S+)%, (\S+)%\]", "r2.a2", "r2.a2lo", "r2.a2hi")
many("r2", r"agreement: (\S+)% of 200 items; Cohen's kappa (\S+)", "r2.agree", "r2.kappa")
many("r2", r"200 sampled uniformly from (\S+) links", "r2.pop", cast=num)
many("r2", r"annotator 1: \{'yes'.*?precision \d+/\d+ = (\S+)% ", "r2.w1")
many("r2", r"annotator 2: \{'yes'.*?precision \d+/\d+ = (\S+)% ", "r2.w2")
rx("r2.wk", "r2", r"98\.0% of 100 items; Cohen's kappa (\S+)")
rx("r2.wpop", "r2", r"from the (\d+) one- and two-star matches")
many("r2", r"annotator 1, where.*?in store \d+/\d+ = (\S+)%", "r2.st1")
many("r2", r"annotator 2, where.*?in store \d+/\d+ = (\S+)%", "r2.st2")
many("r2", r"\(annotator 1\): \S+ x \S+ = (\S+)%", "r2.imp1")
many("r2", r"\(annotator 2\): \S+ x \S+ = (\S+)%", "r2.imp2")
many("r2", r"annotator 1, single-word labels: \S+ = (\S+)%", "r2.sw1")
many("r2", r"annotator 2, single-word labels: \S+ = (\S+)%", "r2.sw2")
many("r2", r"annotator 1, multi-word labels: \S+ = (\S+)%", "r2.mw1")
many("r2", r"annotator 2, multi-word labels: \S+ = (\S+)%", "r2.mw2")

# ---------------------------------------------------------------------------- Section 6.2
many("wiki", r"codes (\d+); covered by an article whose title names the code (\d+); not covered (\d+)", "w.codes", "w.cov", "w.not")
many("wiki", r"article groups (\d+);", "w.groups")
many("wsupp", r"articles \d+; about one code (\d+), two (\d+), three to five (\d+)", "w.g1", "w.g2", "w.g35")
many("wiki", r"dem\(g\) vs W\(g\): Spearman (\S+) \[(\S+), (\S+)\], Kendall (\S+), n", "w.rho", "w.lo", "w.hi", "w.tau")
many("wiki", r"K\(g\) keywords vs W\(g\): Spearman (\S+) \[(\S+), (\S+)\]", "w.k", "w.k.lo", "w.k.hi")
many("wiki", r"median (\S+) searches per request; 10th percentile (\S+); 90th (\S+);", "w.med", "w.p10", "w.p90")
many("wiki", r"geometric SD (\S+); for comparison, the vendor volume's own geometric SD across these groups (\S+) and the requests' (\S+)", "w.gsd", "w.gsdv", "w.gsdw")
many("wsupp", r"minimum (\S+), maximum (\S+); between 15,000 and 50,000: \d+ of \d+ \((\S+)%\)", "w.wmin", "w.wmax", "w.w15")
many("wsupp", r"vendor summed volume: minimum (\S+), maximum (\S+)", "w.vmin", "w.vmax")
many("wsupp", r"shifted window: (\S+)", "w.shift")
many("wsupp", r"six months outside the reclassified span: (\S+)", "w.six")
many("wsupp", r"median month: (\S+)", "w.medm")
many("wsupp", r"article title only: (\S+)\n", "w.title")
many("wsupp", r"primary: (\S+)", "w.prim")
many("wsupp", r"Aug to Sep 2026: (\S+)", "w.post")
many("wsupp", r"single-code articles: (\S+)", "w.single")
many("wiki", r"single-code groups only: Spearman (\S+) \[(\S+), (\S+)\], Kendall \S+, n = (\d+)", "w.s1", "w.s1.lo", "w.s1.hi", "w.s1.n")
many("wiki", r"excluding those groups: Spearman (\S+) ", "w.drop")
many("wiki", r"groups dropped for containing a late or zero-keyword code: (\d+) ", "w.dropn")
many("wiki", r"dem\(g\) vs requests Aug to Sep 2026: Spearman (\S+) \[(\S+), (\S+)\]", "w.p2", "w.p2.lo", "w.p2.hi")
many("wiki", r"stability of the public count\): Spearman (\S+) ", "w.stab")
many("wiki", r"pooled (\S+)%; across the 240 groups with requests, median (\S+)%", "w.pool", "w.medr")
many("wsupp", r"10,287 against 2,224, (\S+) times", "w.spike")
many("wsupp", r"later month than September 2024: (\d+);", "w.ten")
many("wsupp", r"\(n = 230\), all titles: (\S+)", "w.x10a")
many("wsupp", r"\(n = 230\), article title only: (\S+)", "w.x10t")
many("wsupp", r"among those 10 articles: (\d+)%.*?(\d+)%\n", "w.rlo", "w.rhi")
rx("w.cgs", "wiki_shipped", r"not a test of the score\): Spearman (\S+) ", note="the release run prints 'not available'; the per-code scores are not in the bundle")
rx("w.req", "wlog", r"(\d+) requests in all")
calc("w.req.c", "F.raw_lines_sum", source="lines in the released resolution, redirects and pageviews files")

# ---------------------------------------------------------------------------- Section 7
many("s7", r"summed over sectors (\S+); range (\S+) \(xlu\) to (\S+) \(xly\)", "s.ans", "s.ansmin", "s.ansmax")
many("s7", r"per cell (\S+) to (\S+); registrable domains per export (\d+) to (\d+)", "s.cmin", "s.cmax", "s.dmin", "s.dmax")
many("s7", r"Google views median (\S+)% \(range (\S+)% to (\S+)%\); other four median (\S+)% \(range (\S+)% to (\S+)%\)", "s.g", "s.glo", "s.ghi", "s.o", "s.olo", "s.ohi")
for p, k in (("aio_searchqueries", "aios"), ("aio_prompts", "aiop"), ("aimode_searchqueries", "aims"), ("aimode_prompts", "aimp"), ("chatgpt", "gpt"), ("perplexity", "per"), ("gemini", "gem"), ("copilot", "cop")):
    many("s7", r"per surface:.*?" + p + r" (\S+?)%", f"s.{k}")
rx("s.dom", "s7", r"highest other surface: (\d+)/11")
rx("s.gpr", "s7", r"Google prompt views only: median (\S+)%")
many("s7", r"Google (\S+)% to (\S+)%; other four (\S+)% to (\S+)%", "s.gb", "s.gbh", "s.ob", "s.obh")
many("s7", r"without YouTube: Google median (\S+)%, other four (\S+)%; lowest Google view above highest other in (\d+)/11", "s.ng", "s.no", "s.nd")
many("s7", r"top three on Google views (\d+)/(\d+); on the other four (\d+)/(\d+)", "s.t3", "s.t3n", "s.t30", "s.t3m")
for p, k in (("aio_searchqueries", "aios"), ("aimode_searchqueries", "aims"), ("chatgpt", "gpt"), ("perplexity", "per"), ("gemini", "gem"), ("copilot", "cop")):
    many("s7", r"  " + p + r"\s+median rank\s+(\d+)", f"s.r.{k}")
many("s7", r"reference\s+Google (\S+)%; other four (\S+)%", "s.refg", "s.refo")
many("s7", r"forum\s+Google (\S+)%; other four (\S+)%", "s.forg", "s.foro")
many("s7", r"report_brands\s+Google (\S+)%; other four (\S+)%", "s.brg", "s.bro")
many("s7", r"other_web\s+Google (\S+)%; other four (\S+)%; Copilot (\S+)%", "s.owg", "s.owo", "s.owc")
many("s7", r"P1 sectors with YouTube first, per view \{'aio_searchqueries': (\d+), 'aio_prompts': (\d+), 'aimode_searchqueries': (\d+), 'aimode_prompts': (\d+)\}", "p1.a", "p1.b", "p1.c", "p1.d")
many("s7", r"P2 sectors with YouTube outside the top five \{'chatgpt': (\d+), 'perplexity': (\d+), 'copilot': (\d+)\}", "p2.a", "p2.b", "p2.c")
many("s7", r"top ten on every surface but Copilot (\d+)/11 -> fails; ChatGPT fails in (\d+) of the (\d+)", "p3", "p3.f", None)
many("s7", r"P4 aio_searchqueries: consumer (\S+)% against other (\S+)%; exact one-sided p (\S+)", "p4.a", "p4.b", "p4.c")
many("s7", r"P4 aio_prompts: consumer (\S+)% against other (\S+)%; exact one-sided p (\S+)", "p4.d", "p4.e", "p4.f")
many("s7", r"Google views (\S+) to (\S+); other four (\S+) to (\S+)", "j.glo", "j.ghi", "j.olo", "j.ohi")
many("s7", r"across the (\d+) sector pairs", "j.pairs")
many("s7", r"== Variance.*?video_community\s+surface (\d+)%\s+sector (\d+)%", "va.s", "va.t")
many("s7", r"== Variance.*?news\s+surface (\d+)%\s+sector (\d+)%", "va.ns", "va.nt")
many("s7", r"== Variance.*?government\s+surface (\d+)%\s+sector (\d+)%", "va.gs", "va.gt")
many("s7", r"== Variance.*?report_brands\s+surface (\d+)%\s+sector (\d+)%", "va.bs", "va.bt")
many("s7", r"bootstrap video_community\s+surface \[(\d+)%, (\d+)%\]\s+sector \[(\d+)%, (\d+)%\]", "va.slo", "va.shi", "va.tlo", "va.thi")
many("s7", r"range of medians (\S+)% to (\S+)%", "tr.lo", "tr.hi")
many("s7", r"aio_searchqueries\s+video and community (\S+)% -> (\S+)%", "rtx.a", "rtx.b")
many("s7", r"perplexity\s+video and community (\S+)% -> (\S+)%", "rtx.pa", "rtx.pb")
many("s7", r"gemini\s+video and community (\S+)% -> (\S+)%", "rtx.ga", "rtx.gb")
rx("rtx.r", "s7", r"aimode_prompts\s+video and community \S+ -> \S+; YouTube rank (\d+) -> \d+")
rx("rtx.r2", "s7", r"aimode_prompts\s+video and community \S+ -> \S+; YouTube rank \d+ -> (\d+)")
rx("rtx.r1", "s7", r"aio_searchqueries\s+video and community \S+ -> \S+; YouTube rank (\d+)")
# saved only, row-level
many("sens", r"'Found in' instead of 'Cited in': Google median (\S+)%, other four median (\S+)%.*?in (\d+)/11", "sn.f.g", "sn.f.o", "sn.f.d")
many("sens", r"largest single host instead of summed hosts: Google median (\S+)%, other four median (\S+)%.*?in (\d+)/11", "sn.h.g", "sn.h.o", "sn.h.d")
many("sens", r"company properties counted as company domains: Google median (\S+)%, other four median (\S+)%.*?in (\d+)/11", "sn.p.g", "sn.p.o", "sn.p.d")
for n_, k in ((100, "t1"), (250, "t2"), (500, "t3")):
    many("sens", rf"first {n_} export rows only: Google median (\S+)%, other four median (\S+)%", f"sn.{k}.g", f"sn.{k}.o")
many("sens", r"AI Mode \(search queries\) (\S+)% -> (\S+)%", "cs.lo.a", "cs.lo.b")
many("sens", r"AI Overviews \(prompts\) (\S+)% -> (\S+)%", "cs.hi.a", "cs.hi.b")
many("sens", r"Gemini 15\.0% -> (\S+)%", "cs.gem")
rx("sn.set", "sens", r"P1 with google\.com set aside: .*?both products (\d+)")
many("sens", r"ChatGPT without Industrials \(RTX\): comm\+video median (\S+)%", "sn.xi")
for nm, lab in (("dm.mat", "Sherwin-Williams"), ("dm.dis", "Amazon"), ("dm.sta", "Walmart"), ("dm.it", "Apple"), ("dm.ind", "Uber")):
    rx(nm, "sens", lab + r"\s+(\S+)%")
many("sens", r"AI Overviews \(search queries\)\s+state\.gov\+uscis\.gov\+cbp\.gov\+dhs\.gov (\S+)%", "visa")
many("sens2", r"company properties\s+AI Overviews \(search queries\)\s+(\S+)% vs (\S+)%, p (\S+)", "p4c.a", "p4c.b", "p4c.p")
rx("p4.pmin", "sens2", r"first 500 rows\s+AI Overviews \(prompts\)\s+\S+ vs \S+, p (\S+)")
many("sens2", r"AI Mode \(search queries\)\s+www\.google\.com (\d+)%", "h.s")
many("sens2", r"AI Mode \(prompts\)\s+www\.google\.com (\d+)%", "h.p")
many("sens2", r"P2 ChatGPT\s+(\d+)/(\d+)\s+P2 Perplexity\s+(\d+)/(\d+)\s+P2 Copilot\s+(\d+)/(\d+)\s+P3 (\d+)/(\d+)", "xi.a", "xi.an", "xi.b", "xi.bn", "xi.c", "xi.cn", "xi.d", "xi.dn")
many("pilot", r"ChatGPT\s+YouTube non-brand rank (\d+)", "pi.gpt")
many("pilot", r"Perplexity\s+YouTube non-brand rank (\d+)", "pi.per")
many("pilot", r"Gemini\s+YouTube non-brand rank (\d+)", "pi.gem")
many("pilot", r"Copilot\s+YouTube non-brand rank (\d+); Reddit (\d+)", "pi.cop", "pi.red")
many("tables", r"top source youtube\.com or google\.com in (\d+) of (\d+) cells", "tb.g", "tb.gn")
many("tables", r"Copilot: top source walmart\.com or amazon\.com in (\d+) of (\d+) sectors", "tb.c", "tb.cn")
many("tables", r"top source wikipedia\.org or reddit\.com in (\d+) of (\d+) cells", "tb.p", "tb.pn")
many("tables", r"top source a \.gov domain in (\d+) of (\d+) sectors", "tb.gv", "tb.gvn")
v("co.109", J["G.n_company_rows"], "CALC", "cross_sector_companies.csv")
v("co.64", J["G.n_props"], "CALC", "cross_sector_company_properties.csv")
rx("de.14", "design", r"stopped at 01:39 after (\d+) of 88 exports")
rx("de.44463", "design", r"(44,463) rows")
rx("de.8", "design", r"(Eight) exports that repeated", cast=lambda s: 8.0)
rx("de.64", "design", r"A list of (\d+) secondary domains")
rx("lit.72", "search", r"(\d+) logged API queries")

# ---------------------------------------------------------------------------- stamps and earlier reproductions
blocks = {}
for h in (971506, 971522, 973934, 973943, 973953):
    blocks[h] = json.loads((O / "blocks" / f"{h}.json").read_text())
v("bk.971506", 971506.0, "CALC", "protocols_manifest and framework manifest .ots proofs, read here; merkle root equals the block's")
v("bk.971522", 971522.0, "CALC", "framework amendment .ots proof, read here; merkle root equals the block's")
rx("r4.n", "run4", r"\*\*Numbers:\*\* (1,479) numbers")
rx("r4.m", "run4", r"\*\*(1,342) MATCH")
rx("r4.d", "run4", r"MATCH, (0) MISMATCH")
rx("r4.c", "run4", r"MISMATCH, (137) CANNOT RUN")
rx("r3.d", "run3", r"(\d+) MISMATCH")
