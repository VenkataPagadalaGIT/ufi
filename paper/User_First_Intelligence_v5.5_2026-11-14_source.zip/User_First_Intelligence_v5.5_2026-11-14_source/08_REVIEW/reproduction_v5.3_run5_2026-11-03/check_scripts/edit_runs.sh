#!/bin/bash
R=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run5
RUN="python3 $R/check_scripts/run_one.py"
N=User_First_Intelligence_v5.3_2026-11-03_source
B=$R/pristine/$N
cd "$B"
for f in edit_v*.py; do t=${f%.py}; RUN_TIMEOUT=60 $RUN $t . - -- python3 $f 2>&1 | cut -c1-200; tail -1 "$R/outputs/$t.stderr" | cut -c1-160; rm -rf "$R/runs/$t"; done
