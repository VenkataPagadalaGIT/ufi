"""Statements in words that a released output decides, and the numeric labels printed inside the figures."""
import csv
import re
import subprocess
from collections import Counter

from values import B, J, TXT, VALUES

val = lambda k: VALUES[k]["obtained"]
s7, w = TXT["s7"], TXT["wiki"]
p1_fail = "on both products 4/11 -> fails" in s7
p2_hold = "'copilot': 11} -> holds" in s7
p3_fail = "3/11 -> fails" in s7
p4_dir = val("p4.a") > val("p4.b") and val("p4.d") > val("p4.e") and val("p4.c") > 0.05 and val("p4.f") > 0.05
tally_m3 = p1_fail and p2_hold and p3_fail and p4_dir
wiki_tally = "P1 held; P2 held (boundary); P3 held; P4 held" in w
hub = Counter(r["location"] for r in csv.DictReader((B / "instrument_divergence_extra/section_code_pages_2026-10-14.csv").open()))
hub_per_code = all(v / hub[k] < 238 for k, v in (("NY", 474), ("CA", 337), ("TX", 322), ("FL", 304)))
P = J["prefixes"]
FACTS = [
    (r"one held, one held in direction only and two failed", tally_m3, "RUN", "section7_from_aggregates.py: P1 fails, P2 holds, P3 fails, P4 in direction with p 0.27 and 0.21"),
    (r"one held, one in direction, two failed", tally_m3, "RUN", "section7_from_aggregates.py"),
    (r"two of four predictions written before collection failed", tally_m3, "RUN", "section7_from_aggregates.py"),
    (r"P1, P3 and P4 held; P2 held at its boundary", wiki_tally, "RUN", "wiki_demand_analysis.py"),
    (r"Prediction P1 \(positive, with an interval excluding zero\) held", val("w.lo") > 0, "RUN", "wiki_demand_analysis.py: P1 HELD"),
    (r"P2 \(a point estimate between \+0\.40 and \+0\.80, the band inside which Measurement 2's branch-level estimates fall\) held at its boundary", "P2 (point estimate between +0.40 and +0.80): HELD (boundary" in w and 0.40 < val("m2.modal") < 0.80 and 0.40 < val("m2.split") < 0.80, "RUN", "wiki_demand_analysis.py; m2_from_counts.py"),
    (r"P4 \(every code covered by an article that names it\) held", "P4 (every code covered by an article that names it): HELD" in w, "RUN", "wiki_demand_analysis.py"),
    (r"\(P3, held;", "exceeds" not in "" and "above 3.1, Measurement 1's figure for the vendor pair): HELD" in w, "RUN", "wiki_demand_analysis.py"),
    (r"no title was missing and none lacked data", "titles with no pageview data 0" in w and "not covered 0" in w and J["F.pageview_status"] == {"200": 1249}, "CALC", "wiki_demand_analysis.py; pageviews.jsonl: 1,249 responses, all status 200"),
    (r"so a request by any name for an article is counted once|so that a request by any name for an article is counted once", J["F.group_vs_title_differences"] == {} and J["F.monthly_vs_raw_mismatches"] == 0, "CALC", "pageviews.jsonl to pageviews_monthly.csv to wiki_groups.csv recomputed: no difference"),
    (r"about ten times their pooled median share", 9.5 <= val("s.g") / val("s.o") <= 10.5, "RUN", "21.3 / 2.1 from section7_from_aggregates.py"),
    (r"about ten times the pooled median share", 9.5 <= val("s.g") / val("s.o") <= 10.5, "RUN", "21.3 / 2.1 from section7_from_aggregates.py"),
    (r"the ratio between the two groups stays near ten", all(9.5 <= a / b <= 10.5 for a, b in ((val("sn.t1.g"), val("sn.t1.o")), (val("sn.t2.g"), val("sn.t2.o")), (val("sn.t3.g"), val("sn.t3.o")))), "SAVED", "cross_sector_sensitivity.py (saved output): 10.2, 10.1, 10.1"),
    (r"more than twice Gemini's", val("s.g") / val("s.gem") > 2, "RUN", "21.3 / 9.2 from section7_from_aggregates.py"),
    (r"with the lowest Google figure above the highest of the other four in every sector", val("s.dom") == 11, "RUN", "section7_from_aggregates.py: 11/11; recomputed from cross_sector_type_shares.csv"),
    (r"In every one of the eleven sectors, the lowest of the four Google views", val("s.dom") == 11, "RUN", "section7_from_aggregates.py: 11/11"),
    (r"Gemini, also Google's, is the highest of the other four", val("s.gem") > max(val("s.gpt"), val("s.per"), val("s.cop")), "RUN", "section7_from_aggregates.py"),
    (r"Semrush reports more ranking keywords than Ahrefs on every prefix", all(x["kr"] > 1 for x in P), "CALC", "data/*.csv"),
    (r"judged about two-thirds correct", 0.62 <= val("r2.a2") / 100 <= 0.70, "RUN", "r2_link_check.py: 65.0% to 66.8%"),
    (r"about two in three are correct", 0.62 <= val("r2.a2") / 100 <= 0.70, "RUN", "r2_link_check.py: 65.0% to 66.8%"),
    (r"about two in three correct", 0.62 <= val("r2.a2") / 100 <= 0.70, "RUN", "r2_link_check.py: 65.0% to 66.8%"),
    (r"single-word labels, which are right about half the time", 48 <= val("r2.sw2") <= val("r2.sw1") <= 52, "RUN", "r2_link_check.py: 48.0% and 50.0%"),
    (r"half for single-word labels", 48 <= val("r2.sw2") <= val("r2.sw1") <= 52, "RUN", "r2_link_check.py: 48.0% and 50.0%"),
    (r"from a factor of five below to nearly nine above", 4.5 <= 1 / val("an.mmin") <= 5.5 and 8.5 <= val("an.mmax") < 9, "RUN", "analyze.py: 0.20x and 8.89x"),
    (r"by a factor of five below to nearly nine above", 4.5 <= 1 / val("an.mmin") <= 5.5 and 8.5 <= val("an.mmax") < 9, "RUN", "analyze.py: 0.20x and 8.89x"),
    (r"can differ by a factor of five below to nearly nine above", 4.5 <= 1 / val("an.mmin") <= 5.5 and 8.5 <= val("an.mmax") < 9, "RUN", "analyze.py: 0.20x and 8.89x"),
    (r"ran from one fifth to seven times", 0.15 <= val("an.min") <= 0.25 and 6.5 <= val("an.max") <= 7.5, "RUN", "analyze.py: 0.20x and 7.24x"),
    (r"about its referring domains by a factor of eleven", 10.5 <= val("rd.x") < 11.5, "CALC", "913 / 80"),
    (r"the other two are six to seven times apart on one instrument and about equal on the other", 6 <= val("rev.b") <= 7.5 and 6 <= val("rev.a") <= 7.5, "RUN", "instrument_extra.py section 10: 7.25x and 6.09x on one, 1.10x and 1.05x on the other"),
    (r"the two exceptions were six to seven times apart on one instrument and about equal on the other", 6 <= val("rev.b") <= 7.5 and 6 <= val("rev.a") <= 7.5, "RUN", "instrument_extra.py section 10"),
    (r"two pairs six to seven times apart were ordered the other way", 6 <= val("rev.b") <= 7.5 and 6 <= val("rev.a") <= 7.5, "RUN", "instrument_extra.py section 10"),
    (r"Each exceeds any individual code page", 294 > 238, "FILE", "single_reads_2026-10.csv: smallest hub 294, largest code page 238"),
    (r"per code it lists, a state hub is cited less often than the most-cited code pages", hub_per_code, "CALC", "section_code_pages_2026-10-14.csv: NY 20.6, CA 8.2, TX 11.1, FL 13.2 answers per code against 238"),
    (r"the 50 states, the District, and the plan-wide toll-free codes", len(hub) == 52 and "NANP AREA" in hub and "DC" in hub, "FILE", "section_code_pages_2026-10-14.csv: 50 states, DC, NANP AREA"),
    (r"It closes every full column", True, "CALC", "Table 5: total less the three bands equals the derived row in all six full columns"),
    (r"the next two lie within four months of it", 133 - 129 <= 4 and 133 - 132 <= 4, "CALC", "data/ahrefs_prefixes: 133, 132 and 129 months"),
    (r"the vendor's figure spreads the class across five orders of magnitude where the count spreads it across one", 4.5 <= __import__("math").log10(val("w.vmax") / val("w.vmin")) <= 5.5 and 0.5 <= __import__("math").log10(val("w.wmax") / val("w.wmin")) <= 1.5, "RUN", "wiki_demand_supplement.py: 4.87 and 1.18 decades"),
    (r"(?:Separate agents )?reproduced the source bundle four times in clean folders", len(list((B / "08_REVIEW").glob("reproduction_v5.2_*"))) == 4, "CALC", "four folders in 08_REVIEW"),
    (r"the paper builds from the bundle", True, "RUN", "build_tex.py rebuilt paper.tex byte for byte; tectonic compiled it to a PDF differing from the shipped one in 60 bytes of date and ID"),
]

# numeric labels printed inside the figures: figure, shipped file, label as printed, registry value
FIG_LABELS = [
    ("Figure 1", "fig0_framework", ["60 of 66"], None), ("Figure 1", "fig0_framework", ["0.20x to 7.24x"], None),
    ("Figure 2", "fig1_divergence", ["25.9x"], "t2.Jul.us"), ("Figure 2", "fig1_divergence", ["27.1x"], "t2.Aug.us"), ("Figure 2", "fig1_divergence", ["10.2x"], "t2.Sep.us"), ("Figure 2", "fig1_divergence", ["7.5x"], "t2.Oct.us"),
    ("Figure 3", "fig2_aio", ["2.94x"], "t3.Jul.r"), ("Figure 3", "fig2_aio", ["2.61x"], "t3.Aug.r"), ("Figure 3", "fig2_aio", ["2.42x"], "t3.Sep.r"), ("Figure 3", "fig2_aio", ["1.34x"], "t3.Oct.r"),
    ("Figure 4", "fig3_refdomains", ["61.9%"], "sr.info"), ("Figure 4", "fig3_refdomains", ["26.4%"], "sr.asia"), ("Figure 4", "fig3_refdomains", ["10.2%"], "sr.axyz"), ("Figure 4", "fig3_refdomains", ["75%"], "sr.sxyz"),
    ("Figure 4", "fig3_refdomains", ["913"], "sr.913"), ("Figure 4", "fig3_refdomains", ["80"], "sr.80"),
    ("Figure 5", "fig4_prefixes", ["−0.11"], "an.rho"),
    ("Figure 7", "fig11_wikipedia", ["+0.45"], "w.prim"), ("Figure 7", "fig11_wikipedia", ["+0.34"], "w.lo"), ("Figure 7", "fig11_wikipedia", ["+0.54"], "w.hi"), ("Figure 7", "fig11_wikipedia", ["240"], "w.groups"), ("Figure 7", "fig11_wikipedia", ["125"], "w.g1"),
    ("Figure 6", "fig9_reviews", ["1,008"], "m2.ment"), ("Figure 6", "fig9_reviews", ["+0.18"], "m2.rhom.x"), ("Figure 6", "fig9_reviews", ["+0.75"], "m2.split"), ("Figure 6", "fig9_reviews", ["17"], "m2.nb"),
    ("Figure 9", "fig5_cited", ["474"], "sr.ny"), ("Figure 9", "fig5_cited", ["337"], "sr.ca"), ("Figure 9", "fig5_cited", ["322"], "sr.tx"), ("Figure 9", "fig5_cited", ["304"], "sr.fl"), ("Figure 9", "fig5_cited", ["294"], "sr.nat"),
    ("Figure 9", "fig5_cited", ["238"], "sr.c214"), ("Figure 9", "fig5_cited", ["228"], "sr.c786"), ("Figure 9", "fig5_cited", ["218"], "sr.c404"),
    ("Figure 10", "fig6_positions", ["15,830"], "t5.pos37"), ("Figure 10", "fig6_positions", ["43,980"], "t5.pos77"), ("Figure 10", "fig6_positions", ["226"], "t6.r2x"), ("Figure 10", "fig6_positions", ["768"], "t6.r2"), ("Figure 10", "fig6_positions", ["132"], "t6.r3"),
    ("Figure 10", "fig6_positions", ["562"], "t6.r4"), ("Figure 10", "fig6_positions", ["1121"], "t6.r5"), ("Figure 10", "fig6_positions", ["411"], "t6.r6"), ("Figure 10", "fig6_positions", ["415"], "t5.rd45"), ("Figure 10", "fig6_positions", ["828"], "t5.rd60"), ("Figure 10", "fig6_positions", ["909"], "t5.rd75"),
]


def figure_text(name):
    return subprocess.run(["pdftotext", str(B / f"{name}.pdf"), "-"], capture_output=True, text=True).stdout
