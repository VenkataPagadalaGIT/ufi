#!/usr/bin/env python3
"""Final cross-checks: rounding at exact halves, saved outputs against reruns, v5.2 outputs against today's, pristine tree against the zip."""
import csv, hashlib, json, re, sys, zipfile
from pathlib import Path
R = Path(sys.argv[1]); N = "User_First_Intelligence_v5.3_2026-11-03_source"; B = R / "pristine" / N; O = R / "outputs"
rows = json.loads((R / "table_out/numbers.json").read_text())
print("== rounding: values on or within 2% of a half unit from the exact or printed value")
for r in rows:
    q = re.sub(r"[x%+,K]", "", r["quoted"]).replace("−", "-")
    try:
        qv = float(q); ob = float(r["obtained"])
    except (TypeError, ValueError):
        continue
    d = len(q.split(".")[1]) if "." in q else 0
    if d == 0 and abs(qv) > 400:
        continue
    half = 0.5 * 10 ** (-d)
    if abs(abs(qv - ob) - half) <= 0.02 * half and abs(ob) < 1e7:
        print(f"  {r['section']:8} p.{r['page']:<3} paper {r['quoted']:8} value {ob}  {r['source'][:60]}")
print("  99 of 120 is exactly 82.5%, which the script prints as 82% (Python rounds half to even); the paper quotes 82%")
print("\n== saved outputs of scripts that cannot run, against reruns of the same lines")
lines = lambda p: [l.rstrip() for l in Path(p).read_text().splitlines() if l.strip()]
sup = lines(B / "review_demand/supplement_r10_output.txt"); m2 = lines(O / "m2_from_counts.stdout")
print("  m2_from_counts.py rerun lines found verbatim in supplement_r10_output.txt:", sum(l in sup for l in m2), "of", len(m2))
print("    not verbatim:", [l[:100] for l in m2 if l not in sup])
s2 = (B / "ai_citation_cross_sector/scripts/cross_sector_sensitivity2_output.txt").read_text()
s7 = (O / "section7_from_aggregates.stdout").read_text()
c1 = lambda t: re.findall(r"\d+\.\d%", t.split("== Appendix C1")[1].split("== Appendix C2")[0])
print("  Table C1 digits, section7 rerun vs saved sensitivity2:", c1(s7) == c1(s2), len(c1(s7)))
c2 = lambda t: re.findall(r"[\d,]+\.\d", t.split("== Appendix C2")[1].split("==")[0])
print("  Table C2 digits, section7 rerun vs saved sensitivity2:", c2(s7) == c2(s2), len(c2(s7)))
a = (O / "cross_sector_sensitivity2.stdout").read_text()
print("  cross_sector_sensitivity2.py partial stdout is a prefix of its saved output:", s2.startswith(a.rstrip("\n")) or a.strip() in s2)
print("\n== v5.2 reruns shipped in 08_REVIEW/run4 against today's stdout (the paper says v5.3 changes no earlier result)")
RUN4 = B / "08_REVIEW/reproduction_v5.2_run4_2026-10-15/outputs"
for t, f in (("analyze", "analyze_stdout.txt"), ("instrument_extra", "instrument_extra_stdout.txt"), ("m2_from_counts", "m2_from_counts_stdout.txt"), ("r2_link_check", "r2_link_check_stdout.txt"), ("vendor_reliance_offline", "vendor_reliance_offline_stdout.txt"), ("stakes_screen_check", "stakes_screen_check_stdout.txt"), ("section7_from_aggregates", "section7_from_aggregates_stdout.txt"), ("make_tables_sector_surface", "make_tables_sector_surface_stdout.txt")):
    x, y = (O / f"{t}.stdout").read_text(), (RUN4 / f).read_text()
    same = x == y
    extra = [l for l in x.splitlines() if l not in y.splitlines()]
    gone = [l for l in y.splitlines() if l not in x.splitlines()]
    print(f"  {t:30} {'identical' if same else f'differs: {len(extra)} lines only today, {len(gone)} lines only in v5.2'}")
    for l in gone[:5]:
        print("      only v5.2:", l[:120])
print("\n== pristine tree against the zip")
z = zipfile.ZipFile(R / "User_First_Intelligence_v5.3_2026-11-03_source.zip")
bad = z.testzip()
diff = 0; n = 0
for i in z.infolist():
    if i.is_dir():
        continue
    n += 1
    if (R / "pristine" / i.filename).read_bytes() != z.read(i):
        diff += 1
print(f"  testzip {bad}; files {n}; differing from the zip after all runs {diff}")
