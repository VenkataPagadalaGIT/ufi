#!/usr/bin/env python3
"""Reproducer's runner, kept outside the bundle. For one script: unpack the zip fresh, run the script with the working
directory and command its README or docstring gives, under a macOS sandbox with no network and no writes to the Desktop,
capture stdout, stderr and exit code, then compare every file in the tree with the pristine unpack.

usage: run_one.py <tag> <folder relative to bundle root> <hashseed or -> -- <command...>"""
import hashlib, json, os, shutil, subprocess, sys, time, zipfile
from pathlib import Path

R = Path(sys.argv[0]).resolve().parents[1]
ZIP = R / "User_First_Intelligence_v5.3_2026-11-03_source.zip"
NAME = "User_First_Intelligence_v5.3_2026-11-03_source"
tag, folder, seed = sys.argv[1:4]
assert sys.argv[4] == "--"
cmd = sys.argv[5:]
PROFILE = '(version 1)(allow default)(deny network*)(deny file-write* (subpath "/Users/venkatapagadala/Desktop"))'


def tree(root):
    out = {}
    for p in root.rglob("*"):
        if p.is_file() and "__pycache__" not in p.parts:
            out[str(p.relative_to(root))] = hashlib.sha256(p.read_bytes()).hexdigest()
    return out


run = R / "runs" / tag
if run.exists():
    shutil.rmtree(run)
run.mkdir(parents=True)
zipfile.ZipFile(ZIP).extractall(run)
root = run / NAME
before = tree(root)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
if seed != "-":
    env["PYTHONHASHSEED"] = seed
t0 = time.time()
try:
    p = subprocess.run(["sandbox-exec", "-p", PROFILE] + cmd, cwd=root / folder, env=env, capture_output=True, text=False, timeout=int(os.environ.get("RUN_TIMEOUT", "550")))
except subprocess.TimeoutExpired as e:
    p = subprocess.CompletedProcess(cmd, 124, e.stdout or b"", (e.stderr or b"") + b"TIMEOUT in reproducer runner")
dt = time.time() - t0
after = tree(root)
OUT = R / "outputs"
(OUT / f"{tag}.stdout").write_bytes(p.stdout)
(OUT / f"{tag}.stderr").write_bytes(p.stderr)
changed = sorted(k for k in after if k in before and after[k] != before[k])
new = sorted(k for k in after if k not in before)
gone = sorted(k for k in before if k not in after)
rec = dict(tag=tag, folder=folder, cmd=" ".join(cmd), hashseed=seed, exit=p.returncode, seconds=round(dt, 1),
           stdout_sha256=hashlib.sha256(p.stdout).hexdigest(), stdout_bytes=len(p.stdout), stderr_bytes=len(p.stderr),
           files_changed=changed, files_new=new, files_gone=gone)
(OUT / f"{tag}.json").write_text(json.dumps(rec, indent=1))
with (R / "command_log.txt").open("a") as f:
    f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] tag={tag} cwd=<fresh unpack>/{folder} hashseed={seed} "
            f"sandbox=no-network,no-desktop-writes: {' '.join(cmd)} -> exit {p.returncode} in {dt:.1f}s; "
            f"stdout {len(p.stdout)} bytes; changed {len(changed)}; new {len(new)}\n")
print(f"{tag}: exit {p.returncode} {dt:.1f}s stdout={len(p.stdout)}b stderr={len(p.stderr)}b changed={changed} new={new[:12]}{'...' if len(new)>12 else ''} gone={gone}")
