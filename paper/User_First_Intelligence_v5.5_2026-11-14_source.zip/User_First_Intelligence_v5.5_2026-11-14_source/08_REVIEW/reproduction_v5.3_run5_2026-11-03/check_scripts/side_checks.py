#!/usr/bin/env python3
"""Side checks, not counted as quoted values: edit-script coverage of the v5.3 text, hub-versus-code arithmetic, figure constants, companion texts."""
import csv, re, sys
from collections import Counter
from pathlib import Path
B = Path(sys.argv[1])
MS = (B / "manuscript_v50.md").read_text()
# 1. Does every sentence of the text v5.3 added appear in an edit script?
ed = "".join(p.read_text() for p in sorted(B.glob("edit_v5*.py")))
ed_u = ed.replace('\\"', '"').replace("\\n", " ")
def body(a, b):
    return MS[MS.index(a):MS.index(b)]
miss = []
for name, a, b in (("6.2", "### 6.2 ", "## 7 Measurement 3"), ("Appendix E", "## Appendix E", "\x00END") if False else ("Appendix E", "## Appendix E", "### E.3")):
    t = body(a, b)
    for s in re.split(r"(?<=[.;:])\s+", t):
        s = s.strip()
        if len(s) > 40 and s[:70] not in ed_u and s[-60:] not in ed_u:
            miss.append((name, s[:110]))
print("sentences of v5.3 text not found in any edit_v5*.py:", len(miss))
for m in miss[:12]:
    print("  ", m)
# 2. per code a state hub lists, against the most-cited code page
C = list(csv.DictReader((B / "instrument_divergence_extra/section_code_pages_2026-10-14.csv").open()))
n = Counter(r["location"] for r in C)
print("code pages per location:", {k: n[k] for k in ("NY", "CA", "TX", "FL")}, "non-state/other values:", sorted(k for k in n if len(k) != 2 or k in ("DC",)))
print("answers per code:", {k: round(v / n[k], 1) for k, v in (("NY", 474), ("CA", 337), ("TX", 322), ("FL", 304))}, "against 238 for the most-cited code page")
print("locations:", len(n), "of which", sorted(n)[:60])
# 3. constants typed into make_figs_v4.py against the released series
src = (B / "make_figs_v4.py").read_text()
T5 = {r["Metric"]: r for r in csv.DictReader((B / "instrument_divergence_extra/instrument_series_table5_checkpoints.csv").open())}
g = lambda m, d: float(re.sub(r"[^\d.]", "", T5[m][d]))
pos = [int(x) for x in re.search(r"pos_all = \[([^\]]+)\]", src).group(1).split(",")]
days = [int(x) for x in re.search(r"days = \[([^\]]+)\]", src).group(1).split(",")]
col = {0: "Day 0 (26 Jul)", 15: "Day 15 (10 Aug)", 30: "Day 30 (25 Aug)", 37: "Day 37 (1 Sep)", 45: "Day 45 (9 Sep)", 60: "Day 60 (24 Sep)", 75: "Day 75 (9 Oct)", 77: "Day 77 (11 Oct)"}
print("figure constants, positions vs Table 5:", all(pos[i] == g("Ranking positions, all", col[d]) for i, d in enumerate(days) if d in col))
print("figure constants: day 6", pos[days.index(6)], "day 67", pos[days.index(67)], "(single_reads: 984, 38,801)")
# 4. arXiv abstract and the companion protocol
ab = (B / "arxiv_abstract.txt").read_text()
toks = re.findall(r"[+−]?\d[\d,]*(?:\.\d+)?(?:x|%)?", ab)
print("arXiv abstract tokens not found in the manuscript:", [t for t in toks if t not in MS])
P = (B / "UFI_Metrics_and_Evaluation_Protocol_v1.0.md").read_text()
vals = ["7.5x to 27.1x", "8.6x to 29.9x", "9.2x to 33.3x", "0.20x to 7.24x", "60 of 66", "1.13", "3.1", "12.6% to 20.0%", "55.6%", "2.25", "+0.18", "+0.27", "+0.47", "+0.75", "14.0%", "65% to 67%", "83% to 85%", "+0.45", "+0.54", "14.5", "21.3%", "2.1%", "0.36 to 0.40", "0.08 to 0.23", "77%", "4/5", "70.4%", "456"]
print("Table D1 values absent from the companion protocol's text:", [v for v in vals if v not in P])
for m in re.finditer(r"(version|v)\s?5\.\d", P):
    print("  protocol mentions:", P[max(0, m.start()-40):m.end()+30].replace("\n", " "))
    break
print("bundle files:", sum(1 for p in B.rglob("*") if p.is_file()))
