#!/usr/bin/env python3
"""List the numeric tokens of the manuscript by section, non-table prose apart from tables, for planning the number table."""
import re, sys
from pathlib import Path
ms = Path(sys.argv[1]).read_text()
parts = re.split(r"(?m)^(#{1,3} .*)$", ms)
TOK = re.compile(r"(?<![\w.])[+−-]?\d[\d,]*(?:\.\d+)?(?:x|%|K)?")
secs = [("front", parts[0])] + [(parts[i].strip("# ").strip(), parts[i + 1]) for i in range(1, len(parts) - 1, 2)]
tot = 0
for name, body in secs:
    if name.startswith("References"):
        continue
    prose = "\n".join(l for l in body.splitlines() if not l.startswith("|"))
    prose = re.sub(r"\[[^\]]*\d{4}[^\]]*\]", " ", prose)  # citations
    toks = TOK.findall(prose)
    tbl = "\n".join(l for l in body.splitlines() if l.startswith("|"))
    t2 = TOK.findall(tbl)
    tot += len(toks) + len(t2)
    print(f"## {name[:60]}: prose {len(toks)}, table {len(t2)}")
print("total", tot)
