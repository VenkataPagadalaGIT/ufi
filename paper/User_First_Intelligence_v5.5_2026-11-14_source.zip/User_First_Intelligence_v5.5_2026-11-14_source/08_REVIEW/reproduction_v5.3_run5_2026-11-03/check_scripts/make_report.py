#!/usr/bin/env python3
"""Write reproduction_report.md, numbers_table.csv and the command log into the report folder, from the table built by number_table.py."""
import csv
import hashlib
import json
import platform
import re
import shutil
import subprocess
import sys
from collections import Counter
from pathlib import Path

R = Path(__file__).resolve().parents[1]
DEST = Path(sys.argv[1])
N = "User_First_Intelligence_v5.3_2026-11-03_source"
O = R / "outputs"
rows = json.loads((R / "table_out/numbers.json").read_text())
cov = json.loads((R / "table_out/coverage.json").read_text())
tally = Counter(r["status"] for r in rows)
basis = Counter((r["status"], r["basis"]) for r in rows)
kinds = Counter("statement in words" if r["value_name"] == "fact" else "label inside a figure" if r["value_name"] == "figure" else "table cell" if r["value_name"] == "table" else "number in prose" for r in rows)
ver = lambda m: __import__("importlib.metadata").metadata.version(m)
sha = hashlib.sha256((R / f"{N}.zip").read_bytes()).hexdigest()
sha_pdf = hashlib.sha256((R / "User_First_Intelligence_v5.3_2026-11-03.pdf").read_bytes()).hexdigest()
J = lambda t: json.loads((O / f"{t}.json").read_text())
assert not any("—" in str(v) for r in rows for v in r.values())


def esc(s):
    return str(s).replace("|", "\\|").replace("\n", " ")


# ------------------------------------------------------------------ the per-number CSV
DEST.mkdir(parents=True, exist_ok=True)
with (DEST / "numbers_table.csv").open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["id", "section", "pdf_page", "quoted_in_paper", "context", "script_or_source", "value_obtained", "basis", "status", "reason"])
    for r in rows:
        w.writerow([r["id"], r["section"], r["page"], r["quoted"], r["context"], r["source"], r["obtained"], r["basis"], r["status"], r["reason"]])

# ------------------------------------------------------------------ command log
head = f"""# Command log, independent reproduction run 5, 3 November 2026
# R = session scratchpad folder repro_run5 (fresh, empty when created). Every script run: a new unpack of the zip, the
# bundle's command, under sandbox-exec denying all network and all writes to the Desktop (check_scripts/run_one.py).
# Setup, before the first logged run:
shasum -a 256 <project>/06_MANUSCRIPT/User_First_Intelligence_v5.3_2026-11-03_source.zip <project>/06_MANUSCRIPT/User_First_Intelligence_v5.3_2026-11-03.pdf
unzip -l <zip>
cp <zip> <pdf> R/
unzip -q -o R/<zip> -d R/pristine
pdftotext -layout R/<pdf> R/paper_layout.txt; pdftotext R/<pdf> R/paper_raw.txt; pdfinfo R/<pdf>
grep -rnE "/Users/|Desktop/|expanduser|~/|Research-Papers" (scripts): no absolute paths outside 08_REVIEW
grep -rlE "urllib.request|requests.|http.client|socket|subprocess|os.system" (scripts)
sandbox-exec -p '(version 1)(allow default)(deny network*)' python3 -c "urllib.request.urlopen('https://example.org')": blocked, as intended
which python3 pdftotext tectonic xelatex pandoc ots; python3 -m pip list; python3 -m pip show ufi
# Three attempts at the build batch stopped on errors in the reproducer's own shell and runner (word splitting in zsh, a broken
# string in run_one.py), before any bundle script started; they are not listed.
"""
auto = (R / "command_log.txt").read_text()
tail = """
# After the logged runs:
PYTHONDONTWRITEBYTECODE=1 python3 check_scripts/side_checks.py R/pristine/<bundle>        # outputs/_side_checks.log
python3 check_scripts/figures_compare.py R                                                # outputs/_figures_compare.log
bash check_scripts/misc_runs.sh                                                           # determinism diff, stamped vs current, PDF byte diff
PYTHONDONTWRITEBYTECODE=1 python3 check_scripts/number_table.py table_out                 # outputs/_number_table.log, repeated while the rules were written
MUTATE=<11,22,33,44,55,66> python3 check_scripts/number_table.py table_out                # outputs/_mutation_final.log
PYTHONDONTWRITEBYTECODE=1 python3 check_scripts/final_checks.py R                         # outputs/_final_checks.log
git -C <project> status --short; shasum -a 256 <zip> <pdf>                                # end-of-run state, read only
python3 check_scripts/make_report.py <report folder>
"""
log = head + "\n# Runs, in order, as the runner logged them:\n" + auto + tail
(DEST / "command_log.txt").write_text(log)

# ------------------------------------------------------------------ report
SCRIPTS = [
    ("data/analyze.py", "`cd data; python3 analyze.py`", "RAN", "No output file ships beside it. Stdout identical to the v5.2 record in `08_REVIEW/.../run4/outputs/analyze_stdout.txt`.", "analyze"),
    ("instrument_divergence_extra/instrument_extra.py", "`cd instrument_divergence_extra; python3 instrument_extra.py`", "RAN", "Stdout byte-identical to `instrument_extra_output.txt`; the four series CSVs it rewrites are byte-identical.", "instrument_extra"),
    ("protocols/instrument_extra_as_stamped.py", "`cd protocols; python3 instrument_extra_as_stamped.py`", "RAN", "No shipped output. Sections 1 to 6 identical to the current script's; its four CSVs byte-identical to the shipped ones.", "instrument_extra_as_stamped"),
    ("protocols/reread_compare.py", "`cd protocols; python3 reread_compare.py`", "FAILED", "FileNotFoundError on `03_DATA/instrument_divergence_ahrefs_prefixes_2026-10-12.csv`. The README says it reads the project's folders and to use the wrapper; expected.", "reread_compare"),
    ("protocols/reread_compare_anywhere.py", "`cd protocols; python3 reread_compare_anywhere.py`", "RAN", "Hash of the stamped script matches the manifest; prints \"the sheet has no values yet\", as it should for an empty sheet.", "reread_compare_anywhere"),
    ("review_demand/m2_from_counts.py", "`cd review_demand; python3 m2_from_counts.py`", "RAN", "Stdout byte-identical to `m2_from_counts_output.txt`. 34 of its 35 lines also appear verbatim in the saved `supplement_r10_output.txt`.", "m2_from_counts"),
    ("review_demand/r2_link_check.py", "`cd review_demand; python3 r2_link_check.py`", "RAN", "Stdout byte-identical to `r2_link_check_output.txt`.", "r2_link_check"),
    ("review_demand/analyze_reviews.py", "`cd review_demand; python3 analyze_reviews.py`", "CANNOT RUN", "Missing `Telecom_reviews_and_responses.xlsx`, `Telecom_classification.xlsx` (licensed, withheld as the paper says). Saved output compared with the paper only.", "analyze_reviews"),
    ("review_demand/r2_link_sample.py", "`cd review_demand; python3 r2_link_sample.py`", "CANNOT RUN", "Missing the same licensed export.", "r2_link_sample"),
    ("review_demand/supplement_r10.py", "`cd review_demand; python3 supplement_r10.py`", "CANNOT RUN", "Missing the same licensed export (and `Telecom_keywords_full.csv.gz`).", "supplement_r10"),
    ("review_demand/make_fig_reviews_v50.py", "`cd review_demand; python3 make_fig_reviews_v50.py`", "CANNOT RUN", "Missing `out/label_demand_aggregates.csv`, written from the licensed export. Figure 6 cannot be redrawn; its printed labels were read.", "make_fig_reviews_v50"),
    ("stakes/vendor_reliance.py", "`cd stakes; python3 vendor_reliance.py --offline`", "RAN", "Stdout byte-identical to `vendor_reliance_output.txt`. The online mode was not run.", "vendor_reliance_offline"),
    ("stakes/stakes_screen_check.py", "`cd stakes; python3 stakes_screen_check.py`", "RAN", "Stdout byte-identical to `stakes_screen_check_output.txt`.", "stakes_screen_check"),
    ("stakes/stakes_screen_sample.py", "`cd stakes; python3 stakes_screen_sample.py` (no network)", "CANNOT RUN", "Needs live OpenAlex for the abstracts. Its selection lines rerun offline give the same 120 ids in the same order as `stakes_screen_ids.csv`.", "stakes_screen_sample"),
    ("wikipedia_demand/wiki_collect.py", "not run, by instruction", "CANNOT RUN", "Live APIs excluded by the caller. Its outputs were checked instead: raw responses to monthly file to per-article table, no difference; 1,497 lines of responses.", None),
    ("wikipedia_demand/wiki_demand_analysis.py", "`cd wikipedia_demand; python3 wiki_demand_analysis.py`", "RAN", "**Differs from the shipped files in one printed line and one JSON key**: the release run prints \"score correlation: not available\" where the shipped output holds the project run's +0.413; `wiki_demand_headline.json` lacks the `cgs` block. All else byte-identical. README discloses this. The run overwrites both shipped files.", "wiki_demand_analysis"),
    ("wikipedia_demand/wiki_demand_supplement.py", "`cd wikipedia_demand; python3 wiki_demand_supplement.py`", "RAN", "Stdout byte-identical to `wiki_demand_supplement_output.txt`.", "wiki_demand_supplement"),
    ("wikipedia_demand/make_fig_wikipedia.py", "`cd wikipedia_demand; python3 make_fig_wikipedia.py`", "RAN", "PNG byte-identical to the shipped `fig11_wikipedia.png`, also when run after the analysis in one tree; PDF differs only in `/CreationDate`.", "make_fig_wikipedia"),
    ("ai_citation_cross_sector/scripts/section7_from_aggregates.py", "`cd .../scripts; python3 section7_from_aggregates.py`", "RAN", "Stdout byte-identical to `section7_from_aggregates_output.txt`.", "section7_from_aggregates"),
    ("ai_citation_cross_sector/scripts/cross_sector.py", "`cd .../scripts; python3 cross_sector.py`", "CANNOT RUN", "Stops with its message: raw Brand Radar exports are withheld. Saved output compared with the paper only.", "cross_sector"),
    ("ai_citation_cross_sector/scripts/cross_sector_sensitivity.py", "`cd .../scripts; python3 cross_sector_sensitivity.py`", "CANNOT RUN", "Same.", "cross_sector_sensitivity"),
    ("ai_citation_cross_sector/scripts/cross_sector_sensitivity2.py", "`cd .../scripts; python3 cross_sector_sensitivity2.py`", "CANNOT RUN", "Prints the variance block it can compute (a prefix of its saved output, byte for byte), then stops: raw exports withheld.", "cross_sector_sensitivity2"),
    ("ai_citation_cross_sector/scripts/make_tables_sector_surface.py", "`cd .../scripts; python3 make_tables_sector_surface.py`", "RAN", "Stdout byte-identical to `make_tables_sector_surface_output.txt`.", "make_tables_sector_surface"),
    ("ai_citation_cross_sector/scripts/make_fig_sources.py", "`cd .../scripts; python3 make_fig_sources.py`", "RAN", "PNG byte-identical to the shipped `fig10_sources.png`; PDF differs only in `/CreationDate`.", "make_fig_sources"),
    ("ai_citation_cross_sector/scripts/make_brand_radar_urls.py", "`cd .../scripts; python3 make_brand_radar_urls.py`", "RAN", "Rewrites `cross_sector_report_urls.json` byte-identically. It builds addresses and requests nothing.", "make_brand_radar_urls"),
    ("make_figs_v4.py", "`python3 make_figs_v4.py`", "RAN", "Six PNGs byte-identical to the shipped ones; six PDFs differ only in `/CreationDate`.", "make_figs_v4"),
    ("make_fig0.py", "`python3 make_fig0.py`", "RAN", "PNG byte-identical; PDF differs only in `/CreationDate`.", "make_fig0"),
    ("build_tex.py", "`python3 build_tex.py`", "RAN", "`build/paper.tex` byte-identical to the shipped `paper.tex`.", "build_tex"),
    ("build_docx.sh", "`zsh build_docx.sh`", "RAN", "Writes `build/paper.docx`. No DOCX ships in the bundle to compare with.", "build_docx"),
]
scr = "| Script | How run | Result | Against the shipped output |\n|---|---|---|---|\n"
for s, how, st, note, tag in SCRIPTS:
    t = ""
    if tag:
        j = J(tag)
        t = f" (exit {j['exit']}, {j['seconds']} s)"
    scr += f"| `{s}` | {how} | {st}{t} | {note} |\n"
scr += f"| `tectonic paper.tex` (the README's build; not a script) | `tectonic --keep-logs --chatter minimal paper.tex` | RAN (exit {J('tectonic_compile')['exit']}) | 39 pages. The PDF differs from the shipped one in 60 of 739,326 bytes (creation date and file ID); `pdftotext -layout` output byte-identical. |\n"
scr += "| `edit_v49*.py`, `edit_v5*.py` (35 scripts) | each once, in a disposable copy | RAN as documented: all 35 stop without writing | 5 stop on the missing `manuscript_v49.md`, 30 print REFUSE. The README says each refuses to run twice. |\n"
scr += "| `08_REVIEW/**/*.py` (37 scripts) | attempted with no arguments, offline | not applicable | Earlier reproducers' private checks with no documented command: 3 ran, 34 stop asking for their own arguments (`outputs/_08_review_scripts.tsv`). No number in the paper rests on them. |\n"
n_ran = sum(1 for x in SCRIPTS if x[2] == "RAN")
n_fail = sum(1 for x in SCRIPTS if x[2] == "FAILED")
n_cant = sum(1 for x in SCRIPTS if x[2] == "CANNOT RUN")

miss = [r for r in rows if r["status"] == "MISMATCH"]
mtab = "| Location | Paper says | Obtained | Script or source | Why |\n|---|---|---|---|---|\n"
for r in miss:
    ob = r["obtained"]
    ob = f"{int(ob):,}" if isinstance(ob, float) else ob
    mtab += f"| {r['section']}, PDF p. {r['page']} | {r['quoted']} | {ob} | {esc(r['source'])} | {esc(r['reason'])} |\n"

GROUPS = [("Licensed review export (`Telecom_reviews_and_responses.xlsx`, `Telecom_classification.xlsx`, `Telecom_keywords_full.csv.gz`)", ("supplement_r10", "analyze_reviews", "r2_link_sample")),
          ("Raw Brand Radar exports (`03_DATA/raw/brand_radar_*`), the sensitivities that need row-level data, and the pilot", ("cross_sector", "project copy")),
          ("`ufi` repository (not in the bundle): digests, 924 queries, 66 codes, 4/5, 70.4%, thirteen surface types, commit counts", ("ufi repository",)),
          ("`r1_predictors.csv` per-code scores (held back with Study R1): the +0.41", ("wiki_demand_analysis_output",)),
          ("Other statements with no source in the bundle (Table 7's cost figures, the 52 and 53 hub counts, code 451 in the registry, the stopped prompt-level exports)", ("none",))]
gr = "| Missing input | Values |\n|---|---|\n"
accounted = 0
for lab, keys in GROUPS:
    n = sum(1 for r in rows if r["status"] == "CANNOT RUN" and any(r["source"].startswith(k) for k in keys))
    accounted += n
    gr += f"| {lab} | {n} |\n"
assert accounted == tally["CANNOT RUN"], (accounted, tally)
n_saved = sum(1 for r in rows if r["status"] == "CANNOT RUN" and "agrees with the saved output" in r["reason"])

covt = "| Token class | Count |\n|---|---|\n" + "".join(f"| {k} | {v:,} |\n" for k, v in sorted(cov.items(), key=lambda kv: -kv[1]))

tab = "| # | Location | Quoted | Context | Script or source | Obtained | Basis | Status | Reason |\n|---|---|---|---|---|---|---|---|---|\n"
for r in rows:
    tab += f"| {r['id']} | {r['section']}, p. {r['page']} | {esc(r['quoted'])} | {esc(r['context'])} | {esc(r['source'])} | {esc(r['obtained'])} | {r['basis']} | {r['status']} | {esc(r['reason'])} |\n"

env = (O / "_environment.txt").read_text().strip()
git_state = (O / "_git_state_end.txt").read_text().strip()
report = f"""# Independent reproduction, run 5: User First Intelligence, manuscript v5.3 source bundle

Reproducer: an AI agent (Claude Code), working from the released bundle and the PDF the caller named, in a fresh folder in the session scratchpad, on 3 November 2026. Nothing was copied from the author's working project. No file of the paper, the bundle or the project was edited; the only addition to the project is this folder.

## Results at a glance

- **Scripts:** of the bundle's {len(SCRIPTS)} paper scripts, not counting 35 edit scripts, {n_ran} ran as documented, {n_fail} failed as its README predicts (`protocols/reread_compare.py`), {n_cant} cannot run ({n_cant - 1} need withheld data or a live service, and `wiki_collect.py` was excluded by instruction). The tectonic build also ran.
- **Output files:** every shipped output with a rerun counterpart is byte-identical except `wiki_demand_analysis_output.txt` and `wiki_demand_headline.json`, which differ in the one line and one key the README discloses. Every regenerated PNG is byte-identical; the PDFs differ only in `/CreationDate`. Every script that prints numbers was rerun under two fixed hash seeds with identical stdout.
- **Numbers:** **{len(rows):,} values checked: {tally['MATCH']:,} MATCH, {tally['MISMATCH']} MISMATCH, {tally['CANNOT RUN']} CANNOT RUN.** Those are {kinds['number in prose']:,} numbers in prose, {kinds['table cell']} table cells, {kinds['label inside a figure']} labels inside figures and {kinds['statement in words']} statements in words that an output decides.
- **What the matches rest on:** {basis[('MATCH', 'RUN')]} on a script rerun here, {basis[('MATCH', 'CALC')]} on the reproducer's own recomputation from released files, {basis[('MATCH', 'BLOCK')]} on public block data, {basis[('MATCH', 'FILE')]} on a released data file that records a dashboard read or a plan, and **{basis[('MATCH', 'CIRC')]} that cannot fail**: series CSVs parsed from the paper's own tables, as Section 14 discloses.
- **Build:** `build_tex.py` regenerates `paper.tex` byte for byte, and it compiles to the shipped PDF's exact text. So checks made on `manuscript_v50.md` hold for the PDF; every value was also located on a page of the shipped PDF.

## Problems found, most important first

**1. The Study W stamp first reached a Bitcoin block earlier than the paper says (the two mismatches).**

{mtab}
The paper's sentence (Section 6.2, PDF p. 15): "before the stamp reached a Bitcoin block (block 973,943, mined at 06:51 UTC): the proof dates the plan to within two hours of the read". The shipped proof `wikipedia_demand/wikipedia_demand_372_manifest.txt.ots` commits to the manifest's SHA-256 and holds **three** Bitcoin attestations, on separate branches of the proof. Executing the proof's operations and comparing with block data from a public explorer, each path's digest equals that block's merkle root:

| Block | Mined (UTC, 31 October 2026) | Merkle root (proof = block) |
|---|---|---|
| **973,934** | **05:44:22** | 787c370594040933515ca884d9b1ec72a2069c969103d9a38adde980df61e37e |
| 973,943 (the one the paper names) | 06:51:59 | 966975ca852fb540aa9172dfbe277cd09e0406134f32c0ee76e7b5a3e70fb771 |
| 973,953 | 08:19:43 | 7e9523b5b7ba3f7f9512ce74082e461f0ef2407b34e7dbd4244afe2b35320de1 |

Block 973,943 is a genuine attestation, so the paper's figure is not invented, but it is not when the stamp reached a block. The first anchor is 34 minutes after the stated 05:10 stamp and 24 minutes 37 seconds after the collection ended (05:19:45 in `collection_log.txt`). The error runs against the paper's own interest: the ordering it discloses still holds (the read finished before any block, so the proof alone does not order plan and read), while "within two hours" is true but much looser than the proof shows. The same figures are in `wikipedia_demand/README.md` line 6 and `CHANGELOG_versions.md` line 72, and came from `edit_v53e.py`. Which block `ots verify` would report could not be run here: no OpenTimestamps client is installed.

**2. One quoted value of Study W cannot come from the release, and the shipped output holds a line the release cannot print.** The "+0.41" for the Content Gap Score (Section 6.2, PDF p. 16) needs the per-code scores in the withheld `r1_predictors.csv`. The shipped `wiki_demand_analysis_output.txt` and `wiki_demand_headline.json` carry the project run's +0.413; a release run prints "not available", as the README says, and overwrites both files. Section 6.2's closing "the analysis reruns from them" holds for everything else.

**3. {tally['CANNOT RUN']} values rest on inputs the bundle does not contain.** {n_saved} of them agree with a saved output shipped beside the script, which shows the paper quotes that output correctly and not that the output is right.

{gr}
Where the anonymized counts allowed it, values the paper attributes to withheld data were recomputed and match: +0.28 over 213 labels, Kendall +0.13, and 106 labels at zero volume, all from `m2_label_counts.csv`.

**4. {basis[('MATCH', 'CIRC')]} matches cannot fail, and {basis[('MATCH', 'FILE')]} confirm only a transcription.** `instrument_extra.py` writes the Table 2, 3, 5 and 6 CSVs by parsing the manuscript, so those raw cells agree by construction. Dashboard reads in `single_reads_2026-10.csv` and the twelve-prefix files are matched against a file the same author's agents wrote; none of this can catch a misread dashboard, and Section 14 says so. The derived cells (ratios, Wilson intervals, the 21 to 100 row, all of Table 6) were recomputed here and do test something.

**5. P3's "lax bar" is stated without the plan's qualifier (no number differs).** Section 6.2 says the bar "fails only if log requests track log volume at a Pearson correlation above about 0.9". The plan says that holds "at a comparable spread". At the spreads actually observed, geometric SDs of 16.69 and 1.50, the ratio's geometric SD cannot fall below 11.1 at any correlation (recomputed; the observed log-log Pearson is +0.41), so P3 could not have failed. Counted as a MATCH on the 0.9, with this note.

**6. Stale pointers, not numbers.**
- `single_reads_2026-10.csv`, column "where in the paper": 4 rows say "Figure 9 caption" and 8 say "Figure 8". Since v5.3's renumbering those figures are Figure 10 and Figure 9.
- Appendix E.3 places the search record at `01_LITERATURE/checklist_search_2026-10-31/` "in the source bundle"; the bundle has `literature/checklist_search_2026-10-31/`. Section 6.2 cites `02_DESIGN/wikipedia_demand_372.md`; the bundle has `wikipedia_demand/wikipedia_demand_372.md`.
- `CHANGELOG_versions.md` line 71 names edit scripts up to `edit_v53f.py`; the bundle stops at `edit_v53e.py`, while its README says the edit scripts record every change. Every sentence of Sections 6.2, E.1 and E.2 was found in `edit_v5*.py`, so no unrecorded text was observed, but what `edit_v53f.py` did cannot be told from here.
- `wikipedia_demand/README.md` lists `stamp_manifest.sh`, and the plan names `smoke_test.py` "kept beside it" and a review record in `08_REVIEW/`. None is in the bundle.

**7. Two scripts overwrite shipped files when run.** `wiki_demand_analysis.py` overwrites its shipped outputs (item 2). `stakes_screen_sample.py` truncates `stakes_screen_ids.csv` before its first fetch, so a failed run leaves the released id list damaged; observed in a disposable copy.

## Limits of this reproduction

- **One network decision to check.** The caller barred requests to a vendor. Ten HTTPS requests went to `blockstream.info` for the five block heights' headers (`outputs/blocks/`). That is a public block explorer and not a vendor of this study, and no project data was sent. If you read the instruction more widely, the {sum(1 for r in rows if r['basis'] == 'BLOCK')} values on that basis become CANNOT RUN, and problem 1 would rest on block heights alone (973,934 is below 973,943 whatever the times). Every script ran with the network denied by the sandbox.
- **Not checked:** other studies' figures quoted in Section 2 and elsewhere; times with no released source (the 23:05 to 01:15 collection session of Section 7.2); dates; the `ufi` repository, which is public but outside the bundle. The vendor side of Study W (`dem`, `K`) was taken as released: the raw-to-table chain was recomputed for the public side only, because the frozen vendor table is withheld. Its hash in the two manifests and the collection log agree.
- **The `ufi` package is installed on this machine** (0.2.0, user site-packages) but is not in the bundle. Three review scripts import it and then stop on the missing export; no result here used it.
- **The checker itself:** six end-to-end mutation tests altered 615 quoted values in memory across the manuscript; all 615 were caught (`outputs/_mutation_final.log`). An early run missed some, which exposed a table check comparing cells with themselves and patterns falling through to an exclusion; both were fixed before the counts above. Rules that map a value to its source were written by this agent and could still map a value to a wrong but equal source.
- **The project moved during this run, and this report does not cover the move.** The working tree was clean at the start and shows the changes below at the end. This run did not make them: its writes were limited to the scratchpad and this folder. They include a modified `06_MANUSCRIPT/src/manuscript_v50.md` and `03_DATA/single_reads_2026-10.csv` and an untracked `06_MANUSCRIPT/src/edit_v53f.py`, none of which was read. Everything here applies to the zip and PDF as hashed in section 1, whose hashes were unchanged at the end, so some problems above may already be in hand in the working copy:

```
{git_state}
```

## 1. Environment and bundle

{env}

- Bundle SHA-256: `{sha}` (532 files; Python's `zipfile.testzip` clean; all 532 in the untouched unpack still identical to the zip after every run).
- PDF SHA-256: `{sha_pdf}` (39 pages).
- Manifests: all 7 digests in `protocols/protocols_manifest.txt` match the released files. 4 of the 5 in `wikipedia_demand_372_manifest.txt` match; the fifth is the withheld `r1_predictors.csv`. The Study R1 manifest's files are held back, as its README says. All four `.ots` proofs commit to the file beside them. Blocks 971,506 (merkle root 7bdc6025...59a3, 04:05:42 UTC) and 971,522 (06:10:20 UTC) are confirmed.
- Companion texts: every number in `arxiv_abstract.txt` appears in the paper. Of 28 Table D1 values tried, the companion protocol's text holds all but the 456.

## 2. Scripts

{scr}
Data chain of Study W, recomputed separately: all 1,249 pageview responses have status 200; `pageviews_monthly.csv` equals `pageviews.jsonl`; every window of every article in `wiki_groups.csv` equals the sum over `pageviews_monthly.csv`; `dem` and `K` equal the sums over `wiki_codes.csv`; resolution, redirect and pageview responses count 8 + 240 + 1,249 = 1,497, the paper's request count.

Version 5.3 "changes no earlier result" (Appendix A): today's stdout is identical to the v5.2 reproduction's shipped record for `analyze`, `m2_from_counts`, `r2_link_check`, `vendor_reliance`, `stakes_screen_check`, `section7_from_aggregates` and `make_tables_sector_surface`; `instrument_extra` differs only by 11 added lines (its section 10).

Rounding near a half unit (`outputs/_final_checks.log`): 99 of 120 is exactly 82.5%, printed and quoted as 82%; the interval end +0.74 is exactly 0.735. The others are valid roundings of the exact value: +0.25 from 0.24503, +0.28 from 0.28498, +0.31 from 0.31498.

## 3. Quoted numbers

Each value's precision is the paper's: a MATCH means the obtained value rounds to it. Basis, in the table and in `numbers_table.csv`: RUN (a script rerun here), CALC (recomputed here), FILE (a released data file), CIRC (a CSV parsed from the paper's own table), SAVED (only in the saved output of a script that cannot run), BLOCK (public block data), NONE (no source).

**Coverage.** Every numeric token in the text outside the reference list and the cell-checked tables is either checked or excluded for a stated reason; none is left over. The excluded tokens are listed one by one in `excluded_tokens.tsv`.

{covt}
**The full table** ({len(rows):,} rows; also `numbers_table.csv`):

{tab}
## 4. Command log

```
{log}
```
"""
report = report.replace("—", ", ")
(DEST / "reproduction_report.md").write_text(report)
shutil.copy(R / "table_out/excluded_tokens.tsv", DEST / "excluded_tokens.tsv")
for sub, src in (("check_scripts", R / "check_scripts"), ("outputs", R / "outputs")):
    d = DEST / sub
    if d.exists():
        shutil.rmtree(d)
    shutil.copytree(src, d, ignore=shutil.ignore_patterns("__pycache__"))
print("wrote", DEST, len(report), "chars;", len(rows), "rows;", dict(tally), "scripts ran", n_ran, "failed", n_fail, "cannot", n_cant)
