#!/usr/bin/env python3
"""Reproducer's independent recomputations from the bundle's released files only (written fresh, kept outside the bundle).
Nothing here edits a bundle file. Prints a readable log and writes recomputed.json for the number table.

usage: recompute.py <pristine bundle root> <out json>"""
import csv, hashlib, json, math, random, re, statistics as st, sys
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path

import numpy as np
from scipy.stats import kendalltau, spearmanr

B = Path(sys.argv[1])
OUT = {}


def put(k, v):
    OUT[k] = v
    print(f"{k} = {v}")


def wilson(k, n, z=1.96):
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (c - h, c + h)


def kappa(a, b):
    n = len(a)
    po = sum(x == y for x, y in zip(a, b)) / n
    ca, cb = Counter(a), Counter(b)
    pe = sum(ca[c] * cb[c] for c in set(a) | set(b)) / (n * n)
    return (po - pe) / (1 - pe), po


# ------------------------------------------------------------------ A. twelve prefixes, from the two CSVs
print("\n== A. twelve prefixes")
A = {r["prefix"]: r for r in csv.DictReader((B / "data/ahrefs_prefixes_2026-10-12.csv").open())}
S = {r["prefix"]: r for r in csv.DictReader((B / "data/semrush_prefixes_2026-10-12.csv").open())}
P = []
for p, a in A.items():
    s = S[p]
    y, m = map(int, a["ahrefs_first_traffic_month"].split("-"))
    at, st_ = float(a["ahrefs_organic_traffic"]), float(s["semrush_organic_traffic_us"])
    ak, sk = float(a["ahrefs_organic_keywords"]), float(s["semrush_organic_keywords_us"])
    ar, sr = float(a["ahrefs_ref_domains"]), float(s["semrush_ref_domains"])
    us = float(a["ahrefs_us_share"])
    P.append(dict(prefix=p, age=(2026 - y) * 12 + 10 - m, at=at, st=st_, ak=ak, sk=sk, ar=ar, sr=sr, us=us,
                  vr=st_ / at, mr=st_ / (at * us), kr=sk / ak, rr=ar / sr))
OUT["prefixes"] = P
vr = [x["vr"] for x in P]
put("A.rho_age", spearmanr([x["age"] for x in P], vr).statistic)
put("A.rho_age_matched", spearmanr([x["age"] for x in P], [x["mr"] for x in P]).statistic)
nz = [x for x in P if x["prefix"] != "/local/area-codes/"]
put("A.rho_age_excl", spearmanr([x["age"] for x in nz], [x["vr"] for x in nz]).statistic)
put("A.rho_kw", spearmanr([x["kr"] for x in P], vr).statistic)
put("A.rho_kw_excl", spearmanr([x["kr"] for x in nz], [x["vr"] for x in nz]).statistic)
put("A.rho_order", spearmanr([x["at"] for x in P], [x["st"] for x in P]).statistic)
put("A.tau_order", kendalltau([x["at"] for x in P], [x["st"] for x in P]).statistic)
conc = sum((x["at"] - y["at"]) * (x["st"] - y["st"]) > 0 for x, y in combinations(P, 2))
put("A.concordant", conc)
put("A.pairs", len(list(combinations(P, 2))))
put("A.ratio_min", min(vr))
put("A.ratio_max", max(vr))
put("A.ratio_median", st.median(vr))
put("A.spread_decades", math.log10(max(vr) / min(vr)))
put("A.below_one", sum(v < 1 for v in vr))
mr = [x["mr"] for x in P]
put("A.mratio_min", min(mr))
put("A.mratio_max", max(mr))
put("A.mratio_median", st.median(mr))
put("A.mbelow_one", sum(v < 1 for v in mr))
lv = [math.log(v) for v in vr]
gm, gsd = math.exp(st.mean(lv)), math.exp(st.stdev(lv))
put("A.geomean", gm)
put("A.geosd", gsd)
put("A.range_lo", math.exp(st.mean(lv) - 1.96 * st.stdev(lv)))
put("A.range_hi", math.exp(st.mean(lv) + 1.96 * st.stdev(lv)))
# size bands by geometric mean; factor bands per instrument
b = Counter()
b2 = Counter()
for x, y in combinations(P, 2):
    c = (x["at"] - y["at"]) * (x["st"] - y["st"]) > 0
    g = max(math.sqrt(x["at"] * x["st"]), math.sqrt(y["at"] * y["st"])) / min(math.sqrt(x["at"] * x["st"]), math.sqrt(y["at"] * y["st"]))
    k = "gm_within3" if g <= 3 else "gm_beyond3"
    b[k + "_n"] += 1
    b[k + "_c"] += c
    fa = max(x["at"], y["at"]) / min(x["at"], y["at"])
    fs = max(x["st"], y["st"]) / min(x["st"], y["st"])
    k2 = "both" if (fa > 3 and fs > 3) else ("one" if (fa > 3 or fs > 3) else "none")
    b2[k2 + "_n"] += 1
    b2[k2 + "_c"] += c
put("A.bands_gm", dict(b))
put("A.bands_factor", dict(b2))
# Fisher CI and power
r = OUT["A.rho_age"]
z = math.atanh(r)
se = 1 / math.sqrt(12 - 3)
put("A.fisher_lo", math.tanh(z - 1.96 * se))
put("A.fisher_hi", math.tanh(z + 1.96 * se))
from statistics import NormalDist
N = NormalDist()
ncp = math.atanh(0.5) * math.sqrt(9)
put("A.power", 1 - N.cdf(1.959964 - ncp) + N.cdf(-1.959964 - ncp))
seven = [x for x in P if 84 <= x["age"] <= 133]
put("A.n_7_to_11y", len(seven))
put("A.7_11_unmatched", (min(x["vr"] for x in seven), max(x["vr"] for x in seven)))
put("A.7_11_matched", (min(x["mr"] for x in seven), max(x["mr"] for x in seven)))
sub = [x for x in P if x["vr"] < 1]
put("A.subone_min_kw", min(x["kr"] for x in sub))

# ------------------------------------------------------------------ B. the area-code tables, arithmetic from the released series
print("\n== B. tables 2, 3, 5, 6")
T2 = {"July": (3862, 100012, 103045), "August": (32281, 876153, 963937), "September": (150113, 1534362, 1765077), "October": (215577, 1610284, 1858297)}
csv2 = list(csv.DictReader((B / "instrument_divergence_extra/instrument_series_table2_visits_by_month.csv").open()))
num = lambda s: float(re.sub(r"[^\d.]", "", s))
for r_ in csv2[1:]:
    m = r_["Month"].split()[0]
    a_ = num(r_["Ahrefs, worldwide"])
    u_, w_ = re.match(r"([\d,]+) \(([\d,]+)\)", r_["Semrush, US (worldwide)"]).groups()
    assert (a_, num(u_), num(w_)) == T2[m], m
    OUT[f"B.t2.{m}.us_ww"] = num(u_) / a_
    OUT[f"B.t2.{m}.ww_ww"] = num(w_) / a_
    OUT[f"B.t2.{m}.us_us"] = num(u_) / (a_ * 0.815)
    print(m, round(OUT[f"B.t2.{m}.us_ww"], 3), round(OUT[f"B.t2.{m}.ww_ww"], 3), round(OUT[f"B.t2.{m}.us_us"], 3))
put("B.err_factor", math.sqrt(T2["August"][1] / T2["August"][0]))
put("B.err_abs_times", (T2["August"][1] - T2["August"][0]) / 2 / T2["August"][0])
T3 = {"July": (47, 284, 138), "August": (851, 6749, 2221), "September": (3380, 22665, 8187), "October": (7455, 37238, 10018)}
for m, (k, n, c) in T3.items():
    lo, hi = wilson(k, n)
    OUT[f"B.t3.{m}"] = dict(pct=100 * k / n, lo=100 * lo, hi=100 * hi, ratio=c / k)
    print(m, OUT[f"B.t3.{m}"])
# table 5 and 6 arithmetic
rows = {r_["Metric"]: r_ for r_ in csv.DictReader((B / "instrument_divergence_extra/instrument_series_table5_checkpoints.csv").open())}
days = list(rows["Ranking positions, all"].keys())[1:]
for d in days:
    vals = [rows[k][d] for k in ("Ranking positions, all", "Positions 1–3", "Positions 4–10", "Positions 11–20", "Positions 21–100 (derived)")]
    if "n/r" not in vals:
        t, a1, a2, a3, a4 = [num(v) for v in vals]
        assert t - a1 - a2 - a3 == a4, d
print("table 5 derived row closes every full column")
pos = [num(rows["Ranking positions, all"][d]) for d in days]
rd = [num(rows["Live referring domains"][d]) for d in days]
ans = {d: rows["AI answers citing the section"][d] for d in days}
put("B.t6", [(p2 - p1, round((p2 - p1) / dd)) for p1, p2, dd in zip(pos[:6], pos[1:7], [15, 15, 7, 8, 15, 15])])
put("B.t6_rd", [r2 - r1 for r1, r2 in zip(rd[:6], rd[1:7])])
put("B.share_d37", 100 * 15830 / 43302)
put("B.share_after", 100 * (43302 - 15830) / 43302)
put("B.share_after_d45", 100 * (43302 - 20326) / 43302)
put("B.ai_lo", 100 * (14823 - 6390) / 14823)
put("B.ai_hi", 100 * (14823 - 3725) / 14823)
put("B.fastest_vs_arrival", 100 * (768 / 562 - 1))
put("B.implied_end_sep", 19 + 917 - 95)
put("B.ai_scope", 158100 / 17206)
put("B.cited_pages_times", 29600 / 434)
put("B.rd_ratio", 913 / 80)
put("B.kw_us", 58586 / 29000)
put("B.kw_ww", 92300 / 28900)
put("B.hub_range", (294 / 238, 474 / 238))
put("B.fifty_of_441", 100 * 50 / 441)
put("B.reread_oct_us", 100 * (1659636 / 1610284 - 1))
put("B.reread_oct_ww", 100 * (1910867 / 1858297 - 1))
put("B.decomp_us", (1610284 / 215577, 58586 / 29000, (1610284 / 215577) / (58586 / 29000), math.log(58586 / 29000) / math.log(1610284 / 215577)))
put("B.decomp_ww", (1858297 / 215577, 92300 / 28900, (1858297 / 215577) / (92300 / 28900), math.log(92300 / 28900) / math.log(1858297 / 215577)))
g = {m: (T2[n][0] / T2[o][0], T2[n][1] / T2[o][1]) for m, o, n in (("JA", "July", "August"), ("AS", "August", "September"), ("SO", "September", "October"))}
put("B.growth", {k: (v[0], v[1], v[0] / v[1]) for k, v in g.items()})

# ------------------------------------------------------------------ C. the code pages list
print("\n== C. section_code_pages")
C = list(csv.DictReader((B / "instrument_divergence_extra/section_code_pages_2026-10-14.csv").open()))
put("C.rows", len(C))
put("C.groups", dict(Counter(r_["group"] for r_ in C)))
put("C.locations", len({r_["location"] for r_ in C}))
put("C.registry_use", dict(Counter(r_["registry_use"] for r_ in C)))

# ------------------------------------------------------------------ D. Section 6, from the anonymized counts, to more decimals
print("\n== D. m2_label_counts")
L = list(csv.DictReader((B / "review_demand/m2_label_counts.csv").open()))
BR = list(csv.DictReader((B / "review_demand/m2_branches.csv").open()))
bv = {b_["branch_id"]: float(b_["own_volume_share"]) for b_ in BR}
ment = [int(x["mentions"]) for x in L]
vrank = [float(x["volume_rank"]) for x in L]
orank = [float(x["own_volume_rank"]) for x in L]
nodes = [{k: int(c) for k, c in (p.split(":") for p in x["branch_nodes"].split(";"))} for x in L]
mi = [k for k in range(len(L)) if ment[k] > 0]
put("D.linkable", len(L))
put("D.mentioned", len(mi))
put("D.unmentioned", len(L) - len(mi))
put("D.rho_mentioned_exact", spearmanr([ment[k] for k in mi], [vrank[k] for k in mi]).statistic)
put("D.tau_mentioned_exact", kendalltau([ment[k] for k in mi], [vrank[k] for k in mi]).statistic)
put("D.rho_all_exact", spearmanr(ment, vrank).statistic)
ge20 = [k for k in mi if ment[k] >= 20]
put("D.n_ge20", len(ge20))
put("D.rho_ge20_exact", spearmanr([ment[k] for k in ge20], [vrank[k] for k in ge20]).statistic)
zero_rank = min(vrank)
put("D.n_zero_volume_mentioned", sum(vrank[k] == zero_rank for k in mi))
put("D.n_zero_volume_all", sum(v == zero_rank for v in vrank))
put("D.rho_own_m", spearmanr([ment[k] for k in mi], [orank[k] for k in mi]).statistic)
put("D.rho_own_a", spearmanr(ment, orank).statistic)
# the same seeded resampling sequence as m2_from_counts.py, printed to five decimals
rng = random.Random(20261015)


def boot(xs, ys, reps):
    n, out = len(xs), []
    for _ in range(reps):
        idx = [rng.randrange(n) for _ in range(n)]
        r_ = spearmanr([xs[i] for i in idx], [ys[i] for i in idx]).statistic
        if r_ == r_:
            out.append(r_)
    out.sort()
    return out[int(0.025 * len(out))], out[int(0.975 * len(out)) - 1]


put("D.ci_mentioned", boot([ment[k] for k in mi], [vrank[k] for k in mi], 10_000))
put("D.ci_all", boot(ment, vrank, 2_000))


def split(counts, rows_):
    o = {}
    for k in rows_:
        if counts[k]:
            tot = sum(nodes[k].values())
            for b_, c in nodes[k].items():
                o[b_] = o.get(b_, 0) + counts[k] * c / tot
    return o


def modal(counts, rows_):
    o = {}
    for k in rows_:
        if counts[k]:
            b_ = max(nodes[k].items(), key=lambda bc: bc[1])[0]
            o[b_] = o.get(b_, 0) + counts[k]
    return o


def shares(d):
    tot = sum(d.get(b_, 0) for b_ in bv)
    return [d.get(b_, 0) / tot for b_ in bv]


vs = [bv[b_] / sum(bv.values()) for b_ in bv]
rs = shares(split(ment, range(len(L))))
Bs = sorted(zip(bv, rs, vs), key=lambda t: -t[1])
put("D.rho_branch_split", spearmanr([t[1] for t in Bs], [t[2] for t in Bs]).statistic)
put("D.ci_branch_split", boot([t[1] for t in Bs], [t[2] for t in Bs], 10_000))
r2v = shares(modal(ment, range(len(L))))
put("D.rho_branch_modal", spearmanr(r2v, vs).statistic)
put("D.p_branch_modal", spearmanr(r2v, vs).pvalue)
put("D.ci_branch_modal", boot(r2v, vs, 10_000))
mw = sorted((k for k in range(len(L)) if int(L[k]["words"]) >= 2), key=lambda k: int(L[k]["multiword_order"]))
cm = {k: int(L[k]["mentions_multiword_linker"]) for k in mw}
mmw = [k for k in mw if cm[k] > 0]
put("D.mw_labels", len(mw))
put("D.mw_mentioned", len(mmw))
put("D.rho_mw_mentioned", spearmanr([cm[k] for k in mmw], [vrank[k] for k in mmw]).statistic)
put("D.ci_mw_mentioned", boot([cm[k] for k in mmw], [vrank[k] for k in mmw], 10_000))
cnt_mw = [cm.get(k, 0) for k in range(len(L))]
Bm = shares(split(cnt_mw, mw))
put("D.rho_mw_split", spearmanr(Bm, vs).statistic)
put("D.ci_mw_split", boot(Bm, vs, 10_000))
put("D.rho_mw_modal", spearmanr(shares(modal(cnt_mw, mw)), vs).statistic)
names = {b_["branch_id"]: b_["branch"] for b_ in BR}
put("D.shares", {names[b_]: (round(100 * r_, 3), round(100 * v_, 3)) for b_, r_, v_ in Bs[:4]})
put("D.mw_top", {names[b_]: (round(100 * r_, 3), round(100 * v_, 3)) for b_, r_, v_ in sorted(zip(bv, Bm, vs), key=lambda t: -t[1])[:3]})
put("D.arith_link_rate", 100 * 20663 / 37193)
put("D.arith_labels_per", 46517 / 20663)
put("D.arith_36", 100 * 367 / 1008)
put("D.arith_105", 100 * 106 / 1008)
put("D.wilson_neg", tuple(100 * x for x in wilson(924, 6620)) + (100 * 924 / 6620,))
put("D.wilson_5star", tuple(100 * x for x in wilson(564, 29225)) + (100 * 564 / 29225,))

# ------------------------------------------------------------------ E. link check and stakes screen from the judgments
print("\n== E. link check and stakes screen")


def col(name, key):
    return {r_["sample_id"]: r_[key].strip().lower() for r_ in csv.DictReader((B / name).open())}


hdr = lambda n: next(csv.reader((B / n).open()))
print(hdr("review_demand/r2_judgments_A.csv"), hdr("review_demand/r2_judgments_B.csv"), hdr("stakes/stakes_screen_judgments_1.csv"))
kA = hdr("review_demand/r2_judgments_A.csv")[1]
kB = hdr("review_demand/r2_judgments_B.csv")[1]
a1, a2 = col("review_demand/r2_judgments_A.csv", kA), col("review_demand/r2_judgments_A_annotator2.csv", kA)
ids = sorted(a1)
ka, po = kappa([a1[i] for i in ids], [a2[i] for i in ids])
put("E.kappa_A", ka)
put("E.agree_A", 100 * po)
put("E.count_A", (dict(Counter(a1.values())), dict(Counter(a2.values()))))
b1, b2 = col("review_demand/r2_judgments_B.csv", kB), col("review_demand/r2_judgments_B_annotator2.csv", kB)
ids = sorted(b1)
kb, po = kappa([b1[i] for i in ids], [b2[i] for i in ids])
put("E.kappa_B", kb)
put("E.agree_B", 100 * po)
put("E.count_B", (dict(Counter(b1.values())), dict(Counter(b2.values()))))
s1, s2 = col("stakes/stakes_screen_judgments_1.csv", "uses_vendor_data"), col("stakes/stakes_screen_judgments_2.csv", "uses_vendor_data")
ids = sorted(s1)
ks, po = kappa([s1[i] for i in ids], [s2[i] for i in ids])
put("E.kappa_stakes", ks)
put("E.agree_stakes", 100 * po)
put("E.count_stakes", (dict(Counter(s1.values())), dict(Counter(s2.values()))))
put("E.wilson_99_120", tuple(100 * x for x in wilson(99, 120)))
put("E.wilson_104_120", tuple(100 * x for x in wilson(104, 120)))
# stakes sample: rerun the selection lines of stakes_screen_sample.py without its network fetch
W = list(csv.DictReader((B / "stakes/vendor_reliance_works.csv").open()))
print("works columns:", list(W[0].keys()))
src = (B / "stakes/stakes_screen_sample.py").read_text()
print("--- sampling lines of stakes_screen_sample.py ---")
print("\n".join(src.splitlines()[21:34]))
seen, rows_ = set(), []
for r_ in W:
    if r_["id"] not in seen and int(r_["n_tools"]) >= 1:
        seen.add(r_["id"])
        rows_.append(r_)
put("E.works_named", len(rows_))
put("E.works_by_year", {y: sum(str(r_.get("year", r_.get("publication_year"))) == y for r_ in rows_) for y in ("2020", "2025", "2026")})

# ------------------------------------------------------------------ F. Study W, data chain and statistics recomputed from the per-title file
print("\n== F. Study W")
W_ = B / "wikipedia_demand"
G = list(csv.DictReader((W_ / "wiki_groups.csv").open()))
K = list(csv.DictReader((W_ / "wiki_codes.csv").open()))
PV = list(csv.DictReader((W_ / "pageviews_monthly.csv").open()))
put("F.n_groups", len(G))
put("F.n_codes", len(K))
put("F.codes_per_group", dict(sorted(Counter(int(g_["n_codes"]) for g_ in G).items())))
put("F.n_redirect_titles", sum(int(g_["n_redirect_titles"]) for g_ in G))
put("F.n_keywords_total", sum(int(k["n_keywords"]) for k in K))
put("F.n_titles", len({r_["title"] for r_ in PV}))
# raw json lines against the monthly file
raw = defaultdict(dict)
statuses = Counter()
n_lines = Counter()
for name in ("resolution.jsonl", "search_fallback.jsonl", "redirects.jsonl", "pageviews.jsonl"):
    with (W_ / name).open() as f:
        for line in f:
            n_lines[name] += 1
            if name == "pageviews.jsonl":
                d = json.loads(line)
                statuses[d["status"]] += 1
                for it in d["body"].get("items", []):
                    raw[d["title"]][it["timestamp"][:6]] = it["views"]
put("F.raw_lines", dict(n_lines))
put("F.raw_lines_sum", sum(n_lines.values()))
put("F.pageview_status", dict(statuses))
bad = sum(raw[r_["title"]].get(r_["month"], 0) != int(r_["views"]) for r_ in PV)
put("F.monthly_vs_raw_mismatches", bad)
# per-article sums against wiki_groups
PRIMARY = [f"{y}{m:02d}" for y, m in [(2024, 10), (2024, 11), (2024, 12)] + [(2025, m) for m in range(1, 10)]]
SHIFT = [f"{y}{m:02d}" for y, m in [(2024, 9), (2024, 10), (2024, 11), (2024, 12)] + [(2025, m) for m in range(1, 9)]]
CLEAN = [f"{y}{m:02d}" for y, m in [(2024, 10), (2024, 11), (2024, 12), (2025, 1), (2025, 2), (2025, 9)]]
POST = ["202608", "202609"]
by = defaultdict(lambda: defaultdict(int))
for r_ in PV:
    by[r_["article_pageid"]][r_["month"]] += int(r_["views"])
dif = Counter()
for g_ in G:
    m_ = by[g_["article_pageid"]]
    if sum(m_[x] for x in PRIMARY) != int(g_["views_primary"]):
        dif["primary"] += 1
    if sum(m_[x] for x in SHIFT) != int(g_["views_shifted"]):
        dif["shifted"] += 1
    if sum(m_[x] for x in CLEAN) != int(g_["views_clean6"]):
        dif["clean6"] += 1
    if sum(m_[x] for x in POST) != int(g_["views_post"]):
        dif["post"] += 1
    if 12 * st.median(m_[x] for x in PRIMARY) != float(g_["views_primary_median_x12"]):
        dif["median"] += 1
    if max(m_[x] for x in PRIMARY) != int(g_["views_primary_max_month"]):
        dif["max"] += 1
put("F.group_vs_title_differences", dict(dif))
# dem per group against code rows
dv = defaultdict(int)
kw = defaultdict(int)
for k in K:
    dv[k["article_pageid"]] += int(float(k["volume"]))
    kw[k["article_pageid"]] += int(k["n_keywords"])
put("F.dem_differences", sum(dv[g_["article_pageid"]] != int(float(g_["dem"])) for g_ in G))
put("F.kw_differences", sum(kw[g_["article_pageid"]] != int(g_["n_keywords"]) for g_ in G))
dem = np.array([float(g_["dem"]) for g_ in G])
Wg = np.array([float(g_["views_primary"]) for g_ in G])
kg = np.array([float(g_["n_keywords"]) for g_ in G])
put("F.rho", spearmanr(dem, Wg).statistic)
put("F.tau", kendalltau(dem, Wg).statistic)
put("F.rho_kw", spearmanr(kg, Wg).statistic)
ratio = dem / (Wg / 12)
put("F.ratio_pct", (float(np.percentile(ratio, 10)), float(np.median(ratio)), float(np.percentile(ratio, 90))))
put("F.gsd_ratio", float(np.exp(np.std(np.log(ratio), ddof=1))))
put("F.gsd_dem", float(np.exp(np.std(np.log(dem), ddof=1))))
put("F.gsd_W", float(np.exp(np.std(np.log(Wg), ddof=1))))
put("F.W_minmax", (float(Wg.min()), float(Wg.max())))
put("F.dem_minmax", (float(dem.min()), float(dem.max())))
put("F.W_15_50", (int(((Wg >= 15000) & (Wg <= 50000)).sum()), float(100 * ((Wg >= 15000) & (Wg <= 50000)).mean())))
put("F.pearson_loglog", float(np.corrcoef(np.log(dem), np.log(Wg))[0, 1]))
put("F.p3_floor_gsd", float(np.exp(abs(np.std(np.log(dem), ddof=1) - np.std(np.log(Wg), ddof=1)))))
Wa = np.array([float(g_["views_primary_article_only"]) for g_ in G])
put("F.pooled_redirect_share", float(100 * (1 - Wa.sum() / Wg.sum())))
put("F.median_redirect_share", float(100 * np.median(1 - Wa / Wg)))
vols = np.array([float(k["volume"]) for k in K if float(k["volume"]) > 0])
put("F.log10_sd_code_volume_nonzero", float(np.std(np.log10(vols), ddof=1)))
put("F.zero_volume_codes", [k["code"] for k in K if float(k["volume"]) == 0])

# ------------------------------------------------------------------ G. Section 7, medians recomputed from the aggregates by separate code
print("\n== G. Section 7 aggregates")
AG = B / "ai_citation_cross_sector/aggregates"
TS = list(csv.DictReader((AG / "cross_sector_type_shares.csv").open()))
print("type share columns:", list(TS[0].keys()))
PMc = list(csv.DictReader((AG / "cross_sector_platform_metrics.csv").open()))
print("metric columns:", list(PMc[0].keys()))
GOOG = ["aio_searchqueries", "aio_prompts", "aimode_searchqueries", "aimode_prompts"]
OTH = ["chatgpt", "perplexity", "gemini", "copilot"]
vc = {}
for r_ in TS:
    vc[(r_["etf"], r_["surface"])] = 100 * sum(float(r_[k]) for k in ("share_video", "share_forum", "share_social", "share_user_publishing"))
sect = sorted({k[0] for k in vc})
put("G.n_cells", len(vc))
put("G.n_sectors", len(sect))
gv = [vc[(s, p)] for s in sect for p in GOOG]
ov = [vc[(s, p)] for s in sect for p in OTH]
put("G.median_google", st.median(gv))
put("G.range_google", (min(gv), max(gv)))
put("G.median_other", st.median(ov))
put("G.range_other", (min(ov), max(ov)))
put("G.by_surface", {p: round(st.median(vc[(s, p)] for s in sect), 3) for p in GOOG + OTH})
put("G.dominance", sum(min(vc[(s, p)] for p in GOOG) > max(vc[(s, p)] for p in OTH) for s in sect))
props = list(csv.DictReader((B / "ai_citation_cross_sector/design/cross_sector_company_properties.csv").open()))
comp = list(csv.DictReader((B / "ai_citation_cross_sector/design/cross_sector_companies.csv").open()))
put("G.n_props", len(props))
put("G.n_company_rows", len(comp))
print("companies columns:", list(comp[0].keys()))
put("G.answer_counts", sum(int(r_["ai_responses_us_all_platforms"]) for r_ in csv.DictReader((AG / "sector_answer_counts.csv").open())))
CE = list(csv.DictReader((AG / "cross_sector_cells.csv").open()))
print("cell columns:", list(CE[0].keys()))
sizes = [int(r_["cited_in_sum"]) for r_ in CE if r_["surface"] in GOOG + OTH]
put("G.cell_size_range", (min(sizes), max(sizes)))
sha = (AG / "raw_exports_SHA1SUMS.txt").read_text().splitlines()
c = Counter()
for line in sha:
    pth = line.split()[1]
    pth = pth[2:] if pth.startswith("./") else pth
    c[pth.split("/")[0]] += 1
put("G.sha1_lines", len(sha))
put("G.sha1_by_top_folder", dict(c))

Path(sys.argv[2]).write_text(json.dumps(OUT, indent=1, default=str))
