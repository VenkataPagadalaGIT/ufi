#!/bin/bash
R=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run5
RUN="python3 $R/check_scripts/run_one.py"
B=$R/pristine/User_First_Intelligence_v5.3_2026-11-03_source
export RUN_TIMEOUT=60
$RUN stakes_screen_sample stakes - -- python3 stakes_screen_sample.py | cut -c1-200
tail -1 "$R/outputs/stakes_screen_sample.stderr" | cut -c1-200
cd "$B"
: > "$R/outputs/_08_review_scripts.tsv"
for f in $(find 08_REVIEW -name '*.py' | sort); do
  d=$(dirname "$f"); s=$(basename "$f"); t="rv_$(echo "$f" | tr '/.' '__')"
  out=$($RUN "$t" "$d" - -- python3 "$s" 2>&1 | cut -c1-200)
  ex=$(python3 -c "import json,sys;print(json.load(open('$R/outputs/$t.json'))['exit'])")
  err=$(tail -1 "$R/outputs/$t.stderr" | cut -c1-120 | tr '\t' ' ')
  printf "%s\t%s\t%s\n" "$f" "$ex" "$err" >> "$R/outputs/_08_review_scripts.tsv"
  rm -rf "$R/runs/$t"
done
cut -f2 "$R/outputs/_08_review_scripts.tsv" | sort | uniq -c
cut -c1-170 "$R/outputs/_08_review_scripts.tsv"
