#!/bin/bash
R=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run5
RUN="python3 $R/check_scripts/run_one.py"
$RUN analyze data - -- python3 analyze.py
$RUN instrument_extra instrument_divergence_extra - -- python3 instrument_extra.py
$RUN instrument_extra_as_stamped protocols - -- python3 instrument_extra_as_stamped.py
$RUN reread_compare protocols - -- python3 reread_compare.py
$RUN reread_compare_anywhere protocols - -- python3 reread_compare_anywhere.py
$RUN m2_from_counts review_demand - -- python3 m2_from_counts.py
$RUN r2_link_check review_demand - -- python3 r2_link_check.py
$RUN analyze_reviews review_demand - -- python3 analyze_reviews.py
$RUN r2_link_sample review_demand - -- python3 r2_link_sample.py
$RUN supplement_r10 review_demand - -- python3 supplement_r10.py
$RUN make_fig_reviews_v50 review_demand - -- python3 make_fig_reviews_v50.py
$RUN vendor_reliance_offline stakes - -- python3 vendor_reliance.py --offline
$RUN stakes_screen_check stakes - -- python3 stakes_screen_check.py
$RUN wiki_demand_analysis wikipedia_demand - -- python3 wiki_demand_analysis.py
$RUN wiki_demand_supplement wikipedia_demand - -- python3 wiki_demand_supplement.py
$RUN make_fig_wikipedia wikipedia_demand - -- python3 make_fig_wikipedia.py
$RUN section7_from_aggregates ai_citation_cross_sector/scripts - -- python3 section7_from_aggregates.py
$RUN cross_sector ai_citation_cross_sector/scripts - -- python3 cross_sector.py
$RUN cross_sector_sensitivity ai_citation_cross_sector/scripts - -- python3 cross_sector_sensitivity.py
$RUN cross_sector_sensitivity2 ai_citation_cross_sector/scripts - -- python3 cross_sector_sensitivity2.py
$RUN make_tables_sector_surface ai_citation_cross_sector/scripts - -- python3 make_tables_sector_surface.py
$RUN make_fig_sources ai_citation_cross_sector/scripts - -- python3 make_fig_sources.py
$RUN make_brand_radar_urls ai_citation_cross_sector/scripts - -- python3 make_brand_radar_urls.py
$RUN make_figs_v4 . - -- python3 make_figs_v4.py
$RUN make_fig0 . - -- python3 make_fig0.py
