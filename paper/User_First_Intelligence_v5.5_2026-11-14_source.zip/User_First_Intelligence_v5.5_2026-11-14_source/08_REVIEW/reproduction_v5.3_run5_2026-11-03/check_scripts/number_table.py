#!/usr/bin/env python3
"""Build the per-number table: find every quoted value in manuscript_v50.md (byte-identical in content to the shipped PDF's
source, see the report), compare it at the paper's precision with the value obtained, locate it on a PDF page, and list
every numeric token that no rule or exclusion accounts for.

usage: number_table.py <out dir>"""
import csv
import json
import re
import subprocess
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import values as V
from values import VALUES, v, TXT, B, R, J
from rules import RULES
from extra_values import install as install_extra
from tables_check import table_rows, TABLE_SPANS
from exclusions import LABELS, LITERATURE, classify_rest

install_extra()
OUT = Path(sys.argv[1])
OUT.mkdir(parents=True, exist_ok=True)
MS = (B / "manuscript_v50.md").read_text()
import os
MUT = []
if os.environ.get("MUTATE"):
    import random as _r
    prev = [x for x in json.loads((OUT / "numbers.json").read_text()) if x["status"] == "MATCH" and x["value_name"] not in ("fact", "figure") and re.search(r"\d", x["quoted"]) and x["basis"] in ("RUN", "CALC", "FILE", "CIRC", "BLOCK")]
    rng = _r.Random(int(os.environ["MUTATE"]))
    ms_ = list(MS)
    for x in rng.sample(prev, 120):
        p0 = int(x["pos"])
        tk = x["quoted"]
        if MS[p0:p0 + len(tk)] != tk:
            continue
        idx = [i for i, ch in enumerate(tk) if ch.isdigit()]
        i = idx[-1]
        ms_[p0 + i] = str((int(tk[i]) + 3) % 10)
        MUT.append((p0, tk))
    MS = "".join(ms_)
    OUT = OUT / "mutation"
    OUT.mkdir(exist_ok=True)
PDF = R / "User_First_Intelligence_v5.3_2026-11-03.pdf"

# ---------------------------------------------------------------- sections and PDF pages
heads = [(m.start(), m.group(2).strip()) for m in re.finditer(r"(?m)^(#{1,3}) (.*)$", MS)]


def section_at(pos):
    name = "Title block"
    for s, h in heads:
        if s <= pos:
            name = h
        else:
            break
    if name.startswith("User First Intelligence for"):
        return "Title block"
    return re.sub(r"^(\d+(\.\d+)?|[A-E]\.\d) .*", r"§\1", name).replace("Appendix ", "App. ").split(":")[0]


def norm(s):
    s = unicodedata.normalize("NFKC", s).replace("−", "-").replace("–", "-").replace("’", "'").replace("“", '"').replace("”", '"')
    s = re.sub(r"[\*`\\_]", "", s)
    return re.sub(r"[\s\-]+", "", s)


n_pages = int(re.search(r"Pages:\s+(\d+)", subprocess.run(["pdfinfo", str(PDF)], capture_output=True, text=True).stdout).group(1))
PAGES = {}
for p in range(1, n_pages + 1):
    PAGES[p] = norm(subprocess.run(["pdftotext", "-f", str(p), "-l", str(p), str(PDF), "-"], capture_output=True, text=True).stdout)


def locate(pos, tok):
    """Page of a quoted value: look for the value with widening context, in the PDF's text."""
    for w in (70, 45, 28, 16):
        ctx = norm(MS[max(0, pos - w):pos + len(tok) + w])
        hits = [p for p, t in PAGES.items() if ctx in t]
        if len(hits) >= 1:
            return hits[0]
    # context can straddle a column or page break: try the left and right sides alone
    for w in (40, 25, 14):
        for ctx in (norm(MS[max(0, pos - w):pos + len(tok)]), norm(MS[pos:pos + len(tok) + w])):
            hits = [p for p, t in PAGES.items() if ctx in t]
            if len(hits) >= 1:
                return hits[0]
    return None


# ---------------------------------------------------------------- compare
WORDS = {"zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11, "twelve": 12,
         "thirteen": 13, "fifteen": 15, "nineteen": 19, "twenty": 20, "fifty": 50, "seventeen": 17}


def parse(tok):
    t = tok.lower().strip()
    if t in WORDS:
        return float(WORDS[t]), 0
    mult = 1000 if t.endswith("k") else 1
    t = t.rstrip("kx%").replace(",", "").replace("+", "").replace("−", "-")
    d = len(t.split(".")[1]) if "." in t else 0
    return float(t) * mult, (d - (3 if mult == 1000 else 0))


def equal(tok, obt):
    if isinstance(obt, str):
        return tok.strip() == obt.strip()
    val, d = parse(tok)
    tol = 0.5 * 10 ** (-d) + 1e-9
    return abs(val - float(obt)) <= tol


rows = []
used = []  # spans accounted for


def add(pos, tok, name, ctx=None):
    meta = VALUES[name]
    obt, basis = meta["obtained"], meta["basis"]
    if name in ("p001", "p001b", "p_below"):
        same = float(obt) < float(tok)
    else:
        same = equal(tok, obt) if obt is not None else None
    if basis == "NONE":
        status, why = "CANNOT RUN", meta["note"] or "no source in the bundle"
    elif basis == "SAVED":
        if same:
            status, why = "CANNOT RUN", (meta["note"] + "; " if meta["note"] else "") + "agrees with the saved output; the script that prints it needs withheld data"
        else:
            status, why = "MISMATCH", f"paper {tok}, saved output {obt}"
    else:
        status = "MATCH" if same else "MISMATCH"
        why = meta["note"]
    rows.append(dict(section=section_at(pos), page=locate(pos, tok), quoted=tok, context=" ".join(MS[max(0, pos - 45):pos + len(tok) + 30].split()),
                     source=meta["source"], obtained=obt if not isinstance(obt, float) else (round(obt, 6)), basis=basis, status=status, reason=why, value_name=name, pos=pos))
    used.append((pos, pos + len(tok)))


masked = list(MS)
for a, b_ in TABLE_SPANS(MS):
    for i in range(a, b_):
        if masked[i] != "\n":
            masked[i] = " "
ref_a = MS.index("## References")
ref_b = MS.index("## Appendix A")
for i in range(ref_a, ref_b):
    if masked[i] != "\n":
        masked[i] = " "
TEXT = "".join(masked)

seen = set()
missing_rules = []
for pat, names, sec in RULES:
    if sec == "NONE" or not names:
        continue
    hit = 0
    for m in re.finditer(pat, TEXT):
        if sec and not section_at(m.start()).startswith(sec):
            continue
        hit += 1
        for i, nm in enumerate(names, 1):
            if nm is None:
                continue
            st_ = m.start(i)
            if st_ < 0 or (st_, m.end(i)) in seen:
                continue
            seen.add((st_, m.end(i)))
            add(st_, m.group(i), nm)
    if not hit:
        missing_rules.append(pat)

# ---------------------------------------------------------------- cell-by-cell tables
CAP_PAGE = {}


def caption_page(pos):
    """A table cell's page: the table's caption page, or the next page where the cell itself does not sit on it."""
    cap = list(re.finditer(r"(?m)^\*Table [\dCD]+\.[^\n]{0,60}", MS[:pos]))[-1]
    return locate(cap.start() + 2, cap.group(0)[1:40]) or None


for row in table_rows(MS, locate, section_at):
    if not row["page"]:
        row["page"] = caption_page(row["pos"])
    tb = re.findall(r"(?m)^\*Table ([\dCD]+)\.", MS[:row["pos"]])[-1]
    row["context"] = f"Table {tb}"
    row["section"] = f"Table {tb}"
    rows.append(row)

# ---------------------------------------------------------------- coverage of numeric tokens outside the checked tables
TOK = re.compile(r"(?<![\w.:/-])[+−]?\d[\d,]*(?:\.\d+)?(?:x|%|K)?(?![\w])")
excl_spans = []
for reason, pats in LABELS.items():
    for pat in pats:
        for m in re.finditer(pat, TEXT):
            g = range(1, (m.lastindex or 0) + 1) or [0]
            for i in g:
                if m.start(i) >= 0:
                    excl_spans.append((m.start(i), m.end(i), reason))
cov = Counter()
uncovered = []
UNC_POS = []
excluded_rows = []
usedset = sorted(used)
for m in TOK.finditer(TEXT):
    a, b_ = m.span()
    tok = m.group(0).rstrip(",")
    if any(x <= a < y for x, y in used):
        cov["checked"] += 1
        continue
    reason = next((r_ for x, y, r_ in excl_spans if x <= a < y), None)
    if reason is None:
        reason = classify_rest(section_at(a), TEXT, a, b_)
    if reason:
        cov["excluded: " + reason] += 1
        excluded_rows.append((section_at(a), tok, reason, " ".join(MS[max(0, a - 40):b_ + 30].split())))
    else:
        cov["uncovered"] += 1
        uncovered.append((section_at(a), tok, " ".join(MS[max(0, a - 50):b_ + 35].split())))
        UNC_POS.append(a)

# ---------------------------------------------------------------- statements in words, and figure labels
from facts import FACTS, FIG_LABELS, figure_text
for pat, ok, basis_, src in FACTS:
    found = list(re.finditer(pat, TEXT))
    if not found:
        missing_rules.append("FACT " + pat)
    for m in found:
        status = "MATCH" if ok else "MISMATCH"
        why = "statement in words"
        if basis_ == "SAVED":
            status, why = ("CANNOT RUN", "statement in words; agrees with the saved output; the script that prints it needs withheld data") if ok else ("MISMATCH", "statement in words")
        rows.append(dict(section=section_at(m.start()), page=locate(m.start(), m.group(0)), quoted=m.group(0), context=" ".join(MS[max(0, m.start() - 30):m.end() + 20].split()), source=src,
                         obtained="agrees" if ok else "DISAGREES", basis=basis_, status=status, reason=why, value_name="fact", pos=m.start()))
for fig, fname, labels, name in FIG_LABELS:
    txt = figure_text(fname)
    cap = MS.index(f"![{fig}.")
    for lab in labels:
        present = lab in txt
        if name:
            meta = VALUES[name]
            ok = present and equal(lab, meta["obtained"])
            src, bs, obt = meta["source"], meta["basis"], meta["obtained"]
        else:
            ok, src, bs, obt = present, "analyze.py", "RUN", lab
        cant = fname == "fig9_reviews"
        rows.append(dict(section=fig, page=locate(cap + 2, f"{fig}."), quoted=lab, context=f"printed inside {fname}.pdf", source=src, obtained=obt if not isinstance(obt, float) else round(obt, 6), basis=bs,
                         status="MATCH" if ok else "MISMATCH", reason=("label in the shipped figure; the figure itself cannot be redrawn (licensed export)" if cant else "label in the shipped figure; the figure script reruns to identical bytes (PNG)"), value_name="figure", pos=cap))

# anything still without a page: the page of its table caption or section heading
for r_ in rows:
    if not r_["page"]:
        cap = list(re.finditer(r"(?m)^\*Table [\dCD]+\.[^\n]{0,60}", MS[:r_["pos"]]))
        if r_["section"].startswith("App. D") and cap:
            r_["page"] = locate(cap[-1].start() + 2, cap[-1].group(0)[1:40])
rows.sort(key=lambda r_: r_["pos"])
for i, r_ in enumerate(rows, 1):
    r_["id"] = i
tally = Counter(r_["status"] for r_ in rows)
basis = Counter((r_["status"], r_["basis"]) for r_ in rows)
print("values", len(rows), dict(tally))
print("by status and basis", sorted(basis.items()))
print("located on a PDF page:", sum(1 for r_ in rows if r_["page"]), "of", len(rows))
print("coverage", dict(cov))
print("rules with no hit:", len(missing_rules))
for p in missing_rules:
    print("   ", p[:110])
print("MISMATCH rows:")
for r_ in rows:
    if r_["status"] == "MISMATCH":
        print("  ", r_["section"], "p.", r_["page"], "paper", r_["quoted"], "obtained", r_["obtained"], "|", r_["source"], "|", r_["reason"][:150], "|", r_["context"][:90])
print("not located:")
for r_ in rows:
    if not r_["page"]:
        print("  ", r_["section"], r_["quoted"], "|", r_["context"][:90])
print("UNCOVERED", len(uncovered))
for s, t, c in uncovered:
    print(f"  {s:10} {t:12} {c}")
if MUT:
    flagged = {int(r_["pos"]) for r_ in rows if r_["status"] == "MISMATCH"}
    unc = 0
    caught = 0
    missed = []
    for p0, tk in MUT:
        if any(abs(int(r_["pos"]) - p0) < 2 and r_["status"] == "MISMATCH" for r_ in rows):
            caught += 1
        elif any(abs(x0 - p0) <= 12 for x0 in UNC_POS):
            caught += 1
            unc += 1
        else:
            missed.append((p0, tk, MS[max(0, p0 - 30):p0 + 25].replace(chr(10), " ")))
    print(f"MUTATION seed {os.environ['MUTATE']}: {len(MUT)} tokens altered; caught {caught} ({unc} by a pattern ceasing to match, reported as uncovered); missed {len(missed)}")
    for z in missed[:20]:
        print("   missed", z)
(OUT / "numbers.json").write_text(json.dumps(rows, indent=0, default=str, ensure_ascii=False))
with (OUT / "excluded_tokens.tsv").open("w") as f:
    f.write("section\ttoken\treason\tcontext\n")
    for e in excluded_rows:
        f.write("\t".join(e) + "\n")
with (OUT / "coverage.json").open("w") as f:
    json.dump(dict(cov), f, indent=1)
