#!/bin/bash
R=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run5
RUN="python3 $R/check_scripts/run_one.py"
N=User_First_Intelligence_v5.3_2026-11-03_source
B=$R/pristine/$N
# determinism: fixed, different hash seeds on every number-producing script that ran
for sd in 1 987654; do
$RUN analyze__hs$sd data $sd -- python3 analyze.py
$RUN instrument_extra__hs$sd instrument_divergence_extra $sd -- python3 instrument_extra.py
$RUN m2_from_counts__hs$sd review_demand $sd -- python3 m2_from_counts.py
$RUN r2_link_check__hs$sd review_demand $sd -- python3 r2_link_check.py
$RUN vendor_reliance_offline__hs$sd stakes $sd -- python3 vendor_reliance.py --offline
$RUN stakes_screen_check__hs$sd stakes $sd -- python3 stakes_screen_check.py
$RUN wiki_demand_analysis__hs$sd wikipedia_demand $sd -- python3 wiki_demand_analysis.py
$RUN wiki_demand_supplement__hs$sd wikipedia_demand $sd -- python3 wiki_demand_supplement.py
$RUN section7_from_aggregates__hs$sd ai_citation_cross_sector/scripts $sd -- python3 section7_from_aggregates.py
$RUN make_tables_sector_surface__hs$sd ai_citation_cross_sector/scripts $sd -- python3 make_tables_sector_surface.py
done
