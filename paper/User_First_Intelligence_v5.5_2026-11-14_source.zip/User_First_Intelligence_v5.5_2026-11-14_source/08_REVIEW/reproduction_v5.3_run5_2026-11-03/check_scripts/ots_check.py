#!/usr/bin/env python3
"""Offline reader of OpenTimestamps proofs, written fresh by the reproducer. For each .ots: the file digest it commits to
(compared with the SHA-256 of the file beside it), then every path to an attestation, executing the operations, printing
the Bitcoin block height and the digest at that attestation (the block's merkle root, in both byte orders). No network;
block times and merkle roots cannot be checked against the chain from here.

usage: ots_check.py <bundle root>"""
import hashlib, sys
from pathlib import Path

B = Path(sys.argv[1])
MAGIC = bytes.fromhex("004f70656e54696d657374616d7073000050726f6f6600bf89e2e884e89294")
BTC = bytes.fromhex("0588960d73d71901")
PEND = bytes.fromhex("83dfe30d2ef90c8e")


class R:
    def __init__(self, b):
        self.b, self.i = b, 0

    def byte(self):
        self.i += 1
        return self.b[self.i - 1]

    def take(self, n):
        self.i += n
        return self.b[self.i - n:self.i]

    def varuint(self):
        v, s = 0, 0
        while True:
            x = self.byte()
            v |= (x & 0x7f) << s
            if not x & 0x80:
                return v
            s += 7

    def varbytes(self):
        return self.take(self.varuint())


def run_op(tag, r, msg):
    if tag == 0xf0:
        return msg + r.varbytes()
    if tag == 0xf1:
        return r.varbytes() + msg
    if tag == 0xf2:
        return msg[::-1]
    if tag == 0xf3:
        return msg.hex().encode()
    if tag == 0x08:
        return hashlib.sha256(msg).digest()
    if tag == 0x02:
        return hashlib.sha1(msg).digest()
    if tag == 0x03:
        return hashlib.new("ripemd160", msg).digest()
    if tag == 0x67:
        import hashlib as h
        return h.new("keccak-256", msg).digest() if "keccak-256" in h.algorithms_available else msg
    raise ValueError(f"unknown op {tag:#x}")


def walk(r, msg, out):
    while True:
        tag = r.byte()
        if tag == 0xff:  # fork: this branch, then continue
            walk_one(r, msg, out)
            continue
        walk_tag(tag, r, msg, out)
        return


def walk_one(r, msg, out):
    tag = r.byte()
    if tag == 0xff:
        walk_one(r, msg, out)
        walk(r, msg, out)
        return
    walk_tag(tag, r, msg, out)


def walk_tag(tag, r, msg, out):
    if tag == 0x00:
        kind = r.take(8)
        payload = r.varbytes()
        if kind == BTC:
            h = R(payload).varuint()
            out.append(("bitcoin", h, msg.hex(), msg[::-1].hex()))
        elif kind == PEND:
            pr = R(payload)
            out.append(("pending", pr.varbytes().decode(), msg.hex(), ""))
        else:
            out.append(("other", kind.hex(), msg.hex(), ""))
        return
    msg2 = run_op(tag, r, msg)
    walk(r, msg2, out)


for ots, target in [
    ("protocols/protocols_manifest.txt.ots", "protocols/protocols_manifest.txt"),
    ("framework_test_r1/framework_retro_test_381_manifest.txt.ots", "framework_test_r1/framework_retro_test_381_manifest.txt"),
    ("framework_test_r1/framework_retro_test_381_amendment_2026-10-15.md.ots", "framework_test_r1/framework_retro_test_381_amendment_2026-10-15.md"),
    ("wikipedia_demand/wikipedia_demand_372_manifest.txt.ots", "wikipedia_demand/wikipedia_demand_372_manifest.txt"),
]:
    b = (B / ots).read_bytes()
    assert b.startswith(MAGIC), ots
    r = R(b[len(MAGIC):])
    ver = r.varuint()
    op = r.byte()
    assert op == 0x08, hex(op)
    dig = r.take(32)
    actual = hashlib.sha256((B / target).read_bytes()).digest()
    print(f"\n{ots}\n  version {ver}; commits to {dig.hex()}\n  sha256({target}) = {actual.hex()}  -> {'EQUAL' if dig == actual else 'DIFFERENT'}")
    out = []
    walk(r, dig, out)
    for o in out:
        if o[0] == "bitcoin":
            print(f"  bitcoin block {o[1]:,}: digest {o[2]} (reversed {o[3]})")
        else:
            print(f"  {o[0]}: {o[1]}")
    print(f"  bytes read {r.i + len(MAGIC)} of {len(b)}")
