"""Cell-by-cell check of the paper's data tables against the released files and the reruns."""
import csv
import math
import re

from values import B, J, TXT, O


def _table(ms, caption_start):
    """The markdown table following the caption that starts with the given text: (start, end, rows of (pos, cell))."""
    a = ms.index(caption_start)
    m = re.compile(r"(?m)^\|.*\n(?:\|.*\n?)+").search(ms, a)
    start, end = m.span()
    rows = []
    pos = start
    for line in m.group(0).splitlines(True):
        cells = []
        i = pos
        parts = line.rstrip("\n").split("|")[1:-1]
        i = pos + 1
        for c in parts:
            lead = len(c) - len(c.lstrip())
            cells.append((i + lead, c.strip()))
            i += len(c) + 1
        rows.append(cells)
        pos += len(line)
    return start, end, rows


CAPS = {"T1": "*Table 1. Instruments", "T2": "*Table 2. Estimated monthly", "T3": "*Table 3. AI Overview citation", "T4": "*Table 4. Twelve URL prefixes", "T5": "*Table 5. Outcomes",
        "T6": "*Table 6. Position growth", "T7": "*Table 7. What the deployment cost", "C1": "*Table C1. Share", "C2": "*Table C2. Size", "C3": "*Table C3. Which source", "C4": "*Table C4. The three"}


def TABLE_SPANS(ms):
    return [_table(ms, c)[:2] for c in CAPS.values()]


def table_rows(ms, locate, section_at):
    out = []

    def add(pos, tok, obtained, basis, source, status=None, reason=""):
        if status is None:
            if isinstance(obtained, str):
                same = tok.strip() == obtained.strip()
            else:
                t = tok.replace(",", "").replace("x", "").replace("%", "").replace("**", "").replace("+", "").replace("−", "-").replace("≈", "")
                d = len(t.split(".")[1]) if "." in t else 0
                same = abs(float(t) - float(obtained)) <= 0.5 * 10 ** (-d) + 1e-9
            status = "MATCH" if same else "MISMATCH"
        out.append(dict(section=section_at(pos), page=locate(pos, tok), quoted=tok, context="", source=source, obtained=obtained if not isinstance(obtained, float) else round(obtained, 6),
                        basis=basis, status=status, reason=reason, value_name="table", pos=pos))

    n = lambda s: float(re.sub(r"[^\d.]", "", s))
    CIRC = "circular: the CSV is parsed from this table; the dashboard read is not archived"
    # ---- Table 2
    _, _, rows = _table(ms, CAPS["T2"])
    csvr = list(csv.DictReader((B / "instrument_divergence_extra/instrument_series_table2_visits_by_month.csv").open()))
    for r, c in zip(rows[2:], csvr):
        m = r[0][1].split()[0]
        if m != "June":
            for (p, t), col in ((r[1], "Days live"), (r[2], "Ahrefs, worldwide")):
                t0 = t.split()[0]
                add(p, t0, n(c[col].split()[0]), "CIRC", "instrument_series_table2 CSV", reason=CIRC)
            p, t = r[3]
            us, ww = re.match(r"([\d,]+) \(([\d,]+)\)", t).groups()
            cu, cw = re.match(r"([\d,]+) \(([\d,]+)\)", c["Semrush, US (worldwide)"]).groups()
            add(p, us, n(cu), "CIRC", "instrument_series_table2 CSV", reason=CIRC)
            add(p + len(us) + 2, ww, n(cw), "CIRC", "instrument_series_table2 CSV", reason=CIRC)
            for k, cell in zip(("us_ww", "ww_ww", "us_us"), r[4:7]):
                add(cell[0], cell[1], J[f"B.t2.{m}.{k}"], "CALC", "arithmetic on Table 2's visits; 81.5% for the third")
    # ---- Table 3
    _, _, rows = _table(ms, CAPS["T3"])
    C3CSV = {r_["Month"].split()[0]: r_ for r_ in csv.DictReader((B / "instrument_divergence_extra/instrument_series_table3_ai_overview_citation_by_month.csv").open())}
    for r in rows[2:]:
        m = r[0][1].split()[0]
        k, nn = re.match(r"([\d,]+) of ([\d,]+)", r[1][1]).groups()
        ck, cn = re.match(r"([\d,]+) of ([\d,]+)", C3CSV[m]["(a) Ahrefs: cited / all AIO keywords"]).groups()
        add(r[1][0], k, n(ck), "CIRC", "instrument_series_table3 CSV", reason=CIRC)
        add(r[1][0] + len(k) + 4, nn, n(cn), "CIRC", "instrument_series_table3 CSV", reason=CIRC)
        pct, lo, hi = re.match(r"([\d.]+)% \[([\d.]+), ([\d.]+)\]", r[2][1]).groups()
        d = J[f"B.t3.{m}"]
        add(r[2][0], pct, d["pct"], "CALC", "arithmetic on Table 3's counts")
        add(r[2][0] + len(pct) + 3, lo, d["lo"], "CALC", "Wilson interval on Table 3's counts")
        add(r[2][0] + len(pct) + 5 + len(lo), hi, d["hi"], "CALC", "Wilson interval on Table 3's counts")
        add(r[3][0], r[3][1], n(C3CSV[m]["(b) Semrush count"]), "CIRC", "instrument_series_table3 CSV", reason=CIRC)
        add(r[4][0], r[4][1], d["ratio"], "CALC", "arithmetic on Table 3's counts")
    # ---- Table 4: reads against the two released files, ratios against the rerun and recomputed
    _, _, rows = _table(ms, CAPS["T4"])
    P = {x["prefix"]: x for x in J["prefixes"]}
    ext = {}
    for line in TXT["extra"].splitlines():
        m = re.match(r"\s+(/\S+)\s+(\d+)\s+([\d.]+)%\s+([\d.]+)x\s+([\d.]+)x\s+([\d.]+)x\s+([\d.]+)x", line)
        if m:
            ext[m[1]] = [float(x) for x in m.groups()[1:]]
    for r in rows[2:]:
        pf = r[0][1]
        x, e = P[pf], ext[pf]
        F_A, F_S = "data/ahrefs_prefixes_2026-10-12.csv", "data/semrush_prefixes_2026-10-12.csv"
        RD = "dashboard read, not archived"
        add(r[1][0], r[1][1], float(x["age"]), "RUN", "instrument_extra.py section 8; age recomputed from the file")
        assert e[0] == x["age"]
        add(r[2][0], r[2][1], x["at"], "FILE", F_A, reason=RD)
        add(r[3][0], r[3][1], x["st"], "FILE", F_S, reason=RD)
        add(r[4][0], r[4][1].strip("*"), e[2], "RUN", "instrument_extra.py section 8")
        add(r[5][0], r[5][1], e[1], "RUN", "instrument_extra.py section 8")
        add(r[6][0], r[6][1].strip("*"), e[3], "RUN", "instrument_extra.py section 8")
        add(r[7][0], r[7][1], x["ak"], "FILE", F_A, reason=RD)
        add(r[8][0], r[8][1], x["sk"], "FILE", F_S, reason=RD)
        add(r[9][0], r[9][1], e[4], "RUN", "instrument_extra.py section 8")
        add(r[10][0], r[10][1], x["ar"], "FILE", F_A, reason=RD)
        add(r[11][0], r[11][1], x["sr"], "FILE", F_S, reason=RD)
        add(r[12][0], r[12][1].strip("*"), e[5], "RUN", "instrument_extra.py section 8")
    # ---- Table 5
    _, _, rows = _table(ms, CAPS["T5"])
    T5 = {r["Metric"]: r for r in csv.DictReader((B / "instrument_divergence_extra/instrument_series_table5_checkpoints.csv").open())}
    heads = [c[1].strip("*") for c in rows[0]]
    days = list(T5["Ranking positions, all"].keys())[1:]
    for r in rows[2:]:
        name = r[0][1]
        for (p, t), d in zip(r[1:], days):
            t0 = t.strip("*")
            if "n/r" in t0:
                add(p, "n/r", T5[name][d], "CIRC", "instrument_series_table5 CSV", reason="not recorded in the paper and in the CSV")
                continue
            if name.startswith("Positions 21"):
                g = lambda k: n(T5[k][d])
                add(p, t0, g("Ranking positions, all") - g("Positions 1–3") - g("Positions 4–10") - g("Positions 11–20"), "CALC", "total less the three reported bands")
            else:
                add(p, t0, n(T5[name][d]), "CIRC", "instrument_series_table5 CSV", reason=CIRC)
    # ---- Table 6: from Table 5
    _, _, rows = _table(ms, CAPS["T6"])
    pos = [n(T5["Ranking positions, all"][d]) for d in days]
    rd = [n(T5["Live referring domains"][d]) for d in days]
    dd = [15, 15, 7, 8, 15, 15]
    for i, r in enumerate(rows[2:]):
        a, b_ = re.match(r"(\d+) to (\d+)", r[1][1]).groups()
        add(r[1][0], a, rd[i], "CALC", "Table 5 referring domains")
        add(r[1][0] + len(a) + 4, b_, rd[i + 1], "CALC", "Table 5 referring domains")
        add(r[2][0], r[2][1], rd[i + 1] - rd[i], "CALC", "difference of Table 5 referring domains")
        add(r[3][0], r[3][1], pos[i + 1] - pos[i], "CALC", "difference of Table 5 positions")
        add(r[4][0], r[4][1].split()[0], (pos[i + 1] - pos[i]) / dd[i], "CALC", "positions gained over the interval's days")
    # ---- Table 7: nothing in the bundle
    _, _, rows = _table(ms, CAPS["T7"])
    for r in rows[2:]:
        m = re.search(r"≈? ?(USD )?([\d,]+)( person-weeks| / year)?", r[1][1])
        if m:
            add(r[1][0], m.group(2), None, "NONE", "none", status="CANNOT RUN", reason="the author's reconstruction from project records; no source in the bundle")
    # ---- Tables C1, C2 against the rerun, and against the saved raw-export output
    _, _, rows = _table(ms, CAPS["C1"])
    NAMES = {"AI Overviews, search queries": "aio_searchqueries", "AI Overviews, prompts": "aio_prompts", "AI Mode, search queries": "aimode_searchqueries", "AI Mode, prompts": "aimode_prompts",
             "ChatGPT": "chatgpt", "Perplexity": "perplexity", "Gemini": "gemini", "Copilot": "copilot"}
    C1 = {}
    for line in TXT["s7"].split("== Appendix C1")[1].split("== Appendix C2")[0].splitlines():
        if "video_community" in line:
            k = line.split()[0]
            C1[k] = re.findall(r"(\S+) (\S+)% \((\S+)%-(\S+)%\)", line)
    for r in rows[2:]:
        k = NAMES[r[0][1]]
        for j, cell in enumerate(r[1:]):
            med, lo, hi = re.match(r"([\d.]+)% \(([\d.]+)–([\d.]+)\)", cell[1]).groups()
            _, a_, b_, c_ = C1[k][j]
            add(cell[0], med, float(a_), "RUN", "section7_from_aggregates.py, Table C1")
            add(cell[0] + len(med) + 3, lo, float(b_), "RUN", "section7_from_aggregates.py, Table C1")
            add(cell[0] + len(med) + 4 + len(lo), hi, float(c_), "RUN", "section7_from_aggregates.py, Table C1")
    _, _, rows = _table(ms, CAPS["C2"])
    SEC = {"Information Technology": "xlk", "Health Care": "xlv", "Financials": "xlf", "Consumer Discretionary": "xly", "Communication Services": "xlc", "Industrials": "xli", "Consumer Staples": "xlp",
           "Energy": "xle", "Utilities": "xlu", "Real Estate": "xlre", "Materials": "xlb"}
    C2 = {}
    for line in TXT["s7"].split("== Appendix C2")[1].split("== Truncation")[0].splitlines():
        p = line.split()
        if len(p) == 9:
            C2[p[0]] = [float(x.replace(",", "")) for x in p[1:]]
    for r in rows[2:]:
        for cell, val in zip(r[1:], C2[SEC[r[0][1]]]):
            add(cell[0], cell[1], val, "RUN", "section7_from_aggregates.py, Table C2")
    # ---- Tables C3, C4 against the rerun
    tb = TXT["tables"].split("\n\n")
    def parse_md(t):
        return {l.split("|")[1].strip(): [c.strip() for c in l.split("|")[2:-1]] for l in t.splitlines() if l.startswith("|") and not l.startswith("|---") and not l.startswith("| Sector")}
    c3, c4 = parse_md(tb[0]), parse_md(tb[1])
    _, _, rows = _table(ms, CAPS["C3"])
    for r in rows[2:]:
        for cell, val in zip(r[1:], c3[r[0][1]]):
            add(cell[0], cell[1], val, "RUN", "make_tables_sector_surface.py, Table C3")
    _, _, rows = _table(ms, CAPS["C4"])
    for r in rows[2:]:
        for cell, val in zip(r[1:], c4[r[0][1]]):
            q = cell[0]
            for d, o in zip(cell[1].split(", "), val.split(", ")):
                add(q, d, o, "RUN", "make_tables_sector_surface.py, Table C4")
                q += len(d) + 2
    return out
