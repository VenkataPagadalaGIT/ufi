"""Numeric tokens that are not results of this study: labels, dates, others' published figures. Each has a stated reason."""
import re

MONTH = r"(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
LABELS = {
    "cross-reference label": [
        r"\b(?:Sections?|Figures?|Tables?|Appendix|Appendices|lessons?|items?|open items?|conditions?|Measurements?|Tasks?|Rounds?|Studies)\s+((?:[A-E]\.)?\d+(?:\.\d+)?[a-z]?)(?:(?:,| and| to|,? and) ((?:[A-E]\.)?\d+(?:\.\d+)?)(?:(?:,| and| to) ((?:[A-E]\.)?\d+(?:\.\d+)?))?(?:(?:,| and| to) ((?:[A-E]\.)?\d+(?:\.\d+)?))?)?",
        r"§(\d+(?:\.\d+)?)", r"\b(?:Items) (\d+), (\d+), (\d+) and (\d+)", r"\bitems (\d+), (\d+) and (\d+)", r"\bTables (\d+), (\d+), (\d+) and (\d+)",
        r"(?m)^(\d+)\. \*\*", r"(?m)^#{1,3} ([\d.]+) ", r"\bTables (\d+) and (\d+)",
        r"\b(?:RQ|P|A)(\d)\b", r"Sections (\d+) and (\d+) to (\d+)", r"Sections (\d+)(?:\.\d+)? to (\d+)(?:\.\d+)?", r"Sections (\d+), (\d+) and (\d+) to (\d+)", r"Sections (\d+\.\d+) and (\d+) to (\d+)", r"Sections (\d+\.\d+), (\d+\.\d+) and (\d+)",
        r"Conditions (\d+) to (\d+)", r"Sections (\d+\.\d+) and (\d+\.\d+)", r"Sections (\d+) and (\d+)", r"conditions (\d+) to (\d+)", r"Tables? C(\d)", r"\(Tables (C\d) and (C\d)\)", r"Measurements (\d) to (\d)", r"Sections (\d+) to (\d+)",
    ],
    "date or time label": [
        r"\b(\d{1,2})(?:–(\d{1,2}))? " + MONTH, MONTH + r" (\d{1,2})\b(?!,\d)", r"\b((?:19|20)\d\d)\b", r"\b(\d{1,2}) to (\d{1,2}) (?:" + MONTH + r")", r"\b(\d{1,2}) and (\d{1,2}) (?:" + MONTH + r")",
        r"(\d\d:\d\d)", r"\bday (\d+)\b", r"\bdays (\d+) to (\d+)\b", r"Day (\d+)\b", r"\bday-(\d+)\b", r"\b(\d+)-day\b", r"\bdays? (\d+)-(\d+)\b", r"day (\d+) to day (\d+)", r"\bdays (\d+)\b",
        r"\((\d+) September\)", r"(\d+)(?:–|-)(\d+) (?:Oct|October)", r"between (\d+) and (\d+) October",
    ],
    "version label": [r"\b[vV]ersions? (\d+\.\d+)(?: to (\d+\.\d+))?", r"\bv(\d+(?:\.\d+)?)", r"\bv(\d+) to v(\d+\.\d+)", r"public versions (\d\.\d) to (\d\.\d)", r"Version (\d\.\d)", r"Protocol v(\d)"],
    "rank label, position band or range name": [r"\bpositions? (\d+)(?:–| to )(\d+)", r"\bPositions? (\d+)–(\d+)", r"\bin (\d+)–(\d+)", r"\bStudies A and B", r"\branks? (\d+)–(\d+)", r"\((\d+)–(\d+)\b", r"Authority Score (\d+)(?:–| to )(\d+)", r"\b(\d+)th percentile", r"\b(\d+)th and (\d+)th percentiles", r"at the (\d+)th\b", r"\b(95)% (?:Wilson|bootstrap|interval|percentile|intervals|CI)", r"\b(95)% (?:Wilson )?(?:interval|intervals)", r"URL Rating below (\d+)"],
    "code or page name": [r"\b(214) (?:Dallas|page)", r"\b(786) Miami", r"\b(404) Atlanta", r"HTTP (\d+)", r"\b(451), assigned", r"codes (327) and (870)", r"code (214)\"", r"the (214) page", r"\"where is area code (214)\""],
    "name, not a value": [r"S&P (500)", r"the (50) states", r"Apache (2\.0)", r"Python (3\.10)", r"clause (4\.4)", r"section (3\.3), items", r"Claude Opus (5), Opus (5\.5), Fable (5) and Fable (5\.1)", r"\((1)\) the organization", r"\((2)\) public release", r"\((3)\) an institutional", r"\((4)\) withdrawal", r"beyond (3)x", r"\b(?:section) (\d+)\b", r"\b(?:Condition) (\d+)\b", r"The (21)–(100) row", r"the (21)–(100) row", r"\bversion (0\.2\.0)"],
    "withdrawn figure quoted as such": [r"is 381, not (290)", r"the (88)-code within-class"],
    "implementation rubric, not a result": [r"carrying a fact about it (0\.5)", r"defaults to (0),"],
    "formula or parameter": [r"/ (2)\.", r"\((1) − ", r"· \((1) − ", r"\[ α\((1) − ", r"\((1) − α\)", r"(0\.5) for ", r"(1\.0) for ", r"= (0\.5)", r"= (0\.85)", r"(0) for ", r"\b(1\.0) and a list", r"grades (1\.0)"],
}
LITERATURE = "another study's published figure"
OWN_TEXT_NOT_CHECKED = "not a measured result (a count of this paper's own text elements or a rhetorical round number)"


def classify_rest(sec, text, a, b):
    """Whole sections and passages that report others' work or are the implementation's own statements."""
    if sec in ("§2",):
        return LITERATURE
    ctx = text[max(0, a - 400):b + 200]
    if sec == "§13.1":
        return LITERATURE
    if sec == "App. B" and re.search(r"Wulczyn|Piccardi|12,000", ctx):
        return LITERATURE
    if sec == "§7.2" and text[a:b] in ("282", "24", "13", "15") and re.search(r"million", text[b:b + 40]):
        return LITERATURE + " (vendor documentation, Bek 2026)"
    if sec == "§7.6" and re.search(r"19\.4%|31%", text[a:b]):
        return LITERATURE + " (Section 2's vendor reports)"
    return None
