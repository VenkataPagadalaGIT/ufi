"""Values that are not a pull from one output line: table cells named in prose, arithmetic constants, statements with no
source in the bundle, and the stamp values."""
import csv
import json
import re

from values import VALUES, v, B, J, TXT, O, blocks


def install():
    # Table 4 cells quoted in prose (from the released twelve-prefix files, recomputed)
    P = {x["prefix"]: x for x in J["prefixes"]}
    for k, p in (("pc", "/product-compare/"), ("dc", "/device-compare/"), ("es", "/es-us/local/")):
        v(f"tab4.us.{k}", 100 * P[p]["us"], "FILE", "data/ahrefs_prefixes_2026-10-12.csv", "dashboard read")
        v(f"tab4.vr.{k}", P[p]["vr"], "CALC", "data/*.csv, ratio recomputed")
        v(f"tab4.mr.{k}", P[p]["mr"], "CALC", "data/*.csv, ratio recomputed")
    v("tab4.kw.ac", P["/local/area-codes/"]["ak"], "FILE", "data/ahrefs_prefixes_2026-10-12.csv", "dashboard read")
    v("tab4.nonus", 100 * (1 - P["/local/area-codes/"]["us"]), "CALC", "1 minus the US share in data/ahrefs_prefixes_2026-10-12.csv")

    # Table 5 and Table 3 cells quoted in prose: the only released source is the CSV parsed from the table itself
    T5 = {r["Metric"]: r for r in csv.DictReader((B / "instrument_divergence_extra/instrument_series_table5_checkpoints.csv").open())}
    n = lambda s: float(re.sub(r"[^\d.]", "", s))
    D = {"15": "Day 15 (10 Aug)", "30": "Day 30 (25 Aug)", "37": "Day 37 (1 Sep)", "45": "Day 45 (9 Sep)", "60": "Day 60 (24 Sep)", "75": "Day 75 (9 Oct)", "77": "Day 77 (11 Oct)"}
    circ = "instrument_series_table5_checkpoints.csv (parsed from Table 5 itself)"
    cnote = "circular: the CSV is parsed from the paper's own table; the dashboard read is not archived"
    v("t5.pages77", n(T5["Pages holding a position"][D["77"]]), "CIRC", circ, cnote)
    for d, k in (("15", "p15"), ("30", "p30"), ("45", "p45"), ("60", "p60"), ("75", "p75")):
        v(f"t5.{k}", n(T5["Pages holding a position"][D[d]]), "CIRC", circ, cnote)
    v("t5.pos37", n(T5["Ranking positions, all"][D["37"]]), "CIRC", circ, cnote)
    v("t5.pos75", n(T5["Ranking positions, all"][D["75"]]), "CIRC", circ, cnote)
    v("t5.pos77", n(T5["Ranking positions, all"][D["77"]]), "CIRC", circ, cnote)
    v("t5.top37", n(T5["Positions 1–3"][D["37"]]), "CIRC", circ, cnote)
    v("t5.vis37", n(T5["Estimated visits (Ahrefs)"][D["37"]]), "CIRC", circ, cnote)
    v("t5.rd37", n(T5["Live referring domains"][D["37"]]), "CIRC", circ, cnote)
    v("t5.rd75", n(T5["Live referring domains"][D["75"]]), "CIRC", circ, cnote)
    v("t5.ai75", n(T5["AI answers citing the section"][D["75"]]), "CIRC", circ, cnote)
    v("t5.ai77", n(T5["AI answers citing the section"][D["77"]]), "CIRC", circ, cnote)
    T6 = list(csv.DictReader((B / "instrument_divergence_extra/instrument_series_table6_intervals.csv").open()))
    v("t6.r2", n(T6[1]["Rate"]), "CALC", "(14,905 - 3,385) / 15, from Table 5")
    v("t6.r3", n(T6[2]["Rate"]), "CALC", "(15,830 - 14,905) / 7, from Table 5")
    v("t6.r4", n(T6[3]["Rate"]), "CALC", "(20,326 - 15,830) / 8, from Table 5")
    v("n27472", 43302.0 - 15830.0, "CALC", "43,302 - 15,830")
    v("t3.n.jul", 284.0, "CIRC", "instrument_series_table3 CSV (parsed from Table 3 itself)", cnote)
    v("t3.n.oct", 37238.0, "CIRC", "instrument_series_table3 CSV (parsed from Table 3 itself)", cnote)
    v("t3.k.jul", 47.0, "CIRC", "instrument_series_table3 CSV (parsed from Table 3 itself)", cnote)
    v("t3.k.oct", 7455.0, "CIRC", "instrument_series_table3 CSV (parsed from Table 3 itself)", cnote)
    v("t2.days.jul", 6.0, "CALC", "26 to 31 July inclusive")
    v("d77", 77.0, "CALC", "26 July to 11 October 2026 by the calendar")
    v("d37", 37.0, "CALC", "26 July to 1 September 2026 by the calendar")

    # arithmetic and constants of a sentence
    v("urls434", 434.0, "CALC", "381 + 53")
    v("diff21", 21.0, "CALC", "455 - 434")
    v("diff7", 7.0, "CALC", "441 - 434")
    v("n11", 11.0, "CALC", "cross_sector_type_shares.csv: eleven sectors")
    v("cells88", 88.0, "CALC", "cross_sector_type_shares.csv: 88 rows")
    v("de88", 88.0, "CALC", "11 sectors x 8 surfaces")
    v("n200", 200.0, "RUN", "r2_link_check.py")
    v("n100", 100.0, "RUN", "r2_link_check.py")
    v("t50", 50.0, "FILE", "single_reads_2026-10.csv", "stated in the quantity's name")
    v("k1000", 1000.0, "SAVED", "analyze_reviews.py (saved output)", "the threshold named in the saved line")
    v("k100", 100.0, "SAVED", "cross_sector_sensitivity.py (saved output)", "row limit named in the saved line")
    v("k250", 250.0, "SAVED", "cross_sector_sensitivity.py (saved output)", "row limit named in the saved line")
    v("k500", 500.0, "SAVED", "cross_sector_sensitivity.py (saved output)", "row limit named in the saved line")
    v("k501", 501.0, "RUN", "section7_from_aggregates.py", "row range named in the printed line")
    v("k1000b", 1000.0, "RUN", "section7_from_aggregates.py", "row range named in the printed line")
    v("k15", 15000.0, "RUN", "wiki_demand_supplement.py", "band named in the printed line")
    v("k50", 50000.0, "RUN", "wiki_demand_supplement.py", "band named in the printed line")
    v("p2.lo", 0.40, "FILE", "wikipedia_demand_372.md (P2)", "fixed in the stamped plan")
    v("p2.hi", 0.80, "FILE", "wikipedia_demand_372.md (P2)", "fixed in the stamped plan")
    v("p3.09", 0.9, "FILE", "wikipedia_demand_372.md (P3)",
      "as the plan states it, 'at a comparable spread'; the paper drops that qualifier; at the observed spreads (16.69 and 1.50) the ratio's geometric SD cannot fall below 11.1, so P3 could not have failed at any correlation")
    v("power.five", 0.5, "RUN", "instrument_extra.py", "the alternative named in the printed line")
    v("p001", 7e-06, "RUN", "instrument_extra.py", "paper says p < 0.001; the script prints p=7e-06")
    v("p001b", 0.00056, "RUN", "m2_from_counts.py", "paper says p < 0.001; the script prints p=0.00056")
    v("sv.kws.m", 1.898584, "SAVED", "supplement_r10.py (saved output)", "1,898,584")
    v("de.25", 25.0, "FILE", "cross_sector_ai_citation_study.md (A3)")
    # earlier wrong values the paper quotes in order to withdraw them
    CL = (B / "CHANGELOG_versions.md").read_text()
    assert "+0.19" in CL and "+0.29" in CL and ("-0.09" in CL or "−0.09" in CL)
    v("old.m009", -0.09, "FILE", "CHANGELOG_versions.md", "a withdrawn value, quoted as such")
    v("old.019", 0.19, "FILE", "CHANGELOG_versions.md", "a withdrawn value, quoted as such")
    v("old.029", 0.29, "FILE", "CHANGELOG_versions.md", "a withdrawn value, quoted as such")
    v("sv.old78", 0.777, "SAVED", "analyze_reviews.py (saved output)", "the superseded computation, still printed by that script")

    # no source in the bundle
    none = "no source in the bundle"
    v("hubs52", None, "NONE", "none", "the author's statement; the hub list is not released and the pages were not re-fetched")
    v("hubs53", None, "NONE", "none", "the author's statement; the hub list is not released and the pages were not re-fetched")
    SRr = {r["quantity"]: r["value"] for r in csv.DictReader((B / "instrument_divergence_extra/single_reads_2026-10.csv").open())}
    a, b_ = re.match(r"(\d+) and (\d+)", SRr["Domain Ratings of the two national carriers co-cited with the section"]).groups()
    v("dr.87", float(a), "FILE", "single_reads_2026-10.csv", "dashboard read, not archived")
    v("dr.91", float(b_), "FILE", "single_reads_2026-10.csv", "dashboard read, not archived")
    k13 = next(k for k in SRr if k.startswith("Domain Rating of the five domains"))
    a, b_ = re.match(r"(\d+) to (\d+)", SRr[k13]).groups()
    v("dr.13", float(a), "FILE", "single_reads_2026-10.csv", "dashboard read, not archived")
    v("dr.83", float(b_), "FILE", "single_reads_2026-10.csv", "dashboard read, not archived")
    k40 = next(k for k in SRr if k.startswith("reported monthly searches of the lowest-traffic rows"))
    a, b_ = re.match(r"(\d+) to (\d+)", SRr[k40]).groups()
    v("low40", float(a), "FILE", "single_reads_2026-10.csv", "dashboard read, not archived")
    v("low170", float(b_), "FILE", "single_reads_2026-10.csv", "dashboard read, not archived")

    # stamps: block data from the public block explorer, proof paths read offline
    first = min(blocks, key=lambda h: h if h >= 973000 else 10 ** 9)
    t = lambda h, f="%H:%M": __import__("datetime").datetime.fromtimestamp(blocks[h]["timestamp"], __import__("datetime").UTC).strftime(f)
    v("bk.first", float(first), "BLOCK", "wikipedia_demand_372_manifest.txt.ots, read here; blockstream.info block data",
      "973,943 is a valid attestation but not the first: the proof holds three, 973,934 (05:44:22 UTC), 973,943 (06:51:59 UTC) and 973,953 (08:19:43 UTC); each computed digest equals that block's merkle root")
    v("bk.first.t", t(first), "BLOCK", "blockstream.info, block 973,934",
      "the paper's 06:51 is block 973,943's time; the stamp first reached a block at 05:44:22 UTC, 24 minutes after the read ended (05:19:45)")
    v("bk.twoh", 2.0, "BLOCK", "05:10 stamp to 05:44:22 first block (34 minutes); 06:51:59 for the block the paper names",
      "still true of either block, but loose: 34 minutes from the stamp to the first block")
    v("bk.t971506", t(971506), "BLOCK", "blockstream.info, block 971,506 (04:05:42 UTC)", "merkle root equal to the proof's digest")
    v("bk.t971522", t(971522), "BLOCK", "blockstream.info, block 971,522 (06:10:20 UTC)", "merkle root equal to the proof's digest")
    log = TXT["wlog"]
    v("t.0511", re.search(r"(\d\d:\d\d):\d\d UTC  start", log).group(1), "FILE", "collection_log.txt")
    v("t.0519", re.search(r"(\d\d:\d\d):\d\d UTC  done", log).group(1), "FILE", "collection_log.txt")
    v("t.0510", re.search(r"Written 2026-10-31 (\d\d:\d\d) UTC", (B / "wikipedia_demand/wikipedia_demand_372_manifest.txt").read_text()).group(1), "FILE", "wikipedia_demand_372_manifest.txt")

    # second pass
    cells = list(csv.DictReader((B / "ai_citation_cross_sector/aggregates/cross_sector_cells.csv").open()))
    assert {r["export_rows"] for r in cells} == {"1000"}
    v("exp1000", 1000.0, "CALC", "cross_sector_cells.csv: export_rows is 1000 in all 88 cells")
    v("p_below", 3.4e-09, "RUN", "m2_from_counts.py: p=3.4e-09 (+0.185), p=0 and p=2.2e-07 (own volumes); paper says below 0.001")
    NOUFI = "needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here)"
    for nm, val in (("ufi.924", 924.0), ("ufi.66", 66.0), ("ufi.dg1", None), ("ufi.dg2", None), ("ufi.c1", None), ("ufi.c2", None), ("ufi.a", 0.5), ("ufi.b", 0.5), ("ufi.d", 0.85),
                    ("ufi.22", 22.0), ("ufi.21", 21.0), ("ufi.022", 0.22), ("ufi.30", 30.0), ("ufi.08", 0.8), ("ufi.4", 4.0), ("ufi.5", 5.0), ("ufi.704", 70.4),
                    ("ufi.13", 13.0), ("ufi.4s", 4.0), ("ufi.2q", 2.0), ("ufi.4q", 4.0)):
        v(nm, None, "NONE", "ufi repository (not in the bundle)", NOUFI)
    v("de.10000", 10000.0, "FILE", "cross_sector_ai_citation_study.md (A1)")
    v("de.10000b", None, "NONE", "none", "the stopped prompt-level exports are not in the bundle")
    v("t2.days78", 78.0, "CALC", "6 + 31 + 30 + 11")
    m_ = re.search(r"\((\d+) duplicates dropped\); (\d+) name", TXT["vendor"])
    v("st.459", float(m_[1]) + float(m_[2]), "RUN", "vendor_reliance.py --offline: 456 + 3 duplicates", "a withdrawn value, quoted as such")
    v("cal.24", 24.0, "CALC", "26 July + 60 days by the calendar")
    v("day60", 60.0, "CALC", "26 July + 60 days = 24 September")
    v("cal.29", 29.0, "CALC", "26 July + 65 days by the calendar")
    v("day65", 65.0, "CALC", "26 July + 65 days = 29 September")
    pi = re.search(r"12 Oct (\d\d:\d\d)-(\d\d:\d\d)", TXT["pilot"])
    v("pi.t1", pi[1], "SAVED", "project copy of cross_sector_sensitivity.py (saved output)")
    v("pi.t2", pi[2], "SAVED", "project copy of cross_sector_sensitivity.py (saved output)")
    v("terr6", 6.0, "FILE", "wikipedia_demand_372.md ('excluding the six territory codes')")
    v("npa451", None, "NONE", "none", "the numbering plan registry extract (npa_report.csv) is not in the bundle")
    v("n8", 8.0, "CALC", "cross_sector_type_shares.csv: eight surfaces")
    v("n7cp", 7.0, "CALC", "Table 5: columns after day 0")
    v("n2cross", 2.0, "CALC", "/product-compare/ and /device-compare/ cross one when matched")
    v("nine10", 9.0, "RUN", "r2_link_check.py: 90.5% and 89.2% in store", "nine in ten")
    v("one", 1.0, "CALC", "924 of 6,620 is 1 in 7.2")
    v("one_in_7", 7.0, "CALC", "924 of 6,620 is 1 in 7.2")
    v("n4", 4.0, "FILE", "cross_sector_ai_citation_study.md and wikipedia_demand_372.md: P1 to P4 in each")
    src = (B / "ai_citation_cross_sector/scripts/cross_sector.py").read_text()
    v("n17", 17.0, "CALC", "the video, forum, social and user_publishing sets in cross_sector.py, with x.com and twitter.com as one platform", "")
    v("n4runs", 4.0, "CALC", "four reproduction folders in 08_REVIEW")
    v("n4q", 4.0, "CALC", "Table 5: rows with a value in the day-37 column")
    v("n9q", 9.0, "CALC", "Table 5: nine rows")
    v("t6.r2x", 226.0, "CALC", "(3,385 - 2) / 15, from Table 5")
    v("t6.r5", 1121.0, "CALC", "(37,141 - 20,326) / 15, from Table 5")
    v("t6.r6", 411.0, "CALC", "(43,302 - 37,141) / 15, from Table 5")
    v("t5.rd45", n(T5["Live referring domains"][D["45"]]), "CIRC", circ, cnote)
    v("t5.rd60", n(T5["Live referring domains"][D["60"]]), "CIRC", circ, cnote)

