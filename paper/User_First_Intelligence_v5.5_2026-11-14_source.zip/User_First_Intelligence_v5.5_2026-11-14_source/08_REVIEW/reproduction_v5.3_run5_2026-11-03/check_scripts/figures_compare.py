#!/usr/bin/env python3
"""Compare every regenerated figure with the one shipped at the bundle's top level: PNG byte for byte and pixel for pixel;
PDF byte for byte, then with the /CreationDate and /ID removed, and rendered at 150 dpi pixel for pixel."""
import hashlib, re, subprocess, sys, tempfile
from pathlib import Path
from PIL import Image, ImageChops
R = Path(sys.argv[1]); N = "User_First_Intelligence_v5.3_2026-11-03_source"; P = R / "pristine" / N
MAP = {"fig0_framework": ("make_fig0", "."), "fig1_divergence": ("make_figs_v4", "."), "fig2_aio": ("make_figs_v4", "."), "fig3_refdomains": ("make_figs_v4", "."),
       "fig4_prefixes": ("make_figs_v4", "."), "fig5_cited": ("make_figs_v4", "."), "fig6_positions": ("make_figs_v4", "."),
       "fig10_sources": ("make_fig_sources", "ai_citation_cross_sector/scripts"), "fig11_wikipedia": ("make_fig_wikipedia", "wikipedia_demand")}
def render(pdf, out):
    subprocess.run(["pdftoppm", "-r", "150", "-png", "-singlefile", str(pdf), str(out)], check=True)
    return Image.open(str(out) + ".png").convert("RGB")
def strip(b):
    b = re.sub(rb"/CreationDate \([^)]*\)", b"", b)
    b = re.sub(rb"/ModDate \([^)]*\)", b"", b)
    return b
for fig, (tag, folder) in MAP.items():
    new = R / "runs" / tag / N / folder
    pngA, pngB = (P / f"{fig}.png"), (new / f"{fig}.png")
    pdfA, pdfB = (P / f"{fig}.pdf"), (new / f"{fig}.pdf")
    png_same = pngA.read_bytes() == pngB.read_bytes()
    px = ImageChops.difference(Image.open(pngA).convert("RGB"), Image.open(pngB).convert("RGB")).getbbox() if Image.open(pngA).size == Image.open(pngB).size else "size differs"
    pdf_same = pdfA.read_bytes() == pdfB.read_bytes()
    pdf_same2 = strip(pdfA.read_bytes()) == strip(pdfB.read_bytes())
    with tempfile.TemporaryDirectory() as t:
        a = render(pdfA, Path(t) / "a"); b = render(pdfB, Path(t) / "b")
        rpx = ImageChops.difference(a, b).getbbox() if a.size == b.size else "size differs"
    print(f"{fig:18} script {tag:20} PNG bytes {'same' if png_same else 'DIFF'}; PNG pixels {'same' if px is None else 'DIFF ' + str(px)}; PDF bytes {'same' if pdf_same else 'differ'}; PDF without dates {'same' if pdf_same2 else 'DIFF'}; PDF rendered {'same' if rpx is None else 'DIFF ' + str(rpx)}")
# figure 6 cannot be redrawn; the shipped file's printed labels
print("fig9_reviews: make_fig_reviews_v50.py cannot run (needs out/label_demand_aggregates.csv and out/branch_shares_corrected.csv from the licensed export)")
