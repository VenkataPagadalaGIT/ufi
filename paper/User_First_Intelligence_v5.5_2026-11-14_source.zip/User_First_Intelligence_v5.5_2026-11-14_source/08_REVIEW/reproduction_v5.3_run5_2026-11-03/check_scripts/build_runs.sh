#!/bin/bash
R=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run5
RUN="python3 $R/check_scripts/run_one.py"
N=User_First_Intelligence_v5.3_2026-11-03_source
B=$R/pristine/$N
$RUN build_tex . - -- python3 build_tex.py 2>&1 | cut -c1-500
cut -c1-300 "$R/outputs/build_tex.stdout"; tail -3 "$R/outputs/build_tex.stderr" | cut -c1-300
ls "$R/runs/build_tex/$N/build" | head -30
cmp "$R/runs/build_tex/$N/build/paper.tex" "$B/paper.tex" && echo "paper.tex IDENTICAL"
$RUN build_docx . - -- /bin/zsh build_docx.sh 2>&1 | cut -c1-400
cut -c1-200 "$R/outputs/build_docx.stdout"; tail -3 "$R/outputs/build_docx.stderr" | cut -c1-200
ls -la "$R/runs/build_docx/$N/build" | head
RUN_TIMEOUT=500 $RUN tectonic_compile . - -- /bin/zsh -c 'tectonic --keep-logs --chatter minimal paper.tex' 2>&1 | cut -c1-400
tail -5 "$R/outputs/tectonic_compile.stderr" | cut -c1-300; tail -5 "$R/outputs/tectonic_compile.stdout" | cut -c1-300
ls -la "$R/runs/tectonic_compile/$N/paper.pdf" 2>/dev/null
