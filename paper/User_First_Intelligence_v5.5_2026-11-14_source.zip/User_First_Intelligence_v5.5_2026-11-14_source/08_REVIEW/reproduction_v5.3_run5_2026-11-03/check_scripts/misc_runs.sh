#!/bin/bash
R=/private/tmp/claude-501/-Users-venkatapagadala-Desktop-Research-Papers-Paper-03-user-first-intelligence/7064c615-0af8-4198-b24b-f143956075d5/scratchpad/repro_run5
RUN="python3 $R/check_scripts/run_one.py"
N=User_First_Intelligence_v5.3_2026-11-03_source
B=$R/pristine/$N
cd "$R"
echo "--- README order for Study W in one tree"
$RUN wiki_readme_sequence wikipedia_demand - -- /bin/bash -c 'python3 wiki_demand_analysis.py && python3 make_fig_wikipedia.py' | cut -c1-260
cmp "runs/wiki_readme_sequence/$N/wikipedia_demand/fig11_wikipedia.png" "$B/fig11_wikipedia.png" && echo "figure after analysis: PNG byte-identical to shipped"
echo "--- determinism: every hash-seed rerun against the first run"
for t in analyze instrument_extra m2_from_counts r2_link_check vendor_reliance_offline stakes_screen_check wiki_demand_analysis wiki_demand_supplement section7_from_aggregates make_tables_sector_surface; do
  for s in 1 987654; do cmp -s "outputs/$t.stdout" "outputs/${t}__hs$s.stdout" && echo "same   $t hs=$s" || echo "DIFFER $t hs=$s"; done
done
echo "--- as-stamped script against current: sections 1 to 6"
diff <(sed -n '/^== 1\./,/^== 7\./p' outputs/instrument_extra.stdout | sed '$d') outputs/instrument_extra_as_stamped.stdout | cut -c1-200 && echo "sections 1 to 6: identical"
for f in instrument_series_table2_visits_by_month instrument_series_table3_ai_overview_citation_by_month instrument_series_table5_checkpoints instrument_series_table6_intervals; do
  cmp "runs/instrument_extra_as_stamped/$N/protocols/$f.csv" "$B/instrument_divergence_extra/$f.csv" && echo "as-stamped wrote $f.csv identical to shipped"
done
echo "--- PDF differences between recompile and shipped"
python3 - "$R/runs/tectonic_compile/$N/paper.pdf" "$R/User_First_Intelligence_v5.3_2026-11-03.pdf" <<'PY'
import sys,re
a,b=open(sys.argv[1],'rb').read(),open(sys.argv[2],'rb').read()
print('lengths',len(a),len(b))
d=[i for i,(x,y) in enumerate(zip(a,b)) if x!=y]
print('differing bytes',len(d),'first offsets',d[:3],'last',d[-3:])
for i in sorted({x//80 for x in d}):
    print(i*80, a[i*80:i*80+80])
PY
echo "--- v5.2 run 4 outputs shipped in the bundle against today's reruns"
ls "$B/08_REVIEW/reproduction_v5.2_run4_2026-10-15/outputs" | head -100
