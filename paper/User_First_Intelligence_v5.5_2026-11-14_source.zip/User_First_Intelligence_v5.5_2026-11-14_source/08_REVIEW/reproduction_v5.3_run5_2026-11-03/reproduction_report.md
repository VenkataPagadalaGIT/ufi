# Independent reproduction, run 5: User First Intelligence, manuscript v5.3 source bundle

Reproducer: an AI agent (Claude Code), working from the released bundle and the PDF the caller named, in a fresh folder in the session scratchpad, on 3 November 2026. Nothing was copied from the author's working project. No file of the paper, the bundle or the project was edited; the only addition to the project is this folder.

## Results at a glance

- **Scripts:** of the bundle's 29 paper scripts, not counting 35 edit scripts, 19 ran as documented, 1 failed as its README predicts (`protocols/reread_compare.py`), 9 cannot run (8 need withheld data or a live service, and `wiki_collect.py` was excluded by instruction). The tectonic build also ran.
- **Output files:** every shipped output with a rerun counterpart is byte-identical except `wiki_demand_analysis_output.txt` and `wiki_demand_headline.json`, which differ in the one line and one key the README discloses. Every regenerated PNG is byte-identical; the PDFs differ only in `/CreationDate`. Every script that prints numbers was rerun under two fixed hash seeds with identical stdout.
- **Numbers:** **1,781 values checked: 1,628 MATCH, 2 MISMATCH, 151 CANNOT RUN.** Those are 1,002 numbers in prose, 693 table cells, 45 labels inside figures and 41 statements in words that an output decides.
- **What the matches rest on:** 983 on a script rerun here, 276 on the reproducer's own recomputation from released files, 3 on public block data, 220 on a released data file that records a dashboard read or a plan, and **146 that cannot fail**: series CSVs parsed from the paper's own tables, as Section 14 discloses.
- **Build:** `build_tex.py` regenerates `paper.tex` byte for byte, and it compiles to the shipped PDF's exact text. So checks made on `manuscript_v50.md` hold for the PDF; every value was also located on a page of the shipped PDF.

## Problems found, most important first

**1. The Study W stamp first reached a Bitcoin block earlier than the paper says (the two mismatches).**

| Location | Paper says | Obtained | Script or source | Why |
|---|---|---|---|---|
| §6.2, PDF p. 15 | 973,943 | 973,934 | wikipedia_demand_372_manifest.txt.ots, read here; blockstream.info block data | 973,943 is a valid attestation but not the first: the proof holds three, 973,934 (05:44:22 UTC), 973,943 (06:51:59 UTC) and 973,953 (08:19:43 UTC); each computed digest equals that block's merkle root |
| §6.2, PDF p. 15 | 06:51 | 05:44 | blockstream.info, block 973,934 | the paper's 06:51 is block 973,943's time; the stamp first reached a block at 05:44:22 UTC, 24 minutes after the read ended (05:19:45) |

The paper's sentence (Section 6.2, PDF p. 15): "before the stamp reached a Bitcoin block (block 973,943, mined at 06:51 UTC): the proof dates the plan to within two hours of the read". The shipped proof `wikipedia_demand/wikipedia_demand_372_manifest.txt.ots` commits to the manifest's SHA-256 and holds **three** Bitcoin attestations, on separate branches of the proof. Executing the proof's operations and comparing with block data from a public explorer, each path's digest equals that block's merkle root:

| Block | Mined (UTC, 31 October 2026) | Merkle root (proof = block) |
|---|---|---|
| **973,934** | **05:44:22** | 787c370594040933515ca884d9b1ec72a2069c969103d9a38adde980df61e37e |
| 973,943 (the one the paper names) | 06:51:59 | 966975ca852fb540aa9172dfbe277cd09e0406134f32c0ee76e7b5a3e70fb771 |
| 973,953 | 08:19:43 | 7e9523b5b7ba3f7f9512ce74082e461f0ef2407b34e7dbd4244afe2b35320de1 |

Block 973,943 is a genuine attestation, so the paper's figure is not invented, but it is not when the stamp reached a block. The first anchor is 34 minutes after the stated 05:10 stamp and 24 minutes 37 seconds after the collection ended (05:19:45 in `collection_log.txt`). The error runs against the paper's own interest: the ordering it discloses still holds (the read finished before any block, so the proof alone does not order plan and read), while "within two hours" is true but much looser than the proof shows. The same figures are in `wikipedia_demand/README.md` line 6 and `CHANGELOG_versions.md` line 72, and came from `edit_v53e.py`. Which block `ots verify` would report could not be run here: no OpenTimestamps client is installed.

**2. One quoted value of Study W cannot come from the release, and the shipped output holds a line the release cannot print.** The "+0.41" for the Content Gap Score (Section 6.2, PDF p. 16) needs the per-code scores in the withheld `r1_predictors.csv`. The shipped `wiki_demand_analysis_output.txt` and `wiki_demand_headline.json` carry the project run's +0.413; a release run prints "not available", as the README says, and overwrites both files. Section 6.2's closing "the analysis reruns from them" holds for everything else.

**3. 151 values rest on inputs the bundle does not contain.** 105 of them agree with a saved output shipped beside the script, which shows the paper quotes that output correctly and not that the output is right.

| Missing input | Values |
|---|---|
| Licensed review export (`Telecom_reviews_and_responses.xlsx`, `Telecom_classification.xlsx`, `Telecom_keywords_full.csv.gz`) | 53 |
| Raw Brand Radar exports (`03_DATA/raw/brand_radar_*`), the sensitivities that need row-level data, and the pilot | 51 |
| `ufi` repository (not in the bundle): digests, 924 queries, 66 codes, 4/5, 70.4%, thirteen surface types, commit counts | 36 |
| `r1_predictors.csv` per-code scores (held back with Study R1): the +0.41 | 1 |
| Other statements with no source in the bundle (Table 7's cost figures, the 52 and 53 hub counts, code 451 in the registry, the stopped prompt-level exports) | 10 |

Where the anonymized counts allowed it, values the paper attributes to withheld data were recomputed and match: +0.28 over 213 labels, Kendall +0.13, and 106 labels at zero volume, all from `m2_label_counts.csv`.

**4. 146 matches cannot fail, and 220 confirm only a transcription.** `instrument_extra.py` writes the Table 2, 3, 5 and 6 CSVs by parsing the manuscript, so those raw cells agree by construction. Dashboard reads in `single_reads_2026-10.csv` and the twelve-prefix files are matched against a file the same author's agents wrote; none of this can catch a misread dashboard, and Section 14 says so. The derived cells (ratios, Wilson intervals, the 21 to 100 row, all of Table 6) were recomputed here and do test something.

**5. P3's "lax bar" is stated without the plan's qualifier (no number differs).** Section 6.2 says the bar "fails only if log requests track log volume at a Pearson correlation above about 0.9". The plan says that holds "at a comparable spread". At the spreads actually observed, geometric SDs of 16.69 and 1.50, the ratio's geometric SD cannot fall below 11.1 at any correlation (recomputed; the observed log-log Pearson is +0.41), so P3 could not have failed. Counted as a MATCH on the 0.9, with this note.

**6. Stale pointers, not numbers.**
- `single_reads_2026-10.csv`, column "where in the paper": 4 rows say "Figure 9 caption" and 8 say "Figure 8". Since v5.3's renumbering those figures are Figure 10 and Figure 9.
- Appendix E.3 places the search record at `01_LITERATURE/checklist_search_2026-10-31/` "in the source bundle"; the bundle has `literature/checklist_search_2026-10-31/`. Section 6.2 cites `02_DESIGN/wikipedia_demand_372.md`; the bundle has `wikipedia_demand/wikipedia_demand_372.md`.
- `CHANGELOG_versions.md` line 71 names edit scripts up to `edit_v53f.py`; the bundle stops at `edit_v53e.py`, while its README says the edit scripts record every change. Every sentence of Sections 6.2, E.1 and E.2 was found in `edit_v5*.py`, so no unrecorded text was observed, but what `edit_v53f.py` did cannot be told from here.
- `wikipedia_demand/README.md` lists `stamp_manifest.sh`, and the plan names `smoke_test.py` "kept beside it" and a review record in `08_REVIEW/`. None is in the bundle.

**7. Two scripts overwrite shipped files when run.** `wiki_demand_analysis.py` overwrites its shipped outputs (item 2). `stakes_screen_sample.py` truncates `stakes_screen_ids.csv` before its first fetch, so a failed run leaves the released id list damaged; observed in a disposable copy.

## Limits of this reproduction

- **One network decision to check.** The caller barred requests to a vendor. Ten HTTPS requests went to `blockstream.info` for the five block heights' headers (`outputs/blocks/`). That is a public block explorer and not a vendor of this study, and no project data was sent. If you read the instruction more widely, the 5 values on that basis become CANNOT RUN, and problem 1 would rest on block heights alone (973,934 is below 973,943 whatever the times). Every script ran with the network denied by the sandbox.
- **Not checked:** other studies' figures quoted in Section 2 and elsewhere; times with no released source (the 23:05 to 01:15 collection session of Section 7.2); dates; the `ufi` repository, which is public but outside the bundle. The vendor side of Study W (`dem`, `K`) was taken as released: the raw-to-table chain was recomputed for the public side only, because the frozen vendor table is withheld. Its hash in the two manifests and the collection log agree.
- **The `ufi` package is installed on this machine** (0.2.0, user site-packages) but is not in the bundle. Three review scripts import it and then stop on the missing export; no result here used it.
- **The checker itself:** six end-to-end mutation tests altered 615 quoted values in memory across the manuscript; all 615 were caught (`outputs/_mutation_final.log`). An early run missed some, which exposed a table check comparing cells with themselves and patterns falling through to an exclusion; both were fixed before the counts above. Rules that map a value to its source were written by this agent and could still map a value to a wrong but equal source.
- **The project moved during this run, and this report does not cover the move.** The working tree was clean at the start and shows the changes below at the end. This run did not make them: its writes were limited to the scratchpad and this folder. They include a modified `06_MANUSCRIPT/src/manuscript_v50.md` and `03_DATA/single_reads_2026-10.csv` and an untracked `06_MANUSCRIPT/src/edit_v53f.py`, none of which was read. Everything here applies to the zip and PDF as hashed in section 1, whose hashes were unchanged at the end, so some problems above may already be in hand in the working copy:

```
M 01_LITERATURE/checklist_search_2026-10-31/search_record.md
 M 03_DATA/single_reads_2026-10.csv
 M 04_ANALYSIS/wikipedia_demand/README.md
 M 06_MANUSCRIPT/CHANGELOG_versions.md
 M 06_MANUSCRIPT/UFI_Metrics_and_Evaluation_Protocol_v1.0.md
 M 06_MANUSCRIPT/arxiv_abstract.txt
 M 06_MANUSCRIPT/measurements/ledger.csv
 M 06_MANUSCRIPT/src/manuscript_v50.md
 M 06_MANUSCRIPT/src/package_v49.sh
 M 08_REVIEW/REVIEW_LOG.md
 M 09_SUBMISSION/author_tasks/README.md
 M 09_SUBMISSION/stage_release_v53.py
 M 09_SUBMISSION/ufi_release_v5.3/README.md
?? 01_LITERATURE/checklist_search_2026-10-31/raw/NOT_RELEASED.txt
?? 06_MANUSCRIPT/measurements/2026-11-03_bcf09851_145739.json
?? 06_MANUSCRIPT/measurements/2026-11-03_bcf09851_145739.md
?? 06_MANUSCRIPT/measurements/2026-11-03_bcf09851_145945.json
?? 06_MANUSCRIPT/measurements/2026-11-03_bcf09851_145945.md
?? 06_MANUSCRIPT/measurements/2026-11-03_bcf09851_150150.json
?? 06_MANUSCRIPT/measurements/2026-11-03_bcf09851_150150.md
?? 06_MANUSCRIPT/src/edit_v53f.py
?? 09_SUBMISSION/arxiv/
```

## 1. Environment and bundle

- Environment: macOS 15.4.1 (arm64); Python 3.13.2; numpy 2.4.1, scipy 1.17.1, pandas 3.0.0, matplotlib 3.11.1, openpyxl 3.1.5, pillow 12.1.1; tectonic 0.17.0; pandoc 3.9.0.2; pdftotext version 26.02.0; no XeLaTeX; no OpenTimestamps client (the proofs were read by `check_scripts/ots_check.py`, written for this run).
- Isolation: each script ran in its own new unpack of the zip, under `sandbox-exec` with all network and all writes to the Desktop denied (`check_scripts/run_one.py`).

- Bundle SHA-256: `6f3a5cfeddc34a07159aa71df983d81225acdcb1850d1560873d264ca1643cd9` (532 files; Python's `zipfile.testzip` clean; all 532 in the untouched unpack still identical to the zip after every run).
- PDF SHA-256: `bcf0985127a98da9c29e00fddb90a507bf0ed484d5433478d1aeaff7325d12d5` (39 pages).
- Manifests: all 7 digests in `protocols/protocols_manifest.txt` match the released files. 4 of the 5 in `wikipedia_demand_372_manifest.txt` match; the fifth is the withheld `r1_predictors.csv`. The Study R1 manifest's files are held back, as its README says. All four `.ots` proofs commit to the file beside them. Blocks 971,506 (merkle root 7bdc6025...59a3, 04:05:42 UTC) and 971,522 (06:10:20 UTC) are confirmed.
- Companion texts: every number in `arxiv_abstract.txt` appears in the paper. Of 28 Table D1 values tried, the companion protocol's text holds all but the 456.

## 2. Scripts

| Script | How run | Result | Against the shipped output |
|---|---|---|---|
| `data/analyze.py` | `cd data; python3 analyze.py` | RAN (exit 0, 0.3 s) | No output file ships beside it. Stdout identical to the v5.2 record in `08_REVIEW/.../run4/outputs/analyze_stdout.txt`. |
| `instrument_divergence_extra/instrument_extra.py` | `cd instrument_divergence_extra; python3 instrument_extra.py` | RAN (exit 0, 35.5 s) | Stdout byte-identical to `instrument_extra_output.txt`; the four series CSVs it rewrites are byte-identical. |
| `protocols/instrument_extra_as_stamped.py` | `cd protocols; python3 instrument_extra_as_stamped.py` | RAN (exit 0, 0.9 s) | No shipped output. Sections 1 to 6 identical to the current script's; its four CSVs byte-identical to the shipped ones. |
| `protocols/reread_compare.py` | `cd protocols; python3 reread_compare.py` | FAILED (exit 1, 0.1 s) | FileNotFoundError on `03_DATA/instrument_divergence_ahrefs_prefixes_2026-10-12.csv`. The README says it reads the project's folders and to use the wrapper; expected. |
| `protocols/reread_compare_anywhere.py` | `cd protocols; python3 reread_compare_anywhere.py` | RAN (exit 0, 0.1 s) | Hash of the stamped script matches the manifest; prints "the sheet has no values yet", as it should for an empty sheet. |
| `review_demand/m2_from_counts.py` | `cd review_demand; python3 m2_from_counts.py` | RAN (exit 0, 36.9 s) | Stdout byte-identical to `m2_from_counts_output.txt`. 34 of its 35 lines also appear verbatim in the saved `supplement_r10_output.txt`. |
| `review_demand/r2_link_check.py` | `cd review_demand; python3 r2_link_check.py` | RAN (exit 0, 0.2 s) | Stdout byte-identical to `r2_link_check_output.txt`. |
| `review_demand/analyze_reviews.py` | `cd review_demand; python3 analyze_reviews.py` | CANNOT RUN (exit 1, 1.4 s) | Missing `Telecom_reviews_and_responses.xlsx`, `Telecom_classification.xlsx` (licensed, withheld as the paper says). Saved output compared with the paper only. |
| `review_demand/r2_link_sample.py` | `cd review_demand; python3 r2_link_sample.py` | CANNOT RUN (exit 1, 0.5 s) | Missing the same licensed export. |
| `review_demand/supplement_r10.py` | `cd review_demand; python3 supplement_r10.py` | CANNOT RUN (exit 1, 1.2 s) | Missing the same licensed export (and `Telecom_keywords_full.csv.gz`). |
| `review_demand/make_fig_reviews_v50.py` | `cd review_demand; python3 make_fig_reviews_v50.py` | CANNOT RUN (exit 1, 0.7 s) | Missing `out/label_demand_aggregates.csv`, written from the licensed export. Figure 6 cannot be redrawn; its printed labels were read. |
| `stakes/vendor_reliance.py` | `cd stakes; python3 vendor_reliance.py --offline` | RAN (exit 0, 0.1 s) | Stdout byte-identical to `vendor_reliance_output.txt`. The online mode was not run. |
| `stakes/stakes_screen_check.py` | `cd stakes; python3 stakes_screen_check.py` | RAN (exit 0, 0.1 s) | Stdout byte-identical to `stakes_screen_check_output.txt`. |
| `stakes/stakes_screen_sample.py` | `cd stakes; python3 stakes_screen_sample.py` (no network) | CANNOT RUN (exit 1, 0.2 s) | Needs live OpenAlex for the abstracts. Its selection lines rerun offline give the same 120 ids in the same order as `stakes_screen_ids.csv`. |
| `wikipedia_demand/wiki_collect.py` | not run, by instruction | CANNOT RUN | Live APIs excluded by the caller. Its outputs were checked instead: raw responses to monthly file to per-article table, no difference; 1,497 lines of responses. |
| `wikipedia_demand/wiki_demand_analysis.py` | `cd wikipedia_demand; python3 wiki_demand_analysis.py` | RAN (exit 0, 21.9 s) | **Differs from the shipped files in one printed line and one JSON key**: the release run prints "score correlation: not available" where the shipped output holds the project run's +0.413; `wiki_demand_headline.json` lacks the `cgs` block. All else byte-identical. README discloses this. The run overwrites both shipped files. |
| `wikipedia_demand/wiki_demand_supplement.py` | `cd wikipedia_demand; python3 wiki_demand_supplement.py` | RAN (exit 0, 0.9 s) | Stdout byte-identical to `wiki_demand_supplement_output.txt`. |
| `wikipedia_demand/make_fig_wikipedia.py` | `cd wikipedia_demand; python3 make_fig_wikipedia.py` | RAN (exit 0, 1.1 s) | PNG byte-identical to the shipped `fig11_wikipedia.png`, also when run after the analysis in one tree; PDF differs only in `/CreationDate`. |
| `ai_citation_cross_sector/scripts/section7_from_aggregates.py` | `cd .../scripts; python3 section7_from_aggregates.py` | RAN (exit 0, 76.1 s) | Stdout byte-identical to `section7_from_aggregates_output.txt`. |
| `ai_citation_cross_sector/scripts/cross_sector.py` | `cd .../scripts; python3 cross_sector.py` | CANNOT RUN (exit 1, 0.1 s) | Stops with its message: raw Brand Radar exports are withheld. Saved output compared with the paper only. |
| `ai_citation_cross_sector/scripts/cross_sector_sensitivity.py` | `cd .../scripts; python3 cross_sector_sensitivity.py` | CANNOT RUN (exit 1, 0.1 s) | Same. |
| `ai_citation_cross_sector/scripts/cross_sector_sensitivity2.py` | `cd .../scripts; python3 cross_sector_sensitivity2.py` | CANNOT RUN (exit 1, 0.1 s) | Prints the variance block it can compute (a prefix of its saved output, byte for byte), then stops: raw exports withheld. |
| `ai_citation_cross_sector/scripts/make_tables_sector_surface.py` | `cd .../scripts; python3 make_tables_sector_surface.py` | RAN (exit 0, 0.1 s) | Stdout byte-identical to `make_tables_sector_surface_output.txt`. |
| `ai_citation_cross_sector/scripts/make_fig_sources.py` | `cd .../scripts; python3 make_fig_sources.py` | RAN (exit 0, 1.3 s) | PNG byte-identical to the shipped `fig10_sources.png`; PDF differs only in `/CreationDate`. |
| `ai_citation_cross_sector/scripts/make_brand_radar_urls.py` | `cd .../scripts; python3 make_brand_radar_urls.py` | RAN (exit 0, 0.1 s) | Rewrites `cross_sector_report_urls.json` byte-identically. It builds addresses and requests nothing. |
| `make_figs_v4.py` | `python3 make_figs_v4.py` | RAN (exit 0, 2.1 s) | Six PNGs byte-identical to the shipped ones; six PDFs differ only in `/CreationDate`. |
| `make_fig0.py` | `python3 make_fig0.py` | RAN (exit 0, 0.9 s) | PNG byte-identical; PDF differs only in `/CreationDate`. |
| `build_tex.py` | `python3 build_tex.py` | RAN (exit 0, 3.0 s) | `build/paper.tex` byte-identical to the shipped `paper.tex`. |
| `build_docx.sh` | `zsh build_docx.sh` | RAN (exit 0, 0.6 s) | Writes `build/paper.docx`. No DOCX ships in the bundle to compare with. |
| `tectonic paper.tex` (the README's build; not a script) | `tectonic --keep-logs --chatter minimal paper.tex` | RAN (exit 0) | 39 pages. The PDF differs from the shipped one in 60 of 739,326 bytes (creation date and file ID); `pdftotext -layout` output byte-identical. |
| `edit_v49*.py`, `edit_v5*.py` (35 scripts) | each once, in a disposable copy | RAN as documented: all 35 stop without writing | 5 stop on the missing `manuscript_v49.md`, 30 print REFUSE. The README says each refuses to run twice. |
| `08_REVIEW/**/*.py` (37 scripts) | attempted with no arguments, offline | not applicable | Earlier reproducers' private checks with no documented command: 3 ran, 34 stop asking for their own arguments (`outputs/_08_review_scripts.tsv`). No number in the paper rests on them. |

Data chain of Study W, recomputed separately: all 1,249 pageview responses have status 200; `pageviews_monthly.csv` equals `pageviews.jsonl`; every window of every article in `wiki_groups.csv` equals the sum over `pageviews_monthly.csv`; `dem` and `K` equal the sums over `wiki_codes.csv`; resolution, redirect and pageview responses count 8 + 240 + 1,249 = 1,497, the paper's request count.

Version 5.3 "changes no earlier result" (Appendix A): today's stdout is identical to the v5.2 reproduction's shipped record for `analyze`, `m2_from_counts`, `r2_link_check`, `vendor_reliance`, `stakes_screen_check`, `section7_from_aggregates` and `make_tables_sector_surface`; `instrument_extra` differs only by 11 added lines (its section 10).

Rounding near a half unit (`outputs/_final_checks.log`): 99 of 120 is exactly 82.5%, printed and quoted as 82%; the interval end +0.74 is exactly 0.735. The others are valid roundings of the exact value: +0.25 from 0.24503, +0.28 from 0.28498, +0.31 from 0.31498.

## 3. Quoted numbers

Each value's precision is the paper's: a MATCH means the obtained value rounds to it. Basis, in the table and in `numbers_table.csv`: RUN (a script rerun here), CALC (recomputed here), FILE (a released data file), CIRC (a CSV parsed from the paper's own table), SAVED (only in the saved output of a script that cannot run), BLOCK (public block data), NONE (no source).

**Coverage.** Every numeric token in the text outside the reference list and the cell-checked tables is either checked or excluded for a stated reason; none is left over. The excluded tokens are listed one by one in `excluded_tokens.tsv`.

| Token class | Count |
|---|---|
| checked | 881 |
| excluded: cross-reference label | 412 |
| excluded: date or time label | 318 |
| excluded: another study's published figure | 50 |
| excluded: rank label, position band or range name | 35 |
| excluded: name, not a value | 28 |
| excluded: formula or parameter | 13 |
| excluded: version label | 9 |
| excluded: code or page name | 8 |
| excluded: another study's published figure (vendor documentation, Bek 2026) | 4 |
| excluded: another study's published figure (Section 2's vendor reports) | 2 |
| excluded: implementation rubric, not a result | 2 |
| excluded: withdrawn figure quoted as such | 2 |

**The full table** (1,781 rows; also `numbers_table.csv`):

| # | Location | Quoted | Context | Script or source | Obtained | Basis | Status | Reason |
|---|---|---|---|---|---|---|---|---|
| 1 | Abstract, p. 1 | 381 | ge US telecommunications provider's website (381 code pages and 53 hubs), obse | section_code_pages_2026-10-14.csv | 381 | FILE | MATCH |  |
| 2 | Abstract, p. 1 | 53 | tions provider's website (381 code pages and 53 hubs), observed from zero, tw | none | None | NONE | CANNOT RUN | the author's statement; the hub list is not released and the pages were not re-fetched |
| 3 | Abstract, p. 1 | 7.5 | orms differed on estimated monthly visits by 7.5x to 27.1x, and by 8.6x to 29. | arithmetic on Table 2 / its released CSV | 7.469647 | CALC | MATCH |  |
| 4 | Abstract, p. 1 | 27.1 | fered on estimated monthly visits by 7.5x to 27.1x, and by 8.6x to 29.9x with b | arithmetic on Table 2 / its released CSV | 27.141445 | CALC | MATCH |  |
| 5 | Abstract, p. 1 | 8.6 | ated monthly visits by 7.5x to 27.1x, and by 8.6x to 29.9x with both read worl | arithmetic on Table 2 / its released CSV | 8.620108 | CALC | MATCH |  |
| 6 | Abstract, p. 1 | 29.9 | thly visits by 7.5x to 27.1x, and by 8.6x to 29.9x with both read worldwide; ac | arithmetic on Table 2 / its released CSV | 29.860816 | CALC | MATCH |  |
| 7 | Abstract, p. 1 | twelve | 6x to 29.9x with both read worldwide; across twelve sections of the same domain t | data/analyze.py | 12.0 | RUN | MATCH |  |
| 8 | Abstract, p. 1 | 0.20 | ctions of the same domain the ratio ran from 0.20x to 7.24x, with no detectable | data/analyze.py | 0.2 | RUN | MATCH |  |
| 9 | Abstract, p. 1 | 7.24 | the same domain the ratio ran from 0.20x to 7.24x, with no detectable relation | data/analyze.py | 7.24 | RUN | MATCH |  |
| 10 | Abstract, p. 1 | −0.11 | ctable relationship to section age (Spearman −0.11, a test of low power with twe | data/analyze.py | -0.11 | RUN | MATCH |  |
| 11 | Abstract, p. 1 | twelve | ge (Spearman −0.11, a test of low power with twelve sections), while the platform | data/analyze.py | 12.0 | RUN | MATCH |  |
| 12 | Abstract, p. 1 | 60 | atforms agreed on which section is larger in 60 of 66 pairs, though in only 9 | data/analyze.py | 60.0 | RUN | MATCH |  |
| 13 | Abstract, p. 1 | 66 | s agreed on which section is larger in 60 of 66 pairs, though in only 9 of th | data/analyze.py | 66.0 | RUN | MATCH |  |
| 14 | Abstract, p. 1 | 9 | is larger in 60 of 66 pairs, though in only 9 of the 15 pairs within a fact | instrument_extra.py | 9.0 | RUN | MATCH |  |
| 15 | Abstract, p. 1 | 15 | r in 60 of 66 pairs, though in only 9 of the 15 pairs within a factor of thre | instrument_extra.py | 15.0 | RUN | MATCH |  |
| 16 | Abstract, p. 1 | 37,193 | of the 15 pairs within a factor of three. On 37,193 reviews of 378 telecom stores | supplement_r10.py (saved output) | 37193.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 17 | Abstract, p. 1 | 378 | thin a factor of three. On 37,193 reviews of 378 telecom stores linked to a 42 | supplement_r10.py (saved output) | 378.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 18 | Abstract, p. 1 | 42,994 | 93 reviews of 378 telecom stores linked to a 42,994-node keyword taxonomy, review | supplement_r10.py (saved output) | 42994.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 19 | Abstract, p. 1 | +0.47 | roughly on the taxonomy's branches (Spearman +0.47 to +0.75, depending on how la | m2_from_counts.py | 0.468 | RUN | MATCH |  |
| 20 | Abstract, p. 1 | +0.75 | n the taxonomy's branches (Spearman +0.47 to +0.75, depending on how labels are | m2_from_counts.py | 0.748 | RUN | MATCH |  |
| 21 | Abstract, p. 1 | +0.18 | ttributed to branches) and barely on topics (+0.18), on links that two blind AI | m2_label_counts.csv, to five decimals | 0.184869 | CALC | MATCH |  |
| 22 | Abstract, p. 1 | judged about two-thirds correct | that two blind AI annotators judged about two-thirds correct. On the 372 area co | r2_link_check.py: 65.0% to 66.8% | agrees | RUN | MATCH | statement in words |
| 23 | Abstract, p. 1 | 372 | tors judged about two-thirds correct. On the 372 area codes the section covers | wiki_demand_analysis.py | 372.0 | RUN | MATCH |  |
| 24 | Abstract, p. 1 | +0.45 | lume agreed roughly on the ranking (Spearman +0.45, bootstrap 95% interval +0.34 | wiki_demand_supplement.py | 0.44598 | RUN | MATCH |  |
| 25 | Abstract, p. 1 | +0.34 | king (Spearman +0.45, bootstrap 95% interval +0.34 to +0.54, over 240 articles) | wiki_demand_analysis.py | 0.344 | RUN | MATCH |  |
| 26 | Abstract, p. 1 | +0.54 | arman +0.45, bootstrap 95% interval +0.34 to +0.54, over 240 articles) and not o | wiki_demand_analysis.py | 0.541 | RUN | MATCH |  |
| 27 | Abstract, p. 1 | 240 | bootstrap 95% interval +0.34 to +0.54, over 240 articles) and not on the magn | wiki_demand_analysis.py | 240.0 | RUN | MATCH |  |
| 28 | Abstract, p. 1 | 0.3 | on the magnitudes (searches per request from 0.3 to 244 between the 10th and 9 | wiki_demand_analysis.py | 0.3 | RUN | MATCH |  |
| 29 | Abstract, p. 1 | 244 | magnitudes (searches per request from 0.3 to 244 between the 10th and 90th per | wiki_demand_analysis.py | 243.7 | RUN | MATCH |  |
| 30 | Abstract, p. 1 | four | argest holdings of each S&P 500 sector fund, four predictions written before co | cross_sector_ai_citation_study.md and wikipedia_demand_372.md: P1 to P4 in each | 4.0 | FILE | MATCH |  |
| 31 | Abstract, p. 1 | one held, one held in direction only and two failed | ten before collection yielded one held, one held in direction only and two failed; video and communit | section7_from_aggregates.py: P1 fails, P2 holds, P3 fails, P4 in direction with p 0.27 and 0.21 | agrees | RUN | MATCH | statement in words |
| 32 | Abstract, p. 1 | 21 | led; video and community sites took a median 21% of citation incidences on Go | section7_from_aggregates.py | 21.3 | RUN | MATCH |  |
| 33 | Abstract, p. 1 | 0.6 | on Google's AI Overviews and AI Mode against 0.6% to 9.2% on ChatGPT, Copilot, | section7_from_aggregates.py | 0.6 | RUN | MATCH |  |
| 34 | Abstract, p. 1 | 9.2 | e's AI Overviews and AI Mode against 0.6% to 9.2% on ChatGPT, Copilot, Perplex | section7_from_aggregates.py | 9.2 | RUN | MATCH |  |
| 35 | Abstract, p. 1 | with the lowest Google figure above the highest of the other four in every sector | pilot, Perplexity and Gemini, with the lowest Google figure above the highest of the other four in every sector. Traffic estimates | section7_from_aggregates.py: 11/11; recomputed from cross_sector_type_shares.csv | agrees | RUN | MATCH | statement in words |
| 36 | §1, p. 2 | 456 | 2022]. The practice is growing: in OpenAlex, 456 works name Ahrefs, Semrush or | vendor_reliance.py --offline | 456.0 | RUN | MATCH |  |
| 37 | §1, p. 2 | 27 | sh or Similarweb in their title or abstract, 27 of them published in 2020, 87 | vendor_reliance.py --offline | 27.0 | RUN | MATCH |  |
| 38 | §1, p. 2 | 87 | e or abstract, 27 of them published in 2020, 87 in 2025 and 110 in 2026 to mi | vendor_reliance.py --offline | 87.0 | RUN | MATCH |  |
| 39 | §1, p. 2 | 110 | 27 of them published in 2020, 87 in 2025 and 110 in 2026 to mid-October. Scree | vendor_reliance.py --offline | 110.0 | RUN | MATCH |  |
| 40 | §1, p. 2 | 120 | two blind AI annotators, a random sample of 120 of them gives 82% to 87% that | stakes_screen_check.py | 120.0 | RUN | MATCH |  |
| 41 | §1, p. 2 | 82 | tators, a random sample of 120 of them gives 82% to 87% that use a vendor's f | stakes_screen_check.py | 82.0 | RUN | MATCH |  |
| 42 | §1, p. 2 | 87 | a random sample of 120 of them gives 82% to 87% that use a vendor's figures | stakes_screen_check.py | 87.0 | RUN | MATCH |  |
| 43 | §1, p. 2 | 75 | ndor's figures as data (Wilson 95% intervals 75% to 92%; Cohen's kappa 0.63), | stakes_screen_check.py | 75.0 | RUN | MATCH |  |
| 44 | §1, p. 2 | 92 | figures as data (Wilson 95% intervals 75% to 92%; Cohen's kappa 0.63), and of | stakes_screen_check.py | 92.0 | RUN | MATCH |  |
| 45 | §1, p. 2 | 0.63 | lson 95% intervals 75% to 92%; Cohen's kappa 0.63), and of those, 87% to 88% us | stakes_screen_check.py | 0.63 | RUN | MATCH |  |
| 46 | §1, p. 2 | 87 | % to 92%; Cohen's kappa 0.63), and of those, 87% to 88% use one vendor's figu | stakes_screen_check.py | 87.0 | RUN | MATCH |  |
| 47 | §1, p. 2 | 88 | %; Cohen's kappa 0.63), and of those, 87% to 88% use one vendor's figures onl | stakes_screen_check.py | 88.0 | RUN | MATCH |  |
| 48 | §1, p. 2 | five | to 88% use one vendor's figures only, while five to seven compare vendors (`ve | stakes_screen_check.py | 5.0 | RUN | MATCH |  |
| 49 | §1, p. 2 | seven | use one vendor's figures only, while five to seven compare vendors (`vendor_reli | stakes_screen_check.py | 7.0 | RUN | MATCH |  |
| 50 | §1, p. 2 | eight | oulos 2026]; this paper adds a comparison of eight vendor-collected answer surfa | cross_sector_type_shares.csv: eight surfaces | 8.0 | CALC | MATCH |  |
| 51 | §1.1, p. 2 | 381 | ame site. This paper uses one such section: 381 code pages plus hubs under a | section_code_pages_2026-10-14.csv | 381 | FILE | MATCH |  |
| 52 | §1.1, p. 2 | 77 | , published on 26 July 2026 and observed for 77 days, with ranking positions | 26 July to 11 October 2026 by the calendar | 77.0 | CALC | MATCH |  |
| 53 | §1.1, p. 2 | seven | t's daily series and the other quantities at seven checkpoints and as monthly hi | Table 5: columns after day 0 | 7.0 | CALC | MATCH |  |
| 54 | Figure 1, p. 3 | 60 of 66 | printed inside fig0_framework.pdf | analyze.py | 60 of 66 | RUN | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 55 | Figure 1, p. 3 | 0.20x to 7.24x | printed inside fig0_framework.pdf | analyze.py | 0.20x to 7.24x | RUN | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 56 | §1.1, p. 3 | thirteen | e User First Intelligence framework. (a) The thirteen demand-surface types the rele | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 57 | §1.2, p. 2 | 30 | ates of the same pages differ by up to about 30 times worldwide (33 times US | arithmetic on Table 2 / its released CSV | 29.860816 | CALC | MATCH |  |
| 58 | §1.2, p. 2 | 33 | es differ by up to about 30 times worldwide (33 times US to US, estimated), i | arithmetic on Table 2 / its released CSV | 33.302387 | CALC | MATCH |  |
| 59 | §1.2, p. 2 | 7.5 | efix from zero differ on estimated visits by 7.5x to 27.1x (8.6x to 29.9x worl | arithmetic on Table 2 / its released CSV | 7.469647 | CALC | MATCH |  |
| 60 | §1.2, p. 2 | 27.1 | m zero differ on estimated visits by 7.5x to 27.1x (8.6x to 29.9x worldwide aga | arithmetic on Table 2 / its released CSV | 27.141445 | CALC | MATCH |  |
| 61 | §1.2, p. 2 | 8.6 | differ on estimated visits by 7.5x to 27.1x (8.6x to 29.9x worldwide against w | arithmetic on Table 2 / its released CSV | 8.620108 | CALC | MATCH |  |
| 62 | §1.2, p. 2 | 29.9 | n estimated visits by 7.5x to 27.1x (8.6x to 29.9x worldwide against worldwide) | arithmetic on Table 2 / its released CSV | 29.860816 | CALC | MATCH |  |
| 63 | §1.2, p. 2 | twelve | o 29.9x worldwide against worldwide); across twelve sections of one domain the ra | data/analyze.py | 12.0 | RUN | MATCH |  |
| 64 | §1.2, p. 2 | 0.20 | welve sections of one domain the ratio spans 0.20x to 7.24x with no detectable | data/analyze.py | 0.2 | RUN | MATCH |  |
| 65 | §1.2, p. 2 | 7.24 | tions of one domain the ratio spans 0.20x to 7.24x with no detectable relations | data/analyze.py | 7.24 | RUN | MATCH |  |
| 66 | §1.2, p. 2 | 60 | atforms agree on the ordering of sections in 60 of 66 pairs. This is the pape | data/analyze.py | 60.0 | RUN | MATCH |  |
| 67 | §1.2, p. 2 | 66 | s agree on the ordering of sections in 60 of 66 pairs. This is the paper's ma | data/analyze.py | 66.0 | RUN | MATCH |  |
| 68 | §1.2, p. 2 | 37,193 | 6; RQ2), bearing on the demand surfaces. On 37,193 business reviews linked to a | supplement_r10.py (saved output) | 37193.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 69 | §1.2, p. 2 | 42,994 | aces. On 37,193 business reviews linked to a 42,994-node keyword taxonomy, the tw | supplement_r10.py (saved output) | 42994.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 70 | §1.2, p. 2 | 372 | s, most for complaints (Section 6.1). On the 372 area codes, a public count of | wiki_demand_analysis.py | 372.0 | RUN | MATCH |  |
| 71 | §1.2, p. 2 | +0.45 | endor's volume agree roughly on the ranking (+0.45 over 240 articles) and not on | wiki_demand_supplement.py | 0.44598 | RUN | MATCH |  |
| 72 | §1.2, p. 2 | 240 | ume agree roughly on the ranking (+0.45 over 240 articles) and not on the magn | wiki_demand_analysis.py | 240.0 | RUN | MATCH |  |
| 73 | §1.2, p. 3 | eleven | surfaces. In one vendor's index, across the eleven S&P 500 sectors and eight ans | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 74 | §1.2, p. 3 | eight | index, across the eleven S&P 500 sectors and eight answer surfaces, Google's AI | cross_sector_type_shares.csv: eight surfaces | 8.0 | CALC | MATCH |  |
| 75 | §1.2, p. 3 | about ten times their pooled median share | surface in every sector, and about ten times their pooled median share (21.3% against 2.1% | 21.3 / 2.1 from section7_from_aggregates.py | agrees | RUN | MATCH | statement in words |
| 76 | §1.2, p. 3 | 21.3 | d about ten times their pooled median share (21.3% against 2.1%); of four predi | section7_from_aggregates.py | 21.3 | RUN | MATCH |  |
| 77 | §1.2, p. 3 | 2.1 | mes their pooled median share (21.3% against 2.1%); of four predictions writte | section7_from_aggregates.py | 2.1 | RUN | MATCH |  |
| 78 | §1.2, p. 3 | four | pooled median share (21.3% against 2.1%); of four predictions written before co | cross_sector_ai_citation_study.md and wikipedia_demand_372.md: P1 to P4 in each | 4.0 | FILE | MATCH |  |
| 79 | §1.2, p. 3 | one held, one held in direction only and two failed | ns written before collection, one held, one held in direction only and two failed. It motivates a per | section7_from_aggregates.py: P1 fails, P2 holds, P3 fails, P4 in direction with p 0.27 and 0.21 | agrees | RUN | MATCH | statement in words |
| 80 | §1.2, p. 3 | 77 | t as context** (Sections 3.1 and 8 to 11): a 77-day series with a primary che | 26 July to 11 October 2026 by the calendar | 77.0 | CALC | MATCH |  |
| 81 | §1.2, p. 3 | 1.2 | in more AI answers than any per-entity page (1.2 to 2.0 times the most-cited o | arithmetic on Section 9.1's counts | 1.235294 | CALC | MATCH |  |
| 82 | §1.2, p. 3 | 2.0 | AI answers than any per-entity page (1.2 to 2.0 times the most-cited one), th | arithmetic on Section 9.1's counts | 1.991597 | CALC | MATCH |  |
| 83 | §1.3, p. 3 | 90 | on a domain with an Ahrefs Domain Rating of 90 and a Semrush Authority Score | single_reads_2026-10.csv | 90.0 | FILE | MATCH | dashboard read, not archived |
| 84 | §1.3, p. 3 | 86 | ating of 90 and a Semrush Authority Score of 86. Nothing here bounds how much | single_reads_2026-10.csv | 86.0 | FILE | MATCH | dashboard read, not archived |
| 85 | §1.4, p. 4 | thirteen | struction of it. The implementation declares thirteen surface types (Figure 1a) and | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 86 | §2, p. 5 | twelve | h observed from zero, and a cross-section of twelve sections of one domain on one | data/analyze.py | 12.0 | RUN | MATCH |  |
| 87 | §2, p. 5 | twelve | tors and the opposite on calibration: across twelve sections of one site, the rat | data/analyze.py | 12.0 | RUN | MATCH |  |
| 88 | §2, p. 6 | eleven | t al. 2026]. Section 7 differs in its frame, eleven sectors fixed by an external | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 89 | §2, p. 6 | eight | sectors fixed by an external rule, in using eight vendor-collected surfaces, an | cross_sector_type_shares.csv: eight surfaces | 8.0 | CALC | MATCH |  |
| 90 | §2, p. 6 | 381 | need expressed as many distinct strings (the 381 code pages rank for 29,000 ke | section_code_pages_2026-10-14.csv | 381 | FILE | MATCH |  |
| 91 | §2, p. 6 | 29,000 | istinct strings (the 381 code pages rank for 29,000 keywords on one instrument). | single_reads_2026-10.csv | 29000.0 | FILE | MATCH | dashboard read, not archived |
| 92 | §2, p. 6 | twelve | s first day on two instruments, and compares twelve sections of the site on one d | data/analyze.py | 12.0 | RUN | MATCH |  |
| 93 | §2, p. 6 | eleven | ixes the industries by an external rule, the eleven GICS sectors, and compares ei | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 94 | §2, p. 6 | eight | rule, the eleven GICS sectors, and compares eight vendor-collected surfaces. # | cross_sector_type_shares.csv: eight surfaces | 8.0 | CALC | MATCH |  |
| 95 | §3, p. 7 | 52 | ng every code page linked from the section's 52 state hubs, the section holds | none | None | NONE | CANNOT RUN | the author's statement; the hub list is not released and the pages were not re-fetched |
| 96 | §3, p. 7 | 381 | e section's 52 state hubs, the section holds 381 code pages**: 374 for geograp | section_code_pages_2026-10-14.csv | 381 | FILE | MATCH |  |
| 97 | §3, p. 7 | 374 | te hubs, the section holds 381 code pages**: 374 for geographic codes assigned | section_code_pages_2026-10-14.csv | 374 | FILE | MATCH |  |
| 98 | §3, p. 7 | 372 | US states and the District of Columbia (all 372 in service and two assigned b | section_code_pages_2026-10-14.csv | 372 | FILE | MATCH |  |
| 99 | §3, p. 7 | two | District of Columbia (all 372 in service and two assigned but not yet in servi | section_code_pages_2026-10-14.csv | 2 | FILE | MATCH |  |
| 100 | §3, p. 7 | 7 | nd two assigned but not yet in service), and 7 for toll-free codes (the rele | section_code_pages_2026-10-14.csv | 7 | FILE | MATCH |  |
| 101 | §3, p. 7 | 52 | s each code's registry location, which takes 52 values: the 50 states, the Di | section_code_pages_2026-10-14.csv | 52 | FILE | MATCH |  |
| 102 | §3, p. 7 | the 50 states, the District, and the plan-wide toll-free codes | ation, which takes 52 values: the 50 states, the District, and the plan-wide toll-free codes); a re-fetch on 14 | section_code_pages_2026-10-14.csv: 50 states, DC, NANP AREA | agrees | FILE | MATCH | statement in words |
| 103 | §3, p. 7 | 381 | a re-fetch on 14 October 2026 found the same 381 and matched them to the numbe | section_code_pages_2026-10-14.csv | 381 | FILE | MATCH |  |
| 104 | §3, p. 7 | 381 | n administrator's registry of that date. All 381 return HTTP 200, are canonica | section_code_pages_2026-10-14.csv | 381 | FILE | MATCH |  |
| 105 | §3, p. 7 | six | aphic codes in the plan with no page are the six assigned to US territories an | wikipedia_demand_372.md ('excluding the six territory codes') | 6.0 | FILE | MATCH |  |
| 106 | §3, p. 7 | 451 | e are the six assigned to US territories and 451, assigned to North Carolina o | none | None | NONE | CANNOT RUN | the numbering plan registry extract (npa_report.csv) is not in the bundle |
| 107 | §3, p. 7 | 210 | able 5's series of pages holding a position (210, 365, 391, 414, 440) is there | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 210.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 108 | §3, p. 7 | 365 | 5's series of pages holding a position (210, 365, 391, 414, 440) is therefore | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 365.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 109 | §3, p. 7 | 391 | eries of pages holding a position (210, 365, 391, 414, 440) is therefore the i | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 391.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 110 | §3, p. 7 | 414 | of pages holding a position (210, 365, 391, 414, 440) is therefore the indexi | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 414.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 111 | §3, p. 7 | 440 | ages holding a position (210, 365, 391, 414, 440) is therefore the indexing of | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 440.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 112 | §3, p. 7 | 434 | is therefore the indexing of a fixed set of 434 URLs by one instrument, and n | 381 + 53 | 434.0 | CALC | MATCH |  |
| 113 | §3, p. 7 | 381 | ge counts remain and are easy to conflate. **381** is the number of code pages | section_code_pages_2026-10-14.csv | 381 | FILE | MATCH |  |
| 114 | §3, p. 7 | 441 | he number of code pages the section holds. **441** is the number of URLs under | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 441.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 115 | §3, p. 7 | 381 | which is selected on the outcome; it exceeds 381 plus the 53 hub pages by seve | section_code_pages_2026-10-14.csv | 381 | FILE | MATCH |  |
| 116 | §3, p. 7 | 53 | cted on the outcome; it exceeds 381 plus the 53 hub pages by seven, which is | none | None | NONE | CANNOT RUN | the author's statement; the hub list is not released and the pages were not re-fetched |
| 117 | §3, p. 7 | seven | ome; it exceeds 381 plus the 53 hub pages by seven, which is within what the ins | 441 - 434 | 7.0 | CALC | MATCH |  |
| 118 | §3, p. 7 | 455 | its canonical pages. Brand Radar's count of 455 distinct cited pages, read on | single_reads_2026-10.csv | 455.0 | FILE | MATCH | dashboard read, not archived |
| 119 | §3, p. 7 | 434 | ashboard reads in the released data, exceeds 434 by 21; that instrument does n | 381 + 53 | 434.0 | CALC | MATCH |  |
| 120 | §3, p. 7 | 21 | d reads in the released data, exceeds 434 by 21; that instrument does not doc | 455 - 434 | 21.0 | CALC | MATCH |  |
| 121 | §3.1, p. 7 | 90 | top-decile authority.** Ahrefs Domain Rating 90, Semrush Authority Score 86. | single_reads_2026-10.csv | 90.0 | FILE | MATCH | dashboard read, not archived |
| 122 | §3.1, p. 7 | 86 | fs Domain Rating 90, Semrush Authority Score 86. 5. **No comparable-authority | single_reads_2026-10.csv | 86.0 | FILE | MATCH | dashboard read, not archived |
| 123 | §3.1, p. 7 | 87 | -per-entity.** Two carriers at Domain Rating 87 and 91 had, between them, ove | single_reads_2026-10.csv | 87.0 | FILE | MATCH | dashboard read, not archived |
| 124 | §3.1, p. 7 | 91 | tity.** Two carriers at Domain Rating 87 and 91 had, between them, overlay no | single_reads_2026-10.csv | 91.0 | FILE | MATCH | dashboard read, not archived |
| 125 | §3.1, p. 7 | 13 | rectories and voice vendors at Domain Rating 13 to 83, and none mounted a vis | single_reads_2026-10.csv | 13.0 | FILE | MATCH | dashboard read, not archived |
| 126 | §3.1, p. 7 | 83 | ies and voice vendors at Domain Rating 13 to 83, and none mounted a visible r | single_reads_2026-10.csv | 83.0 | FILE | MATCH | dashboard read, not archived |
| 127 | §4.1, p. 7 | 105 | h's is the US database. The section ranks in 105 countries with 18.5% of Ahref | single_reads_2026-10.csv | 105.0 | FILE | MATCH | dashboard read, not archived |
| 128 | §4.1, p. 7 | 18.5 | ase. The section ranks in 105 countries with 18.5% of Ahrefs' estimated visits | single_reads_2026-10.csv | 18.5 | FILE | MATCH | dashboard read, not archived |
| 129 | §4.1, p. 7 | 18.6 | hrefs' estimated visits from outside the US (18.6% in the 12 October read of Ta | 1 minus the US share in data/ahrefs_prefixes_2026-10-12.csv | 18.6 | CALC | MATCH |  |
| 130 | §4.1, p. 7 | 7.5 | igure's territory and is nonetheless between 7.5 and 27.1 times larger. Table | arithmetic on Table 2 / its released CSV | 7.469647 | CALC | MATCH |  |
| 131 | §4.1, p. 7 | 27.1 | territory and is nonetheless between 7.5 and 27.1 times larger. Table 2 therefo | arithmetic on Table 2 / its released CSV | 27.141445 | CALC | MATCH |  |
| 132 | §4.1, p. 7 | 8.6 | rs less territory; worldwide over worldwide (8.6x to 29.9x); and US over US (9 | arithmetic on Table 2 / its released CSV | 8.620108 | CALC | MATCH |  |
| 133 | §4.1, p. 7 | 29.9 | territory; worldwide over worldwide (8.6x to 29.9x); and US over US (9.2x to 33 | arithmetic on Table 2 / its released CSV | 29.860816 | CALC | MATCH |  |
| 134 | §4.1, p. 7 | 9.2 | r worldwide (8.6x to 29.9x); and US over US (9.2x to 33.3x), estimated by appl | arithmetic on Table 2 / its released CSV | 9.165211 | CALC | MATCH |  |
| 135 | §4.1, p. 7 | 33.3 | ide (8.6x to 29.9x); and US over US (9.2x to 33.3x), estimated by applying Ahre | arithmetic on Table 2 / its released CSV | 33.302387 | CALC | MATCH |  |
| 136 | §4.1, p. 7 | 81.5 | applying Ahrefs' US share of its own visits, 81.5%, read once in October, to ev | single_reads_2026-10.csv | 81.5 | FILE | MATCH | dashboard read, not archived |
| 137 | §4.3, p. 8 | 24 | dow. The September 2026 spam update began on 24 September, day 60, which is a | 26 July + 60 days by the calendar | 24.0 | CALC | MATCH |  |
| 138 | §4.3, p. 8 | 60 | 2026 spam update began on 24 September, day 60, which is also the day of the | 26 July + 60 days = 24 September | 60.0 | CALC | MATCH |  |
| 139 | §4.3, p. 8 | 29 | ated-traffic peak. Ahrefs posted a notice on 29 September, day 65, that Googl | 26 July + 65 days by the calendar | 29.0 | CALC | MATCH |  |
| 140 | §4.3, p. 8 | 65 | Ahrefs posted a notice on 29 September, day 65, that Google had changed how | 26 July + 65 days = 29 September | 65.0 | CALC | MATCH |  |
| 141 | §4.3, p. 8 | four | y checkpoints, and the 11 October read gives four of the nine quantities for it | Table 5: rows with a value in the day-37 column | 4.0 | CALC | MATCH |  |
| 142 | §4.3, p. 8 | nine | s, and the 11 October read gives four of the nine quantities for it, not all ni | Table 5: nine rows | 9.0 | CALC | MATCH |  |
| 143 | §5.1, p. 9 | 7.5 | . ### 5.1 Estimated visits: a divergence of 7.5x to 27.1x on one prefix *Tab | arithmetic on Table 2 / its released CSV | 7.469647 | CALC | MATCH |  |
| 144 | §5.1, p. 9 | 27.1 | .1 Estimated visits: a divergence of 7.5x to 27.1x on one prefix *Table 2. Est | arithmetic on Table 2 / its released CSV | 27.141445 | CALC | MATCH |  |
| 145 | §5.1, p. 10 | 81.5 | divides Semrush US by Ahrefs worldwide times 81.5%, Ahrefs' US share read on 11 | single_reads_2026-10.csv | 81.5 | FILE | MATCH | dashboard read, not archived |
| 146 | Table 2, p. 10 | 6 | Table 2 | instrument_series_table2 CSV | 6.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 147 | Table 2, p. 10 | 3,862 | Table 2 | instrument_series_table2 CSV | 3862.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 148 | Table 2, p. 10 | 100,012 | Table 2 | instrument_series_table2 CSV | 100012.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 149 | Table 2, p. 10 | 103,045 | Table 2 | instrument_series_table2 CSV | 103045.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 150 | Table 2, p. 10 | 25.9x | Table 2 | arithmetic on Table 2's visits; 81.5% for the third | 25.896427 | CALC | MATCH |  |
| 151 | Table 2, p. 10 | 26.7x | Table 2 | arithmetic on Table 2's visits; 81.5% for the third | 26.681771 | CALC | MATCH |  |
| 152 | Table 2, p. 10 | 31.8x | Table 2 | arithmetic on Table 2's visits; 81.5% for the third | 31.774757 | CALC | MATCH |  |
| 153 | Table 2, p. 10 | 31 | Table 2 | instrument_series_table2 CSV | 31.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 154 | Table 2, p. 10 | 32,281 | Table 2 | instrument_series_table2 CSV | 32281.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 155 | Table 2, p. 10 | 876,153 | Table 2 | instrument_series_table2 CSV | 876153.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 156 | Table 2, p. 10 | 963,937 | Table 2 | instrument_series_table2 CSV | 963937.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 157 | Table 2, p. 10 | 27.1x | Table 2 | arithmetic on Table 2's visits; 81.5% for the third | 27.141445 | CALC | MATCH |  |
| 158 | Table 2, p. 10 | 29.9x | Table 2 | arithmetic on Table 2's visits; 81.5% for the third | 29.860816 | CALC | MATCH |  |
| 159 | Table 2, p. 10 | 33.3x | Table 2 | arithmetic on Table 2's visits; 81.5% for the third | 33.302387 | CALC | MATCH |  |
| 160 | Table 2, p. 10 | 30 | Table 2 | instrument_series_table2 CSV | 30.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 161 | Table 2, p. 10 | 150,113 | Table 2 | instrument_series_table2 CSV | 150113.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 162 | Table 2, p. 10 | 1,534,362 | Table 2 | instrument_series_table2 CSV | 1534362.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 163 | Table 2, p. 10 | 1,765,077 | Table 2 | instrument_series_table2 CSV | 1765077.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 164 | Table 2, p. 10 | 10.2x | Table 2 | arithmetic on Table 2's visits; 81.5% for the third | 10.22138 | CALC | MATCH |  |
| 165 | Table 2, p. 10 | 11.8x | Table 2 | arithmetic on Table 2's visits; 81.5% for the third | 11.758322 | CALC | MATCH |  |
| 166 | Table 2, p. 10 | 12.5x | Table 2 | arithmetic on Table 2's visits; 81.5% for the third | 12.54157 | CALC | MATCH |  |
| 167 | Table 2, p. 10 | 11 | Table 2 | instrument_series_table2 CSV | 11.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 168 | Table 2, p. 10 | 215,577 | Table 2 | instrument_series_table2 CSV | 215577.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 169 | Table 2, p. 10 | 1,610,284 | Table 2 | instrument_series_table2 CSV | 1610284.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 170 | Table 2, p. 10 | 1,858,297 | Table 2 | instrument_series_table2 CSV | 1858297.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 171 | Table 2, p. 10 | 7.5x | Table 2 | arithmetic on Table 2's visits; 81.5% for the third | 7.469647 | CALC | MATCH |  |
| 172 | Table 2, p. 10 | 8.6x | Table 2 | arithmetic on Table 2's visits; 81.5% for the third | 8.620108 | CALC | MATCH |  |
| 173 | Table 2, p. 10 | 9.2x | Table 2 | arithmetic on Table 2's visits; 81.5% for the third | 9.165211 | CALC | MATCH |  |
| 174 | Figure 2, p. 9 | 25.9x | printed inside fig1_divergence.pdf | arithmetic on Table 2 / its released CSV | 25.896427 | CALC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 175 | Figure 2, p. 9 | 27.1x | printed inside fig1_divergence.pdf | arithmetic on Table 2 / its released CSV | 27.141445 | CALC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 176 | Figure 2, p. 9 | 10.2x | printed inside fig1_divergence.pdf | arithmetic on Table 2 / its released CSV | 10.22138 | CALC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 177 | Figure 2, p. 9 | 7.5x | printed inside fig1_divergence.pdf | arithmetic on Table 2 / its released CSV | 7.469647 | CALC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 178 | §5.1, p. 9 | 8.4 | section grew. From July to August they did (8.4x on Ahrefs, 8.8x on Semrush U | instrument_extra.py | 8.36 | RUN | MATCH |  |
| 179 | §5.1, p. 9 | 8.8 | rom July to August they did (8.4x on Ahrefs, 8.8x on Semrush US); from August | instrument_extra.py | 8.76 | RUN | MATCH |  |
| 180 | §5.1, p. 9 | 4.65 | om August to September Ahrefs' estimate grew 4.65x and Semrush's 1.75x, and int | instrument_extra.py | 4.65 | RUN | MATCH |  |
| 181 | §5.1, p. 9 | 1.75 | er Ahrefs' estimate grew 4.65x and Semrush's 1.75x, and into October's run-rate | instrument_extra.py | 1.75 | RUN | MATCH |  |
| 182 | §5.1, p. 9 | 1.44 | Semrush's 1.75x, and into October's run-rate 1.44x against 1.05x. A month's lif | instrument_extra.py | 1.44 | RUN | MATCH |  |
| 183 | §5.1, p. 9 | 1.05 | x, and into October's run-rate 1.44x against 1.05x. A month's lift measured on | instrument_extra.py | 1.05 | RUN | MATCH |  |
| 184 | §5.1, p. 9 | 18.5 | ide figure throughout, and the section draws 18.5% of its Ahrefs-estimated visi | single_reads_2026-10.csv | 18.5 | FILE | MATCH | dashboard read, not archived |
| 185 | §5.1, p. 9 | 8.6 | it: worldwide against worldwide it runs from 8.6x to 29.9x, and US against US, | arithmetic on Table 2 / its released CSV | 8.620108 | CALC | MATCH |  |
| 186 | §5.1, p. 9 | 29.9 | dwide against worldwide it runs from 8.6x to 29.9x, and US against US, estimate | arithmetic on Table 2 / its released CSV | 29.860816 | CALC | MATCH |  |
| 187 | §5.1, p. 9 | 9.2 | to 29.9x, and US against US, estimated, from 9.2x to 33.3x (Table 2). **It na | arithmetic on Table 2 / its released CSV | 9.165211 | CALC | MATCH |  |
| 188 | §5.1, p. 9 | 33.3 | , and US against US, estimated, from 9.2x to 33.3x (Table 2). **It narrows aft | arithmetic on Table 2 / its released CSV | 33.302387 | CALC | MATCH |  |
| 189 | §5.1, p. 9 | 27.1 | fter the second month on this prefix**, from 27.1x to 10.2x to 7.5x. Section 5. | arithmetic on Table 2 / its released CSV | 27.141445 | CALC | MATCH |  |
| 190 | §5.1, p. 9 | 10.2 | second month on this prefix**, from 27.1x to 10.2x to 7.5x. Section 5.5 tests w | arithmetic on Table 2 / its released CSV | 10.22138 | CALC | MATCH |  |
| 191 | §5.1, p. 9 | 7.5 | nth on this prefix**, from 27.1x to 10.2x to 7.5x. Section 5.5 tests whether t | arithmetic on Table 2 / its released CSV | 7.469647 | CALC | MATCH |  |
| 192 | §5.1, p. 9 | twelve | arrowing is a property of section age across twelve prefixes and finds that it is | data/analyze.py | 12.0 | RUN | MATCH |  |
| 193 | §5.2, p. 9 | 29,000 | fix ranks in positions 1–100, Ahrefs reports 29,000 for all locations and Semrush | single_reads_2026-10.csv | 29000.0 | FILE | MATCH | dashboard read, not archived |
| 194 | §5.2, p. 9 | 58,586 | reports 29,000 for all locations and Semrush 58,586 for the US database, read a d | single_reads_2026-10.csv | 58586.0 | FILE | MATCH | dashboard read, not archived |
| 195 | §5.2, p. 9 | 2.0 | e US database, read a day apart: a factor of 2.0, again with the larger figure | arithmetic on the paper's own counts | 2.020207 | CALC | MATCH |  |
| 196 | §5.2, p. 9 | 92.3K | he author in its interface on 12 October, is 92.3K (the interface rounds to the | single_reads_2026-10.csv (92.3K) | 92300.0 | FILE | MATCH | read by the author; dashboard read, not archived |
| 197 | §5.2, p. 9 | 3.2 | 92.3K (the interface rounds to the hundred), 3.2 times Ahrefs' 28,900 for all | arithmetic on the paper's own counts | 3.193772 | CALC | MATCH |  |
| 198 | §5.2, p. 9 | 28,900 | ce rounds to the hundred), 3.2 times Ahrefs' 28,900 for all locations on the same | data/ahrefs_prefixes_2026-10-12.csv | 28900.0 | FILE | MATCH | dashboard read |
| 199 | §5.2, p. 9 | 441 | gap. Pages holding at least one position are 441 in Ahrefs. ### 5.3 AI answer | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 441.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 200 | §5.3, p. 9 | 17,206 | parable at the prefix level.** Brand Radar's 17,206 stored answers citing the sec | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 17206.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 201 | §5.3, p. 9 | 158,100 | red answers citing the section and Semrush's 158,100 mentions read on 10 October d | single_reads_2026-10.csv | 158100.0 | FILE | MATCH | dashboard read, not archived |
| 202 | §5.3, p. 9 | 9.2 | ons read on 10 October differ by a factor of 9.2, but that ratio is a scope mi | arithmetic on the paper's own counts | 9.188655 | CALC | MATCH |  |
| 203 | §5.3, p. 9 | 29,600 | t a divergence: Semrush's companion count of 29,600 cited pages is 68 times the 4 | single_reads_2026-10.csv | 29600.0 | FILE | MATCH | dashboard read, not archived |
| 204 | §5.3, p. 9 | 68 | h's companion count of 29,600 cited pages is 68 times the 434 URLs the sectio | arithmetic on the paper's own counts | 68.202765 | CALC | MATCH |  |
| 205 | §5.3, p. 9 | 434 | count of 29,600 cited pages is 68 times the 434 URLs the section holds, so it | 381 + 53 | 434.0 | CALC | MATCH |  |
| 206 | §5.3, p. 9 | 17,206 | ad date in Section 4.1. The Ahrefs figure of 17,206 stored answers is reported in | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 17206.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 207 | Table 3, p. 10 | 47 | Table 3 | instrument_series_table3 CSV | 47.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 208 | Table 3, p. 10 | 284 | Table 3 | instrument_series_table3 CSV | 284.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 209 | Table 3, p. 10 | 16.5 | Table 3 | arithmetic on Table 3's counts | 16.549296 | CALC | MATCH |  |
| 210 | Table 3, p. 10 | 12.7 | Table 3 | Wilson interval on Table 3's counts | 12.679358 | CALC | MATCH |  |
| 211 | Table 3, p. 10 | 21.3 | Table 3 | Wilson interval on Table 3's counts | 21.312115 | CALC | MATCH |  |
| 212 | Table 3, p. 10 | 138 | Table 3 | instrument_series_table3 CSV | 138.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 213 | Table 3, p. 10 | 2.94x | Table 3 | arithmetic on Table 3's counts | 2.93617 | CALC | MATCH |  |
| 214 | Table 3, p. 10 | 851 | Table 3 | instrument_series_table3 CSV | 851.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 215 | Table 3, p. 10 | 6,749 | Table 3 | instrument_series_table3 CSV | 6749.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 216 | Table 3, p. 10 | 12.6 | Table 3 | arithmetic on Table 3's counts | 12.609275 | CALC | MATCH |  |
| 217 | Table 3, p. 10 | 11.8 | Table 3 | Wilson interval on Table 3's counts | 11.838506 | CALC | MATCH |  |
| 218 | Table 3, p. 10 | 13.4 | Table 3 | Wilson interval on Table 3's counts | 13.422587 | CALC | MATCH |  |
| 219 | Table 3, p. 10 | 2,221 | Table 3 | instrument_series_table3 CSV | 2221.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 220 | Table 3, p. 10 | 2.61x | Table 3 | arithmetic on Table 3's counts | 2.609871 | CALC | MATCH |  |
| 221 | Table 3, p. 10 | 3,380 | Table 3 | instrument_series_table3 CSV | 3380.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 222 | Table 3, p. 10 | 22,665 | Table 3 | instrument_series_table3 CSV | 22665.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 223 | Table 3, p. 10 | 14.9 | Table 3 | arithmetic on Table 3's counts | 14.912861 | CALC | MATCH |  |
| 224 | Table 3, p. 10 | 14.5 | Table 3 | Wilson interval on Table 3's counts | 14.455051 | CALC | MATCH |  |
| 225 | Table 3, p. 10 | 15.4 | Table 3 | Wilson interval on Table 3's counts | 15.382563 | CALC | MATCH |  |
| 226 | Table 3, p. 10 | 8,187 | Table 3 | instrument_series_table3 CSV | 8187.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 227 | Table 3, p. 10 | 2.42x | Table 3 | arithmetic on Table 3's counts | 2.422189 | CALC | MATCH |  |
| 228 | Table 3, p. 10 | 7,455 | Table 3 | instrument_series_table3 CSV | 7455.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 229 | Table 3, p. 10 | 37,238 | Table 3 | instrument_series_table3 CSV | 37238.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 230 | Table 3, p. 10 | 20.0 | Table 3 | arithmetic on Table 3's counts | 20.019872 | CALC | MATCH |  |
| 231 | Table 3, p. 10 | 19.6 | Table 3 | Wilson interval on Table 3's counts | 19.616545 | CALC | MATCH |  |
| 232 | Table 3, p. 10 | 20.4 | Table 3 | Wilson interval on Table 3's counts | 20.429384 | CALC | MATCH |  |
| 233 | Table 3, p. 10 | 10,018 | Table 3 | instrument_series_table3 CSV | 10018.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 234 | Table 3, p. 10 | 1.34x | Table 3 | arithmetic on Table 3's counts | 1.343796 | CALC | MATCH |  |
| 235 | Figure 3, p. 10 | 2.94x | printed inside fig2_aio.pdf | arithmetic on Table 3 / its released CSV | 2.93617 | CALC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 236 | Figure 3, p. 10 | 2.61x | printed inside fig2_aio.pdf | arithmetic on Table 3 / its released CSV | 2.609871 | CALC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 237 | Figure 3, p. 10 | 2.42x | printed inside fig2_aio.pdf | arithmetic on Table 3 / its released CSV | 2.422189 | CALC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 238 | Figure 3, p. 10 | 1.34x | printed inside fig2_aio.pdf | arithmetic on Table 3 / its released CSV | 1.343796 | CALC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 239 | §5.3, p. 10 | 284 | Wilson intervals; the denominators grow from 284 to 37,238. (b) The two vendor | instrument_series_table3 CSV (parsed from Table 3 itself) | 284.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 240 | §5.3, p. 10 | 37,238 | intervals; the denominators grow from 284 to 37,238. (b) The two vendor counts, S | instrument_series_table3 CSV (parsed from Table 3 itself) | 37238.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 241 | §5.3, p. 9 | 2.94 | The ratio between the two counts falls from 2.94 to 1.34 over four months (Fig | arithmetic on Table 3 / its released CSV | 2.93617 | CALC | MATCH |  |
| 242 | §5.3, p. 9 | 1.34 | io between the two counts falls from 2.94 to 1.34 over four months (Figure 3b). | arithmetic on Table 3 / its released CSV | 1.343796 | CALC | MATCH |  |
| 243 | §5.3, p. 9 | 47 | not a trend estimate. The July row rests on 47 events over six days live, an | instrument_series_table3 CSV (parsed from Table 3 itself) | 47.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 244 | §5.3, p. 9 | six | timate. The July row rests on 47 events over six days live, and its interval i | 26 to 31 July inclusive | 6.0 | CALC | MATCH |  |
| 245 | §5.3, p. 9 | 284 | orders of magnitude across the series, from 284 to 37,238, and it is not mono | instrument_series_table3 CSV (parsed from Table 3 itself) | 284.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 246 | §5.3, p. 9 | 37,238 | of magnitude across the series, from 284 to 37,238, and it is not monotone. Its | instrument_series_table3 CSV (parsed from Table 3 itself) | 37238.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 247 | §5.4, p. 10 | 11.4 | trument's error. ### 5.4 Referring domains: 11.4x, and disagreement about comp | arithmetic on the paper's own counts | 11.4125 | CALC | MATCH |  |
| 248 | §5.4, p. 10 | 913 | tudy after estimated visits. Ahrefs reports 913 referring domains to the pref | single_reads_2026-10.csv | 913.0 | FILE | MATCH | dashboard read, not archived |
| 249 | §5.4, p. 10 | 80 | e prefix; Semrush Backlink Analytics indexes 80 for the subfolder: a factor o | single_reads_2026-10.csv | 80.0 | FILE | MATCH | dashboard read, not archived |
| 250 | §5.4, p. 10 | 11.4 | cs indexes 80 for the subfolder: a factor of 11.4. They also disagree about wha | arithmetic on the paper's own counts | 11.4125 | CALC | MATCH |  |
| 251 | §5.4, p. 10 | 61.9 | ee about what those domains are. Ahrefs puts 61.9% on .info, 26.4% on .asia and | single_reads_2026-10.csv | 61.9 | FILE | MATCH | dashboard read, not archived |
| 252 | §5.4, p. 10 | 26.4 | ose domains are. Ahrefs puts 61.9% on .info, 26.4% on .asia and 10.2% on .xyz; | single_reads_2026-10.csv | 26.4 | FILE | MATCH | dashboard read, not archived |
| 253 | §5.4, p. 10 | 10.2 | refs puts 61.9% on .info, 26.4% on .asia and 10.2% on .xyz; Semrush puts 75% on | single_reads_2026-10.csv | 10.2 | FILE | MATCH | dashboard read, not archived |
| 254 | §5.4, p. 10 | 75 | .4% on .asia and 10.2% on .xyz; Semrush puts 75% on .xyz and 88% at Authority | single_reads_2026-10.csv | 75.0 | FILE | MATCH | dashboard read, not archived |
| 255 | §5.4, p. 10 | 88 | 10.2% on .xyz; Semrush puts 75% on .xyz and 88% at Authority Score 0 to 10. | single_reads_2026-10.csv | 88.0 | FILE | MATCH | dashboard read, not archived |
| 256 | Figure 4, p. 11 | 61.9% | printed inside fig3_refdomains.pdf | single_reads_2026-10.csv | 61.9 | FILE | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 257 | Figure 4, p. 11 | 26.4% | printed inside fig3_refdomains.pdf | single_reads_2026-10.csv | 26.4 | FILE | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 258 | Figure 4, p. 11 | 10.2% | printed inside fig3_refdomains.pdf | single_reads_2026-10.csv | 10.2 | FILE | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 259 | Figure 4, p. 11 | 75% | printed inside fig3_refdomains.pdf | single_reads_2026-10.csv | 75.0 | FILE | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 260 | Figure 4, p. 11 | 913 | printed inside fig3_refdomains.pdf | single_reads_2026-10.csv | 913.0 | FILE | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 261 | Figure 4, p. 11 | 80 | printed inside fig3_refdomains.pdf | single_reads_2026-10.csv | 80.0 | FILE | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 262 | §5.4, p. 11 | 913 | each instrument on 11 October 2026. Ahrefs: 913 domains; Semrush Backlink Ana | single_reads_2026-10.csv | 913.0 | FILE | MATCH | dashboard read, not archived |
| 263 | §5.4, p. 11 | 80 | fs: 913 domains; Semrush Backlink Analytics: 80 domains, of which the instrum | single_reads_2026-10.csv | 80.0 | FILE | MATCH | dashboard read, not archived |
| 264 | §5.4, p. 11 | 75 | 80 domains, of which the instrument reports 75% on .xyz and does not break d | single_reads_2026-10.csv | 75.0 | FILE | MATCH | dashboard read, not archived |
| 265 | §5.4, p. 10 | 909 | s even its own count: its daily series gives 909 at day 75 against 913 on 11 O | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 909.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 266 | §5.4, p. 10 | 913 | its daily series gives 909 at day 75 against 913 on 11 October, and its new-an | single_reads_2026-10.csv | 913.0 | FILE | MATCH | dashboard read, not archived |
| 267 | §5.4, p. 21 | 917 | its new-and-lost report for September gives 917 new against 95 lost, which wi | single_reads_2026-10.csv | 917.0 | FILE | MATCH | dashboard read, not archived |
| 268 | §5.4, p. 21 | 95 | t report for September gives 917 new against 95 lost, which with nineteen at | single_reads_2026-10.csv | 95.0 | FILE | MATCH | dashboard read, not archived |
| 269 | §5.4, p. 21 | nineteen | er gives 917 new against 95 lost, which with nineteen at day 37 implies about 841 a | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 19.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 270 | §5.4, p. 11 | 841 | which with nineteen at day 37 implies about 841 at the end of September, an e | arithmetic on the paper's own counts | 841 | CALC | MATCH |  |
| 271 | §5.5, p. 11 | Twelve | laim here turns on the exact count. ### 5.5 Twelve prefixes on one domain: the d | data/analyze.py | 12.0 | RUN | MATCH |  |
| 272 | §5.5, p. 11 | twelve | on 12 October 2026, on both instruments, for twelve sections of the same domain: | data/analyze.py | 12.0 | RUN | MATCH |  |
| 273 | §5.5, p. 11 | eleven | f the same domain: the area-code section and eleven others chosen by the author t | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 274 | §5.5, p. 11 | twelve | , not random, and the results describe these twelve. Every figure below is a dash | data/analyze.py | 12.0 | RUN | MATCH |  |
| 275 | §5.5, p. 12 | Twelve | the remaining per-prefix figures. *Table 4. Twelve URL prefixes on one domain, b | data/analyze.py | 12.0 | RUN | MATCH |  |
| 276 | §5.5, p. 12 | the next two lie within four months of it | -censored at that horizon and the next two lie within four months of it. Ahrefs visits are | data/ahrefs_prefixes: 133, 132 and 129 months | agrees | CALC | MATCH | statement in words |
| 277 | §5.5, p. 12 | 29,000 | Sections 5.2 and 5.4's 10–11 October reads (29,000 and 58,586 keywords; 80 Semru | single_reads_2026-10.csv | 29000.0 | FILE | MATCH | dashboard read, not archived |
| 278 | §5.5, p. 12 | 58,586 | .2 and 5.4's 10–11 October reads (29,000 and 58,586 keywords; 80 Semrush domains, | single_reads_2026-10.csv | 58586.0 | FILE | MATCH | dashboard read, not archived |
| 279 | §5.5, p. 12 | 80 | 1 October reads (29,000 and 58,586 keywords; 80 Semrush domains, 11.4x).* \| | single_reads_2026-10.csv | 80.0 | FILE | MATCH | dashboard read, not archived |
| 280 | §5.5, p. 12 | 11.4 | 000 and 58,586 keywords; 80 Semrush domains, 11.4x).* \| Prefix \| Age (mo) \| Ah | arithmetic on the paper's own counts | 11.4125 | CALC | MATCH |  |
| 281 | Table 4, p. 12 | 3 | Table 4 | instrument_extra.py section 8; age recomputed from the file | 3.0 | RUN | MATCH |  |
| 282 | Table 4, p. 12 | 221,000 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 221000.0 | FILE | MATCH | dashboard read, not archived |
| 283 | Table 4, p. 12 | 1,600,000 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 1600000.0 | FILE | MATCH | dashboard read, not archived |
| 284 | Table 4, p. 12 | 7.24 | Table 4 | instrument_extra.py section 8 | 7.24 | RUN | MATCH |  |
| 285 | Table 4, p. 12 | 81.4% | Table 4 | instrument_extra.py section 8 | 81.4 | RUN | MATCH |  |
| 286 | Table 4, p. 12 | 8.89 | Table 4 | instrument_extra.py section 8 | 8.89 | RUN | MATCH |  |
| 287 | Table 4, p. 12 | 28,900 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 28900.0 | FILE | MATCH | dashboard read, not archived |
| 288 | Table 4, p. 12 | 59,000 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 59000.0 | FILE | MATCH | dashboard read, not archived |
| 289 | Table 4, p. 12 | 2.0 | Table 4 | instrument_extra.py section 8 | 2.0 | RUN | MATCH |  |
| 290 | Table 4, p. 12 | 913 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 913.0 | FILE | MATCH | dashboard read, not archived |
| 291 | Table 4, p. 12 | 81 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 81.0 | FILE | MATCH | dashboard read, not archived |
| 292 | Table 4, p. 12 | 11.3 | Table 4 | instrument_extra.py section 8 | 11.3 | RUN | MATCH |  |
| 293 | Table 4, p. 12 | 21 | Table 4 | instrument_extra.py section 8; age recomputed from the file | 21.0 | RUN | MATCH |  |
| 294 | Table 4, p. 12 | 5,500 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 5500.0 | FILE | MATCH | dashboard read, not archived |
| 295 | Table 4, p. 12 | 4,100 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 4100.0 | FILE | MATCH | dashboard read, not archived |
| 296 | Table 4, p. 12 | 0.75 | Table 4 | instrument_extra.py section 8 | 0.75 | RUN | MATCH |  |
| 297 | Table 4, p. 12 | 69.6% | Table 4 | instrument_extra.py section 8 | 69.6 | RUN | MATCH |  |
| 298 | Table 4, p. 12 | 1.07 | Table 4 | instrument_extra.py section 8 | 1.07 | RUN | MATCH |  |
| 299 | Table 4, p. 12 | 716 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 716.0 | FILE | MATCH | dashboard read, not archived |
| 300 | Table 4, p. 12 | 2,300 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 2300.0 | FILE | MATCH | dashboard read, not archived |
| 301 | Table 4, p. 12 | 3.2 | Table 4 | instrument_extra.py section 8 | 3.2 | RUN | MATCH |  |
| 302 | Table 4, p. 12 | 187 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 187.0 | FILE | MATCH | dashboard read, not archived |
| 303 | Table 4, p. 12 | 41 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 41.0 | FILE | MATCH | dashboard read, not archived |
| 304 | Table 4, p. 12 | 4.6 | Table 4 | instrument_extra.py section 8 | 4.6 | RUN | MATCH |  |
| 305 | Table 4, p. 12 | 36 | Table 4 | instrument_extra.py section 8; age recomputed from the file | 36.0 | RUN | MATCH |  |
| 306 | Table 4, p. 12 | 25,600 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 25600.0 | FILE | MATCH | dashboard read, not archived |
| 307 | Table 4, p. 12 | 5,200 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 5200.0 | FILE | MATCH | dashboard read, not archived |
| 308 | Table 4, p. 12 | 0.20 | Table 4 | instrument_extra.py section 8 | 0.2 | RUN | MATCH |  |
| 309 | Table 4, p. 12 | 99.2% | Table 4 | instrument_extra.py section 8 | 99.2 | RUN | MATCH |  |
| 310 | Table 4, p. 12 | 0.20 | Table 4 | instrument_extra.py section 8 | 0.2 | RUN | MATCH |  |
| 311 | Table 4, p. 12 | 2,100 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 2100.0 | FILE | MATCH | dashboard read, not archived |
| 312 | Table 4, p. 12 | 33,800 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 33800.0 | FILE | MATCH | dashboard read, not archived |
| 313 | Table 4, p. 12 | 16.1 | Table 4 | instrument_extra.py section 8 | 16.1 | RUN | MATCH |  |
| 314 | Table 4, p. 12 | 115 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 115.0 | FILE | MATCH | dashboard read, not archived |
| 315 | Table 4, p. 12 | 194 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 194.0 | FILE | MATCH | dashboard read, not archived |
| 316 | Table 4, p. 12 | 0.6 | Table 4 | instrument_extra.py section 8 | 0.6 | RUN | MATCH |  |
| 317 | Table 4, p. 12 | 39 | Table 4 | instrument_extra.py section 8; age recomputed from the file | 39.0 | RUN | MATCH |  |
| 318 | Table 4, p. 12 | 26,700 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 26700.0 | FILE | MATCH | dashboard read, not archived |
| 319 | Table 4, p. 12 | 26,400 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 26400.0 | FILE | MATCH | dashboard read, not archived |
| 320 | Table 4, p. 12 | 0.99 | Table 4 | instrument_extra.py section 8 | 0.99 | RUN | MATCH |  |
| 321 | Table 4, p. 12 | 82.6% | Table 4 | instrument_extra.py section 8 | 82.6 | RUN | MATCH |  |
| 322 | Table 4, p. 12 | 1.20 | Table 4 | instrument_extra.py section 8 | 1.2 | RUN | MATCH |  |
| 323 | Table 4, p. 12 | 2,400 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 2400.0 | FILE | MATCH | dashboard read, not archived |
| 324 | Table 4, p. 12 | 12,600 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 12600.0 | FILE | MATCH | dashboard read, not archived |
| 325 | Table 4, p. 12 | 5.2 | Table 4 | instrument_extra.py section 8 | 5.2 | RUN | MATCH |  |
| 326 | Table 4, p. 12 | 47 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 47.0 | FILE | MATCH | dashboard read, not archived |
| 327 | Table 4, p. 12 | 45 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 45.0 | FILE | MATCH | dashboard read, not archived |
| 328 | Table 4, p. 12 | 1.0 | Table 4 | instrument_extra.py section 8 | 1.0 | RUN | MATCH |  |
| 329 | Table 4, p. 12 | 57 | Table 4 | instrument_extra.py section 8; age recomputed from the file | 57.0 | RUN | MATCH |  |
| 330 | Table 4, p. 12 | 37,300 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 37300.0 | FILE | MATCH | dashboard read, not archived |
| 331 | Table 4, p. 12 | 135,100 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 135100.0 | FILE | MATCH | dashboard read, not archived |
| 332 | Table 4, p. 12 | 3.62 | Table 4 | instrument_extra.py section 8 | 3.62 | RUN | MATCH |  |
| 333 | Table 4, p. 12 | 98.8% | Table 4 | instrument_extra.py section 8 | 98.8 | RUN | MATCH |  |
| 334 | Table 4, p. 12 | 3.67 | Table 4 | instrument_extra.py section 8 | 3.67 | RUN | MATCH |  |
| 335 | Table 4, p. 12 | 3,600 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 3600.0 | FILE | MATCH | dashboard read, not archived |
| 336 | Table 4, p. 12 | 37,500 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 37500.0 | FILE | MATCH | dashboard read, not archived |
| 337 | Table 4, p. 12 | 10.4 | Table 4 | instrument_extra.py section 8 | 10.4 | RUN | MATCH |  |
| 338 | Table 4, p. 12 | 144 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 144.0 | FILE | MATCH | dashboard read, not archived |
| 339 | Table 4, p. 12 | 225 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 225.0 | FILE | MATCH | dashboard read, not archived |
| 340 | Table 4, p. 12 | 0.6 | Table 4 | instrument_extra.py section 8 | 0.6 | RUN | MATCH |  |
| 341 | Table 4, p. 12 | 93 | Table 4 | instrument_extra.py section 8; age recomputed from the file | 93.0 | RUN | MATCH |  |
| 342 | Table 4, p. 12 | 1,900,000 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 1900000.0 | FILE | MATCH | dashboard read, not archived |
| 343 | Table 4, p. 12 | 1,957,880 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 1957880.0 | FILE | MATCH | dashboard read, not archived |
| 344 | Table 4, p. 12 | 1.03 | Table 4 | instrument_extra.py section 8 | 1.03 | RUN | MATCH |  |
| 345 | Table 4, p. 12 | 98.7% | Table 4 | instrument_extra.py section 8 | 98.7 | RUN | MATCH |  |
| 346 | Table 4, p. 12 | 1.04 | Table 4 | instrument_extra.py section 8 | 1.04 | RUN | MATCH |  |
| 347 | Table 4, p. 12 | 38,700 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 38700.0 | FILE | MATCH | dashboard read, not archived |
| 348 | Table 4, p. 12 | 351,854 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 351854.0 | FILE | MATCH | dashboard read, not archived |
| 349 | Table 4, p. 12 | 9.1 | Table 4 | instrument_extra.py section 8 | 9.1 | RUN | MATCH |  |
| 350 | Table 4, p. 12 | 10,600 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 10600.0 | FILE | MATCH | dashboard read, not archived |
| 351 | Table 4, p. 12 | 7,056 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 7056.0 | FILE | MATCH | dashboard read, not archived |
| 352 | Table 4, p. 12 | 1.5 | Table 4 | instrument_extra.py section 8 | 1.5 | RUN | MATCH |  |
| 353 | Table 4, p. 12 | 95 | Table 4 | instrument_extra.py section 8; age recomputed from the file | 95.0 | RUN | MATCH |  |
| 354 | Table 4, p. 12 | 102,000 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 102000.0 | FILE | MATCH | dashboard read, not archived |
| 355 | Table 4, p. 12 | 47,300 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 47300.0 | FILE | MATCH | dashboard read, not archived |
| 356 | Table 4, p. 12 | 0.46 | Table 4 | instrument_extra.py section 8 | 0.46 | RUN | MATCH |  |
| 357 | Table 4, p. 12 | 99.8% | Table 4 | instrument_extra.py section 8 | 99.8 | RUN | MATCH |  |
| 358 | Table 4, p. 12 | 0.46 | Table 4 | instrument_extra.py section 8 | 0.46 | RUN | MATCH |  |
| 359 | Table 4, p. 12 | 5,400 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 5400.0 | FILE | MATCH | dashboard read, not archived |
| 360 | Table 4, p. 12 | 31,900 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 31900.0 | FILE | MATCH | dashboard read, not archived |
| 361 | Table 4, p. 12 | 5.9 | Table 4 | instrument_extra.py section 8 | 5.9 | RUN | MATCH |  |
| 362 | Table 4, p. 12 | 258 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 258.0 | FILE | MATCH | dashboard read, not archived |
| 363 | Table 4, p. 12 | 245 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 245.0 | FILE | MATCH | dashboard read, not archived |
| 364 | Table 4, p. 12 | 1.1 | Table 4 | instrument_extra.py section 8 | 1.1 | RUN | MATCH |  |
| 365 | Table 4, p. 12 | 95 | Table 4 | instrument_extra.py section 8; age recomputed from the file | 95.0 | RUN | MATCH |  |
| 366 | Table 4, p. 12 | 644,000 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 644000.0 | FILE | MATCH | dashboard read, not archived |
| 367 | Table 4, p. 12 | 1,014,124 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 1014124.0 | FILE | MATCH | dashboard read, not archived |
| 368 | Table 4, p. 12 | 1.57 | Table 4 | instrument_extra.py section 8 | 1.57 | RUN | MATCH |  |
| 369 | Table 4, p. 12 | 98.5% | Table 4 | instrument_extra.py section 8 | 98.5 | RUN | MATCH |  |
| 370 | Table 4, p. 12 | 1.60 | Table 4 | instrument_extra.py section 8 | 1.6 | RUN | MATCH |  |
| 371 | Table 4, p. 12 | 19,800 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 19800.0 | FILE | MATCH | dashboard read, not archived |
| 372 | Table 4, p. 12 | 206,365 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 206365.0 | FILE | MATCH | dashboard read, not archived |
| 373 | Table 4, p. 12 | 10.4 | Table 4 | instrument_extra.py section 8 | 10.4 | RUN | MATCH |  |
| 374 | Table 4, p. 12 | 7,400 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 7400.0 | FILE | MATCH | dashboard read, not archived |
| 375 | Table 4, p. 12 | 3,246 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 3246.0 | FILE | MATCH | dashboard read, not archived |
| 376 | Table 4, p. 12 | 2.3 | Table 4 | instrument_extra.py section 8 | 2.3 | RUN | MATCH |  |
| 377 | Table 4, p. 12 | 114 | Table 4 | instrument_extra.py section 8; age recomputed from the file | 114.0 | RUN | MATCH |  |
| 378 | Table 4, p. 12 | 243,000 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 243000.0 | FILE | MATCH | dashboard read, not archived |
| 379 | Table 4, p. 12 | 220,600 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 220600.0 | FILE | MATCH | dashboard read, not archived |
| 380 | Table 4, p. 12 | 0.91 | Table 4 | instrument_extra.py section 8 | 0.91 | RUN | MATCH |  |
| 381 | Table 4, p. 12 | 93.6% | Table 4 | instrument_extra.py section 8 | 93.6 | RUN | MATCH |  |
| 382 | Table 4, p. 12 | 0.97 | Table 4 | instrument_extra.py section 8 | 0.97 | RUN | MATCH |  |
| 383 | Table 4, p. 12 | 13,300 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 13300.0 | FILE | MATCH | dashboard read, not archived |
| 384 | Table 4, p. 12 | 79,700 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 79700.0 | FILE | MATCH | dashboard read, not archived |
| 385 | Table 4, p. 12 | 6.0 | Table 4 | instrument_extra.py section 8 | 6.0 | RUN | MATCH |  |
| 386 | Table 4, p. 12 | 1,700 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 1700.0 | FILE | MATCH | dashboard read, not archived |
| 387 | Table 4, p. 12 | 516 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 516.0 | FILE | MATCH | dashboard read, not archived |
| 388 | Table 4, p. 12 | 3.3 | Table 4 | instrument_extra.py section 8 | 3.3 | RUN | MATCH |  |
| 389 | Table 4, p. 12 | 129 | Table 4 | instrument_extra.py section 8; age recomputed from the file | 129.0 | RUN | MATCH |  |
| 390 | Table 4, p. 12 | 312,000 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 312000.0 | FILE | MATCH | dashboard read, not archived |
| 391 | Table 4, p. 12 | 2,051,269 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 2051269.0 | FILE | MATCH | dashboard read, not archived |
| 392 | Table 4, p. 12 | 6.57 | Table 4 | instrument_extra.py section 8 | 6.57 | RUN | MATCH |  |
| 393 | Table 4, p. 12 | 99.4% | Table 4 | instrument_extra.py section 8 | 99.4 | RUN | MATCH |  |
| 394 | Table 4, p. 12 | 6.61 | Table 4 | instrument_extra.py section 8 | 6.61 | RUN | MATCH |  |
| 395 | Table 4, p. 12 | 14,700 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 14700.0 | FILE | MATCH | dashboard read, not archived |
| 396 | Table 4, p. 12 | 306,952 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 306952.0 | FILE | MATCH | dashboard read, not archived |
| 397 | Table 4, p. 12 | 20.9 | Table 4 | instrument_extra.py section 8 | 20.9 | RUN | MATCH |  |
| 398 | Table 4, p. 12 | 4,100 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 4100.0 | FILE | MATCH | dashboard read, not archived |
| 399 | Table 4, p. 12 | 3,527 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 3527.0 | FILE | MATCH | dashboard read, not archived |
| 400 | Table 4, p. 12 | 1.2 | Table 4 | instrument_extra.py section 8 | 1.2 | RUN | MATCH |  |
| 401 | Table 4, p. 12 | 132 | Table 4 | instrument_extra.py section 8; age recomputed from the file | 132.0 | RUN | MATCH |  |
| 402 | Table 4, p. 12 | 214,000 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 214000.0 | FILE | MATCH | dashboard read, not archived |
| 403 | Table 4, p. 12 | 219,600 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 219600.0 | FILE | MATCH | dashboard read, not archived |
| 404 | Table 4, p. 12 | 1.03 | Table 4 | instrument_extra.py section 8 | 1.03 | RUN | MATCH |  |
| 405 | Table 4, p. 12 | 99.3% | Table 4 | instrument_extra.py section 8 | 99.3 | RUN | MATCH |  |
| 406 | Table 4, p. 12 | 1.03 | Table 4 | instrument_extra.py section 8 | 1.03 | RUN | MATCH |  |
| 407 | Table 4, p. 12 | 5,300 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 5300.0 | FILE | MATCH | dashboard read, not archived |
| 408 | Table 4, p. 12 | 32,000 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 32000.0 | FILE | MATCH | dashboard read, not archived |
| 409 | Table 4, p. 12 | 6.0 | Table 4 | instrument_extra.py section 8 | 6.0 | RUN | MATCH |  |
| 410 | Table 4, p. 12 | 1,600 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 1600.0 | FILE | MATCH | dashboard read, not archived |
| 411 | Table 4, p. 12 | 2,042 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 2042.0 | FILE | MATCH | dashboard read, not archived |
| 412 | Table 4, p. 12 | 0.8 | Table 4 | instrument_extra.py section 8 | 0.8 | RUN | MATCH |  |
| 413 | Table 4, p. 12 | 133 | Table 4 | instrument_extra.py section 8; age recomputed from the file | 133.0 | RUN | MATCH |  |
| 414 | Table 4, p. 12 | 8,900 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 8900.0 | FILE | MATCH | dashboard read, not archived |
| 415 | Table 4, p. 12 | 2,200 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 2200.0 | FILE | MATCH | dashboard read, not archived |
| 416 | Table 4, p. 12 | 0.25 | Table 4 | instrument_extra.py section 8 | 0.25 | RUN | MATCH |  |
| 417 | Table 4, p. 12 | 42.6% | Table 4 | instrument_extra.py section 8 | 42.6 | RUN | MATCH |  |
| 418 | Table 4, p. 12 | 0.58 | Table 4 | instrument_extra.py section 8 | 0.58 | RUN | MATCH |  |
| 419 | Table 4, p. 12 | 1,300 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 1300.0 | FILE | MATCH | dashboard read, not archived |
| 420 | Table 4, p. 12 | 4,800 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 4800.0 | FILE | MATCH | dashboard read, not archived |
| 421 | Table 4, p. 12 | 3.7 | Table 4 | instrument_extra.py section 8 | 3.7 | RUN | MATCH |  |
| 422 | Table 4, p. 12 | 284 | Table 4 | data/ahrefs_prefixes_2026-10-12.csv | 284.0 | FILE | MATCH | dashboard read, not archived |
| 423 | Table 4, p. 12 | 62 | Table 4 | data/semrush_prefixes_2026-10-12.csv | 62.0 | FILE | MATCH | dashboard read, not archived |
| 424 | Table 4, p. 12 | 4.6 | Table 4 | instrument_extra.py section 8 | 4.6 | RUN | MATCH |  |
| 425 | Figure 5, p. 12 | −0.11 | printed inside fig4_prefixes.pdf | data/analyze.py | -0.11 | RUN | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 426 | §5.5, p. 12 | Twelve | 4,800 \| 3.7 \| 284 \| 62 \| 4.6 \| ![Figure 5. Twelve URL prefixes on one domain, b | data/analyze.py | 12.0 | RUN | MATCH |  |
| 427 | §5.5, p. 11 | −0.11 | etween age and the unmatched visits ratio is −0.11 over twelve prefixes, with a | data/analyze.py | -0.11 | RUN | MATCH |  |
| 428 | §5.5, p. 11 | twelve | and the unmatched visits ratio is −0.11 over twelve prefixes, with a Fisher 95% i | data/analyze.py | 12.0 | RUN | MATCH |  |
| 429 | §5.5, p. 11 | −0.64 | elve prefixes, with a Fisher 95% interval of −0.64 to +0.49 and a permutation p | data/analyze.py | -0.64 | RUN | MATCH |  |
| 430 | §5.5, p. 11 | +0.49 | ixes, with a Fisher 95% interval of −0.64 to +0.49 and a permutation p of 0.73; | data/analyze.py | 0.49 | RUN | MATCH |  |
| 431 | §5.5, p. 11 | 0.73 | val of −0.64 to +0.49 and a permutation p of 0.73; territory-matched it is −0.2 | data/analyze.py | 0.73 | RUN | MATCH |  |
| 432 | §5.5, p. 11 | −0.28 | rmutation p of 0.73; territory-matched it is −0.28; excluding the area-code sect | data/analyze.py | -0.28 | RUN | MATCH |  |
| 433 | §5.5, p. 11 | +0.15 | −0.28; excluding the area-code section it is +0.15. Twelve prefixes give about 3 | data/analyze.py | 0.15 | RUN | MATCH |  |
| 434 | §5.5, p. 11 | Twelve | excluding the area-code section it is +0.15. Twelve prefixes give about 38% power | data/analyze.py | 12.0 | RUN | MATCH |  |
| 435 | §5.5, p. 11 | 38 | tion it is +0.15. Twelve prefixes give about 38% power to detect a correlatio | data/analyze.py | 38.0 | RUN | MATCH |  |
| 436 | §5.5, p. 11 | 0.5 | e about 38% power to detect a correlation of 0.5 (37.8% by the Fisher approxim | instrument_extra.py | 0.5 | RUN | MATCH | the alternative named in the printed line |
| 437 | §5.5, p. 11 | 37.8 | ut 38% power to detect a correlation of 0.5 (37.8% by the Fisher approximation) | instrument_extra.py | 37.8 | RUN | MATCH |  |
| 438 | §5.5, p. 11 | seven | common value as sections mature, because the seven sections aged between seven a | instrument_extra.py | 7.0 | RUN | MATCH |  |
| 439 | §5.5, p. 11 | eleven | se the seven sections aged between seven and eleven years sit anywhere from 0.25x | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 440 | §5.5, p. 11 | 0.25 | een seven and eleven years sit anywhere from 0.25x to 6.57x unmatched (0.46x to | instrument_extra.py | 0.25 | RUN | MATCH |  |
| 441 | §5.5, p. 11 | 6.57 | and eleven years sit anywhere from 0.25x to 6.57x unmatched (0.46x to 6.61x ma | instrument_extra.py | 6.57 | RUN | MATCH |  |
| 442 | §5.5, p. 11 | 0.46 | sit anywhere from 0.25x to 6.57x unmatched (0.46x to 6.61x matched). The age h | instrument_extra.py | 0.46 | RUN | MATCH |  |
| 443 | §5.5, p. 11 | 6.61 | here from 0.25x to 6.57x unmatched (0.46x to 6.61x matched). The age hypothesis | instrument_extra.py | 6.61 | RUN | MATCH |  |
| 444 | §5.5, p. 11 | 27.1 | nd the narrowing of the area-code ratio from 27.1x to 7.5x over three months is | arithmetic on Table 2 / its released CSV | 27.141445 | CALC | MATCH |  |
| 445 | §5.5, p. 11 | 7.5 | rrowing of the area-code ratio from 27.1x to 7.5x over three months is reporte | arithmetic on Table 2 / its released CSV | 7.469647 | CALC | MATCH |  |
| 446 | §5.5, p. 11 | one | tion on one section and not attributed. Only one prefix in the cross-section i | instrument_extra.py | 1.0 | RUN | MATCH |  |
| 447 | §5.5, p. 11 | 0.20 | from one fifth of Ahrefs' (/local/bundles/, 0.20x) to seven times it (/local/a | data/analyze.py | 0.2 | RUN | MATCH |  |
| 448 | §5.5, p. 11 | 7.24 | .20x) to seven times it (/local/area-codes/, 7.24x), a spread of 1.55 orders of | data/analyze.py | 7.24 | RUN | MATCH |  |
| 449 | §5.5, p. 11 | 1.55 | it (/local/area-codes/, 7.24x), a spread of 1.55 orders of magnitude, with a m | data/analyze.py | 1.55 | RUN | MATCH |  |
| 450 | §5.5, p. 11 | 1.01 | f 1.55 orders of magnitude, with a median of 1.01 and six of twelve prefixes be | data/analyze.py | 1.01 | RUN | MATCH |  |
| 451 | §5.5, p. 11 | six | ders of magnitude, with a median of 1.01 and six of twelve prefixes below one. | data/analyze.py | 6.0 | RUN | MATCH |  |
| 452 | §5.5, p. 11 | twelve | magnitude, with a median of 1.01 and six of twelve prefixes below one. Matched f | data/analyze.py | 12.0 | RUN | MATCH |  |
| 453 | §5.5, p. 11 | 0.20 | . Matched for territory the spread is wider (0.20x to 8.89x), the median is 1.0 | data/analyze.py | 0.2 | RUN | MATCH |  |
| 454 | §5.5, p. 11 | 8.89 | for territory the spread is wider (0.20x to 8.89x), the median is 1.06, and fo | data/analyze.py | 8.89 | RUN | MATCH |  |
| 455 | §5.5, p. 11 | 1.06 | ead is wider (0.20x to 8.89x), the median is 1.06, and four of twelve are below | data/analyze.py | 1.06 | RUN | MATCH |  |
| 456 | §5.5, p. 11 | four | er (0.20x to 8.89x), the median is 1.06, and four of twelve are below one, beca | data/analyze.py | 4.0 | RUN | MATCH |  |
| 457 | §5.5, p. 11 | twelve | x to 8.89x), the median is 1.06, and four of twelve are below one, because two of | data/analyze.py | 12.0 | RUN | MATCH |  |
| 458 | §5.5, p. 11 | two | 6, and four of twelve are below one, because two of the six sub-one prefixes c | /product-compare/ and /device-compare/ cross one when matched | 2.0 | CALC | MATCH |  |
| 459 | §5.5, p. 11 | six | of twelve are below one, because two of the six sub-one prefixes cross one on | data/analyze.py | 6.0 | RUN | MATCH |  |
| 460 | §5.5, p. 11 | 69.6 | on-US traffic is removed (/product-compare/, 69.6% US, from 0.75x to 1.07x; /de | data/ahrefs_prefixes_2026-10-12.csv | 69.6 | FILE | MATCH | dashboard read |
| 461 | §5.5, p. 11 | 0.75 | s removed (/product-compare/, 69.6% US, from 0.75x to 1.07x; /device-compare/, | data/*.csv, ratio recomputed | 0.745455 | CALC | MATCH |  |
| 462 | §5.5, p. 11 | 1.07 | (/product-compare/, 69.6% US, from 0.75x to 1.07x; /device-compare/, 82.6% US, | data/*.csv, ratio recomputed | 1.071055 | CALC | MATCH |  |
| 463 | §5.5, p. 11 | 82.6 | % US, from 0.75x to 1.07x; /device-compare/, 82.6% US, from 0.99x to 1.20x); /e | data/ahrefs_prefixes_2026-10-12.csv | 82.6 | FILE | MATCH | dashboard read |
| 464 | §5.5, p. 11 | 0.99 | x to 1.07x; /device-compare/, 82.6% US, from 0.99x to 1.20x); /es-us/local/, at | data/*.csv, ratio recomputed | 0.988764 | CALC | MATCH |  |
| 465 | §5.5, p. 11 | 1.20 | x; /device-compare/, 82.6% US, from 0.99x to 1.20x); /es-us/local/, at 42.6% US | data/*.csv, ratio recomputed | 1.197051 | CALC | MATCH |  |
| 466 | §5.5, p. 11 | 42.6 | US, from 0.99x to 1.20x); /es-us/local/, at 42.6% US, moves from 0.25x to 0.58 | data/ahrefs_prefixes_2026-10-12.csv | 42.6 | FILE | MATCH | dashboard read |
| 467 | §5.5, p. 11 | 0.25 | 20x); /es-us/local/, at 42.6% US, moves from 0.25x to 0.58x and stays below one | data/*.csv, ratio recomputed | 0.247191 | CALC | MATCH |  |
| 468 | §5.5, p. 11 | 0.58 | -us/local/, at 42.6% US, moves from 0.25x to 0.58x and stays below one. The ter | data/*.csv, ratio recomputed | 0.580261 | CALC | MATCH |  |
| 469 | §5.5, p. 11 | twelve | or maps one onto the other. Taken across the twelve, the unmatched ratio has a ge | data/analyze.py | 12.0 | RUN | MATCH |  |
| 470 | §5.5, p. 11 | 1.13 | the unmatched ratio has a geometric mean of 1.13 (bootstrap 95% interval 0.62 | instrument_extra.py | 1.13 | RUN | MATCH |  |
| 471 | §5.5, p. 11 | 0.62 | ometric mean of 1.13 (bootstrap 95% interval 0.62 to 2.12) and a geometric stan | instrument_extra.py | 0.62 | RUN | MATCH |  |
| 472 | §5.5, p. 11 | 2.12 | mean of 1.13 (bootstrap 95% interval 0.62 to 2.12) and a geometric standard dev | instrument_extra.py | 2.12 | RUN | MATCH |  |
| 473 | §5.5, p. 11 | 3.1 | 2.12) and a geometric standard deviation of 3.1 (1.9 to 4.1), a normal range | instrument_extra.py | 3.13 | RUN | MATCH |  |
| 474 | §5.5, p. 11 | 1.9 | ) and a geometric standard deviation of 3.1 (1.9 to 4.1), a normal range on th | instrument_extra.py | 1.92 | RUN | MATCH |  |
| 475 | §5.5, p. 11 | 4.1 | geometric standard deviation of 3.1 (1.9 to 4.1), a normal range on the log s | instrument_extra.py | 4.14 | RUN | MATCH |  |
| 476 | §5.5, p. 11 | 0.12 | 1), a normal range on the log scale of about 0.12x to 10.6x; with twelve purpos | instrument_extra.py | 0.12 | RUN | MATCH |  |
| 477 | §5.5, p. 11 | 10.6 | mal range on the log scale of about 0.12x to 10.6x; with twelve purposively cho | instrument_extra.py | 10.61 | RUN | MATCH |  |
| 478 | §5.5, p. 11 | twelve | the log scale of about 0.12x to 10.6x; with twelve purposively chosen sections t | data/analyze.py | 12.0 | RUN | MATCH |  |
| 479 | §5.5, p. 11 | twelve | d disagree on their magnitudes.** Across the twelve prefixes, the rank correlatio | data/analyze.py | 12.0 | RUN | MATCH |  |
| 480 | §5.5, p. 11 | +0.94 | ween the two instruments' visit estimates is +0.94 (bootstrap 95% interval over | data/analyze.py | 0.94 | RUN | MATCH |  |
| 481 | §5.5, p. 11 | +0.70 | +0.94 (bootstrap 95% interval over prefixes +0.70 to +1.00; p < 0.001; Kendall' | instrument_extra.py | 0.7 | RUN | MATCH |  |
| 482 | §5.5, p. 11 | +1.00 | ootstrap 95% interval over prefixes +0.70 to +1.00; p < 0.001; Kendall's tau +0. | instrument_extra.py | 1.0 | RUN | MATCH |  |
| 483 | §5.5, p. 11 | 0.001 | % interval over prefixes +0.70 to +1.00; p < 0.001; Kendall's tau +0.82, interva | instrument_extra.py | 7e-06 | RUN | MATCH | paper says p < 0.001; the script prints p=7e-06 |
| 484 | §5.5, p. 11 | +0.82 | xes +0.70 to +1.00; p < 0.001; Kendall's tau +0.82, interval +0.57 to +1.00; 60 | data/analyze.py | 0.82 | RUN | MATCH |  |
| 485 | §5.5, p. 11 | +0.57 | 00; p < 0.001; Kendall's tau +0.82, interval +0.57 to +1.00; 60 of 66 pairs conc | instrument_extra.py | 0.57 | RUN | MATCH |  |
| 486 | §5.5, p. 11 | +1.00 | .001; Kendall's tau +0.82, interval +0.57 to +1.00; 60 of 66 pairs concordant). | instrument_extra.py | 1.0 | RUN | MATCH |  |
| 487 | §5.5, p. 11 | 60 | endall's tau +0.82, interval +0.57 to +1.00; 60 of 66 pairs concordant). The | data/analyze.py | 60.0 | RUN | MATCH |  |
| 488 | §5.5, p. 11 | 66 | 's tau +0.82, interval +0.57 to +1.00; 60 of 66 pairs concordant). The vendor | data/analyze.py | 66.0 | RUN | MATCH |  |
| 489 | §5.5, p. 11 | 60 | vendors agree on which section is larger in 60 of 66 pairs; what has unknown | data/analyze.py | 60.0 | RUN | MATCH |  |
| 490 | §5.5, p. 11 | 66 | rs agree on which section is larger in 60 of 66 pairs; what has unknown sign | data/analyze.py | 66.0 | RUN | MATCH |  |
| 491 | §5.5, p. 11 | 51 | , differ by more than a factor of three, all 51 are ordered alike; of the 15 | instrument_extra.py | 51 | RUN | MATCH | 19 + 32 printed in two bands |
| 492 | §5.5, p. 11 | 15 | r of three, all 51 are ordered alike; of the 15 pairs within a factor of thre | instrument_extra.py | 15.0 | RUN | MATCH |  |
| 493 | §5.5, p. 11 | 9 | e; of the 15 pairs within a factor of three, 9 are. Read by the factor on ea | instrument_extra.py | 9.0 | RUN | MATCH |  |
| 494 | §5.5, p. 11 | 40 | y the factor on each instrument instead, all 40 pairs more than three times a | instrument_extra.py | 40.0 | RUN | MATCH |  |
| 495 | §5.5, p. 11 | 16 | imes apart on both are ordered alike, as are 16 of the 18 more than three tim | instrument_extra.py | 16.0 | RUN | MATCH |  |
| 496 | §5.5, p. 11 | 18 | on both are ordered alike, as are 16 of the 18 more than three times apart o | instrument_extra.py | 18.0 | RUN | MATCH |  |
| 497 | §5.5, p. 11 | the other two are six to seven times apart on one instrument and about equal on the other | e times apart on exactly one (the other two are six to seven times apart on one instrument and about equal on the other) and 4 of the 8 wit | instrument_extra.py section 10: 7.25x and 6.09x on one, 1.10x and 1.05x on the other | agrees | RUN | MATCH | statement in words |
| 498 | §5.5, p. 11 | 4 | instrument and about equal on the other) and 4 of the 8 within a factor of t | instrument_extra.py | 4.0 | RUN | MATCH |  |
| 499 | §5.5, p. 11 | 8 | t and about equal on the other) and 4 of the 8 within a factor of three on b | instrument_extra.py | 8.0 | RUN | MATCH |  |
| 500 | §5.5, p. 11 | Semrush reports more ranking keywords than Ahrefs on every prefix | timates do not follow them.** Semrush reports more ranking keywords than Ahrefs on every prefix, by between 2.0x an | data/*.csv | agrees | CALC | MATCH | statement in words |
| 501 | §5.5, p. 11 | 2.0 | ords than Ahrefs on every prefix, by between 2.0x and 20.9x. The rank correlat | data/analyze.py | 2.0 | RUN | MATCH |  |
| 502 | §5.5, p. 11 | 20.9 | Ahrefs on every prefix, by between 2.0x and 20.9x. The rank correlation betwee | data/analyze.py | 20.9 | RUN | MATCH |  |
| 503 | §5.5, p. 11 | +0.17 | en the keyword ratio and the visits ratio is +0.17 over all twelve, and +0.52 wi | data/analyze.py | 0.17 | RUN | MATCH |  |
| 504 | §5.5, p. 11 | twelve | ratio and the visits ratio is +0.17 over all twelve, and +0.52 with the area-code | data/analyze.py | 12.0 | RUN | MATCH |  |
| 505 | §5.5, p. 11 | +0.52 | e visits ratio is +0.17 over all twelve, and +0.52 with the area-code section ex | data/analyze.py | 0.52 | RUN | MATCH |  |
| 506 | §5.5, p. 11 | 16.1 | ndles/ has the second-largest keyword ratio (16.1x) and the smallest visits rat | instrument_extra.py | 16.1 | RUN | MATCH |  |
| 507 | §5.5, p. 12 | 0.20 | ratio (16.1x) and the smallest visits ratio (0.20x). Across sections, then, the | data/analyze.py | 0.2 | RUN | MATCH |  |
| 508 | §5.5, p. 12 | 0.60 | ionship with the visits ratio (two-sided p = 0.60 over all twelve and 0.10 with | instrument_extra.py | 0.6 | RUN | MATCH |  |
| 509 | §5.5, p. 12 | twelve | he visits ratio (two-sided p = 0.60 over all twelve and 0.10 without the area-cod | data/analyze.py | 12.0 | RUN | MATCH |  |
| 510 | §5.5, p. 12 | 0.10 | atio (two-sided p = 0.60 over all twelve and 0.10 without the area-code section | instrument_extra.py | 0.1 | RUN | MATCH |  |
| 511 | §5.5, p. 12 | 7.24 | ree most.** It has the highest visits ratio (7.24x unmatched, 8.89x matched; /s | data/analyze.py | 7.24 | RUN | MATCH |  |
| 512 | §5.5, p. 12 | 8.89 | s the highest visits ratio (7.24x unmatched, 8.89x matched; /stores/ is next at | data/analyze.py | 8.89 | RUN | MATCH |  |
| 513 | §5.5, p. 12 | 6.57 | nmatched, 8.89x matched; /stores/ is next at 6.57x) and the highest referring-d | data/analyze.py | 6.57 | RUN | MATCH |  |
| 514 | §5.5, p. 12 | 11.3 | 57x) and the highest referring-domain ratio (11.3x) of the twelve. The referrin | instrument_extra.py | 11.3 | RUN | MATCH |  |
| 515 | §5.5, p. 12 | twelve | ighest referring-domain ratio (11.3x) of the twelve. The referring-domain outlier | data/analyze.py | 12.0 | RUN | MATCH |  |
| 516 | §5.5, p. 13 | 158.3K | ng.** Semrush's AI-visibility panel reported 158.3K mentions and 29.5K cited page | single_reads_2026-10.csv (158.3K) | 158300.0 | FILE | MATCH | dashboard read, not archived |
| 517 | §5.5, p. 13 | 29.5K | isibility panel reported 158.3K mentions and 29.5K cited pages for every one of | single_reads_2026-10.csv (29.5K) | 29500.0 | FILE | MATCH | dashboard read, not archived |
| 518 | §5.5, p. 13 | twelve | s and 29.5K cited pages for every one of the twelve subfolders, identically, on 1 | data/analyze.py | 12.0 | RUN | MATCH |  |
| 519 | §5.5, p. 13 | 158,100 | r (Section 5.3 quotes the 10 October read of 158,100 and 29,600). Those figures ar | single_reads_2026-10.csv | 158100.0 | FILE | MATCH | dashboard read, not archived |
| 520 | §5.5, p. 13 | 29,600 | .3 quotes the 10 October read of 158,100 and 29,600). Those figures are domain-sc | single_reads_2026-10.csv | 29600.0 | FILE | MATCH | dashboard read, not archived |
| 521 | §5.5, p. 13 | Twelve | e compared at the prefix level. **Limits.** Twelve prefixes, one domain, one rea | data/analyze.py | 12.0 | RUN | MATCH |  |
| 522 | §5.5, p. 13 | one | efix and close to that horizon for two more; one prefix under twenty-one month | instrument_extra.py | 1.0 | RUN | MATCH |  |
| 523 | §5.6, p. 13 | 27.1 | − T\|) ≥ \|A − B\| / 2. At the August ratio of 27.1x, the two readings cannot bot | arithmetic on Table 2 / its released CSV | 27.141445 | CALC | MATCH |  |
| 524 | §5.6, p. 13 | 5.2 | readings cannot both lie within a factor of 5.2, the square root of 27.1, of | reproducer's recomputation (recompute.py) | 5.209745 | CALC | MATCH |  |
| 525 | §5.6, p. 13 | 27.1 | e within a factor of 5.2, the square root of 27.1, of the true value, so at lea | arithmetic on Table 2 / its released CSV | 27.141445 | CALC | MATCH |  |
| 526 | §5.6, p. 13 | 13 | er: the larger of the two errors is at least 13 times the smaller reading. Th | reproducer's recomputation (recompute.py) | 13.070723 | CALC | MATCH |  |
| 527 | §5.6, p. 13 | 27.1 | does and does not support.** The ratio falls 27.1 → 10.2 → 7.5 over three month | arithmetic on Table 2 / its released CSV | 27.141445 | CALC | MATCH |  |
| 528 | §5.6, p. 13 | 10.2 | d does not support.** The ratio falls 27.1 → 10.2 → 7.5 over three months on th | arithmetic on Table 2 / its released CSV | 10.22138 | CALC | MATCH |  |
| 529 | §5.6, p. 13 | 7.5 | not support.** The ratio falls 27.1 → 10.2 → 7.5 over three months on this pre | arithmetic on Table 2 / its released CSV | 7.469647 | CALC | MATCH |  |
| 530 | §5.6, p. 13 | twelve | the hypothesis; Section 5.5 tested it across twelve prefixes and found no detecta | data/analyze.py | 12.0 | RUN | MATCH |  |
| 531 | §5.6, p. 13 | 7.47 | nd 11 October, the divergence decomposes as 7.47x = 2.02x (keyword universe) × | instrument_extra.py | 7.47 | RUN | MATCH |  |
| 532 | §5.6, p. 13 | 2.02 | tober, the divergence decomposes as 7.47x = 2.02x (keyword universe) × 3.70x ( | instrument_extra.py | 2.02 | RUN | MATCH |  |
| 533 | §5.6, p. 13 | 3.70 | poses as 7.47x = 2.02x (keyword universe) × 3.70x (estimated visits per rankin | instrument_extra.py | 3.7 | RUN | MATCH |  |
| 534 | §5.6, p. 13 | 35 | so the keyword universe accounts for about 35% of the divergence in log ter | instrument_extra.py | 35.0 | RUN | MATCH |  |
| 535 | §5.6, p. 13 | 8.62 | rldwide (keywords read on 12 October), it is 8.62x = 3.19x (keyword universe) × | instrument_extra.py | 8.62 | RUN | MATCH |  |
| 536 | §5.6, p. 13 | 3.19 | (keywords read on 12 October), it is 8.62x = 3.19x (keyword universe) × 2.70x ( | instrument_extra.py | 3.19 | RUN | MATCH |  |
| 537 | §5.6, p. 13 | 2.70 | r), it is 8.62x = 3.19x (keyword universe) × 2.70x (per keyword), and the keywo | instrument_extra.py | 2.7 | RUN | MATCH |  |
| 538 | §5.6, p. 13 | 54 | and the keyword universe accounts for about 54%. How Semrush aggregates its | instrument_extra.py | 54.0 | RUN | MATCH |  |
| 539 | §5.6, p. 13 | 8.62 | ative. Matching worldwide to worldwide gives 8.62x for October and 26.7x to 29. | instrument_extra.py | 8.62 | RUN | MATCH |  |
| 540 | §5.6, p. 13 | 26.7 | ide to worldwide gives 8.62x for October and 26.7x to 29.9x in the first two mo | arithmetic on Table 2 / its released CSV | 26.681771 | CALC | MATCH |  |
| 541 | §5.6, p. 13 | 29.9 | rldwide gives 8.62x for October and 26.7x to 29.9x in the first two months (Tab | arithmetic on Table 2 / its released CSV | 29.860816 | CALC | MATCH |  |
| 542 | §5.6, p. 13 | 18.5 | US to US, deflating the Ahrefs figure by the 18.5% non-US share of its own esti | single_reads_2026-10.csv | 18.5 | FILE | MATCH | dashboard read, not archived |
| 543 | §5.6, p. 13 | 9.17 | S share of its own estimated visits, gives **9.17x** for October against the 7. | arithmetic on Table 2 / its released CSV | 9.165211 | CALC | MATCH |  |
| 544 | §5.6, p. 13 | 7.5 | its, gives **9.17x** for October against the 7.5x unmatched. Applying the same | arithmetic on Table 2 / its released CSV | 7.469647 | CALC | MATCH |  |
| 545 | §5.6, p. 13 | 31.8 | me share to July, August and September gives 31.8x, 33.3x and 12.5x (Table 2); | arithmetic on Table 2 / its released CSV | 31.774757 | CALC | MATCH |  |
| 546 | §5.6, p. 13 | 33.3 | e to July, August and September gives 31.8x, 33.3x and 12.5x (Table 2); the sha | arithmetic on Table 2 / its released CSV | 33.302387 | CALC | MATCH |  |
| 547 | §5.6, p. 13 | 12.5 | August and September gives 31.8x, 33.3x and 12.5x (Table 2); the share was rea | arithmetic on Table 2 / its released CSV | 12.54157 | CALC | MATCH |  |
| 548 | §5.6, p. 13 | twelve | nding that bears on it most directly. Across twelve sections of one domain the ve | data/analyze.py | 12.0 | RUN | MATCH |  |
| 549 | §5.6, p. 13 | 0.20 | n the vendor ratio on estimated visits spans 0.20x to 7.24x (0.20x to 8.89x ter | data/analyze.py | 0.2 | RUN | MATCH |  |
| 550 | §5.6, p. 13 | 7.24 | dor ratio on estimated visits spans 0.20x to 7.24x (0.20x to 8.89x territory-ma | data/analyze.py | 7.24 | RUN | MATCH |  |
| 551 | §5.6, p. 13 | 0.20 | io on estimated visits spans 0.20x to 7.24x (0.20x to 8.89x territory-matched), | data/analyze.py | 0.2 | RUN | MATCH |  |
| 552 | §5.6, p. 13 | 8.89 | imated visits spans 0.20x to 7.24x (0.20x to 8.89x territory-matched), so no do | data/analyze.py | 8.89 | RUN | MATCH |  |
| 553 | §5.6, p. 13 | 60 | agree on which of two sections is larger in 60 of 66 pairs, so a single-vend | data/analyze.py | 60.0 | RUN | MATCH |  |
| 554 | §5.6, p. 13 | 66 | on which of two sections is larger in 60 of 66 pairs, so a single-vendor ran | data/analyze.py | 66.0 | RUN | MATCH |  |
| 555 | §5.6, p. 13 | 40 | differ several-fold on both instruments (all 40 pairs more than three times a | instrument_extra.py | 40.0 | RUN | MATCH |  |
| 556 | §5.6, p. 13 | 9 | on both) and less often when they are close (9 of the 15 pairs within a fact | instrument_extra.py | 9.0 | RUN | MATCH |  |
| 557 | §5.6, p. 13 | 15 | and less often when they are close (9 of the 15 pairs within a factor of thre | instrument_extra.py | 15.0 | RUN | MATCH |  |
| 558 | §5.6, p. 13 | two pairs six to seven times apart were ordered the other way | ured on one instrument alone, two pairs six to seven times apart were ordered the other way on the second; the | instrument_extra.py section 10 | agrees | RUN | MATCH | statement in words |
| 559 | §5.6, p. 13 | can differ by a factor of five below to nearly nine above | other section's on the other, can differ by a factor of five below to nearly nine above. Growth measured on | analyze.py: 0.20x and 8.89x | agrees | RUN | MATCH | statement in words |
| 560 | §5.6, p. 13 | by a factor of five below to nearly nine above | on's on the other, can differ by a factor of five below to nearly nine above. Growth measured on | analyze.py: 0.20x and 8.89x | agrees | RUN | MATCH | statement in words |
| 561 | §5.6, p. 13 | 2.7 | wo instruments also differed, by a factor of 2.7 in one month (Section 5.1). B | instrument_extra.py | 2.66 | RUN | MATCH |  |
| 562 | §5.6, p. 14 | 77 | ; the longitudinal series is one prefix over 77 days and the cross-section is | 26 July to 11 October 2026 by the calendar | 77.0 | CALC | MATCH |  |
| 563 | §5.6, p. 14 | twelve | prefix over 77 days and the cross-section is twelve prefixes on one date. What is | data/analyze.py | 12.0 | RUN | MATCH |  |
| 564 | §5.6, p. 14 | from a factor of five below to nearly nine above | between sections of one site, from a factor of five below to nearly nine above, that no relationsh | analyze.py: 0.20x and 8.89x | agrees | RUN | MATCH | statement in words |
| 565 | §5.6, p. 14 | twelve | onship with section age is detectable across twelve sections, only one of them un | data/analyze.py | 12.0 | RUN | MATCH |  |
| 566 | §5.6, p. 14 | one | e is detectable across twelve sections, only one of them under twenty-one mont | instrument_extra.py | 1.0 | RUN | MATCH |  |
| 567 | §6.1, p. 14 | 47,485 | e same industry allows a first run. It holds 47,485 Google reviews of 379 retail | supplement_r10.py (saved output) | 47485.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 568 | §6.1, p. 14 | 379 | first run. It holds 47,485 Google reviews of 379 retail locations of major US | supplement_r10.py (saved output) | 379.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 569 | §6.1, p. 14 | 37,193 | e and exported on 8 September 2026, of which 37,193 carry text, at 378 of the loc | supplement_r10.py (saved output) | 37193.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 570 | §6.1, p. 14 | 378 | ptember 2026, of which 37,193 carry text, at 378 of the locations. The rule by | supplement_r10.py (saved output) | 378.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 571 | §6.1, p. 14 | 1 | n was not recorded. The export holds between 1 and 201 reviews per location | supplement_r10.py (saved output) | 1.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 572 | §6.1, p. 14 | 201 | not recorded. The export holds between 1 and 201 reviews per location (median | supplement_r10.py (saved output) | 201.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 573 | §6.1, p. 14 | 145 | tween 1 and 201 reviews per location (median 145) and dates reviews only relat | supplement_r10.py (saved output) | 145.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 574 | §6.1, p. 14 | 26 | wn; where owner responses name a carrier, at 26 locations, they name five dif | supplement_r10.py (saved output) | 26.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 575 | §6.1, p. 14 | 42,994 | ame five different carriers. It also holds a 42,994-node telecom taxonomy built b | supplement_r10.py (saved output) | 42994.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 576 | §6.1, p. 14 | 1,898,584 | built by the author's clustering engine from 1,898,584 keywords, each node carrying | supplement_r10.py (saved output) | 1898584.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 577 | §6.1, p. 14 | 37,193 | the sum over the nodes that carry it. Of the 37,193 reviews, 20,663 (55.6%) linke | supplement_r10.py (saved output) | 37193.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 578 | §6.1, p. 14 | 20,663 | nodes that carry it. Of the 37,193 reviews, 20,663 (55.6%) linked to at least on | analyze_reviews.py (saved output) | 20663.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 579 | §6.1, p. 14 | 55.6 | hat carry it. Of the 37,193 reviews, 20,663 (55.6%) linked to at least one of 2 | analyze_reviews.py (saved output) | 55.6 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 580 | §6.1, p. 14 | 27,817 | ws, 20,663 (55.6%) linked to at least one of 27,817 linkable labels, at 2.25 labe | m2_from_counts.py | 27817.0 | RUN | MATCH |  |
| 581 | §6.1, p. 14 | 2.25 | o at least one of 27,817 linkable labels, at 2.25 labels per linked review, and | analyze_reviews.py (saved output) | 2.25 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 582 | §6.1, p. 14 | 1,008 | abels, at 2.25 labels per linked review, and 1,008 labels were mentioned at leas | m2_from_counts.py | 1008.0 | RUN | MATCH |  |
| 583 | §6.1, p. 14 | 17 | least once. At the level of the taxonomy's 17 top-level branches the two si | m2_from_counts.py | 17.0 | RUN | MATCH |  |
| 584 | §6.1, p. 14 | +0.75 | tions and the share of search volume is then +0.75 (bootstrap 95% interval over | m2_from_counts.py | 0.748 | RUN | MATCH |  |
| 585 | §6.1, p. 14 | +0.44 | +0.75 (bootstrap 95% interval over branches +0.44 to +0.90; p < 0.001, 17 branc | m2_from_counts.py | 0.443 | RUN | MATCH |  |
| 586 | §6.1, p. 14 | +0.90 | ootstrap 95% interval over branches +0.44 to +0.90; p < 0.001, 17 branches; Figu | m2_from_counts.py | 0.9 | RUN | MATCH |  |
| 587 | §6.1, p. 14 | 0.001 | % interval over branches +0.44 to +0.90; p < 0.001, 17 branches; Figure 6b), and | m2_from_counts.py | 0.00056 | RUN | MATCH | paper says p < 0.001; the script prints p=0.00056 |
| 588 | §6.1, p. 14 | 17 | val over branches +0.44 to +0.90; p < 0.001, 17 branches; Figure 6b), and +0. | m2_from_counts.py | 17.0 | RUN | MATCH |  |
| 589 | §6.1, p. 14 | +0.47 | .90; p < 0.001, 17 branches; Figure 6b), and +0.47 (+0.01 to +0.78; p = 0.06) if | m2_from_counts.py | 0.468 | RUN | MATCH |  |
| 590 | §6.1, p. 14 | +0.01 | < 0.001, 17 branches; Figure 6b), and +0.47 (+0.01 to +0.78; p = 0.06) if each l | m2_from_counts.py | 0.006 | RUN | MATCH |  |
| 591 | §6.1, p. 14 | +0.78 | 17 branches; Figure 6b), and +0.47 (+0.01 to +0.78; p = 0.06) if each label's me | m2_from_counts.py | 0.783 | RUN | MATCH |  |
| 592 | §6.1, p. 14 | 0.06 | ; Figure 6b), and +0.47 (+0.01 to +0.78; p = 0.06) if each label's mentions go | m2_from_counts.py | 0.058 | RUN | MATCH |  |
| 593 | §6.1, p. 14 | +0.78 | s is attributed. An earlier computation gave +0.78; it summed nested volumes ove | analyze_reviews.py (saved output) | 0.777 | SAVED | CANNOT RUN | the superseded computation, still printed by that script; agrees with the saved output; the script that prints it needs withheld data |
| 594 | §6.1, p. 14 | 66.8 | ded. The shares differ widely: carriers draw 66.8% of review mentions and 14.9% | m2_from_counts.py | 66.8 | RUN | MATCH |  |
| 595 | §6.1, p. 14 | 14.9 | : carriers draw 66.8% of review mentions and 14.9% of search volume, devices 11 | m2_from_counts.py | 14.9 | RUN | MATCH |  |
| 596 | §6.1, p. 14 | 11.0 | mentions and 14.9% of search volume, devices 11.0% and 32.7%, broadband 4.0% an | m2_from_counts.py | 11.0 | RUN | MATCH |  |
| 597 | §6.1, p. 14 | 32.7 | nd 14.9% of search volume, devices 11.0% and 32.7%, broadband 4.0% and 18.1%. A | m2_from_counts.py | 32.7 | RUN | MATCH |  |
| 598 | §6.1, p. 14 | 4.0 | h volume, devices 11.0% and 32.7%, broadband 4.0% and 18.1%. At the level of t | m2_from_counts.py | 4.0 | RUN | MATCH |  |
| 599 | §6.1, p. 14 | 18.1 | devices 11.0% and 32.7%, broadband 4.0% and 18.1%. At the level of topics the | m2_from_counts.py | 18.1 | RUN | MATCH |  |
| 600 | §6.1, p. 14 | 1,008 | l of topics the two barely agree. Across the 1,008 labels that at least one revi | m2_from_counts.py | 1008.0 | RUN | MATCH |  |
| 601 | §6.1, p. 14 | +0.18 | etween review mentions and monthly volume is +0.18 (bootstrap 95% interval over | m2_label_counts.csv, to five decimals | 0.184869 | CALC | MATCH |  |
| 602 | §6.1, p. 14 | +0.12 | is +0.18 (bootstrap 95% interval over labels +0.12 to +0.25; Kendall's tau +0.13 | m2_from_counts.py | 0.124 | RUN | MATCH |  |
| 603 | §6.1, p. 14 | +0.25 | (bootstrap 95% interval over labels +0.12 to +0.25; Kendall's tau +0.13); counti | m2_from_counts.py | 0.245 | RUN | MATCH |  |
| 604 | §6.1, p. 14 | +0.13 | al over labels +0.12 to +0.25; Kendall's tau +0.13); counting the 26,809 linkabl | m2_label_counts.csv | 0.131702 | CALC | MATCH |  |
| 605 | §6.1, p. 14 | 26,809 | to +0.25; Kendall's tau +0.13); counting the 26,809 linkable labels that no revie | m2_label_counts.csv | 26809 | CALC | MATCH |  |
| 606 | §6.1, p. 14 | +0.27 | abels that no review mentions as zero, it is +0.27 (+0.26 to +0.28). It is +0.28 | m2_from_counts.py | 0.273 | RUN | MATCH |  |
| 607 | §6.1, p. 14 | +0.26 | hat no review mentions as zero, it is +0.27 (+0.26 to +0.28). It is +0.28 among | m2_from_counts.py | 0.26 | RUN | MATCH |  |
| 608 | §6.1, p. 14 | +0.28 | view mentions as zero, it is +0.27 (+0.26 to +0.28). It is +0.28 among the 213 l | same seeded resampling as m2_from_counts.py, five decimals | 0.284982 | CALC | MATCH |  |
| 609 | §6.1, p. 14 | +0.28 | as zero, it is +0.27 (+0.26 to +0.28). It is +0.28 among the 213 labels with at | m2_label_counts.csv (ranks are enough for this correlation) | 0.281843 | CALC | MATCH |  |
| 610 | §6.1, p. 14 | 213 | 0.27 (+0.26 to +0.28). It is +0.28 among the 213 labels with at least twenty m | m2_label_counts.csv | 213 | CALC | MATCH |  |
| 611 | §6.1, p. 14 | +0.16 | 13 labels with at least twenty mentions, and +0.16 among the 106 labels mentione | analyze_reviews.py (saved output) | 0.16 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 612 | §6.1, p. 14 | 106 | t least twenty mentions, and +0.16 among the 106 labels mentioned at least twe | analyze_reviews.py (saved output) | 106.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 613 | §6.1, p. 14 | 0.001 | aws: these intervals, and the p-values below 0.001 the scripts print, are too na | m2_from_counts.py: p=3.4e-09 (+0.185), p=0 and p=2.2e-07 (own volumes); paper says below 0.001 | 0.0 | RUN | MATCH |  |
| 614 | §6.1, p. 14 | 1,008 | em (`supplement_r10.py`, section 12). Of the 1,008 labels, 367 (36.4%) carry und | m2_from_counts.py | 1008.0 | RUN | MATCH |  |
| 615 | §6.1, p. 14 | 367 | t_r10.py`, section 12). Of the 1,008 labels, 367 (36.4%) carry under 1,000 mon | analyze_reviews.py (saved output) | 367.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 616 | §6.1, p. 14 | 36.4 | .py`, section 12). Of the 1,008 labels, 367 (36.4%) carry under 1,000 monthly s | analyze_reviews.py (saved output) | 36.4 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 617 | §6.1, p. 14 | 1,000 | Of the 1,008 labels, 367 (36.4%) carry under 1,000 monthly searches and 106 (10. | analyze_reviews.py (saved output) | 1000.0 | SAVED | CANNOT RUN | the threshold named in the saved line; agrees with the saved output; the script that prints it needs withheld data |
| 618 | §6.1, p. 14 | 106 | 6.4%) carry under 1,000 monthly searches and 106 (10.5%) carry none. A label's | m2_label_counts.csv: mentioned labels at the lowest volume rank | 106 | CALC | MATCH |  |
| 619 | §6.1, p. 14 | 10.5 | carry under 1,000 monthly searches and 106 (10.5%) carry none. A label's volum | 106 / 1008 | 10.515873 | CALC | MATCH |  |
| 620 | §6.1, p. 14 | +0.16 | ren's), the two label-level correlations are +0.16 and +0.26. Several variants a | m2_from_counts.py | 0.162 | RUN | MATCH |  |
| 621 | §6.1, p. 14 | +0.26 | e two label-level correlations are +0.16 and +0.26. Several variants are reporte | m2_from_counts.py | 0.258 | RUN | MATCH |  |
| 622 | §6.1, p. 14 | 200 | protocol and none of the hypotheses, judged 200 links drawn uniformly from th | r2_link_check.py | 200.0 | RUN | MATCH |  |
| 623 | §6.1, p. 14 | 46,517 | s, judged 200 links drawn uniformly from the 46,517: 65% to 67% are correct (Wils | r2_link_check.py | 46517.0 | RUN | MATCH |  |
| 624 | §6.1, p. 14 | 65 | d 200 links drawn uniformly from the 46,517: 65% to 67% are correct (Wilson 9 | r2_link_check.py | 65.0 | RUN | MATCH |  |
| 625 | §6.1, p. 14 | 67 | inks drawn uniformly from the 46,517: 65% to 67% are correct (Wilson 95% inte | r2_link_check.py | 66.8 | RUN | MATCH |  |
| 626 | §6.1, p. 14 | 58 | 67% are correct (Wilson 95% intervals about 58% to 73%), and the two agree o | r2_link_check.py | 58.2 | RUN | MATCH |  |
| 627 | §6.1, p. 14 | 73 | e correct (Wilson 95% intervals about 58% to 73%), and the two agree on 95.5% | r2_link_check.py | 73.0 | RUN | MATCH |  |
| 628 | §6.1, p. 14 | 95.5 | vals about 58% to 73%), and the two agree on 95.5% of the items (Cohen's kappa | r2_link_check.py | 95.5 | RUN | MATCH |  |
| 629 | §6.1, p. 14 | 0.90 | o agree on 95.5% of the items (Cohen's kappa 0.90). The errors lie almost entir | r2_link_check.py | 0.9 | RUN | MATCH |  |
| 630 | §6.1, p. 14 | single-word labels, which are right about half the time | errors lie almost entirely in single-word labels, which are right about half the time (for example "Thank | r2_link_check.py: 48.0% and 50.0% | agrees | RUN | MATCH | statement in words |
| 631 | §6.1, p. 14 | 95 | so first names), while multi-word labels are 95% to 96% right. Restricted, af | r2_link_check.py | 94.5 | RUN | MATCH |  |
| 632 | §6.1, p. 14 | 96 | t names), while multi-word labels are 95% to 96% right. Restricted, after thi | r2_link_check.py | 95.8 | RUN | MATCH |  |
| 633 | §6.1, p. 14 | +0.91 | word labels, the branch-level correlation is +0.91 (bootstrap 95% interval +0.74 | m2_from_counts.py | 0.914 | RUN | MATCH |  |
| 634 | §6.1, p. 14 | +0.74 | correlation is +0.91 (bootstrap 95% interval +0.74 to +0.98) with split attribut | m2_from_counts.py | 0.735 | RUN | MATCH |  |
| 635 | §6.1, p. 14 | +0.98 | on is +0.91 (bootstrap 95% interval +0.74 to +0.98) with split attribution and + | m2_from_counts.py | 0.983 | RUN | MATCH |  |
| 636 | §6.1, p. 14 | +0.65 | l +0.74 to +0.98) with split attribution and +0.65 with modal attribution, the l | m2_from_counts.py | 0.649 | RUN | MATCH |  |
| 637 | §6.1, p. 14 | +0.24 | l-level correlation over mentioned labels is +0.24 (+0.16 to +0.33), and carrier | m2_from_counts.py | 0.243 | RUN | MATCH |  |
| 638 | §6.1, p. 14 | +0.16 | correlation over mentioned labels is +0.24 (+0.16 to +0.33), and carriers still | m2_from_counts.py | 0.158 | RUN | MATCH |  |
| 639 | §6.1, p. 14 | +0.33 | ion over mentioned labels is +0.24 (+0.16 to +0.33), and carriers still draw 56% | m2_from_counts.py | 0.326 | RUN | MATCH |  |
| 640 | §6.1, p. 14 | 56 | 24 (+0.16 to +0.33), and carriers still draw 56% of review mentions against 1 | m2_from_counts.py | 56.1 | RUN | MATCH |  |
| 641 | §6.1, p. 14 | 15 | rs still draw 56% of review mentions against 15% of search volume. The conclu | m2_from_counts.py | 14.9 | RUN | MATCH |  |
| 642 | §6.1, p. 14 | 6,620 | tice had identified is the cleanest case. Of 6,620 one- and two-star reviews, 92 | analyze_reviews.py (saved output) | 6620.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 643 | §6.1, p. 14 | 924 | st case. Of 6,620 one- and two-star reviews, 924 (14.0%, Wilson 95% interval 1 | analyze_reviews.py (saved output) | 924.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 644 | §6.1, p. 14 | 14.0 | se. Of 6,620 one- and two-star reviews, 924 (14.0%, Wilson 95% interval 13.1% t | analyze_reviews.py (saved output) | 14.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 645 | §6.1, p. 14 | 13.1 | tar reviews, 924 (14.0%, Wilson 95% interval 13.1% to 14.8%) match a pattern fo | supplement_r10.py (saved output) | 13.1 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 646 | §6.1, p. 14 | 14.8 | ws, 924 (14.0%, Wilson 95% interval 13.1% to 14.8%) match a pattern for waiting | supplement_r10.py (saved output) | 14.8 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 647 | §6.1, p. 14 | 1.9 | waiting, long line, hours in line), against 1.9% (1.8% to 2.1%) of five-star | analyze_reviews.py (saved output) | 1.9 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 648 | §6.1, p. 14 | 1.8 | ng, long line, hours in line), against 1.9% (1.8% to 2.1%) of five-star review | supplement_r10.py (saved output) | 1.8 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 649 | §6.1, p. 14 | 2.1 | line, hours in line), against 1.9% (1.8% to 2.1%) of five-star reviews. The s | supplement_r10.py (saved output) | 2.1 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 650 | §6.1, p. 14 | 100 | ive-star reviews. The same annotators judged 100 of the 924 matches: 83% to 85 | r2_link_check.py | 100.0 | RUN | MATCH |  |
| 651 | §6.1, p. 14 | 924 | views. The same annotators judged 100 of the 924 matches: 83% to 85% are compl | r2_link_check.py | 924.0 | RUN | MATCH |  |
| 652 | §6.1, p. 14 | 83 | me annotators judged 100 of the 924 matches: 83% to 85% are complaints about | r2_link_check.py | 83.0 | RUN | MATCH |  |
| 653 | §6.1, p. 14 | 85 | tators judged 100 of the 924 matches: 83% to 85% are complaints about waiting | r2_link_check.py | 84.8 | RUN | MATCH |  |
| 654 | §6.1, p. 14 | 0.93 | are complaints about waiting (Cohen's kappa 0.93), and about nine in ten of th | r2_link_check.py | 0.93 | RUN | MATCH |  |
| 655 | §6.1, p. 14 | nine | bout waiting (Cohen's kappa 0.93), and about nine in ten of those concern waiti | r2_link_check.py: 90.5% and 89.2% in store | 9.0 | RUN | MATCH | nine in ten |
| 656 | §6.1, p. 14 | 12 | ose concern waiting in the store, so roughly 12% of one- and two-star reviews | r2_link_check.py | 11.9 | RUN | MATCH |  |
| 657 | §6.1, p. 15 | 1.9 | m in a store. The whole taxonomy, built from 1.9 million keywords, holds 11 la | supplement_r10.py (saved output) | 1.898584 | SAVED | CANNOT RUN | 1,898,584; agrees with the saved output; the script that prints it needs withheld data |
| 658 | §6.1, p. 15 | 11 | nomy, built from 1.9 million keywords, holds 11 labels containing "wait", wit | supplement_r10.py (saved output) | 11.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 659 | §6.1, p. 15 | 622 | rds, holds 11 labels containing "wait", with 622 searches a month between them | supplement_r10.py (saved output) | 622.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 660 | §6.1, p. 15 | 12 | n name; the one that reviews mention carries 12. Eight labels name a remedy, | analyze_reviews.py (saved output) | 12.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 661 | §6.1, p. 15 | 13,170 | edy, appointments, queues or callbacks, with 13,170 searches a month between them | supplement_r10.py (saved output) | 13170.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 662 | Figure 6, p. 16 | 1,008 | printed inside fig9_reviews.pdf | m2_from_counts.py | 1008.0 | RUN | MATCH | label in the shipped figure; the figure itself cannot be redrawn (licensed export) |
| 663 | Figure 6, p. 16 | +0.18 | printed inside fig9_reviews.pdf | m2_label_counts.csv, to five decimals | 0.184869 | CALC | MATCH | label in the shipped figure; the figure itself cannot be redrawn (licensed export) |
| 664 | Figure 6, p. 16 | +0.75 | printed inside fig9_reviews.pdf | m2_from_counts.py | 0.748 | RUN | MATCH | label in the shipped figure; the figure itself cannot be redrawn (licensed export) |
| 665 | Figure 6, p. 16 | 17 | printed inside fig9_reviews.pdf | m2_from_counts.py | 17.0 | RUN | MATCH | label in the shipped figure; the figure itself cannot be redrawn (licensed export) |
| 666 | §6.1, p. 16 | 37,193 | ool-derived demand on one industry taxonomy: 37,193 Google reviews of 378 retail | supplement_r10.py (saved output) | 37193.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 667 | §6.1, p. 16 | 378 | industry taxonomy: 37,193 Google reviews of 378 retail locations of major US | supplement_r10.py (saved output) | 378.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 668 | §6.1, p. 16 | 42,994 | ns of major US telecom carriers, linked to a 42,994-node taxonomy carrying vendor | supplement_r10.py (saved output) | 42994.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 669 | §6.1, p. 16 | 1,008 | h DataForSEO). (a) Each marker is one of the 1,008 taxonomy labels mentioned in | m2_from_counts.py | 1008.0 | RUN | MATCH |  |
| 670 | §6.1, p. 16 | 17 | of search volume for the nine largest of the 17 top-level branches. Only aggr | m2_from_counts.py | 17.0 | RUN | MATCH |  |
| 671 | §6.1, p. 15 | about two in three are correct | y, exact-match links of which about two in three are correct, relative review da | r2_link_check.py: 65.0% to 66.8% | agrees | RUN | MATCH | statement in words |
| 672 | §6.2, p. 15 | 372 | est count against the vendor's volume on the 372 area codes The reviews above | wiki_demand_analysis.py | 372.0 | RUN | MATCH |  |
| 673 | §6.2, p. 15 | 372 | e can re-read to the digit. Every one of the 372 geographic area codes in serv | wiki_demand_analysis.py | 372.0 | RUN | MATCH |  |
| 674 | §6.2, p. 15 | 240 | hared with the codes of its overlay complex (240 articles: 125 about one code, | wiki_demand_analysis.py | 240.0 | RUN | MATCH |  |
| 675 | §6.2, p. 15 | 125 | codes of its overlay complex (240 articles: 125 about one code, 102 about two | wiki_demand_supplement.py | 125.0 | RUN | MATCH |  |
| 676 | §6.2, p. 15 | 102 | y complex (240 articles: 125 about one code, 102 about two, 13 about three to | wiki_demand_supplement.py | 102.0 | RUN | MATCH |  |
| 677 | §6.2, p. 15 | 13 | articles: 125 about one code, 102 about two, 13 about three to five), and the | wiki_demand_supplement.py | 13.0 | RUN | MATCH |  |
| 678 | §6.2, p. 15 | four | pre-launch keywords that name it. The plan, four predictions and the analysis | cross_sector_ai_citation_study.md and wikipedia_demand_372.md: P1 to P4 in each | 4.0 | FILE | MATCH |  |
| 679 | §6.2, p. 15 | 05:10 | and submitted for an OpenTimestamps stamp at 05:10 UTC on 31 October 2026, befor | wikipedia_demand_372_manifest.txt | 05:10 | FILE | MATCH |  |
| 680 | §6.2, p. 15 | 1,497 | d_372.md`). The collection followed at once, 1,497 requests to two public APIs f | lines in the released resolution, redirects and pageviews files | 1497 | CALC | MATCH |  |
| 681 | §6.2, p. 15 | 05:11 | once, 1,497 requests to two public APIs from 05:11 to 05:19 UTC, before the stam | collection_log.txt | 05:11 | FILE | MATCH |  |
| 682 | §6.2, p. 15 | 05:19 | 97 requests to two public APIs from 05:11 to 05:19 UTC, before the stamp reached | collection_log.txt | 05:19 | FILE | MATCH |  |
| 683 | §6.2, p. 15 | 973,943 | ore the stamp reached a Bitcoin block (block 973,943, mined at 06:51 UTC): the pro | wikipedia_demand_372_manifest.txt.ots, read here; blockstream.info block data | 973934.0 | BLOCK | MISMATCH | 973,943 is a valid attestation but not the first: the proof holds three, 973,934 (05:44:22 UTC), 973,943 (06:51:59 UTC) and 973,953 (08:19:43 UTC); each computed digest equals that block's merkle root |
| 684 | §6.2, p. 15 | 06:51 | hed a Bitcoin block (block 973,943, mined at 06:51 UTC): the proof dates the pla | blockstream.info, block 973,934 | 05:44 | BLOCK | MISMATCH | the paper's 06:51 is block 973,943's time; the stamp first reached a block at 05:44:22 UTC, 24 minutes after the read ended (05:19:45) |
| 685 | §6.2, p. 15 | two | :51 UTC): the proof dates the plan to within two hours of the read, and the or | 05:10 stamp to 05:44:22 first block (34 minutes); 06:51:59 for the block the paper names | 2.0 | BLOCK | MATCH | still true of either block, but loose: 34 minutes from the stamp to the first block |
| 686 | §6.2, p. 15 | so that a request by any name for an article is counted once | each code's resolution path, so that a request by any name for an article is counted once; no title was missi | pageviews.jsonl to pageviews_monthly.csv to wiki_groups.csv recomputed: no difference | agrees | CALC | MATCH | statement in words |
| 687 | §6.2, p. 15 | no title was missing and none lacked data | r an article is counted once; no title was missing and none lacked data. The items a review | wiki_demand_analysis.py; pageviews.jsonl: 1,249 responses, all status 200 | agrees | CALC | MATCH | statement in words |
| 688 | §6.2, p. 15 | 240 | d not at all on the magnitudes.** Across the 240 articles, the rank correlatio | wiki_demand_analysis.py | 240.0 | RUN | MATCH |  |
| 689 | §6.2, p. 15 | +0.45 | r's summed volume and the year's requests is +0.45 (bootstrap 95% interval +0.34 | wiki_demand_supplement.py | 0.44598 | RUN | MATCH |  |
| 690 | §6.2, p. 15 | +0.34 | 's requests is +0.45 (bootstrap 95% interval +0.34 to +0.54; Kendall's tau +0.30 | wiki_demand_analysis.py | 0.344 | RUN | MATCH |  |
| 691 | §6.2, p. 15 | +0.54 | ts is +0.45 (bootstrap 95% interval +0.34 to +0.54; Kendall's tau +0.30; Figure | wiki_demand_analysis.py | 0.541 | RUN | MATCH |  |
| 692 | §6.2, p. 15 | +0.30 | p 95% interval +0.34 to +0.54; Kendall's tau +0.30; Figure 7), and +0.54 (+0.45 | wiki_demand_analysis.py | 0.303 | RUN | MATCH |  |
| 693 | §6.2, p. 15 | +0.54 | o +0.54; Kendall's tau +0.30; Figure 7), and +0.54 (+0.45 to +0.62) between the | wiki_demand_analysis.py | 0.541 | RUN | MATCH |  |
| 694 | §6.2, p. 15 | +0.45 | ; Kendall's tau +0.30; Figure 7), and +0.54 (+0.45 to +0.62) between the number | wiki_demand_analysis.py | 0.448 | RUN | MATCH |  |
| 695 | §6.2, p. 15 | +0.62 | 's tau +0.30; Figure 7), and +0.54 (+0.45 to +0.62) between the number of matche | wiki_demand_analysis.py | 0.623 | RUN | MATCH |  |
| 696 | §6.2, p. 15 | Prediction P1 (positive, with an interval excluding zero) held | atched keywords and requests. Prediction P1 (positive, with an interval excluding zero) held; P2 (a point estima | wiki_demand_analysis.py: P1 HELD | agrees | RUN | MATCH | statement in words |
| 697 | §6.2, p. 15 | P2 (a point estimate between +0.40 and +0.80, the band inside which Measurement 2's branch-level estimates fall) held at its boundary | nterval excluding zero) held; P2 (a point estimate between +0.40 and +0.80, the band inside which Measurement 2's branch-level estimates fall) held at its boundary, because the interv | wiki_demand_analysis.py; m2_from_counts.py | agrees | RUN | MATCH | statement in words |
| 698 | §6.2, p. 15 | +0.40 | ing zero) held; P2 (a point estimate between +0.40 and +0.80, the band inside wh | wikipedia_demand_372.md (P2) | 0.4 | FILE | MATCH | fixed in the stamped plan |
| 699 | §6.2, p. 15 | +0.80 | held; P2 (a point estimate between +0.40 and +0.80, the band inside which Measur | wikipedia_demand_372.md (P2) | 0.8 | FILE | MATCH | fixed in the stamped plan |
| 700 | §6.2, p. 15 | +0.40 | t its boundary, because the interval crosses +0.40; P4 (every code covered by an | wikipedia_demand_372.md (P2) | 0.4 | FILE | MATCH | fixed in the stamped plan |
| 701 | §6.2, p. 15 | P4 (every code covered by an article that names it) held | e the interval crosses +0.40; P4 (every code covered by an article that names it) held. The magnitudes are | wiki_demand_analysis.py | agrees | RUN | MATCH | statement in words |
| 702 | §6.2, p. 15 | 1.5 | articles, a geometric standard deviation of 1.5 (7,989 to 120,065 in the year | wiki_demand_analysis.py | 1.5 | RUN | MATCH |  |
| 703 | §6.2, p. 15 | 7,989 | cles, a geometric standard deviation of 1.5 (7,989 to 120,065 in the year, 87.5% | wiki_demand_supplement.py | 7989.0 | RUN | MATCH |  |
| 704 | §6.2, p. 15 | 120,065 | eometric standard deviation of 1.5 (7,989 to 120,065 in the year, 87.5% of article | wiki_demand_supplement.py | 120065.0 | RUN | MATCH |  |
| 705 | §6.2, p. 15 | 87.5 | iation of 1.5 (7,989 to 120,065 in the year, 87.5% of articles between 15,000 a | wiki_demand_supplement.py | 87.5 | RUN | MATCH |  |
| 706 | §6.2, p. 15 | 15,000 | 0,065 in the year, 87.5% of articles between 15,000 and 50,000), while the vendor | wiki_demand_supplement.py | 15000.0 | RUN | MATCH | band named in the printed line |
| 707 | §6.2, p. 15 | 50,000 | e year, 87.5% of articles between 15,000 and 50,000), while the vendor's summed v | wiki_demand_supplement.py | 50000.0 | RUN | MATCH | band named in the printed line |
| 708 | §6.2, p. 15 | 16.7 | hile the vendor's summed volumes have one of 16.7 (50 to 3,704,650 searches a m | wiki_demand_analysis.py | 16.69 | RUN | MATCH |  |
| 709 | §6.2, p. 15 | 50 | he vendor's summed volumes have one of 16.7 (50 to 3,704,650 searches a month | wiki_demand_supplement.py | 50.0 | RUN | MATCH |  |
| 710 | §6.2, p. 15 | 3,704,650 | dor's summed volumes have one of 16.7 (50 to 3,704,650 searches a month), so monthly | wiki_demand_supplement.py | 3704650.0 | RUN | MATCH |  |
| 711 | §6.2, p. 15 | 0.3 | onthly searches per monthly request run from 0.3 at the 10th percentile to 244 | wiki_demand_analysis.py | 0.3 | RUN | MATCH |  |
| 712 | §6.2, p. 15 | 244 | quest run from 0.3 at the 10th percentile to 244 at the 90th (median 35), a ge | wiki_demand_analysis.py | 243.7 | RUN | MATCH |  |
| 713 | §6.2, p. 15 | 35 | e 10th percentile to 244 at the 90th (median 35), a geometric standard deviat | wiki_demand_analysis.py | 34.8 | RUN | MATCH |  |
| 714 | §6.2, p. 15 | 14.5 | edian 35), a geometric standard deviation of 14.5 against the 3.1 that Measurem | wiki_demand_analysis.py | 14.48 | RUN | MATCH |  |
| 715 | §6.2, p. 15 | 3.1 | etric standard deviation of 14.5 against the 3.1 that Measurement 1 reports fo | instrument_extra.py | 3.13 | RUN | MATCH |  |
| 716 | §6.2, p. 15 | twelve | urement 1 reports for the vendor pair across twelve prefixes (P3, held; the plan | data/analyze.py | 12.0 | RUN | MATCH |  |
| 717 | §6.2, p. 15 | (P3, held; | r pair across twelve prefixes (P3, held; the plan calls this | wiki_demand_analysis.py | agrees | RUN | MATCH | statement in words |
| 718 | §6.2, p. 15 | 0.9 | volume at a Pearson correlation above about 0.9). Whatever the public count m | wikipedia_demand_372.md (P3) | 0.9 | FILE | MATCH | as the plan states it, 'at a comparable spread'; the paper drops that qualifier; at the observed spreads (16.69 and 1.50) the ratio's geometric SD cannot fall below 11.1, so P3 could not have failed at any correlation |
| 719 | §6.2, p. 15 | the vendor's figure spreads the class across five orders of magnitude where the count spreads it across one | copy of the vendor's volume: the vendor's figure spreads the class across five orders of magnitude where the count spreads it across one. ![Figure 7. A pub | wiki_demand_supplement.py: 4.87 and 1.18 decades | agrees | RUN | MATCH | statement in words |
| 720 | Figure 7, p. 16 | +0.45 | printed inside fig11_wikipedia.pdf | wiki_demand_supplement.py | 0.44598 | RUN | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 721 | Figure 7, p. 16 | +0.34 | printed inside fig11_wikipedia.pdf | wiki_demand_analysis.py | 0.344 | RUN | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 722 | Figure 7, p. 16 | +0.54 | printed inside fig11_wikipedia.pdf | wiki_demand_analysis.py | 0.541 | RUN | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 723 | Figure 7, p. 16 | 240 | printed inside fig11_wikipedia.pdf | wiki_demand_analysis.py | 240.0 | RUN | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 724 | Figure 7, p. 16 | 125 | printed inside fig11_wikipedia.pdf | wiki_demand_supplement.py | 125.0 | RUN | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 725 | §6.2, p. 16 | 372 | est count against the vendor's volume on the 372 area codes. Each marker is on | wiki_demand_analysis.py | 372.0 | RUN | MATCH |  |
| 726 | §6.2, p. 16 | 240 | ach marker is one English Wikipedia article (240): its requests per month, Wik | wiki_demand_analysis.py | 240.0 | RUN | MATCH |  |
| 727 | §6.2, p. 15 | +0.45 | ** Shifting the window a month earlier gives +0.45; the six months outside the F | wiki_demand_supplement.py | 0.44511 | RUN | MATCH |  |
| 728 | §6.2, p. 15 | +0.45 | ion's reclassification of automated traffic, +0.45; twelve times the median mont | wiki_demand_supplement.py | 0.45001 | RUN | MATCH |  |
| 729 | §6.2, p. 15 | 4.6 | article, for codes 327 and 870, had a month 4.6 times its median), +0.44; dro | wiki_demand_supplement.py | 4.6 | RUN | MATCH |  |
| 730 | §6.2, p. 15 | +0.44 | and 870, had a month 4.6 times its median), +0.44; dropping the six articles th | wiki_demand_supplement.py | 0.44109 | RUN | MATCH |  |
| 731 | §6.2, p. 15 | +0.46 | ober 2025 or a code with no matched keyword, +0.46; the first two full months af | wiki_demand_analysis.py | 0.457 | RUN | MATCH |  |
| 732 | §6.2, p. 15 | +0.39 | two full months after the section's launch, +0.39 (+0.29 to +0.49), with the pu | wiki_demand_supplement.py | 0.39423 | RUN | MATCH |  |
| 733 | §6.2, p. 15 | +0.29 | ll months after the section's launch, +0.39 (+0.29 to +0.49), with the public co | wiki_demand_analysis.py | 0.289 | RUN | MATCH |  |
| 734 | §6.2, p. 15 | +0.49 | after the section's launch, +0.39 (+0.29 to +0.49), with the public count itsel | wiki_demand_analysis.py | 0.491 | RUN | MATCH |  |
| 735 | §6.2, p. 15 | +0.85 | lic count itself stable between the windows (+0.85). Counting an article's curre | wiki_demand_analysis.py | 0.85 | RUN | MATCH |  |
| 736 | §6.2, p. 15 | +0.31 | nting an article's current title alone gives +0.31, partly because ten articles | wiki_demand_supplement.py | 0.31498 | RUN | MATCH |  |
| 737 | §6.2, p. 15 | 44 | ly renamed as overlay codes were added, with 44% to 100% of their requests ar | wiki_demand_supplement.py | 44.0 | RUN | MATCH |  |
| 738 | §6.2, p. 15 | 100 | med as overlay codes were added, with 44% to 100% of their requests arriving t | wiki_demand_supplement.py | 100.0 | RUN | MATCH |  |
| 739 | §6.2, p. 15 | +0.37 | s that are now redirects (without those ten, +0.37 on the title alone against +0 | wiki_demand_supplement.py | 0.36572 | RUN | MATCH |  |
| 740 | §6.2, p. 15 | +0.43 | those ten, +0.37 on the title alone against +0.43 on all titles; `wiki_demand_s | wiki_demand_supplement.py | 0.43366 | RUN | MATCH |  |
| 741 | §6.2, p. 15 | 9.3 | igures the stamped script does not). Pooled, 9.3% of requests arrive through r | wiki_demand_analysis.py | 9.3 | RUN | MATCH |  |
| 742 | §6.2, p. 15 | 0.7 | ugh redirect titles; for the median article, 0.7%. Among the 125 articles abou | wiki_demand_analysis.py | 0.7 | RUN | MATCH |  |
| 743 | §6.2, p. 15 | 125 | les; for the median article, 0.7%. Among the 125 articles about one code the c | wiki_demand_supplement.py | 125.0 | RUN | MATCH |  |
| 744 | §6.2, p. 15 | +0.30 | 5 articles about one code the correlation is +0.30 (+0.12 to +0.46): a shared ar | wiki_demand_supplement.py | 0.29919 | RUN | MATCH |  |
| 745 | §6.2, p. 15 | +0.12 | les about one code the correlation is +0.30 (+0.12 to +0.46): a shared article p | wiki_demand_analysis.py | 0.116 | RUN | MATCH |  |
| 746 | §6.2, p. 15 | +0.46 | one code the correlation is +0.30 (+0.12 to +0.46): a shared article pools seve | wiki_demand_analysis.py | 0.457 | RUN | MATCH |  |
| 747 | §6.2, p. 16 | 372 | the same shape as Section 6.1's: on the same 372 entities, a free public count | wiki_demand_analysis.py | 372.0 | RUN | MATCH |  |
| 748 | §6.2, p. 16 | +0.45 | ree only roughly on which carry more demand (+0.45, against +0.47 to +0.75 for t | wiki_demand_supplement.py | 0.44598 | RUN | MATCH |  |
| 749 | §6.2, p. 16 | +0.47 | y on which carry more demand (+0.45, against +0.47 to +0.75 for the taxonomy's b | m2_from_counts.py | 0.468 | RUN | MATCH |  |
| 750 | §6.2, p. 16 | +0.75 | h carry more demand (+0.45, against +0.47 to +0.75 for the taxonomy's branches) | m2_from_counts.py | 0.748 | RUN | MATCH |  |
| 751 | §6.2, p. 16 | +0.41 | between the Content Gap Score and the count, +0.41, is not a test of the score, | wiki_demand_analysis_output.txt (project run; the release run prints not available) | 0.413 | SAVED | CANNOT RUN | the release run prints 'not available'; the per-code scores are not in the bundle; agrees with the saved output; the script that prints it needs withheld data |
| 752 | §7, p. 16 | eleven | Measurement 3: what AI answers cite, across eleven sectors and eight answer surf | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 753 | §7, p. 16 | eight | t AI answers cite, across eleven sectors and eight answer surfaces This measure | cross_sector_type_shares.csv: eight surfaces | 8.0 | CALC | MATCH |  |
| 754 | §7.1, p. 16 | 22:21 | -learning brands, made on 12 October between 22:21 and 22:26, under an hour befo | project copy of cross_sector_sensitivity.py (saved output) | 22:21 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 755 | §7.1, p. 16 | 22:26 | brands, made on 12 October between 22:21 and 22:26, under an hour before the fir | project copy of cross_sector_sensitivity.py (saved output) | 22:26 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 756 | §7.1, p. 16 | 28 | d domain on all four Google views and ranked 28th on ChatGPT, 4th on Perplexi | project copy of cross_sector_sensitivity.py (saved output) | 28.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 757 | §7.1, p. 16 | 4 | our Google views and ranked 28th on ChatGPT, 4th on Perplexity, 5th on Gemin | project copy of cross_sector_sensitivity.py (saved output) | 4.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 758 | §7.1, p. 16 | 5 | d ranked 28th on ChatGPT, 4th on Perplexity, 5th on Gemini and 9th on Copilo | project copy of cross_sector_sensitivity.py (saved output) | 5.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 759 | §7.1, p. 16 | 9 | hatGPT, 4th on Perplexity, 5th on Gemini and 9th on Copilot, and reddit.com | project copy of cross_sector_sensitivity.py (saved output) | 9.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 760 | §7.1, p. 17 | 240 | e top three on every surface except Copilot (240th); these figures are printed | project copy of cross_sector_sensitivity.py (saved output) | 240.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 761 | §7.2, p. 17 | 14 | nd the prompt-level sample was stopped after 14 of 88 exports (Section 13). T | cross_sector_ai_citation_study.md | 14.0 | FILE | MATCH |  |
| 762 | §7.2, p. 17 | 88 | prompt-level sample was stopped after 14 of 88 exports (Section 13). The fra | 11 sectors x 8 surfaces | 88.0 | CALC | MATCH |  |
| 763 | §7.2, p. 17 | eleven | of 88 exports (Section 13). The frame is the eleven GICS sectors of the S&P 500, | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 764 | §7.2, p. 17 | 109 | fund pages (holdings as of 9 October 2026): 109 companies, because Communicat | cross_sector_companies.csv | 109 | CALC | MATCH |  |
| 765 | §7.2, p. 17 | eight | or, the cited-domains table was exported for eight vendor views of six answer pr | cross_sector_type_shares.csv: eight surfaces | 8.0 | CALC | MATCH |  |
| 766 | §7.2, p. 17 | 1,000 | ity; Gemini; Copilot). Each export holds the 1,000 domains found in the most ans | cross_sector_cells.csv: export_rows is 1000 in all 88 cells | 1000.0 | CALC | MATCH |  |
| 767 | §7.2, p. 17 | 760 | the most this table exports, which reduce to 760 to 975 registrable domains; t | section7_from_aggregates.py | 760.0 | RUN | MATCH |  |
| 768 | §7.2, p. 17 | 975 | t this table exports, which reduce to 760 to 975 registrable domains; the 88 e | section7_from_aggregates.py | 975.0 | RUN | MATCH |  |
| 769 | §7.2, p. 17 | 88 | educe to 760 to 975 registrable domains; the 88 exports are analyzed, and an | cross_sector_type_shares.csv: 88 rows | 88.0 | CALC | MATCH |  |
| 770 | §7.2, p. 17 | 20,389,967 | ten companies. Summed over sectors it holds 20,389,967 answer records, from 18,763 ( | section7_from_aggregates.py | 20389967.0 | RUN | MATCH |  |
| 771 | §7.2, p. 17 | 18,763 | ors it holds 20,389,967 answer records, from 18,763 (Utilities) to 7,766,466 (Con | section7_from_aggregates.py | 18763.0 | RUN | MATCH |  |
| 772 | §7.2, p. 17 | 7,766,466 | 7 answer records, from 18,763 (Utilities) to 7,766,466 (Consumer Discretionary), not | section7_from_aggregates.py | 7766466.0 | RUN | MATCH |  |
| 773 | §7.2, p. 18 | 1,000 | s, Medium, Substack, DEV, GitHub), among the 1,000 domains found in the most ans | cross_sector_cells.csv: export_rows is 1000 in all 88 cells | 1000.0 | CALC | MATCH |  |
| 774 | §7.3, p. 17 | In every one of the eleven sectors, the lowest of the four Google views | most between answer surfaces. In every one of the eleven sectors, the lowest of the four Google views gave video and comm | section7_from_aggregates.py: 11/11 | agrees | RUN | MATCH | statement in words |
| 775 | §7.3, p. 17 | eleven | between answer surfaces. In every one of the eleven sectors, the lowest of the fo | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 776 | §7.3, p. 17 | 21.3 | ross sectors and views, the median share was 21.3% on the Google views (range 8 | section7_from_aggregates.py | 21.3 | RUN | MATCH |  |
| 777 | §7.3, p. 17 | 8.1 | n share was 21.3% on the Google views (range 8.1% to 35.8%; 95% bootstrap inte | section7_from_aggregates.py | 8.1 | RUN | MATCH |  |
| 778 | §7.3, p. 17 | 35.8 | was 21.3% on the Google views (range 8.1% to 35.8%; 95% bootstrap interval over | section7_from_aggregates.py | 35.8 | RUN | MATCH |  |
| 779 | §7.3, p. 17 | 17.2 | o 35.8%; 95% bootstrap interval over sectors 17.2% to 26.7%) against 2.1% on th | section7_from_aggregates.py | 17.2 | RUN | MATCH |  |
| 780 | §7.3, p. 17 | 26.7 | 95% bootstrap interval over sectors 17.2% to 26.7%) against 2.1% on the other f | section7_from_aggregates.py | 26.7 | RUN | MATCH |  |
| 781 | §7.3, p. 17 | 2.1 | nterval over sectors 17.2% to 26.7%) against 2.1% on the other four (range 0.3 | section7_from_aggregates.py | 2.1 | RUN | MATCH |  |
| 782 | §7.3, p. 17 | 0.3 | 26.7%) against 2.1% on the other four (range 0.3% to 16.7%; interval 1.7% to 2 | section7_from_aggregates.py | 0.3 | RUN | MATCH |  |
| 783 | §7.3, p. 17 | 16.7 | gainst 2.1% on the other four (range 0.3% to 16.7%; interval 1.7% to 2.7%), and | section7_from_aggregates.py | 16.7 | RUN | MATCH |  |
| 784 | §7.3, p. 17 | 1.7 | he other four (range 0.3% to 16.7%; interval 1.7% to 2.7%), and by surface 0.6 | section7_from_aggregates.py | 1.7 | RUN | MATCH |  |
| 785 | §7.3, p. 17 | 2.7 | four (range 0.3% to 16.7%; interval 1.7% to 2.7%), and by surface 0.6% on Cop | section7_from_aggregates.py | 2.7 | RUN | MATCH |  |
| 786 | §7.3, p. 17 | 0.6 | 6.7%; interval 1.7% to 2.7%), and by surface 0.6% on Copilot, 0.9% on ChatGPT, | section7_from_aggregates.py | 0.6 | RUN | MATCH |  |
| 787 | §7.3, p. 17 | 0.9 | 7% to 2.7%), and by surface 0.6% on Copilot, 0.9% on ChatGPT, 4.6% on Perplexi | section7_from_aggregates.py | 0.9 | RUN | MATCH |  |
| 788 | §7.3, p. 17 | 4.6 | by surface 0.6% on Copilot, 0.9% on ChatGPT, 4.6% on Perplexity and 9.2% on Ge | section7_from_aggregates.py | 4.6 | RUN | MATCH |  |
| 789 | §7.3, p. 17 | 9.2 | lot, 0.9% on ChatGPT, 4.6% on Perplexity and 9.2% on Gemini. The bootstrap res | section7_from_aggregates.py | 9.2 | RUN | MATCH |  |
| 790 | §7.3, p. 17 | 24.6 | prompt-based surfaces, the Google median is 24.6%. youtube.com was among the t | section7_from_aggregates.py | 24.6 | RUN | MATCH |  |
| 791 | §7.3, p. 17 | 38 | ins other than the sector's own companies in 38 of the 44 sector-by-Google-vi | section7_from_aggregates.py | 38.0 | RUN | MATCH |  |
| 792 | §7.3, p. 17 | 44 | than the sector's own companies in 38 of the 44 sector-by-Google-view cells a | section7_from_aggregates.py | 44.0 | RUN | MATCH |  |
| 793 | §7.3, p. 17 | 44 | ctor-by-Google-view cells and in none of the 44 others; its median rank was 1 | section7_from_aggregates.py | 44.0 | RUN | MATCH |  |
| 794 | §7.3, p. 17 | 1 | n none of the 44 others; its median rank was 1 on AI Overviews, 2 on AI Mode | section7_from_aggregates.py | 1.0 | RUN | MATCH |  |
| 795 | §7.3, p. 17 | 2 | hers; its median rank was 1 on AI Overviews, 2 on AI Mode, 7 on Perplexity a | section7_from_aggregates.py | 2.0 | RUN | MATCH |  |
| 796 | §7.3, p. 17 | 7 | an rank was 1 on AI Overviews, 2 on AI Mode, 7 on Perplexity and Gemini, 151 | section7_from_aggregates.py | 7.0 | RUN | MATCH |  |
| 797 | §7.3, p. 17 | 151 | s, 2 on AI Mode, 7 on Perplexity and Gemini, 151 on ChatGPT and 161 on Copilot | section7_from_aggregates.py | 151.0 | RUN | MATCH |  |
| 798 | §7.3, p. 17 | 161 | on Perplexity and Gemini, 151 on ChatGPT and 161 on Copilot (Figure 8b), where | section7_from_aggregates.py | 161.0 | RUN | MATCH |  |
| 799 | §7.3, p. 17 | 12.7 | t YouTube alone: without it, the medians are 12.7% and 1.6%, and the lowest Goo | section7_from_aggregates.py | 12.7 | RUN | MATCH |  |
| 800 | §7.3, p. 17 | 1.6 | alone: without it, the medians are 12.7% and 1.6%, and the lowest Google view | section7_from_aggregates.py | 1.6 | RUN | MATCH |  |
| 801 | §7.3, p. 17 | 7 | le view exceeds the highest other surface in 7 of 11 sectors. The design can | section7_from_aggregates.py | 7.0 | RUN | MATCH |  |
| 802 | §7.3, p. 17 | 11 | ew exceeds the highest other surface in 7 of 11 sectors. The design cannot sa | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 803 | §7.3, p. 17 | Gemini, also Google's, is the highest of the other four | gh-share surface is Google's, Gemini, also Google's, is the highest of the other four, and Perplexity, wh | section7_from_aggregates.py | agrees | RUN | MATCH | statement in words |
| 804 | §7.3, p. 17 | 2.7 | ot supported: the median reference share was 2.7% on the other four surfaces a | section7_from_aggregates.py | 2.7 | RUN | MATCH |  |
| 805 | §7.3, p. 17 | 3.2 | was 2.7% on the other four surfaces against 3.2% on the Google views, and for | section7_from_aggregates.py | 3.2 | RUN | MATCH |  |
| 806 | §7.3, p. 18 | 1.1 | st 3.2% on the Google views, and forum sites 1.1% against 5.7%. On those four, | section7_from_aggregates.py | 1.1 | RUN | MATCH |  |
| 807 | §7.3, p. 18 | 5.7 | e Google views, and forum sites 1.1% against 5.7%. On those four, the largest | section7_from_aggregates.py | 5.7 | RUN | MATCH |  |
| 808 | §7.3, p. 18 | 14.1 | was the sector's own company domains (median 14.1%), a share the selection rule | section7_from_aggregates.py | 14.1 | RUN | MATCH |  |
| 809 | §7.3, p. 18 | 61 | fixed list does not classify, held a median 61% of incidences on the Google | section7_from_aggregates.py | 61.1 | RUN | MATCH |  |
| 810 | §7.3, p. 18 | 72 | an 61% of incidences on the Google views and 72% on the other four (90% on Co | section7_from_aggregates.py | 71.7 | RUN | MATCH |  |
| 811 | §7.3, p. 18 | 90 | the Google views and 72% on the other four (90% on Copilot), so the classifi | section7_from_aggregates.py | 89.9 | RUN | MATCH |  |
| 812 | §7.3, p. 18 | seventeen | d the claim here is about the share going to seventeen named video and community pla | the video, forum, social and user_publishing sets in cross_sector.py, with x.com and twitter.com as one platform | 17.0 | CALC | MATCH |  |
| 813 | §7.3, p. 18 | 88 | than about every kind of source. Across the 88 cells, answer surface explain | cross_sector_type_shares.csv: 88 rows | 88.0 | CALC | MATCH |  |
| 814 | §7.3, p. 18 | 77 | Across the 88 cells, answer surface explains 77% of the variance of that shar | section7_from_aggregates.py | 77.0 | RUN | MATCH |  |
| 815 | §7.3, p. 18 | 70 | t share (bootstrap 95% interval over sectors 70% to 91%) and sector 14% (5% t | section7_from_aggregates.py | 70.0 | RUN | MATCH |  |
| 816 | §7.3, p. 18 | 91 | (bootstrap 95% interval over sectors 70% to 91%) and sector 14% (5% to 20%); | section7_from_aggregates.py | 91.0 | RUN | MATCH |  |
| 817 | §7.3, p. 18 | 14 | interval over sectors 70% to 91%) and sector 14% (5% to 20%); for news (12% a | section7_from_aggregates.py | 14.0 | RUN | MATCH |  |
| 818 | §7.3, p. 18 | 5 | val over sectors 70% to 91%) and sector 14% (5% to 20%); for news (12% again | section7_from_aggregates.py | 5.0 | RUN | MATCH |  |
| 819 | §7.3, p. 18 | 20 | er sectors 70% to 91%) and sector 14% (5% to 20%); for news (12% against 73%) | section7_from_aggregates.py | 20.0 | RUN | MATCH |  |
| 820 | §7.3, p. 18 | 12 | o 91%) and sector 14% (5% to 20%); for news (12% against 73%), government (26 | section7_from_aggregates.py | 12.0 | RUN | MATCH |  |
| 821 | §7.3, p. 18 | 73 | ector 14% (5% to 20%); for news (12% against 73%), government (26% against 49 | section7_from_aggregates.py | 73.0 | RUN | MATCH |  |
| 822 | §7.3, p. 18 | 26 | 0%); for news (12% against 73%), government (26% against 49%) and the compani | section7_from_aggregates.py | 26.0 | RUN | MATCH |  |
| 823 | §7.3, p. 18 | 49 | s (12% against 73%), government (26% against 49%) and the companies' own doma | section7_from_aggregates.py | 49.0 | RUN | MATCH |  |
| 824 | §7.3, p. 18 | 40 | against 49%) and the companies' own domains (40% against 45%), sector explain | section7_from_aggregates.py | 40.0 | RUN | MATCH |  |
| 825 | §7.3, p. 18 | 45 | and the companies' own domains (40% against 45%), sector explains more (the | section7_from_aggregates.py | 45.0 | RUN | MATCH |  |
| 826 | §7.3, p. 18 | 88 | the share of the total sum of squares of the 88 cell shares explained by the | cross_sector_type_shares.csv: 88 rows | 88.0 | CALC | MATCH |  |
| 827 | §7.3, p. 18 | 0.36 | e on the Google views (mean pairwise Jaccard 0.36 to 0.40 across the 55 sector | section7_from_aggregates.py | 0.36 | RUN | MATCH |  |
| 828 | §7.3, p. 18 | 0.40 | Google views (mean pairwise Jaccard 0.36 to 0.40 across the 55 sector pairs) t | section7_from_aggregates.py | 0.4 | RUN | MATCH |  |
| 829 | §7.3, p. 18 | 55 | ean pairwise Jaccard 0.36 to 0.40 across the 55 sector pairs) than on the oth | section7_from_aggregates.py | 55.0 | RUN | MATCH |  |
| 830 | §7.3, p. 18 | 0.08 | the 55 sector pairs) than on the other four (0.08 to 0.23), a measure not plann | section7_from_aggregates.py | 0.08 | RUN | MATCH |  |
| 831 | §7.3, p. 18 | 0.23 | ector pairs) than on the other four (0.08 to 0.23), a measure not planned befor | section7_from_aggregates.py | 0.23 | RUN | MATCH |  |
| 832 | §7.3, p. 18 | 22.5 | st its direction reversed on search queries (22.5% against 24.2%), and in no ch | cross_sector_sensitivity2.py (saved output) | 22.5 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 833 | §7.3, p. 18 | 24.2 | on reversed on search queries (22.5% against 24.2%), and in no check did it app | cross_sector_sensitivity2.py (saved output) | 24.2 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 834 | §7.3, p. 18 | 0.23 | n no check did it approach significance (p = 0.23 to 0.63). In several sectors | cross_sector_sensitivity2.py (saved output) | 0.23 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 835 | §7.3, p. 18 | 0.63 | ck did it approach significance (p = 0.23 to 0.63). In several sectors one comp | cross_sector_sensitivity2.py (saved output) | 0.63 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 836 | §7.3, p. 18 | 94 | e all-surface export, Sherwin-Williams holds 94% of Materials, Amazon 75% of | cross_sector_sensitivity.py (saved output) | 93.9 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 837 | §7.3, p. 18 | 75 | rwin-Williams holds 94% of Materials, Amazon 75% of Consumer Discretionary, W | cross_sector_sensitivity.py (saved output) | 75.4 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 838 | §7.3, p. 18 | 65 | mazon 75% of Consumer Discretionary, Walmart 65% of Consumer Staples, Apple 6 | cross_sector_sensitivity.py (saved output) | 65.4 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 839 | §7.3, p. 18 | 62 | nary, Walmart 65% of Consumer Staples, Apple 62% of Information Technology an | cross_sector_sensitivity.py (saved output) | 62.2 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 840 | §7.3, p. 18 | 55 | Apple 62% of Information Technology and Uber 55% of Industrials, so a sector | cross_sector_sensitivity.py (saved output) | 54.8 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 841 | §7.4, p. 18 | one held, one held in direction only and two failed | fore collection Of the four, one held, one held in direction only and two failed. P1, that youtube.c | section7_from_aggregates.py: P1 fails, P2 holds, P3 fails, P4 in direction with p 0.27 and 0.21 | agrees | RUN | MATCH | statement in words |
| 842 | §7.4, p. 19 | 9 | failed as written: it held on AI Overviews (9 of 11 sectors on search queri | section7_from_aggregates.py | 9.0 | RUN | MATCH |  |
| 843 | §7.4, p. 19 | 11 | ed as written: it held on AI Overviews (9 of 11 sectors on search queries, 8 | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 844 | §7.4, p. 19 | 8 | verviews (9 of 11 sectors on search queries, 8 of 11 on prompts) and not on | section7_from_aggregates.py | 8.0 | RUN | MATCH |  |
| 845 | §7.4, p. 19 | 11 | ews (9 of 11 sectors on search queries, 8 of 11 on prompts) and not on AI Mod | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 846 | §7.4, p. 19 | 2 | ies, 8 of 11 on prompts) and not on AI Mode (2 of 11 on each), where google. | section7_from_aggregates.py | 2.0 | RUN | MATCH |  |
| 847 | §7.4, p. 19 | 11 | 8 of 11 on prompts) and not on AI Mode (2 of 11 on each), where google.com, a | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 848 | §7.4, p. 19 | 93 | com, almost all of it www.google.com (median 93% and 98% of its incidences on | cross_sector_sensitivity2.py (saved output) | 93.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 849 | §7.4, p. 19 | 98 | ost all of it www.google.com (median 93% and 98% of its incidences on the two | cross_sector_sensitivity2.py (saved output) | 98.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 850 | §7.4, p. 19 | 9 | every domain reduction tried; it would hold (9 of 11) if google.com, Google' | cross_sector_sensitivity.py (saved output) | 9.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 851 | §7.4, p. 19 | 11 | domain reduction tried; it would hold (9 of 11) if google.com, Google's answ | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 852 | §7.4, p. 19 | 11 | in a majority of sectors, held on all three (11, 6 and 11 of 11). P3, that Re | section7_from_aggregates.py | 11.0 | RUN | MATCH |  |
| 853 | §7.4, p. 19 | 6 | majority of sectors, held on all three (11, 6 and 11 of 11). P3, that Reddi | section7_from_aggregates.py | 6.0 | RUN | MATCH |  |
| 854 | §7.4, p. 19 | 11 | ity of sectors, held on all three (11, 6 and 11 of 11). P3, that Reddit is am | section7_from_aggregates.py | 11.0 | RUN | MATCH |  |
| 855 | §7.4, p. 19 | 11 | sectors, held on all three (11, 6 and 11 of 11). P3, that Reddit is among th | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 856 | §7.4, p. 19 | 3 | in a majority of sectors, failed: it held in 3 of 11, and ChatGPT was a fail | section7_from_aggregates.py | 3.0 | RUN | MATCH |  |
| 857 | §7.4, p. 19 | 11 | majority of sectors, failed: it held in 3 of 11, and ChatGPT was a failing su | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 858 | §7.4, p. 19 | eight | 11, and ChatGPT was a failing surface in all eight sectors where it did not hold | section7_from_aggregates.py | 8.0 | RUN | MATCH |  |
| 859 | §7.4, p. 19 | 26.9 | als is in neither group), held in direction (26.9% against 24.2% on search quer | section7_from_aggregates.py | 26.9 | RUN | MATCH |  |
| 860 | §7.4, p. 19 | 24.2 | her group), held in direction (26.9% against 24.2% on search queries, 29.6% aga | section7_from_aggregates.py | 24.2 | RUN | MATCH |  |
| 861 | §7.4, p. 19 | 29.6 | tion (26.9% against 24.2% on search queries, 29.6% against 24.4% on prompts) an | section7_from_aggregates.py | 29.6 | RUN | MATCH |  |
| 862 | §7.4, p. 19 | 24.4 | ainst 24.2% on search queries, 29.6% against 24.4% on prompts) and not beyond c | section7_from_aggregates.py | 24.4 | RUN | MATCH |  |
| 863 | §7.4, p. 19 | 0.27 | yond chance (exact one-sided permutation p = 0.27 and 0.21). ### 7.5 Sensitivi | section7_from_aggregates.py | 0.274 | RUN | MATCH |  |
| 864 | §7.4, p. 19 | 0.21 | ce (exact one-sided permutation p = 0.27 and 0.21). ### 7.5 Sensitivity None | section7_from_aggregates.py | 0.21 | RUN | MATCH |  |
| 865 | §7.5, p. 19 | 21.5 | nd in" in place of "Cited in" (Google median 21.5%, other four 3.3%; lowest Goo | cross_sector_sensitivity.py (saved output) | 21.5 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 866 | §7.5, p. 19 | 3.3 | "Cited in" (Google median 21.5%, other four 3.3%; lowest Google view above th | cross_sector_sensitivity.py (saved output) | 3.3 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 867 | §7.5, p. 19 | 11 | ogle view above the highest other surface in 11 of 11 sectors), with the larg | cross_sector_sensitivity.py (saved output) | 11.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 868 | §7.5, p. 19 | 11 | iew above the highest other surface in 11 of 11 sectors), with the largest si | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 869 | §7.5, p. 19 | 22.0 | argest single host in place of summed hosts (22.0%, 2.4%, 11 of 11), and with 6 | cross_sector_sensitivity.py (saved output) | 22.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 870 | §7.5, p. 19 | 2.4 | single host in place of summed hosts (22.0%, 2.4%, 11 of 11), and with 64 prop | cross_sector_sensitivity.py (saved output) | 2.4 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 871 | §7.5, p. 19 | 11 | host in place of summed hosts (22.0%, 2.4%, 11 of 11), and with 64 propertie | cross_sector_sensitivity.py (saved output) | 11.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 872 | §7.5, p. 19 | 11 | in place of summed hosts (22.0%, 2.4%, 11 of 11), and with 64 properties of t | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 873 | §7.5, p. 19 | 64 | mmed hosts (22.0%, 2.4%, 11 of 11), and with 64 properties of the sector's co | cross_sector_company_properties.csv | 64 | CALC | MATCH |  |
| 874 | §7.5, p. 19 | 19.8 | le (Section 14), counted as company domains (19.8%, 2.1%, 10 of 11). The except | cross_sector_sensitivity.py (saved output) | 19.8 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 875 | §7.5, p. 19 | 2.1 | tion 14), counted as company domains (19.8%, 2.1%, 10 of 11). The exception is | cross_sector_sensitivity.py (saved output) | 2.1 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 876 | §7.5, p. 19 | 10 | 4), counted as company domains (19.8%, 2.1%, 10 of 11). The exception is Comm | cross_sector_sensitivity.py (saved output) | 10.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 877 | §7.5, p. 19 | 11 | unted as company domains (19.8%, 2.1%, 10 of 11). The exception is Communicat | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 878 | §7.5, p. 19 | 20.2 | ounted as theirs, the Google views fall from 20.2% to 32.4% to 5.9% to 12.7%, a | cross_sector_sensitivity.py (saved output) | 20.2 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 879 | §7.5, p. 19 | 32.4 | theirs, the Google views fall from 20.2% to 32.4% to 5.9% to 12.7%, and Gemini | cross_sector_sensitivity.py (saved output) | 32.4 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 880 | §7.5, p. 19 | 5.9 | the Google views fall from 20.2% to 32.4% to 5.9% to 12.7%, and Gemini's 9.2% | cross_sector_sensitivity.py (saved output) | 5.9 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 881 | §7.5, p. 19 | 12.7 | le views fall from 20.2% to 32.4% to 5.9% to 12.7%, and Gemini's 9.2% exceeds A | cross_sector_sensitivity.py (saved output) | 12.7 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 882 | §7.5, p. 19 | 9.2 | 0.2% to 32.4% to 5.9% to 12.7%, and Gemini's 9.2% exceeds AI Mode on search qu | cross_sector_sensitivity.py (saved output) | 9.2 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 883 | §7.5, p. 19 | 100 | ueries. Restricting each export to its first 100, 250 or 500 rows gives Google | cross_sector_sensitivity.py (saved output) | 100.0 | SAVED | CANNOT RUN | row limit named in the saved line; agrees with the saved output; the script that prints it needs withheld data |
| 884 | §7.5, p. 19 | 250 | s. Restricting each export to its first 100, 250 or 500 rows gives Google medi | cross_sector_sensitivity.py (saved output) | 250.0 | SAVED | CANNOT RUN | row limit named in the saved line; agrees with the saved output; the script that prints it needs withheld data |
| 885 | §7.5, p. 19 | 500 | ricting each export to its first 100, 250 or 500 rows gives Google medians of | cross_sector_sensitivity.py (saved output) | 500.0 | SAVED | CANNOT RUN | row limit named in the saved line; agrees with the saved output; the script that prints it needs withheld data |
| 886 | §7.5, p. 19 | 30.6 | 100, 250 or 500 rows gives Google medians of 30.6%, 26.3% and 23.3% against 3.0 | cross_sector_sensitivity.py (saved output) | 30.6 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 887 | §7.5, p. 19 | 26.3 | 0 or 500 rows gives Google medians of 30.6%, 26.3% and 23.3% against 3.0%, 2.6% | cross_sector_sensitivity.py (saved output) | 26.3 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 888 | §7.5, p. 19 | 23.3 | ows gives Google medians of 30.6%, 26.3% and 23.3% against 3.0%, 2.6% and 2.3%. | cross_sector_sensitivity.py (saved output) | 23.3 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 889 | §7.5, p. 19 | 3.0 | le medians of 30.6%, 26.3% and 23.3% against 3.0%, 2.6% and 2.3%. Shares there | cross_sector_sensitivity.py (saved output) | 3.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 890 | §7.5, p. 19 | 2.6 | ians of 30.6%, 26.3% and 23.3% against 3.0%, 2.6% and 2.3%. Shares therefore f | cross_sector_sensitivity.py (saved output) | 2.6 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 891 | §7.5, p. 19 | 2.3 | 0.6%, 26.3% and 23.3% against 3.0%, 2.6% and 2.3%. Shares therefore fall as ro | cross_sector_sensitivity.py (saved output) | 2.3 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 892 | §7.5, p. 19 | 1,000 | refore fall as rows are added: truncation at 1,000 rows biases them upward, the | cross_sector_cells.csv: export_rows is 1000 in all 88 cells | 1000.0 | CALC | MATCH |  |
| 893 | §7.5, p. 19 | the ratio between the two groups stays near ten | t direction is unknown, while the ratio between the two groups stays near ten. Ranks 501 to 1,000 | cross_sector_sensitivity.py (saved output): 10.2, 10.1, 10.1 | agrees | SAVED | CANNOT RUN | statement in words; agrees with the saved output; the script that prints it needs withheld data |
| 894 | §7.5, p. 19 | 501 | between the two groups stays near ten. Ranks 501 to 1,000 carry a median 7.6% | section7_from_aggregates.py | 501.0 | RUN | MATCH | row range named in the printed line |
| 895 | §7.5, p. 19 | 1,000 | the two groups stays near ten. Ranks 501 to 1,000 carry a median 7.6% to 13.8% | section7_from_aggregates.py | 1000.0 | RUN | MATCH | row range named in the printed line |
| 896 | §7.5, p. 19 | 7.6 | near ten. Ranks 501 to 1,000 carry a median 7.6% to 13.8% of each export's in | section7_from_aggregates.py | 7.6 | RUN | MATCH |  |
| 897 | §7.5, p. 19 | 13.8 | n. Ranks 501 to 1,000 carry a median 7.6% to 13.8% of each export's incidences, | section7_from_aggregates.py | 13.8 | RUN | MATCH |  |
| 898 | §7.6, p. 19 | 31.3 | ntially unchanged (video and community share 31.3% to 30.1% on AI Overviews sea | section7_from_aggregates.py | 31.3 | RUN | MATCH |  |
| 899 | §7.6, p. 19 | 30.1 | nchanged (video and community share 31.3% to 30.1% on AI Overviews search queri | section7_from_aggregates.py | 30.1 | RUN | MATCH |  |
| 900 | §7.6, p. 19 | 1 | rviews search queries; YouTube's rank stayed 1 on AI Overviews and moved fro | section7_from_aggregates.py | 1.0 | RUN | MATCH |  |
| 901 | §7.6, p. 19 | 2 | rank stayed 1 on AI Overviews and moved from 2 to 1 on AI Mode prompts), mov | section7_from_aggregates.py | 2.0 | RUN | MATCH |  |
| 902 | §7.6, p. 19 | 1 | stayed 1 on AI Overviews and moved from 2 to 1 on AI Mode prompts), moved Pe | section7_from_aggregates.py | 1.0 | RUN | MATCH |  |
| 903 | §7.6, p. 19 | 6.2 | 1 on AI Mode prompts), moved Perplexity from 6.2% to 5.5% and Gemini from 15.0 | section7_from_aggregates.py | 6.2 | RUN | MATCH |  |
| 904 | §7.6, p. 19 | 5.5 | Mode prompts), moved Perplexity from 6.2% to 5.5% and Gemini from 15.0% to 13. | section7_from_aggregates.py | 5.5 | RUN | MATCH |  |
| 905 | §7.6, p. 19 | 15.0 | Perplexity from 6.2% to 5.5% and Gemini from 15.0% to 13.4%, and changed Copilo | section7_from_aggregates.py | 15.0 | RUN | MATCH |  |
| 906 | §7.6, p. 19 | 13.4 | y from 6.2% to 5.5% and Gemini from 15.0% to 13.4%, and changed Copilot's top n | section7_from_aggregates.py | 13.4 | RUN | MATCH |  |
| 907 | §7.6, p. 19 | 0.8 | s; without Industrials the ChatGPT median is 0.8%, P2 holds on ChatGPT and Cop | cross_sector_sensitivity.py (saved output) | 0.8 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 908 | §7.6, p. 19 | 10 | is 0.8%, P2 holds on ChatGPT and Copilot in 10 of 10 sectors and on Perplexi | cross_sector_sensitivity2.py (saved output) | 10.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 909 | §7.6, p. 19 | 10 | 8%, P2 holds on ChatGPT and Copilot in 10 of 10 sectors and on Perplexity in | cross_sector_sensitivity2.py (saved output) | 10.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 910 | §7.6, p. 19 | 6 | lot in 10 of 10 sectors and on Perplexity in 6 of 10, and P3 holds in 3 of 1 | cross_sector_sensitivity2.py (saved output) | 6.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 911 | §7.6, p. 19 | 10 | n 10 of 10 sectors and on Perplexity in 6 of 10, and P3 holds in 3 of 10. "Vi | cross_sector_sensitivity2.py (saved output) | 10.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 912 | §7.6, p. 19 | 3 | nd on Perplexity in 6 of 10, and P3 holds in 3 of 10. "Visa" also matched an | cross_sector_sensitivity2.py (saved output) | 3.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 913 | §7.6, p. 19 | 10 | Perplexity in 6 of 10, and P3 holds in 3 of 10. "Visa" also matched answers | cross_sector_sensitivity2.py (saved output) | 10.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 914 | §7.6, p. 19 | 2.2 | rder domains of the US government hold up to 2.2% of a Financials surface's in | cross_sector_sensitivity.py (saved output) | 2.2 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 915 | §7.6, p. 19 | 25 | t the domain level, by reading each sector's 25 most-cited non-company domain | cross_sector_ai_citation_study.md (A3) | 25.0 | FILE | MATCH |  |
| 916 | §7.6, p. 19 | 860 | ry sector equally, although cells range from 860 to 18,381,848 incidences (App | section7_from_aggregates.py | 860.0 | RUN | MATCH |  |
| 917 | §7.6, p. 19 | 18,381,848 | or equally, although cells range from 860 to 18,381,848 incidences (Appendix C gives | section7_from_aggregates.py | 18381848.0 | RUN | MATCH |  |
| 918 | §7.6, p. 19 | 4.6 | ar higher (19.4% to 31%; Section 2) than the 4.6% median video-and-community s | section7_from_aggregates.py | 4.6 | RUN | MATCH |  |
| 919 | §7.6, p. 19 | about ten times the pooled median share | e video and community domains about ten times the pooled median share of the other four s | 21.3 / 2.1 from section7_from_aggregates.py | agrees | RUN | MATCH | statement in words |
| 920 | §7.6, p. 19 | more than twice Gemini's | the other four surfaces, and more than twice Gemini's. If that holds outs | 21.3 / 9.2 from section7_from_aggregates.py | agrees | RUN | MATCH | statement in words |
| 921 | §8, p. 19 | 381 | uments recorded following the publication of 381 code pages and their hubs, on | section_code_pages_2026-10-14.csv | 381 | FILE | MATCH |  |
| 922 | Table 5, p. 20 | 2 | Table 5 | instrument_series_table5 CSV | 2.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 923 | Table 5, p. 20 | 210 | Table 5 | instrument_series_table5 CSV | 210.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 924 | Table 5, p. 20 | 365 | Table 5 | instrument_series_table5 CSV | 365.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 925 | Table 5, p. 20 | n/r | Table 5 | instrument_series_table5 CSV | n/r | CIRC | MATCH | not recorded in the paper and in the CSV |
| 926 | Table 5, p. 20 | 391 | Table 5 | instrument_series_table5 CSV | 391.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 927 | Table 5, p. 20 | 414 | Table 5 | instrument_series_table5 CSV | 414.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 928 | Table 5, p. 20 | 440 | Table 5 | instrument_series_table5 CSV | 440.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 929 | Table 5, p. 20 | 441 | Table 5 | instrument_series_table5 CSV | 441.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 930 | Table 5, p. 20 | 2 | Table 5 | instrument_series_table5 CSV | 2.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 931 | Table 5, p. 20 | 3,385 | Table 5 | instrument_series_table5 CSV | 3385.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 932 | Table 5, p. 20 | 14,905 | Table 5 | instrument_series_table5 CSV | 14905.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 933 | Table 5, p. 20 | 15,830 | Table 5 | instrument_series_table5 CSV | 15830.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 934 | Table 5, p. 20 | 20,326 | Table 5 | instrument_series_table5 CSV | 20326.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 935 | Table 5, p. 20 | 37,141 | Table 5 | instrument_series_table5 CSV | 37141.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 936 | Table 5, p. 20 | 43,302 | Table 5 | instrument_series_table5 CSV | 43302.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 937 | Table 5, p. 20 | 43,980 | Table 5 | instrument_series_table5 CSV | 43980.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 938 | Table 5, p. 20 | 0 | Table 5 | instrument_series_table5 CSV | 0.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 939 | Table 5, p. 20 | 727 | Table 5 | instrument_series_table5 CSV | 727.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 940 | Table 5, p. 20 | 1,801 | Table 5 | instrument_series_table5 CSV | 1801.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 941 | Table 5, p. 20 | 1,874 | Table 5 | instrument_series_table5 CSV | 1874.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 942 | Table 5, p. 20 | 2,649 | Table 5 | instrument_series_table5 CSV | 2649.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 943 | Table 5, p. 20 | 5,822 | Table 5 | instrument_series_table5 CSV | 5822.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 944 | Table 5, p. 20 | 8,753 | Table 5 | instrument_series_table5 CSV | 8753.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 945 | Table 5, p. 20 | 9,239 | Table 5 | instrument_series_table5 CSV | 9239.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 946 | Table 5, p. 20 | 1 | Table 5 | instrument_series_table5 CSV | 1.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 947 | Table 5, p. 20 | 1,494 | Table 5 | instrument_series_table5 CSV | 1494.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 948 | Table 5, p. 20 | 10,151 | Table 5 | instrument_series_table5 CSV | 10151.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 949 | Table 5, p. 20 | n/r | Table 5 | instrument_series_table5 CSV | n/r | CIRC | MATCH | not recorded in the paper and in the CSV |
| 950 | Table 5, p. 20 | 15,104 | Table 5 | instrument_series_table5 CSV | 15104.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 951 | Table 5, p. 20 | 28,733 | Table 5 | instrument_series_table5 CSV | 28733.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 952 | Table 5, p. 20 | 33,203 | Table 5 | instrument_series_table5 CSV | 33203.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 953 | Table 5, p. 20 | 33,560 | Table 5 | instrument_series_table5 CSV | 33560.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 954 | Table 5, p. 20 | 0 | Table 5 | instrument_series_table5 CSV | 0.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 955 | Table 5, p. 20 | 909 | Table 5 | instrument_series_table5 CSV | 909.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 956 | Table 5, p. 20 | 2,639 | Table 5 | instrument_series_table5 CSV | 2639.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 957 | Table 5, p. 20 | n/r | Table 5 | instrument_series_table5 CSV | n/r | CIRC | MATCH | not recorded in the paper and in the CSV |
| 958 | Table 5, p. 20 | 2,331 | Table 5 | instrument_series_table5 CSV | 2331.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 959 | Table 5, p. 20 | 2,336 | Table 5 | instrument_series_table5 CSV | 2336.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 960 | Table 5, p. 20 | 1,276 | Table 5 | instrument_series_table5 CSV | 1276.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 961 | Table 5, p. 20 | n/r | Table 5 | instrument_series_table5 CSV | n/r | CIRC | MATCH | not recorded in the paper and in the CSV |
| 962 | Table 5, p. 20 | 1 | Table 5 | total less the three reported bands | 1.0 | CALC | MATCH |  |
| 963 | Table 5, p. 20 | 255 | Table 5 | total less the three reported bands | 255.0 | CALC | MATCH |  |
| 964 | Table 5, p. 20 | 314 | Table 5 | total less the three reported bands | 314.0 | CALC | MATCH |  |
| 965 | Table 5, p. 20 | n/r | Table 5 | instrument_series_table5 CSV | n/r | CIRC | MATCH | not recorded in the paper and in the CSV |
| 966 | Table 5, p. 20 | 242 | Table 5 | total less the three reported bands | 242.0 | CALC | MATCH |  |
| 967 | Table 5, p. 20 | 250 | Table 5 | total less the three reported bands | 250.0 | CALC | MATCH |  |
| 968 | Table 5, p. 20 | 70 | Table 5 | total less the three reported bands | 70.0 | CALC | MATCH |  |
| 969 | Table 5, p. 20 | n/r | Table 5 | instrument_series_table5 CSV | n/r | CIRC | MATCH | not recorded in the paper and in the CSV |
| 970 | Table 5, p. 20 | 2 | Table 5 | instrument_series_table5 CSV | 2.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 971 | Table 5, p. 20 | 22,016 | Table 5 | instrument_series_table5 CSV | 22016.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 972 | Table 5, p. 20 | 51,517 | Table 5 | instrument_series_table5 CSV | 51517.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 973 | Table 5, p. 20 | ≈51,800 | Table 5 | instrument_series_table5 CSV | 51800.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 974 | Table 5, p. 20 | 92,897 | Table 5 | instrument_series_table5 CSV | 92897.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 975 | Table 5, p. 20 | 244,041 | Table 5 | instrument_series_table5 CSV | 244041.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 976 | Table 5, p. 20 | 221,933 | Table 5 | instrument_series_table5 CSV | 221933.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 977 | Table 5, p. 20 | n/r | Table 5 | instrument_series_table5 CSV | n/r | CIRC | MATCH | not recorded in the paper and in the CSV |
| 978 | Table 5, p. 20 | 0 | Table 5 | instrument_series_table5 CSV | 0.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 979 | Table 5, p. 20 | 1 | Table 5 | instrument_series_table5 CSV | 1.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 980 | Table 5, p. 20 | 19 | Table 5 | instrument_series_table5 CSV | 19.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 981 | Table 5, p. 20 | 19 | Table 5 | instrument_series_table5 CSV | 19.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 982 | Table 5, p. 20 | 415 | Table 5 | instrument_series_table5 CSV | 415.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 983 | Table 5, p. 20 | 828 | Table 5 | instrument_series_table5 CSV | 828.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 984 | Table 5, p. 20 | 909 | Table 5 | instrument_series_table5 CSV | 909.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 985 | Table 5, p. 20 | 913 | Table 5 | instrument_series_table5 CSV | 913.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 986 | Table 5, p. 20 | 0 | Table 5 | instrument_series_table5 CSV | 0.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 987 | Table 5, p. 20 | 1,603 | Table 5 | instrument_series_table5 CSV | 1603.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 988 | Table 5, p. 20 | 3,725 | Table 5 | instrument_series_table5 CSV | 3725.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 989 | Table 5, p. 20 | n/r | Table 5 | instrument_series_table5 CSV | n/r | CIRC | MATCH | not recorded in the paper and in the CSV |
| 990 | Table 5, p. 20 | 6,390 | Table 5 | instrument_series_table5 CSV | 6390.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 991 | Table 5, p. 20 | 10,266 | Table 5 | instrument_series_table5 CSV | 10266.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 992 | Table 5, p. 20 | 14,823 | Table 5 | instrument_series_table5 CSV | 14823.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 993 | Table 5, p. 20 | 17,206 | Table 5 | instrument_series_table5 CSV | 17206.0 | CIRC | MATCH | circular: the CSV is parsed from this table; the dashboard read is not archived |
| 994 | §8, p. 20 | It closes every full column | and not a fourth measurement. It closes every full column. The row is small, | Table 5: total less the three bands equals the derived row in all six full columns | agrees | CALC | MATCH | statement in words |
| 995 | §8, p. 20 | 37 | nguish them. **At the primary checkpoint**, 37 days after publication, the s | 26 July to 1 September 2026 by the calendar | 37.0 | CALC | MATCH |  |
| 996 | §8, p. 20 | 15,830 | 37 days after publication, the section held 15,830 ranking positions, 1,874 of t | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 15830.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 997 | §8, p. 20 | 1,874 | , the section held 15,830 ranking positions, 1,874 of them in positions 1 to 3, | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 1874.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 998 | §8, p. 20 | 51,800 | them in positions 1 to 3, with an estimated 51,800 monthly visits and nineteen r | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 51800.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 999 | §8, p. 20 | nineteen | with an estimated 51,800 monthly visits and nineteen referring domains. By day 77 | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 19.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1000 | §8, p. 20 | 43,980 | ineteen referring domains. By day 77 it held 43,980 positions across 441 URLs hol | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 43980.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1001 | §8, p. 20 | 441 | s. By day 77 it held 43,980 positions across 441 URLs holding at least one pos | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 441.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1002 | §8, p. 20 | 29,000 | Ls holding at least one position, ranked for 29,000 keywords in one instrument an | single_reads_2026-10.csv | 29000.0 | FILE | MATCH | dashboard read, not archived |
| 1003 | §8, p. 20 | 58,586 | ed for 29,000 keywords in one instrument and 58,586 in the other, was recorded as | single_reads_2026-10.csv | 58586.0 | FILE | MATCH | dashboard read, not archived |
| 1004 | §8, p. 20 | 7,455 | as a cited source in Google AI Overviews on 7,455 keywords, and appeared in 17, | instrument_series_table3 CSV (parsed from Table 3 itself) | 7455.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1005 | §8, p. 20 | 17,206 | Overviews on 7,455 keywords, and appeared in 17,206 stored AI answers. **Concent | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 17206.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1006 | §8, p. 20 | 441 | tored AI answers. **Concentration.** Of the 441 URLs holding a position on 11 | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 441.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1007 | §8, p. 20 | 22.8 | on 11 October, the ten highest-traffic carry 22.8% of estimated visits and the | single_reads_2026-10.csv | 22.8 | FILE | MATCH | dashboard read, not archived |
| 1008 | §8, p. 20 | 50 | carry 22.8% of estimated visits and the top 50 carry 64.9%, both from one in | single_reads_2026-10.csv | 50.0 | FILE | MATCH | stated in the quantity's name |
| 1009 | §8, p. 20 | 64.9 | .8% of estimated visits and the top 50 carry 64.9%, both from one instrument an | single_reads_2026-10.csv | 64.9 | FILE | MATCH | dashboard read, not archived |
| 1010 | §8, p. 20 | 441 | a universe selected by the outcome. Fifty of 441 is 11% of the pages carrying | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 441.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1011 | §8, p. 20 | 11 | rse selected by the outcome. Fifty of 441 is 11% of the pages carrying about | arithmetic on the paper's own counts | 11.337868 | CALC | MATCH |  |
| 1012 | §8, p. 20 | 58,586 | the volume tools do not report.** Among the 58,586 US keywords, the lowest-traff | single_reads_2026-10.csv | 58586.0 | FILE | MATCH | dashboard read, not archived |
| 1013 | §8, p. 20 | 40 | s, numeric fragments and question forms with 40 to 170 reported searches a mo | single_reads_2026-10.csv | 40.0 | FILE | MATCH | dashboard read, not archived |
| 1014 | §8, p. 20 | 170 | eric fragments and question forms with 40 to 170 reported searches a month or | single_reads_2026-10.csv | 170.0 | FILE | MATCH | dashboard read, not archived |
| 1015 | §8, p. 20 | 105 | a month or none at all. The section ranks in 105 countries, with 18.5% of Ahre | single_reads_2026-10.csv | 105.0 | FILE | MATCH | dashboard read, not archived |
| 1016 | §8, p. 20 | 18.5 | ll. The section ranks in 105 countries, with 18.5% of Ahrefs-estimated visits f | single_reads_2026-10.csv | 18.5 | FILE | MATCH | dashboard read, not archived |
| 1017 | §9.1, p. 20 | 474 | t enumerate codes, cities and maps: New York 474 answers, California 337, Texa | single_reads_2026-10.csv | 474.0 | FILE | MATCH | dashboard read, not archived |
| 1018 | §9.1, p. 20 | 337 | s and maps: New York 474 answers, California 337, Texas 322, Florida 304, and | single_reads_2026-10.csv | 337.0 | FILE | MATCH | dashboard read, not archived |
| 1019 | §9.1, p. 20 | 322 | New York 474 answers, California 337, Texas 322, Florida 304, and the nationa | single_reads_2026-10.csv | 322.0 | FILE | MATCH | dashboard read, not archived |
| 1020 | §9.1, p. 20 | 304 | answers, California 337, Texas 322, Florida 304, and the national hub 294. Ea | single_reads_2026-10.csv | 304.0 | FILE | MATCH | dashboard read, not archived |
| 1021 | §9.1, p. 20 | 294 | Texas 322, Florida 304, and the national hub 294. Each exceeds any individual | single_reads_2026-10.csv | 294.0 | FILE | MATCH | dashboard read, not archived |
| 1022 | §9.1, p. 20 | Each exceeds any individual code page | 04, and the national hub 294. Each exceeds any individual code page: 214 Dallas 238, 78 | single_reads_2026-10.csv: smallest hub 294, largest code page 238 | agrees | FILE | MATCH | statement in words |
| 1023 | §9.1, p. 20 | 238 | exceeds any individual code page: 214 Dallas 238, 786 Miami 228, 404 Atlanta 2 | single_reads_2026-10.csv | 238.0 | FILE | MATCH | dashboard read, not archived |
| 1024 | §9.1, p. 20 | 228 | ividual code page: 214 Dallas 238, 786 Miami 228, 404 Atlanta 218 (Figure 9). | single_reads_2026-10.csv | 228.0 | FILE | MATCH | dashboard read, not archived |
| 1025 | §9.1, p. 20 | 218 | : 214 Dallas 238, 786 Miami 228, 404 Atlanta 218 (Figure 9). A hub lists many | single_reads_2026-10.csv | 218.0 | FILE | MATCH | dashboard read, not archived |
| 1026 | §9.1, p. 20 | per code it lists, a state hub is cited less often than the most-cited code pages | questions about all of them: per code it lists, a state hub is cited less often than the most-cited code pages. The observation is | section_code_pages_2026-10-14.csv: NY 20.6, CA 8.2, TX 11.1, FL 13.2 answers per code against 238 | agrees | CALC | MATCH | statement in words |
| 1027 | Figure 9, p. 20 | 474 | printed inside fig5_cited.pdf | single_reads_2026-10.csv | 474.0 | FILE | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1028 | Figure 9, p. 20 | 337 | printed inside fig5_cited.pdf | single_reads_2026-10.csv | 337.0 | FILE | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1029 | Figure 9, p. 20 | 322 | printed inside fig5_cited.pdf | single_reads_2026-10.csv | 322.0 | FILE | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1030 | Figure 9, p. 20 | 304 | printed inside fig5_cited.pdf | single_reads_2026-10.csv | 304.0 | FILE | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1031 | Figure 9, p. 20 | 294 | printed inside fig5_cited.pdf | single_reads_2026-10.csv | 294.0 | FILE | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1032 | Figure 9, p. 20 | 238 | printed inside fig5_cited.pdf | single_reads_2026-10.csv | 238.0 | FILE | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1033 | Figure 9, p. 20 | 228 | printed inside fig5_cited.pdf | single_reads_2026-10.csv | 228.0 | FILE | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1034 | Figure 9, p. 20 | 218 | printed inside fig5_cited.pdf | single_reads_2026-10.csv | 218.0 | FILE | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1035 | §9.2, p. 21 | 13 | two voice vendors, at Domain Ratings between 13 and 83. Wikipedia, at 97, is | single_reads_2026-10.csv | 13.0 | FILE | MATCH | dashboard read, not archived |
| 1036 | §9.2, p. 21 | 83 | ce vendors, at Domain Ratings between 13 and 83. Wikipedia, at 97, is co-cite | single_reads_2026-10.csv | 83.0 | FILE | MATCH | dashboard read, not archived |
| 1037 | §9.2, p. 21 | 97 | ain Ratings between 13 and 83. Wikipedia, at 97, is co-cited in roughly 11,00 | single_reads_2026-10.csv | 97.0 | FILE | MATCH | dashboard read, not archived |
| 1038 | §9.2, p. 21 | 11,000 | 83. Wikipedia, at 97, is co-cited in roughly 11,000 of the answers that cite the | single_reads_2026-10.csv (about 11,000) | 11000.0 | FILE | MATCH | dashboard read, not archived |
| 1039 | §9.2, p. 21 | 9 | arriers of comparable authority are co-cited 9 times (Domain Rating 91) and | single_reads_2026-10.csv | 9.0 | FILE | MATCH | dashboard read, not archived |
| 1040 | §9.2, p. 21 | 91 | uthority are co-cited 9 times (Domain Rating 91) and 240 times (Domain Rating | single_reads_2026-10.csv | 91.0 | FILE | MATCH | dashboard read, not archived |
| 1041 | §9.2, p. 21 | 240 | are co-cited 9 times (Domain Rating 91) and 240 times (Domain Rating 87), aga | single_reads_2026-10.csv | 240.0 | FILE | MATCH | dashboard read, not archived |
| 1042 | §9.2, p. 21 | 87 | main Rating 91) and 240 times (Domain Rating 87), against the section's 17,20 | single_reads_2026-10.csv | 87.0 | FILE | MATCH | dashboard read, not archived |
| 1043 | §9.2, p. 21 | 17,206 | es (Domain Rating 87), against the section's 17,206. Neither published a page per | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 17206.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1044 | §10, p. 21 | nineteen | mains through 31 July, one on 10 August, and nineteen on 25 August and still ninete | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 19.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1045 | §10, p. 21 | nineteen | August, and nineteen on 25 August and still nineteen on 1 September, by which date | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 19.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1046 | §10, p. 21 | 15,830 | n 1 September, by which date it already held 15,830 ranking positions. The refer | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 15830.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1047 | §10, p. 21 | 913 | 11 October is reported by the instrument as 913, while the same instrument's | single_reads_2026-10.csv | 913.0 | FILE | MATCH | dashboard read, not archived |
| 1048 | §10, p. 21 | 909 | ile the same instrument's daily series gives 909 at day 75 and its new-and-los | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 909.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1049 | §10, p. 21 | 917 | its new-and-lost report for September gives 917 new against 95 lost, which wi | single_reads_2026-10.csv | 917.0 | FILE | MATCH | dashboard read, not archived |
| 1050 | §10, p. 21 | 95 | t report for September gives 917 new against 95 lost, which with nineteen at | single_reads_2026-10.csv | 95.0 | FILE | MATCH | dashboard read, not archived |
| 1051 | §10, p. 21 | nineteen | er gives 917 new against 95 lost, which with nineteen at day 37 implies about 841 a | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 19.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1052 | §10, p. 21 | 841 | which with nineteen at day 37 implies about 841 at the end of September. The | arithmetic on the paper's own counts | 841 | CALC | MATCH |  |
| 1053 | §10, p. 21 | nineteen | here turns on the exact count; the shape is nineteen through day 37, several hundr | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 19.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1054 | §10, p. 21 | 61.9 | s not in doubt. They are automated networks: 61.9% .info, 26.4% .asia, 10.2% .x | single_reads_2026-10.csv | 61.9 | FILE | MATCH | dashboard read, not archived |
| 1055 | §10, p. 21 | 26.4 | t. They are automated networks: 61.9% .info, 26.4% .asia, 10.2% .xyz, every lin | single_reads_2026-10.csv | 26.4 | FILE | MATCH | dashboard read, not archived |
| 1056 | §10, p. 21 | 10.2 | utomated networks: 61.9% .info, 26.4% .asia, 10.2% .xyz, every linking page at | single_reads_2026-10.csv | 10.2 | FILE | MATCH | dashboard read, not archived |
| 1057 | §10, p. 21 | 80 | link sellers. The second instrument indexes 80 referring domains for the sub | single_reads_2026-10.csv | 80.0 | FILE | MATCH | dashboard read, not archived |
| 1058 | §10, p. 21 | 88 | exes 80 referring domains for the subfolder, 88% from domains at Authority Sc | single_reads_2026-10.csv | 88.0 | FILE | MATCH | dashboard read, not archived |
| 1059 | §10, p. 21 | 75 | 88% from domains at Authority Score 0–10 and 75% on .xyz. ### 10.1 What the | single_reads_2026-10.csv | 75.0 | FILE | MATCH | dashboard read, not archived |
| 1060 | Table 6, p. 22 | 0 | Table 6 | Table 5 referring domains | 0.0 | CALC | MATCH |  |
| 1061 | Table 6, p. 22 | 1 | Table 6 | Table 5 referring domains | 1.0 | CALC | MATCH |  |
| 1062 | Table 6, p. 22 | 1 | Table 6 | difference of Table 5 referring domains | 1.0 | CALC | MATCH |  |
| 1063 | Table 6, p. 22 | 3,383 | Table 6 | difference of Table 5 positions | 3383.0 | CALC | MATCH |  |
| 1064 | Table 6, p. 22 | 226 | Table 6 | positions gained over the interval's days | 225.533333 | CALC | MATCH |  |
| 1065 | Table 6, p. 22 | 1 | Table 6 | Table 5 referring domains | 1.0 | CALC | MATCH |  |
| 1066 | Table 6, p. 22 | 19 | Table 6 | Table 5 referring domains | 19.0 | CALC | MATCH |  |
| 1067 | Table 6, p. 22 | 18 | Table 6 | difference of Table 5 referring domains | 18.0 | CALC | MATCH |  |
| 1068 | Table 6, p. 22 | 11,520 | Table 6 | difference of Table 5 positions | 11520.0 | CALC | MATCH |  |
| 1069 | Table 6, p. 22 | 768 | Table 6 | positions gained over the interval's days | 768.0 | CALC | MATCH |  |
| 1070 | Table 6, p. 22 | 19 | Table 6 | Table 5 referring domains | 19.0 | CALC | MATCH |  |
| 1071 | Table 6, p. 22 | 19 | Table 6 | Table 5 referring domains | 19.0 | CALC | MATCH |  |
| 1072 | Table 6, p. 22 | 0 | Table 6 | difference of Table 5 referring domains | 0.0 | CALC | MATCH |  |
| 1073 | Table 6, p. 22 | 925 | Table 6 | difference of Table 5 positions | 925.0 | CALC | MATCH |  |
| 1074 | Table 6, p. 22 | 132 | Table 6 | positions gained over the interval's days | 132.142857 | CALC | MATCH |  |
| 1075 | Table 6, p. 22 | 19 | Table 6 | Table 5 referring domains | 19.0 | CALC | MATCH |  |
| 1076 | Table 6, p. 22 | 415 | Table 6 | Table 5 referring domains | 415.0 | CALC | MATCH |  |
| 1077 | Table 6, p. 22 | 396 | Table 6 | difference of Table 5 referring domains | 396.0 | CALC | MATCH |  |
| 1078 | Table 6, p. 22 | 4,496 | Table 6 | difference of Table 5 positions | 4496.0 | CALC | MATCH |  |
| 1079 | Table 6, p. 22 | 562 | Table 6 | positions gained over the interval's days | 562.0 | CALC | MATCH |  |
| 1080 | Table 6, p. 22 | 415 | Table 6 | Table 5 referring domains | 415.0 | CALC | MATCH |  |
| 1081 | Table 6, p. 22 | 828 | Table 6 | Table 5 referring domains | 828.0 | CALC | MATCH |  |
| 1082 | Table 6, p. 22 | 413 | Table 6 | difference of Table 5 referring domains | 413.0 | CALC | MATCH |  |
| 1083 | Table 6, p. 22 | 16,815 | Table 6 | difference of Table 5 positions | 16815.0 | CALC | MATCH |  |
| 1084 | Table 6, p. 22 | 1,121 | Table 6 | positions gained over the interval's days | 1121.0 | CALC | MATCH |  |
| 1085 | Table 6, p. 22 | 828 | Table 6 | Table 5 referring domains | 828.0 | CALC | MATCH |  |
| 1086 | Table 6, p. 22 | 909 | Table 6 | Table 5 referring domains | 909.0 | CALC | MATCH |  |
| 1087 | Table 6, p. 22 | 81 | Table 6 | difference of Table 5 referring domains | 81.0 | CALC | MATCH |  |
| 1088 | Table 6, p. 22 | 6,161 | Table 6 | difference of Table 5 positions | 6161.0 | CALC | MATCH |  |
| 1089 | Table 6, p. 22 | 411 | Table 6 | positions gained over the interval's days | 410.733333 | CALC | MATCH |  |
| 1090 | Figure 10, p. 22 | 15,830 | printed inside fig6_positions.pdf | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 15830.0 | CIRC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1091 | Figure 10, p. 22 | 43,980 | printed inside fig6_positions.pdf | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 43980.0 | CIRC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1092 | Figure 10, p. 22 | 226 | printed inside fig6_positions.pdf | (3,385 - 2) / 15, from Table 5 | 226.0 | CALC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1093 | Figure 10, p. 22 | 768 | printed inside fig6_positions.pdf | (14,905 - 3,385) / 15, from Table 5 | 768.0 | CALC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1094 | Figure 10, p. 22 | 132 | printed inside fig6_positions.pdf | (15,830 - 14,905) / 7, from Table 5 | 132.0 | CALC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1095 | Figure 10, p. 22 | 562 | printed inside fig6_positions.pdf | (20,326 - 15,830) / 8, from Table 5 | 562.0 | CALC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1096 | Figure 10, p. 22 | 1121 | printed inside fig6_positions.pdf | (37,141 - 20,326) / 15, from Table 5 | 1121.0 | CALC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1097 | Figure 10, p. 22 | 411 | printed inside fig6_positions.pdf | (43,302 - 37,141) / 15, from Table 5 | 411.0 | CALC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1098 | Figure 10, p. 22 | 415 | printed inside fig6_positions.pdf | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 415.0 | CIRC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1099 | Figure 10, p. 22 | 828 | printed inside fig6_positions.pdf | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 828.0 | CIRC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1100 | Figure 10, p. 22 | 909 | printed inside fig6_positions.pdf | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 909.0 | CIRC | MATCH | label in the shipped figure; the figure script reruns to identical bytes (PNG) |
| 1101 | §10.1, p. 22 | 77 | Ranking positions and the link profile over 77 days. Upper panel: ranking po | 26 July to 11 October 2026 by the calendar | 77.0 | CALC | MATCH |  |
| 1102 | §10.1, p. 22 | 984 | that are not checkpoints in Table 5: day 6 (984 positions, 186 in 1–3) and da | single_reads_2026-10.csv | 984.0 | FILE | MATCH | dashboard read, not archived |
| 1103 | §10.1, p. 22 | 186 | heckpoints in Table 5: day 6 (984 positions, 186 in 1–3) and day 67 (38,801 an | single_reads_2026-10.csv | 186.0 | FILE | MATCH | dashboard read, not archived |
| 1104 | §10.1, p. 22 | 38,801 | ay 6 (984 positions, 186 in 1–3) and day 67 (38,801 and 6,942).](fig6_positions.p | single_reads_2026-10.csv | 38801.0 | FILE | MATCH | dashboard read, not archived |
| 1105 | §10.1, p. 22 | 6,942 | ositions, 186 in 1–3) and day 67 (38,801 and 6,942).](fig6_positions.pdf) Of th | single_reads_2026-10.csv | 6942.0 | FILE | MATCH | dashboard read, not archived |
| 1106 | §10.1, p. 21 | 43,302 | 801 and 6,942).](fig6_positions.pdf) Of the 43,302 positions held at day 75, 15, | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 43302.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1107 | §10.1, p. 21 | 15,830 | df) Of the 43,302 positions held at day 75, 15,830 (36.6%) were held at day 37 a | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 15830.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1108 | §10.1, p. 21 | 36.6 | the 43,302 positions held at day 75, 15,830 (36.6%) were held at day 37 and 27, | arithmetic on the paper's own counts | 36.557203 | CALC | MATCH |  |
| 1109 | §10.1, p. 21 | 27,472 | y 75, 15,830 (36.6%) were held at day 37 and 27,472 (63.4%) were acquired after t | 43,302 - 15,830 | 27472.0 | CALC | MATCH |  |
| 1110 | §10.1, p. 21 | 63.4 | ,830 (36.6%) were held at day 37 and 27,472 (63.4%) were acquired after the net | arithmetic on the paper's own counts | 63.442797 | CALC | MATCH |  |
| 1111 | §10.1, p. 21 | 53.1 | t share is itself bounded rather than exact: 53.1% to 63.4%. For AI answers, da | arithmetic on the paper's own counts | 53.059905 | CALC | MATCH |  |
| 1112 | §10.1, p. 21 | 63.4 | s itself bounded rather than exact: 53.1% to 63.4%. For AI answers, day 37 is n | arithmetic on the paper's own counts | 63.442797 | CALC | MATCH |  |
| 1113 | §10.1, p. 21 | 56.9 | orded, so the corresponding share is bounded 56.9% to 74.9%. **What survives.* | arithmetic on the paper's own counts | 56.891318 | CALC | MATCH |  |
| 1114 | §10.1, p. 21 | 74.9 | the corresponding share is bounded 56.9% to 74.9%. **What survives.** A resul | arithmetic on the paper's own counts | 74.870134 | CALC | MATCH |  |
| 1115 | §10.1, p. 21 | 15,830 | 9% to 74.9%. **What survives.** A result of 15,830 ranking positions and 1,874 t | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 15830.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1116 | §10.1, p. 21 | 1,874 | .** A result of 15,830 ranking positions and 1,874 top-three positions was estab | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 1874.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1117 | §10.1, p. 21 | nineteen | 874 top-three positions was established with nineteen referring domains, a count un | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 19.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1118 | §10.1, p. 21 | nineteen | not show that links played no part, because nineteen referring domains are not non | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 19.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1119 | §10.1, p. 21 | 768 | as showing it.** The fastest clean interval, 768 a day across days 15 to 30, i | (14,905 - 3,385) / 15, from Table 5 | 768.0 | CALC | MATCH |  |
| 1120 | §10.1, p. 21 | 37 | interval, 768 a day across days 15 to 30, is 37% faster than the 562 a day of | arithmetic on the paper's own counts | 36.654804 | CALC | MATCH |  |
| 1121 | §10.1, p. 21 | 562 | across days 15 to 30, is 37% faster than the 562 a day of the arrival interval | (20,326 - 15,830) / 8, from Table 5 | 562.0 | CALC | MATCH |  |
| 1122 | §10.1, p. 21 | 132 | 2 a day of the arrival interval. Reading the 132-a-day trough immediately befo | (15,830 - 14,905) / 7, from Table 5 | 132.0 | CALC | MATCH |  |
| 1123 | §10.1, p. 21 | 441 | oes not survive showing all six intervals. A 441-page section entering an inde | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 441.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1124 | Table 7, p. 23 | 3 | Table 7 | none | None | NONE | CANNOT RUN | the author's reconstruction from project records; no source in the bundle |
| 1125 | Table 7, p. 23 | 2 | Table 7 | none | None | NONE | CANNOT RUN | the author's reconstruction from project records; no source in the bundle |
| 1126 | Table 7, p. 23 | 0 | Table 7 | none | None | NONE | CANNOT RUN | the author's reconstruction from project records; no source in the bundle |
| 1127 | Table 7, p. 23 | 0 | Table 7 | none | None | NONE | CANNOT RUN | the author's reconstruction from project records; no source in the bundle |
| 1128 | Table 7, p. 23 | 6,000 | Table 7 | none | None | NONE | CANNOT RUN | the author's reconstruction from project records; no source in the bundle |
| 1129 | §11.2, p. 23 | thirteen | ent collected no first-party surface: of the thirteen demand-surface types the rele | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1130 | §11.2, p. 23 | four | synthetic records, flagged as synthetic, on four of the thirteen surface types | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1131 | §11.2, p. 23 | thirteen | ecords, flagged as synthetic, on four of the thirteen surface types, and untested o | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1132 | §12, p. 23 | 2.94 | re, which differ by a factor that falls from 2.94 to 1.34; both are reported, a | arithmetic on Table 3 / its released CSV | 2.93617 | CALC | MATCH |  |
| 1133 | §12, p. 23 | 1.34 | h differ by a factor that falls from 2.94 to 1.34; both are reported, and a com | arithmetic on Table 3 / its released CSV | 1.343796 | CALC | MATCH |  |
| 1134 | §12, p. 23 | twelve | on the territory pairing. External validity: twelve purposively chosen prefixes o | data/analyze.py | 12.0 | RUN | MATCH |  |
| 1135 | §12, p. 23 | 77 | ixes on one domain, one of them followed for 77 days; one vendor pair; one re | 26 July to 11 October 2026 by the calendar | 77.0 | CALC | MATCH |  |
| 1136 | §12, p. 23 | about two in three correct | easured but modest precision (about two in three correct, half for single-wo | r2_link_check.py: 65.0% to 66.8% | agrees | RUN | MATCH | statement in words |
| 1137 | §12, p. 23 | half for single-word labels | (about two in three correct, half for single-word labels; judged by blind AI | r2_link_check.py: 48.0% and 50.0% | agrees | RUN | MATCH | statement in words |
| 1138 | §12, p. 23 | 53.1 | sponded. The automated link network: between 53.1% and 63.4% of day-75 position | arithmetic on the paper's own counts | 53.059905 | CALC | MATCH |  |
| 1139 | §12, p. 23 | 63.4 | he automated link network: between 53.1% and 63.4% of day-75 positions postdate | arithmetic on the paper's own counts | 63.442797 | CALC | MATCH |  |
| 1140 | §12, p. 24 | 77 | industry, one class, a top-authority domain, 77 days, six stated conditions. | 26 July to 11 October 2026 by the calendar | 77.0 | CALC | MATCH |  |
| 1141 | §13, p. 24 | six | a US state or the District of Columbia; the six territory codes without pages | wikipedia_demand_372.md ('excluding the six territory codes') | 6.0 | FILE | MATCH |  |
| 1142 | §13, p. 24 | 1.2 | of the individual code pages they enumerate (1.2 to 2.0 times the most-cited c | arithmetic on Section 9.1's counts | 1.235294 | CALC | MATCH |  |
| 1143 | §13, p. 24 | 2.0 | individual code pages they enumerate (1.2 to 2.0 times the most-cited code pag | arithmetic on Section 9.1's counts | 1.991597 | CALC | MATCH |  |
| 1144 | §13, p. 24 | 924 | the set with its digest. The example ships a 924-query demonstration over the | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1145 | §13, p. 24 | 66 | ple ships a 924-query demonstration over the 66 codes in its registry extract | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1146 | §13, p. 24 | f05ce279942be5f8 | 66 codes in its registry extract, at digest `f05ce279942be5f8`; the set for the full class | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1147 | §13, p. 24 | 0.5 | s. Five scoring parameters are locked: **α = 0.5, β = 0.5, damping = 0.85, at | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1148 | §13, p. 24 | 0.5 | coring parameters are locked: **α = 0.5, β = 0.5, damping = 0.85, at least thr | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1149 | §13, p. 24 | 0.85 | rs are locked: **α = 0.5, β = 0.5, damping = 0.85, at least three phrasings per | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1150 | §13, p. 24 | 7290a2235d8de05f | ion and a mean class aggregate, lock digest `7290a2235d8de05f`, locked 12 October 2026**. T | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1151 | §13, p. 24 | 372 | e its outcomes were read.** Every one of the 372 geographic codes in service r | wiki_demand_analysis.py | 372.0 | RUN | MATCH |  |
| 1152 | §13, p. 24 | 971,506 | est); the stamp is anchored in Bitcoin block 971,506, mined at 04:05 UTC on 15 Oct | protocols_manifest and framework manifest .ots proofs, read here; merkle root equals the block's | 971506.0 | CALC | MATCH |  |
| 1153 | §13, p. 24 | 04:05 | anchored in Bitcoin block 971,506, mined at 04:05 UTC on 15 October 2026. Earli | blockstream.info, block 971,506 (04:05:42 UTC) | 04:05 | BLOCK | MATCH | merkle root equal to the proof's digest |
| 1154 | §13, p. 24 | 971,522 | est and anchored separately in Bitcoin block 971,522 (06:10 UTC on 15 October 2026 | framework amendment .ots proof, read here; merkle root equals the block's | 971522.0 | CALC | MATCH |  |
| 1155 | §13, p. 24 | 06:10 | nchored separately in Bitcoin block 971,522 (06:10 UTC on 15 October 2026), reco | blockstream.info, block 971,522 (06:10:20 UTC) | 06:10 | BLOCK | MATCH | merkle root equal to the proof's digest |
| 1156 | §13, p. 25 | eleven | ion of Measurement 3 (Section 7).** The same eleven sectors and eight surfaces at | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 1157 | §13, p. 25 | eight | 3 (Section 7).** The same eleven sectors and eight surfaces at the level of the | cross_sector_type_shares.csv: eight surfaces | 8.0 | CALC | MATCH |  |
| 1158 | §13, p. 25 | 10,000 | m. Amendment A1 fixed a sampling rule of the 10,000 highest-volume prompts per se | cross_sector_ai_citation_study.md (A1) | 10000.0 | FILE | MATCH |  |
| 1159 | §13, p. 25 | 10,000 | s no volume sort, the exports took the first 10,000 rows in the vendor's default | none | None | NONE | CANNOT RUN | the stopped prompt-level exports are not in the bundle |
| 1160 | §13, p. 25 | 14 | ter two small sectors, Energy and Utilities (14 of 88 exports, 44,463 answers | cross_sector_ai_citation_study.md | 14.0 | FILE | MATCH |  |
| 1161 | §13, p. 25 | 88 | o small sectors, Energy and Utilities (14 of 88 exports, 44,463 answers), whe | 11 sectors x 8 surfaces | 88.0 | CALC | MATCH |  |
| 1162 | §13, p. 25 | 44,463 | ors, Energy and Utilities (14 of 88 exports, 44,463 answers), when the vendor's t | cross_sector_ai_citation_study.md | 44463.0 | FILE | MATCH |  |
| 1163 | §13, p. 25 | twelve | fixed in advance, and re-reads the original twelve on a later date, was stamped | data/analyze.py | 12.0 | RUN | MATCH |  |
| 1164 | §13.1, p. 25 | thirteen | laim made here. **Surfaces that move.** The thirteen surface types the implementat | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1165 | §13.1, p. 25 | 109 | e note [Pagadala 2026]. Costco is one of the 109 companies of Section 7. Loggi | cross_sector_companies.csv | 109 | CALC | MATCH |  |
| 1166 | §14, p. 25 | 149994a | he 2.0, version 0.2.0, cited here as commit `149994a` of 12 October 2026, because | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1167 | §14, p. 25 | 22 | assistant under the author's direction (all 22 commits at that point are AI- | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1168 | §14, p. 25 | 21 | ll 22 commits at that point are AI-assisted: 21 carry the assistant as author | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1169 | §14, p. 25 | thirteen | the example uses. The demand layer declares thirteen surface types, ships two gene | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1170 | §14, p. 25 | 924 | atform is left to the deployment. The frozen 924-query set, the parameter lock | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1171 | §14, p. 26 | twelve | d. **Data released with this version.** The twelve-prefix cross-section (Table 4 | data/analyze.py | 12.0 | RUN | MATCH |  |
| 1172 | §14, p. 26 | 109 | 7, the design file with its amendments, the 109-company list with its source, | cross_sector_companies.csv | 109 | CALC | MATCH |  |
| 1173 | §14, p. 26 | 14,823 | e Brand Radar answer count, which moved from 14,823 (9 October) to 17,206 (11 Oct | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 14823.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1174 | §14, p. 26 | 17,206 | ount, which moved from 14,823 (9 October) to 17,206 (11 October) and 17,400 (12 O | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 17206.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1175 | §14, p. 26 | 17,400 | 4,823 (9 October) to 17,206 (11 October) and 17,400 (12 October) as stored answer | single_reads_2026-10.csv | 17400.0 | FILE | MATCH | dashboard read, not archived |
| 1176 | §14, p. 26 | 3 | ies; the October run-rate had moved by about 3% (worldwide 1,910,867, US 1,6 | arithmetic on the paper's own counts | 3.064801 | CALC | MATCH |  |
| 1177 | §14, p. 26 | 1,910,867 | er run-rate had moved by about 3% (worldwide 1,910,867, US 1,659,636). The Ahrefs da | single_reads_2026-10.csv | 1910867.0 | FILE | MATCH | dashboard read, not archived |
| 1178 | §14, p. 26 | 1,659,636 | d moved by about 3% (worldwide 1,910,867, US 1,659,636). The Ahrefs daily series sho | single_reads_2026-10.csv | 1659636.0 | FILE | MATCH | dashboard read, not archived |
| 1179 | §14, p. 26 | 13 | stly specialist directories at Domain Rating 13 to 83, in a public search ind | single_reads_2026-10.csv | 13.0 | FILE | MATCH | dashboard read, not archived |
| 1180 | §14, p. 26 | 83 | pecialist directories at Domain Rating 13 to 83, in a public search index. Th | single_reads_2026-10.csv | 83.0 | FILE | MATCH | dashboard read, not archived |
| 1181 | §14, p. 27 | 109 | on 12); that organization is also one of the 109 companies in Section 7, inclu | cross_sector_companies.csv | 109 | CALC | MATCH |  |
| 1182 | §14, p. 27 | Separate agents reproduced the source bundle four times in clean folders | without the withheld exports. Separate agents reproduced the source bundle four times in clean folders on 15 October 2026. | four folders in 08_REVIEW | agrees | CALC | MATCH | statement in words |
| 1183 | §14, p. 27 | four | Separate agents reproduced the source bundle four times in clean folders on 15 | four reproduction folders in 08_REVIEW | 4.0 | CALC | MATCH |  |
| 1184 | §14, p. 27 | seven | folders on 15 October 2026. The third found seven values that differed (a corre | 08_REVIEW run3 report | 7.0 | FILE | MATCH |  |
| 1185 | §14, p. 27 | +0.19 | rrelation and an interval end rounded twice, +0.19 and +0.29 for +0.18 and +0.28 | CHANGELOG_versions.md | 0.19 | FILE | MATCH | a withdrawn value, quoted as such |
| 1186 | §14, p. 27 | +0.29 | and an interval end rounded twice, +0.19 and +0.29 for +0.18 and +0.28, and a st | CHANGELOG_versions.md | 0.29 | FILE | MATCH | a withdrawn value, quoted as such |
| 1187 | §14, p. 27 | +0.18 | erval end rounded twice, +0.19 and +0.29 for +0.18 and +0.28, and a stale cell i | m2_label_counts.csv, to five decimals | 0.184869 | CALC | MATCH |  |
| 1188 | §14, p. 27 | +0.28 | rounded twice, +0.19 and +0.29 for +0.18 and +0.28, and a stale cell in a releas | same seeded resampling as m2_from_counts.py, five decimals | 0.284982 | CALC | MATCH |  |
| 1189 | §14, p. 27 | 1,479 | ble), all since corrected; in the fourth, of 1,479 values the paper quotes from | 08_REVIEW run4 report | 1479.0 | FILE | MATCH |  |
| 1190 | §14, p. 27 | 1,342 | values the paper quotes from its own study, 1,342 matched what the released scr | 08_REVIEW run4 report | 1342.0 | FILE | MATCH |  |
| 1191 | §14, p. 27 | 137 | ent recomputed from them, none differed, and 137 could not be checked because | 08_REVIEW run4 report | 137.0 | FILE | MATCH |  |
| 1192 | §14, p. 27 | the paper builds from the bundle | ause they need withheld data; the paper builds from the bundle (`08_REVIEW/reprodu | build_tex.py rebuilt paper.tex byte for byte; tectonic compiled it to a PDF differing from the shipped one in 60 bytes of date and ID | agrees | RUN | MATCH | statement in words |
| 1193 | §15, p. 28 | thirteen | ased as an open implementation that declares thirteen demand-surface types; the sco | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1194 | §15, p. 28 | 7.5 | ed about its estimated traffic by factors of 7.5 to 27.1 over four months (8.6 | arithmetic on Table 2 / its released CSV | 7.469647 | CALC | MATCH |  |
| 1195 | §15, p. 28 | 27.1 | t its estimated traffic by factors of 7.5 to 27.1 over four months (8.6 to 29.9 | arithmetic on Table 2 / its released CSV | 27.141445 | CALC | MATCH |  |
| 1196 | §15, p. 28 | 8.6 | by factors of 7.5 to 27.1 over four months (8.6 to 29.9 with both read worldw | arithmetic on Table 2 / its released CSV | 8.620108 | CALC | MATCH |  |
| 1197 | §15, p. 28 | 29.9 | tors of 7.5 to 27.1 over four months (8.6 to 29.9 with both read worldwide), ab | arithmetic on Table 2 / its released CSV | 29.860816 | CALC | MATCH |  |
| 1198 | §15, p. 28 | 2.7 | worldwide), about its growth by a factor of 2.7 in one month, and about its r | instrument_extra.py | 2.66 | RUN | MATCH |  |
| 1199 | §15, p. 28 | about its referring domains by a factor of eleven | ctor of 2.7 in one month, and about its referring domains by a factor of eleven. Across twelve sect | 913 / 80 | agrees | CALC | MATCH | statement in words |
| 1200 | §15, p. 28 | eleven | d about its referring domains by a factor of eleven. Across twelve sections of th | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 1201 | §15, p. 28 | twelve | erring domains by a factor of eleven. Across twelve sections of the same domain, | data/analyze.py | 12.0 | RUN | MATCH |  |
| 1202 | §15, p. 28 | ran from one fifth to seven times | eir ratio on estimated visits ran from one fifth to seven times, with no detectable | analyze.py: 0.20x and 7.24x | agrees | RUN | MATCH | statement in words |
| 1203 | §15, p. 28 | 60 | greed on which of two sections was larger in 60 of 66 pairs, less often when | data/analyze.py | 60.0 | RUN | MATCH |  |
| 1204 | §15, p. 28 | 66 | on which of two sections was larger in 60 of 66 pairs, less often when the se | data/analyze.py | 66.0 | RUN | MATCH |  |
| 1205 | §15, p. 28 | 37,193 | at a volume tool counts, on one taxonomy. On 37,193 business reviews, the two agr | supplement_r10.py (saved output) | 37193.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 1206 | §15, p. 28 | +0.47 | eed only roughly on the taxonomy's branches (+0.47 to +0.75, depending on attrib | m2_from_counts.py | 0.468 | RUN | MATCH |  |
| 1207 | §15, p. 28 | +0.75 | roughly on the taxonomy's branches (+0.47 to +0.75, depending on attribution) wh | m2_from_counts.py | 0.748 | RUN | MATCH |  |
| 1208 | §15, p. 28 | +0.18 | ry differently, and barely agreed on topics (+0.18, or +0.27 counting labels no | m2_label_counts.csv, to five decimals | 0.184869 | CALC | MATCH |  |
| 1209 | §15, p. 28 | +0.27 | ntly, and barely agreed on topics (+0.18, or +0.27 counting labels no review men | m2_from_counts.py | 0.273 | RUN | MATCH |  |
| 1210 | §15, p. 28 | one | ls no review mentions), most for complaints: one in seven unhappy reviews matc | 924 of 6,620 is 1 in 7.2 | 1.0 | CALC | MATCH |  |
| 1211 | §15, p. 28 | seven | eview mentions), most for complaints: one in seven unhappy reviews matched a wai | 924 of 6,620 is 1 in 7.2 | 7.0 | CALC | MATCH |  |
| 1212 | §15, p. 28 | 11 | ting pattern, while the whole taxonomy holds 11 labels mentioning waiting, no | supplement_r10.py (saved output) | 11.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 1213 | §15, p. 28 | 622 | waiting, none about waiting in a store, with 622 searches a month. On the 372 | supplement_r10.py (saved output) | 622.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 1214 | §15, p. 28 | 372 | n a store, with 622 searches a month. On the 372 area codes, a public count of | wiki_demand_analysis.py | 372.0 | RUN | MATCH |  |
| 1215 | §15, p. 28 | +0.45 | the vendor's volume roughly on the ranking (+0.45 over 240 articles) and not at | wiki_demand_supplement.py | 0.44598 | RUN | MATCH |  |
| 1216 | §15, p. 28 | 240 | 's volume roughly on the ranking (+0.45 over 240 articles) and not at all on m | wiki_demand_analysis.py | 240.0 | RUN | MATCH |  |
| 1217 | §15, p. 28 | 1.5 | etric standard deviations across articles of 1.5 for the count and 16.7 for th | wiki_demand_analysis.py | 1.5 | RUN | MATCH |  |
| 1218 | §15, p. 28 | 16.7 | ons across articles of 1.5 for the count and 16.7 for the volume), in a compari | wiki_demand_analysis.py | 16.69 | RUN | MATCH |  |
| 1219 | §15, p. 28 | eleven | swers that name the largest companies of the eleven S&P 500 sectors, that the sha | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 1220 | §15, p. 28 | 21 | ffers most between answer surfaces: a median 21% on Google's AI Overviews and | section7_from_aggregates.py | 21.3 | RUN | MATCH |  |
| 1221 | §15, p. 28 | 0.6 | on Google's AI Overviews and AI Mode against 0.6% to 9.2% on the four other su | section7_from_aggregates.py | 0.6 | RUN | MATCH |  |
| 1222 | §15, p. 28 | 9.2 | e's AI Overviews and AI Mode against 0.6% to 9.2% on the four other surfaces, | section7_from_aggregates.py | 9.2 | RUN | MATCH |  |
| 1223 | §15, p. 28 | two of four predictions written before collection failed | ces varied more by sector and two of four predictions written before collection failed. That is why a per- | section7_from_aggregates.py | agrees | RUN | MATCH | statement in words |
| 1224 | §15, p. 28 | four | any sources varied more by sector and two of four predictions written before co | cross_sector_ai_citation_study.md and wikipedia_demand_372.md: P1 to P4 in each | 4.0 | FILE | MATCH |  |
| 1225 | §15, p. 28 | 15,830 | overed and no one defended, the section held 15,830 ranking positions with ninete | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 15830.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1226 | §15, p. 28 | nineteen | e section held 15,830 ranking positions with nineteen referring domains at day 37, | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 19.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1227 | §15, p. 28 | 17,206 | domains at day 37, and by day 77 appeared in 17,206 recorded AI answers, with no | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 17206.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1228 | App. A, p. 31 | 381 | iven. - **Measurement 1.** The page count is 381, not 290, which removed the 8 | section_code_pages_2026-10-14.csv | 381 | FILE | MATCH |  |
| 1229 | App. A, p. 31 | 9.2 | omated link network had arrived by day 45. A 9.2x AI-answer comparison was wit | arithmetic on the paper's own counts | 9.188655 | CALC | MATCH |  |
| 1230 | App. A, p. 31 | 78 | y run-rate, and its days-live column sums to 78 (days 0 to 77). Disagreement | 6 + 31 + 30 + 11 | 78.0 | CALC | MATCH |  |
| 1231 | App. A, p. 31 | 5.2 | a bound on the larger error, by a factor of 5.2 at 27.1x, not 13 times. The h | reproducer's recomputation (recompute.py) | 5.209745 | CALC | MATCH |  |
| 1232 | App. A, p. 31 | 27.1 | d on the larger error, by a factor of 5.2 at 27.1x, not 13 times. The hypothesi | arithmetic on Table 2 / its released CSV | 27.141445 | CALC | MATCH |  |
| 1233 | App. A, p. 31 | 13 | rger error, by a factor of 5.2 at 27.1x, not 13 times. The hypothesis that th | reproducer's recomputation (recompute.py) | 13.070723 | CALC | MATCH |  |
| 1234 | App. A, p. 31 | −0.09 | n, and a stale copy of Figure 5 that printed −0.09 for −0.11 was replaced. - **T | CHANGELOG_versions.md | -0.09 | FILE | MATCH | a withdrawn value, quoted as such |
| 1235 | App. A, p. 31 | −0.11 | tale copy of Figure 5 that printed −0.09 for −0.11 was replaced. - **The deploym | data/analyze.py | -0.11 | RUN | MATCH |  |
| 1236 | App. A, p. 32 | +0.47 | ry. - **Measurement 2.** Branch agreement is +0.47 to +0.75 depending on how lab | m2_from_counts.py | 0.468 | RUN | MATCH |  |
| 1237 | App. A, p. 32 | +0.75 | easurement 2.** Branch agreement is +0.47 to +0.75 depending on how labels are a | m2_from_counts.py | 0.748 | RUN | MATCH |  |
| 1238 | App. A, p. 32 | +0.78 | labels are attributed, replacing an earlier +0.78 computed on review-mentioned | analyze_reviews.py (saved output) | 0.777 | SAVED | CANNOT RUN | the superseded computation, still printed by that script; agrees with the saved output; the script that prints it needs withheld data |
| 1239 | App. A, p. 32 | 11 | each branch's own volume; the taxonomy holds 11 labels containing "wait", not | supplement_r10.py (saved output) | 11.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 1240 | App. A, p. 32 | 456 | he count of works naming the vendor tools is 456, not 459 (three works were co | vendor_reliance.py --offline | 456.0 | RUN | MATCH |  |
| 1241 | App. A, p. 32 | 459 | of works naming the vendor tools is 456, not 459 (three works were counted twi | vendor_reliance.py --offline: 456 + 3 duplicates | 459.0 | RUN | MATCH | a withdrawn value, quoted as such |
| 1242 | App. A, p. 32 | +0.18 | topic-level correlation of Measurement 2 is +0.18, not +0.19, which had rounded | m2_label_counts.csv, to five decimals | 0.184869 | CALC | MATCH |  |
| 1243 | App. A, p. 32 | +0.19 | l correlation of Measurement 2 is +0.18, not +0.19, which had rounded a printed | CHANGELOG_versions.md | 0.19 | FILE | MATCH | a withdrawn value, quoted as such |
| 1244 | App. A, p. 32 | +0.185 | 0.18, not +0.19, which had rounded a printed +0.185 a second time; statistics tha | m2_from_counts.py | 0.185 | RUN | MATCH |  |
| 1245 | App. B, p. 32 | 0.22 | ro when other entities also have none (about 0.22 when 30 of 66 entities have n | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1246 | App. B, p. 32 | 30 | her entities also have none (about 0.22 when 30 of 66 entities have none). ow | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1247 | App. B, p. 32 | 66 | tities also have none (about 0.22 when 30 of 66 entities have none). own(*e*) | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1248 | App. B, p. 32 | 0.5 | uncovered. Five parameters are locked: α = 0.5, β = 0.5, damping = 0.85, at | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1249 | App. B, p. 32 | 0.5 | d. Five parameters are locked: α = 0.5, β = 0.5, damping = 0.85, at least thr | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1250 | App. B, p. 32 | 0.85 | ters are locked: α = 0.5, β = 0.5, damping = 0.85, at least three phrasings per | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1251 | App. B, p. 32 | 7290a2235d8de05f | on 13's class-level comparison uses (digest `7290a2235d8de05f`, set at 02:00 UTC on 12 Octo | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1252 | App. B, p. 32 | 02d7588 | e changed at 03:45 UTC the same day (commit `02d7588`, which changed which questio | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1253 | App. B, p. 32 | 0.8 | term correlates with node degree at roughly 0.8 in the released example, so o | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1254 | App. B, p. 33 | 4 | an answer. On the released example these are 4/5 and 70.4%, with two of the | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1255 | App. B, p. 33 | 5 | answer. On the released example these are 4/5 and 70.4%, with two of the fo | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1256 | App. B, p. 33 | 70.4 | r. On the released example these are 4/5 and 70.4%, with two of the four expres | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1257 | App. B, p. 33 | two | leased example these are 4/5 and 70.4%, with two of the four expressible quest | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1258 | App. B, p. 33 | four | ple these are 4/5 and 70.4%, with two of the four expressible questions answere | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1259 | App. C, p. 34 | eleven | llection and answer surface: median over the eleven sectors, with the range in pa | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 1260 | App. C, p. 34 | 1,000 | session on 12 and 13 October 2026; among the 1,000 domains found in the most ans | cross_sector_cells.csv: export_rows is 1000 in all 88 cells | 1000.0 | CALC | MATCH |  |
| 1261 | Table C1, p. 34 | 25.8 | Table C1 | section7_from_aggregates.py, Table C1 | 25.8 | RUN | MATCH |  |
| 1262 | Table C1, p. 34 | 14.3 | Table C1 | section7_from_aggregates.py, Table C1 | 14.3 | RUN | MATCH |  |
| 1263 | Table C1, p. 34 | 34.3 | Table C1 | section7_from_aggregates.py, Table C1 | 34.3 | RUN | MATCH |  |
| 1264 | Table C1, p. 34 | 4.3 | Table C1 | section7_from_aggregates.py, Table C1 | 4.3 | RUN | MATCH |  |
| 1265 | Table C1, p. 34 | 1.3 | Table C1 | section7_from_aggregates.py, Table C1 | 1.3 | RUN | MATCH |  |
| 1266 | Table C1, p. 34 | 8.1 | Table C1 | section7_from_aggregates.py, Table C1 | 8.1 | RUN | MATCH |  |
| 1267 | Table C1, p. 34 | 0.7 | Table C1 | section7_from_aggregates.py, Table C1 | 0.7 | RUN | MATCH |  |
| 1268 | Table C1, p. 34 | 0.2 | Table C1 | section7_from_aggregates.py, Table C1 | 0.2 | RUN | MATCH |  |
| 1269 | Table C1, p. 34 | 2.8 | Table C1 | section7_from_aggregates.py, Table C1 | 2.8 | RUN | MATCH |  |
| 1270 | Table C1, p. 34 | 0.4 | Table C1 | section7_from_aggregates.py, Table C1 | 0.4 | RUN | MATCH |  |
| 1271 | Table C1, p. 34 | 0.2 | Table C1 | section7_from_aggregates.py, Table C1 | 0.2 | RUN | MATCH |  |
| 1272 | Table C1, p. 34 | 8.6 | Table C1 | section7_from_aggregates.py, Table C1 | 8.6 | RUN | MATCH |  |
| 1273 | Table C1, p. 34 | 11.9 | Table C1 | section7_from_aggregates.py, Table C1 | 11.9 | RUN | MATCH |  |
| 1274 | Table C1, p. 34 | 6.1 | Table C1 | section7_from_aggregates.py, Table C1 | 6.1 | RUN | MATCH |  |
| 1275 | Table C1, p. 34 | 23.5 | Table C1 | section7_from_aggregates.py, Table C1 | 23.5 | RUN | MATCH |  |
| 1276 | Table C1, p. 34 | 55.6 | Table C1 | section7_from_aggregates.py, Table C1 | 55.6 | RUN | MATCH |  |
| 1277 | Table C1, p. 34 | 41.1 | Table C1 | section7_from_aggregates.py, Table C1 | 41.1 | RUN | MATCH |  |
| 1278 | Table C1, p. 34 | 62.0 | Table C1 | section7_from_aggregates.py, Table C1 | 62.0 | RUN | MATCH |  |
| 1279 | Table C1, p. 34 | 32.4 | Table C1 | section7_from_aggregates.py, Table C1 | 32.4 | RUN | MATCH |  |
| 1280 | Table C1, p. 34 | 13.4 | Table C1 | section7_from_aggregates.py, Table C1 | 13.4 | RUN | MATCH |  |
| 1281 | Table C1, p. 34 | 35.8 | Table C1 | section7_from_aggregates.py, Table C1 | 35.8 | RUN | MATCH |  |
| 1282 | Table C1, p. 34 | 2.6 | Table C1 | section7_from_aggregates.py, Table C1 | 2.6 | RUN | MATCH |  |
| 1283 | Table C1, p. 34 | 0.7 | Table C1 | section7_from_aggregates.py, Table C1 | 0.7 | RUN | MATCH |  |
| 1284 | Table C1, p. 34 | 3.9 | Table C1 | section7_from_aggregates.py, Table C1 | 3.9 | RUN | MATCH |  |
| 1285 | Table C1, p. 34 | 1.0 | Table C1 | section7_from_aggregates.py, Table C1 | 1.0 | RUN | MATCH |  |
| 1286 | Table C1, p. 34 | 0.1 | Table C1 | section7_from_aggregates.py, Table C1 | 0.1 | RUN | MATCH |  |
| 1287 | Table C1, p. 34 | 5.8 | Table C1 | section7_from_aggregates.py, Table C1 | 5.8 | RUN | MATCH |  |
| 1288 | Table C1, p. 34 | 0.3 | Table C1 | section7_from_aggregates.py, Table C1 | 0.3 | RUN | MATCH |  |
| 1289 | Table C1, p. 34 | 0.1 | Table C1 | section7_from_aggregates.py, Table C1 | 0.1 | RUN | MATCH |  |
| 1290 | Table C1, p. 34 | 3.8 | Table C1 | section7_from_aggregates.py, Table C1 | 3.8 | RUN | MATCH |  |
| 1291 | Table C1, p. 34 | 8.1 | Table C1 | section7_from_aggregates.py, Table C1 | 8.1 | RUN | MATCH |  |
| 1292 | Table C1, p. 34 | 2.7 | Table C1 | section7_from_aggregates.py, Table C1 | 2.7 | RUN | MATCH |  |
| 1293 | Table C1, p. 34 | 20.5 | Table C1 | section7_from_aggregates.py, Table C1 | 20.5 | RUN | MATCH |  |
| 1294 | Table C1, p. 34 | 59.0 | Table C1 | section7_from_aggregates.py, Table C1 | 59.0 | RUN | MATCH |  |
| 1295 | Table C1, p. 34 | 42.0 | Table C1 | section7_from_aggregates.py, Table C1 | 42.0 | RUN | MATCH |  |
| 1296 | Table C1, p. 34 | 75.3 | Table C1 | section7_from_aggregates.py, Table C1 | 75.3 | RUN | MATCH |  |
| 1297 | Table C1, p. 34 | 17.8 | Table C1 | section7_from_aggregates.py, Table C1 | 17.8 | RUN | MATCH |  |
| 1298 | Table C1, p. 34 | 9.0 | Table C1 | section7_from_aggregates.py, Table C1 | 9.0 | RUN | MATCH |  |
| 1299 | Table C1, p. 34 | 23.8 | Table C1 | section7_from_aggregates.py, Table C1 | 23.8 | RUN | MATCH |  |
| 1300 | Table C1, p. 34 | 4.2 | Table C1 | section7_from_aggregates.py, Table C1 | 4.2 | RUN | MATCH |  |
| 1301 | Table C1, p. 34 | 2.2 | Table C1 | section7_from_aggregates.py, Table C1 | 2.2 | RUN | MATCH |  |
| 1302 | Table C1, p. 34 | 10.4 | Table C1 | section7_from_aggregates.py, Table C1 | 10.4 | RUN | MATCH |  |
| 1303 | Table C1, p. 34 | 1.0 | Table C1 | section7_from_aggregates.py, Table C1 | 1.0 | RUN | MATCH |  |
| 1304 | Table C1, p. 34 | 0.3 | Table C1 | section7_from_aggregates.py, Table C1 | 0.3 | RUN | MATCH |  |
| 1305 | Table C1, p. 34 | 4.2 | Table C1 | section7_from_aggregates.py, Table C1 | 4.2 | RUN | MATCH |  |
| 1306 | Table C1, p. 34 | 0.4 | Table C1 | section7_from_aggregates.py, Table C1 | 0.4 | RUN | MATCH |  |
| 1307 | Table C1, p. 34 | 0.1 | Table C1 | section7_from_aggregates.py, Table C1 | 0.1 | RUN | MATCH |  |
| 1308 | Table C1, p. 34 | 8.6 | Table C1 | section7_from_aggregates.py, Table C1 | 8.6 | RUN | MATCH |  |
| 1309 | Table C1, p. 34 | 10.8 | Table C1 | section7_from_aggregates.py, Table C1 | 10.8 | RUN | MATCH |  |
| 1310 | Table C1, p. 34 | 5.1 | Table C1 | section7_from_aggregates.py, Table C1 | 5.1 | RUN | MATCH |  |
| 1311 | Table C1, p. 34 | 17.6 | Table C1 | section7_from_aggregates.py, Table C1 | 17.6 | RUN | MATCH |  |
| 1312 | Table C1, p. 34 | 65.3 | Table C1 | section7_from_aggregates.py, Table C1 | 65.3 | RUN | MATCH |  |
| 1313 | Table C1, p. 34 | 53.1 | Table C1 | section7_from_aggregates.py, Table C1 | 53.1 | RUN | MATCH |  |
| 1314 | Table C1, p. 34 | 71.4 | Table C1 | section7_from_aggregates.py, Table C1 | 71.4 | RUN | MATCH |  |
| 1315 | Table C1, p. 34 | 24.1 | Table C1 | section7_from_aggregates.py, Table C1 | 24.1 | RUN | MATCH |  |
| 1316 | Table C1, p. 34 | 8.1 | Table C1 | section7_from_aggregates.py, Table C1 | 8.1 | RUN | MATCH |  |
| 1317 | Table C1, p. 34 | 28.3 | Table C1 | section7_from_aggregates.py, Table C1 | 28.3 | RUN | MATCH |  |
| 1318 | Table C1, p. 34 | 2.7 | Table C1 | section7_from_aggregates.py, Table C1 | 2.7 | RUN | MATCH |  |
| 1319 | Table C1, p. 34 | 0.9 | Table C1 | section7_from_aggregates.py, Table C1 | 0.9 | RUN | MATCH |  |
| 1320 | Table C1, p. 34 | 4.5 | Table C1 | section7_from_aggregates.py, Table C1 | 4.5 | RUN | MATCH |  |
| 1321 | Table C1, p. 34 | 1.4 | Table C1 | section7_from_aggregates.py, Table C1 | 1.4 | RUN | MATCH |  |
| 1322 | Table C1, p. 34 | 0.3 | Table C1 | section7_from_aggregates.py, Table C1 | 0.3 | RUN | MATCH |  |
| 1323 | Table C1, p. 34 | 5.6 | Table C1 | section7_from_aggregates.py, Table C1 | 5.6 | RUN | MATCH |  |
| 1324 | Table C1, p. 34 | 0.4 | Table C1 | section7_from_aggregates.py, Table C1 | 0.4 | RUN | MATCH |  |
| 1325 | Table C1, p. 34 | 0.1 | Table C1 | section7_from_aggregates.py, Table C1 | 0.1 | RUN | MATCH |  |
| 1326 | Table C1, p. 34 | 5.0 | Table C1 | section7_from_aggregates.py, Table C1 | 5.0 | RUN | MATCH |  |
| 1327 | Table C1, p. 34 | 9.5 | Table C1 | section7_from_aggregates.py, Table C1 | 9.5 | RUN | MATCH |  |
| 1328 | Table C1, p. 34 | 2.7 | Table C1 | section7_from_aggregates.py, Table C1 | 2.7 | RUN | MATCH |  |
| 1329 | Table C1, p. 34 | 19.3 | Table C1 | section7_from_aggregates.py, Table C1 | 19.3 | RUN | MATCH |  |
| 1330 | Table C1, p. 34 | 65.1 | Table C1 | section7_from_aggregates.py, Table C1 | 65.1 | RUN | MATCH |  |
| 1331 | Table C1, p. 34 | 50.1 | Table C1 | section7_from_aggregates.py, Table C1 | 50.1 | RUN | MATCH |  |
| 1332 | Table C1, p. 34 | 79.3 | Table C1 | section7_from_aggregates.py, Table C1 | 79.3 | RUN | MATCH |  |
| 1333 | Table C1, p. 34 | 0.9 | Table C1 | section7_from_aggregates.py, Table C1 | 0.9 | RUN | MATCH |  |
| 1334 | Table C1, p. 34 | 0.3 | Table C1 | section7_from_aggregates.py, Table C1 | 0.3 | RUN | MATCH |  |
| 1335 | Table C1, p. 34 | 2.5 | Table C1 | section7_from_aggregates.py, Table C1 | 2.5 | RUN | MATCH |  |
| 1336 | Table C1, p. 34 | 1.7 | Table C1 | section7_from_aggregates.py, Table C1 | 1.7 | RUN | MATCH |  |
| 1337 | Table C1, p. 34 | 0.5 | Table C1 | section7_from_aggregates.py, Table C1 | 0.5 | RUN | MATCH |  |
| 1338 | Table C1, p. 34 | 3.4 | Table C1 | section7_from_aggregates.py, Table C1 | 3.4 | RUN | MATCH |  |
| 1339 | Table C1, p. 34 | 1.7 | Table C1 | section7_from_aggregates.py, Table C1 | 1.7 | RUN | MATCH |  |
| 1340 | Table C1, p. 34 | 0.7 | Table C1 | section7_from_aggregates.py, Table C1 | 0.7 | RUN | MATCH |  |
| 1341 | Table C1, p. 34 | 5.2 | Table C1 | section7_from_aggregates.py, Table C1 | 5.2 | RUN | MATCH |  |
| 1342 | Table C1, p. 34 | 3.0 | Table C1 | section7_from_aggregates.py, Table C1 | 3.0 | RUN | MATCH |  |
| 1343 | Table C1, p. 34 | 1.6 | Table C1 | section7_from_aggregates.py, Table C1 | 1.6 | RUN | MATCH |  |
| 1344 | Table C1, p. 34 | 18.2 | Table C1 | section7_from_aggregates.py, Table C1 | 18.2 | RUN | MATCH |  |
| 1345 | Table C1, p. 34 | 27.4 | Table C1 | section7_from_aggregates.py, Table C1 | 27.4 | RUN | MATCH |  |
| 1346 | Table C1, p. 34 | 13.5 | Table C1 | section7_from_aggregates.py, Table C1 | 13.5 | RUN | MATCH |  |
| 1347 | Table C1, p. 34 | 38.2 | Table C1 | section7_from_aggregates.py, Table C1 | 38.2 | RUN | MATCH |  |
| 1348 | Table C1, p. 34 | 61.5 | Table C1 | section7_from_aggregates.py, Table C1 | 61.5 | RUN | MATCH |  |
| 1349 | Table C1, p. 34 | 51.2 | Table C1 | section7_from_aggregates.py, Table C1 | 51.2 | RUN | MATCH |  |
| 1350 | Table C1, p. 34 | 76.1 | Table C1 | section7_from_aggregates.py, Table C1 | 76.1 | RUN | MATCH |  |
| 1351 | Table C1, p. 34 | 4.6 | Table C1 | section7_from_aggregates.py, Table C1 | 4.6 | RUN | MATCH |  |
| 1352 | Table C1, p. 34 | 1.8 | Table C1 | section7_from_aggregates.py, Table C1 | 1.8 | RUN | MATCH |  |
| 1353 | Table C1, p. 34 | 7.7 | Table C1 | section7_from_aggregates.py, Table C1 | 7.7 | RUN | MATCH |  |
| 1354 | Table C1, p. 34 | 5.9 | Table C1 | section7_from_aggregates.py, Table C1 | 5.9 | RUN | MATCH |  |
| 1355 | Table C1, p. 34 | 2.8 | Table C1 | section7_from_aggregates.py, Table C1 | 2.8 | RUN | MATCH |  |
| 1356 | Table C1, p. 34 | 10.7 | Table C1 | section7_from_aggregates.py, Table C1 | 10.7 | RUN | MATCH |  |
| 1357 | Table C1, p. 34 | 1.5 | Table C1 | section7_from_aggregates.py, Table C1 | 1.5 | RUN | MATCH |  |
| 1358 | Table C1, p. 34 | 0.3 | Table C1 | section7_from_aggregates.py, Table C1 | 0.3 | RUN | MATCH |  |
| 1359 | Table C1, p. 34 | 7.9 | Table C1 | section7_from_aggregates.py, Table C1 | 7.9 | RUN | MATCH |  |
| 1360 | Table C1, p. 34 | 0.8 | Table C1 | section7_from_aggregates.py, Table C1 | 0.8 | RUN | MATCH |  |
| 1361 | Table C1, p. 34 | 0.1 | Table C1 | section7_from_aggregates.py, Table C1 | 0.1 | RUN | MATCH |  |
| 1362 | Table C1, p. 34 | 12.0 | Table C1 | section7_from_aggregates.py, Table C1 | 12.0 | RUN | MATCH |  |
| 1363 | Table C1, p. 34 | 15.6 | Table C1 | section7_from_aggregates.py, Table C1 | 15.6 | RUN | MATCH |  |
| 1364 | Table C1, p. 34 | 8.2 | Table C1 | section7_from_aggregates.py, Table C1 | 8.2 | RUN | MATCH |  |
| 1365 | Table C1, p. 34 | 29.8 | Table C1 | section7_from_aggregates.py, Table C1 | 29.8 | RUN | MATCH |  |
| 1366 | Table C1, p. 34 | 67.8 | Table C1 | section7_from_aggregates.py, Table C1 | 67.8 | RUN | MATCH |  |
| 1367 | Table C1, p. 34 | 56.4 | Table C1 | section7_from_aggregates.py, Table C1 | 56.4 | RUN | MATCH |  |
| 1368 | Table C1, p. 34 | 73.9 | Table C1 | section7_from_aggregates.py, Table C1 | 73.9 | RUN | MATCH |  |
| 1369 | Table C1, p. 34 | 9.2 | Table C1 | section7_from_aggregates.py, Table C1 | 9.2 | RUN | MATCH |  |
| 1370 | Table C1, p. 34 | 2.9 | Table C1 | section7_from_aggregates.py, Table C1 | 2.9 | RUN | MATCH |  |
| 1371 | Table C1, p. 34 | 16.7 | Table C1 | section7_from_aggregates.py, Table C1 | 16.7 | RUN | MATCH |  |
| 1372 | Table C1, p. 34 | 3.7 | Table C1 | section7_from_aggregates.py, Table C1 | 3.7 | RUN | MATCH |  |
| 1373 | Table C1, p. 34 | 1.2 | Table C1 | section7_from_aggregates.py, Table C1 | 1.2 | RUN | MATCH |  |
| 1374 | Table C1, p. 34 | 6.9 | Table C1 | section7_from_aggregates.py, Table C1 | 6.9 | RUN | MATCH |  |
| 1375 | Table C1, p. 34 | 0.5 | Table C1 | section7_from_aggregates.py, Table C1 | 0.5 | RUN | MATCH |  |
| 1376 | Table C1, p. 34 | 0.1 | Table C1 | section7_from_aggregates.py, Table C1 | 0.1 | RUN | MATCH |  |
| 1377 | Table C1, p. 34 | 3.8 | Table C1 | section7_from_aggregates.py, Table C1 | 3.8 | RUN | MATCH |  |
| 1378 | Table C1, p. 34 | 0.3 | Table C1 | section7_from_aggregates.py, Table C1 | 0.3 | RUN | MATCH |  |
| 1379 | Table C1, p. 34 | 0.1 | Table C1 | section7_from_aggregates.py, Table C1 | 0.1 | RUN | MATCH |  |
| 1380 | Table C1, p. 34 | 2.4 | Table C1 | section7_from_aggregates.py, Table C1 | 2.4 | RUN | MATCH |  |
| 1381 | Table C1, p. 34 | 8.3 | Table C1 | section7_from_aggregates.py, Table C1 | 8.3 | RUN | MATCH |  |
| 1382 | Table C1, p. 34 | 3.2 | Table C1 | section7_from_aggregates.py, Table C1 | 3.2 | RUN | MATCH |  |
| 1383 | Table C1, p. 34 | 33.2 | Table C1 | section7_from_aggregates.py, Table C1 | 33.2 | RUN | MATCH |  |
| 1384 | Table C1, p. 34 | 75.2 | Table C1 | section7_from_aggregates.py, Table C1 | 75.2 | RUN | MATCH |  |
| 1385 | Table C1, p. 34 | 49.5 | Table C1 | section7_from_aggregates.py, Table C1 | 49.5 | RUN | MATCH |  |
| 1386 | Table C1, p. 34 | 85.3 | Table C1 | section7_from_aggregates.py, Table C1 | 85.3 | RUN | MATCH |  |
| 1387 | Table C1, p. 34 | 0.6 | Table C1 | section7_from_aggregates.py, Table C1 | 0.6 | RUN | MATCH |  |
| 1388 | Table C1, p. 34 | 0.3 | Table C1 | section7_from_aggregates.py, Table C1 | 0.3 | RUN | MATCH |  |
| 1389 | Table C1, p. 34 | 1.0 | Table C1 | section7_from_aggregates.py, Table C1 | 1.0 | RUN | MATCH |  |
| 1390 | Table C1, p. 34 | 1.6 | Table C1 | section7_from_aggregates.py, Table C1 | 1.6 | RUN | MATCH |  |
| 1391 | Table C1, p. 34 | 0.3 | Table C1 | section7_from_aggregates.py, Table C1 | 0.3 | RUN | MATCH |  |
| 1392 | Table C1, p. 34 | 2.7 | Table C1 | section7_from_aggregates.py, Table C1 | 2.7 | RUN | MATCH |  |
| 1393 | Table C1, p. 34 | 0.9 | Table C1 | section7_from_aggregates.py, Table C1 | 0.9 | RUN | MATCH |  |
| 1394 | Table C1, p. 34 | 0.2 | Table C1 | section7_from_aggregates.py, Table C1 | 0.2 | RUN | MATCH |  |
| 1395 | Table C1, p. 34 | 5.2 | Table C1 | section7_from_aggregates.py, Table C1 | 5.2 | RUN | MATCH |  |
| 1396 | Table C1, p. 34 | 0.1 | Table C1 | section7_from_aggregates.py, Table C1 | 0.1 | RUN | MATCH |  |
| 1397 | Table C1, p. 34 | 0.0 | Table C1 | section7_from_aggregates.py, Table C1 | 0.0 | RUN | MATCH |  |
| 1398 | Table C1, p. 34 | 2.2 | Table C1 | section7_from_aggregates.py, Table C1 | 2.2 | RUN | MATCH |  |
| 1399 | Table C1, p. 34 | 4.5 | Table C1 | section7_from_aggregates.py, Table C1 | 4.5 | RUN | MATCH |  |
| 1400 | Table C1, p. 34 | 1.6 | Table C1 | section7_from_aggregates.py, Table C1 | 1.6 | RUN | MATCH |  |
| 1401 | Table C1, p. 34 | 27.0 | Table C1 | section7_from_aggregates.py, Table C1 | 27.0 | RUN | MATCH |  |
| 1402 | Table C1, p. 34 | 89.9 | Table C1 | section7_from_aggregates.py, Table C1 | 89.9 | RUN | MATCH |  |
| 1403 | Table C1, p. 34 | 71.6 | Table C1 | section7_from_aggregates.py, Table C1 | 71.6 | RUN | MATCH |  |
| 1404 | Table C1, p. 34 | 94.6 | Table C1 | section7_from_aggregates.py, Table C1 | 94.6 | RUN | MATCH |  |
| 1405 | Table C2, p. 34 | 10,891.5 | Table C2 | section7_from_aggregates.py, Table C2 | 10891.5 | RUN | MATCH |  |
| 1406 | Table C2, p. 34 | 294.3 | Table C2 | section7_from_aggregates.py, Table C2 | 294.3 | RUN | MATCH |  |
| 1407 | Table C2, p. 34 | 1,128.4 | Table C2 | section7_from_aggregates.py, Table C2 | 1128.4 | RUN | MATCH |  |
| 1408 | Table C2, p. 34 | 352.4 | Table C2 | section7_from_aggregates.py, Table C2 | 352.4 | RUN | MATCH |  |
| 1409 | Table C2, p. 34 | 317.5 | Table C2 | section7_from_aggregates.py, Table C2 | 317.5 | RUN | MATCH |  |
| 1410 | Table C2, p. 34 | 186.8 | Table C2 | section7_from_aggregates.py, Table C2 | 186.8 | RUN | MATCH |  |
| 1411 | Table C2, p. 34 | 147.9 | Table C2 | section7_from_aggregates.py, Table C2 | 147.9 | RUN | MATCH |  |
| 1412 | Table C2, p. 34 | 405.6 | Table C2 | section7_from_aggregates.py, Table C2 | 405.6 | RUN | MATCH |  |
| 1413 | Table C2, p. 34 | 604.2 | Table C2 | section7_from_aggregates.py, Table C2 | 604.2 | RUN | MATCH |  |
| 1414 | Table C2, p. 34 | 10.1 | Table C2 | section7_from_aggregates.py, Table C2 | 10.1 | RUN | MATCH |  |
| 1415 | Table C2, p. 34 | 69.8 | Table C2 | section7_from_aggregates.py, Table C2 | 69.8 | RUN | MATCH |  |
| 1416 | Table C2, p. 34 | 16.5 | Table C2 | section7_from_aggregates.py, Table C2 | 16.5 | RUN | MATCH |  |
| 1417 | Table C2, p. 34 | 13.9 | Table C2 | section7_from_aggregates.py, Table C2 | 13.9 | RUN | MATCH |  |
| 1418 | Table C2, p. 34 | 8.5 | Table C2 | section7_from_aggregates.py, Table C2 | 8.5 | RUN | MATCH |  |
| 1419 | Table C2, p. 34 | 7.4 | Table C2 | section7_from_aggregates.py, Table C2 | 7.4 | RUN | MATCH |  |
| 1420 | Table C2, p. 34 | 20.9 | Table C2 | section7_from_aggregates.py, Table C2 | 20.9 | RUN | MATCH |  |
| 1421 | Table C2, p. 34 | 1,776.8 | Table C2 | section7_from_aggregates.py, Table C2 | 1776.8 | RUN | MATCH |  |
| 1422 | Table C2, p. 34 | 78.8 | Table C2 | section7_from_aggregates.py, Table C2 | 78.8 | RUN | MATCH |  |
| 1423 | Table C2, p. 34 | 173.5 | Table C2 | section7_from_aggregates.py, Table C2 | 173.5 | RUN | MATCH |  |
| 1424 | Table C2, p. 34 | 97.5 | Table C2 | section7_from_aggregates.py, Table C2 | 97.5 | RUN | MATCH |  |
| 1425 | Table C2, p. 34 | 64.4 | Table C2 | section7_from_aggregates.py, Table C2 | 64.4 | RUN | MATCH |  |
| 1426 | Table C2, p. 34 | 37.4 | Table C2 | section7_from_aggregates.py, Table C2 | 37.4 | RUN | MATCH |  |
| 1427 | Table C2, p. 34 | 45.3 | Table C2 | section7_from_aggregates.py, Table C2 | 45.3 | RUN | MATCH |  |
| 1428 | Table C2, p. 34 | 85.9 | Table C2 | section7_from_aggregates.py, Table C2 | 85.9 | RUN | MATCH |  |
| 1429 | Table C2, p. 34 | 18,381.8 | Table C2 | section7_from_aggregates.py, Table C2 | 18381.8 | RUN | MATCH |  |
| 1430 | Table C2, p. 34 | 790.0 | Table C2 | section7_from_aggregates.py, Table C2 | 790.0 | RUN | MATCH |  |
| 1431 | Table C2, p. 34 | 1,752.1 | Table C2 | section7_from_aggregates.py, Table C2 | 1752.1 | RUN | MATCH |  |
| 1432 | Table C2, p. 34 | 660.9 | Table C2 | section7_from_aggregates.py, Table C2 | 660.9 | RUN | MATCH |  |
| 1433 | Table C2, p. 34 | 347.0 | Table C2 | section7_from_aggregates.py, Table C2 | 347.0 | RUN | MATCH |  |
| 1434 | Table C2, p. 34 | 441.7 | Table C2 | section7_from_aggregates.py, Table C2 | 441.7 | RUN | MATCH |  |
| 1435 | Table C2, p. 34 | 128.8 | Table C2 | section7_from_aggregates.py, Table C2 | 128.8 | RUN | MATCH |  |
| 1436 | Table C2, p. 34 | 1,581.3 | Table C2 | section7_from_aggregates.py, Table C2 | 1581.3 | RUN | MATCH |  |
| 1437 | Table C2, p. 34 | 4,350.7 | Table C2 | section7_from_aggregates.py, Table C2 | 4350.7 | RUN | MATCH |  |
| 1438 | Table C2, p. 34 | 134.3 | Table C2 | section7_from_aggregates.py, Table C2 | 134.3 | RUN | MATCH |  |
| 1439 | Table C2, p. 34 | 591.5 | Table C2 | section7_from_aggregates.py, Table C2 | 591.5 | RUN | MATCH |  |
| 1440 | Table C2, p. 34 | 163.5 | Table C2 | section7_from_aggregates.py, Table C2 | 163.5 | RUN | MATCH |  |
| 1441 | Table C2, p. 34 | 150.1 | Table C2 | section7_from_aggregates.py, Table C2 | 150.1 | RUN | MATCH |  |
| 1442 | Table C2, p. 34 | 71.8 | Table C2 | section7_from_aggregates.py, Table C2 | 71.8 | RUN | MATCH |  |
| 1443 | Table C2, p. 34 | 76.0 | Table C2 | section7_from_aggregates.py, Table C2 | 76.0 | RUN | MATCH |  |
| 1444 | Table C2, p. 34 | 197.9 | Table C2 | section7_from_aggregates.py, Table C2 | 197.9 | RUN | MATCH |  |
| 1445 | Table C2, p. 34 | 1,223.2 | Table C2 | section7_from_aggregates.py, Table C2 | 1223.2 | RUN | MATCH |  |
| 1446 | Table C2, p. 34 | 52.6 | Table C2 | section7_from_aggregates.py, Table C2 | 52.6 | RUN | MATCH |  |
| 1447 | Table C2, p. 34 | 112.9 | Table C2 | section7_from_aggregates.py, Table C2 | 112.9 | RUN | MATCH |  |
| 1448 | Table C2, p. 34 | 60.2 | Table C2 | section7_from_aggregates.py, Table C2 | 60.2 | RUN | MATCH |  |
| 1449 | Table C2, p. 34 | 52.6 | Table C2 | section7_from_aggregates.py, Table C2 | 52.6 | RUN | MATCH |  |
| 1450 | Table C2, p. 34 | 21.7 | Table C2 | section7_from_aggregates.py, Table C2 | 21.7 | RUN | MATCH |  |
| 1451 | Table C2, p. 34 | 27.2 | Table C2 | section7_from_aggregates.py, Table C2 | 27.2 | RUN | MATCH |  |
| 1452 | Table C2, p. 34 | 79.3 | Table C2 | section7_from_aggregates.py, Table C2 | 79.3 | RUN | MATCH |  |
| 1453 | Table C2, p. 34 | 8,832.0 | Table C2 | section7_from_aggregates.py, Table C2 | 8832.0 | RUN | MATCH |  |
| 1454 | Table C2, p. 34 | 395.4 | Table C2 | section7_from_aggregates.py, Table C2 | 395.4 | RUN | MATCH |  |
| 1455 | Table C2, p. 34 | 982.3 | Table C2 | section7_from_aggregates.py, Table C2 | 982.3 | RUN | MATCH |  |
| 1456 | Table C2, p. 34 | 446.6 | Table C2 | section7_from_aggregates.py, Table C2 | 446.6 | RUN | MATCH |  |
| 1457 | Table C2, p. 34 | 351.7 | Table C2 | section7_from_aggregates.py, Table C2 | 351.7 | RUN | MATCH |  |
| 1458 | Table C2, p. 34 | 215.6 | Table C2 | section7_from_aggregates.py, Table C2 | 215.6 | RUN | MATCH |  |
| 1459 | Table C2, p. 34 | 149.8 | Table C2 | section7_from_aggregates.py, Table C2 | 149.8 | RUN | MATCH |  |
| 1460 | Table C2, p. 34 | 1,295.6 | Table C2 | section7_from_aggregates.py, Table C2 | 1295.6 | RUN | MATCH |  |
| 1461 | Table C2, p. 34 | 103.6 | Table C2 | section7_from_aggregates.py, Table C2 | 103.6 | RUN | MATCH |  |
| 1462 | Table C2, p. 34 | 3.8 | Table C2 | section7_from_aggregates.py, Table C2 | 3.8 | RUN | MATCH |  |
| 1463 | Table C2, p. 34 | 14.8 | Table C2 | section7_from_aggregates.py, Table C2 | 14.8 | RUN | MATCH |  |
| 1464 | Table C2, p. 34 | 5.5 | Table C2 | section7_from_aggregates.py, Table C2 | 5.5 | RUN | MATCH |  |
| 1465 | Table C2, p. 34 | 5.1 | Table C2 | section7_from_aggregates.py, Table C2 | 5.1 | RUN | MATCH |  |
| 1466 | Table C2, p. 34 | 2.0 | Table C2 | section7_from_aggregates.py, Table C2 | 2.0 | RUN | MATCH |  |
| 1467 | Table C2, p. 34 | 2.9 | Table C2 | section7_from_aggregates.py, Table C2 | 2.9 | RUN | MATCH |  |
| 1468 | Table C2, p. 34 | 9.0 | Table C2 | section7_from_aggregates.py, Table C2 | 9.0 | RUN | MATCH |  |
| 1469 | Table C2, p. 34 | 50.3 | Table C2 | section7_from_aggregates.py, Table C2 | 50.3 | RUN | MATCH |  |
| 1470 | Table C2, p. 34 | 2.1 | Table C2 | section7_from_aggregates.py, Table C2 | 2.1 | RUN | MATCH |  |
| 1471 | Table C2, p. 34 | 7.2 | Table C2 | section7_from_aggregates.py, Table C2 | 7.2 | RUN | MATCH |  |
| 1472 | Table C2, p. 34 | 2.6 | Table C2 | section7_from_aggregates.py, Table C2 | 2.6 | RUN | MATCH |  |
| 1473 | Table C2, p. 34 | 2.1 | Table C2 | section7_from_aggregates.py, Table C2 | 2.1 | RUN | MATCH |  |
| 1474 | Table C2, p. 34 | 0.9 | Table C2 | section7_from_aggregates.py, Table C2 | 0.9 | RUN | MATCH |  |
| 1475 | Table C2, p. 34 | 1.5 | Table C2 | section7_from_aggregates.py, Table C2 | 1.5 | RUN | MATCH |  |
| 1476 | Table C2, p. 34 | 3.2 | Table C2 | section7_from_aggregates.py, Table C2 | 3.2 | RUN | MATCH |  |
| 1477 | Table C2, p. 34 | 77.9 | Table C2 | section7_from_aggregates.py, Table C2 | 77.9 | RUN | MATCH |  |
| 1478 | Table C2, p. 34 | 6.4 | Table C2 | section7_from_aggregates.py, Table C2 | 6.4 | RUN | MATCH |  |
| 1479 | Table C2, p. 34 | 22.1 | Table C2 | section7_from_aggregates.py, Table C2 | 22.1 | RUN | MATCH |  |
| 1480 | Table C2, p. 34 | 6.8 | Table C2 | section7_from_aggregates.py, Table C2 | 6.8 | RUN | MATCH |  |
| 1481 | Table C2, p. 34 | 6.8 | Table C2 | section7_from_aggregates.py, Table C2 | 6.8 | RUN | MATCH |  |
| 1482 | Table C2, p. 34 | 4.4 | Table C2 | section7_from_aggregates.py, Table C2 | 4.4 | RUN | MATCH |  |
| 1483 | Table C2, p. 34 | 2.1 | Table C2 | section7_from_aggregates.py, Table C2 | 2.1 | RUN | MATCH |  |
| 1484 | Table C2, p. 34 | 6.8 | Table C2 | section7_from_aggregates.py, Table C2 | 6.8 | RUN | MATCH |  |
| 1485 | Table C2, p. 34 | 337.5 | Table C2 | section7_from_aggregates.py, Table C2 | 337.5 | RUN | MATCH |  |
| 1486 | Table C2, p. 34 | 15.6 | Table C2 | section7_from_aggregates.py, Table C2 | 15.6 | RUN | MATCH |  |
| 1487 | Table C2, p. 34 | 24.3 | Table C2 | section7_from_aggregates.py, Table C2 | 24.3 | RUN | MATCH |  |
| 1488 | Table C2, p. 34 | 17.5 | Table C2 | section7_from_aggregates.py, Table C2 | 17.5 | RUN | MATCH |  |
| 1489 | Table C2, p. 34 | 18.5 | Table C2 | section7_from_aggregates.py, Table C2 | 18.5 | RUN | MATCH |  |
| 1490 | Table C2, p. 34 | 5.6 | Table C2 | section7_from_aggregates.py, Table C2 | 5.6 | RUN | MATCH |  |
| 1491 | Table C2, p. 34 | 6.5 | Table C2 | section7_from_aggregates.py, Table C2 | 6.5 | RUN | MATCH |  |
| 1492 | Table C2, p. 34 | 18.7 | Table C2 | section7_from_aggregates.py, Table C2 | 18.7 | RUN | MATCH |  |
| 1493 | App. C, p. 34 | 1,000 | session on 12 and 13 October 2026, among the 1,000 domains found in the most ans | cross_sector_cells.csv: export_rows is 1000 in all 88 cells | 1000.0 | CALC | MATCH |  |
| 1494 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1495 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1496 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1497 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1498 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1499 | Table C3, p. 34 | wikipedia.org | Table C3 | make_tables_sector_surface.py, Table C3 | wikipedia.org | RUN | MATCH |  |
| 1500 | Table C3, p. 34 | reddit | Table C3 | make_tables_sector_surface.py, Table C3 | reddit | RUN | MATCH |  |
| 1501 | Table C3, p. 34 | walmart | Table C3 | make_tables_sector_surface.py, Table C3 | walmart | RUN | MATCH |  |
| 1502 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1503 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1504 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1505 | Table C3, p. 34 | goodrx | Table C3 | make_tables_sector_surface.py, Table C3 | goodrx | RUN | MATCH |  |
| 1506 | Table C3, p. 34 | fda.gov | Table C3 | make_tables_sector_surface.py, Table C3 | fda.gov | RUN | MATCH |  |
| 1507 | Table C3, p. 34 | nih.gov | Table C3 | make_tables_sector_surface.py, Table C3 | nih.gov | RUN | MATCH |  |
| 1508 | Table C3, p. 34 | goodrx | Table C3 | make_tables_sector_surface.py, Table C3 | goodrx | RUN | MATCH |  |
| 1509 | Table C3, p. 34 | msn | Table C3 | make_tables_sector_surface.py, Table C3 | msn | RUN | MATCH |  |
| 1510 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1511 | Table C3, p. 34 | reddit | Table C3 | make_tables_sector_surface.py, Table C3 | reddit | RUN | MATCH |  |
| 1512 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1513 | Table C3, p. 34 | nerdwallet | Table C3 | make_tables_sector_surface.py, Table C3 | nerdwallet | RUN | MATCH |  |
| 1514 | Table C3, p. 34 | nerdwallet | Table C3 | make_tables_sector_surface.py, Table C3 | nerdwallet | RUN | MATCH |  |
| 1515 | Table C3, p. 34 | nerdwallet | Table C3 | make_tables_sector_surface.py, Table C3 | nerdwallet | RUN | MATCH |  |
| 1516 | Table C3, p. 34 | wallethub | Table C3 | make_tables_sector_surface.py, Table C3 | wallethub | RUN | MATCH |  |
| 1517 | Table C3, p. 34 | wallethub | Table C3 | make_tables_sector_surface.py, Table C3 | wallethub | RUN | MATCH |  |
| 1518 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1519 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1520 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1521 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1522 | Table C3, p. 34 | justwatch | Table C3 | make_tables_sector_surface.py, Table C3 | justwatch | RUN | MATCH |  |
| 1523 | Table C3, p. 34 | wikipedia.org | Table C3 | make_tables_sector_surface.py, Table C3 | wikipedia.org | RUN | MATCH |  |
| 1524 | Table C3, p. 34 | reddit | Table C3 | make_tables_sector_surface.py, Table C3 | reddit | RUN | MATCH |  |
| 1525 | Table C3, p. 34 | walmart | Table C3 | make_tables_sector_surface.py, Table C3 | walmart | RUN | MATCH |  |
| 1526 | Table C3, p. 34 | youtube† | Table C3 | make_tables_sector_surface.py, Table C3 | youtube† | RUN | MATCH |  |
| 1527 | Table C3, p. 34 | youtube† | Table C3 | make_tables_sector_surface.py, Table C3 | youtube† | RUN | MATCH |  |
| 1528 | Table C3, p. 34 | google† | Table C3 | make_tables_sector_surface.py, Table C3 | google† | RUN | MATCH |  |
| 1529 | Table C3, p. 34 | google† | Table C3 | make_tables_sector_surface.py, Table C3 | google† | RUN | MATCH |  |
| 1530 | Table C3, p. 34 | go† | Table C3 | make_tables_sector_surface.py, Table C3 | go† | RUN | MATCH |  |
| 1531 | Table C3, p. 34 | wikipedia.org | Table C3 | make_tables_sector_surface.py, Table C3 | wikipedia.org | RUN | MATCH |  |
| 1532 | Table C3, p. 34 | reddit | Table C3 | make_tables_sector_surface.py, Table C3 | reddit | RUN | MATCH |  |
| 1533 | Table C3, p. 34 | walmart | Table C3 | make_tables_sector_surface.py, Table C3 | walmart | RUN | MATCH |  |
| 1534 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1535 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1536 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1537 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1538 | Table C3, p. 34 | nvidia | Table C3 | make_tables_sector_surface.py, Table C3 | nvidia | RUN | MATCH |  |
| 1539 | Table C3, p. 34 | wikipedia.org | Table C3 | make_tables_sector_surface.py, Table C3 | wikipedia.org | RUN | MATCH |  |
| 1540 | Table C3, p. 34 | reddit | Table C3 | make_tables_sector_surface.py, Table C3 | reddit | RUN | MATCH |  |
| 1541 | Table C3, p. 34 | amazon | Table C3 | make_tables_sector_surface.py, Table C3 | amazon | RUN | MATCH |  |
| 1542 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1543 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1544 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1545 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1546 | Table C3, p. 34 | reddit | Table C3 | make_tables_sector_surface.py, Table C3 | reddit | RUN | MATCH |  |
| 1547 | Table C3, p. 34 | amazon | Table C3 | make_tables_sector_surface.py, Table C3 | amazon | RUN | MATCH |  |
| 1548 | Table C3, p. 34 | reddit | Table C3 | make_tables_sector_surface.py, Table C3 | reddit | RUN | MATCH |  |
| 1549 | Table C3, p. 34 | amazon | Table C3 | make_tables_sector_surface.py, Table C3 | amazon | RUN | MATCH |  |
| 1550 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1551 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1552 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1553 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1554 | Table C3, p. 34 | sec.gov | Table C3 | make_tables_sector_surface.py, Table C3 | sec.gov | RUN | MATCH |  |
| 1555 | Table C3, p. 34 | wikipedia.org | Table C3 | make_tables_sector_surface.py, Table C3 | wikipedia.org | RUN | MATCH |  |
| 1556 | Table C3, p. 34 | reddit | Table C3 | make_tables_sector_surface.py, Table C3 | reddit | RUN | MATCH |  |
| 1557 | Table C3, p. 34 | walmart | Table C3 | make_tables_sector_surface.py, Table C3 | walmart | RUN | MATCH |  |
| 1558 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1559 | Table C3, p. 34 | reddit | Table C3 | make_tables_sector_surface.py, Table C3 | reddit | RUN | MATCH |  |
| 1560 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1561 | Table C3, p. 34 | yahoo | Table C3 | make_tables_sector_surface.py, Table C3 | yahoo | RUN | MATCH |  |
| 1562 | Table C3, p. 34 | sec.gov | Table C3 | make_tables_sector_surface.py, Table C3 | sec.gov | RUN | MATCH |  |
| 1563 | Table C3, p. 34 | wikipedia.org | Table C3 | make_tables_sector_surface.py, Table C3 | wikipedia.org | RUN | MATCH |  |
| 1564 | Table C3, p. 34 | wikipedia.org | Table C3 | make_tables_sector_surface.py, Table C3 | wikipedia.org | RUN | MATCH |  |
| 1565 | Table C3, p. 34 | msn | Table C3 | make_tables_sector_surface.py, Table C3 | msn | RUN | MATCH |  |
| 1566 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1567 | Table C3, p. 34 | extraspace | Table C3 | make_tables_sector_surface.py, Table C3 | extraspace | RUN | MATCH |  |
| 1568 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1569 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1570 | Table C3, p. 34 | sec.gov | Table C3 | make_tables_sector_surface.py, Table C3 | sec.gov | RUN | MATCH |  |
| 1571 | Table C3, p. 34 | wikipedia.org | Table C3 | make_tables_sector_surface.py, Table C3 | wikipedia.org | RUN | MATCH |  |
| 1572 | Table C3, p. 34 | wikipedia.org | Table C3 | make_tables_sector_surface.py, Table C3 | wikipedia.org | RUN | MATCH |  |
| 1573 | Table C3, p. 34 | extraspace | Table C3 | make_tables_sector_surface.py, Table C3 | extraspace | RUN | MATCH |  |
| 1574 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1575 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1576 | Table C3, p. 34 | google | Table C3 | make_tables_sector_surface.py, Table C3 | google | RUN | MATCH |  |
| 1577 | Table C3, p. 34 | youtube | Table C3 | make_tables_sector_surface.py, Table C3 | youtube | RUN | MATCH |  |
| 1578 | Table C3, p. 34 | benjaminmoore | Table C3 | make_tables_sector_surface.py, Table C3 | benjaminmoore | RUN | MATCH |  |
| 1579 | Table C3, p. 34 | kylieminteriors.ca | Table C3 | make_tables_sector_surface.py, Table C3 | kylieminteriors.ca | RUN | MATCH |  |
| 1580 | Table C3, p. 34 | facadecolorizer | Table C3 | make_tables_sector_surface.py, Table C3 | facadecolorizer | RUN | MATCH |  |
| 1581 | Table C3, p. 34 | facadecolorizer | Table C3 | make_tables_sector_surface.py, Table C3 | facadecolorizer | RUN | MATCH |  |
| 1582 | Table C4, p. 35 | youtube | Table C4 | make_tables_sector_surface.py, Table C4 | youtube | RUN | MATCH |  |
| 1583 | Table C4, p. 35 | reddit | Table C4 | make_tables_sector_surface.py, Table C4 | reddit | RUN | MATCH |  |
| 1584 | Table C4, p. 35 | google | Table C4 | make_tables_sector_surface.py, Table C4 | google | RUN | MATCH |  |
| 1585 | Table C4, p. 35 | google | Table C4 | make_tables_sector_surface.py, Table C4 | google | RUN | MATCH |  |
| 1586 | Table C4, p. 35 | wikipedia.org | Table C4 | make_tables_sector_surface.py, Table C4 | wikipedia.org | RUN | MATCH |  |
| 1587 | Table C4, p. 35 | justwatch | Table C4 | make_tables_sector_surface.py, Table C4 | justwatch | RUN | MATCH |  |
| 1588 | Table C4, p. 35 | youtube | Table C4 | make_tables_sector_surface.py, Table C4 | youtube | RUN | MATCH |  |
| 1589 | Table C4, p. 35 | nih.gov | Table C4 | make_tables_sector_surface.py, Table C4 | nih.gov | RUN | MATCH |  |
| 1590 | Table C4, p. 35 | wikipedia.org | Table C4 | make_tables_sector_surface.py, Table C4 | wikipedia.org | RUN | MATCH |  |
| 1591 | Table C4, p. 35 | fda.gov | Table C4 | make_tables_sector_surface.py, Table C4 | fda.gov | RUN | MATCH |  |
| 1592 | Table C4, p. 35 | nih.gov | Table C4 | make_tables_sector_surface.py, Table C4 | nih.gov | RUN | MATCH |  |
| 1593 | Table C4, p. 35 | sec.gov | Table C4 | make_tables_sector_surface.py, Table C4 | sec.gov | RUN | MATCH |  |
| 1594 | Table C4, p. 35 | youtube | Table C4 | make_tables_sector_surface.py, Table C4 | youtube | RUN | MATCH |  |
| 1595 | Table C4, p. 35 | reddit | Table C4 | make_tables_sector_surface.py, Table C4 | reddit | RUN | MATCH |  |
| 1596 | Table C4, p. 35 | nerdwallet | Table C4 | make_tables_sector_surface.py, Table C4 | nerdwallet | RUN | MATCH |  |
| 1597 | Table C4, p. 35 | nerdwallet | Table C4 | make_tables_sector_surface.py, Table C4 | nerdwallet | RUN | MATCH |  |
| 1598 | Table C4, p. 35 | chase† | Table C4 | make_tables_sector_surface.py, Table C4 | chase† | RUN | MATCH |  |
| 1599 | Table C4, p. 35 | capitalone | Table C4 | make_tables_sector_surface.py, Table C4 | capitalone | RUN | MATCH |  |
| 1600 | Table C4, p. 35 | google | Table C4 | make_tables_sector_surface.py, Table C4 | google | RUN | MATCH |  |
| 1601 | Table C4, p. 35 | youtube | Table C4 | make_tables_sector_surface.py, Table C4 | youtube | RUN | MATCH |  |
| 1602 | Table C4, p. 35 | reddit | Table C4 | make_tables_sector_surface.py, Table C4 | reddit | RUN | MATCH |  |
| 1603 | Table C4, p. 35 | justwatch | Table C4 | make_tables_sector_surface.py, Table C4 | justwatch | RUN | MATCH |  |
| 1604 | Table C4, p. 35 | consumerreports.org | Table C4 | make_tables_sector_surface.py, Table C4 | consumerreports.org | RUN | MATCH |  |
| 1605 | Table C4, p. 35 | aboutamazon† | Table C4 | make_tables_sector_surface.py, Table C4 | aboutamazon† | RUN | MATCH |  |
| 1606 | Table C4, p. 35 | youtube† | Table C4 | make_tables_sector_surface.py, Table C4 | youtube† | RUN | MATCH |  |
| 1607 | Table C4, p. 35 | wikipedia.org | Table C4 | make_tables_sector_surface.py, Table C4 | wikipedia.org | RUN | MATCH |  |
| 1608 | Table C4, p. 35 | reddit | Table C4 | make_tables_sector_surface.py, Table C4 | reddit | RUN | MATCH |  |
| 1609 | Table C4, p. 35 | go† | Table C4 | make_tables_sector_surface.py, Table C4 | go† | RUN | MATCH |  |
| 1610 | Table C4, p. 35 | justwatch | Table C4 | make_tables_sector_surface.py, Table C4 | justwatch | RUN | MATCH |  |
| 1611 | Table C4, p. 35 | wikipedia.org | Table C4 | make_tables_sector_surface.py, Table C4 | wikipedia.org | RUN | MATCH |  |
| 1612 | Table C4, p. 35 | youtube | Table C4 | make_tables_sector_surface.py, Table C4 | youtube | RUN | MATCH |  |
| 1613 | Table C4, p. 35 | reddit | Table C4 | make_tables_sector_surface.py, Table C4 | reddit | RUN | MATCH |  |
| 1614 | Table C4, p. 35 | google | Table C4 | make_tables_sector_surface.py, Table C4 | google | RUN | MATCH |  |
| 1615 | Table C4, p. 35 | nvidia | Table C4 | make_tables_sector_surface.py, Table C4 | nvidia | RUN | MATCH |  |
| 1616 | Table C4, p. 35 | tomshardware | Table C4 | make_tables_sector_surface.py, Table C4 | tomshardware | RUN | MATCH |  |
| 1617 | Table C4, p. 35 | techspot | Table C4 | make_tables_sector_surface.py, Table C4 | techspot | RUN | MATCH |  |
| 1618 | Table C4, p. 35 | google | Table C4 | make_tables_sector_surface.py, Table C4 | google | RUN | MATCH |  |
| 1619 | Table C4, p. 35 | youtube | Table C4 | make_tables_sector_surface.py, Table C4 | youtube | RUN | MATCH |  |
| 1620 | Table C4, p. 35 | amazon | Table C4 | make_tables_sector_surface.py, Table C4 | amazon | RUN | MATCH |  |
| 1621 | Table C4, p. 35 | reddit | Table C4 | make_tables_sector_surface.py, Table C4 | reddit | RUN | MATCH |  |
| 1622 | Table C4, p. 35 | wikipedia.org | Table C4 | make_tables_sector_surface.py, Table C4 | wikipedia.org | RUN | MATCH |  |
| 1623 | Table C4, p. 35 | consumerreports.org | Table C4 | make_tables_sector_surface.py, Table C4 | consumerreports.org | RUN | MATCH |  |
| 1624 | Table C4, p. 35 | youtube | Table C4 | make_tables_sector_surface.py, Table C4 | youtube | RUN | MATCH |  |
| 1625 | Table C4, p. 35 | wikipedia.org | Table C4 | make_tables_sector_surface.py, Table C4 | wikipedia.org | RUN | MATCH |  |
| 1626 | Table C4, p. 35 | google | Table C4 | make_tables_sector_surface.py, Table C4 | google | RUN | MATCH |  |
| 1627 | Table C4, p. 35 | sec.gov | Table C4 | make_tables_sector_surface.py, Table C4 | sec.gov | RUN | MATCH |  |
| 1628 | Table C4, p. 35 | chevronlubricants† | Table C4 | make_tables_sector_surface.py, Table C4 | chevronlubricants† | RUN | MATCH |  |
| 1629 | Table C4, p. 35 | mobil† | Table C4 | make_tables_sector_surface.py, Table C4 | mobil† | RUN | MATCH |  |
| 1630 | Table C4, p. 35 | youtube | Table C4 | make_tables_sector_surface.py, Table C4 | youtube | RUN | MATCH |  |
| 1631 | Table C4, p. 35 | wikipedia.org | Table C4 | make_tables_sector_surface.py, Table C4 | wikipedia.org | RUN | MATCH |  |
| 1632 | Table C4, p. 35 | reddit | Table C4 | make_tables_sector_surface.py, Table C4 | reddit | RUN | MATCH |  |
| 1633 | Table C4, p. 35 | sec.gov | Table C4 | make_tables_sector_surface.py, Table C4 | sec.gov | RUN | MATCH |  |
| 1634 | Table C4, p. 35 | reuters | Table C4 | make_tables_sector_surface.py, Table C4 | reuters | RUN | MATCH |  |
| 1635 | Table C4, p. 35 | stockanalysis | Table C4 | make_tables_sector_surface.py, Table C4 | stockanalysis | RUN | MATCH |  |
| 1636 | Table C4, p. 35 | youtube | Table C4 | make_tables_sector_surface.py, Table C4 | youtube | RUN | MATCH |  |
| 1637 | Table C4, p. 35 | google | Table C4 | make_tables_sector_surface.py, Table C4 | google | RUN | MATCH |  |
| 1638 | Table C4, p. 35 | wikipedia.org | Table C4 | make_tables_sector_surface.py, Table C4 | wikipedia.org | RUN | MATCH |  |
| 1639 | Table C4, p. 35 | sec.gov | Table C4 | make_tables_sector_surface.py, Table C4 | sec.gov | RUN | MATCH |  |
| 1640 | Table C4, p. 35 | extraspace | Table C4 | make_tables_sector_surface.py, Table C4 | extraspace | RUN | MATCH |  |
| 1641 | Table C4, p. 35 | wikipedia.org | Table C4 | make_tables_sector_surface.py, Table C4 | wikipedia.org | RUN | MATCH |  |
| 1642 | Table C4, p. 35 | youtube | Table C4 | make_tables_sector_surface.py, Table C4 | youtube | RUN | MATCH |  |
| 1643 | Table C4, p. 35 | google | Table C4 | make_tables_sector_surface.py, Table C4 | google | RUN | MATCH |  |
| 1644 | Table C4, p. 35 | reddit | Table C4 | make_tables_sector_surface.py, Table C4 | reddit | RUN | MATCH |  |
| 1645 | Table C4, p. 35 | benjaminmoore | Table C4 | make_tables_sector_surface.py, Table C4 | benjaminmoore | RUN | MATCH |  |
| 1646 | Table C4, p. 35 | behr | Table C4 | make_tables_sector_surface.py, Table C4 | behr | RUN | MATCH |  |
| 1647 | Table C4, p. 35 | plan-home | Table C4 | make_tables_sector_surface.py, Table C4 | plan-home | RUN | MATCH |  |
| 1648 | App. C, p. 33 | 38 | e top source is youtube.com or google.com in 38 of the 44 sector-by-view cell | make_tables_sector_surface.py | 38.0 | RUN | MATCH |  |
| 1649 | App. C, p. 33 | 44 | ce is youtube.com or google.com in 38 of the 44 sector-by-view cells, four of | make_tables_sector_surface.py | 44.0 | RUN | MATCH |  |
| 1650 | App. C, p. 33 | 15 | Gemini it is wikipedia.org or reddit.com in 15 of 22, on ChatGPT a governmen | make_tables_sector_surface.py | 15.0 | RUN | MATCH |  |
| 1651 | App. C, p. 33 | 22 | i it is wikipedia.org or reddit.com in 15 of 22, on ChatGPT a government doma | make_tables_sector_surface.py | 22.0 | RUN | MATCH |  |
| 1652 | App. C, p. 33 | 4 | 15 of 22, on ChatGPT a government domain in 4 of 11 sectors, and on Copilot | make_tables_sector_surface.py | 4.0 | RUN | MATCH |  |
| 1653 | App. C, p. 33 | 11 | f 22, on ChatGPT a government domain in 4 of 11 sectors, and on Copilot a ret | make_tables_sector_surface.py | 11.0 | RUN | MATCH |  |
| 1654 | App. C, p. 33 | 6 | ot a retailer (walmart.com or amazon.com) in 6 of 11. The script `make_table | make_tables_sector_surface.py | 6.0 | RUN | MATCH |  |
| 1655 | App. C, p. 33 | 11 | retailer (walmart.com or amazon.com) in 6 of 11. The script `make_tables_sect | make_tables_sector_surface.py | 11.0 | RUN | MATCH |  |
| 1656 | App. D, p. 36 | 120 | ctober 2026); in a screened random sample of 120, the share using a vendor's f | stakes_screen_check.py | 120.0 | RUN | MATCH |  |
| 1657 | App. D, p. 36 | 456 | of those, the share using one vendor only \| 456; 82% to 87% (kappa 0.63); 87% | vendor_reliance.py --offline | 456.0 | RUN | MATCH |  |
| 1658 | App. D, p. 36 | 82 | hose, the share using one vendor only \| 456; 82% to 87% (kappa 0.63); 87% to | stakes_screen_check.py | 82.0 | RUN | MATCH |  |
| 1659 | App. D, p. 36 | 87 | he share using one vendor only \| 456; 82% to 87% (kappa 0.63); 87% to 88% \| ` | stakes_screen_check.py | 87.0 | RUN | MATCH |  |
| 1660 | App. D, p. 36 | 0.63 | ing one vendor only \| 456; 82% to 87% (kappa 0.63); 87% to 88% \| `vendor_relian | stakes_screen_check.py | 0.63 | RUN | MATCH |  |
| 1661 | App. D, p. 36 | 87 | vendor only \| 456; 82% to 87% (kappa 0.63); 87% to 88% \| `vendor_reliance`, | stakes_screen_check.py | 87.0 | RUN | MATCH |  |
| 1662 | App. D, p. 36 | 88 | only \| 456; 82% to 87% (kappa 0.63); 87% to 88% \| `vendor_reliance`, `stakes | stakes_screen_check.py | 88.0 | RUN | MATCH |  |
| 1663 | App. D, p. 36 | 7.5 | unmatched; worldwide; US to US (estimated) \| 7.5x to 27.1x; 8.6x to 29.9x; 9.2 | arithmetic on Table 2 / its released CSV | 7.469647 | CALC | MATCH |  |
| 1664 | App. D, p. 36 | 27.1 | d; worldwide; US to US (estimated) \| 7.5x to 27.1x; 8.6x to 29.9x; 9.2x to 33.3 | arithmetic on Table 2 / its released CSV | 27.141445 | CALC | MATCH |  |
| 1665 | App. D, p. 36 | 8.6 | dwide; US to US (estimated) \| 7.5x to 27.1x; 8.6x to 29.9x; 9.2x to 33.3x \| ar | arithmetic on Table 2 / its released CSV | 8.620108 | CALC | MATCH |  |
| 1666 | App. D, p. 36 | 29.9 | S to US (estimated) \| 7.5x to 27.1x; 8.6x to 29.9x; 9.2x to 33.3x \| arithmetic | arithmetic on Table 2 / its released CSV | 29.860816 | CALC | MATCH |  |
| 1667 | App. D, p. 36 | 9.2 | (estimated) \| 7.5x to 27.1x; 8.6x to 29.9x; 9.2x to 33.3x \| arithmetic on Tab | arithmetic on Table 2 / its released CSV | 9.165211 | CALC | MATCH |  |
| 1668 | App. D, p. 36 | 33.3 | ted) \| 7.5x to 27.1x; 8.6x to 29.9x; 9.2x to 33.3x \| arithmetic on Table 2 \| \| | arithmetic on Table 2 / its released CSV | 33.302387 | CALC | MATCH |  |
| 1669 | App. D, p. 36 | 0.95 | th-on-month growth, Ahrefs over Semrush US \| 0.95, 2.66, 1.37 \| `instrument_ext | instrument_extra.py | 0.95 | RUN | MATCH |  |
| 1670 | App. D, p. 36 | 2.66 | month growth, Ahrefs over Semrush US \| 0.95, 2.66, 1.37 \| `instrument_extra` \| | instrument_extra.py | 2.66 | RUN | MATCH |  |
| 1671 | App. D, p. 36 | 1.37 | growth, Ahrefs over Semrush US \| 0.95, 2.66, 1.37 \| `instrument_extra` \| \| M1 e | instrument_extra.py | 1.37 | RUN | MATCH |  |
| 1672 | App. D, p. 36 | 5.2 | re root of their ratio from the true value \| 5.2 at 27.1x \| arithmetic on Tabl | reproducer's recomputation (recompute.py) | 5.209745 | CALC | MATCH |  |
| 1673 | App. D, p. 36 | 27.1 | of their ratio from the true value \| 5.2 at 27.1x \| arithmetic on Table 2 \| \| | arithmetic on Table 2 / its released CSV | 27.141445 | CALC | MATCH |  |
| 1674 | App. D, p. 36 | 35 | only where both terms have the same sign) \| 35% (Semrush US against Ahrefs w | instrument_extra.py | 35.0 | RUN | MATCH |  |
| 1675 | App. D, p. 36 | 54 | \| 35% (Semrush US against Ahrefs worldwide), 54% (both worldwide) \| `instrume | instrument_extra.py | 54.0 | RUN | MATCH |  |
| 1676 | App. D, p. 36 | twelve | ` \| \| M1 cross-section \| visits ratio across twelve prefixes on one date \| 0.20x | data/analyze.py | 12.0 | RUN | MATCH |  |
| 1677 | App. D, p. 36 | 0.20 | s ratio across twelve prefixes on one date \| 0.20x to 7.24x (8.89x matched); me | data/analyze.py | 0.2 | RUN | MATCH |  |
| 1678 | App. D, p. 36 | 7.24 | cross twelve prefixes on one date \| 0.20x to 7.24x (8.89x matched); median 1.01 | data/analyze.py | 7.24 | RUN | MATCH |  |
| 1679 | App. D, p. 36 | 8.89 | welve prefixes on one date \| 0.20x to 7.24x (8.89x matched); median 1.01 \| `ana | data/analyze.py | 8.89 | RUN | MATCH |  |
| 1680 | App. D, p. 36 | 1.01 | ate \| 0.20x to 7.24x (8.89x matched); median 1.01 \| `analyze` \| \| M1 age relati | data/analyze.py | 1.01 | RUN | MATCH |  |
| 1681 | App. D, p. 36 | −0.11 | ratio, Fisher 95% interval, permutation p \| −0.11 [−0.64, +0.49], p = 0.73 \| `a | data/analyze.py | -0.11 | RUN | MATCH |  |
| 1682 | App. D, p. 36 | −0.64 | Fisher 95% interval, permutation p \| −0.11 [−0.64, +0.49], p = 0.73 \| `analyze` | data/analyze.py | -0.64 | RUN | MATCH |  |
| 1683 | App. D, p. 36 | +0.49 | 95% interval, permutation p \| −0.11 [−0.64, +0.49], p = 0.73 \| `analyze` \| \| M1 | data/analyze.py | 0.49 | RUN | MATCH |  |
| 1684 | App. D, p. 36 | 0.73 | l, permutation p \| −0.11 [−0.64, +0.49], p = 0.73 \| `analyze` \| \| M1 ordering a | data/analyze.py | 0.73 | RUN | MATCH |  |
| 1685 | App. D, p. 36 | +0.94 | ts' visits; concordant pairs; by size band \| +0.94, +0.82, 60 of 66; 51 of 51 be | data/analyze.py | 0.94 | RUN | MATCH |  |
| 1686 | App. D, p. 36 | +0.82 | its; concordant pairs; by size band \| +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x | data/analyze.py | 0.82 | RUN | MATCH |  |
| 1687 | App. D, p. 36 | 60 | ncordant pairs; by size band \| +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 | data/analyze.py | 60.0 | RUN | MATCH |  |
| 1688 | App. D, p. 36 | 66 | nt pairs; by size band \| +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 | data/analyze.py | 66.0 | RUN | MATCH |  |
| 1689 | App. D, p. 36 | 51 | airs; by size band \| +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 with | instrument_extra.py | 51 | RUN | MATCH | 19 + 32 printed in two bands |
| 1690 | App. D, p. 36 | 51 | by size band \| +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within; 40 | instrument_extra.py | 51 | RUN | MATCH | 19 + 32 printed in two bands |
| 1691 | App. D, p. 36 | 9 | +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within; 40 of 40 beyond | instrument_extra.py | 9.0 | RUN | MATCH |  |
| 1692 | App. D, p. 36 | 15 | 4, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within; 40 of 40 beyond 3x on | instrument_extra.py | 15.0 | RUN | MATCH |  |
| 1693 | App. D, p. 36 | 40 | 0 of 66; 51 of 51 beyond 3x, 9 of 15 within; 40 of 40 beyond 3x on both instr | instrument_extra.py | 40.0 | RUN | MATCH |  |
| 1694 | App. D, p. 36 | 40 | 6; 51 of 51 beyond 3x, 9 of 15 within; 40 of 40 beyond 3x on both instruments | instrument_extra.py | 40.0 | RUN | MATCH |  |
| 1695 | App. D, p. 36 | 1.13 | geometric standard deviation of the ratio \| 1.13 and 3.1 \| `instrument_extra` | instrument_extra.py | 1.13 | RUN | MATCH |  |
| 1696 | App. D, p. 36 | 3.1 | c standard deviation of the ratio \| 1.13 and 3.1 \| `instrument_extra` \| \| M1 A | instrument_extra.py | 3.13 | RUN | MATCH |  |
| 1697 | App. D, p. 36 | 12.6 | ix ranks on, Wilson interval [Wilson 1927] \| 12.6% to 20.0% \| arithmetic on Tab | arithmetic on Table 3 / its released CSV | 12.609275 | CALC | MATCH |  |
| 1698 | App. D, p. 36 | 20.0 | on, Wilson interval [Wilson 1927] \| 12.6% to 20.0% \| arithmetic on Table 3 \| \| | arithmetic on Table 3 / its released CSV | 20.019872 | CALC | MATCH |  |
| 1699 | App. D, p. 36 | 55.6 | least one label; labels per linked review \| 55.6%; 2.25 \| `analyze_reviews` \| | analyze_reviews.py (saved output) | 55.6 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 1700 | App. D, p. 36 | 2.25 | one label; labels per linked review \| 55.6%; 2.25 \| `analyze_reviews` \| \| M2 la | analyze_reviews.py (saved output) | 2.25 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 1701 | App. D, p. 36 | +0.18 | (descriptive; labels are not independent) \| +0.18 (mentioned), +0.27 (all linka | m2_label_counts.csv, to five decimals | 0.184869 | CALC | MATCH |  |
| 1702 | App. D, p. 36 | +0.27 | ls are not independent) \| +0.18 (mentioned), +0.27 (all linkable) \| `analyze_rev | m2_from_counts.py | 0.273 | RUN | MATCH |  |
| 1703 | App. D, p. 36 | +0.47 | h branch's own volume, by attribution rule \| +0.47 (modal), +0.75 (split) \| `sup | m2_from_counts.py | 0.468 | RUN | MATCH |  |
| 1704 | App. D, p. 36 | +0.75 | volume, by attribution rule \| +0.47 (modal), +0.75 (split) \| `supplement_r10`, ` | m2_from_counts.py | 0.748 | RUN | MATCH |  |
| 1705 | App. D, p. 36 | 14.0 | ching a waiting pattern, against five-star \| 14.0% against 1.9% \| `analyze_revi | analyze_reviews.py (saved output) | 14.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 1706 | App. D, p. 36 | 1.9 | g pattern, against five-star \| 14.0% against 1.9% \| `analyze_reviews` \| \| M2 l | analyze_reviews.py (saved output) | 1.9 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 1707 | App. D, p. 36 | 65 | t by two blind annotators; their agreement \| 65% to 67%; kappa 0.90 (single-w | r2_link_check.py | 65.0 | RUN | MATCH |  |
| 1708 | App. D, p. 36 | 67 | o blind annotators; their agreement \| 65% to 67%; kappa 0.90 (single-word lab | r2_link_check.py | 66.8 | RUN | MATCH |  |
| 1709 | App. D, p. 36 | 0.90 | otators; their agreement \| 65% to 67%; kappa 0.90 (single-word labels about 50% | r2_link_check.py | 0.9 | RUN | MATCH |  |
| 1710 | App. D, p. 36 | 50 | to 67%; kappa 0.90 (single-word labels about 50%, multi-word 95% to 96%) \| `r | r2_link_check.py | 50.0 | RUN | MATCH |  |
| 1711 | App. D, p. 36 | 95 | 90 (single-word labels about 50%, multi-word 95% to 96%) \| `r2_link_check` \| | r2_link_check.py | 94.5 | RUN | MATCH |  |
| 1712 | App. D, p. 36 | 96 | gle-word labels about 50%, multi-word 95% to 96%) \| `r2_link_check` \| \| M2 wa | r2_link_check.py | 95.8 | RUN | MATCH |  |
| 1713 | App. D, p. 36 | 83 | d complaints about waiting; share in store \| 83% to 85%, kappa 0.93; about 90 | r2_link_check.py | 83.0 | RUN | MATCH |  |
| 1714 | App. D, p. 36 | 85 | aints about waiting; share in store \| 83% to 85%, kappa 0.93; about 90% in st | r2_link_check.py | 84.8 | RUN | MATCH |  |
| 1715 | App. D, p. 36 | 0.93 | waiting; share in store \| 83% to 85%, kappa 0.93; about 90% in store \| `r2_lin | r2_link_check.py | 0.93 | RUN | MATCH |  |
| 1716 | App. D, p. 36 | 90 | are in store \| 83% to 85%, kappa 0.93; about 90% in store \| `r2_link_check` \| | r2_link_check.py | 90.5 | RUN | MATCH |  |
| 1717 | App. D, p. 36 | 240 | d volume and Wikipedia requests per article (240 articles, October 2024 to Sep | wiki_demand_analysis.py | 240.0 | RUN | MATCH |  |
| 1718 | App. D, p. 36 | +0.45 | the matched keyword count against requests \| +0.45 (+0.34 to +0.54); +0.54 (+0.4 | wiki_demand_supplement.py | 0.44598 | RUN | MATCH |  |
| 1719 | App. D, p. 36 | +0.34 | ched keyword count against requests \| +0.45 (+0.34 to +0.54); +0.54 (+0.45 to +0 | wiki_demand_analysis.py | 0.344 | RUN | MATCH |  |
| 1720 | App. D, p. 36 | +0.54 | ord count against requests \| +0.45 (+0.34 to +0.54); +0.54 (+0.45 to +0.62) \| `w | wiki_demand_analysis.py | 0.541 | RUN | MATCH |  |
| 1721 | App. D, p. 36 | +0.54 | t against requests \| +0.45 (+0.34 to +0.54); +0.54 (+0.45 to +0.62) \| `wiki_dema | wiki_demand_analysis.py | 0.541 | RUN | MATCH |  |
| 1722 | App. D, p. 36 | +0.45 | st requests \| +0.45 (+0.34 to +0.54); +0.54 (+0.45 to +0.62) \| `wiki_demand_anal | wiki_demand_analysis.py | 0.448 | RUN | MATCH |  |
| 1723 | App. D, p. 36 | +0.62 | ts \| +0.45 (+0.34 to +0.54); +0.54 (+0.45 to +0.62) \| `wiki_demand_analysis` \| \| | wiki_demand_analysis.py | 0.623 | RUN | MATCH |  |
| 1724 | App. D, p. 36 | 35 | n; 10th and 90th percentiles; geometric SD \| 35; 0.3 to 244; 14.5 \| `wiki_dem | wiki_demand_analysis.py | 34.8 | RUN | MATCH |  |
| 1725 | App. D, p. 36 | 0.3 | 0th and 90th percentiles; geometric SD \| 35; 0.3 to 244; 14.5 \| `wiki_demand_a | wiki_demand_analysis.py | 0.3 | RUN | MATCH |  |
| 1726 | App. D, p. 36 | 244 | 90th percentiles; geometric SD \| 35; 0.3 to 244; 14.5 \| `wiki_demand_analysis | wiki_demand_analysis.py | 243.7 | RUN | MATCH |  |
| 1727 | App. D, p. 36 | 14.5 | percentiles; geometric SD \| 35; 0.3 to 244; 14.5 \| `wiki_demand_analysis` \| \| | wiki_demand_analysis.py | 14.48 | RUN | MATCH |  |
| 1728 | App. D, p. 36 | P1, P3 and P4 held; P2 held at its boundary | as fixed before collection \| P1, P3 and P4 held; P2 held at its boundary \| `wiki_demand_anal | wiki_demand_analysis.py | agrees | RUN | MATCH | statement in words |
| 1729 | App. D, p. 36 | 1,000 | a source type over all incidences among the 1,000 exported domains \| Table C1 \| | cross_sector_cells.csv: export_rows is 1000 in all 88 cells | 1000.0 | CALC | MATCH |  |
| 1730 | App. D, p. 37 | 21.3 | nst the other four, bootstrap over sectors \| 21.3% (17.2 to 26.7) against 2.1% | section7_from_aggregates.py | 21.3 | RUN | MATCH |  |
| 1731 | App. D, p. 37 | 17.2 | other four, bootstrap over sectors \| 21.3% (17.2 to 26.7) against 2.1% (1.7 to | section7_from_aggregates.py | 17.2 | RUN | MATCH |  |
| 1732 | App. D, p. 37 | 26.7 | our, bootstrap over sectors \| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) \| | section7_from_aggregates.py | 26.7 | RUN | MATCH |  |
| 1733 | App. D, p. 37 | 2.1 | over sectors \| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) \| `cross_sector | section7_from_aggregates.py | 2.1 | RUN | MATCH |  |
| 1734 | App. D, p. 37 | 1.7 | sectors \| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) \| `cross_sector_sensi | section7_from_aggregates.py | 1.7 | RUN | MATCH |  |
| 1735 | App. D, p. 37 | 2.7 | \| 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) \| `cross_sector_sensitivity` | section7_from_aggregates.py | 2.7 | RUN | MATCH |  |
| 1736 | App. D, p. 36 | 11 | gle view exceeds the highest other surface \| 11 of 11 \| `cross_sector_sensiti | section7_from_aggregates.py | 11.0 | RUN | MATCH |  |
| 1737 | App. D, p. 36 | 11 | ew exceeds the highest other surface \| 11 of 11 \| `cross_sector_sensitivity` | cross_sector_type_shares.csv: eleven sectors | 11.0 | CALC | MATCH |  |
| 1738 | App. D, p. 37 | 0.36 | op-ten non-company domains between sectors \| 0.36 to 0.40 against 0.08 to 0.23 | section7_from_aggregates.py | 0.36 | RUN | MATCH |  |
| 1739 | App. D, p. 37 | 0.40 | on-company domains between sectors \| 0.36 to 0.40 against 0.08 to 0.23 \| `cross | section7_from_aggregates.py | 0.4 | RUN | MATCH |  |
| 1740 | App. D, p. 37 | 0.08 | mains between sectors \| 0.36 to 0.40 against 0.08 to 0.23 \| `cross_sector` \| \| | section7_from_aggregates.py | 0.08 | RUN | MATCH |  |
| 1741 | App. D, p. 37 | 0.23 | tween sectors \| 0.36 to 0.40 against 0.08 to 0.23 \| `cross_sector` \| \| M3 varia | section7_from_aggregates.py | 0.23 | RUN | MATCH |  |
| 1742 | App. D, p. 37 | 77 | shares explained by surface and by sector \| 77% against 14% (video and commu | section7_from_aggregates.py | 77.0 | RUN | MATCH |  |
| 1743 | App. D, p. 37 | 14 | ained by surface and by sector \| 77% against 14% (video and community) \| `cro | section7_from_aggregates.py | 14.0 | RUN | MATCH |  |
| 1744 | App. D, p. 36 | one held, one in direction, two failed | s written before collection \| one held, one in direction, two failed \| `cross_sector` \| | section7_from_aggregates.py | agrees | RUN | MATCH | statement in words |
| 1745 | App. D, p. 37 | 4 | petency questions the ontology can express \| 4/5 (released example) \| `ufi c | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1746 | App. D, p. 37 | 5 | tency questions the ontology can express \| 4/5 (released example) \| `ufi cq` | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1747 | App. D, p. 37 | 70.4 | graph answers, over expressible questions \| 70.4% (released example) \| `ufi cq | ufi repository (not in the bundle) | None | NONE | CANNOT RUN | needs the ufi repository, which is not in the bundle (the paper cites it at a public URL; not fetched here) |
| 1748 | §E.1, p. 38 | twelve | same domain-scoped figures for every one of twelve subfolders queried (Section 5 | data/analyze.py | 12.0 | RUN | MATCH |  |
| 1749 | §E.1, p. 38 | 14,823 | ived, and one stored-answer count moved from 14,823 to 17,206 to 17,400 between 9 | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 14823.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1750 | §E.1, p. 38 | 17,206 | one stored-answer count moved from 14,823 to 17,206 to 17,400 between 9 and 12 Oc | instrument_series_table5_checkpoints.csv (parsed from Table 5 itself) | 17206.0 | CIRC | MATCH | circular: the CSV is parsed from the paper's own table; the dashboard read is not archived |
| 1751 | §E.1, p. 38 | 17,400 | -answer count moved from 14,823 to 17,206 to 17,400 between 9 and 12 October 2026 | single_reads_2026-10.csv | 17400.0 | FILE | MATCH | dashboard read, not archived |
| 1752 | §E.1, p. 38 | 7.5 | d. Two instruments differed on one prefix by 7.5x to 27.1x, and across twelve | arithmetic on Table 2 / its released CSV | 7.469647 | CALC | MATCH |  |
| 1753 | §E.1, p. 38 | 27.1 | nstruments differed on one prefix by 7.5x to 27.1x, and across twelve prefixes | arithmetic on Table 2 / its released CSV | 27.141445 | CALC | MATCH |  |
| 1754 | §E.1, p. 38 | twelve | d on one prefix by 7.5x to 27.1x, and across twelve prefixes of one domain by 0.2 | data/analyze.py | 12.0 | RUN | MATCH |  |
| 1755 | §E.1, p. 38 | 0.20 | and across twelve prefixes of one domain by 0.20x to 7.24x (Sections 5.1 and 5 | data/analyze.py | 0.2 | RUN | MATCH |  |
| 1756 | §E.1, p. 38 | 7.24 | ss twelve prefixes of one domain by 0.20x to 7.24x (Sections 5.1 and 5.5). 5. * | data/analyze.py | 7.24 | RUN | MATCH |  |
| 1757 | §E.1, p. 38 | 40 | one instrument does not settle it. Here all 40 pairs of sections more than t | instrument_extra.py | 40.0 | RUN | MATCH |  |
| 1758 | §E.1, p. 38 | 16 | both instruments were ordered alike, as were 16 of the 18 more than three tim | instrument_extra.py | 16.0 | RUN | MATCH |  |
| 1759 | §E.1, p. 38 | 18 | uments were ordered alike, as were 16 of the 18 more than three times apart o | instrument_extra.py | 18.0 | RUN | MATCH |  |
| 1760 | §E.1, p. 38 | 4 | re than three times apart on exactly one and 4 of the 8 within that factor o | instrument_extra.py | 4.0 | RUN | MATCH |  |
| 1761 | §E.1, p. 38 | 8 | hree times apart on exactly one and 4 of the 8 within that factor on both; t | instrument_extra.py | 8.0 | RUN | MATCH |  |
| 1762 | §E.1, p. 38 | the two exceptions were six to seven times apart on one instrument and about equal on the other | 8 within that factor on both; the two exceptions were six to seven times apart on one instrument and about equal on the other (Sections 5.5 and 5 | instrument_extra.py section 10 | agrees | RUN | MATCH | statement in words |
| 1763 | §E.1, p. 38 | twelve | ng instruments. Matching changed how many of twelve prefixes fell below a ratio o | data/analyze.py | 12.0 | RUN | MATCH |  |
| 1764 | §E.1, p. 38 | six | lve prefixes fell below a ratio of one, from six to four (Section 5.5). 7. **T | data/analyze.py | 6.0 | RUN | MATCH |  |
| 1765 | §E.1, p. 38 | four | fixes fell below a ratio of one, from six to four (Section 5.5). 7. **The keywo | data/analyze.py | 4.0 | RUN | MATCH |  |
| 1766 | §E.1, p. 38 | 35 | area-code prefix the universe term was about 35% of the log gap with Semrush | instrument_extra.py | 35.0 | RUN | MATCH |  |
| 1767 | §E.1, p. 38 | 54 | emrush US against Ahrefs worldwide and about 54% with both worldwide (Section | instrument_extra.py | 54.0 | RUN | MATCH |  |
| 1768 | §E.1, p. 38 | twelve | ith both worldwide (Section 5.6); across the twelve prefixes the keyword ratio ha | data/analyze.py | 12.0 | RUN | MATCH |  |
| 1769 | §E.1, p. 38 | 14.0 | beside it, with its source and period. Here 14.0% of one- and two-star reviews | analyze_reviews.py (saved output) | 14.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 1770 | §E.1, p. 38 | 11 | tched a waiting pattern while the taxonomy's 11 labels mentioning waiting car | supplement_r10.py (saved output) | 11.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 1771 | §E.1, p. 38 | 622 | onomy's 11 labels mentioning waiting carried 622 searches a month (Section 6.1 | supplement_r10.py (saved output) | 622.0 | SAVED | CANNOT RUN | agrees with the saved output; the script that prints it needs withheld data |
| 1772 | §E.1, p. 38 | twelve | that prints each quoted statistic. Here the twelve-prefix reads and `analyze.py` | data/analyze.py | 12.0 | RUN | MATCH |  |
| 1773 | §E.2, p. 38 | 35 | on the area-code prefix under both pairings (35% and 54%, the second approxim | instrument_extra.py | 35.0 | RUN | MATCH |  |
| 1774 | §E.2, p. 39 | 54 | rea-code prefix under both pairings (35% and 54%, the second approximate beca | instrument_extra.py | 54.0 | RUN | MATCH |  |
| 1775 | §E.2, p. 39 | 3.2 | low one, the keyword ratio is still at least 3.2 (`instrument_extra.py`, secti | instrument_extra.py | 3.2 | RUN | MATCH |  |
| 1776 | §E.3, p. 39 | 72 | , Crossref, the EQUATOR library and the web (72 logged API queries; Semantic | checklist search_record.md | 72.0 | FILE | MATCH |  |
| 1777 | §E.3, p. 39 | 120 | ks Section 1 counts: in a screened sample of 120, 82% to 87% use a vendor's fi | stakes_screen_check.py | 120.0 | RUN | MATCH |  |
| 1778 | §E.3, p. 39 | 82 | ction 1 counts: in a screened sample of 120, 82% to 87% use a vendor's figure | stakes_screen_check.py | 82.0 | RUN | MATCH |  |
| 1779 | §E.3, p. 39 | 87 | counts: in a screened sample of 120, 82% to 87% use a vendor's figures as da | stakes_screen_check.py | 87.0 | RUN | MATCH |  |
| 1780 | §E.3, p. 39 | 87 | % to 87% use a vendor's figures as data, and 87% to 88% of those use one vend | stakes_screen_check.py | 87.0 | RUN | MATCH |  |
| 1781 | §E.3, p. 39 | 88 | % use a vendor's figures as data, and 87% to 88% of those use one vendor's on | stakes_screen_check.py | 88.0 | RUN | MATCH |  |

## 4. Command log

```
# Command log, independent reproduction run 5, 3 November 2026
# R = session scratchpad folder repro_run5 (fresh, empty when created). Every script run: a new unpack of the zip, the
# bundle's command, under sandbox-exec denying all network and all writes to the Desktop (check_scripts/run_one.py).
# Setup, before the first logged run:
shasum -a 256 <project>/06_MANUSCRIPT/User_First_Intelligence_v5.3_2026-11-03_source.zip <project>/06_MANUSCRIPT/User_First_Intelligence_v5.3_2026-11-03.pdf
unzip -l <zip>
cp <zip> <pdf> R/
unzip -q -o R/<zip> -d R/pristine
pdftotext -layout R/<pdf> R/paper_layout.txt; pdftotext R/<pdf> R/paper_raw.txt; pdfinfo R/<pdf>
grep -rnE "/Users/|Desktop/|expanduser|~/|Research-Papers" (scripts): no absolute paths outside 08_REVIEW
grep -rlE "urllib.request|requests.|http.client|socket|subprocess|os.system" (scripts)
sandbox-exec -p '(version 1)(allow default)(deny network*)' python3 -c "urllib.request.urlopen('https://example.org')": blocked, as intended
which python3 pdftotext tectonic xelatex pandoc ots; python3 -m pip list; python3 -m pip show ufi
# Three attempts at the build batch stopped on errors in the reproducer's own shell and runner (word splitting in zsh, a broken
# string in run_one.py), before any bundle script started; they are not listed.

# Runs, in order, as the runner logged them:
[2026-11-03 14:36:49] tag=analyze cwd=<fresh unpack>/data hashseed=- sandbox=no-network,no-desktop-writes: python3 analyze.py -> exit 0 in 0.3s; stdout 1233 bytes; changed 0; new 0
[2026-11-03 14:37:24] tag=instrument_extra cwd=<fresh unpack>/instrument_divergence_extra hashseed=- sandbox=no-network,no-desktop-writes: python3 instrument_extra.py -> exit 0 in 35.5s; stdout 5712 bytes; changed 0; new 0
[2026-11-03 14:37:26] tag=instrument_extra_as_stamped cwd=<fresh unpack>/protocols hashseed=- sandbox=no-network,no-desktop-writes: python3 instrument_extra_as_stamped.py -> exit 0 in 0.9s; stdout 2496 bytes; changed 0; new 4
[2026-11-03 14:37:26] tag=reread_compare cwd=<fresh unpack>/protocols hashseed=- sandbox=no-network,no-desktop-writes: python3 reread_compare.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:37:27] tag=reread_compare_anywhere cwd=<fresh unpack>/protocols hashseed=- sandbox=no-network,no-desktop-writes: python3 reread_compare_anywhere.py -> exit 0 in 0.1s; stdout 130 bytes; changed 0; new 0
[2026-11-03 14:38:04] tag=m2_from_counts cwd=<fresh unpack>/review_demand hashseed=- sandbox=no-network,no-desktop-writes: python3 m2_from_counts.py -> exit 0 in 36.9s; stdout 2465 bytes; changed 0; new 0
[2026-11-03 14:38:05] tag=r2_link_check cwd=<fresh unpack>/review_demand hashseed=- sandbox=no-network,no-desktop-writes: python3 r2_link_check.py -> exit 0 in 0.2s; stdout 1997 bytes; changed 0; new 0
[2026-11-03 14:38:06] tag=analyze_reviews cwd=<fresh unpack>/review_demand hashseed=- sandbox=no-network,no-desktop-writes: python3 analyze_reviews.py -> exit 1 in 1.4s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:38:07] tag=r2_link_sample cwd=<fresh unpack>/review_demand hashseed=- sandbox=no-network,no-desktop-writes: python3 r2_link_sample.py -> exit 1 in 0.5s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:38:09] tag=supplement_r10 cwd=<fresh unpack>/review_demand hashseed=- sandbox=no-network,no-desktop-writes: python3 supplement_r10.py -> exit 1 in 1.2s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:38:10] tag=make_fig_reviews_v50 cwd=<fresh unpack>/review_demand hashseed=- sandbox=no-network,no-desktop-writes: python3 make_fig_reviews_v50.py -> exit 1 in 0.7s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:38:10] tag=vendor_reliance_offline cwd=<fresh unpack>/stakes hashseed=- sandbox=no-network,no-desktop-writes: python3 vendor_reliance.py --offline -> exit 0 in 0.1s; stdout 470 bytes; changed 0; new 0
[2026-11-03 14:38:11] tag=stakes_screen_check cwd=<fresh unpack>/stakes hashseed=- sandbox=no-network,no-desktop-writes: python3 stakes_screen_check.py -> exit 0 in 0.1s; stdout 600 bytes; changed 0; new 0
[2026-11-03 14:38:33] tag=wiki_demand_analysis cwd=<fresh unpack>/wikipedia_demand hashseed=- sandbox=no-network,no-desktop-writes: python3 wiki_demand_analysis.py -> exit 0 in 21.9s; stdout 4911 bytes; changed 2; new 0
[2026-11-03 14:38:34] tag=wiki_demand_supplement cwd=<fresh unpack>/wikipedia_demand hashseed=- sandbox=no-network,no-desktop-writes: python3 wiki_demand_supplement.py -> exit 0 in 0.9s; stdout 1589 bytes; changed 0; new 0
[2026-11-03 14:38:36] tag=make_fig_wikipedia cwd=<fresh unpack>/wikipedia_demand hashseed=- sandbox=no-network,no-desktop-writes: python3 make_fig_wikipedia.py -> exit 0 in 1.1s; stdout 3 bytes; changed 0; new 2
[2026-11-03 14:39:52] tag=section7_from_aggregates cwd=<fresh unpack>/ai_citation_cross_sector/scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 section7_from_aggregates.py -> exit 0 in 76.1s; stdout 6873 bytes; changed 0; new 0
[2026-11-03 14:39:52] tag=cross_sector cwd=<fresh unpack>/ai_citation_cross_sector/scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 cross_sector.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:39:53] tag=cross_sector_sensitivity cwd=<fresh unpack>/ai_citation_cross_sector/scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 cross_sector_sensitivity.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:39:53] tag=cross_sector_sensitivity2 cwd=<fresh unpack>/ai_citation_cross_sector/scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 cross_sector_sensitivity2.py -> exit 1 in 0.1s; stdout 760 bytes; changed 0; new 0
[2026-11-03 14:39:54] tag=make_tables_sector_surface cwd=<fresh unpack>/ai_citation_cross_sector/scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 make_tables_sector_surface.py -> exit 0 in 0.1s; stdout 3007 bytes; changed 0; new 0
[2026-11-03 14:39:55] tag=make_fig_sources cwd=<fresh unpack>/ai_citation_cross_sector/scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 make_fig_sources.py -> exit 0 in 1.3s; stdout 123 bytes; changed 0; new 2
[2026-11-03 14:39:56] tag=make_brand_radar_urls cwd=<fresh unpack>/ai_citation_cross_sector/scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 make_brand_radar_urls.py -> exit 0 in 0.1s; stdout 330 bytes; changed 0; new 0
[2026-11-03 14:39:58] tag=make_figs_v4 cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 make_figs_v4.py -> exit 0 in 2.1s; stdout 3 bytes; changed 6; new 0
[2026-11-03 14:40:00] tag=make_fig0 cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 make_fig0.py -> exit 0 in 0.9s; stdout 3 bytes; changed 1; new 0
[2026-11-03 14:40:57] tag=build_tex cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 build_tex.py -> exit 0 in 3.0s; stdout 866 bytes; changed 0; new 15
[2026-11-03 14:40:58] tag=build_docx cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: /bin/zsh build_docx.sh -> exit 0 in 0.6s; stdout 23 bytes; changed 0; new 2
[2026-11-03 14:41:01] tag=tectonic_compile cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: /bin/zsh -c tectonic --keep-logs --chatter minimal paper.tex -> exit 0 in 2.9s; stdout 0 bytes; changed 0; new 2
[2026-11-03 14:41:16] tag=edit_v49 cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v49.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:17] tag=edit_v49_r9 cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v49_r9.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:17] tag=edit_v49_r9b cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v49_r9b.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:18] tag=edit_v49_r9c cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v49_r9c.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:18] tag=edit_v50 cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v50.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:19] tag=edit_v50b cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v50b.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:19] tag=edit_v50c cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v50c.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:19] tag=edit_v51 cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v51.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:20] tag=edit_v51b cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v51b.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:20] tag=edit_v52 cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:21] tag=edit_v52b cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52b.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:21] tag=edit_v52c cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52c.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:22] tag=edit_v52d cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52d.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:22] tag=edit_v52e cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52e.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:23] tag=edit_v52f cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52f.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:23] tag=edit_v52g cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52g.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:23] tag=edit_v52h cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52h.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:24] tag=edit_v52i cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52i.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:24] tag=edit_v52j cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52j.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:25] tag=edit_v52k cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52k.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:25] tag=edit_v52l cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52l.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:26] tag=edit_v52m cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52m.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:26] tag=edit_v52n cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52n.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:27] tag=edit_v52o cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52o.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:27] tag=edit_v52p cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52p.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:28] tag=edit_v52q cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52q.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:28] tag=edit_v52r cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52r.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:29] tag=edit_v52s cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52s.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:29] tag=edit_v52t cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52t.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:30] tag=edit_v52u cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v52u.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:30] tag=edit_v53a cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v53a.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:30] tag=edit_v53b cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v53b.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:31] tag=edit_v53c cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v53c.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:31] tag=edit_v53d cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v53d.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:32] tag=edit_v53e cwd=<fresh unpack>/. hashseed=- sandbox=no-network,no-desktop-writes: python3 edit_v53e.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 14:41:32] tag=analyze__hs1 cwd=<fresh unpack>/data hashseed=1 sandbox=no-network,no-desktop-writes: python3 analyze.py -> exit 0 in 0.3s; stdout 1233 bytes; changed 0; new 0
[2026-11-03 14:42:05] tag=instrument_extra__hs1 cwd=<fresh unpack>/instrument_divergence_extra hashseed=1 sandbox=no-network,no-desktop-writes: python3 instrument_extra.py -> exit 0 in 32.4s; stdout 5712 bytes; changed 0; new 0
[2026-11-03 14:42:42] tag=m2_from_counts__hs1 cwd=<fresh unpack>/review_demand hashseed=1 sandbox=no-network,no-desktop-writes: python3 m2_from_counts.py -> exit 0 in 36.6s; stdout 2465 bytes; changed 0; new 0
[2026-11-03 14:42:42] tag=r2_link_check__hs1 cwd=<fresh unpack>/review_demand hashseed=1 sandbox=no-network,no-desktop-writes: python3 r2_link_check.py -> exit 0 in 0.1s; stdout 1997 bytes; changed 0; new 0
[2026-11-03 14:42:43] tag=vendor_reliance_offline__hs1 cwd=<fresh unpack>/stakes hashseed=1 sandbox=no-network,no-desktop-writes: python3 vendor_reliance.py --offline -> exit 0 in 0.1s; stdout 470 bytes; changed 0; new 0
[2026-11-03 14:42:43] tag=stakes_screen_check__hs1 cwd=<fresh unpack>/stakes hashseed=1 sandbox=no-network,no-desktop-writes: python3 stakes_screen_check.py -> exit 0 in 0.1s; stdout 600 bytes; changed 0; new 0
[2026-11-03 14:43:05] tag=wiki_demand_analysis__hs1 cwd=<fresh unpack>/wikipedia_demand hashseed=1 sandbox=no-network,no-desktop-writes: python3 wiki_demand_analysis.py -> exit 0 in 20.9s; stdout 4911 bytes; changed 2; new 0
[2026-11-03 14:43:06] tag=wiki_demand_supplement__hs1 cwd=<fresh unpack>/wikipedia_demand hashseed=1 sandbox=no-network,no-desktop-writes: python3 wiki_demand_supplement.py -> exit 0 in 1.1s; stdout 1589 bytes; changed 0; new 0
[2026-11-03 14:44:25] tag=section7_from_aggregates__hs1 cwd=<fresh unpack>/ai_citation_cross_sector/scripts hashseed=1 sandbox=no-network,no-desktop-writes: python3 section7_from_aggregates.py -> exit 0 in 78.4s; stdout 6873 bytes; changed 0; new 0
[2026-11-03 14:44:25] tag=make_tables_sector_surface__hs1 cwd=<fresh unpack>/ai_citation_cross_sector/scripts hashseed=1 sandbox=no-network,no-desktop-writes: python3 make_tables_sector_surface.py -> exit 0 in 0.1s; stdout 3007 bytes; changed 0; new 0
[2026-11-03 14:44:26] tag=analyze__hs987654 cwd=<fresh unpack>/data hashseed=987654 sandbox=no-network,no-desktop-writes: python3 analyze.py -> exit 0 in 0.3s; stdout 1233 bytes; changed 0; new 0
[2026-11-03 14:44:59] tag=instrument_extra__hs987654 cwd=<fresh unpack>/instrument_divergence_extra hashseed=987654 sandbox=no-network,no-desktop-writes: python3 instrument_extra.py -> exit 0 in 32.8s; stdout 5712 bytes; changed 0; new 0
[2026-11-03 14:45:42] tag=m2_from_counts__hs987654 cwd=<fresh unpack>/review_demand hashseed=987654 sandbox=no-network,no-desktop-writes: python3 m2_from_counts.py -> exit 0 in 42.8s; stdout 2465 bytes; changed 0; new 0
[2026-11-03 14:45:43] tag=r2_link_check__hs987654 cwd=<fresh unpack>/review_demand hashseed=987654 sandbox=no-network,no-desktop-writes: python3 r2_link_check.py -> exit 0 in 0.2s; stdout 1997 bytes; changed 0; new 0
[2026-11-03 14:45:44] tag=vendor_reliance_offline__hs987654 cwd=<fresh unpack>/stakes hashseed=987654 sandbox=no-network,no-desktop-writes: python3 vendor_reliance.py --offline -> exit 0 in 0.2s; stdout 470 bytes; changed 0; new 0
[2026-11-03 14:45:44] tag=stakes_screen_check__hs987654 cwd=<fresh unpack>/stakes hashseed=987654 sandbox=no-network,no-desktop-writes: python3 stakes_screen_check.py -> exit 0 in 0.2s; stdout 600 bytes; changed 0; new 0
[2026-11-03 14:46:19] tag=wiki_demand_analysis__hs987654 cwd=<fresh unpack>/wikipedia_demand hashseed=987654 sandbox=no-network,no-desktop-writes: python3 wiki_demand_analysis.py -> exit 0 in 34.1s; stdout 4911 bytes; changed 2; new 0
[2026-11-03 14:46:21] tag=wiki_demand_supplement__hs987654 cwd=<fresh unpack>/wikipedia_demand hashseed=987654 sandbox=no-network,no-desktop-writes: python3 wiki_demand_supplement.py -> exit 0 in 1.3s; stdout 1589 bytes; changed 0; new 0
[2026-11-03 14:48:26] python3 check_scripts/recompute.py <pristine> recomputed.json
[2026-11-03 14:48:43] tag=section7_from_aggregates__hs987654 cwd=<fresh unpack>/ai_citation_cross_sector/scripts hashseed=987654 sandbox=no-network,no-desktop-writes: python3 section7_from_aggregates.py -> exit 0 in 141.6s; stdout 6873 bytes; changed 0; new 0
[2026-11-03 14:48:43] tag=make_tables_sector_surface__hs987654 cwd=<fresh unpack>/ai_citation_cross_sector/scripts hashseed=987654 sandbox=no-network,no-desktop-writes: python3 make_tables_sector_surface.py -> exit 0 in 0.1s; stdout 3007 bytes; changed 0; new 0
[2026-11-03 14:49:04] python3 check_scripts/ots_check.py <pristine>
[2026-11-03 14:49:36] curl -s --max-time 25 https://blockstream.info/api/block-height/971506 (public Bitcoin block explorer; not a study vendor)
[2026-11-03 14:49:37] curl -s --max-time 25 https://blockstream.info/api/block/00000000000000000001eae50cb039defe3499981760a7a14cc7c3040bf18484
[2026-11-03 14:49:37] curl -s --max-time 25 https://blockstream.info/api/block-height/971522 (public Bitcoin block explorer; not a study vendor)
[2026-11-03 14:49:37] curl -s --max-time 25 https://blockstream.info/api/block/00000000000000000000e8543c3a9bed1b007dbee49088a6a8790516f12d121c
[2026-11-03 14:49:38] curl -s --max-time 25 https://blockstream.info/api/block-height/973934 (public Bitcoin block explorer; not a study vendor)
[2026-11-03 14:49:38] curl -s --max-time 25 https://blockstream.info/api/block/000000000000000000016bb394d8a6d087c8a601b80bc79b5ebb9ae8cd43d4ac
[2026-11-03 14:49:38] curl -s --max-time 25 https://blockstream.info/api/block-height/973943 (public Bitcoin block explorer; not a study vendor)
[2026-11-03 14:49:39] curl -s --max-time 25 https://blockstream.info/api/block/00000000000000000000cb7860fed43d4b3c9aa86231acda0f8383bc528cbdbe
[2026-11-03 14:49:39] curl -s --max-time 25 https://blockstream.info/api/block-height/973953 (public Bitcoin block explorer; not a study vendor)
[2026-11-03 14:49:39] curl -s --max-time 25 https://blockstream.info/api/block/00000000000000000001737a96818c134287b87c2f6b601c392395dd5afeabe9
[2026-11-03 14:50:57] tag=wiki_readme_sequence cwd=<fresh unpack>/wikipedia_demand hashseed=- sandbox=no-network,no-desktop-writes: /bin/bash -c python3 wiki_demand_analysis.py && python3 make_fig_wikipedia.py -> exit 0 in 23.1s; stdout 4914 bytes; changed 2; new 2
[2026-11-03 15:02:51] tag=stakes_screen_sample cwd=<fresh unpack>/stakes hashseed=- sandbox=no-network,no-desktop-writes: python3 stakes_screen_sample.py -> exit 1 in 0.2s; stdout 0 bytes; changed 1; new 0
[2026-11-03 15:02:52] tag=rv_08_REVIEW_reproduction_v5_2_2026-10-15_checks_check_appc_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 check_appc.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:02:53] tag=rv_08_REVIEW_reproduction_v5_2_2026-10-15_checks_check_kappa_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 check_kappa.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:02:53] tag=rv_08_REVIEW_reproduction_v5_2_2026-10-15_checks_check_m1_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 check_m1.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:02:54] tag=rv_08_REVIEW_reproduction_v5_2_2026-10-15_checks_check_m3_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 check_m3.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:02:55] tag=rv_08_REVIEW_reproduction_v5_2_2026-10-15_checks_check_stakes_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 check_stakes.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:02:55] tag=rv_08_REVIEW_reproduction_v5_2_2026-10-15_checks_check_t3_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 check_t3.py -> exit 0 in 0.1s; stdout 202 bytes; changed 0; new 0
[2026-11-03 15:02:56] tag=rv_08_REVIEW_reproduction_v5_2_2026-10-15_checks_dups_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 dups.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:02:57] tag=rv_08_REVIEW_reproduction_v5_2_2026-10-15_checks_md_vs_tex_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 md_vs_tex.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:02:57] tag=rv_08_REVIEW_reproduction_v5_2_2026-10-15_checks_numbers_table_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 numbers_table.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:02:58] tag=rv_08_REVIEW_reproduction_v5_2_2026-10-15_checks_pdfdiff_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 pdfdiff.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:02:59] tag=rv_08_REVIEW_reproduction_v5_2_run2_2026-10-15_checks_boot_seeds_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 boot_seeds.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:00] tag=rv_08_REVIEW_reproduction_v5_2_run2_2026-10-15_checks_check_numbers_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 check_numbers.py -> exit 1 in 1.2s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:01] tag=rv_08_REVIEW_reproduction_v5_2_run2_2026-10-15_checks_coverage_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 coverage.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:02] tag=rv_08_REVIEW_reproduction_v5_2_run2_2026-10-15_checks_ots_parse_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 ots_parse.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:02] tag=rv_08_REVIEW_reproduction_v5_2_run2_2026-10-15_checks_pdfdiff_bytes_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 pdfdiff_bytes.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:03] tag=rv_08_REVIEW_reproduction_v5_2_run2_2026-10-15_checks_single_reads_coverage_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 single_reads_coverage.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:04] tag=rv_08_REVIEW_reproduction_v5_2_run2_2026-10-15_checks_tally_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run2_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 tally.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:04] tag=rv_08_REVIEW_reproduction_v5_2_run3_2026-10-15_checks_boundary_scan_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 boundary_scan.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:05] tag=rv_08_REVIEW_reproduction_v5_2_run3_2026-10-15_checks_check_numbers_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 check_numbers.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:06] tag=rv_08_REVIEW_reproduction_v5_2_run3_2026-10-15_checks_coverage_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 coverage.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:07] tag=rv_08_REVIEW_reproduction_v5_2_run3_2026-10-15_checks_m2_precise_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 m2_precise.py -> exit 1 in 0.8s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:08] tag=rv_08_REVIEW_reproduction_v5_2_run3_2026-10-15_checks_make_report_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 make_report.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:08] tag=rv_08_REVIEW_reproduction_v5_2_run3_2026-10-15_checks_ots_parse_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 ots_parse.py -> exit 0 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:09] tag=rv_08_REVIEW_reproduction_v5_2_run3_2026-10-15_checks_pdf_compare_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run3_2026-10-15/checks hashseed=- sandbox=no-network,no-desktop-writes: python3 pdf_compare.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:11] tag=rv_08_REVIEW_reproduction_v5_2_run4_2026-10-15_check_scripts_check_numbers_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 check_numbers.py -> exit 1 in 0.9s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:11] tag=rv_08_REVIEW_reproduction_v5_2_run4_2026-10-15_check_scripts_compare_figures_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 compare_figures.py -> exit 1 in 0.4s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:12] tag=rv_08_REVIEW_reproduction_v5_2_run4_2026-10-15_check_scripts_compare_outputs_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 compare_outputs.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:13] tag=rv_08_REVIEW_reproduction_v5_2_run4_2026-10-15_check_scripts_coverage_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 coverage.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:13] tag=rv_08_REVIEW_reproduction_v5_2_run4_2026-10-15_check_scripts_figure_check_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 figure_check.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:14] tag=rv_08_REVIEW_reproduction_v5_2_run4_2026-10-15_check_scripts_label_audit_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 label_audit.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:16] tag=rv_08_REVIEW_reproduction_v5_2_run4_2026-10-15_check_scripts_m2_boundary_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 m2_boundary.py -> exit 1 in 0.9s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:17] tag=rv_08_REVIEW_reproduction_v5_2_run4_2026-10-15_check_scripts_m2_precise_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 m2_precise.py -> exit 1 in 0.8s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:18] tag=rv_08_REVIEW_reproduction_v5_2_run4_2026-10-15_check_scripts_make_report_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 make_report.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:18] tag=rv_08_REVIEW_reproduction_v5_2_run4_2026-10-15_check_scripts_manifest_check_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 manifest_check.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:19] tag=rv_08_REVIEW_reproduction_v5_2_run4_2026-10-15_check_scripts_md_vs_built_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 md_vs_built.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:19] tag=rv_08_REVIEW_reproduction_v5_2_run4_2026-10-15_check_scripts_ots_parse_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 ots_parse.py -> exit 0 in 0.1s; stdout 0 bytes; changed 0; new 0
[2026-11-03 15:03:20] tag=rv_08_REVIEW_reproduction_v5_2_run4_2026-10-15_check_scripts_tokens_py cwd=<fresh unpack>/08_REVIEW/reproduction_v5.2_run4_2026-10-15/check_scripts hashseed=- sandbox=no-network,no-desktop-writes: python3 tokens.py -> exit 1 in 0.1s; stdout 0 bytes; changed 0; new 0

# After the logged runs:
PYTHONDONTWRITEBYTECODE=1 python3 check_scripts/side_checks.py R/pristine/<bundle>        # outputs/_side_checks.log
python3 check_scripts/figures_compare.py R                                                # outputs/_figures_compare.log
bash check_scripts/misc_runs.sh                                                           # determinism diff, stamped vs current, PDF byte diff
PYTHONDONTWRITEBYTECODE=1 python3 check_scripts/number_table.py table_out                 # outputs/_number_table.log, repeated while the rules were written
MUTATE=<11,22,33,44,55,66> python3 check_scripts/number_table.py table_out                # outputs/_mutation_final.log
PYTHONDONTWRITEBYTECODE=1 python3 check_scripts/final_checks.py R                         # outputs/_final_checks.log
git -C <project> status --short; shasum -a 256 <zip> <pdf>                                # end-of-run state, read only
python3 check_scripts/make_report.py <report folder>

```
