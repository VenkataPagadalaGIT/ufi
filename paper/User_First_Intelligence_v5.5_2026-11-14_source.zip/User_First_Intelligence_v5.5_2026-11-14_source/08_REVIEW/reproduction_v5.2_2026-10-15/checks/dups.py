import csv, sys
from collections import Counter
rows = list(csv.DictReader(open(sys.argv[1])))
c = Counter(r["id"] for r in rows)
d = [k for k, v in c.items() if v > 1]
for k in d:
    for r in rows:
        if r["id"] == k:
            print(r["id"], r["year"], r["n_tools"], r["tools_named"], r["title"][:70])
seen, ded = set(), []
for r in rows:
    if r["id"] not in seen:
        seen.add(r["id"]); ded.append(r)
m = [r for r in ded if int(r["n_tools"]) >= 1]
one = sum(int(r["n_tools"]) == 1 for r in m)
print(f"deduplicated: {len(ded)} works; {len(m)} name a tool; exactly one {one} ({one/len(m):.1%})")
