"""Reproducer's own check: agreement and kappa from the four judgment files, computed independently."""
import csv, sys
from collections import Counter
d = sys.argv[1]
def load(f, k):
    return {r["sample_id"]: r[k].strip().lower() for r in csv.DictReader(open(f"{d}/{f}"))}
for name, f1, f2, k in (("A", "r2_judgments_A.csv", "r2_judgments_A_annotator2.csv", "judgment"),
                        ("B", "r2_judgments_B.csv", "r2_judgments_B_annotator2.csv", "waiting_complaint")):
    a, b = load(f1, k), load(f2, k)
    ids = sorted(set(a) & set(b)); n = len(ids)
    po = sum(a[i] == b[i] for i in ids) / n
    ca, cb = Counter(a[i] for i in ids), Counter(b[i] for i in ids)
    pe = sum(ca[c] * cb[c] for c in set(ca) | set(cb)) / n / n
    print(f"{name}: n {n} (ids identical: {set(a) == set(b)}); counts {dict(ca)} / {dict(cb)}; agreement {po:.1%}; kappa {(po - pe) / (1 - pe):.3f}")
