"""Reproducer's own consistency check: the summary in stakes/vendor_reliance_output.txt recomputed from the
shipped stakes/vendor_reliance_works.csv (the script itself re-queries the live OpenAlex API and was not run).
Usage: python3 -I check_stakes.py <bundle dir>
"""
import csv
import sys
from collections import Counter
from pathlib import Path

rows = list(csv.DictReader((Path(sys.argv[1]) / "stakes/vendor_reliance_works.csv").open()))
for r in rows:
    r["n_tools"] = int(r["n_tools"])
matched = [r for r in rows if r["n_tools"] >= 1]
by_year = Counter(r["year"] for r in matched)
one = sum(1 for r in matched if r["n_tools"] == 1)
recent = [r for r in matched if r["year"] and 2023 <= int(r["year"]) <= 2026]
r1 = sum(1 for r in recent if r["n_tools"] == 1)
print(f"{len(rows)} works in the file; {len(matched)} name at least one tool")
print("by year:", ", ".join(f"{y}: {by_year[y]}" for y in sorted(k for k in by_year if k)))
print(f"name exactly one of the three: {one} of {len(matched)} ({one / len(matched):.0%}); two or more: {len(matched) - one}")
print(f"2023 to 2026: {len(recent)} works, {r1} ({r1 / len(recent):.0%}) name exactly one tool")
print("works per tool:", ", ".join(f"{t}: {sum(1 for r in matched if t in r['tools_named'].split(';'))}" for t in ("Ahrefs", "Semrush", "Similarweb")))
print(f"distinct ids: {len(set(r['id'] for r in rows))}")
