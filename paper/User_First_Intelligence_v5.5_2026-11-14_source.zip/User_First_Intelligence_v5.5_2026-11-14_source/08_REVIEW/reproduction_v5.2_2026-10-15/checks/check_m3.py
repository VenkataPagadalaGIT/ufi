"""Reproducer's own check (not an author script): Section 7 and Appendix C numbers recomputed from the
bundle's shipped aggregates (ai_citation_cross_sector/aggregates) and design files only. Where a paper number
comes from a bootstrap, the resampling described in the paper is re-implemented here with the seed the author's
script uses, on the per-cell shares in the aggregates.
Usage: python3 -I check_m3.py <bundle dir>
"""
import csv
import json
import random
import statistics as st
import sys
from itertools import combinations
from pathlib import Path

B = Path(sys.argv[1])
AG = B / "ai_citation_cross_sector/aggregates"
DE = B / "ai_citation_cross_sector/design"
SECTORS = ["xlk", "xlv", "xlf", "xly", "xlc", "xli", "xlp", "xle", "xlu", "xlre", "xlb"]
NAME = {"xlk": "Information Technology", "xlv": "Health Care", "xlf": "Financials", "xly": "Consumer Discretionary",
        "xlc": "Communication Services", "xli": "Industrials", "xlp": "Consumer Staples", "xle": "Energy",
        "xlu": "Utilities", "xlre": "Real Estate", "xlb": "Materials"}
GOOGLE = ["aio_searchqueries", "aio_prompts", "aimode_searchqueries", "aimode_prompts"]
CHAT = ["chatgpt", "perplexity", "gemini", "copilot"]
SURF = GOOGLE + CHAT
med = st.median
pct = lambda x: f"{x:.1%}"

print("== Design and answer counts")
comp = list(csv.DictReader((DE / "cross_sector_companies.csv").open()))
props = list(csv.DictReader((DE / "cross_sector_company_properties.csv").open()))
print(f"  company rows {len(comp)}; per sector {dict((s, sum(r['etf'].lower() == s for r in comp)) for s in SECTORS)}")
print(f"  company-property rows {len(props)}")
cnt = {r["etf"]: int(r["ai_responses_us_all_platforms"]) for r in csv.DictReader((AG / "sector_answer_counts.csv").open())}
lo, hi = min(cnt, key=cnt.get), max(cnt, key=cnt.get)
print(f"  answer records summed {sum(cnt.values()):,}; min {cnt[lo]:,} ({NAME[lo]}); max {cnt[hi]:,} ({NAME[hi]})")

PM = {}
RTX = {}
for r in csv.DictReader((AG / "cross_sector_platform_metrics.csv").open()):
    if r["etf"] == "xli_rtxcorp":
        RTX[r["surface"]] = r
    else:
        PM[(r["etf"], r["surface"])] = r
print(f"  platform_metrics rows: {len(PM)} sector cells + {len(RTX)} RTX re-run cells")
sh = {k: float(v["share_community_video"]) for k, v in PM.items()}
ytr = {k: (int(v["yt_rank_nonbrand"]) if v["yt_rank_nonbrand"] else None) for k, v in PM.items()}
rdr = {k: (int(v["reddit_rank_nonbrand"]) if v["reddit_rank_nonbrand"] else None) for k, v in PM.items()}
yts = {k: float(v["yt_share"]) for k, v in PM.items()}

print("\n== Section 7.3 headline (video and community share)")
g = [sh[(s, p)] for s in SECTORS for p in GOOGLE]
c = [sh[(s, p)] for s in SECTORS for p in CHAT]
print(f"  Google median {pct(med(g))} (range {pct(min(g))} to {pct(max(g))}); other four median {pct(med(c))} (range {pct(min(c))} to {pct(max(c))})")
print("  per surface medians: " + "; ".join(f"{p} {pct(med([sh[(s, p)] for s in SECTORS]))}" for p in SURF))
every = sum(min(sh[(s, p)] for p in GOOGLE) > max(sh[(s, p)] for p in CHAT) for s in SECTORS)
print(f"  lowest Google view above highest other surface: {every}/11 sectors")
mp = [sh[(s, p)] for s in SECTORS for p in ("aio_prompts", "aimode_prompts")]
print(f"  Google prompt views only: median {pct(med(mp))}")
yt3g = sum((ytr[(s, p)] or 9999) <= 3 for s in SECTORS for p in GOOGLE)
yt3c = sum((ytr[(s, p)] or 9999) <= 3 for s in SECTORS for p in CHAT)
print(f"  YouTube in non-company top 3: Google cells {yt3g}/44; other cells {yt3c}/44")
print("  YouTube median non-company rank (not cited = 9999): " + "; ".join(f"{p} {med([ytr[(s, p)] or 9999 for s in SECTORS])}" for p in SURF))
ny = {k: sh[k] - yts[k] for k in sh}
g2 = [ny[(s, p)] for s in SECTORS for p in GOOGLE]
c2 = [ny[(s, p)] for s in SECTORS for p in CHAT]
every2 = sum(min(ny[(s, p)] for p in GOOGLE) > max(ny[(s, p)] for p in CHAT) for s in SECTORS)
print(f"  without YouTube: Google median {pct(med(g2))}, other four {pct(med(c2))}; lowest Google above highest other in {every2}/11")
rnd = random.Random(20261013)
bg, bc = [], []
for _ in range(10000):
    ss = [rnd.choice(SECTORS) for _ in SECTORS]
    bg.append(med([sh[(s, p)] for s in ss for p in GOOGLE]))
    bc.append(med([sh[(s, p)] for s in ss for p in CHAT]))
bg.sort(); bc.sort()
print(f"  bootstrap over sectors (seed 20261013, 10,000): Google {pct(bg[249])} to {pct(bg[9749])}; other four {pct(bc[249])} to {pct(bc[9749])}")

print("\n== Source types (cross_sector_type_shares.csv)")
TS = {}
for r in csv.DictReader((AG / "cross_sector_type_shares.csv").open()):
    t = {k: float(v) for k, v in r.items() if k.startswith("share_")}
    t["share_video_community"] = t["share_video"] + t["share_forum"] + t["share_social"] + t["share_user_publishing"]
    TS[(r["etf"], r["surface"])] = t
mx = max(abs(TS[k]["share_video_community"] - sh[k]) for k in sh)
print(f"  type_shares video+community vs platform_metrics share_community_video: max abs difference {mx:.2e}")
for k in ("share_reference", "share_forum", "share_report_brands", "share_other_web"):
    print(f"  {k[6:]}: Google pooled median {pct(med([TS[(s, p)][k] for s in SECTORS for p in GOOGLE]))}; "
          f"other four pooled median {pct(med([TS[(s, p)][k] for s in SECTORS for p in CHAT]))}; Copilot median {pct(med([TS[(s, 'copilot')][k] for s in SECTORS]))}")
KEYS = ["share_video_community", "share_video", "share_forum", "share_social", "share_reference", "share_news",
        "share_government", "share_report_brands", "share_other_web"]
for k in KEYS:
    v = {(s, p): TS[(s, p)][k] for s in SECTORS for p in SURF}
    gm = st.mean(v.values())
    tot = sum((x - gm) ** 2 for x in v.values())
    ssp = len(SECTORS) * sum((st.mean(v[(s, p)] for s in SECTORS) - gm) ** 2 for p in SURF)
    sss = len(SURF) * sum((st.mean(v[(s, p)] for p in SURF) - gm) ** 2 for s in SECTORS)
    print(f"  variance {k[6:]:18s} surface {ssp / tot:5.0%}  sector {sss / tot:5.0%}")
rng = random.Random(20261015)
for k in ("share_video_community", "share_news"):
    surf, sect = [], []
    for _ in range(10_000):
        S_ = [rng.choice(SECTORS) for _ in SECTORS]
        v = {(i, p): TS[(s, p)][k] for i, s in enumerate(S_) for p in SURF}
        gm = st.mean(v.values())
        tot = sum((x - gm) ** 2 for x in v.values())
        if tot == 0:
            continue
        surf.append(len(S_) * sum((st.mean(v[(i, p)] for i in range(len(S_))) - gm) ** 2 for p in SURF) / tot)
        sect.append(len(SURF) * sum((st.mean(v[(i, p)] for p in SURF) - gm) ** 2 for i in range(len(S_))) / tot)
    surf.sort(); sect.sort(); n = len(surf)
    print(f"  bootstrap (seed 20261015) {k[6:]:18s} surface [{surf[int(0.025 * n)]:.0%}, {surf[int(0.975 * n) - 1]:.0%}]  sector [{sect[int(0.025 * n)]:.0%}, {sect[int(0.975 * n) - 1]:.0%}]")

print("\n== Table C1 recomputed (median (min-max) over 11 sectors)")
C1 = {}
for p in SURF:
    row = []
    for k in ("share_video_community", "share_reference", "share_news", "share_government", "share_report_brands", "share_other_web"):
        xs = [TS[(s, p)][k] for s in SECTORS]
        row.append(f"{med(xs) * 100:.1f}% ({min(xs) * 100:.1f}–{max(xs) * 100:.1f})")
    C1[p] = row
    print(f"  {p:22s} " + " | ".join(row))

print("\n== Table C2 recomputed (cited_in_sum / 1000) and cell sizes (cross_sector_cells.csv)")
CE = {(r["etf"], r["surface"]): r for r in csv.DictReader((AG / "cross_sector_cells.csv").open())}
C2 = {}
for s in SECTORS:
    C2[s] = [f"{int(CE[(s, p)]['cited_in_sum']) / 1000:,.1f}" for p in SURF]
    print(f"  {NAME[s]:24s} " + " ".join(C2[s]))
sz = [int(r["cited_in_sum"]) for r in CE.values()]
rd = [int(r["registrable_domains"]) for r in CE.values()]
print(f"  cell sizes {min(sz):,} to {max(sz):,}; registrable domains per cell {min(rd)} to {max(rd)}")
ms = {p: med([float(CE[(s, p)]["mass_rows_501_1000"]) for s in SECTORS]) for p in SURF}
print("  median mass in rows 501-1000: " + "; ".join(f"{p} {pct(v)}" for p, v in ms.items()) + f"; range {pct(min(ms.values()))} to {pct(max(ms.values()))}")
pmsz = max(abs(int(PM[k]["cited_in_sum"]) - int(CE[k]["cited_in_sum"])) for k in PM)
print(f"  platform_metrics vs cells cited_in_sum: max abs difference {pmsz}")

print("\n== Predictions P1 to P4 from platform_metrics")
p1v = {p: sum(ytr[(s, p)] == 1 for s in SECTORS) for p in GOOGLE}
p1b = sum(any(ytr[(s, p)] == 1 for p in GOOGLE[:2]) and any(ytr[(s, p)] == 1 for p in GOOGLE[2:]) for s in SECTORS)
print(f"  P1 per view {p1v}; both products {p1b}/11")
p2 = {p: sum((ytr[(s, p)] or 9999) > 5 for s in SECTORS) for p in ("chatgpt", "perplexity", "copilot")}
print(f"  P2 {p2}")
hold = [s for s in SECTORS if all((rdr[(s, p)] or 9999) <= 10 for p in SURF if p != "copilot")]
fails = {s: [p for p in SURF if p != "copilot" and (rdr[(s, p)] or 9999) > 10] for s in SECTORS if s not in hold}
print(f"  P3 holds in {len(hold)}/11 {hold}; ChatGPT failing in {sum('chatgpt' in v for v in fails.values())} of {len(fails)} non-holding sectors")
CONS, NONC = ["xly", "xlp", "xlc", "xlv", "xlk"], ["xle", "xlb", "xlu", "xlre", "xli"]


def exact_p(a, b):
    pooled, obs = a + b, st.mean(a) - st.mean(b)
    hits = tot = 0
    for idx in combinations(range(len(pooled)), len(a)):
        s_ = set(idx)
        x = [pooled[i] for i in idx]
        y = [pooled[i] for i in range(len(pooled)) if i not in s_]
        tot += 1
        hits += (st.mean(x) - st.mean(y)) >= obs - 1e-12
    return hits / tot


for p in ("aio_searchqueries", "aio_prompts"):
    a = [sh[(s, p)] for s in CONS]; b = [sh[(s, p)] for s in NONC]
    print(f"  P4 {p}: consumer {pct(st.mean(a))} vs other {pct(st.mean(b))}; exact one-sided p {exact_p(a, b):.3f}")

print("\n== Without Industrials (10 sectors) and the RTX re-run (platform_metrics)")
xi = [s for s in SECTORS if s != "xli"]
print(f"  ChatGPT median without Industrials {pct(med([sh[(s, 'chatgpt')] for s in xi]))}; "
      f"P2 {dict((p, sum((ytr[(s, p)] or 9999) > 5 for s in xi)) for p in ('chatgpt', 'perplexity', 'copilot'))}; "
      f"P3 {sum(all((rdr[(s, p)] or 9999) <= 10 for p in SURF if p != 'copilot') for s in xi)}/10")
for p, r in RTX.items():
    o = PM[("xli", p)]
    print(f"  RTX {p:22s} comm+video {pct(float(o['share_community_video']))} -> {pct(float(r['share_community_video']))}; "
          f"YouTube rank {o['yt_rank_nonbrand']} -> {r['yt_rank_nonbrand']}; top {o['top1_nonbrand']} -> {r['top1_nonbrand']}")

print("\n== Top-10 non-company file: Jaccard and P1 with google.com set aside")
T10 = {}
for r in csv.DictReader((AG / "cross_sector_top10_nonbrand.csv").open()):
    T10.setdefault((r["etf"], r["surface"]), []).append((int(r["rank"]), r["domain"]))
T10 = {k: [d for _, d in sorted(v)] for k, v in T10.items()}
jac = {p: st.mean(len(set(T10[(a, p)]) & set(T10[(b, p)])) / len(set(T10[(a, p)]) | set(T10[(b, p)]))
                  for a, b in combinations(SECTORS, 2)) for p in SURF}
print("  Jaccard: " + "; ".join(f"{p} {v:.2f}" for p, v in jac.items()))
pj = json.loads((AG / "cross_sector_predictions.json").read_text())["exploratory_top10_jaccard"]
print(f"  max abs difference from predictions.json: {max(abs(jac[p] - pj[p]) for p in SURF):.2e}")
ng = {(s, p): ([d for d in T10[(s, p)] if d != "google.com"].index("youtube.com") + 1
               if "youtube.com" in T10[(s, p)] else None) for s in SECTORS for p in GOOGLE}
print(f"  P1 with google.com set aside: per view {dict((p, sum(ng[(s, p)] == 1 for s in SECTORS)) for p in GOOGLE)}; "
      f"both products {sum(any(ng[(s, p)] == 1 for p in GOOGLE[:2]) and any(ng[(s, p)] == 1 for p in GOOGLE[2:]) for s in SECTORS)}")
top1 = {(s, p): T10[(s, p)][0] for s in SECTORS for p in SURF}
agree = sum(top1[(s, p)] == PM[(s, p)]["top1_nonbrand"] for s in SECTORS for p in SURF)
print(f"  top-10 file rank 1 equals platform_metrics top1_nonbrand in {agree}/88 cells")
