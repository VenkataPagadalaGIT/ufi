"""Reproducer's own check (not an author script): Table 4 and the Section 5.5/5.6 numbers that no
released script prints, recomputed from the bundle's data CSVs and Table 2 as printed in the manuscript.
Usage: python3 -I check_m1.py <bundle dir>
"""
import csv
import math
import sys
from pathlib import Path

B = Path(sys.argv[1])
A = {r["prefix"]: r for r in csv.DictReader((B / "data/ahrefs_prefixes_2026-10-12.csv").open())}
S = {r["prefix"]: r for r in csv.DictReader((B / "data/semrush_prefixes_2026-10-12.csv").open())}

# Table 4 as printed in the manuscript
ms = (B / "manuscript_v50.md").read_text()
i = ms.index("| Prefix | Age (mo) |")
lines = [ln for ln in ms[i:].split("\n\n")[0].splitlines() if ln.startswith("| /")]
T4 = {}
for ln in lines:
    c = [x.strip().replace("**", "") for x in ln.strip("|").split("|")]
    T4[c[0]] = c

def f(x):
    return float(x.replace(",", "").replace("%", ""))

print("== Table 4: each printed cell against the data files (computed value in brackets when different)")
bad = 0
rows = []
for p in A:
    a, s = A[p], S[p]
    y, m = map(int, a["ahrefs_first_traffic_month"].split("-"))
    age = (2026 - y) * 12 + (10 - m)
    at, st = float(a["ahrefs_organic_traffic"]), float(s["semrush_organic_traffic_us"])
    us = float(a["ahrefs_us_share"])
    ak, sk = float(a["ahrefs_organic_keywords"]), float(s["semrush_organic_keywords_us"])
    ar, sr = float(a["ahrefs_ref_domains"]), float(s["semrush_ref_domains"])
    comp = [p, f"{age}", f"{at:,.0f}", f"{st:,.0f}", f"{st/at:.2f}", f"{us*100:.1f}%", f"{st/(at*us):.2f}",
            f"{ak:,.0f}", f"{sk:,.0f}", f"{sk/ak:.1f}", f"{ar:,.0f}", f"{sr:,.0f}", f"{ar/sr:.1f}"]
    printed = T4[p]
    diffs = [(k, printed[k], comp[k]) for k in range(1, 13) if printed[k] != comp[k]]
    bad += len(diffs)
    print(f"  {p:22s} {'all 12 cells match' if not diffs else diffs}")
    rows.append(dict(p=p, age=age, vr=st / at, vm=st / (at * us), kr=sk / ak, rd=ar / sr, us=us))
print(f"  cells differing: {bad}")

print("\n== Section 5.5 statements no script prints")
old = [r for r in rows if 84 <= r["age"] <= 144]
print(f"  sections aged 7 to 12 years: {len(old)}; ages {sorted(r['age'] for r in old)}; "
      f"unmatched {min(r['vr'] for r in old):.2f}x to {max(r['vr'] for r in old):.2f}x; "
      f"matched {min(r['vm'] for r in old):.2f}x to {max(r['vm'] for r in old):.2f}x")
print(f"  prefixes under 21 months: {[r['p'] for r in rows if r['age'] < 21]}")
for p in ("/product-compare/", "/device-compare/", "/es-us/local/"):
    r = next(x for x in rows if x["p"] == p)
    print(f"  {p}: US share {r['us']:.1%}; unmatched {r['vr']:.2f}x -> matched {r['vm']:.2f}x")
kr = sorted(rows, key=lambda r: -r["kr"])
print(f"  keyword ratio ranking: first {kr[0]['p']} {kr[0]['kr']:.1f}x, second {kr[1]['p']} {kr[1]['kr']:.1f}x")
rd = sorted(rows, key=lambda r: -r["rd"])
print(f"  referring-domain ratio: highest {rd[0]['p']} {rd[0]['rd']:.1f}x, next {rd[1]['p']} {rd[1]['rd']:.1f}x")
vm = sorted(rows, key=lambda r: -r["vm"])
print(f"  matched ratio: highest {vm[0]['p']} {vm[0]['vm']:.2f}x")
z = math.atanh(0.5)
print(f"  power for rho = 0.5, n = 12, Fisher z approximation: {0.5 * math.erfc(-(z * 3 - 1.959964) / math.sqrt(2)):.3f}")

print("\n== Section 5.1 and 5.6 arithmetic on Table 2 (values from the manuscript's Table 2)")
T2 = {"Jul": (3862, 100012, 103045), "Aug": (32281, 876153, 963937), "Sep": (150113, 1534362, 1765077),
      "Oct": (215577, 1610284, 1858297)}
for k, (a_, u, w) in T2.items():
    print(f"  {k}: US/ww {u/a_:.2f}x; ww/ww {w/a_:.2f}x; US/US (81.5%) {u/(a_*0.815):.2f}x")
r = 876153 / 32281
print(f"  August ratio {r:.2f}; sqrt {math.sqrt(r):.2f}; larger error at least (ratio - 1)/2 = {(r - 1) / 2:.1f} times the smaller reading")
