"""Reproducer's own arithmetic check of Table 3 (Appendix D: 'arithmetic on Table 3')."""
import math
z = 1.96
for m, k, n, b in (("Jul", 47, 284, 138), ("Aug", 851, 6749, 2221), ("Sep", 3380, 22665, 8187), ("Oct", 7455, 37238, 10018)):
    p = k / n
    c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    print(f"{m}: {k}/{n} = {p:.1%} [{(c-h)*100:.1f}, {(c+h)*100:.1f}]; (b)/(a) {b/k:.2f}x")
