| # | Location | Quoted in the paper | Script that prints it | What I obtained | Status | Basis | Note |
|---|---|---|---|---|---|---|---|
| 1 | 5.1, para 3 | growth Jul to Aug: 8.4x Ahrefs, 8.8x Semrush US | instrument_extra | 8.36x, 8.76x | MATCH | S |  |
| 2 | 5.1, para 3 | growth Aug to Sep: 4.65x against 1.75x | instrument_extra | 4.65x, 1.75x | MATCH | S |  |
| 3 | 5.1, para 3 | growth Sep to Oct run-rate: 1.44x against 1.05x | instrument_extra | 1.44x, 1.05x | MATCH | S |  |
| 4 | 5.1, para 3 | lift differs by a factor of more than two | instrument_extra | 2.66 | MATCH | S |  |
| 5 | 5.5, Table 4 | 144 numeric cells (12 prefixes x 12 columns) | none prints the table; data/*.csv | all 144 equal the values computed from the two CSVs | MATCH | R | ratio columns are arithmetic, not script output |
| 6 | 5.5, para 1 | Spearman(age, unmatched ratio) −0.11 | analyze | -0.11 | MATCH | S |  |
| 7 | 5.5, para 1 | Fisher 95% interval −0.64 to +0.49 | analyze | [-0.64, +0.49] | MATCH | S |  |
| 8 | 5.5, para 1 | permutation p 0.73 | analyze | 0.73 | MATCH | S |  |
| 9 | 5.5, para 1 | territory-matched −0.28 | analyze | -0.28 | MATCH | S |  |
| 10 | 5.5, para 1 | excluding the area-code section +0.15 | analyze | +0.15 (n = 11) | MATCH | S |  |
| 11 | 5.5, para 1 | roughly 38% power for rho = 0.5 | analyze | 'roughly 38%' | MATCH | S | fixed string in analyze.py, not computed; Fisher-z approximation gives 37.8% |
| 12 | 5.5, para 1 | seven sections aged 7 to 11 years: 0.25x to 6.57x unmatched | none (paper attributes to analyze) | 7 sections, 93 to 133 months, 0.25x to 6.57x | MATCH | R | not printed by any script |
| 13 | 5.5, para 1 | same seven: 0.46x to 6.61x matched | none | 0.46x to 6.61x | MATCH | R | not printed by any script |
| 14 | 5.5, para 1 | only one prefix under twenty-one months | none | 1 (/local/area-codes/, 3 months) | MATCH | R | not printed by any script |
| 15 | 5.5, para 2 | 0.20x (/local/bundles/) to 7.24x (/local/area-codes/) | analyze | min 0.20x, max 7.24x, same prefixes | MATCH | S |  |
| 16 | 5.5, para 2 | spread 1.55 orders of magnitude | analyze | 1.55 decades | MATCH | S |  |
| 17 | 5.5, para 2 | median 1.01; six of twelve below one | analyze | 1.01; 6 of 12 | MATCH | S |  |
| 18 | 5.5, para 2 | matched 0.20x to 8.89x, median 1.06, four of twelve below one | analyze | 0.20x, 8.89x, 1.06, 4 of 12 | MATCH | S |  |
| 19 | 5.5, para 2 | /product-compare/ 69.6% US, 0.75x to 1.07x | none (analyze prints 70%) | 69.6%, 0.75x, 1.07x | MATCH | R | not printed by any script |
| 20 | 5.5, para 2 | /device-compare/ 82.6% US, 0.99x to 1.20x | none (analyze prints 83%) | 82.6%, 0.99x, 1.20x | MATCH | R | not printed by any script |
| 21 | 5.5, para 2 | /es-us/local/ 42.6% US, 0.25x to 0.58x | none (analyze prints 43%) | 42.6%, 0.25x, 0.58x | MATCH | R | not printed by any script |
| 22 | 5.5, para 2 | geometric mean 1.13, bootstrap 0.62 to 2.12 | instrument_extra | 1.13x [0.62x, 2.12x] | MATCH | S |  |
| 23 | 5.5, para 2 | geometric SD 3.1 (1.9 to 4.1) | instrument_extra | 3.13 [1.92, 4.14] | MATCH | S |  |
| 24 | 5.5, para 2 | normal range about 0.12x to 10.6x | instrument_extra | 0.12x to 10.61x | MATCH | S |  |
| 25 | 5.5, para 3 | ordering Spearman +0.94 | analyze, instrument_extra | +0.94 (+0.937) | MATCH | S |  |
| 26 | 5.5, para 3 | bootstrap interval +0.70 to +1.00; p < 0.001 | instrument_extra | [+0.70, +1.00]; p = 7e-06 | MATCH | S |  |
| 27 | 5.5, para 3 | Kendall +0.82, interval +0.57 to +1.00 | analyze, instrument_extra | +0.82 [+0.57, +1.00] | MATCH | S |  |
| 28 | 5.5, para 3 | 60 of 66 pairs concordant | analyze | 60 of 66 | MATCH | S |  |
| 29 | 5.5, para 3 | all 51 pairs more than 3x apart ordered alike | instrument_extra | 19 of 19 plus 32 of 32 | MATCH | S | 51 is the sum of two printed lines |
| 30 | 5.5, para 3 | 9 of the 15 pairs within 3x | instrument_extra | 9 of 15 | MATCH | S |  |
| 31 | 5.5, para 4 | keyword ratio 2.0x to 20.9x, above one everywhere | analyze | 2.0x, 20.9x, all above one | MATCH | S |  |
| 32 | 5.5, para 4 | rho(keyword ratio, visits ratio) +0.17; +0.52 without area-codes | analyze | +0.17; +0.52 | MATCH | S |  |
| 33 | 5.5, para 4 | /local/bundles/ second-largest keyword ratio, 16.1x | none | 16.1x, second to /stores/ 20.9x | MATCH | R | not printed by any script |
| 34 | 5.5, para 5 | highest ratio 7.24x (8.89x matched); /stores/ next at 6.57x | analyze | max 7.24x, second 6.57x (/stores/), matched max 8.89x | MATCH | S | that the matched maximum is area-codes is not printed (R) |
| 35 | 5.5, para 5 | highest referring-domain ratio, 11.3x | none | 11.3x (next 4.6x) | MATCH | R | not printed by any script |
| 36 | 5.5, para 6 | 158.3K mentions, 29.5K cited pages (dashboard read) | none; single_reads_2026-10.csv | 158.3K, 29.5K in the released file | MATCH | R | a read, not a computation |
| 37 | 5.6, para 1 | factor of 5.2, square root of 27.1 | arithmetic on Table 2 | sqrt(27.14) = 5.21 | MATCH | R |  |
| 38 | 5.6, para 1 | larger error at least 13 times the smaller reading | arithmetic on Table 2 | (27.14 - 1)/2 = 13.07 | MATCH | R |  |
| 39 | 5.6, para 2 | 27.1 to 10.2 to 7.5 | arithmetic on Table 2 | 27.14, 10.22, 7.47 | MATCH | R |  |
| 40 | 5.6, para 3 | 7.47x = 2.02x x 3.70x | instrument_extra | same | MATCH | S |  |
| 41 | 5.6, para 3 | keyword universe about 35% (US pairing) | instrument_extra | 35% | MATCH | S |  |
| 42 | 5.6, para 3 | 8.62x = 3.19x x 2.70x | instrument_extra | same | MATCH | S |  |
| 43 | 5.6, para 3 | about 54% (worldwide pairing) | instrument_extra | 54% | MATCH | S |  |
| 44 | 5.6, para 4 | worldwide 8.62x (Oct); 26.7x to 29.9x (Jul, Aug) | arithmetic on Table 2 | 8.62, 26.68, 29.86 | MATCH | R |  |
| 45 | 5.6, para 4 | US to US 9.17x for October | arithmetic on Table 2 | 9.17 | MATCH | R |  |
| 46 | 5.6, para 4 | 31.8x, 33.3x and 12.5x | arithmetic on Table 2 | 31.77, 33.30, 12.54 | MATCH | R |  |
| 47 | 5.6, para 5 | 0.20x to 7.24x (0.20x to 8.89x matched) | analyze | same | MATCH | S |  |
| 48 | 5.6, para 5 | 60 of 66 pairs | analyze | 60 of 66 | MATCH | S |  |
| 49 | 5.6, para 5 | within a factor of three: 9 of 15 pairs | instrument_extra | 9 of 15 | MATCH | S |  |
| 50 | 5.6, para 5 | two pairs six to seven times apart ordered the other way | instrument_extra | 7.3x (area-codes vs internet, Semrush); 6.1x (stores vs support, Ahrefs) | MATCH | S | 7.3x described as seven |
| 51 | 5.6, para 5 | a factor of five below to nearly nine above | analyze | 0.20x; 8.89x | MATCH | S |  |
| 52 | 5.6, para 5 | growth differed by a factor of 2.7 in one month | instrument_extra | 2.66 | MATCH | S |  |
| 53 | 6, para 3 | 200 links judged | r2_link_check (inputs) | 200 judgments per annotator, same ids | MATCH | S |  |
| 54 | 6, para 3 | drawn uniformly from the 46,517 links | r2_link_sample | - | CANNOT RUN | - | needs Telecom_reviews_and_responses.xlsx and Telecom_classification.xlsx (licensed); r2_link_check prints 46,517 as a fixed string |
| 55 | 6, para 3 | 65% to 67% correct | r2_link_check | 65.0%, 65.5%, 66.8% | MATCH | S |  |
| 56 | 6, para 3 | Wilson 95% intervals about 58% to 73% | r2_link_check | 58.2% to 73.0% | MATCH | S |  |
| 57 | 6, para 3 | agreement 95.5%, Cohen's kappa 0.90 | r2_link_check | 95.5%; 0.90 (independent recomputation 0.902) | MATCH | S |  |
| 58 | 6, para 3 | single-word labels right about half the time | r2_link_check, section C | - | CANNOT RUN | - | needs 03_DATA/raw/r2_link_check/sample_A_links.csv (private, holds review text); shipped output 50.0%, 48.0% |
| 59 | 6, para 3 | multi-word labels 95% to 96% right | r2_link_check, section C | - | CANNOT RUN | - | same private file; shipped output 95.8%, 94.5% |
| 60 | 6, para 4 | 100 waiting matches judged | r2_link_check (inputs) | 100 judgments per annotator, same ids | MATCH | S |  |
| 61 | 6, para 4 | 83% to 85% are complaints about waiting | r2_link_check | 83.0%, 84.0%, 84.8% | MATCH | S |  |
| 62 | 6, para 4 | Cohen's kappa 0.93 | r2_link_check | 0.93 (independent recomputation 0.928) | MATCH | S |  |
| 63 | 6, para 4 | about nine in ten in the store | r2_link_check | 90.5%, 89.2% | MATCH | S |  |
| 64 | 6, para 4 | roughly 12% of one- and two-star reviews complain about a wait | r2_link_check | 11.9%, 11.6% | MATCH | S | uses 14.0% from analyze_reviews as a fixed input |
| 65 | 6, para 6 | links about two in three correct | r2_link_check | 65.0% to 66.8% | MATCH | S |  |
| 66 | 6, para 1 | 47,485 reviews, 379 locations; 37,193 with text at 378; 1 to 201 per location, median 145 | supplement_r10 | - | CANNOT RUN | - | licensed export withheld; shipped output agrees |
| 67 | 6, para 1 | owner responses name a carrier at 26 locations, five carriers | supplement_r10 | - | CANNOT RUN | - | also needs private 03_DATA/private/carrier_name_patterns.txt; shipped output agrees |
| 68 | 6, para 1 | 42,994-node taxonomy from 1,898,584 keywords | supplement_r10 | - | CANNOT RUN | - | needs Telecom_classification.xlsx, Telecom_keywords_full.csv.gz; shipped output agrees |
| 69 | 6, para 1 | 20,663 (55.6%) linked; 27,817 labels; 2.25 per linked review; 1,008 labels | analyze_reviews | - | CANNOT RUN | - | shipped output agrees |
| 70 | 6, para 2 | branch rho +0.75 (+0.44 to +0.90; p < 0.001), split | supplement_r10 | - | CANNOT RUN | - | shipped +0.748 [+0.443, +0.900], p 0.00056 |
| 71 | 6, para 2 | branch rho +0.47 (+0.01 to +0.78; p = 0.06), modal; earlier +0.78 | supplement_r10, analyze_reviews | - | CANNOT RUN | - | shipped +0.468 [+0.006, +0.783]; +0.777 |
| 72 | 6, para 2 | carriers 66.8% / 14.9%, devices 11.0% / 32.7%, broadband 4.0% / 18.1% | supplement_r10 | - | CANNOT RUN | - | shipped output agrees |
| 73 | 6, para 2 | label rho +0.19 (+0.12 to +0.25; tau +0.13); +0.27 (+0.26 to +0.29) over all linkable | analyze_reviews, supplement_r10 | - | CANNOT RUN | - | shipped output agrees; 26,809 = 27,817 - 1,008 is not printed |
| 74 | 6, para 2 | +0.28 over 213 labels; +0.16 (p = 0.10) over 106 complaint labels | analyze_reviews | - | CANNOT RUN | - | shipped output agrees |
| 75 | 6, para 2 | 367 (36.4%) under 1,000 searches; 106 (10.5%) none; own-volume +0.16 and +0.26 | analyze_reviews, supplement_r10 | - | CANNOT RUN | - | shipped output agrees |
| 76 | 6, para 3 | multi-word only: +0.91 (+0.74 to +0.98), +0.65, +0.24 (+0.16 to +0.33), carriers 56% / 15% | supplement_r10 | - | CANNOT RUN | - | shipped output agrees |
| 77 | 6, para 4 | 6,620 reviews; 924 (14.0%, 13.1% to 14.8%); five-star 1.9% (1.8% to 2.1%) | analyze_reviews, supplement_r10 | - | CANNOT RUN | - | shipped output agrees |
| 78 | 6, para 4 | 11 'wait' labels, 622 searches; mentioned one carries 12; 8 remedy labels, 13,170 searches; no check-in label | supplement_r10, analyze_reviews | - | CANNOT RUN | - | shipped outputs agree; the last line of analyze_reviews_output.txt is not what the shipped script prints |
| 79 | 7.2 | 109 companies (Communication Services 9) | cross_sector | 109 rows in design/cross_sector_companies.csv, xlc 9 | MATCH | R | cross_sector.py cannot run |
| 80 | 7.2 | 1,000 rows per export reduce to 760 to 975 registrable domains; 88 exports | cross_sector_sensitivity | 88 cells, 1,000 rows each, 760 to 975 | MATCH | R | from cross_sector_cells.csv |
| 81 | 7.2 | 20,389,967 answer records; 18,763 (Utilities) to 7,766,466 (Consumer Discretionary) | cross_sector | same | MATCH | R | sector_answer_counts.csv, SHA-1 equals the raw manifest entry |
| 82 | 7.3, para 1 | lowest Google view above highest other surface in every sector | cross_sector_sensitivity | 11 of 11 | MATCH | R |  |
| 83 | 7.3, para 1 | Google median 21.3% (range 8.1% to 35.8%) | cross_sector | same | MATCH | R |  |
| 84 | 7.3, para 1 | bootstrap over sectors 17.2% to 26.7% | cross_sector_sensitivity | same | MATCH | R | resampling re-implemented with the script's seed 20261013 on per-cell shares |
| 85 | 7.3, para 1 | other four 2.1% (range 0.3% to 16.7%) | cross_sector | same | MATCH | R |  |
| 86 | 7.3, para 1 | bootstrap 1.7% to 2.7% | cross_sector_sensitivity | same | MATCH | R | as above |
| 87 | 7.3, para 1 | Copilot 0.6%, ChatGPT 0.9%, Perplexity 4.6%, Gemini 9.2% | cross_sector | same | MATCH | R |  |
| 88 | 7.3, para 1 | Google prompt views only: 24.6% | cross_sector_sensitivity | 24.6% | MATCH | R |  |
| 89 | 7.3, para 1 | YouTube top three in 38 of 44 Google cells, none of the 44 others | cross_sector | 38/44; 0/44 | MATCH | R |  |
| 90 | 7.3, para 1 | YouTube median rank 1, 2, 7, 7, 151, 161 | cross_sector | same | MATCH | R |  |
| 91 | 7.3, para 1 | without YouTube 12.7% and 1.6%; 7 of 11 sectors | cross_sector_sensitivity | same | MATCH | R | share minus yt_share |
| 92 | 7.3, para 2 | reference 2.7% (other four) against 3.2% (Google) | cross_sector_sensitivity | same | MATCH | R |  |
| 93 | 7.3, para 2 | forum 1.1% against 5.7% | cross_sector_sensitivity | same | MATCH | R |  |
| 94 | 7.3, para 2 | company domains median 14.1% on the other four | cross_sector_sensitivity | 14.1% | MATCH | R |  |
| 95 | 7.3, para 2 | other web 61% Google, 72% other four, 90% Copilot | cross_sector_sensitivity | 61.1%, 71.7%, 89.9% | MATCH | R |  |
| 96 | 7.3, para 2 | surface 77%, sector 14% of variance (video and community) | cross_sector_sensitivity2 | 77%, 14% | MATCH | L | section 1 printed before the script stops at the raw exports; also R |
| 97 | 7.3, para 2 | bootstrap 70% to 91% (surface), 5% to 20% (sector) | cross_sector_sensitivity2 | same | MATCH | R | unreachable in the script without raw exports; re-implemented with seed 20261015 |
| 98 | 7.3, para 2 | news 12% / 73%, government 26% / 49%, companies 40% / 45% | cross_sector_sensitivity2 | same | MATCH | L |  |
| 99 | 7.3, para 3 | ChatGPT's top non-company domain in each of the 11 sectors | make_tables_sector_surface | google, fda.gov, nerdwallet, justwatch, go, nvidia, reddit, sec.gov x3, benjaminmoore | MATCH | L |  |
| 100 | 7.3, para 3 | Jaccard 0.36 to 0.40 (Google) against 0.08 to 0.23 | cross_sector | same; equals predictions.json | MATCH | R |  |
| 101 | 7.3, para 3 | P4 with company properties 22.5% against 24.2%; p = 0.23 to 0.63 | cross_sector_sensitivity2 | - | CANNOT RUN | - | needs raw exports; shipped output agrees |
| 102 | 7.3, para 3 | largest company: Sherwin-Williams 94%, Amazon 75%, Walmart 65%, Apple 62%, Uber 55% | cross_sector_sensitivity | - | CANNOT RUN | - | needs the all-surface raw exports; shipped 93.9, 75.4, 65.4, 62.2, 54.8 |
| 103 | 7.3, para 3 | go.com, chase.com, mobil.com among ChatGPT's top three | make_tables_sector_surface | in Table C4 output | MATCH | L |  |
| 104 | 7.4 | P1: 9 and 8 of 11 on AI Overviews, 2 of 11 on each AI Mode view | cross_sector | same | MATCH | R |  |
| 105 | 7.4 | www.google.com median 93% and 98% of google.com | cross_sector_sensitivity2 | - | CANNOT RUN | - | needs raw exports; shipped output agrees |
| 106 | 7.4 | P1 would hold (9 of 11) with google.com set aside | cross_sector_sensitivity | 9 | MATCH | R | from the shipped top-10 file |
| 107 | 7.4 | P2 held 11, 6 and 11 of 11 | cross_sector | same | MATCH | R |  |
| 108 | 7.4 | P3 held in 3 of 11; ChatGPT failing in all eight others | cross_sector | 3; 8 of 8 | MATCH | R |  |
| 109 | 7.4 | P4 26.9% / 24.2% (search queries), 29.6% / 24.4% (prompts) | cross_sector | same | MATCH | R |  |
| 110 | 7.4 | exact one-sided p 0.27 and 0.21 | cross_sector | 0.274, 0.210 | MATCH | R | all 252 splits enumerated |
| 111 | 7.5 | 'Found in': 21.5%, 3.3%, 11 of 11 | cross_sector_sensitivity | - | CANNOT RUN | - | needs raw exports; shipped output agrees |
| 112 | 7.5 | largest single host: 22.0%, 2.4%, 11 of 11 | cross_sector_sensitivity | - | CANNOT RUN | - | needs raw exports; shipped output agrees |
| 113 | 7.5 | 64 company properties | design/cross_sector_company_properties.csv | 64 rows | MATCH | R |  |
| 114 | 7.5 | company properties as company: 19.8%, 2.1%, 10 of 11 | cross_sector_sensitivity | - | CANNOT RUN | - | needs raw exports; shipped output agrees |
| 115 | 7.5 | Communication Services Google views 20.2% to 32.4% before reassignment | cross_sector_sensitivity | 31.9, 32.4, 20.2, 25.8 | MATCH | R |  |
| 116 | 7.5 | after reassignment 5.9% to 12.7%; Gemini 9.2% above AI Mode search | cross_sector_sensitivity | - | CANNOT RUN | - | needs raw exports; shipped output agrees |
| 117 | 7.5 | first 100, 250, 500 rows: 30.6%, 26.3%, 23.3% against 3.0%, 2.6%, 2.3% | cross_sector_sensitivity | - | CANNOT RUN | - | needs raw exports; shipped output agrees |
| 118 | 7.5 | ranks 501 to 1,000 carry a median 7.6% to 13.8% | cross_sector_sensitivity | 7.6% to 13.8% | MATCH | R | from cross_sector_cells.csv |
| 119 | 7.6 | RTX: 31.3% to 30.1% (AIO search); YouTube rank 1 to 1 (AIO), 2 to 1 (AI Mode prompts) | cross_sector | same | MATCH | R | RTX rows in platform_metrics |
| 120 | 7.6 | Perplexity 6.2% to 5.5%; Gemini 15.0% to 13.4%; Copilot top amazon.com to a flight-route site | cross_sector | same (flightconnections.com) | MATCH | R |  |
| 121 | 7.6 | without Industrials: ChatGPT 0.8%; P2 10/10, 10/10, 6/10; P3 3 of 10 | cross_sector_sensitivity, sensitivity2 | same | MATCH | R |  |
| 122 | 7.6 | 'Visa': immigration domains up to 2.2% of a Financials surface | cross_sector_sensitivity | - | CANNOT RUN | - | needs raw exports; shipped output agrees |
| 123 | 7.6 | cells range from 860 to 18,381,848 incidences | cross_sector_sensitivity | same | MATCH | R |  |
| 124 | 7.6, last para | about ten times the other four's pooled median; more than twice Gemini's | arithmetic | 21.3/2.1 = 10.1; 21.3/9.2 = 2.3 | MATCH | R |  |
| 125 | 7.1 | pilot: YouTube 1st on 4 Google views, 28th, 4th, 5th, 9th; reddit top three except Copilot (240th) | cross_sector_sensitivity (pilot section) | - | CANNOT RUN | - | pilot exports and brand set withheld; the released script omits this section, which only the shipped output contains |
| 126 | App. C, Table C1 | 48 cells (8 surfaces x 6 types, median and range) | cross_sector_sensitivity2 | all 48 equal my recomputation from cross_sector_type_shares.csv and the shipped output | MATCH | R | the script reaches these lines only after raw-export sections |
| 127 | App. C, Table C2 | 88 cell sizes | cross_sector_sensitivity2 | all 88 equal my recomputation from cross_sector_cells.csv and the shipped output | MATCH | R | as above |
| 128 | App. C, Table C3 | 88 cells | make_tables_sector_surface | 88 of 88 identical | MATCH | L |  |
| 129 | App. C, Table C4 | 22 cells (66 domains) | make_tables_sector_surface | 22 of 22 identical | MATCH | L |  |
| 130 | App. C, text | top source youtube.com or google.com in 38 of 44 Google cells | make_tables_sector_surface | 38 of 44 | MATCH | L |  |
| 131 | App. C, text | four of them Alphabet properties in Communication Services | make_tables_sector_surface | 4 marked Google cells in that row | MATCH | L |  |
| 132 | App. C, text | Perplexity and Gemini: wikipedia.org or reddit.com in 15 of 22 | make_tables_sector_surface | 15 of 22 | MATCH | L |  |
| 133 | App. C, text | ChatGPT: a government domain in 4 of 11 | make_tables_sector_surface | 4 of 11 | MATCH | L |  |
| 134 | App. C, text | Copilot: walmart.com or amazon.com in 6 of 11 | make_tables_sector_surface | 6 of 11 | MATCH | L |  |
| 135 | App. D, Stakes | 459; 86% | vendor_reliance | - | CANNOT RUN | - | reads the live OpenAlex API; shipped output agrees with the shipped CSV, but that CSV repeats 3 works (456 and 85.7% without them) |
| 136 | App. D, M1 visits ratio | 7.5x to 27.1x; 8.6x to 29.9x; 9.2x to 33.3x | arithmetic on Table 2 | 7.47 to 27.14; 8.62 to 29.86; 9.17 to 33.30 | MATCH | R |  |
| 137 | App. D, M1 growth | 0.95, 2.66, 1.37 | instrument_extra | same | MATCH | S |  |
| 138 | App. D, M1 error bound | 5.2 at 27.1x | arithmetic on Table 2 | 5.21 | MATCH | R |  |
| 139 | App. D, M1 decomposition | 35%, 54% | instrument_extra | same | MATCH | S |  |
| 140 | App. D, M1 cross-section | 0.20x to 7.24x (8.89x matched); median 1.01 | analyze | same | MATCH | S |  |
| 141 | App. D, M1 age | −0.11 [−0.64, +0.49], p = 0.73 | analyze | same | MATCH | S |  |
| 142 | App. D, M1 ordering | +0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within | analyze, instrument_extra | same | MATCH | S |  |
| 143 | App. D, M1 dispersion | 1.13 and 3.1 | instrument_extra | 1.13, 3.13 | MATCH | S |  |
| 144 | App. D, M1 AI Overview | 12.6% to 20.0% | arithmetic on Table 3 | 12.6% to 20.0%; Table 3 intervals and ratios also recomputed | MATCH | R |  |
| 145 | App. D, M2 link rate | 55.6%; 2.25 | analyze_reviews | - | CANNOT RUN | - | licensed export; shipped output agrees |
| 146 | App. D, M2 label agreement | +0.19, +0.27 | analyze_reviews, supplement_r10 | - | CANNOT RUN | - | shipped output agrees |
| 147 | App. D, M2 branch agreement | +0.47, +0.75 | supplement_r10 | - | CANNOT RUN | - | shipped output agrees |
| 148 | App. D, M2 complaint rate | 14.0% against 1.9% | analyze_reviews | - | CANNOT RUN | - | shipped output agrees |
| 149 | App. D, M2 link precision | 65% to 67%; kappa 0.90 | r2_link_check | same | MATCH | S |  |
| 150 | App. D, M2 link precision | single-word about 50%, multi-word 95% to 96% | r2_link_check, section C | - | CANNOT RUN | - | private sample file; shipped output agrees |
| 151 | App. D, M2 waiting precision | 83% to 85%, kappa 0.93; about 90% in store | r2_link_check | same | MATCH | S |  |
| 152 | App. D, M3 source-type share | Table C1 | cross_sector, sensitivity2 | see Table C1 row | MATCH | R |  |
| 153 | App. D, M3 surface contrast | 21.3% (17.2 to 26.7) against 2.1% (1.7 to 2.7) | cross_sector_sensitivity | same | MATCH | R |  |
| 154 | App. D, M3 dominance | 11 of 11 | cross_sector_sensitivity | 11 of 11 | MATCH | R |  |
| 155 | App. D, M3 overlap | 0.36 to 0.40 against 0.08 to 0.23 | cross_sector | same | MATCH | R |  |
| 156 | App. D, M3 variance | 77% against 14% | cross_sector_sensitivity2 | same | MATCH | L |  |
| 157 | App. D, M3 predictions | one held, one in direction, two failed | cross_sector | P2 held, P4 direction only, P1 and P3 failed | MATCH | R |  |
| 158 | App. D, schema pass rate | 4/5 | ufi cq | - | CANNOT RUN | - | released example (examples/nanp ontology and graph) is in neither the bundle nor the installed ufi 0.2.0; rdflib not installed |
| 159 | App. D, instance coverage | 70.4% | ufi cq | - | CANNOT RUN | - | as above |
| 160 | Abstract | 7.5x to 27.1x; 8.6x to 29.9x | arithmetic on Table 2 | as Table 2 | MATCH | R |  |
| 161 | Abstract | 0.20x to 7.24x; Spearman −0.11; 60 of 66 pairs | analyze | same | MATCH | S |  |
| 162 | Abstract | links about two-thirds correct | r2_link_check | 65.0% to 66.8% | MATCH | S |  |
| 163 | Abstract | +0.47 to +0.75 (branches); +0.19 (topics) | supplement_r10, analyze_reviews | - | CANNOT RUN | - | shipped output agrees |
| 164 | Abstract | prediction tally; median 21% against 0.6% to 9.2%; every sector | cross_sector, sensitivity | same | MATCH | R |  |
| 165 | 1.2 | up to about 30 times worldwide (33 times US to US) | arithmetic on Table 2 | 29.86; 33.30 | MATCH | R |  |
| 166 | 1.2, item 1 | 7.5x to 27.1x; 8.6x to 29.9x; 0.20x to 7.24x; 60 of 66 | analyze, Table 2 | same | MATCH | S | the first two ranges are Table 2 arithmetic (R) |
| 167 | 1.2, item 3 | about ten times (21.3% against 2.1%); one held, one in direction, two failed | cross_sector | same | MATCH | R |  |
| 168 | 12, M1 | 0.20x to 7.24x (8.89x); 2.94 to 1.34; 2.7; 35% or 54%; two pairs six to seven times apart | analyze, instrument_extra, Table 3 | same | MATCH | S | 2.94 to 1.34 is Table 3 arithmetic (R) |
| 169 | 12, M2 | links about two in three correct | r2_link_check | 65.0% to 66.8% | MATCH | S |  |
| 170 | 12, M2 | half for single-word labels | r2_link_check, section C | - | CANNOT RUN | - | private sample file; shipped output agrees |
| 171 | 15 | one fifth to seven times; 60 of 66; factor 2.7; two pairs six to seven times apart | analyze, instrument_extra | same | MATCH | S |  |
| 172 | 15 | median 21%, 0.6% to 9.2%, every sector; two of four predictions failed | cross_sector, sensitivity | same | MATCH | R |  |
| 173 | 15 | +0.47 to +0.75, +0.19, +0.27, one in seven, 11 labels, 622 searches | analyze_reviews, supplement_r10 | - | CANNOT RUN | - | shipped output agrees |
