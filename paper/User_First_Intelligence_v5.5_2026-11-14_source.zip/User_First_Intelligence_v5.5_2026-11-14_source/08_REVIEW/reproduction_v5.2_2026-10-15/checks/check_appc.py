"""Reproducer's own check: Tables C1 to C4 as printed in manuscript_v50.md against (a) the shipped
cross_sector_sensitivity2_output.txt, (b) my recomputation from the aggregates (C1, C2), and (c) the
make_tables_sector_surface.py output obtained in the layout diagnostic (C3, C4).
Usage: python3 -I check_appc.py <bundle dir> <my_check_m3.txt> <make_tables stdout>
"""
import re
import sys
from pathlib import Path

B = Path(sys.argv[1])
mine = Path(sys.argv[2]).read_text()
mt = Path(sys.argv[3]).read_text()
ms = (B / "manuscript_v50.md").read_text()
s2 = (B / "ai_citation_cross_sector/scripts/cross_sector_sensitivity2_output.txt").read_text()


def table_after(marker):
    i = ms.index(marker)
    block = ms[i:].split("\n\n")[1]
    return [[c.strip() for c in ln.strip().strip("|").split("|")] for ln in block.splitlines()
            if ln.startswith("|") and not ln.startswith("|---")][1:]


SURF = ["aio_searchqueries", "aio_prompts", "aimode_searchqueries", "aimode_prompts", "chatgpt", "perplexity", "gemini", "copilot"]
# C1
c1 = table_after("*Table C1.")
mine_c1 = {ln.split()[0]: [x.strip() for x in ln.split(None, 1)[1].split("|")]
           for ln in mine.split("== Table C1 recomputed")[1].split("\n\n")[0].splitlines()[1:]}
s2_c1 = {}
for ln in s2.split("== Appendix C1")[1].split("\n\n")[0].splitlines()[1:]:
    name, rest = ln[:33].strip(), ln[33:]
    vals = re.findall(r"([\d.]+%) \(([\d.]+)%-([\d.]+)%\)", rest)
    s2_c1[name] = [f"{a} ({b}–{c})" for a, b, c in vals]
bad = 0
for row, p in zip(c1, SURF):
    paper = row[1:]
    m = mine_c1[p]
    s = s2_c1[row[0].replace("AI Overviews, search queries", "AI Overviews (search queries)").replace("AI Overviews, prompts", "AI Overviews (prompts)").replace("AI Mode, search queries", "AI Mode (search queries)").replace("AI Mode, prompts", "AI Mode (prompts)")]
    d = [(i, paper[i], m[i], s[i]) for i in range(6) if not (paper[i] == m[i] == s[i])]
    bad += len(d)
    print(f"C1 {row[0]:30s} {'6 of 6 cells: paper = shipped output = recomputed' if not d else d}")
print(f"C1 cells differing: {bad}\n")
# C2
c2 = table_after("*Table C2.")
mine_c2 = {}
for ln in mine.split("== Table C2 recomputed")[1].split("\n")[1:12]:
    mine_c2[ln[:27].strip()] = ln[27:].split()
s2_c2 = {}
for ln in s2.split("== Appendix C2")[1].split("\n\n")[0].splitlines()[1:]:
    s2_c2[ln[:27].strip()] = ln[27:].split()
bad = 0
for row in c2:
    d = [(i, row[1 + i], mine_c2[row[0]][i], s2_c2[row[0]][i]) for i in range(8) if not (row[1 + i] == mine_c2[row[0]][i] == s2_c2[row[0]][i])]
    bad += len(d)
    print(f"C2 {row[0]:24s} {'8 of 8 cells: paper = shipped output = recomputed' if not d else d}")
print(f"C2 cells differing: {bad}\n")
# C3 and C4 against the make_tables output (layout diagnostic)
mt_blocks = mt.split("\n\n")
mt_c3 = [[c.strip() for c in ln.strip().strip("|").split("|")] for ln in mt_blocks[0].splitlines()[2:]]
mt_c4 = [[c.strip() for c in ln.strip().strip("|").split("|")] for ln in mt_blocks[1].splitlines()[2:]]
for name, paper, script in (("C3", table_after("*Table C3."), mt_c3), ("C4", table_after("*Table C4."), mt_c4)):
    n = sum(len(r) - 1 for r in paper)
    d = [(pr[0], i, pr[i], sr[i]) for pr, sr in zip(paper, script) for i in range(1, len(pr)) if pr[i] != sr[i]]
    print(f"{name}: {n} cells; rows paper {len(paper)} script {len(script)}; differing cells {len(d)} {d if d else ''}")
