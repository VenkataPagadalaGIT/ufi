"""Reproducer's own check: do manuscript_v50.md and paper.tex carry the same numbers, section by section?
Numeric tokens are compared as multisets per section, sections matched by title. Layout numbers that exist only
in LaTeX (column widths, spacing, list markers) are removed before comparing. Usage:
python3 -I md_vs_tex.py <bundle dir>
"""
import re
import sys
from collections import Counter
from pathlib import Path

B = Path(sys.argv[1])
md = (B / "manuscript_v50.md").read_text()
tex = (B / "paper.tex").read_text()
NUM = re.compile(r"\d[\d,]*(?:\.\d+)?")


def norm_tex(s):
    s = s.replace(r"\allowbreak{}", "").replace(r"\%", "%")
    s = re.sub(r"\\hsize=[\d.]+\\hsize", " ", s)
    s = re.sub(r"\\(?:vspace|hspace)\*?\{[^}]*\}", " ", s)
    s = re.sub(r"\\setlength\{[^}]*\}\{[^}]*\}", " ", s)
    s = re.sub(r"\\begin\{(?:minipage|tabularx)\}(\[[^\]]*\])?\{[^}]*\}", " ", s)
    s = re.sub(r"\\includegraphics\[[^\]]*\]", " ", s)
    s = re.sub(r"\\(?:label|ref)\{[^}]*\}", " ", s)
    s = re.sub(r"\[(?:width|height)=[^\]]*\]", " ", s)
    s = re.sub(r"\\begin\{enumerate\}\[[^\]]*\]", " ", s)
    s = re.sub(r"\\(?:leftmargin|itemsep|topsep|parsep|labelsep|itemindent)=[^,\]]*", " ", s)
    s = re.sub(r"\\(?:arraystretch|tabcolsep)\}\{[\d.]+\}", " ", s)
    s = re.sub(r"\\renewcommand\{\\arraystretch\}\{[\d.]+\}", " ", s)
    s = re.sub(r"\\setcounter\{[^}]*\}\{\d+\}", " ", s)
    return s


def norm_md(s):
    s = re.sub(r"(?m)^\d+\. ", " ", s)          # list markers
    s = re.sub(r"\]\(fig[^)]*\)", "]", s)         # figure file names
    return s


def nums(s):
    return Counter(t.rstrip(",.") for t in NUM.findall(s))


def key(h):
    h = re.sub(r"^Appendix [A-Z]: ", "", h)
    h = re.sub(r"^[\d.]+ ", "", h)
    return re.sub(r"\W", "", h.lower().replace("’", "'"))


md_parts = re.split(r"\n(?=#{2,3} )", md)
md_sec = {key(p.splitlines()[0].lstrip("#").strip()): p.split("\n", 1)[1] if "\n" in p else "" for p in md_parts[1:]}
md_order = [key(p.splitlines()[0].lstrip("#").strip()) for p in md_parts[1:]]
m = re.search(r"\\textbf\{Abstract\.\}(.*?)\\vspace", tex, re.S)
tex_sec = {"abstract": m.group(1)}
body = tex[tex.index(r"\section{Introduction}"):]
for p in re.split(r"\n(?=\\(?:sub)?section\*?\{)", body):
    h = re.match(r"\\(?:sub)?section\*?\{([^}]*)\}", p).group(1)
    tex_sec[key(h)] = p.split("\n", 1)[1] if "\n" in p else ""
total = 0
for k in md_order:
    if k not in tex_sec:
        print(f"{k[:50]:50s} NOT FOUND IN TEX")
        continue
    a, b = nums(norm_md(md_sec[k])), nums(norm_tex(tex_sec[k]))
    om, ot = a - b, b - a
    total += sum(om.values()) + sum(ot.values())
    print(f"{k[:50]:50s} {'same numbers (' + str(sum(a.values())) + ' tokens)' if not om and not ot else 'ONLY IN MD ' + str(dict(om)) + '; ONLY IN TEX ' + str(dict(ot))}")
print(f"sections: md {len(md_order)}, tex {len(tex_sec)}; tokens differing in total: {total}")
