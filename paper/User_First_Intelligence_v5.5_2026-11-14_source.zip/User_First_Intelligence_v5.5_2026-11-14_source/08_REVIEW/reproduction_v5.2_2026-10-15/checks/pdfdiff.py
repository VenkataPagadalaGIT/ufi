"""Reproducer's own check: are all byte differences between two PDFs inside the /CreationDate value?"""
import sys
a, b = open(sys.argv[1], "rb").read(), open(sys.argv[2], "rb").read()
if len(a) != len(b):
    print("sizes differ", len(a), len(b)); sys.exit()
diff = [i for i in range(len(a)) if a[i] != b[i]]
s = a.find(b"/CreationDate (D:"); e = a.find(b")", s)
print(f"{len(diff)} differing bytes; all inside /CreationDate value [{s},{e}]: {all(s < i < e for i in diff)}")
