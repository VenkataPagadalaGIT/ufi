# Independent reproduction of the v5.2 source bundle (15 October 2026)

Run by the `independent-reproducer` agent (`~/.claude/agents/independent-reproducer.md`), separate from the agent that
writes the paper, on `06_MANUSCRIPT/User_First_Intelligence_v5.2_2026-10-14_source.zip` (SHA-256 `20778e70...cd3a`),
in a clean temporary folder, with only the bundle's files. The agent could not write into the project; its report was
saved here by the authoring agent from its working files, unedited: `checks/numbers_table.md` (every quoted number,
its script, the value obtained and the verdict), `checks/command_log.txt`, and the check scripts it wrote.

## Summary as returned

- Scripts: 3 of 31 ran as shipped (`analyze.py`, `instrument_extra.py`, `r2_link_check.py`); 7 failed as shipped; 21
  could not run because their inputs are withheld. `instrument_extra.py` reproduced its shipped output byte for byte.
- Numbers: 173 quoted numbers checked. 136 MATCH (60 from scripts run as shipped, 12 from scripts run once the bundle's
  own files sat where their docstrings say, 64 recomputed from bundle files because no runnable script prints them),
  0 MISMATCH, 37 CANNOT RUN (licensed review export, private link-check sample, raw vendor exports, live OpenAlex, ufi
  example files). Every CANNOT RUN number agrees with the output file shipped beside its script.

## Problems found, and what was done (version 5.2, same day)

1. No Section 7 script ran from the bundle as shipped (paths `02_DESIGN/`, `03_DATA/processed/` against the bundle's
   `design/`, `aggregates/`).
2. Tables C1 and C2 and the Section 7 headlines were printed only after sections that open the withheld raw exports.
3. "Every statistic in Section 5.5 is printed by a script" was overstated: eight statistics and Table 4's ratio
   columns were printed by no script; "38% power" was a fixed string.
4. The stakes count included three duplicated works (456, not 459; 86% unchanged).
5. Two shipped outputs were not produced by the shipped scripts (`analyze_reviews_output.txt`'s last line;
   `cross_sector_sensitivity_output.txt`'s education-pilot section).
6. The link check by label length needed a private file.
7. Figure and build scripts did not run from the bundle (a Linux-only font; paths outside the bundle).
8. Figure 5's panel note named Sections 6 to 8 for the deployment, which v5.2 numbers 8 to 11.
9. Minor drift in the bundle README and the protocol's command line; one YouTube rank differs between two aggregates.

The fixes are recorded in the changelog under v5.2 and were checked by a second reproduction run.
