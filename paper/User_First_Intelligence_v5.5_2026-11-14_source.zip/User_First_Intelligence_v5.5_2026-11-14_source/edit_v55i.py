"""Version 5.5, ninth edit (14 November 2026): one sentence in Section 3.2, from the author's account of the same day.

The topic had been on the backlog for some time and was taken up only after the author saw it in the graph; the author
judged it evergreen and likely to add to the site's authority on the industry's topics. The employer's commercial
reasons (which products the pages might promote) are left out of the paper."""
import pathlib

p = pathlib.Path(__file__).with_name("manuscript_v50.md")
s = p.read_text()
a = "the directories and voice vendors of condition 6. The graph also showed what the topic connects to;"
b = ("the directories and voice vendors of condition 6. By the same account the topic had been on the content backlog for "
     "some time without being taken up, and it was taken up after the graph showed it; the author judged it evergreen and "
     "likely to add to the site's authority on the industry's topics. The graph also showed what the topic connects to;")
if s.count(a) != 1:
    raise SystemExit(f"REFUSE: {s.count(a)} matches")
if b in s:
    raise SystemExit("REFUSE: already applied")
p.write_text(s.replace(a, b))
print("edit_v55i applied")
