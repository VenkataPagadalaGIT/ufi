"""Version 5.2, Measurement 2's text matching measured (independent measurement, statistics: "every Measurement 2
statistic rests on exact-match links whose precision was never measured"). Two blind annotators, separate AI agents on
different models given only random samples and a fixed protocol, judged 200 of the 46,517 links and 100 of the 924
waiting matches (04_ANALYSIS/review_demand/r2_link_check_output.txt; the analysis script was committed before either
annotator's judgments were read). The multi-word sensitivity, run after the check and labelled post hoc, is section 11
of supplement_r10_output.txt."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:  # already applied: an insertion keeps its anchor, so a second run would insert twice
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("the two label-level correlations are +0.16 and +0.26.",
     "the two label-level correlations are +0.16 and +0.26.\n\n"
     "**How good the links are.** Two blind annotators, separate AI agents on different models given only a random sample and a fixed protocol and none of the hypotheses, judged 200 links drawn uniformly from the 46,517: 65% to 67% are correct (Wilson 95% intervals about 58% to 73%), and the two agree on 95.5% of the items (Cohen's kappa 0.90). The errors lie almost entirely in single-word labels, which are right about half the time (for example \"Thanks\", \"People\", \"Customers\" and place names that are also first names), while multi-word labels are 95% to 96% right. Restricted, after this check, to multi-word labels, the branch-level correlation is +0.91 (bootstrap 95% interval +0.74 to +0.98) with split attribution and +0.65 with modal attribution, the label-level correlation over mentioned labels is +0.24 (+0.16 to +0.33), and carriers still draw 56% of review mentions against 15% of search volume. The conclusions hold, and the branch-level agreement is stronger when the links are cleaner. The annotators are models, not people; a check of the same sample by a person is outstanding."),
    ("against 1.9% (1.8% to 2.1%) of five-star reviews; the matches have not been checked by hand.",
     "against 1.9% (1.8% to 2.1%) of five-star reviews. The same annotators judged 100 of the 924 matches: 83% to 85% are complaints about waiting (Cohen's kappa 0.93), and about nine in ten of those concern waiting in the store, so roughly 12% of one- and two-star reviews complain about a wait, most of them in a store."),
    ("It uses one first-party surface on one platform in one industry, exact-match linking whose precision has not been hand-checked, relative review dates,",
     "It uses one first-party surface on one platform in one industry, exact-match links of which about two in three are correct, relative review dates,"),
    ("One first-party surface on one platform in one industry; exact-match linking whose precision has not been hand-checked;",
     "One first-party surface on one platform in one industry; exact-match links of measured but modest precision (about two in three correct, half for single-word labels; judged by blind AI annotators, not by people);"),
    ("The links and the waiting matches have not been checked by hand, and a review is a different construct from an information need.",
     "No person has checked the links or the waiting matches, and a review is a different construct from an information need."),
    ("and barely on topics (+0.19).",
     "and barely on topics (+0.19), on links two blind annotators judged about two-thirds correct."),
    ("| M2 complaint rate | one- and two-star reviews matching a waiting pattern, against five-star | 14.0% against 1.9% | `analyze_reviews` |",
     "| M2 complaint rate | one- and two-star reviews matching a waiting pattern, against five-star | 14.0% against 1.9% | `analyze_reviews` |\n"
     "| M2 link precision | sampled links judged correct by two blind annotators; their agreement | 65% to 67%; kappa 0.90 (single-word labels about 50%, multi-word 95% to 96%) | `r2_link_check` |\n"
     "| M2 waiting-match precision | sampled waiting matches judged complaints about waiting; share in store | 83% to 85%, kappa 0.93; about 90% in store | `r2_link_check` |"),
    ("measured the manuscript against a fixed rubric, and version 5.2 responds to that measurement.",
     "measured the manuscript against a fixed rubric, and version 5.2 responds to that measurement; two further agents, on different models and blind to the analysis, annotated the samples of Section 6's link check."),
    ("see only part of that demand, through models whose figures are often reported as if they were counts.",
     "see only part of it, through models whose figures are often reported as counts."),
    ("two failed; descriptively, video and community sites", "two failed; video and community sites"),
])
P.write_text(s)
i = s.index("## Abstract")
print(f"{len(s.split()):,} words; abstract {len(s[i:s.index(chr(10) + '## ', i + 5)].split()) - 2} words")
