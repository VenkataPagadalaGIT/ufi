"""Version 5.3, 3 November 2026: from the last of the blind runs on sha 58881ff6 (7.3, 7.3, 7.1). Holding the number of matched
keywords constant, Section 6.2's rank agreement disappears (-0.12; a post hoc check, wiki_demand_supplement.py), so the
abstract, the contribution, the section and the conclusion now say so. The abstract is rewritten shorter; Section 5's "does
not rest on the author's judgment" excepts the choice of sections; the bound of Section 5.6 states its one-quantity assumption;
the stakes counts are marked as raw; Font-Julian et al. gets its open-access copy."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


# the abstract's two long paragraphs
L = s.split("\n")
i = next(k for k, x in enumerate(L) if x.startswith("On the area-code section of a large US telecommunications provider's website"))
j = next(k for k, x in enumerate(L) if x.startswith("User First Intelligence (UFI) is the framework built on that premise:"))
L[i] = ("On the area-code section of a large US telecommunications provider's website (381 code pages and 53 hubs), two commercial analytics platforms' stored records from the section's first month differ on estimated monthly visits by 7.5x to 27.1x (8.6x to 29.9x with both read worldwide). Across twelve sections of the domain the ratio runs from 0.20x to 7.24x, with no detectable relationship to section age (Spearman −0.11, a test of low power), while the platforms agree on which section is larger in 60 of 66 pairs, though in only 9 of the 15 within a factor of three. "
        "On 37,193 reviews of 378 telecom stores linked to a 42,994-node keyword taxonomy, on links two blind AI annotators judged about two-thirds correct, review demand and search volume barely agree on topics (+0.18) and agree on branches to a degree that depends on attribution and link quality (+0.47 to +0.91), while sizing them very differently. "
        "On the 372 area codes, in a comparison whose predictions were fixed before collection, a public count of requests for each code's Wikipedia article and the vendor's keyword volume agree roughly on ranking (+0.45, bootstrap 95% interval +0.34 to +0.54, over 240 articles), an agreement that disappears once the number of keywords matched per code is held constant (−0.12, post hoc), and not on magnitudes (searches per request from 0.3 to 244 between the 10th and 90th percentiles). "
        "In one vendor's index of AI answers (Ahrefs Brand Radar, US, October 2026) that name or cite the ten largest holdings of each S&P 500 sector fund, of four predictions written before collection one held, one held in direction only and two failed; video and community sites took a median 21% of citation incidences on Google's AI Overviews and AI Mode against 0.6% to 9.2% on ChatGPT, Copilot, Perplexity and Gemini, in every sector. "
        "Traffic estimates and cited sources therefore have to be measured per instrument and per answer surface.")
L[j] = ("User First Intelligence (UFI), the framework built on that premise, collects what people ask beyond the website, links it to an industry's entities under an ontology, and scores where the organization does not answer. An open implementation is released; its scoring function is specified, not evaluated. No causal claim is made.")
s = "\n".join(L)

rep([
    ("27 of them published in 2020, 87 in 2025 and 110 in 2026 to mid-October.", "27 of them published in 2020, 87 in 2025 and 110 in 2026 to mid-October (raw counts, not normalized for the growth of the index)."),
    ("agree roughly on the ranking (+0.45 over 240 articles) and not on the magnitudes, in a comparison whose predictions were fixed before collection (Section 6.2).",
     "agree roughly on the ranking (+0.45 over 240 articles), an agreement that disappears given the number of keywords matched per code, and not on the magnitudes, in a comparison whose predictions were fixed before collection (Section 6.2)."),
    ("It is reported first because it does not rest on the author's judgment: every figure in it is one of two vendors' readings", "It is reported first because its figures do not rest on the author's judgment, though the choice of the twelve sections of Section 5.5 does: every figure in it is one of two vendors' readings"),
    ("from the quantity both are estimating, and this study cannot say which.", "from the quantity both are estimating, and this study cannot say which. This treats the two figures as readings of one quantity, which is an approximation: they differ in territory, which only strengthens the bound, and in unit (Section 4.1), which it does not carry."),
    ("so the spread reflects how many keywords the carriers' exports matched for each code as well as the volume per keyword, whose geometric standard deviation is 7.0 (a post hoc check; `wiki_demand_supplement.py`).",
     "so the spread reflects how many keywords the carriers' exports matched for each code as well as the volume per keyword, whose geometric standard deviation is 7.0. The same goes for the ranking: holding the keyword count constant, the rank correlation between volume and requests is −0.12 (bootstrap 95% interval −0.24 to 0.00), so the agreement above may reflect how many keywords the carriers ranked for rather than the volume model (post hoc checks; `wiki_demand_supplement.py`). A vendor side built from the same phrasings for all 372 codes, not conditioned on the carriers' rankings, would separate the two; it needs vendor data this study did not buy."),
    ("a free public count and a commercial volume model agree only roughly on which carry more demand (+0.45, against +0.47 to +0.75 on all links for the taxonomy's branches) and size them very differently.",
     "a free public count and a commercial volume model agree only roughly on which carry more demand (+0.45, against +0.47 to +0.75 on all links for the taxonomy's branches), an agreement carried by the keyword count, and size them very differently."),
    ("agreed with the vendor's volume roughly on the ranking (+0.45 over 240 articles) and not at all on magnitudes", "agreed with the vendor's volume roughly on the ranking (+0.45 over 240 articles, an agreement that disappears given the number of keywords matched per code) and not at all on magnitudes"),
    ("| M2 public count dispersion |", "| M2 public count, keywords held constant | partial rank correlation of volume and requests given the matched keyword count (post hoc); share of the variance of log volume in log keyword count | −0.12; 77% | `wiki_demand_supplement` |\n| M2 public count dispersion |"),
    ("*Journal of Information Science, 52*(4), 1075–1088. https://doi.org/10.1177/01655515261445903", "*Journal of Information Science, 52*(4), 1075–1088. https://doi.org/10.1177/01655515261445903 (open-access copy: https://riunet.upv.es/handle/10251/236956)"),
])
P.write_text(s)
print(f"{len(s.split()):,} words")
