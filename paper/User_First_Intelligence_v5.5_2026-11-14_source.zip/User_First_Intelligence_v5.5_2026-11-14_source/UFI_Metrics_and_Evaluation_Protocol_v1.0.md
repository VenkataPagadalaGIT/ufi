---
title: "User First Intelligence: Metrics and Evaluation Protocol"
subtitle: "Companion to the manuscript, version 5.5 (14 November 2026)"
author: "Venkata Pagadala, Research Scholar, KL University (Koneru Lakshmaiah Education Foundation)"
date: "14 November 2026"
---

# 1. Purpose

This document defines every metric the manuscript reports, states the value each takes in the paper, names the script that prints it, and sets out a protocol under which other researchers can test the same questions on new data and propose better models. It is written for examiners, who will ask how each quantity is defined and computed, and for anyone who wants to beat the baselines reported here.

Three rules apply throughout.

1. **Name the instrument, territory, read date and denominator** of every quantity. Two analytics platforms, two territories or two read dates give different numbers for the same object (Measurement 1).
2. **Declare any attribution or reduction rule before computing.** Several results here change with such rules: the branch-level agreement in Measurement 2 runs from +0.47 to +0.75 depending on how a label is attributed to a branch.
3. **Report the result under every reasonable rule, not only the preferred one,** with the number of units and an interval or test.

# 2. Notation

| Symbol | Meaning |
|---|---|
| $A$, $B$ | two analytics instruments (here Ahrefs and Semrush) |
| $V_X(p, t)$ | estimated monthly visits for URL prefix $p$ in month $t$ on instrument $X$ |
| $K_X(p)$ | ranking keywords (positions 1 to 100) for prefix $p$ on instrument $X$ |
| $s$, $q$ | a sector; an answer surface (an AI product and, for Google, a query set) |
| $c_{s,q}(d)$ | citation incidence of domain $d$ in cell $(s, q)$: the number of stored answers citing $d$ ("Cited in"), summed over the hosts of its registrable domain |
| $e$, $Q_e$ | an entity of the ontology; the competency questions about $e$ |

# 3. Measurement 1: two instruments on one website

| Metric | Definition | Value in the paper | Printed by |
|---|---|---|---|
| Visits ratio, unmatched | $R = V_B / V_A$, Semrush US over Ahrefs worldwide | 7.5x to 27.1x (July to October 2026), the dashboards' monthly views as displayed; against Ahrefs' daily series, August 17.0x and September 6.3x (manuscript Section 5.1) | Table 2 (arithmetic) |
| Visits ratio, worldwide | both instruments worldwide | 8.6x to 29.9x | Table 2 (arithmetic) |
| Visits ratio, US to US (estimated) | Semrush US over Ahrefs worldwide times Ahrefs' US share (81.5%, read once) | 9.2x to 33.3x | Table 2 (arithmetic) |
| Growth agreement | $G_X(t) = V_X(t+1)/V_X(t)$; report $G_A/G_B$ | 0.95, 2.66, 1.37 for July to October | `instrument_extra.py` |
| Error bound | for two readings $a < b$ of a true value $T$: $\max(\lvert a-T\rvert, \lvert b-T\rvert) \ge (b-a)/2$; multiplicatively at least one reading is a factor $\sqrt{b/a}$ or more from $T$ | at 27.1x, a factor of 5.2 | Section 5.6 (arithmetic) |
| Decomposition | $R = (K_B/K_A) \times \frac{V_B/K_B}{V_A/K_A}$; keyword-universe share $= \ln(K_B/K_A)/\ln R$ | 35% (US pairing), 54% (worldwide pairing) | `instrument_extra.py` |
| Cross-section range | $R$ across prefixes on one domain, one read date | 0.20x to 7.24x (0.20x to 8.89x territory-matched); median 1.01 | `analyze.py` |
| Age relationship | Spearman $\rho$ between section age and $R$, Fisher 95% interval, permutation $p$ | $-0.11$ [$-0.64$, $+0.49$], $p = 0.73$, 12 prefixes, about 38% power for $\rho = 0.5$ | `analyze.py` |
| Ordering agreement | Spearman $\rho$ and Kendall $\tau$ [Kendall 1938] between $V_A(p)$ and $V_B(p)$; concordant pairs | $+0.94$ (bootstrap 95% interval $+0.70$ to $+1.00$; $p < 0.001$), $\tau = +0.82$ ($+0.57$ to $+1.00$), 60 of 66 pairs | `analyze.py`; $p$ and intervals from `instrument_extra.py` |
| Size-banded concordance | concordant pairs by the ratio of pair sizes (geometric mean of both instruments' estimates) | 51 of 51 pairs more than 3x apart; 9 of 15 within 3x | `instrument_extra.py` |
| Dispersion | geometric mean and geometric standard deviation of $R$ across prefixes | 1.13 (bootstrap 95% interval 0.62 to 2.12) and 3.1 (1.9 to 4.1); normal range on the log scale 0.12x to 10.6x, describing these twelve, not a prediction | `instrument_extra.py` |
| AI Overview citation rate | keywords whose AI Overview cites the prefix over all keywords with an AI Overview the prefix ranks on, Wilson 95% interval [Wilson 1927] | 12.6% to 20.0% by month | Table 3 (arithmetic) |

**Reproduce.** `cd data/instrument_divergence && python3 analyze.py` (public, `ufi` repository; the script opens its data files from the folder it is run in) prints the cross-section rows; `python3 04_ANALYSIS/instrument_divergence/instrument_extra.py` prints growth, decomposition, size bands and dispersion (prepared for release). From the paper's source bundle: `cd data && python3 analyze.py` and `cd instrument_divergence_extra && python3 instrument_extra.py`.

# 4. Measurement 2: reviews against keyword volume

| Metric | Definition | Value in the paper | Printed by |
|---|---|---|---|
| Link rate | share of reviews with text that the exact-match linker attaches to at least one taxonomy label; labels per linked review | 55.6%; 2.25 | `analyze_reviews.py` |
| Label-level agreement | Spearman $\rho$ between review mentions and monthly search volume per label | $+0.18$ over the 1,008 mentioned labels; $+0.27$ over all 27,817 linkable labels (unmentioned = 0); $+0.16$ and $+0.26$ on each node's own (non-nested) volume | `analyze_reviews.py`, `supplement_r10.py` |
| Branch-level agreement | Spearman $\rho$ between branch shares of mentions and of each branch's own volume, under a declared attribution rule | $+0.47$ ($p = 0.06$, modal branch), $+0.75$ (mentions split across branches); an earlier $+0.78$ used summed volumes of review-mentioned labels only and is superseded | `supplement_r10.py` |
| Share gap | review share minus volume share per branch, in percentage points | carriers $+51.9$ (66.8% against 14.9%); devices $-21.7$ (11.0% against 32.7%); broadband $-14.1$ (4.0% against 18.1%) | `supplement_r10.py` |
| Complaint pattern rate | share of one- and two-star reviews matching a waiting pattern, against five-star, Wilson 95% intervals | 14.0% (13.1% to 14.8%) against 1.9% (1.8% to 2.1%) | `analyze_reviews.py`, `supplement_r10.py` |
| Link precision | share of a uniform sample of 200 links judged correct by two blind annotators (AI agents on different models); Cohen's kappa between them | 65% to 67% (single-word labels about 50%, multi-word 95% to 96%); kappa 0.90 | `r2_link_check.py` |
| Waiting-match precision | share of a uniform sample of 100 waiting matches judged complaints about waiting; share of those about waiting in a store | 83% to 85% (kappa 0.93); about 90% in store | `r2_link_check.py` |
| Remedy coverage | taxonomy labels for the complaint and for its remedies, with monthly volume | 11 labels containing "wait" (622 searches), none about waiting in a store; 8 labels for appointments, queues or callbacks (13,170 searches), none for check-in | `supplement_r10.py` |

**Reproduce.** The review export is licensed and private (it contains reviewer display names). With access to the same exports: `PYTHONPATH=<ufi>/src python3 analyze_reviews.py <export folder>` and `python3 supplement_r10.py <export folder>`. Without them, from the source bundle: `cd review_demand && python3 m2_from_counts.py` recomputes every correlation, branch share and interval in this table from the released per-label counts (anonymized: no label names, volumes as ranks), and `python3 r2_link_check.py` the link and waiting-match precision. Label-level statistics are descriptive: labels share reviews and nest in one taxonomy, so they are not independent draws.

**Study W (manuscript Section 6.2): a public request count against the vendor's volume.** Units are English Wikipedia articles about the 372 US geographic area codes in service at the section's launch (240 articles; codes of one overlay complex share an article). $W(g)$ is the number of requests the Wikimedia Foundation classifies as human (agent type `user`) for the article's title and every redirect to it, October 2024 to September 2025; $\mathrm{dem}(g)$ is the DataForSEO monthly search volume summed over the pre-launch keywords naming the article's codes, from the table frozen for Study R1. The plan, four predictions and the analysis were fixed before collection and submitted for an OpenTimestamps stamp a minute before it began; the stamp reached a Bitcoin block after the collection (manuscript Section 6.2; `02_DESIGN/wikipedia_demand_372.md`).

| Metric | Definition | Value in the paper | Printed by |
|---|---|---|---|
| Coverage | codes whose title resolves to an article that names them | 372 of 372 (P4 held) | `wiki_demand_analysis.py` |
| Ranking agreement | Spearman $\rho$ between $\mathrm{dem}(g)$ and $W(g)$ over articles, 95% percentile bootstrap over articles (seed 20261031); Kendall's $\tau$ | $+0.45$ ($+0.34$ to $+0.54$); $\tau = +0.30$; keyword count against requests $+0.54$ ($+0.45$ to $+0.62$) (P1 held; P2 held at its boundary) | `wiki_demand_analysis.py` |
| Keywords held constant | partial rank correlation of volume and requests given the matched keyword count (post hoc), bootstrap over articles; Spearman of volume and keyword count; share of the variance of log volume in log keyword count | $-0.12$ ($-0.24$ to $0.00$); $+0.90$; 77% | `wiki_demand_supplement.py` |
| Magnitude dispersion | searches per request, $\mathrm{dem}(g) / (W(g)/12)$: median, 10th and 90th percentiles, geometric SD; the geometric SDs of each side alone | 35; 0.3 to 244; 14.5 (P3 held against Measurement 1's 3.1); vendor volume 16.7, requests 1.5 | `wiki_demand_analysis.py` |
| Sensitivities | window shifted one month; six months outside the Foundation's reclassified span; twelve times the median month; excluding articles with a late or zero-keyword code; article title only; single-code articles; August to September 2026 | $+0.45$; $+0.45$; $+0.44$; $+0.46$; $+0.31$; $+0.30$; $+0.39$ | `wiki_demand_analysis.py` |

**Reproduce.** From the source bundle: `cd wikipedia_demand && python3 wiki_demand_analysis.py` prints every value above from the released tables; `python3 wiki_collect.py` re-reads the public APIs (redirect lists and counts are live and may differ from the released files, which record the 31 October 2026 read).

# 5. Measurement 3: what AI answers cite

| Metric | Definition | Value in the paper | Printed by |
|---|---|---|---|
| Source-type share | $\sum_{d \in \text{type}} c_{s,q}(d) / \sum_d c_{s,q}(d)$ over the 1,000 exported domains, types fixed before collection | Table C1 | `cross_sector.py`, `cross_sector_sensitivity2.py` |
| Surface contrast | median video-and-community share over sectors and views, Google views against the other four | 21.3% against 2.1%; bootstrap over sectors 17.2% to 26.7% against 1.7% to 2.7% | `cross_sector.py`, `cross_sector_sensitivity.py` |
| Every-sector dominance | sectors in which the lowest Google view exceeds the highest other surface | 11 of 11 (10 of 11 with company properties reassigned; 7 of 11 without YouTube) | `cross_sector_sensitivity.py` |
| YouTube rank | rank of youtube.com among non-company domains, median over sectors | 1, 2, 7, 7, 151, 161 (AI Overviews, AI Mode, Perplexity, Gemini, ChatGPT, Copilot) | `cross_sector.py` |
| Cross-sector overlap | mean pairwise Jaccard of the ten most-cited non-company domains between sectors | 0.36 to 0.40 on Google views; 0.08 to 0.23 on the others (exploratory) | `cross_sector.py` |
| Variance decomposition | share of the total sum of squares of the 88 cell shares explained by surface means and by sector means | video and community 77% (bootstrap over sectors 70% to 91%) against 14% (5% to 20%); news 12% against 73% | `cross_sector_sensitivity2.py` |
| Top source by cell | most-cited non-company domain per sector and surface | Tables C3, C4 | `make_tables_sector_surface.py` |
| Predictions | P1 to P4 as written before collection | one held, one held in direction only, two failed | `cross_sector.py` |

**Sensitivities to report with any surface contrast:** "Found in" instead of "Cited in"; the largest single host instead of summed hosts; company properties counted as company domains; the first 100, 250 and 500 export rows (truncation); excluding contaminated names.

**Reproduce.** The raw vendor exports are not released. `cd data/ai_citation_cross_sector/scripts && python3 section7_from_aggregates.py` (in the source bundle, `cd ai_citation_cross_sector/scripts`) prints every value in this table from the released aggregates, except the sensitivities that need row-level data (company properties, "Found in", largest host, truncation), which `cross_sector_sensitivity.py` prints from the exports.

# 6. The framework's own metrics

| Metric | Definition | Value | Source |
|---|---|---|---|
| Schema pass rate | share of competency questions the ontology can express (property-path check, plus questions declared unsupported) | 4/5 on the released example | `ufi cq` |
| Instance coverage rate | mean over expressible questions of the share of subjects for which the graph returns an answer | 70.4% on the released example | `ufi cq` |
| Content Gap Score | $\text{CGS}(e) = \text{prior}(e)\,(1 - \text{own}(e))\,[\alpha(1-\text{cov}_K(e)) + (1-\alpha)\,\text{mean}_{q \in Q_e}(1 - \text{ans}(q,e))]$, with $\text{prior}(e) = \beta\,\text{rel}(e) + (1-\beta)\,\text{dem}(e)$; rel is a topic-sensitive PageRank, dem is rank-normalized linked demand | not evaluated; $\alpha = \beta = 0.5$, damping 0.85 locked | `ufi` `score.py` |

# 7. Benchmark protocol for future work

Each task below names its input, the metric to report, and the baseline this paper sets. Tasks D to G are proposed and have no baseline yet; their metrics are fixed here so that results can be compared.

**Task A. Instrument agreement on a new domain.** Read two or more analytics instruments on every prefix of a multi-section domain above a stated traffic threshold, on two read dates at least a week apart. Report $R$ under each territory pairing, ordering agreement with size bands, dispersion, growth agreement and the decomposition. *Baseline:* 0.20x to 7.24x across twelve prefixes; ordering $\rho = +0.94$; GSD 3.1.

**Task B. First-party demand against volume.** Given a taxonomy with search volume and one first-party surface, report the link rate, the link precision on a uniform random sample of at least 200 links judged by at least two annotators blind to the analysis, with their agreement, and label-level and branch-level agreement under every declared attribution rule. *Baseline:* label $\rho$ $+0.18$ to $+0.27$; branch $\rho$ $+0.47$ to $+0.75$; link precision 65% to 67% (two AI annotators, kappa 0.90); with multi-word labels only, branch $\rho$ $+0.65$ to $+0.91$.

**Task C. Source mix by answer surface.** For a frame fixed by an external rule, report source-type shares per cell, the surface contrast with a bootstrap over the frame's units, the every-sector count, the variance decomposition and the cross-unit overlap, with the sensitivities of Section 5. *Baseline:* 21.3% against 2.1%; 11 of 11. A later, unpredicted read of one category in thirteen countries (manuscript Section 7.7; `intl_from_cells.py`) gives 14.0% against 0.6% over 104 cells, with the lowest Google view above the highest other surface in 13 of 13 countries.

**Task D. Does the Content Gap Score find gaps that matter?** A first, retrospective instance is registered in the manuscript (Section 13, Study R1): the score of all 372 area codes from pre-launch data, the plan and the analysis fixed and stamped with OpenTimestamps before any outcome was read; it waits on the vendors' per-page exports. Freeze and hash a query set before launch; publish pages for the three classes of the manuscript's Section 13 (top class by score, top class by volume, a class in the bottom quartile of the score), with matched page counts; measure top-ten presence on the frozen set at day 37 on both instruments. Compare the classes on that outcome, and, at the level of entities, report precision at $k$ and nDCG at $k$ [Järvelin & Kekäläinen 2002] of the score's ranking of entities and of the volume ranking against each entity's observed outcome, and inter-annotator agreement on the own, coverage and answerability judgments as weighted kappa [Cohen 1968] with a bootstrap interval. *Comparison:* the score against volume ranking, with parameters locked before collection; a random ranking of entities may be added as a floor.

**Task E. Surface drift.** For one industry, report the share of linked questions by demand surface each quarter, with the same linker and ontology, and the time until a surface's share halves. This measures how quickly a demand layer goes stale.

**Task F. Agent alignment.** For a fixed set of tasks given to AI agents and to people, report the overlap of the questions they ask (Jaccard of normalized question sets) and of the sources they rely on, per agent.

**Task G. Disclosure signal.** For the 109 companies of Measurement 3, code what each says about AI search on its quarterly earnings calls, and report the correlation, over quarters, between disclosure and the number of answers citing the company's domains, by surface, on a prompt set fixed in advance that does not depend on whether the answer names the company. The citation shares of Measurement 3 are partly fixed by its selection rule and cannot serve.

**Task H. A public count against volume on a new entity class.** For a finite class with a public request count per entity (Wikipedia articles, a registry's own page views), freeze the vendor volume per entity first, state the predictions, stamp the plan and wait for the stamp to reach a Bitcoin block before reading any count, and report the ranking agreement with its interval, the dispersion of searches per request and the sensitivities of Study W. *Baseline:* $\rho = +0.45$ over 240 articles; geometric SD of searches per request 14.5; every prediction held, one at its boundary.

# 8. Reporting checklist

Every result that claims to improve on these baselines should report: the instrument and its version or read date; the territory; the denominator and how the universe was selected; the attribution, reduction and truncation rules, declared before computing; the number of units; an interval or test; the sensitivities; the scripts that print each number; what data can and cannot be released; and the use of AI tools.

# 9. Where things are

Manuscript `06_MANUSCRIPT/User_First_Intelligence_v5.5_2026-11-14.pdf`. Data index `03_DATA/README.md`. Scripts `04_ANALYSIS/` (`instrument_divergence/`, `review_demand/`, `wikipedia_demand/`, `ai_cited_sources/`, `edu_ai_citations/`). Public: the twelve-prefix data and `analyze.py` in the `ufi` repository. Prepared for release, not yet public (staged in `09_SUBMISSION/ufi_release_v5.4/` by `09_SUBMISSION/stage_release_v54.py`): the Measurement 3 design, aggregates and scripts, `instrument_extra.py`, the link check, the stakes count, Study W (public data throughout) and Section 7.7's per-cell counts. An independent reproduction of the source bundle is in `08_REVIEW/reproduction_v5.2_2026-10-15/`. Private: raw vendor exports and the licensed review export.

# References

Cohen, J. (1968). Weighted kappa: Nominal scale agreement provision for scaled disagreement or partial credit. *Psychological Bulletin, 70*(4), 213–220. https://doi.org/10.1037/h0026256

Järvelin, K., & Kekäläinen, J. (2002). Cumulated gain-based evaluation of IR techniques. *ACM Transactions on Information Systems, 20*(4), 422–446. https://doi.org/10.1145/582415.582418

Kendall, M. G. (1938). A new measure of rank correlation. *Biometrika, 30*(1–2), 81–93. https://doi.org/10.1093/biomet/30.1-2.81

Wilson, E. B. (1927). Probable inference, the law of succession, and statistical inference. *Journal of the American Statistical Association, 22*(158), 209–212. https://doi.org/10.1080/01621459.1927.10502953
