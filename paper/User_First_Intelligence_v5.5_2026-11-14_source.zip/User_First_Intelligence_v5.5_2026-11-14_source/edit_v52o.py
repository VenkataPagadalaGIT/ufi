"""Version 5.2, 15 October 2026: writing (the three blind paper-measure runs: "collapse the restatements of
Measurement 1 (Sections 1.2, 5.6, 12 and 15)"). Section 12 states Measurement 1's threats without restating its
numbers, and adds the unarchived dashboard reads; the conclusion's Measurement 1 paragraph is shortened; the
author-independence statement is made exact about the checks AI agents made."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()
if "dashboard reads that were not archived" in s:
    raise SystemExit("REFUSE: already applied")


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


i = s.index("**Measurement 1 (Section 5).** Instrumentation is its subject rather than a caveat on it.")
j = s.index("\n\n**Measurement 2 (Section 6).**", i)
s = s[:i] + ("**Measurement 1 (Section 5).** Instrumentation is its subject rather than a caveat on it, and no outcome is a "
             "measured visit. One instrument posted a data-reliability notice covering days 65 to 75. \"AI Overview citation\" "
             "has two operational definitions here, which differ by a factor that falls from 2.94 to 1.34; both are reported, "
             "and a comparison of AI-answer counts is withdrawn as a scope mismatch (Section 5.3). The estimated-visit figures "
             "are vendor click models that do not distinguish automated from human requests, and a section attracting an "
             "automated link network may also attract automated requests; no instrument available here separates them. "
             "Ordering agreement is weaker for sections within a factor of three of each other, and the share of the "
             "divergence the keyword universe explains depends on the territory pairing. External validity: twelve "
             "purposively chosen prefixes on one domain, one of them followed for 77 days; one vendor pair; one read date for "
             "the cross-section; no ground truth; and dashboard reads that were not archived, so they can be checked only by "
             "reading the dashboards again. Internal analytics would resolve much of this and are not available.") + s[j:]

rep([
    ("Measurement 1 is the paper's main result. Two commercial analytics platforms' histories of the same section begin on the day it appeared. Over four months they disagreed about its estimated traffic by factors between 7.5 and 27.1 with the territories mismatched, and between 8.6 and 29.9 with both read worldwide; read once, they disagreed about its ranking keywords by a factor of two (three worldwide) and about its referring domains by a factor of eleven. Read on the same day across twelve sections of the same domain, their ratio on estimated visits ran from one fifth to seven times, with no detectable relationship to how old each section was or to how many keywords each vendor had found, while they agreed on which of two sections was larger in 60 of 66 pairs. On this domain the correction factor between the vendors has no fixed sign or size, so a single-vendor study of magnitudes carries a range it cannot bound from its own data, while a single-vendor ranking of sections agrees in direction with the other instrument's when sections differ several-fold on both; on one instrument alone, two pairs six to seven times apart were reversed on the other. The two also disagreed about growth, by a factor of 2.7 in one month.",
     "Measurement 1 is the paper's main result. Two commercial analytics platforms, reading the same section from the day it appeared, disagreed about its estimated traffic by factors of 7.5 to 27.1 over four months (8.6 to 29.9 with both read worldwide), about its growth by a factor of 2.7 in one month, and about its referring domains by a factor of eleven. Across twelve sections of the same domain, read on one day, their ratio on estimated visits ran from one fifth to seven times, with no detectable relationship to section age or to the keyword universe each vendor had found, while they agreed on which of two sections was larger in 60 of 66 pairs, less often when the sections were close in size. On this domain the correction factor between the vendors has no fixed sign or size: a single-vendor study of magnitudes carries a range it cannot bound from its own data, while a single-vendor ranking of sections that differ several-fold agrees in direction with the other instrument."),
    ("No part of the evaluation has been performed by anyone else.",
     "No person other than the author has performed any part of the evaluation; the reproduction and annotation checks of Sections 6 and 14 were made by AI agents the author ran."),
])
P.write_text(s)
print(f"{len(s.split()):,} words")
