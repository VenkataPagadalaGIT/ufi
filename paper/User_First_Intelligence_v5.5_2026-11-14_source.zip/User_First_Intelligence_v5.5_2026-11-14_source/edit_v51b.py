"""Version 5.1, the author's decisions on the PhD examiner's final review (13 October 2026):
F1, keep the title (no change); F3, remove the first pilot of Section 7 (the author's platform dataset of 7 October).
Open item 2 (the pilot's data basis and consent) is closed by the removal, so the open items are renumbered 1 to 4.
The scope of the agency's permission (the rest of F3) awaits the author's information and is not written here.
"""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:  # already applied: an insertion keeps its anchor, so a second run would insert twice
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("### 7.1 Two pilots", "### 7.1 Pilot"),
    ("The first is a commercial AI-visibility dataset for the US online-learning market, computed on 7 October 2026 (UTC) by the author's own analytics platform, in a pre-production dashboard, from Ahrefs Brand Radar data accessed through Previsible's account (snapshot 22 September 2026). It holds 372,853 AI answers to 348,450 prompts that name none of 22 tracked course providers, carrying 2,343,022 citations. The providers together drew 19.9% of citations; youtube.com drew 12.4%, the most of any outside domain; and video, forum, social and user-publishing sites among the fifteen most-cited outside domains drew at least 20.1%. Google's AI Overviews and AI Mode produced 92.9% of the answers and 98.0% of the citations. No provider is named, and the platform is not released, so no reader can rerun this pilot. The second is a per-surface export of the same Brand Radar table for six online-learning brands,",
     "The pilot is a per-surface export of the Brand Radar cited-domains table for six online-learning brands,"),
    ("The predictions below were written after seeing it, so the cross-sector study is a replication across sectors of a pattern first seen in one market. The first pilot covers answers that cite or name a tracked provider, to prompts that name none; the second, like the cross-sector study, covers answers that name or cite a listed brand, so the first describes a different population from the study below.",
     "The predictions below were written after seeing it, so the cross-sector study is a replication across sectors of a pattern first seen in one market. Like the cross-sector study, the pilot covers answers that name or cite a listed brand. An earlier pilot, computed by the author's own analytics platform, was withdrawn in version 5.1 (Appendix A)."),
    (" The first pilot in Section 7 was computed on 7 October 2026 (UTC), before Previsible's permission, by the author's own analytics platform from Brand Radar data accessed through Previsible's account, and is reported in aggregate with no provider named.", ""),
    ("(2) the basis on which the author's platform held the pilot data, and the consent of any client for whom it was computed, or removal of the pilot; (3) public release of the Section 7 artifacts at a cited commit; (4) an institutional ethics determination for Section 6; and (5) withdrawal or correction",
     "(2) public release of the Section 7 artifacts at a cited commit; (3) an institutional ethics determination for Section 6; and (4) withdrawal or correction"),
    ("prepared for release with the Section 7 artifacts (open item 3);", "prepared for release with the Section 7 artifacts (open item 2);"),
    ("and the scripts for Sections 6 and 7 are prepared for release (open item 3).", "and the scripts for Sections 6 and 7 are prepared for release (open item 2)."),
    ("is withdrawn here (open item 5).", "is withdrawn here (open item 4)."),
    ("The author owns an AI-visibility analytics platform, which computed the first pilot in Section 7, and may develop commercial tools and a book based on the framework.",
     "The author owns an AI-visibility analytics platform, which computed a pilot for Section 7 that was withdrawn in version 5.1, and may develop commercial tools and a book based on the framework."),
    ("changed the title to name the framework's purpose;",
     "changed the title to name the framework's purpose; removed the first pilot of Section 7, a dataset the author's own analytics platform computed on 7 October 2026 from vendor data accessed through the agency's account before its permission was given;"),
])
P.write_text(s)
print(f"{len(s.split()):,} words")
