"""Version 5.3, dated 3 November 2026: from the second adversarial check of Appendix E (31 October; its skeptics were cut off
by a session limit, so the author's agent checked the remaining findings against the files itself on 3 November) and from
the Bitcoin anchor of Study W's stamp, which came after the collection and is disclosed. Also: one value rounded twice
(+0.32 for +0.31, from a printed 0.315; the exact value is 0.31498, wiki_demand_supplement.py), a causal "because" narrowed
to what the supplement shows, geometric standard deviations no longer called factors, and the ordering agreement
printed by the factor on each instrument (instrument_extra.py, section 10)."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("Manuscript version 5.3, 31 October 2026. Preprint, not yet peer reviewed.",
     "Manuscript version 5.3, 3 November 2026. Preprint, not yet peer reviewed."),
    # abstract, contribution, conclusion, Table D1: fixed first, with the stamp's timing in Section 6.2
    ("in a comparison whose predictions and analysis were stamped before collection. In one vendor's index",
     "in a comparison whose predictions and analysis were fixed before collection. In one vendor's index"),
    ("and not on the magnitudes, in a comparison stamped before collection (Section 6.2).",
     "and not on the magnitudes, in a comparison whose predictions were fixed before collection (Section 6.2)."),
    ("not at all on magnitudes, the count spreading the class across a factor of 1.5 and the vendor's volume across a factor of 16.7, in a comparison whose predictions were stamped before its data were read.",
     "not at all on magnitudes (geometric standard deviations across articles of 1.5 for the count and 16.7 for the volume), in a comparison whose predictions were fixed before its data were read."),
    ("| M2 public count predictions | P1 to P4 as stamped before collection |", "| M2 public count predictions | P1 to P4 as fixed before collection |"),
    # Section 1: the third search did not test the priority claim
    ("A search of OpenAlex and Crossref on 14 October 2026, an independent search of five databases with citation chasing by a separate agent on 15 October, and a search for reporting guidelines by another on 31 October (Appendix E), all recorded in the source bundle, found vendor tools compared",
     "A search of OpenAlex and Crossref on 14 October 2026 and an independent search of five databases with citation chasing by a separate agent on 15 October, both recorded in the source bundle, found vendor tools compared"),
    ("to the extent of those searches, this paper reports the first.",
     "to the extent of those two searches, this paper reports the first. A third search, for reporting guidelines, on 31 October found none specific to such figures (Appendix E)."),
    # Section 5.5, 5.6, Table D1: the factor on each instrument
    ("of the 15 pairs within a factor of three, 9 are. The consequence for practice",
     "of the 15 pairs within a factor of three, 9 are. Read by the factor on each instrument instead, all 40 pairs more than three times apart on both are ordered alike, as are 16 of the 18 more than three times apart on exactly one (the other two are six to seven times apart on one instrument and about equal on the other) and 4 of the 8 within a factor of three on both (`instrument_extra.py`, section 10). The consequence for practice"),
    ("when sections differ several-fold on both instruments and less often when they are within a factor of three (9 of 15 pairs);",
     "when sections differ several-fold on both instruments (all 40 pairs more than three times apart on both) and less often when they are close (9 of the 15 pairs within a factor of three on the geometric mean of the two estimates);"),
    ("+0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within |", "+0.94, +0.82, 60 of 66; 51 of 51 beyond 3x, 9 of 15 within; 40 of 40 beyond 3x on both instruments |"),
    ("| M1 decomposition | share of the log visits ratio due to the keyword-universe ratio (Appendix E.2) |",
     "| M1 decomposition | share of the log visits ratio carried by the keyword-universe term (Appendix E.2; defined only where both terms have the same sign) |"),
    # Section 6.2: the stamp's timing
    ("The plan, four predictions and the analysis script were committed and stamped with OpenTimestamps on 31 October 2026, before any request count was collected and after four AI reviewers had read a draft of them (`02_DESIGN/wikipedia_demand_372.md`). The collection, 1,497 requests to two public APIs on the same day, read",
     "The plan, four predictions and the analysis script were reviewed in draft by four AI agents, committed, and submitted for an OpenTimestamps stamp at 05:10 UTC on 31 October 2026, before any request count was collected apart from a few probes of the endpoints that the plan lists (`02_DESIGN/wikipedia_demand_372.md`). The collection followed at once, 1,497 requests to two public APIs from 05:11 to 05:19 UTC, before the stamp reached a Bitcoin block (block 973,943, mined at 06:51 UTC): the proof dates the plan to within two hours of the read, and the order of the two within that span rests on the commit history and the collection log, which the author's agents wrote. It read"),
    ("while the vendor's summed volumes vary by a factor of 16.7 (50 to 3,704,650 searches a month),",
     "while the vendor's summed volumes have one of 16.7 (50 to 3,704,650 searches a month),"),
    ("Counting an article's current title alone gives +0.32, because ten articles carry their current title only since January 2025 or later, renamed as overlay codes were added, and their former titles, now redirects, carry most of their requests (pooled, 9.3% of requests arrive through redirect titles; for the median article, 0.7%).",
     "Counting an article's current title alone gives +0.31, partly because ten articles carry their current title only since January 2025 or later, apparently renamed as overlay codes were added, with 44% to 100% of their requests arriving through former titles that are now redirects (without those ten, +0.37 on the title alone against +0.43 on all titles; `wiki_demand_supplement.py`, written after the data were read, prints these and the other descriptive figures the stamped script does not). Pooled, 9.3% of requests arrive through redirect titles; for the median article, 0.7%."),
    # Section 14
    ("(Claude Opus 5, Opus 5.5, Fable 5 and Fable 5.1, in October 2026)", "(Claude Opus 5, Opus 5.5, Fable 5 and Fable 5.1, in October and November 2026)"),
    # Appendix E
    ("Report an ordering read on one instrument with the factor between the units, and as unresolved unless a second instrument shares it or the units are several-fold apart on both. Here the two instruments agreed on which of two sections was larger in 60 of 66 pairs, in all 51 pairs more than three times apart and in 9 of 15 within a factor of three, while two pairs six to seven times apart on one instrument were ordered the other way on the second (Sections 5.5 and 5.6).",
     "Report an ordering read on one instrument with the factor between the units, and as unconfirmed until a second instrument shares it, since a large factor on one instrument does not settle it. Here all 40 pairs of sections more than three times apart on both instruments were ordered alike, as were 16 of the 18 more than three times apart on exactly one and 4 of the 8 within that factor on both; the two exceptions were six to seven times apart on one instrument and about equal on the other (Sections 5.5 and 5.6)."),
    ("Here an AI browser assistant read the dashboards and made the Section 7 exports, one figure was read by the author, no API was used, and the clauses on automated use are quoted with each vendor's position (Sections 4.1 and 14).",
     "Here an AI browser assistant read the Ahrefs and Semrush dashboards and made the Section 7 exports, one figure was read by the author, no vendor API was used for those figures, and the clauses on automated use are quoted, with the statement that neither vendor has confirmed whether these reads fall within them (Sections 4.1 and 14)."),
    ("as they do on the area-code prefix under both pairings (35% and 54%; Section 5.6). On the six prefixes whose visits ratio is below one, the keyword ratio is still at least 2.0 (Section 5.5), so there the two terms pull in opposite directions and no share reading exists.",
     "as they do on the area-code prefix under both pairings (35% and 54%, the second approximate because its keyword counts were read after its visits; Section 5.6). On the six prefixes whose unmatched visits ratio is below one, the keyword ratio is still at least 3.2 (`instrument_extra.py`, section 10), so there the two terms pull in opposite directions and no share reading exists."),
    ("(72 logged queries; Semantic Scholar unreachable; one screener, an AI agent; indexed English-language literature; recorded in",
     "(72 logged API queries; Semantic Scholar and DBLP not searched, being unreachable; vendor and practitioner grey literature sampled, not searched systematically; one screener, an AI agent; indexed English-language literature; recorded in"),
    ("none names a search-analytics vendor. Items 1, 2 and 10 restate their access-date, parameter and data-sharing items for these instruments; item 4 extends to a second instrument the repeated samples from one opaque instrument that Hölzl, Keusch and Sajons recommend, and applies to vendors the design of comparing engines on one query set [Thelwall 2008]; the other items are this paper's findings.",
     "none names a commercial SEO or web-analytics tool such as Ahrefs, Semrush or Similarweb. Items 1, 2, 9 and 10 restate their access-date, parameter, access-path and data-sharing items for these instruments, item 9 adding who operated the interface and which of the vendor's terms were read; item 3 adds the distinction between counted and modeled figures; item 4 extends to a second instrument the repeated samples from one opaque instrument that Hölzl, Keusch and Sajons recommend, and applies to vendors the design of comparing engines on one query set [Thelwall 2008]; item 8 extends their external-validation item to a counted or first-party signal read beside the volume; items 5, 6 and 7 rest on this paper's findings."),
])
# Appendix A: this version's bullet follows version 5.2's
a = "and the closest prior work found by the searches is cited (Section 2).\n"
b = a + "- **Version 5.3** adds Section 6.2 and Appendix E and changes no earlier result; Table D1's label for the first decomposition pairing now names it as Section 5.6 does (Semrush US against Ahrefs worldwide), and the first-comparison claim of Section 1 now rests on the two searches that tested it.\n"
if s.count(a) != 1:
    raise SystemExit(f"REFUSE: {s.count(a)} matches for the Appendix A anchor")
if "- **Version 5.3**" in s:
    raise SystemExit("REFUSE: Appendix A bullet already present")
s = s.replace(a, b)
P.write_text(s)
print(f"{len(s.split()):,} words")
