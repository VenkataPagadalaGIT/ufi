"""Version 5.3, 31 October 2026: Study W positioned against the closest prior work on third-party web counts as research
instruments, each checked at Crossref on 31 October 2026 (Thelwall 2008 on search-engine hit counts; Hölzl, Keusch &
Sajons 2025 on Google Trends; Alibudbud 2023 on Wikipedia page views), found by the independent literature search
recorded in 01_LITERATURE/checklist_search_2026-10-31/. References inserted in alphabetical order."""
import unicodedata
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("this paper places the two signals on one taxonomy and compares the topics each ranks. For Measurement 3:",
     "this paper places the two signals on one taxonomy and compares the topics each ranks; its second comparison (Section 6.2) follows the work that treats search-engine hit counts [Thelwall 2008], Google Trends [Hölzl, Keusch & Sajons 2025] and Wikipedia page views [Alibudbud 2023] as instruments whose settings, access dates and handling of crawlers and redirects must be reported, and checks one such count against a vendor's volume on a fixed class of entities. For Measurement 3:"),
    ("so that a request by any name for an article is counted once; no title was missing and none lacked data.",
     "so that a request by any name for an article is counted once; no title was missing and none lacked data. The items a review of page-view studies asks authors to state, the pages, the language, the dates, the agent type and whether crawlers and redirects were included [Alibudbud 2023], are fixed in the plan."),
])

NEW = [
    "Alibudbud, R. (2023). Wikipedia page views for health research: A review. *Frontiers in Big Data, 6*, 1199060. https://doi.org/10.3389/fdata.2023.1199060",
    "Hölzl, J., Keusch, F., & Sajons, C. (2025). The (mis)use of Google Trends data in the social sciences: A systematic review, critique, and recommendations. *Social Science Research, 126*, 103099. https://doi.org/10.1016/j.ssresearch.2024.103099",
    "Thelwall, M. (2008). Quantitative comparisons of search engine results. *Journal of the American Society for Information Science and Technology, 59*(11), 1702–1710. https://doi.org/10.1002/asi.20834",
]


def key(line):
    return unicodedata.normalize("NFKD", line).encode("ascii", "ignore").decode().lower()


head, refs_and_rest = s.split("\n## References\n", 1)
refs, rest = refs_and_rest.split("\n## Appendix A", 1)
lines = refs.split("\n")
entries = [i for i, x in enumerate(lines) if x.strip() and not x.startswith("#")]
for entry in NEW:
    if any(x.startswith(entry[:25]) for x in lines):
        raise SystemExit(f"REFUSE: already present: {entry[:40]}")
    pos = next((i for i in entries if key(lines[i]) > key(entry)), None)
    if pos is None:
        raise SystemExit("no insertion point")
    lines[pos:pos] = [entry, ""]
    entries = [i for i, x in enumerate(lines) if x.strip() and not x.startswith("#")]
s = head + "\n## References\n" + "\n".join(lines) + "\n## Appendix A" + rest
P.write_text(s)
print(f"{len(s.split()):,} words")
