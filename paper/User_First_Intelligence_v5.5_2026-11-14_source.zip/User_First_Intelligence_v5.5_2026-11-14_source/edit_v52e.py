"""Version 5.2, the author's decisions of 14 October 2026 and two corrections found while checking them against the data.

1. Vendor terms (integrity gate of the first independent measurement): the paper now discloses Ahrefs' clause 4.4(j),
   as the released design file (A3) already did, and the design file records the author's decision as A4.
2. Table 1: the October 2025 search volumes came from DataForSEO ranked-keyword exports, not an Ahrefs export (author's
   answer, checked: the three files on disk are DataForSEO exports dated 12 to 19 October 2025, and their area-code
   rows sum to 62.1 million monthly searches, the "62.2M" an earlier version reported; no Ahrefs export of that date
   exists in the project or on the machine).
3. Measurement 2's locations: the export holds 379 locations, of which 378 have a text review, so "47,485 reviews of
   378 locations" was off by one; the selection rule was not recorded (author's answer) and the export's composition
   is now stated (04_ANALYSIS/review_demand/supplement_r10_output.txt, section 9).
"""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:  # already applied: an insertion keeps its anchor, so a second run would insert twice
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("No API was used, and raw vendor exports are not redistributed.",
     "No API was used, and raw vendor exports are not redistributed. Ahrefs' terms of service prohibit using its services \"through an automated means\" except through its API (clause 4.4(j), read 13 October 2026); the Ahrefs reads and exports were made through its web interface by the browser assistant, no confirmation from the vendor has been obtained, and the prompt-level collection of Section 13 was stopped when the clause was found."),
    ("Collection was stopped after two small sectors, Energy and Utilities (14 of 88 exports, 44,463 answers), a decision taken before any row was examined;",
     "Collection was stopped after two small sectors, Energy and Utilities (14 of 88 exports, 44,463 answers), when the vendor's terms on automated use were found (Section 14), before any row was examined;"),
    ("| Ahrefs organic-keywords export, three carrier domains, US database | exported Oct 2025 |",
     "| DataForSEO ranked-keyword exports, three carrier domains, US database | exported 12 to 19 Oct 2025 |"),
    ("It holds 47,485 Google reviews of 378 retail locations of major US telecom carriers, obtained through DataForSEO under its license and exported on 8 September 2026, of which 37,193 carry text;",
     "It holds 47,485 Google reviews of 379 retail locations of major US telecom carriers, obtained through DataForSEO under its license and exported on 8 September 2026, of which 37,193 carry text, at 378 of the locations. The rule by which the locations were chosen was not recorded. The export holds between 1 and 201 reviews per location (median 145) and dates reviews only relatively (for example \"a year ago\"), so the period they cover is not known; where owner responses name a carrier, at 26 locations, they name five different carriers. It also holds"),
])
# the sentence continued "; and a 42,994-node telecom taxonomy ..." after the replaced clause
s = s.replace("It also holds and a 42,994-node telecom taxonomy", "It also holds a 42,994-node telecom taxonomy", 1)
if "It also holds a 42,994-node telecom taxonomy" not in s:
    raise SystemExit("REFUSE: the taxonomy clause did not join as expected")
P.write_text(s)
print(f"{len(s.split()):,} words")
