# The link check's annotation protocol (Section 6), as given to the two annotators

Each annotator was a separate AI agent, given only the instructions below (copied verbatim from the session record)
and the two sample files, which hold review text and are not released. Neither saw the paper, the hypotheses, the
analysis script or the other's judgments. The analysis script, `r2_link_check.py`, was committed before either
annotator's judgments were read.

- Annotator 1: launched 2026-10-15 03:38 UTC; general-purpose agent on the session's default model
  (Claude Opus 5.5). Judgments: `r2_judgments_A.csv`, `r2_judgments_B.csv`.
- Annotator 2: launched 2026-10-15 03:50 UTC; general-purpose agent on a Claude Sonnet model (requested by
  the alias "sonnet"). Judgments: `r2_judgments_A_annotator2.csv`, `r2_judgments_B_annotator2.csv`. A launch 18 seconds
  earlier through an agent definition that was not yet registered did not run; the instructions below are those of the
  launch that ran, and their judging criteria are the same as annotator 1's.

The released judgment files omit the annotators' free-text reasons, which in places name a company.

## Annotator 1

```
You are an annotator for a text-matching quality check. You have no other role. Do not open any file other than the two input files named below and the two output files you write; do not read any manuscript, analysis script, review report or note in the project, and do not search the web. Judge each item on its own text.

Input files (CSV, UTF-8, one row per item):
1. /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/03_DATA/raw/r2_link_check/sample_A_links.csv
   Columns: sample_id, rating (1 to 5 stars), review_text (a public Google review of a telecom retail store), linked_label (a topic label that an automatic matcher attached to the review because the label's words appear in the text), label_in_taxonomy (where the label sits in a topic taxonomy, from broad to narrow, which shows the sense the label is meant in).
   For each row decide whether the link is right: does the review actually talk about the topic the label names, in the sense its taxonomy path gives?
   - correct: a careful reader would say the review mentions or discusses that topic.
   - incorrect: the words occur but the review is not about that topic (another sense of the words, part of a name or an unrelated phrase, or a mention so incidental that it is not about the topic at all).
   - unclear: you cannot tell from the text.
2. /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/03_DATA/raw/r2_link_check/sample_B_waiting.csv
   Columns: sample_id, rating, review_text, matched_phrase (the words that matched a pattern for waiting).
   For each row decide:
   - waiting_complaint: yes if the reviewer complains about having to wait for something; no if the matched words are used otherwise (for example "can't wait to come back", "waiting for my friend" with no complaint); unclear if you cannot tell.
   - where: if waiting_complaint is yes, the main wait the reviewer complains about: in_store (in line, in the store, for an appointment at the store), phone_or_chat, order_or_delivery, repair_or_activation, other, or unclear. Leave empty otherwise.

Read every row in full. Work through the files in chunks so that you read all 200 and all 100 rows; do not sample, skip or guess rows you have not read.

Write two CSV files, with no review text in them:
- /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/04_ANALYSIS/review_demand/r2_judgments_A.csv with header: sample_id,judgment,reason
- /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/04_ANALYSIS/review_demand/r2_judgments_B.csv with header: sample_id,waiting_complaint,where,reason
"reason" is at most twelve words of your own, not quoted from the review, and must not contain any person's name.

Every sample_id must appear exactly once in the matching output file. When done, report only: the number of rows written to each file, and the counts of each judgment value (and of each "where" value), with no commentary on what they might mean.
```

## Annotator 2

```
You are a blind annotator. You judge items; you do not analyze, summarize or interpret results.

Blindness rules (absolute): open only the two input files and write only the two output files named below. Do not read manuscripts, analysis scripts, review reports, notes, or any other file in /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/04_ANALYSIS/review_demand/ (another annotator's judgments are there and you must not see them). Do not search the web. Read every row in full, in chunks if needed; never sample, skip or guess a row you have not read. When the text does not decide a question, use "unclear". Reasons are at most twelve words of your own, never quoted from the item, never containing a person's name.

Input files (CSV, UTF-8, one row per item):
1. /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/03_DATA/raw/r2_link_check/sample_A_links.csv
   Columns: sample_id, rating (1 to 5 stars), review_text (a public Google review of a telecom retail store), linked_label (a topic label an automatic matcher attached because the label's words appear in the text), label_in_taxonomy (where the label sits in a topic taxonomy, broad to narrow, showing the sense meant).
   For each row: does the review actually talk about the topic the label names, in the sense its taxonomy path gives?
   - correct: a careful reader would say the review mentions or discusses that topic.
   - incorrect: the words occur but the review is not about that topic (another sense, part of a name or unrelated phrase, or a mention so incidental it is not about the topic).
   - unclear: you cannot tell from the text.
2. /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/03_DATA/raw/r2_link_check/sample_B_waiting.csv
   Columns: sample_id, rating, review_text, matched_phrase (words that matched a pattern for waiting).
   For each row:
   - waiting_complaint: yes if the reviewer complains about having to wait for something; no if the words are used otherwise; unclear if you cannot tell.
   - where (only if waiting_complaint is yes): in_store, phone_or_chat, order_or_delivery, repair_or_activation, other, or unclear.

Write, with no review text, one row per sample_id, every id exactly once:
- /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/04_ANALYSIS/review_demand/r2_judgments_A_annotator2.csv with header: sample_id,judgment,reason
- /Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/04_ANALYSIS/review_demand/r2_judgments_B_annotator2.csv with header: sample_id,waiting_complaint,where,reason

When done, report only the row counts and the count of each judgment value (and each "where" value). No commentary.
```
