"""Round 10 supplement to analyze_reviews.py (Section 6): two checks the PhD examiner asked for.

1. Labels containing "wait" across the whole taxonomy, not only among labels mentioned in reviews.
2. The rank correlation between review mentions and monthly volume over every linkable label,
   counting labels no review mentions as zero, beside the published figure over mentioned labels.
Reads the same private exports as analyze_reviews.py (path as the first argument); prints aggregates only.
"""
import re
import sys
from pathlib import Path

import pandas as pd
from scipy.stats import spearmanr, kendalltau
from ufi.demand import TokenLinker

SRC = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
r = pd.read_excel(SRC / "Telecom_reviews_and_responses.xlsx", sheet_name="Reviews")
t = pd.read_excel(SRC / "Telecom_classification.xlsx", sheet_name="Taxonomy")
r = r[r["Review text"].notna()].copy()
r["text"] = r["Review text"].astype(str)

allt = t.copy()
allt["Label"] = allt["Label"].astype(str).str.strip()
w_all = allt[allt["Label"].str.contains("wait", case=False)]
print(f"taxonomy nodes: {len(allt)}; nodes whose label contains 'wait': {len(w_all)}; distinct such labels: {w_all['Label'].nunique()}; "
      f"their keywords: {int(w_all['Keywords'].sum())}; their monthly volume: {int(w_all['Monthly volume'].sum())}")
print("  labels:", sorted(w_all["Label"].unique())[:20])
qpat = re.compile(r"\b(?:wait(?:ed|ing)?|line|queue|appointment|check[- ]?in)\b", re.I)
q_all = allt[allt["Label"].str.contains(qpat)]
print(f"nodes whose label names waiting, lines, queues, appointments or check-in: {len(q_all)}; distinct labels {q_all['Label'].nunique()}; "
      f"monthly volume {int(q_all['Monthly volume'].sum())}")

t2 = t[t["Depth"] >= 2].copy()
t2["Label"] = t2["Label"].astype(str).str.strip()
STOP = {"telecom", "phone", "store", "stores", "service", "internet", "wireless", "overview", "reviews & ratings", "how-to & troubleshooting"}
lab = t2[((t2["Label"].str.split().str.len() >= 2) | (t2["Label"].str.len() >= 6)) & ~t2["Label"].str.lower().isin(STOP)]
per_label = lab.groupby("Label").agg(monthly_volume=("Monthly volume", "sum"))
linker = TokenLinker({label: [label] for label in per_label.index})
mentions = {k: 0 for k in per_label.index}
for txt in r["text"]:
    for i in linker.link(txt):
        mentions[i] += 1
m = pd.Series(mentions)
v = per_label["monthly_volume"].reindex(m.index)
rho_all, p_all = spearmanr(m, v)
tau_all, _ = kendalltau(m, v)
mm = m[m > 0]
rho_m, p_m = spearmanr(mm, v.reindex(mm.index))
print(f"linkable labels: {len(m)}; mentioned: {len(mm)}")
print(f"Spearman over all linkable labels (unmentioned = 0): {rho_all:+.3f} (p={p_all:.2g}); Kendall {tau_all:+.3f}")
print(f"Spearman over mentioned labels only (published): {rho_m:+.3f} (p={p_m:.2g})")

# 3. Branch-level comparison without double counting (TOIS panel E2). Each branch's volume is its own
#    depth-1 node volume (the taxonomy's volumes are hierarchical: a parent carries its children's).
#    Each label's review mentions are split across the branches where the label occurs, in proportion to
#    the number of the label's nodes in each branch.
t2["branch"] = t2["Path"].astype(str).str.split(".").str[1]
lab = lab.assign(branch=lab["Path"].astype(str).str.split(".").str[1])
node_counts = lab.groupby(["Label", "branch"]).size()
bm = {}
for label, cnt in m.items():
    if cnt == 0:
        continue
    nb = node_counts.loc[label]
    for br, k in nb.items():
        bm[br] = bm.get(br, 0) + cnt * k / nb.sum()
d1 = t[t["Depth"] == 1].copy()
d1["branch"] = d1["Path"].astype(str).str.split(".").str[1]
bv = dict(zip(d1["branch"], d1["Monthly volume"]))
names = dict(zip(d1["branch"], d1["Label"].astype(str)))
B = pd.DataFrame({"branch": list(bv), "review": [bm.get(b, 0) for b in bv], "volume": [bv[b] for b in bv]})
B["review_share"] = B["review"] / B["review"].sum()
B["volume_share"] = B["volume"] / B["volume"].sum()
B = B.sort_values("review_share", ascending=False)
print("\nbranch | review share (split) | own volume share")
for _, x in B.iterrows():
    print(f"  {names[x.branch][:34]:34} {x.review_share:6.1%} {x.volume_share:6.1%}")
rb, pb = spearmanr(B["review_share"], B["volume_share"])
print(f"branch-level Spearman, own volumes and split mentions: rho={rb:+.3f} p={pb:.2g} over {len(B)} branches")
top2 = B.head(2)
print(f"top two branches by review share: {', '.join(names[b] for b in top2.branch)}: {top2.review_share.sum():.1%} of mentions, {top2.volume_share.sum():.1%} of volume")
B.assign(branch=B["branch"].map(names))[["branch", "review_share", "volume_share"]].to_csv(Path(__file__).parent / "out" / "branch_shares_corrected.csv", index=False)
print("wrote out/branch_shares_corrected.csv")

# 4. Sensitivity of the branch correlation to how mentions are attributed (TOIS re-review): each label's
#    mentions to its modal branch (most of its nodes), with each branch's own volume.
modal = node_counts.groupby(level=0).idxmax().map(lambda x: x[1])
bm2 = {}
for label, cnt in m.items():
    if cnt:
        bm2[modal[label]] = bm2.get(modal[label], 0) + cnt
B2 = pd.DataFrame({"branch": list(bv), "review": [bm2.get(b, 0) for b in bv], "volume": [bv[b] for b in bv]})
r2, p2b = spearmanr(B2["review"] / B2["review"].sum(), B2["volume"] / B2["volume"].sum())
print(f"branch-level Spearman, own volumes and modal attribution: rho={r2:+.3f} p={p2b:.2g}")

# 5. Label-level correlations on each node's own volume (PhD re-examination N9). Volumes are hierarchical,
#    so a node's own volume is its volume less its children's; a label's volume is the sum of its nodes' own.
tt = t.copy()
tt["Path"] = tt["Path"].astype(str)
tt["parent_path"] = tt["Path"].str.rsplit(".", n=1).str[0]
child_sum = tt.groupby("parent_path")["Monthly volume"].sum()
tt["own_volume"] = (tt["Monthly volume"] - tt["Path"].map(child_sum).fillna(0)).clip(lower=0)
tt["Label"] = tt["Label"].astype(str).str.strip()
own = tt[tt["Node ID"].isin(lab["Node ID"])].groupby("Label")["own_volume"].sum().reindex(m.index).fillna(0)
r_own_m, p_own_m = spearmanr(m[m > 0], own.reindex(m[m > 0].index))
r_own_a, p_own_a = spearmanr(m, own)
print(f"\nlabel-level Spearman on own (non-nested) volumes: mentioned labels {r_own_m:+.3f} (p={p_own_m:.2g}); all linkable labels {r_own_a:+.3f} (p={p_own_a:.2g})")

# 6. Broader waiting count without "line" (PhD re-examination N10): wait, queue, appointment, check-in.
qp = re.compile(r"\b(?:wait(?:ed|ing|s)?|queue[sd]?|appointments?|check[- ]?in)\b", re.I)
qn = allt[allt["Label"].str.contains(qp)]
print(f"labels naming waiting, queues, appointments or check-in (no 'line'): nodes {len(qn)}; distinct {qn['Label'].nunique()}; monthly volume {int(qn['Monthly volume'].sum())}")
print("  examples:", sorted(qn["Label"].unique())[:25])

# 7. The fifteen split (PhD final review F5): which name waiting, which name a remedy.
wq = qn[qn["Label"].str.contains("wait", case=False)]
rq = qn[~qn["Label"].str.contains("wait", case=False)]
print(f"  of these, naming waiting: {len(wq)} labels, {int(wq['Monthly volume'].sum())} searches a month; "
      f"naming appointments, queues or callbacks: {len(rq)} labels, {int(rq['Monthly volume'].sum())} searches a month; "
      f"naming check-in: {int(qn['Label'].str.contains(r'check[- ]?in', case=False).sum())}")
for _, x in rq.sort_values("Monthly volume", ascending=False).iterrows():
    print(f"    {x['Label']}: {int(x['Monthly volume'])}")

# 8. Dataset sizes quoted in Section 6 (independent measurement, 14 October 2026: printed by no script before).
import gzip
allr = pd.read_excel(SRC / "Telecom_reviews_and_responses.xlsx", sheet_name="Reviews")
with gzip.open(SRC / "Telecom_keywords_full.csv.gz", "rt", errors="replace") as fh:
    nkw = sum(1 for _ in fh) - 1  # one header row
print(f"\ndataset sizes: review rows {len(allr)}, with text {int(allr['Review text'].notna().sum())}; "
      f"taxonomy nodes {len(t)}; keywords the taxonomy was built from {nkw}")

# 9. What the export's locations are (independent measurement: the selection rule is not stated). Counts only; no
# carrier is named in this output.
per_loc = allr.groupby("Business ID").size()
txt_locs = allr[allr["Review text"].notna()]["Business ID"].nunique()
# The carrier-name patterns are kept in a private file so that the released script names no company.
_pf = Path(__file__).resolve().parents[2] / "03_DATA/private/carrier_name_patterns.txt"
carrier_pats = [x for x in _pf.read_text().splitlines() if x.strip()] if _pf.exists() else []
resp = allr["Owner response"].astype(str)
named = {i: set(allr.loc[resp.str.contains(p, case=False, regex=True, na=False), "Business ID"]) for i, p in enumerate(carrier_pats)}
any_named = set().union(*named.values())
dated = allr["Review date"].astype(str).str.contains(r"\d{4}", regex=True).sum()
print(f"locations in the export {per_loc.size}; with at least one text review {txt_locs}; reviews per location min {per_loc.min()}, "
      f"median {int(per_loc.median())}, max {per_loc.max()}; reviews with an absolute date {dated} of {len(allr)} (the rest relative, e.g. 'a year ago'); "
      f"locations whose owner responses name a carrier {len(any_named)}, naming {sum(1 for v in named.values() if v)} different carriers")

# 10. Intervals for the Measurement 2 headlines (independent measurement: intervals on every headline). Percentile
# bootstrap, fixed seed: labels resampled for the label-level correlations, branches for the branch-level ones;
# Wilson intervals for the waiting-pattern shares.
import math
import random
rng = random.Random(20261015)


def boot(xs, ys, reps):
    n, out = len(xs), []
    for _ in range(reps):
        idx = [rng.randrange(n) for _ in range(n)]
        r_ = spearmanr([xs[i] for i in idx], [ys[i] for i in idx]).statistic
        if r_ == r_:
            out.append(r_)
    out.sort()
    return out[int(0.025 * len(out))], out[int(0.975 * len(out)) - 1]


def wilson(k, n, z=1.96):
    p = k / n
    c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return c - h, c + h


lo, hi = boot(list(mm.values), list(v.reindex(mm.index).values), 10_000)
print(f"\n== 10. Intervals\n  label-level Spearman, mentioned labels: {rho_m:+.3f} [95% {lo:+.3f}, {hi:+.3f}] ({len(mm)} labels, 10,000 resamples)")
lo, hi = boot(list(m.values), list(v.values), 2_000)
print(f"  label-level Spearman, all linkable labels: {rho_all:+.3f} [95% {lo:+.3f}, {hi:+.3f}] ({len(m)} labels, 2,000 resamples)")
lo, hi = boot(list(B["review_share"]), list(B["volume_share"]), 10_000)
print(f"  branch-level Spearman, split attribution: {rb:+.3f} [95% {lo:+.3f}, {hi:+.3f}] (17 branches)")
lo, hi = boot(list(B2["review"] / B2["review"].sum()), list(B2["volume"] / B2["volume"].sum()), 10_000)
print(f"  branch-level Spearman, modal attribution: {r2:+.3f} [95% {lo:+.3f}, {hi:+.3f}] (17 branches)")
wpat = re.compile(r"\b(?:wait(?:ed|ing)?|hours? (?:in|at) (?:line|the store)|long line)\b", re.I)
neg = r[r["Rating"] <= 2]
five = r[r["Rating"] == 5]
kn, kf = int(neg["text"].str.contains(wpat).sum()), int(five["text"].str.contains(wpat).sum())
print(f"  waiting pattern: one- and two-star {kn}/{len(neg)} = {kn / len(neg):.1%} [Wilson 95% {wilson(kn, len(neg))[0]:.1%}, {wilson(kn, len(neg))[1]:.1%}]; "
      f"five-star {kf}/{len(five)} = {kf / len(five):.1%} [{wilson(kf, len(five))[0]:.1%}, {wilson(kf, len(five))[1]:.1%}]")

# 11. Sensitivity to link precision (added after the link check of 15 October 2026, so post hoc and labelled as such).
# The blind link check found single-word labels linked correctly about half the time and multi-word labels almost
# always (r2_link_check.py). The Measurement 2 correlations are recomputed with multi-word labels only.
lab_mw = lab[lab["Label"].str.split().str.len() >= 2]
linker_mw = TokenLinker({label: [label] for label in lab_mw["Label"].unique()})
ment_mw = {k: 0 for k in lab_mw["Label"].unique()}
linked_mw = 0
for txt in r["text"]:
    ids = linker_mw.link(txt)
    linked_mw += bool(ids)
    for i in ids:
        ment_mw[i] += 1
m_mw = pd.Series(ment_mw)
v_mw = lab_mw.groupby("Label")["Monthly volume"].sum().reindex(m_mw.index)
mm_mw = m_mw[m_mw > 0]
ra, pa = spearmanr(m_mw, v_mw)
rm_, pm_ = spearmanr(mm_mw, v_mw.reindex(mm_mw.index))
lo1, hi1 = boot(list(mm_mw.values), list(v_mw.reindex(mm_mw.index).values), 10_000)
nc_mw = lab_mw.groupby(["Label", "branch"]).size()
bmw = {}
for label, cnt in m_mw.items():
    if cnt:
        nb = nc_mw.loc[label]
        for br, k in nb.items():
            bmw[br] = bmw.get(br, 0) + cnt * k / nb.sum()
Bm = pd.DataFrame({"branch": list(bv), "review": [bmw.get(b, 0) for b in bv], "volume": [bv[b] for b in bv]})
rbm, pbm = spearmanr(Bm["review"] / Bm["review"].sum(), Bm["volume"] / Bm["volume"].sum())
lo2, hi2 = boot(list(Bm["review"] / Bm["review"].sum()), list(Bm["volume"] / Bm["volume"].sum()), 10_000)
modal_mw = nc_mw.groupby(level=0).idxmax().map(lambda x: x[1])
bmm = {}
for label, cnt in m_mw.items():
    if cnt:
        bmm[modal_mw[label]] = bmm.get(modal_mw[label], 0) + cnt
Bmm = pd.DataFrame({"branch": list(bv), "review": [bmm.get(b, 0) for b in bv], "volume": [bv[b] for b in bv]})
rbmm, pbmm = spearmanr(Bmm["review"] / Bmm["review"].sum(), Bmm["volume"] / Bmm["volume"].sum())
top = Bm.assign(rs=Bm["review"] / Bm["review"].sum(), vs=Bm["volume"] / Bm["volume"].sum()).sort_values("rs", ascending=False).head(3)
print(f"\n== 11. Multi-word labels only (post hoc sensitivity)\n  linkable labels {len(m_mw)}; reviews linked {linked_mw} of {len(r)}; labels mentioned {len(mm_mw)}")
print(f"  label-level Spearman: mentioned labels {rm_:+.3f} [95% {lo1:+.3f}, {hi1:+.3f}] (p={pm_:.2g}); all linkable labels {ra:+.3f} (p={pa:.2g})")
print(f"  branch-level Spearman, own volumes: split {rbm:+.3f} [95% {lo2:+.3f}, {hi2:+.3f}] (p={pbm:.2g}); modal {rbmm:+.3f} (p={pbmm:.2g})")
print("  three largest branches by review share: " + "; ".join(f"{names[b][:30]} {x.rs:.1%} of mentions, {x.vs:.1%} of volume" for b, x in zip(top.branch, top.itertuples())))

# 12. Can the label-level intervals be made to respect that labels are not independent? (Independent measurement of
# 15 October 2026: the intervals of section 10 resample labels as if they were independent, though labels share reviews
# and nest in one taxonomy; it suggested resampling reviews instead.) Tried both ways a bootstrap over reviews can be
# done: drawing reviews with replacement, and reweighting every review with an Exponential(1) weight (the Bayesian
# bootstrap, Rubin 1981). Neither is valid here, and neither is reported in the paper: label counts are small integers
# with many ties, and resampling or reweighting reviews changes those ties (and, when drawing, the set of mentioned
# labels), which moves a rank correlation over counts systematically, so the replicates are not centred on the
# estimate. This section prints the diagnostic: each method's interval and the share of replicates below the estimate
# (about one half for a usable bootstrap). Unit weights reproduce the point estimates of sections 2 and 3 (checked).
import numpy as np


def incidence(link, labels, texts):
    li = {l: k for k, l in enumerate(labels)}
    rv, lb = [], []
    for j, txt in enumerate(texts):
        for i in link(txt):
            rv.append(j)
            lb.append(li[i])
    return np.array(rv), np.array(lb)


def review_boot(vol, rv, lb, nrev, nlab, reps, how, seed=20261015):
    g = np.random.default_rng(seed)
    out = {"mentioned": [], "all": []}
    for rep in range(reps + 1):
        if rep == 0:
            w = np.ones(nrev)
        elif how == "draw":
            w = np.bincount(g.integers(0, nrev, nrev), minlength=nrev)
        else:
            w = g.exponential(1.0, nrev)
        cnt = np.bincount(lb, weights=w[rv], minlength=nlab)
        pos = cnt > 0
        vals = {"mentioned": spearmanr(cnt[pos], vol[pos]).statistic, "all": spearmanr(cnt, vol).statistic}
        for k, x in vals.items():
            (out[k].append(x) if rep else out.setdefault("point_" + k, x))
    return out


labels = list(m.index)
vol = v.reindex(labels).to_numpy(dtype=float)
rv, lb = incidence(linker.link, labels, r["text"])
print("\n== 12. Bootstraps over reviews (diagnostic only; not valid for these statistics, see the comment above)")
for how, name in (("draw", "reviews drawn with replacement"), ("weight", "every review reweighted (Bayesian bootstrap)")):
    o = review_boot(vol, rv, lb, len(r), len(labels), 2_000, how)
    assert abs(o["point_mentioned"] - rho_m) < 1e-9 and abs(o["point_all"] - rho_all) < 1e-9
    for k, est in (("mentioned", rho_m), ("all", rho_all)):
        xs = np.sort(np.array(o[k]))
        lo, hi = xs[int(0.025 * len(xs))], xs[int(0.975 * len(xs)) - 1]
        print(f"  {name}, {k} labels: estimate {est:+.3f}; replicates' 95% range [{lo:+.3f}, {hi:+.3f}]; "
              f"share of replicates below the estimate {np.mean(xs < est):.0%}")

# 13. Anonymized per-label counts for release (independent measurement of 15 October 2026: Measurement 2's numbers
# traced only to saved outputs of scripts that need the licensed export). One row per linkable label in this script's
# order, with no label name and no review text: the label's number of words, its review mentions under the full
# linker and, for multi-word labels, under the multi-word linker of section 11, the ranks (not the values) of its
# summed and own monthly volumes, its node count in each top-level branch, and its place in section 11's own order of
# labels (which the bootstrap of section 11 follows). Branches are given by name with their
# own-volume share. m2_from_counts.py recomputes sections 2 to 5, 10 and 11 from these two files alone.
import csv
from scipy.stats import rankdata
HERE = Path(__file__).resolve().parent
bid = {b: f"b{k + 1:02d}" for k, b in enumerate(bv)}
vrank, orank = rankdata(v.reindex(m.index).to_numpy(dtype=float)), rankdata(own.reindex(m.index).to_numpy(dtype=float))
with (HERE / "m2_label_counts.csv").open("w", newline="") as f:
    wtr = csv.writer(f)
    wtr.writerow(["label_id", "words", "mentions", "mentions_multiword_linker", "multiword_order", "volume_rank",
                  "own_volume_rank", "branch_nodes"])
    mw_pos = {label: k for k, label in enumerate(m_mw.index)}
    for k, label in enumerate(m.index):
        nb = node_counts.loc[label]
        wtr.writerow([f"L{k + 1:05d}", len(label.split()), int(m[label]),
                      int(m_mw[label]) if label in mw_pos else "", mw_pos.get(label, ""), f"{vrank[k]:g}", f"{orank[k]:g}",
                      ";".join(f"{bid[br]}:{int(c)}" for br, c in nb.items())])
tot = sum(bv.values())
with (HERE / "m2_branches.csv").open("w", newline="") as f:
    wtr = csv.writer(f)
    wtr.writerow(["branch_id", "branch", "own_volume_share"])
    for b in bv:
        wtr.writerow([bid[b], names[b], repr(bv[b] / tot)])
print(f"\n== 13. wrote m2_label_counts.csv ({len(m)} labels) and m2_branches.csv ({len(bv)} branches) beside this script")
