"""Measurement 2 (Section 6) recomputed from the released, anonymized per-label counts, without the licensed export.

supplement_r10.py (section 13) wrote, from the licensed review export and the taxonomy:
  m2_label_counts.csv  one row per linkable label, in that script's order, with no label name and no review text:
                       words in the label; review mentions under the full linker; for multi-word labels, mentions under
                       the multi-word linker, and their order there (section 11); the ranks, not the values, of the
                       label's summed and own monthly volumes; its node count in each top-level branch
  m2_branches.csv      the 17 top-level branches, by name, with each branch's own-volume share
Rank correlations depend only on ranks, so every Spearman and Kendall statistic, p-value and bootstrap interval below
equals the one supplement_r10.py prints from the private data (sections 2 to 5, 10 and 11; same seed, same order of
resampling). What needs the review text (the linking itself, the waiting pattern, dataset sizes) is printed only by
the scripts that read the export.

Usage, in this folder: python3 m2_from_counts.py
"""
import csv
import random
from pathlib import Path

from scipy.stats import kendalltau, spearmanr

HERE = Path(__file__).resolve().parent
L = list(csv.DictReader((HERE / "m2_label_counts.csv").open()))
BR = list(csv.DictReader((HERE / "m2_branches.csv").open()))
bv = {b["branch_id"]: float(b["own_volume_share"]) for b in BR}
names = {b["branch_id"]: b["branch"] for b in BR}
ment = [int(x["mentions"]) for x in L]
vrank = [float(x["volume_rank"]) for x in L]
orank = [float(x["own_volume_rank"]) for x in L]
nodes = [{k: int(c) for k, c in (p.split(":") for p in x["branch_nodes"].split(";"))} for x in L]
multi = [int(x["words"]) >= 2 for x in L]

# section 2: label level, summed volumes
rho_all, p_all = spearmanr(ment, vrank)
tau_all = kendalltau(ment, vrank).statistic
mi = [k for k in range(len(L)) if ment[k] > 0]
rho_m, p_m = spearmanr([ment[k] for k in mi], [vrank[k] for k in mi])
print(f"linkable labels: {len(L)}; mentioned: {len(mi)}")
print(f"Spearman over all linkable labels (unmentioned = 0): {rho_all:+.3f} (p={p_all:.2g}); Kendall {tau_all:+.3f}")
print(f"Spearman over mentioned labels only (published): {rho_m:+.3f} (p={p_m:.2g})")


def branch_split(counts, rows):
    out = {}
    for k in rows:
        if counts[k]:
            tot = sum(nodes[k].values())
            for b, c in nodes[k].items():
                out[b] = out.get(b, 0) + counts[k] * c / tot
    return out


def branch_modal(counts, rows):
    out = {}
    for k in rows:
        if counts[k]:
            # the branch holding most of the label's nodes; ties go to the first branch in the private script's order
            b = max(nodes[k].items(), key=lambda bc: bc[1])[0]
            out[b] = out.get(b, 0) + counts[k]
    return out


def shares(d):
    tot = sum(d.get(b, 0) for b in bv)
    return [d.get(b, 0) / tot for b in bv]


# section 3: branch level, split attribution, sorted as the private script sorts its table
bm = branch_split(ment, range(len(L)))
rs, vs = shares(bm), [bv[b] / sum(bv.values()) for b in bv]
B = sorted(zip(bv, rs, vs), key=lambda t: -t[1])
print("\nbranch | review share (split) | own volume share")
for b, r_, v_ in B:
    print(f"  {names[b][:34]:34} {r_:6.1%} {v_:6.1%}")
rb, pb = spearmanr([t[1] for t in B], [t[2] for t in B])
print(f"branch-level Spearman, own volumes and split mentions: rho={rb:+.3f} p={pb:.2g} over {len(B)} branches")
print(f"top two branches by review share: {', '.join(names[t[0]] for t in B[:2])}: "
      f"{B[0][1] + B[1][1]:.1%} of mentions, {B[0][2] + B[1][2]:.1%} of volume")

# section 4: modal attribution
r2v = shares(branch_modal(ment, range(len(L))))
r2, p2b = spearmanr(r2v, vs)
print(f"branch-level Spearman, own volumes and modal attribution: rho={r2:+.3f} p={p2b:.2g}")

# section 5: own (non-nested) volumes
r_own_m, p_own_m = spearmanr([ment[k] for k in mi], [orank[k] for k in mi])
r_own_a, p_own_a = spearmanr(ment, orank)
print(f"\nlabel-level Spearman on own (non-nested) volumes: mentioned labels {r_own_m:+.3f} (p={p_own_m:.2g}); "
      f"all linkable labels {r_own_a:+.3f} (p={p_own_a:.2g})")

# section 10: intervals, the private script's seed and order
rng = random.Random(20261015)


def boot(xs, ys, reps):
    n, out = len(xs), []
    for _ in range(reps):
        idx = [rng.randrange(n) for _ in range(n)]
        r_ = spearmanr([xs[i] for i in idx], [ys[i] for i in idx]).statistic
        if r_ == r_:
            out.append(r_)
    out.sort()
    return out[int(0.025 * len(out))], out[int(0.975 * len(out)) - 1]


lo, hi = boot([ment[k] for k in mi], [vrank[k] for k in mi], 10_000)
print(f"\n== 10. Intervals\n  label-level Spearman, mentioned labels: {rho_m:+.3f} [95% {lo:+.3f}, {hi:+.3f}] ({len(mi)} labels, 10,000 resamples)")
lo, hi = boot(ment, vrank, 2_000)
print(f"  label-level Spearman, all linkable labels: {rho_all:+.3f} [95% {lo:+.3f}, {hi:+.3f}] ({len(L)} labels, 2,000 resamples)")
lo, hi = boot([t[1] for t in B], [t[2] for t in B], 10_000)
print(f"  branch-level Spearman, split attribution: {rb:+.3f} [95% {lo:+.3f}, {hi:+.3f}] (17 branches)")
lo, hi = boot(r2v, vs, 10_000)
print(f"  branch-level Spearman, modal attribution: {r2:+.3f} [95% {lo:+.3f}, {hi:+.3f}] (17 branches)")

# section 11: multi-word labels only (post hoc), mentions under the multi-word linker
mw = sorted((k for k in range(len(L)) if multi[k]), key=lambda k: int(L[k]["multiword_order"]))  # section 11's order
cm = {k: int(L[k]["mentions_multiword_linker"]) for k in mw}
mmw = [k for k in mw if cm[k] > 0]
ra, pa = spearmanr([cm[k] for k in mw], [vrank[k] for k in mw])
rm_, pm_ = spearmanr([cm[k] for k in mmw], [vrank[k] for k in mmw])
lo1, hi1 = boot([cm[k] for k in mmw], [vrank[k] for k in mmw], 10_000)
cnt_mw = [cm.get(k, 0) for k in range(len(L))]
Bm = shares(branch_split(cnt_mw, mw))
rbm, pbm = spearmanr(Bm, vs)
lo2, hi2 = boot(Bm, vs, 10_000)
rbmm, pbmm = spearmanr(shares(branch_modal(cnt_mw, mw)), vs)
top = sorted(zip(bv, Bm, vs), key=lambda t: -t[1])[:3]
print(f"\n== 11. Multi-word labels only (post hoc sensitivity)\n  linkable labels {len(mw)}; labels mentioned {len(mmw)}")
print(f"  label-level Spearman: mentioned labels {rm_:+.3f} [95% {lo1:+.3f}, {hi1:+.3f}] (p={pm_:.2g}); all linkable labels {ra:+.3f} (p={pa:.2g})")
print(f"  branch-level Spearman, own volumes: split {rbm:+.3f} [95% {lo2:+.3f}, {hi2:+.3f}] (p={pbm:.2g}); modal {rbmm:+.3f} (p={pbmm:.2g})")
print("  three largest branches by review share: " + "; ".join(f"{names[b][:30]} {r_:.1%} of mentions, {v_:.1%} of volume" for b, r_, v_ in top))
