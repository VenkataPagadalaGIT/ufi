"""Samples for checking Measurement 2's two text-matching steps (independent measurement, 14 October 2026: "every
Measurement 2 statistic rests on exact-match links whose precision was never measured").

Rebuilds the links exactly as analyze_reviews.py does (same label filter, same TokenLinker, same waiting pattern), then
draws with a fixed seed:
  A. 200 links, uniformly from all (review, label) links;
  B. 100 one- and two-star reviews that match the waiting pattern, uniformly.
Writes the sample with review text to 03_DATA/raw/r2_link_check/ (git-ignored: the review export is licensed; no
reviewer name is written) and prints the population sizes. Judgments are recorded against the sample ids only.
Also writes r2_sample_A_label_words.csv beside this script (sample id and the number of words in the linked label, no
label and no text), which r2_link_check.py uses for its precision by label length when the private sample is absent.

Usage: python3 r2_link_sample.py <folder holding the Omniscite telecom exports>
"""
import csv
import random
import re
import sys
from pathlib import Path

import pandas as pd

from ufi.demand import TokenLinker

SRC = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
HERE = Path(__file__).resolve().parent
DST = HERE.parents[1] / "03_DATA/raw/r2_link_check"
SEED = 20261014

r = pd.read_excel(SRC / "Telecom_reviews_and_responses.xlsx", sheet_name="Reviews")
t = pd.read_excel(SRC / "Telecom_classification.xlsx", sheet_name="Taxonomy")
r = r[r["Review text"].notna()].copy().reset_index(drop=True)
r["text"] = r["Review text"].astype(str)
names = {str(p): str(l) for p, l in zip(t["Path"], t["Label"])}
t = t[t["Depth"] >= 2].copy()
t["Label"] = t["Label"].astype(str).str.strip()
STOP = {"telecom", "phone", "store", "stores", "service", "internet", "wireless", "overview", "reviews & ratings", "how-to & troubleshooting"}
lab = t[((t["Label"].str.split().str.len() >= 2) | (t["Label"].str.len() >= 6)) & ~t["Label"].str.lower().isin(STOP)]
linker = TokenLinker({label: [label] for label in lab["Label"].unique()})


def context(label):
    """The taxonomy path of the label's shallowest node, as names, so a reader can see which sense is meant."""
    rows = lab[lab["Label"] == label].sort_values("Depth")
    path = str(rows.iloc[0]["Path"]).split(".")
    return " > ".join(names.get(".".join(path[:i]), "?") for i in range(2, len(path) + 1))


links = [(i, lbl) for i, txt in enumerate(r["text"]) for lbl in sorted(linker.link(txt))]
pat = re.compile(r"\b(?:wait(?:ed|ing)?|hours? (?:in|at) (?:line|the store)|long line)\b", re.I)
neg_wait = [i for i in r.index if r.at[i, "Rating"] <= 2 and pat.search(r.at[i, "text"])]
print(f"links: {len(links)} over {len(set(i for i, _ in links))} reviews; one- and two-star reviews matching the waiting pattern: {len(neg_wait)}")

rng = random.Random(SEED)
a = rng.sample(links, 200)
b = rng.sample(neg_wait, 100)
DST.mkdir(parents=True, exist_ok=True)
with (DST / "sample_A_links.csv").open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["sample_id", "rating", "review_text", "linked_label", "label_in_taxonomy"])
    for k, (i, lbl) in enumerate(a, 1):
        w.writerow([f"A{k:03d}", int(r.at[i, "Rating"]), r.at[i, "text"], lbl, context(lbl)])
with (DST / "sample_B_waiting.csv").open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["sample_id", "rating", "review_text", "matched_phrase"])
    for k, i in enumerate(b, 1):
        w.writerow([f"B{k:03d}", int(r.at[i, "Rating"]), r.at[i, "text"], pat.search(r.at[i, "text"]).group(0)])
with (HERE / "r2_sample_A_label_words.csv").open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["sample_id", "label_word_count"])
    for k, (i, lbl) in enumerate(a, 1):
        w.writerow([f"A{k:03d}", len(lbl.split())])
print(f"wrote sample_A_links.csv (200) and sample_B_waiting.csv (100) to 03_DATA/raw/r2_link_check/, and "
      f"r2_sample_A_label_words.csv; seed {SEED}")
