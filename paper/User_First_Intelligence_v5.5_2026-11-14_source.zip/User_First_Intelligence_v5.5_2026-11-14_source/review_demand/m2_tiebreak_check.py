"""Section 6.1's modal attribution gives each label to the branch holding most of its nodes, and ties went to the first
branch in the private script's order (m2_from_counts.py, branch_modal). This checks how much that arbitrary order matters: the
same correlation with ties broken at random, 2,000 draws, seed 20261103. Written 3 November 2026 after an independent
assessor found the tie-break undisclosed. Runs on the released anonymized counts. Usage: python3 m2_tiebreak_check.py"""
import csv
import random
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.stats import spearmanr

HERE = Path(__file__).resolve().parent
L = list(csv.DictReader((HERE / "m2_label_counts.csv").open()))
B = list(csv.DictReader((HERE / "m2_branches.csv").open()))
vs = [float(b["own_volume_share"]) for b in B]
ids = [b["branch_id"] for b in B]
nodes = [dict((x.split(":")[0], int(x.split(":")[1])) for x in r["branch_nodes"].split(";") if x) for r in L]
OUT = []


def say(s):
    print(s)
    OUT.append(s)


for label, col, keep in (("all links", "mentions", lambda r: True), ("multi-word labels only", "mentions_multiword_linker", lambda r: int(r["words"]) >= 2)):
    rows = [(int(r[col]), n) for r, n in zip(L, nodes) if keep(r) and int(r[col]) > 0 and n]
    fixed, tied = defaultdict(float), []
    for c, n in rows:
        top = max(n.values())
        best = [b for b, v in n.items() if v == top]
        if len(best) == 1:
            fixed[best[0]] += c
        else:
            tied.append((c, best))
    rng = random.Random(20261103)
    vals = []
    for _ in range(2000):
        t = dict(fixed)
        for c, best in tied:
            b = rng.choice(best)
            t[b] = t.get(b, 0) + c
        tot = sum(t.values())
        vals.append(spearmanr([t.get(i, 0) / tot for i in ids], vs).statistic)
    say(f"{label}: {len(rows)} labels with mentions, {len(tied)} tied between branches holding {sum(c for c, _ in tied):,} of {sum(c for c, _ in rows):,} mentions; "
        f"modal Spearman under random tie-breaks: median {np.median(vals):+.4f}, 95% of draws {np.percentile(vals, 2.5):+.4f} to {np.percentile(vals, 97.5):+.4f}")
(HERE / "m2_tiebreak_check_output.txt").write_text("\n".join(OUT) + "\n")
