"""Section 6.1 compares a complaint with the taxonomy's labels. An independent assessor (3 November 2026) asked whether the
keywords themselves, not only the labels, show the same thing. Reads the licensed keyword file (not released) and prints only
aggregates. Usage: python3 waiting_keywords_check.py <folder holding Telecom_keywords_full.csv.gz>"""
import csv
import gzip
import re
import sys
from collections import Counter
from pathlib import Path

src = Path(sys.argv[1] if len(sys.argv) > 1 else Path.home() / "Desktop/Omniscite_Exports") / "Telecom_keywords_full.csv.gz"
HERE = Path(__file__).resolve().parent
OUT = []


def say(s):
    print(s)
    OUT.append(s)


WAIT = re.compile(r"\bwait(s|ed|ing|time|times)?\b|\bwaittime\b|\blong lines?\b|\bhours? in line\b", re.I)
STORE = re.compile(r"\b(store|stores|in store|in-store|shop|location|locations|retail)\b", re.I)
TELECOM_OTHER = re.compile(r"\bcall waiting\b|\bwait(ing)? ?list\b|\bwaitlist\b", re.I)
total, vol_total, hits = 0, 0, []
sources = Counter()
with gzip.open(src, "rt", errors="replace") as f:
    for r in csv.DictReader(f):
        total += 1
        v = int(float(r["monthly_volume"] or 0))
        vol_total += v
        sources["ranked keywords of three carrier domains" if r["source"].startswith("ranked:") else r["source"]] += 1
        if WAIT.search(r["keyword"]):
            hits.append((r["keyword"], v))
say(f"keywords {total:,}; summed monthly volume {vol_total:,}; source column: " + ", ".join(f"{k} {n:,}" for k, n in sources.most_common()))
nv = sum(v for _, v in hits)
say(f"keywords matching the waiting pattern: {len(hits):,}, with {nv:,} monthly searches ({100 * nv / vol_total:.3f}% of the file's volume)")
other = [(k, v) for k, v in hits if TELECOM_OTHER.search(k)]
say(f"  of those, call waiting or waitlists: {len(other):,}, with {sum(v for _, v in other):,} searches")
store = [(k, v) for k, v in hits if STORE.search(k) and not TELECOM_OTHER.search(k)]
say(f"  of those, naming a store, shop or location: {len(store):,}, with {sum(v for _, v in store):,} searches")
(HERE / "waiting_keywords_check_output.txt").write_text("\n".join(OUT) + "\n")
