"""Measurement 2's text matching, checked: precision of the review-to-label links and of the waiting pattern, from two
blind annotators (separate AI agents on different models, given only the samples of r2_link_sample.py and a fixed
protocol), with their agreement. Written before either annotator's judgments were read.

Inputs: r2_judgments_A.csv, r2_judgments_B.csv (annotator 1), r2_judgments_A_annotator2.csv,
r2_judgments_B_annotator2.csv (annotator 2), r2_sample_A_label_words.csv (written by r2_link_sample.py: the number of
words in each sampled link's label), and the saved outputs of r2_link_sample.py and analyze_reviews.py for the
population sizes and the 14.0% share of one- and two-star reviews matching the waiting pattern, all in this folder.
Prints the results; reads no review text.
"""
import csv
import math
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent


def load(name, key):
    rows = {r["sample_id"]: r for r in csv.DictReader((HERE / name).open())}
    return {k: v[key].strip().lower() for k, v in rows.items()}, rows


def wilson(k, n, z=1.96):
    if n == 0:
        return float("nan"), float("nan")
    p = k / n
    c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return c - h, c + h


def kappa(a, b):
    ids = sorted(set(a) & set(b))
    cats = sorted(set(a[i] for i in ids) | set(b[i] for i in ids))
    n = len(ids)
    po = sum(a[i] == b[i] for i in ids) / n
    ca, cb = Counter(a[i] for i in ids), Counter(b[i] for i in ids)
    pe = sum(ca[c] * cb[c] for c in cats) / (n * n)
    return (po - pe) / (1 - pe) if pe < 1 else float("nan"), po, n


def precision_report(label, j, pos, neg):
    c = Counter(j.values())
    k, n = c[pos], c[pos] + c[neg]
    lo, hi = wilson(k, n)
    strict_n = sum(c.values())
    slo, shi = wilson(k, strict_n)
    print(f"  {label}: {dict(c)}; precision {k}/{n} = {k / n:.1%} [Wilson 95% {lo:.1%}, {hi:.1%}] excluding unclear; "
          f"{k}/{strict_n} = {k / strict_n:.1%} [{slo:.1%}, {shi:.1%}] counting unclear as wrong")
    return k / n


# Population sizes, read from the saved outputs of the scripts that see the licensed export (both released here).
import re
_pop = re.search(r"links: (\d+) over \d+ reviews; one- and two-star reviews matching the waiting pattern: (\d+)",
                 (HERE / "r2_link_sample_output.txt").read_text())
N_LINKS, N_WAIT = int(_pop.group(1)), int(_pop.group(2))
_neg = re.search(r"1-2 star reviews: (\d+); mentioning waiting: (\d+)", (HERE / "analyze_reviews_output.txt").read_text())
print(f"== A. Review-to-label links (200 sampled uniformly from {N_LINKS:,} links)")
a1, _ = load("r2_judgments_A.csv", "judgment")
a2, _ = load("r2_judgments_A_annotator2.csv", "judgment")
pa1 = precision_report("annotator 1", a1, "correct", "incorrect")
pa2 = precision_report("annotator 2", a2, "correct", "incorrect")
both = [i for i in a1 if a1[i] == a2.get(i) and a1[i] in ("correct", "incorrect")]
kb = sum(a1[i] == "correct" for i in both)
lo, hi = wilson(kb, len(both))
print(f"  items the two annotators judged alike (correct or incorrect): {len(both)}; precision on them {kb}/{len(both)} = {kb / len(both):.1%} [{lo:.1%}, {hi:.1%}]")
k_, po, n = kappa(a1, a2)
print(f"  agreement: {po:.1%} of {n} items; Cohen's kappa {k_:.2f}")

print(f"\n== B. Waiting-pattern matches (100 sampled uniformly from the {N_WAIT:,} one- and two-star matches)")
b1, rows1 = load("r2_judgments_B.csv", "waiting_complaint")
b2, rows2 = load("r2_judgments_B_annotator2.csv", "waiting_complaint")
pb1 = precision_report("annotator 1", b1, "yes", "no")
pb2 = precision_report("annotator 2", b2, "yes", "no")
k_, po, n = kappa(b1, b2)
print(f"  agreement: {po:.1%} of {n} items; Cohen's kappa {k_:.2f}")
for lab, rows, j in (("annotator 1", rows1, b1), ("annotator 2", rows2, b2)):
    where = Counter(rows[i]["where"].strip().lower() for i in rows if j[i] == "yes")
    yes = sum(where.values())
    k = where.get("in_store", 0)
    lo, hi = wilson(k, yes)
    print(f"  {lab}, where the complained-of wait was: {dict(where)}; in store {k}/{yes} = {k / yes:.1%} [{lo:.1%}, {hi:.1%}]")
WAIT_MATCH = round(int(_neg.group(2)) / int(_neg.group(1)), 3)  # 924 of 6,620 one- and two-star reviews: 0.140
for lab, p in (("annotator 1", pb1), ("annotator 2", pb2)):
    print(f"  implied share of one- and two-star reviews complaining about waiting ({lab}): "
          f"{WAIT_MATCH:.1%} x {p:.1%} = {WAIT_MATCH * p:.1%}")

print("\n== C. Link precision by label length (single-word against multi-word labels)")
words = {r["sample_id"]: int(r["label_word_count"]) for r in csv.DictReader((HERE / "r2_sample_A_label_words.csv").open())}
for name, j in (("annotator 1", a1), ("annotator 2", a2)):
    for kind, cond in (("single-word", lambda w: w == 1), ("multi-word", lambda w: w >= 2)):
        c = Counter(j[s] for s in j if cond(words[s]))
        n = c["correct"] + c["incorrect"]
        lo, hi = wilson(c["correct"], n)
        print(f"  {name}, {kind} labels: {c['correct']}/{n} = {c['correct'] / n:.1%} [{lo:.1%}, {hi:.1%}]")
