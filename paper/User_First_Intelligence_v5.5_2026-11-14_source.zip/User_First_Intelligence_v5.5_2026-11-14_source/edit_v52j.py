"""Version 5.2, Section 13: the two studies registered on 14 and 15 October 2026 (the retrospective test of the score,
Study R1, and the second-domain protocol for Measurement 1), both fixed and stamped with OpenTimestamps before any
outcome or reading under them; and Section 13.1 tightened and tied to the measurements (independent measurement,
writing: "off-thread material is included (Section 13.1 ...)"). The directions, the Pew figures and the Costco
material the author asked for are kept; the Costco detail about cleaning up product data is dropped as not needed for
the direction."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()
if 'A retrospective test of the score on this deployment, fixed before its outcomes were read.' in s:  # this script inserts the Study R1 paragraph; later edits changed its wording, so check for the passage itself
    raise SystemExit("REFUSE: already applied (the Study R1 paragraph is present)")


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:  # already applied: an insertion keeps its anchor, so a second run would insert twice
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("**An annotation study**, two graders independent of the author,",
     "**A retrospective test of the score on this deployment, fixed before its outcomes were read.** Every one of the 372 geographic codes in service received a page, so the score cannot be tested here as a guide to which pages to build, but it can be tested as a ranking: whether, from data dated nine months before launch, it orders the codes' later outcomes better than search volume alone, on each instrument. The plan, the score of every code under the locked parameters and the analysis script were committed on 14 October 2026 and stamped with OpenTimestamps before any per-page outcome was read (`02_DESIGN/framework_retro_test_381.md` and its manifest). The test waits on the vendors' per-page exports, which have not been made; its result will be reported whichever way it falls.\n\n"
     "**An annotation study**, two graders independent of the author,"),
    ("Anyone with both subscriptions and any multi-section site can do it in a day; the data file released with this paper gives the read method.",
     "Anyone with both subscriptions and any multi-section site can do it in a day; the data file released with this paper gives the read method. A protocol that chooses the second domain and its prefixes by rules fixed in advance, and re-reads the original twelve on a later date, was stamped with OpenTimestamps on 15 October 2026 before any reading under it."),
])

old_131 = s[s.index("### 13.1 Further directions"):s.index("## 14 Reproducibility")]
new_131 = """### 13.1 Further directions

Three directions follow from the measurements' finding that demand and answers sit on several surfaces and move between them; none tests a claim made here.

**Surfaces that move.** The thirteen surface types the implementation declares are a snapshot. People ask on video, forum, newsletter, professional and short-video platforms (for example YouTube, Reddit, Substack, LinkedIn, X, Snapchat and TikTok), and which of them people use changes: among US adults, use of TikTok rose from 21% in 2021 to 37% in 2025 and use of Reddit from 18% to 26% over the same four years, while use of YouTube and Facebook held steady [Gottfried & Park 2025]. A demand layer therefore has to be re-measured rather than fixed, keeping the relations between people, questions, entities and answers in the graph so that a shift between surfaces shows up as a change in the graph rather than as missing data. Tracking one industry's questions by surface over time, with the same linker and ontology, would show how quickly a demand layer goes stale.

**Agents as askers.** AI agents that research, compare, plan, book and buy for a person are both a demand surface, through the questions they ask, and an answer surface, through the sources they consult. Whether they ask what the people they serve would ask, and rely on the sources Measurement 3 counts, is measurable and not addressed here.

**Business disclosures.** Some companies, Costco among them, now report how AI search affects them, on the record and with a date: on its fourth-quarter fiscal 2026 earnings call, Costco's chief financial officer said that traffic to its site from AI search had grown by triple digits for the second consecutive quarter, from a low base [Motley Fool 2026], in a quarter with net sales of $93.9 billion, up 11.2% [Costco Wholesale Corporation 2026]. The author's reading of the call, as evidence that AI answers have become a sales channel a large retailer measures, is set out in a separate note [Pagadala 2026]. Costco is one of the 109 companies of Section 7. Logging what those companies say about AI search each quarter, beside how often AI answers cite their domains on a prompt set fixed in advance (Section 7's shares are partly fixed by its selection rule), would test whether disclosures move with citations and whether a content program could anticipate a shift rather than read it afterwards.

"""
s = s.replace(old_131, new_131, 1)
P.write_text(s)
print(f"13.1: {len(old_131.split())} -> {len(new_131.split())} words; total {len(s.split()):,}")
