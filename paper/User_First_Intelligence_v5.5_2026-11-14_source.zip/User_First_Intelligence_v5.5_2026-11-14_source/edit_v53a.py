"""Version 5.3, 31 October 2026, first edit: the version line; Section 6 split into 6.1 (the reviews, unchanged text)
and, in edit_v53b.py, 6.2 (Study W, a counted public signal against the vendor's volume on the 372 area codes); the
figures of Sections 7 to 10 renumbered 8 to 10 to make room for Figure 7 in Section 6.2. No result changes here."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("Manuscript version 5.2, 15 October 2026. Preprint, not yet peer reviewed.",
     "Manuscript version 5.3, 31 October 2026. Preprint, not yet peer reviewed."),
    ("## 6 Measurement 2: reviews against keyword volume on one taxonomy\n\nThe framework's premise can be tested wherever",
     "## 6 Measurement 2: reviews and a counted public signal against keyword volume\n\n### 6.1 Reviews against keyword volume on one taxonomy\n\nThe framework's premise can be tested wherever"),
    # figures 7, 8 and 9 become 8, 9 and 10 (captions first, then the references, each with its own context)
    ("![Figure 7. What AI answers cite, by sector and answer surface:", "![Figure 8. What AI answers cite, by sector and answer surface:"),
    ("![Figure 8. The eight pages under the prefix most often cited", "![Figure 9. The eight pages under the prefix most often cited"),
    ("![Figure 9. Ranking positions and the link profile over 77 days.", "![Figure 10. Ranking positions and the link profile over 77 days."),
    ("Perplexity and Gemini (Figure 7a). Across sectors and views,", "Perplexity and Gemini (Figure 8a). Across sectors and views,"),
    ("151 on ChatGPT and 161 on Copilot (Figure 7b), where a rank", "151 on ChatGPT and 161 on Copilot (Figure 8b), where a rank"),
    ("214 Dallas 238, 786 Miami 228, 404 Atlanta 218 (Figure 8). A hub lists many codes,", "214 Dallas 238, 786 Miami 228, 404 Atlanta 218 (Figure 9). A hub lists many codes,"),
    ("were acquired after the network began arriving (Figure 9). Because the arrival is dated", "were acquired after the network began arriving (Figure 10). Because the arrival is dated"),
    ("the pages most cited in AI answers (Figure 8) and the share of visits held", "the pages most cited in AI answers (Figure 9) and the share of visits held"),
])
P.write_text(s)
print(f"{len(s.split()):,} words")
