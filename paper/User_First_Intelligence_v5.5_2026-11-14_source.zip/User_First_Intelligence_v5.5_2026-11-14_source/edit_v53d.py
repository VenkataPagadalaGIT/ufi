"""Version 5.3, 31 October 2026: Appendix E, a reporting checklist for studies that use a commercial search-analytics
instrument's figures as data, with an accounting identity for the gap between two instruments and its positioning
against the closest prior checklists (search record 01_LITERATURE/checklist_search_2026-10-31/, by a separate agent;
every cited work checked at Crossref on 31 October 2026). Pointers from Sections 1.2, 5.6 and 14; Table D1's
decomposition row labelled by its pairing as Section 5.6 states it; three references added in alphabetical order."""
import unicodedata
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


APPENDIX_E = """
## Appendix E: Reporting what a search-analytics instrument measured

### E.1 A reporting checklist

Ten items for any study that uses a commercial search-analytics instrument's figures as data. Each instruction is followed by the finding or disclosure in this paper that motivates it.

1. **Instrument, report, mode and territory.** Name the vendor, the product, the report, the query mode (domain, prefix or subfolder) and the territory or database. One vendor's AI-visibility panel returned the same domain-scoped figures for every one of twelve subfolders queried (Section 5.5).
2. **Dates and a capture.** Date each read, state the period it covers, record the instrument's own index or database date where the report shows one, and keep a dated capture. The dashboard reads here were not archived, and one stored-answer count moved from 14,823 to 17,206 to 17,400 between 9 and 12 October 2026 as the index refreshed (Section 14).
3. **The vendor's definition, counted or modeled.** Quote the definition and say whether the figure is a count or a model's output. Both visit figures here are vendor click models over estimated volumes at estimated positions (Section 4.1).
4. **A second instrument for any magnitude.** Report a second instrument's reading of the same unit, or state that the figure carries a range the study cannot bound. Two instruments differed on one prefix by 7.5x to 27.1x, and across twelve prefixes of one domain by 0.20x to 7.24x (Sections 5.1 and 5.5).
5. **Orderings.** Report an ordering read on one instrument with the factor between the units, and as unresolved unless a second instrument shares it or the units are several-fold apart on both. Here the two instruments agreed on which of two sections was larger in 60 of 66 pairs, in all 51 pairs more than three times apart and in 9 of 15 within a factor of three, while two pairs six to seven times apart on one instrument were ordered the other way on the second (Sections 5.5 and 5.6).
6. **Territory pairing.** State every figure's territory and pair like with like before comparing instruments. Matching changed how many of twelve prefixes fell below a ratio of one, from six to four (Section 5.5).
7. **The keyword universe beside the visits.** Report each instrument's ranking-keyword count next to its visits, so that the gap can be split as in E.2. On the area-code prefix the universe term was about 35% of the log gap with Semrush US against Ahrefs worldwide and about 54% with both worldwide (Section 5.6); across the twelve prefixes the keyword ratio had no detectable relationship with the visits ratio (Section 5.5).
8. **What volume omits.** Where volume stands for demand, say what it cannot see, and report any counted or first-party signal read beside it, with its source and period. Here 14.0% of one- and two-star reviews matched a waiting pattern while the taxonomy's 11 labels mentioning waiting carried 622 searches a month (Section 6.1), and a public request count agreed with the vendor's volume roughly on ranking and not on magnitude (Section 6.2).
9. **How the interface was operated, and the terms.** State whether figures came from an API, an export or a dashboard, who or what operated the interface, and which clauses of the vendor's terms were read. Here an AI browser assistant read the dashboards and made the Section 7 exports, one figure was read by the author, no API was used, and the clauses on automated use are quoted with each vendor's position (Sections 4.1 and 14).
10. **Release.** Release every value read, with its date and method, and the script that prints each quoted statistic. Here the twelve-prefix reads and `analyze.py` are public, and the other read values and scripts are in the source bundle pending release (Section 14).

### E.2 What a gap between two instruments is made of

On the model the vendors describe (Section 4.1), an instrument X's estimated visits for a prefix, V(X), is a sum over its ranking-keyword universe U(X) of an estimated volume times an estimated click share at the keyword's estimated position. Whatever the model, V(X) equals the size of U(X) times m(X), the mean estimated visits per ranking keyword, so for two instruments A and B the log gap splits exactly in two: ln V(B)/V(A) = ln |U(B)|/|U(A)| + ln m(B)/m(A). A dashboard gives the first term, since it reports the ranking-keyword count; the second pools the volume model, the positions and the click model, and separating those needs per-keyword exports, which this paper does not have. The identity is written for one position per keyword; where an instrument counts a keyword once per location, the multiplicity sits in the second term. It is an accounting, not an attribution: the first term reads as a share of the gap only when the two terms have the same sign, as they do on the area-code prefix under both pairings (35% and 54%; Section 5.6). On the six prefixes whose visits ratio is below one, the keyword ratio is still at least 2.0 (Section 5.5), so there the two terms pull in opposite directions and no share reading exists. Report both terms.

### E.3 Positioning

A search on 31 October 2026 of OpenAlex, Crossref, the EQUATOR library and the web (72 logged queries; Semantic Scholar unreachable; one screener, an AI agent; indexed English-language literature; recorded in `01_LITERATURE/checklist_search_2026-10-31/` in the source bundle) found no reporting checklist for commercial search-analytics figures. The closest are documentation checklists for Google Trends [Nuti et al. 2014; Hölzl, Keusch & Sajons 2025], reporting items for Wikipedia page views [Alibudbud 2023], and reporting and disclosure standards for social-media data, including data obtained through commercial intermediaries [Kim, Huang & Emery 2016; Kostygina et al. 2023]; none names a search-analytics vendor. Items 1, 2 and 10 restate their access-date, parameter and data-sharing items for these instruments; item 4 extends to a second instrument the repeated samples from one opaque instrument that Hölzl, Keusch and Sajons recommend, and applies to vendors the design of comparing engines on one query set [Thelwall 2008]; the other items are this paper's findings. The checklist is written for the works Section 1 counts: in a screened sample of 120, 82% to 87% use a vendor's figures as data, and 87% to 88% of those use one vendor's only.
"""

rep([
    ("This is the paper's main empirical result. It does not say which platform is closer to the truth.",
     "This is the paper's main empirical result. It does not say which platform is closer to the truth. Appendix E turns it into a reporting checklist for studies that use such figures."),
    ("Reporting both makes the range of estimates visible; reporting one does not.",
     "Reporting both makes the range of estimates visible; reporting one does not. Appendix E states these consequences as a reporting checklist, with an accounting identity for the gap between two instruments."),
    ("and an independent search of five databases with citation chasing by a separate agent on 15 October, both recorded in the source bundle,",
     "an independent search of five databases with citation chasing by a separate agent on 15 October, and a search for reporting guidelines by another on 31 October (Appendix E), all recorded in the source bundle,"),
    ("| M1 decomposition | share of the log visits ratio due to the keyword-universe ratio | 35% (US pairing), 54% (worldwide) | `instrument_extra` |",
     "| M1 decomposition | share of the log visits ratio due to the keyword-universe ratio (Appendix E.2) | 35% (Semrush US against Ahrefs worldwide), 54% (both worldwide) | `instrument_extra` |"),
])
if "## Appendix E:" in s:
    raise SystemExit("REFUSE: Appendix E already present")
s = s.rstrip("\n") + "\n" + APPENDIX_E

NEW = [
    "Kim, Y., Huang, J., & Emery, S. (2016). Garbage in, garbage out: Data collection, quality assessment and reporting standards for social media data use in health research, infodemiology and digital disease detection. *Journal of Medical Internet Research, 18*(2), e41. https://doi.org/10.2196/jmir.4738",
    "Kostygina, G., Kim, Y., Seeskin, Z. H., LeClere, F. B., & Emery, S. (2023). Disclosure standards for social media and generative artificial intelligence research: Toward transparency and replicability. *Social Media + Society, 9*(4). https://doi.org/10.1177/20563051231216947",
    "Nuti, S. V., Wayda, B., Ranasinghe, I., Wang, S., Dreyer, R. P., Chen, S. I., & Murugiah, K. (2014). The use of Google Trends in health care research: A systematic review. *PLoS ONE, 9*(10), e109583. https://doi.org/10.1371/journal.pone.0109583",
]


def key(line):
    return unicodedata.normalize("NFKD", line).encode("ascii", "ignore").decode().lower()


head, refs_and_rest = s.split("\n## References\n", 1)
refs, rest = refs_and_rest.split("\n## Appendix A", 1)
lines = refs.split("\n")
for entry in NEW:
    if any(x.startswith(entry[:25]) for x in lines):
        raise SystemExit(f"REFUSE: already present: {entry[:40]}")
    entries = [i for i, x in enumerate(lines) if x.strip() and not x.startswith("#")]
    pos = next((i for i in entries if key(lines[i]) > key(entry)), None)
    if pos is None:
        raise SystemExit("no insertion point")
    lines[pos:pos] = [entry, ""]
s = head + "\n## References\n" + "\n".join(lines) + "\n## Appendix A" + rest
P.write_text(s)
print(f"{len(s.split()):,} words")
