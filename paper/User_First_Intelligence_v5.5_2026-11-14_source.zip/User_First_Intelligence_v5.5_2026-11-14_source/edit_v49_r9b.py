"""Round 9 verification fixes to manuscript_v49.md (second pass, after 08_REVIEW/R9_verification.md).

Exact (old, new) replacements that must each match once. Numbers come from
04_ANALYSIS/ai_cited_sources/cross_sector_sensitivity_output.txt and cross_sector_sensitivity2_output.txt.

Edits made by hand between edit_v49_r9.py and this script, recorded here so the change log is complete
(verification finding N31): the abstract was rewritten to 334 words (dropping "social groups",
"executable", the form clause and the adapter sentence) and given the method, result and implication
cues; "analysed"/"unanalysed"/"licence" were changed to US spelling; the Lebo reference was moved above
Le Pochat; and three phrases in edit_v49_r9.py were corrected before it ran (Carroll page range removed,
"read by hand" changed to "transcribed", "commercial product" changed to "own product").

Edits made by hand after this script ran: three leftover phrases ("a measure that was not registered",
"Section 5's divergence result", "their ten largest companies" in Appendix A) were reworded; the
abstract was trimmed to 340 words ("made using two analytics platforms ... motivate it"; "gave" to
"yielded"; the implication sentence shortened to "traffic estimates and cited sources have to be
measured per instrument and per answer surface, not inferred").
"""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v49.md")
s = P.read_text()
E = []

# abstract (N12, N16, N27)
E.append(("keep structure, coverage and demand sources in separate roles in a knowledge graph;",
          "keep structure, coverage, answerability and demand sources in separate roles;"))
E.append(("that name the ten largest companies of each S&P 500 sector,",
          "that name the ten largest holdings of each S&P 500 sector fund,"))
E.append(("The implication is that volume tools disagree by up to an order of magnitude about the same pages",
          "The implication is that commercial analytics platforms can disagree by up to 27 times about the same pages"))

# introduction (N3, N12, N21)
E.append(("classify and link them to the entities of an industry held under an ontology, keep the sources that establish structure, coverage and demand in separate roles",
          "link them to the entities of an industry held under an ontology, keep the sources that establish structure, coverage, answerability and demand in separate roles"))
E.append(("and score where the organization fails to answer, with the form of the answer measured rather than assumed (Figure 1).",
          "and score where the organization fails to answer, with the form of the answer meant to be measured rather than assumed (Figure 1); the released score does not yet do so, because its coverage rubric prefers per-entity pages (Section 7.1, Appendix B)."))
# Figure 1 caption (P1)
E.append(("are marked differently. Section 5.8 measures the answer layer outside the pipeline. (b) The pipeline from observed questions to content, with the two observation layers this paper reports (dashed)",
          "are marked differently. (b) The pipeline from observed questions to content, with the two observation layers this paper reports (dashed; the AI-answer layer is also measured outside the pipeline, in Section 5.8)"))
# contributions (N20, N27)
E.append(("(0.20x to 8.89x territory-matched), shows no relationship with section age,",
          "(0.20x to 8.89x territory-matched), shows no detectable relationship with section age,"))
E.append(("the eleven S&P 500 sectors, their ten largest companies and eight answer surfaces. Of four predictions",
          "the eleven S&P 500 sectors, their largest companies (109 in all) and eight answer surfaces. Of four predictions"))

# Section 1.4 (A28, M2, N11, P3)
E.append(("User First Intelligence has six components and three measures. Appendix B gives the score's formula",
          "User First Intelligence has six components, the last of which, the Content Gap Score, is its output, and two measures of how well the ontology serves the competency questions. Appendix B gives the score's formula"))
E.append(("in the spirit of provenance-typed statements [Carroll et al. 2005; Lebo et al. 2013].",
          "in the spirit of provenance-typed statements [Carroll et al. 2005; Lebo et al. 2013]. Each source has exactly one role; the implementation has no rule yet for a source that both asks and answers, such as a forum thread. Provenance is held on each statement in the implementation's graph and reported per source; its OWL and RDF export does not yet serialize it."))
E.append(("Own coverage, competitor coverage and answerability are graded judgments that need a supplied grader; Appendix B gives both rubrics.",
          "Own coverage, competitor coverage and answerability are graded judgments: the package ships a rule-based grader for its tests and example and no model client, and Appendix B gives both rubrics."))
E.append(("The three measures are the competency-question schema pass rate (the share of competency questions the ontology can express), the instance coverage rate (the mean, over expressible questions, of the share of subjects for which the graph returns an answer) and the Content Gap Score.",
          "The two measures are the competency-question schema pass rate (the share of competency questions the ontology can express) and the instance coverage rate (the mean, over expressible questions, of the share of subjects for which the graph returns an answer). They keep the implementation's names, so \"coverage\" names both a source role and the second rate."))

# related work (N24)
E.append(("argues that the field's headline gains establish neither organic discoverability nor durable traffic effects,",
          "argues that the foundational GEO paper's gains establish neither organic discoverability nor durable traffic effects,"))

# Section 4.2 (N19)
E.append(("its comparisons are stated as conditional on that universe and are comparisons within one instrument across surfaces, on the analogy of the ordering agreement in Section 5.5.",
          "its comparisons are stated as conditional on that universe, are made within one instrument across differently selected universes, and are descriptive. The share going to the sector's own company domains is partly fixed by that selection, and no comparison is drawn from it."))
# Table 1 caption (N22, A25)
E.append(("*Table 1. Instruments, definitions, denominators and read dates for every quantity reported in this paper.*",
          "*Table 1. Instruments, definitions, denominators and read dates for the measured quantities in Sections 4 to 8. Vendor authority scores (Domain Rating, Authority Score, URL Rating) are given with their instrument where they are used.*"))
# Section 5 opening (N30)
E.append(("They are reported first because it is the finding that does not rest on the author's judgment: every figure below is",
          "They are reported first because they do not rest on the author's judgment: every figure in them is"))
# 5.6 (N20)
E.append(("Section 5.5 tested that across twelve prefixes and found no relationship between age and the ratio.",
          "Section 5.5 tested that across twelve prefixes and found no detectable relationship between age and the ratio."))
# 5.7 (N4, N6)
E.append(("The licensed export contained reviewer display names; they were deleted before analysis, and only per-label counts are reported.",
          "The licensed export contains reviewer display names; they were excluded from the analysis and are held only in the author's private copy of the export, and only per-label counts are reported."))
E.append(("This is a first run, not the registered study.", "This is a first run, not the study specified in Section 11."))

# 5.8 pilots (N8, N15, N29)
E.append(("computed on 7 October 2026 by the author's own analytics platform, in a pre-production dashboard, from Ahrefs Brand Radar data (snapshot 22 September 2026).",
          "computed on 7 October 2026 (UTC) by the author's own analytics platform, in a pre-production dashboard, from Ahrefs Brand Radar data accessed through Previsible's account (snapshot 22 September 2026)."))
E.append(("The pilots' universe is prompts that name no brand; the cross-sector universe is answers that name companies, so they do not describe the same population.",
          "The first pilot covers answers that cite or name a tracked provider, to prompts that name none; the second, like the cross-sector study, covers answers that name or cite a listed brand, so the first describes a different population from the study below."))
# 5.8 design (N9, N23)
E.append(("and added the exploratory overlap measure. Two steps the design named",
          "and added the exploratory overlap measure. A third amendment, A3, made after the review of this section, records corrections: how the exports were made, the stopped prompt-level sample, and the company-property list used in one sensitivity check. Two steps the design named"))
E.append(("an all-surfaces export per sector was made and is not used.",
          "an all-surfaces export per sector was made and is used only for the company-dominance figures below."))
# 5.8 results (N2, N18)
E.append(("**Results, descriptive.** The kind of source differs most between answer surfaces.",
          "**Results, descriptive.** The share going to video and community platforms differs most between answer surfaces."))
E.append(("without it, the medians are 12.7% and 1.6%.",
          "without it, the medians are 12.7% and 1.6%, and the lowest Google view exceeds the highest other surface in 7 of 11 sectors."))
E.append(("**Results, the registered source types.**", "**Results, the source types fixed before collection.**"))
E.append(("On those four, the largest classified type was the sector's own company domains (median 14.1%, against 10.4% on the Google views).",
          "On those four, the largest classified type was the sector's own company domains (median 14.1%), a share the selection rule partly fixes, so it is not compared across surfaces."))
E.append(("and the claim here is about the share going to seventeen named video and community platforms rather than about every kind of source.",
          "and the claim here is about the share going to seventeen named video and community platforms rather than about every kind of source. Across the 88 cells, answer surface explains 77% of the variance of that share and sector 14%; for news (12% against 73%), government (26% against 49%) and the companies' own domains (40% against 45%), sector explains more (unweighted decomposition). Appendix C gives every type's median and range by surface."))
E.append(("Three things limit this reading. The registered test of a sector difference, P4, did not exceed chance.",
          "Three things limit this reading. The one prediction about a sector difference, P4, did not exceed chance; with the company-property list its direction reversed on search queries (22.5% against 24.2%), and in no check did it approach significance (p = 0.23 to 0.63)."))
# 5.8 predictions (N6, A24)
E.append(("**The registered predictions.** Of the four,", "**The predictions written before collection.** Of the four,"))
E.append(("failed as registered: it held on AI Overviews", "failed as written: it held on AI Overviews"))
E.append(("and not on AI Mode (2 of 11 on each), where google.com usually ranked first and YouTube second.",
          "and not on AI Mode (2 of 11 on each), where google.com, almost all of it www.google.com (median 93% and 98% of its incidences on the two views), usually ranked first and YouTube second."))
E.append(("which the registration did not provide for.", "which the design did not provide for."))
E.append(("than in five others named in the registration (Financials is in neither group)",
          "than in five others named in the design file (Financials is in neither group)"))
# 5.8 sensitivity (N1, N6)
E.append(("**Sensitivity.** None of the following was registered.", "**Sensitivity.** None of the following was planned before collection."))
E.append(("from a hand-built list released with the design file,", "from a hand-built list prepared for release with the design file (Section 12),"))
# 5.8 limits (N1, N17, A13, C19)
E.append(("so the registered ChatGPT file, led by graphics-hardware sites, stands; without Industrials the ChatGPT median is 0.8% and P2 holds in 10 of 10 sectors.",
          "so the original ChatGPT file, led by graphics-hardware sites, stands; without Industrials the ChatGPT median is 0.8%, P2 holds on ChatGPT and Copilot in 10 of 10 sectors and on Perplexity in 6 of 10, and P3 holds in 3 of 10."))
E.append(("The prompt and search-query sets are the vendor's, not observed user demand.",
          "The prompt and search-query sets are the vendor's, not observed user demand, and whether the Google prompt views and the other four surfaces draw on one prompt set is not established here, so the surfaces may differ in the questions asked as well as in how they answer."))
E.append(("(the per-cell sizes are released)", "(Appendix C gives each cell's size)"))
# 5.8 closing (N2, N26)
E.append(("the publisher types cited differ more between answer surfaces than between sectors, and Google's AI Overviews and AI Mode give video and community domains about ten times the share the other four surfaces do.",
          "the share of citations going to video and community platforms differs more between answer surfaces than between sectors, while news, government and company sources vary more by sector; and Google's AI Overviews and AI Mode give video and community domains about ten times the pooled median share of the other four surfaces, and more than twice Gemini's."))

# 9.2 lesson 1 (N21)
E.append(("Cost: an evaluated method claim; the framework is specified in Appendix B,",
          "Cost: an evaluated method claim; the score is specified in Appendix B,"))
# Section 10 (N13)
E.append(("should weight Section 5's instrument readings, which are independently reproducible from two commercial subscriptions, far above anything else in the paper. Section 5 is the primary result partly for that reason.",
          "should weight the instrument readings of Sections 5.1 to 5.6, which are independently reproducible from two commercial subscriptions, far above anything else in the paper. Those sections are the primary result partly for that reason."))
# Section 11 (N7, N10, N28)
E.append(("The lock covers those five values; it does not cover the scoring code,",
          "The lock covers those five values, two of which, the phrasing minimum and the class aggregate, the released code records but does not consult; it does not cover the scoring code,"))
E.append(("Its sampling rule was fixed in amendment A1, as the first 10,000 rows per sector and surface in the vendor's default order. Collection was stopped after the two smallest sectors, Energy and Utilities (14 of 88 exports, 44,463 answers),",
          "Amendment A1 fixed a sampling rule of the 10,000 highest-volume prompts per sector and surface; because the table keeps no volume sort, the exports took the first 10,000 rows in the vendor's default order, a change recorded after the design file's first commit (A2, A3). Collection was stopped after two small sectors, Energy and Utilities (14 of 88 exports, 44,463 answers),"))
E.append(("(for example parent, business owner, traveller)", "(for example parent, business owner, traveler)"))

# Section 12 (N1, N4, N5, N13, N14, N15, m11)
E.append(("(21 of the 22 commits at that point carry the assistant as author).",
          "(all 22 commits at that point are AI-assisted: 21 carry the assistant as author and one as co-author)."))
E.append(("Its OWL reasoning step uses HermiT through owlready2, which needs a Java runtime.",
          "Its OWL reasoning step uses HermiT through owlready2, which needs a Java runtime; the package declares Python 3.10 or later and minimum, not pinned, dependency versions."))
E.append(("Every figure in Sections 5 and 6 can be re-read", "Every figure in Sections 5.1 to 5.6 and 6 can be re-read"))
E.append(("No experiment was run on people, and no user-level, session or cookie data was collected.",
          "No experiment was run on people, and no data about visitors to the section was collected."))
E.append(("the export contained reviewer display names, which were deleted before analysis;",
          "the export contains reviewer display names, which were excluded from the analysis and are held only in the author's private copy of the licensed export;"))
E.append(("Every vendor figure in Sections 5 and 6 was read from the vendors' web dashboards under paid subscriptions,",
          "Every vendor figure in Sections 3 and 5.1 to 8 was read from the vendors' web dashboards under paid subscriptions held for other work (Section 9.1),"))
E.append(("it read the displayed figures for Sections 5 and 6,", "it read the displayed figures for those sections,"))
E.append(("Ahrefs prohibits using its services through an automated means except through its API (clause 4.4(j)),",
          "Ahrefs prohibits using its services through an automated means except through its API (clause 4.4(j)) and using them to develop a competing product (clause 4.4(l)),"))
E.append(("The pilot dataset in Section 5.8 was computed on 7 October 2026, before Previsible's permission, by the author's own analytics platform from Brand Radar data the platform held;",
          "The first pilot in Section 5.8 was computed on 7 October 2026 (UTC), before Previsible's permission, by the author's own analytics platform from Brand Radar data accessed through Previsible's account; because that platform measures AI visibility, clause 4.4(l) bears on it as well;"))
E.append(("(2) written confirmation from Ahrefs and Semrush that the browser-assistant access and the publication of the figures are permitted,",
          "(2) written confirmation from Ahrefs and Semrush that the browser-assistant access and the publication of the figures are permitted, and from Previsible that its permission covers publication,"))
E.append(("and (5) an institutional ethics determination for Section 5.7.",
          "(5) an institutional ethics determination for Section 5.7; and (6) withdrawal or correction of the earlier manuscript copies in the public repository that assert the organization's approval or name it."))
E.append(("Anthropic's Claude models, through Claude Code and Claude in Chrome,",
          "Anthropic's Claude models (Claude Opus 5, Opus 5.5, Fable 5 and Fable 5.1, in October 2026), through Claude Code and Claude in Chrome,"))
E.append(("operated the browser for every vendor read and export, as stated above;",
          "operated the browser for every vendor read and export, as stated above, and fetched the section's public pages for the page count in Section 3;"))
E.append(("and ran the nine review rounds recorded in Appendix A as simulated panels of AI reviewers, which are not peer review.",
          "and ran the nine review rounds, recorded in the project's review log, as simulated panels of AI reviewers, which are not peer review."))
E.append(("The grading judgments of Section 9.2, lesson 5, were made by AI agents the author built.",
          "The grading judgments of Section 9.2, lesson 5, were made by AI agents the author built; their models and prompts are not documented here."))
E.append(("The author checked the numbers against their source files, and every number in Sections 5.5, 5.7 and 5.8 is printed by a released script.",
          "The author checked the numbers against their source files. Every statistic in Sections 5.5 and 5.7, and every share, rank, prediction tally and sensitivity in Section 5.8, is printed by a script; the scripts for Sections 5.5 and 5.7 are public and those for Section 5.8 are prepared for release (open item 4)."))

# conclusion (N3, N12, N21)
E.append(("classifies and links them to an industry held under an ontology, keeps structure, coverage and demand in separate roles in a knowledge graph, asks that graph competency questions, and scores where the organization fails to answer, with the form of the answer treated as a property to measure rather than assume, as Section 7.1 shows in miniature.",
          "links them to an industry held under an ontology, keeps structure, coverage, answerability and demand sources in separate roles, with demand held in an index linked to the graph, asks that graph competency questions, and scores where the organization fails to answer. It is meant to treat the form of the answer as a property to measure rather than assume; Section 7.1 shows why, and the released score does not yet do so."))

# Appendix A (N1, N23)
E.append(("one amendment before the first export and one after collection.",
          "one amendment before the first export and two after collection (A2; A3, after review)."))
E.append(("Sensitivity checks and four released tables were added.",
          "Sensitivity checks, Appendix C and four tables prepared for release were added. A verification round then found five factual slips in that revision (among them a sector wrongly called one of the two smallest and an amendment misattributed) and narrowed the claim that sources differ more by surface than by sector to video and community sources; both are corrected."))

# Appendix B (N10, N11, M13, P3)
E.append(("The package does not ship a grader; a deployment supplies one.",
          "The package ships a rule-based grader for its tests and worked example and no model client; with no grader supplied, every judgment defaults to 0, so every entity scores as uncovered."))
E.append(("(digest `7290a2235d8de05f`, set at 02:00 UTC on 12 October 2026).",
          "(digest `7290a2235d8de05f`, set at 02:00 UTC on 12 October 2026). The code records the last two but does not consult them: the phrasing minimum is checked only as a warning, and the class aggregate step reports both mean and sum and ranks by the mean."))
E.append(("The implementation reports competency-question performance as two separate rates, because they fail for different reasons:",
          "The implementation reports competency-question performance as two separate rates, because they fail for different reasons, as in test-driven ontology development, which tests a question against the ontology's vocabulary and separately against its instances [Keet & Ławrynowicz 2016; Wiśniewski et al. 2019]:"))

# Appendix C (A7, A14, C21)
E.append(("A question the ontology cannot express is reported as a declared gap with a reason rather than scored as zero.\n",
          """A question the ontology cannot express is reported as a declared gap with a reason rather than scored as zero.

## Appendix C: Section 5.8 by source type and cell

*Table C1. Share of citation incidences by registered source type and answer surface: median over the eleven sectors, with the range in parentheses. Ahrefs Brand Radar, United States, one collection session on 12 and 13 October 2026; among the 1,000 domains found in the most answers that name a sector's largest companies. The company-domain share is partly fixed by the universe's selection rule and is not compared across surfaces.*

| Surface | Video and community | Reference | News | Government | Sector's companies | Other web |
|---|---|---|---|---|---|---|
| AI Overviews, search queries | 25.8% (14.3–34.3) | 4.3% (1.3–8.1) | 0.7% (0.2–2.8) | 0.4% (0.2–8.6) | 11.9% (6.1–23.5) | 55.6% (41.1–62.0) |
| AI Overviews, prompts | 32.4% (13.4–35.8) | 2.6% (0.7–3.9) | 1.0% (0.1–5.8) | 0.3% (0.1–3.8) | 8.1% (2.7–20.5) | 59.0% (42.0–75.3) |
| AI Mode, search queries | 17.8% (9.0–23.8) | 4.2% (2.2–10.4) | 1.0% (0.3–4.2) | 0.4% (0.1–8.6) | 10.8% (5.1–17.6) | 65.3% (53.1–71.4) |
| AI Mode, prompts | 24.1% (8.1–28.3) | 2.7% (0.9–4.5) | 1.4% (0.3–5.6) | 0.4% (0.1–5.0) | 9.5% (2.7–19.3) | 65.1% (50.1–79.3) |
| ChatGPT | 0.9% (0.3–2.5) | 1.7% (0.5–3.4) | 1.7% (0.7–5.2) | 3.0% (1.6–18.2) | 27.4% (13.5–38.2) | 61.5% (51.2–76.1) |
| Perplexity | 4.6% (1.8–7.7) | 5.9% (2.8–10.7) | 1.5% (0.3–7.9) | 0.8% (0.1–12.0) | 15.6% (8.2–29.8) | 67.8% (56.4–73.9) |
| Gemini | 9.2% (2.9–16.7) | 3.7% (1.2–6.9) | 0.5% (0.1–3.8) | 0.3% (0.1–2.4) | 8.3% (3.2–33.2) | 75.2% (49.5–85.3) |
| Copilot | 0.6% (0.3–1.0) | 1.6% (0.3–2.7) | 0.9% (0.2–5.2) | 0.1% (0.0–2.2) | 4.5% (1.6–27.0) | 89.9% (71.6–94.6) |

*Table C2. Size of each cell: summed citation incidences among the exported domains, in thousands. Medians in Section 5.8 weight every cell equally.*

| Sector | AIO search | AIO prompt | AIM search | AIM prompt | ChatGPT | Perplexity | Gemini | Copilot |
|---|---|---|---|---|---|---|---|---|
| Information Technology | 10,891.5 | 294.3 | 1,128.4 | 352.4 | 317.5 | 186.8 | 147.9 | 405.6 |
| Health Care | 604.2 | 10.1 | 69.8 | 16.5 | 13.9 | 8.5 | 7.4 | 20.9 |
| Financials | 1,776.8 | 78.8 | 173.5 | 97.5 | 64.4 | 37.4 | 45.3 | 85.9 |
| Consumer Discretionary | 18,381.8 | 790.0 | 1,752.1 | 660.9 | 347.0 | 441.7 | 128.8 | 1,581.3 |
| Communication Services | 4,350.7 | 134.3 | 591.5 | 163.5 | 150.1 | 71.8 | 76.0 | 197.9 |
| Industrials | 1,223.2 | 52.6 | 112.9 | 60.2 | 52.6 | 21.7 | 27.2 | 79.3 |
| Consumer Staples | 8,832.0 | 395.4 | 982.3 | 446.6 | 351.7 | 215.6 | 149.8 | 1,295.6 |
| Energy | 103.6 | 3.8 | 14.8 | 5.5 | 5.1 | 2.0 | 2.9 | 9.0 |
| Utilities | 50.3 | 2.1 | 7.2 | 2.6 | 2.1 | 0.9 | 1.5 | 3.2 |
| Real Estate | 77.9 | 6.4 | 22.1 | 6.8 | 6.8 | 4.4 | 2.1 | 6.8 |
| Materials | 337.5 | 15.6 | 24.3 | 17.5 | 18.5 | 5.6 | 6.5 | 18.7 |

Both tables are printed by `cross_sector_sensitivity2.py`.
"""))

for old, new in E:
    n = s.count(old)
    if n != 1:
        raise SystemExit(f"REFUSE: {n} matches for: {old[:100]!r}")
    s = s.replace(old, new)
P.write_text(s)
print(f"applied {len(E)} edits; {len(s.split()):,} words")
