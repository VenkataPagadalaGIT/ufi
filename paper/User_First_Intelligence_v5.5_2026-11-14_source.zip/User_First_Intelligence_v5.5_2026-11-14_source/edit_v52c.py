"""Version 5.2 cycle, novelty and positioning (first independent measurement, novelty 6.5: "novelty claims are scoped
'to the author's knowledge' with no search described; the framework is not positioned against existing gap-scoring
methods"). A search of OpenAlex and Crossref on 14 October 2026 (01_LITERATURE/novelty_search_2026-10-14/) found six
relevant works the paper did not cite; each was checked against Crossref or arXiv. The novelty sentence now states
the search; Section 2 cites the closest prior comparisons of SEO tools; Appendix B carries the positioning that
Section 2 promised it would.
"""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:  # already applied: an insertion keeps its anchor, so a second run would insert twice
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("What has not been reported, to the author's knowledge, is a direct comparison of two vendors' records of a single object from a known start date; this paper reports one.",
     "A search of OpenAlex and Crossref on 14 October 2026, whose queries and screened results are released with the paper's data, found vendor tools compared with first-party analytics and with each other on established domains (Section 2), but no comparison of two vendors' records of a single object followed from a known start date; this paper reports one."),
    ("which motivated a ranking built to be stable and hard to manipulate [Le Pochat et al. 2019]. Those studies compare an estimate with a ground truth across many sites, or compare lists across the whole web. This paper does neither:",
     "which motivated a ranking built to be stable and hard to manipulate [Le Pochat et al. 2019]. Tools have also been compared with one another directly: the domain-authority scores of Moz, Semrush and Ahrefs [Reyes-Lillo, Morales-Vargas & Rovira 2023], and the organic keyword counts, keyword search volumes and URL-level traffic that Ahrefs, Semrush, Serpstat and Ubersuggest report for two academic publishers' domains, which overlapped so little that the choice of tool determined the findings [Font-Julián et al. 2026]. Analytical results and simulation show that the processing behind third-party traffic estimates can shrink, inflate or reverse an estimated treatment effect, and caution against their use for causal inference [Khosravi & Yoganarasimhan 2026]. Those studies compare an estimate with a ground truth across many sites, compare lists across the whole web, or compare tools on established domains at one time. This paper does none of these:"),
    ("Section 7 differs in its frame, eleven sectors fixed by an external rule,",
     "Vendor-tracked brand visibility has also been measured: in more than 100,000 prompt responses for over 100 brands, about 78% of the sources engines cited were corporate websites, with YouTube leading the others ahead of Reddit, editorial media and Wikipedia [Kumar 2026], and a scoping review of 23 studies, mostly preprints, maps how such presence and citation are measured [Romero Ramos et al. 2026]. Section 7 differs in its frame, eleven sectors fixed by an external rule,"),
    ("Measurement 2 compares the two on one taxonomy: which topics each signal names, rather than how well either predicts an outcome.",
     "Studies of search increasingly sample their queries, and the queries' volumes, from keyword research tools [Schultheiß et al. 2023]. Measurement 2 compares the two signals on one taxonomy: which topics each names, rather than how well either predicts an outcome."),
    ("Since the function is not evaluated here, that discussion sits with the specification in the appendix.",
     "Since the function is not evaluated here, Appendix B positions it against the closest of these methods."),
    ("This function is not evaluated anywhere in this paper. It was not computed when the build decision was taken, nothing in Sections 5 to 10 tests it, and no published study has tested whether it predicts anything. It appears here because the reference implementation is released and a reader may want the specification it implements.",
     "This function is not evaluated anywhere in this paper. It was not computed when the build decision was taken, nothing in Sections 5 to 10 tests it, and no published study has tested whether it predicts anything. It appears here because the reference implementation is released and a reader may want the specification it implements.\n\n"
     "**Position against the closest methods.** Demand-weighted completeness estimates how complete a knowledge base is with respect to how it is used, predicting from usage data which relations each class of entity requires [Hopkinson et al. 2018]; the score shares the demand weighting, but it scores an organization's own coverage, its competitors' coverage and the web's answerability rather than a knowledge base's facts, and it takes demand from surfaces outside the organization rather than from the system's own usage. Recommender systems for encyclopedias rank missing articles by importance, validated in a controlled experiment with 12,000 French Wikipedia editors in which recommending an article raised its chance of being created by a factor of 3.2 [Wulczyn et al. 2016], and recommend sections for existing articles from similar ones, with a precision of about 80% in human evaluation [Piccardi et al. 2018]; the score ranks an organization's entities against a market rather than an encyclopedia's articles against its sister editions, and, unlike those systems, it has not been evaluated. Completeness estimators for open-world knowledge bases [Galárraga et al. 2017; Luggen et al. 2019; Razniewski et al. 2024] measure what a knowledge base lacks, which corresponds to the score's coverage term when an organization's content is represented as a knowledge base."),
])

NEW = {  # inserted after the reference that precedes each alphabetically; the build sorts the list again
    "Galárraga, L.": None,
    "Kendall, M. G.": ["Khosravi, M., & Yoganarasimhan, H. (2026). *Do third-party web traffic estimates preserve causal variation?* arXiv:2609.30481.",
                       "Kumar, P. (2026). *Generative engine optimization at scale: Measuring brand visibility across AI search engines.* arXiv:2606.20065."],
    "Ren, Y.": ["Reyes-Lillo, D., Morales-Vargas, A., & Rovira, C. (2023). Reliability of domain authority scores calculated by Moz, Semrush, and Ahrefs. *El Profesional de la Información*, e320403. https://doi.org/10.3145/epi.2023.jul.03"],
    "Ripoll, M.": ["Romero Ramos, N., Lobach, Y., Abreu Abreu, D., Castillo Hernández, I., García-Cordero, J. C., & García-Cordero, D. (2026). Measuring brand presence in generative engine optimization (GEO): A scoping review of metrics and validity. *Latitude, 2*(24), 23–39. https://doi.org/10.55946/latitude.v2i24.295"],
    "Scheitle, Q.": ["Schultheiß, S., Lewandowski, D., von Mach, S., & Yagci, N. (2023). Query sampler: Generating query sets for analyzing search engines using keyword research tools. *PeerJ Computer Science, 9*, e1421. https://doi.org/10.7717/peerj-cs.1421"],
}
BEFORE_GALARRAGA = "Font-Julián, C. I., Lopezosa, C., Orduña-Malea, E., & Aguillo, I. F. (2026). Assessing discrepancies across SEO tools in the collection of scholarly web metrics. *Journal of Information Science, 52*(4), 1075–1088. https://doi.org/10.1177/01655515261445903"
lines = s.split("\n")
for anchor, entries in NEW.items():
    idx = [i for i, x in enumerate(lines) if x.startswith(anchor)]
    if len(idx) != 1:
        raise SystemExit(f"REFUSE: {len(idx)} reference lines start with {anchor!r}")
    i = idx[0]
    if entries is None:
        lines[i:i] = [BEFORE_GALARRAGA, ""]
    else:
        add = []
        for e in entries:
            add += ["", e]
        lines[i + 1:i + 1] = add
s = "\n".join(lines)
P.write_text(s)
print(f"{len(s.split()):,} words")
