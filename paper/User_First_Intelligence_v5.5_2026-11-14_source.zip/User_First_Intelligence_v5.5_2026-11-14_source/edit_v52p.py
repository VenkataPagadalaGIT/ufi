"""Version 5.2, 15 October 2026: from the final blind paper-measure runs on the packaged v5.2 (sha 499b89df). Two
paraphrases made exact against their sources (Kumar 2026: YouTube leads among non-corporate sources; Zhao & Berman
2025 v4: "a 7% post-blocking decline in weekly visits measured by SimilarWeb or Semrush within the 6 weeks after
blocking"), and the second-domain protocol's stamped files located (they are now released in protocols/)."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("with YouTube leading the others ahead of Reddit, editorial media and Wikipedia [Kumar 2026]",
     "with YouTube leading the non-corporate sources, ahead of Reddit, editorial media and Wikipedia [Kumar 2026]"),
    ("and a study of news publishers found the same traffic effect of blocking generative-AI crawlers, a decline of about 7% within six weeks, on SimilarWeb and on Semrush [Zhao & Berman 2025].",
     "and a study of news publishers reported a decline of about 7% in weekly visits within six weeks of blocking generative-AI crawlers, measured by SimilarWeb or by Semrush [Zhao & Berman 2025]."),
    ("was stamped with OpenTimestamps before any reading under it, in the same Bitcoin block.",
     "was stamped with OpenTimestamps before any reading under it, in the same Bitcoin block; the protocol and every file its stamped manifest lists are released with the paper's data."),
])
P.write_text(s)
print(f"{len(s.split()):,} words")
