"""Version 5.4, 14 November 2026: Section 7.7's sentence on the row-count check said more than the exports' ledger shows.
Thirty-four of the 44 files match the count the vendor's interface showed exactly; ten fall short by one to seven rows,
19 rows in all (03_DATA/raw/edu_ai_citations_2026-11/ledger.jsonl)."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()
a = "in 44 export files, each checked against the row count the interface showed (one slice, 1,492 ChatGPT answers for France, failed to export and is missing)."
b = "in 44 export files, each checked against the row count the interface showed: 34 match it exactly and ten fall short by one to seven rows, 19 in all (one further slice, 1,492 ChatGPT answers for France, failed to export and is missing)."
if s.count(a) != 1:
    raise SystemExit(f"REFUSE: {s.count(a)} matches")
if b in s:
    raise SystemExit("REFUSE: already applied")
P.write_text(s.replace(a, b))
print(f"{len(s.split()):,} words before")
