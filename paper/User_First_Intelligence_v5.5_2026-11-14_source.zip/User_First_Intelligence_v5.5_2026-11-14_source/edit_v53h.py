"""Version 5.3, 3 November 2026: from the blind paper-measure runs on the package of that afternoon (sha 58881ff6). Each item
was checked first. Google's Search Status Dashboard lists an August 2026 spam update on 18 to 21 August (days 23 to 26) that the
paper had missed, so day 37 does not precede every disturbance. Trade-press reports of altered result pages served to rank trackers
since September 2026 are stated as a threat to test. The modal attribution's tie-break is disclosed and its effect printed
(m2_tiebreak_check.py); the waiting finding is checked at the level of keywords as well as labels (waiting_keywords_check.py);
much of the vendor side's spread in Section 6.2 is the number of keywords matched (wiki_demand_supplement.py)."""
import unicodedata
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    # the missed disturbance
    ("a 77-day series with a primary checkpoint chosen to precede three identified disturbances,", "a 77-day series with a primary checkpoint chosen to precede three of the four identified disturbances,"),
    ("Three disturbances fall in the observation window. The September 2026 spam update began on 24 September, day 60,",
     "Four disturbances fall in the observation window. Google's August 2026 spam update ran from 18 to 21 August, days 23 to 26 [Google 2026]. The September 2026 spam update began on 24 September, day 60,"),
    ("**Day 37 (1 September 2026) is the primary checkpoint**: the last observation preceding all three.",
     "**Day 37 (1 September 2026) is the primary checkpoint**: the last observation preceding the last three. It does not precede the August update, which falls in the month of the largest visits ratio (27.1x), and whose effect on this section is not estimated."),
    ("Algorithm updates: one named, dated update falls in the window, on the day of the traffic peak; whether unannounced ones did is not knowable from here.",
     "Algorithm updates: two named, dated updates fall in the window, the August spam update (days 23 to 26), before the primary checkpoint and inside its fastest interval, and the September one, on the day of the traffic peak; whether unannounced ones did is not knowable from here."),
    ("The fastest clean interval, 768 a day across days 15 to 30,", "The fastest clean interval, 768 a day across days 15 to 30, which holds the August spam update,"),
    ("the vertical rules mark the primary checkpoint (day 37), the September 2026 spam update (day 60) and the vendor data-reliability notice (day 65);", "the vertical rules mark the primary checkpoint (day 37), the September 2026 spam update (day 60) and the vendor data-reliability notice (day 65), and the August 2026 spam update (days 23 to 26) is not drawn;"),
    # altered result pages
    ("**Measurement 1 (Section 5).** Instrumentation is its subject rather than a caveat on it, and no outcome is a measured visit.",
     "**Measurement 1 (Section 5).** Instrumentation is its subject rather than a caveat on it, and no outcome is a measured visit. Trade press reports that Google has served altered result pages to suspected rank trackers since September 2026, with social and forum sites replacing tracked ones: 8.0% of one tracker's pages since 13 September [Rijo 2026a] and 5% to 20% by Ahrefs' account, depending on the provider, with Ahrefs cleaning up past results and Semrush dating the problem to late summer [Rijo 2026b]. These are secondary reports, and the effect here is not measured. Every read in this paper falls after that start; the day-37 figures describe earlier dates but were read from histories a vendor may revise, and a swap favoring social and forum sites would bear on Sections 5, 7 and 8 to 10 alike."),
    # "first day"
    ("this paper holds one site fixed, follows one section from its first day on two instruments, and compares twelve sections of the site on one date.",
     "this paper holds one site fixed, reads back two instruments' stored histories of one section to its first month, in a single retrospective read, and compares twelve sections of the site on one date."),
    # Section 6.1: keyword source, tie-break, keyword-level check
    ("built by the author's clustering engine from 1,898,584 keywords, each node carrying DataForSEO monthly search volume.",
     "built by the author's clustering engine from 1,898,584 keywords (the export labels 1,895,189 of them \"corpus\", 2,781 ranked keywords of three carrier domains and 614 authored), each node carrying DataForSEO monthly search volume."),
    ("and +0.47 (+0.01 to +0.78; p = 0.06) if each label's mentions go to the branch holding most of its nodes;",
     "and +0.47 (+0.01 to +0.78; p = 0.06) if each label's mentions go to the branch holding most of its nodes, with ties broken by the script's fixed order (59 of the 1,008 labels tie; under random tie-breaks the figure has a median of +0.50, and 95% of draws lie between +0.42 and +0.55; `m2_tiebreak_check.py`);"),
    ("with split attribution and +0.65 with modal attribution,", "with split attribution and +0.65 with modal attribution (at the top of its range under random tie-breaks, median +0.53, 95% of draws +0.44 to +0.645),"),
    ("and none concerns waiting in a store: they cover", "and none concerns waiting in a store (at the level of keywords, 532 of the 1,898,584 match the waiting pattern, with 114,329 searches, 0.01% of the file's volume, and nine name a store, shop or location, with 205 searches, some of them about an app store; `waiting_keywords_check.py`): they cover"),
    # Section 6.2
    ("Whatever the public count measures, it is not a scaled copy of the vendor's volume: the vendor's figure spreads the class across five orders of magnitude where the count spreads it across one.",
     "Whatever the public count measures, it is not a scaled copy of the vendor's volume: the vendor's figure spreads the class across five orders of magnitude where the count spreads it across one. Much of that spread is not the volume model alone: summed volume and the number of matched keywords rank the articles nearly alike (+0.90), and the logarithm of the keyword count accounts for 77% of the variance in the logarithm of volume, so the spread reflects how many keywords the carriers' exports matched for each code as well as the volume per keyword, whose geometric standard deviation is 7.0 (a post hoc check; `wiki_demand_supplement.py`)."),
    # Section 14
    ("amendment A4 records the author's decision of 13 October 2026 not to treat that confirmation as a precondition.",
     "amendment A4 records the author's decision of 13 October 2026 not to treat that confirmation as a precondition, so it is not among the open items below, and a reader should weigh that decision."),
])

NEW = [
    "Google. (2026). *Google Search Status Dashboard: Ranking incidents* [August 2026 spam update, 18 to 21 August]. Retrieved November 3, 2026, from https://status.search.google.com/products/rGHU1u87FJnkP6W2GwMi/history",
    "Rijo, L. (2026a, October 19). *Google feeds rank trackers swapped results on 8% of pages, Nozzle finds.* PPC Land. https://ppc.land/google-feeds-rank-trackers-swapped-results-on-8-of-pages-nozzle-finds/",
    "Rijo, L. (2026b, October 22). *Ahrefs says Google poisons 5% to 20% of results served to SEO data tools.* PPC Land. https://ppc.land/ahrefs-says-google-poisons-5-to-20-of-results-served-to-seo-data-tools/",
]


def key(line):
    line = unicodedata.normalize("NFKD", line).encode("ascii", "ignore").decode().lower()
    return line[4:] if line.startswith("the ") else line


head, refs_and_rest = s.split("\n## References\n", 1)
refs, rest = refs_and_rest.split("\n## Appendix A", 1)
lines = refs.split("\n")
# the reference label that an assessor found not matching its citation
a = "Ahrefs. (2026). *What is Organic Traffic in Ahrefs"
hits = [i for i, x in enumerate(lines) if x.startswith(a)]
if len(hits) != 1:
    raise SystemExit("REFUSE: Ahrefs organic-traffic entry not found once")
entry = lines[hits[0]].replace("Ahrefs. (2026).", "Ahrefs. (2026b).")
del lines[hits[0]:hits[0] + 2]
NEW.insert(0, entry)
# two Semrush entries added by edit_v53f.py were filed before The Motley Fool; they follow the first Semrush entry
for start in ("Semrush. (n.d.-b)", "Semrush. (n.d.-c)"):
    hits = [i for i, x in enumerate(lines) if x.startswith(start)]
    if len(hits) != 1:
        raise SystemExit(f"REFUSE: {start} not found once")
    NEW.append(lines[hits[0]])
    del lines[hits[0]:hits[0] + 2]
for entry in NEW:
    if any(x.startswith(entry[:32]) for x in lines):
        raise SystemExit(f"REFUSE: already present: {entry[:40]}")
    ents = [i for i, x in enumerate(lines) if x.strip() and not x.startswith("#")]
    pos = next((i for i in ents if key(lines[i]) > key(entry)), None)
    if pos is None:
        raise SystemExit("no insertion point")
    lines[pos:pos] = [entry, ""]
s = head + "\n## References\n" + "\n".join(lines) + "\n## Appendix A" + rest
P.write_text(s)
print(f"{len(s.split()):,} words")
