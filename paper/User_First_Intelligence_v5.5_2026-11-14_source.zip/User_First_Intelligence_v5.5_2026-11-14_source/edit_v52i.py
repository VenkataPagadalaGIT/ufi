"""Version 5.2, intervals on the headline statistics (independent measurement, statistics: the 8 anchor asks for
intervals on the main claims). New values printed by instrument_extra.py section 7, supplement_r10.py section 10 and
cross_sector_sensitivity2.py (last block), all percentile bootstraps with a fixed seed, and Wilson intervals."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:  # already applied: an insertion keeps its anchor, so a second run would insert twice
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("is +0.94 (p < 0.001; Kendall's tau +0.82, 60 of 66 pairs concordant).",
     "is +0.94 (bootstrap 95% interval over prefixes +0.70 to +1.00; p < 0.001; Kendall's tau +0.82, interval +0.57 to +1.00; 60 of 66 pairs concordant)."),
    ("the unmatched ratio has a geometric mean of 1.13 and a geometric standard deviation of 3.1,",
     "the unmatched ratio has a geometric mean of 1.13 (bootstrap 95% interval 0.62 to 2.12) and a geometric standard deviation of 3.1 (1.9 to 4.1),"),
    ("is +0.19 (Kendall's tau +0.13); counting the 26,809 linkable labels that no review mentions as zero, it is +0.27; both p < 0.001.",
     "is +0.19 (bootstrap 95% interval +0.12 to +0.25; Kendall's tau +0.13); counting the 26,809 linkable labels that no review mentions as zero, it is +0.27 (+0.26 to +0.29); both p < 0.001."),
    ("is then +0.75 (p < 0.001, 17 branches; Figure 6b), and +0.47 (p = 0.06) if each label's mentions go to the branch holding most of its nodes;",
     "is then +0.75 (bootstrap 95% interval over branches +0.44 to +0.90; p < 0.001, 17 branches; Figure 6b), and +0.47 (+0.01 to +0.78; p = 0.06) if each label's mentions go to the branch holding most of its nodes;"),
    ("924 (14.0%) match a pattern for waiting (wait, waited, waiting, long line, hours in line), against 1.9% of five-star reviews;",
     "924 (14.0%, Wilson 95% interval 13.1% to 14.8%) match a pattern for waiting (wait, waited, waiting, long line, hours in line), against 1.9% (1.8% to 2.1%) of five-star reviews;"),
    ("answer surface explains 77% of the variance of that share and sector 14%;",
     "answer surface explains 77% of the variance of that share (bootstrap 95% interval over sectors 70% to 91%) and sector 14% (5% to 20%);"),
])
P.write_text(s)
print(f"{len(s.split()):,} words")
