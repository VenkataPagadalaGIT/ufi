"""Version 5.3, 3 November 2026: from three blind paper-measure runs on the package of that morning (sha bcf09851; 7.3, 7.3,
7.2). Each item was checked at its source before the edit. The main one is a novelty error: the paper said no reporting
guidance exists for these tools, while a work it cites closes with such recommendations (Font-Julian et al. 2026, Section
5.2, read in the open-access copy at RiuNet on 3 November). Also: comparatives no script tests are withdrawn; the +0.91 of
the multi-word check reaches the abstract and conclusion; both vendors' traffic definitions are quoted from their own
documentation; Goel et al. 2010 is cited for what it shows; "registered" is replaced where no registry exists; Study W's
earliest Bitcoin anchor is 973,934, not 973,943; Ahrefs clause 4.4(i) is disclosed; the public Table 4 files are stated."""
import unicodedata
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    # abstract
    ("review demand and search volume agree only roughly on the taxonomy's branches (Spearman +0.47 to +0.75, depending on how labels are attributed to branches) and barely on topics (+0.18), on links that two blind AI annotators judged about two-thirds correct.",
     "review demand and search volume agree on the taxonomy's branches to a degree that depends on attribution and link quality (Spearman +0.47 to +0.75 on all links, up to +0.91 on multi-word labels in a post hoc check), size them very differently, and barely agree on topics (+0.18), on links that two blind AI annotators judged about two-thirds correct."),
    ("In one vendor's index of AI answers (Ahrefs Brand Radar, US, October 2026) that name the ten largest holdings", "In one vendor's index of AI answers (Ahrefs Brand Radar, US, October 2026) that name or cite the ten largest holdings"),
    # Section 1
    ("The place it was asked is increasingly not a search engine:", "The place it was asked is often not a search engine:"),
    ("The vendors do not claim otherwise in their documentation, which describes click models, of the kind studied in information retrieval [Chuklin, Markov & de Rijke 2015], applied to estimated volumes at estimated positions.",
     "The vendors do not claim otherwise in their documentation, which describes click models, of the kind studied in information retrieval [Chuklin, Markov & de Rijke 2015], applied to estimated volumes at estimated positions (Section 4.1)."),
    ("both recorded in the source bundle, found vendor tools compared", "both recorded in the source bundle, the second rating its own saturation partial, found vendor tools compared"),
    ("A third search, for reporting guidelines, on 31 October found none specific to such figures (Appendix E).",
     "A third search, on 31 October, looked for reporting guidelines for such figures and found no checklist; the nearest guidance is the set of recommendations closing one empirical comparison of the tools [Font-Julián et al. 2026], which Appendix E credits."),
    ("and barely agree on topics, most for complaints (Section 6.1).", "and barely agree on topics (Section 6.1)."),
    ("the two demand signals agree only roughly on the taxonomy's branches, size them very differently,", "the two demand signals agree on the taxonomy's branches to a degree that depends on attribution and link quality, size them very differently,"),
    # Section 2
    ("social sources made up 31% of Perplexity's citations against about 7% of ChatGPT's in nine consumer categories in January 2026 [Tinuiti 2026]", "social sources made up 31% of Perplexity's citations against about 7% of ChatGPT's in nine categories it chose in January 2026 [Tinuiti 2026]"),
    ("Section 7 differs in its frame, eleven sectors fixed by an external rule,", "One working paper a search found by title, on 80 global brands in LLM answers, could bear on the frame and could not be read [Cook 2025]. Section 7 differs in its frame, eleven sectors fixed by an external rule,"),
    ("has one documented component, one observation and one open question. Demand that never reaches a search engine in a countable phrasing is documented by the long-tail literature [Goel et al. 2010]; Section 8 adds",
     "has one adjacent documented finding, one observation and one open question. Long-tail studies show demand spread widely across rare items, in web search among other settings [Goel et al. 2010], though they do not measure demand that never reaches a search engine; Section 8 adds"),
    # Section 3.1
    ("and none mounted a visible response during the window.", "and none mounted a visible response during the window; this is an observation, with no archived record."),
    # Section 4.1
    ("**They are models, not counters.** Estimated visits are a click model over an estimated volume at an estimated position. No figure in this paper is a measured visit.",
     "**They are models, not counters, and not of the same unit.** Estimated visits are a click model over an estimated volume at an estimated position. Ahrefs describes its metric as an estimate of the clicks from Google that a target gets each month, summed over the keywords it ranks for from position, monthly search volume and an estimated click-through rate [Ahrefs 2026b]. Semrush describes its figure as the estimated number of visitors a domain receives from unpaid search results each month [Semrush n.d.-b], computed for its domain rankings from the click-through rate at the domain's positions and each keyword's monthly volume [Semrush n.d.-c]. Clicks and visitors are different units, and this paper cannot say how much of the ratios below that difference explains. No figure in this paper is a measured visit."),
    # Section 5.6
    ("and that keyword-universe size does not predict them.", "and that no relationship with keyword-universe size is detectable across them."),
    # Section 6.1
    ("carriers draw 66.8% of review mentions and 14.9% of search volume, devices 11.0% and 32.7%, broadband 4.0% and 18.1%.",
     "carriers draw 66.8% of review mentions and 14.9% of search volume, devices 11.0% and 32.7%, broadband 4.0% and 18.1%; the reviews are of carrier stores, which may itself raise the carriers' share of mentions."),
    ("The conclusions hold, and the branch-level agreement is stronger when the links are cleaner.",
     "The conclusions about topics and about shares hold; the branch-level rank agreement is much stronger when the links are cleaner, so what survives at that level is the difference in shares."),
    ("The pain point most often named by unhappy customers is close to invisible to the volume tool, and what it calls for",
     "A complaint named in about one in eight one- and two-star reviews, though no script ranks it against other complaints, is close to invisible in this taxonomy's volumes, and what it calls for"),
    ("agree only roughly on the broad areas of demand, size them very differently and barely agree on topics, and the disagreement is largest for complaints.",
     "agree on the broad areas of demand to a degree that depends on attribution and link quality, size them very differently and barely agree on topics; agreement among complaint labels (+0.16) is lower than among all frequent labels (+0.28), a difference these data do not test."),
    # Section 6.2
    ("before any request count was collected apart from a few probes of the endpoints that the plan lists (`02_DESIGN/wikipedia_demand_372.md`).",
     "before any request count was collected apart from a few probes of the endpoints that the plan lists (`wikipedia_demand/wikipedia_demand_372.md`)."),
    ("before the stamp reached a Bitcoin block (block 973,943, mined at 06:51 UTC): the proof dates the plan to within two hours of the read, and the order of the two within that span rests on the commit history and the collection log, which the author's agents wrote.",
     "before the stamp reached a Bitcoin block (the earliest is block 973,934, mined at 05:44 UTC): the proof shows that the plan existed within 25 minutes of the end of the read and does not by itself order the two; the order rests on the commit history and the collection log, which the author's agents wrote."),
    ("(+0.45, against +0.47 to +0.75 for the taxonomy's branches)", "(+0.45, against +0.47 to +0.75 on all links for the taxonomy's branches)"),
    ("the per-title monthly counts, the API responses they came from, the per-article and per-code tables and the scripts are released, and the analysis reruns from them.",
     "the per-title monthly counts, the API responses they came from, the per-article and per-code tables and the scripts are in the source bundle and prepared for release, and the analysis reruns from them."),
    # Section 13
    ("(Appendix A records the control that was registered and withdrawn)", "(Appendix A records the control that was planned and withdrawn)"),
    # Section 14
    ("For Section 6.2, everything is public data and is released: the plan", "For Section 6.2, everything is public data and is prepared for release alongside: the plan"),
    ("except through its API (clause 4.4(j), read 13 October 2026);", "except through its API (clause 4.4(j), read 13 October 2026), and searching, scraping or harvesting its data through any \"engine, software, tool, agent, device or mechanism\" other than its own (clause 4.4(i), read 3 November 2026);"),
    ("No written approval has been received. When it is, this paragraph will give its date, the approving role and unit, and its scope; until then, this paper does not state that approval was given.",
     "No written approval has been received. When it is, this paragraph will give its date, the approving role and unit, and its scope; until then, this paper does not state that approval was given. The twelve-prefix reads of Table 4 are already in the public repository, published on 12 October 2026 without that approval, so the approval has to cover them, or they have to be withdrawn."),
    ("The cross-prefix replication, registered before it was run, was performed on 12 October 2026 (Section 5.5); the within-class control registered with it was found not to exist (Section 3).",
     "The cross-prefix replication, planned in an earlier draft before it was run (its date rests on the author's records, with no third-party timestamp), was performed on 12 October 2026 (Section 5.5); the within-class control planned with it was found not to exist (Section 3)."),
    # conclusion
    ("User First Intelligence starts from the observation that people ask most of what they want to know somewhere other than a search box,", "User First Intelligence starts from the observation that people say what they want to know in many places that are not a search box,"),
    ("Two commercial analytics platforms, reading the same section from the day it appeared, disagreed", "Two commercial analytics platforms, in their records of the same section from the month it appeared, disagreed"),
    ("the two agreed only roughly on the taxonomy's branches (+0.47 to +0.75, depending on attribution) while sizing them very differently, and barely agreed on topics (+0.18, or +0.27 counting labels no review mentions), most for complaints: one in seven unhappy reviews matched",
     "the two agreed on the taxonomy's branches to a degree that depends on attribution and link quality (+0.47 to +0.75 on all links, up to +0.91 on multi-word labels, post hoc) while sizing them very differently, and barely agreed on topics (+0.18, or +0.27 counting labels no review mentions). One in seven unhappy reviews matched"),
    ("that would test the framework's two central claims;", "that would test two of the framework's claims;"),
    # Table D1
    ("| M2 branch agreement | Spearman between branch shares on each branch's own volume, by attribution rule | +0.47 (modal), +0.75 (split) |", "| M2 branch agreement | Spearman between branch shares on each branch's own volume, by attribution rule; multi-word labels only (post hoc) | +0.47 (modal), +0.75 (split); +0.65, +0.91 |"),
    # Appendix E
    ("Quote the definition and say whether the figure is a count or a model's output. Both visit figures here are vendor click models over estimated volumes at estimated positions (Section 4.1).",
     "Quote the definition and say whether the figure is a count or a model's output. Both visit figures here are vendor click models over estimated volumes at estimated positions, one defined in clicks and the other in visitors (Section 4.1)."),
    ("recorded in `01_LITERATURE/checklist_search_2026-10-31/` in the source bundle) found no reporting checklist for commercial search-analytics figures. The closest are documentation checklists for Google Trends [Nuti et al. 2014; Hölzl, Keusch & Sajons 2025], reporting items for Wikipedia page views [Alibudbud 2023], and reporting and disclosure standards for social-media data, including data obtained through commercial intermediaries [Kim, Huang & Emery 2016; Kostygina et al. 2023]; none names a commercial SEO or web-analytics tool such as Ahrefs, Semrush or Similarweb. Items 1, 2, 9 and 10 restate their access-date, parameter, access-path and data-sharing items for these instruments, item 9 adding who operated the interface and which of the vendor's terms were read; item 3 adds the distinction between counted and modeled figures; item 4 extends to a second instrument the repeated samples from one opaque instrument that Hölzl, Keusch and Sajons recommend, and applies to vendors the design of comparing engines on one query set [Thelwall 2008]; item 8 extends their external-validation item to a counted or first-party signal read beside the volume; items 5, 6 and 7 rest on this paper's findings.",
     "recorded in `literature/checklist_search_2026-10-31/` in the source bundle) found no reporting checklist for commercial search-analytics figures. Guidance on these tools does exist, and the search record passed over it: an empirical comparison of four SEO tools closes with methodological recommendations [Font-Julián et al. 2026, Section 5.2], to use several tools where possible, to prefer what several detect, to read traffic as relative rather than precise, and to report the tool, the extraction date, the market settings and each metric's definition. Items 1 to 4 cover the same ground and owe it that credit. Where those recommendations advise averaging traffic estimates across tools, this paper's ratios, which run in no fixed direction within one domain, suggest reporting the range. Further off are documentation checklists for Google Trends [Nuti et al. 2014; Hölzl, Keusch & Sajons 2025], reporting items for Wikipedia page views [Alibudbud 2023], and reporting and disclosure standards for social-media data, including data obtained through commercial intermediaries [Kim, Huang & Emery 2016; Kostygina et al. 2023], which name no commercial SEO or web-analytics tool. Items 1, 2, 9 and 10 share their access-date, parameter, access-path and data-sharing items, and item 8 extends their external-validation item to a counted or first-party signal read beside the volume. What this appendix adds is a numbered checklist motivated item by item by measured disagreement: the orderings of item 5, the territory pairing of item 6, the keyword universe of item 7 with the identity of E.2, and in item 9 who operated the interface and which of the vendor's terms were read; item 4 also applies to vendors the design of comparing engines on one query set [Thelwall 2008]."),
])

NEW = [
    ("Ahrefs. (2026). *What is Organic Traffic in Ahrefs and how do we calculate it?* [Help center article]. Retrieved November 3, 2026, from https://help.ahrefs.com/en/articles/1863206-what-is-organic-traffic-in-ahrefs-and-how-do-we-calculate-it", "Chuklin, A."),
    ("Cook, N. (2025). *Mind the invisibility gap: An analysis of 80 leading global brands in LLM answers* [Working paper; not read]. SSRN. https://doi.org/10.2139/ssrn.5698748", "Costco Wholesale"),
    ("Semrush. (n.d.-b). *Overview report* [Knowledge base article on Domain Overview]. Retrieved November 3, 2026, from https://www.semrush.com/kb/1202-domain-overview-overview-report", None),
    ("Semrush. (n.d.-c). *Semrush Rank* [Knowledge base article]. Retrieved November 3, 2026, from https://www.semrush.com/kb/semrush-reports-tools/domain-analytics/ranks/traffic-ranks/", None),
]
head, refs_and_rest = s.split("\n## References\n", 1)
refs, rest = refs_and_rest.split("\n## Appendix A", 1)
lines = refs.split("\n")


def key(line):
    return unicodedata.normalize("NFKD", line).encode("ascii", "ignore").decode().lower()


for entry, _ in NEW:
    if any(x.startswith(entry[:32]) for x in lines):
        raise SystemExit(f"REFUSE: already present: {entry[:40]}")
    ents = [i for i, x in enumerate(lines) if x.strip() and not x.startswith("#")]
    pos = next((i for i in ents if key(lines[i]) > key(entry)), None)
    if pos is None:
        raise SystemExit("no insertion point")
    lines[pos:pos] = [entry, ""]
s = head + "\n## References\n" + "\n".join(lines) + "\n## Appendix A" + rest
# the two existing vendor entries become the a-items of their years, with their one in-text citation each
for a, b in (("Ahrefs. (2026, September 3). *How to use Content Gap", "Ahrefs. (2026a, September 3). *How to use Content Gap"),
             ("Semrush. (n.d.). *How to use Keyword Gap?*", "Semrush. (n.d.-a). *How to use Keyword Gap?*")):
    if s.count(a) != 1:
        raise SystemExit(f"REFUSE: {s.count(a)} matches for {a!r}")
    s = s.replace(a, b)
if s.count("[Ahrefs 2026; Semrush n.d.]") == 1:  # in-text, Appendix B
    s = s.replace("[Ahrefs 2026; Semrush n.d.]", "[Ahrefs 2026a; Semrush n.d.-a]")
P.write_text(s)
print(f"{len(s.split()):,} words")
