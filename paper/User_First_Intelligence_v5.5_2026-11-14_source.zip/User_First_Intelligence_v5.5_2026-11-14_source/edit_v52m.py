"""Version 5.2, 15 October 2026: the date of the version, the Bitcoin anchoring of the two OpenTimestamps stamps (both
proofs were upgraded on 15 October 2026 and attest Bitcoin block 971,506, mined 04:05 UTC that day; merkle root
7bdc6025...59a3 checked against a public block explorer), and Appendix A's record of the independent reproduction."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:  # already applied: an insertion keeps its anchor, so a second run would insert twice
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("Manuscript version 5.2, 14 October 2026. Preprint, not yet peer reviewed.",
     "Manuscript version 5.2, 15 October 2026. Preprint, not yet peer reviewed."),
    ("were committed on 14 October 2026 and stamped with OpenTimestamps before any per-page outcome was read (`02_DESIGN/framework_retro_test_381.md` and its manifest).",
     "were committed on 14 October 2026 and stamped with OpenTimestamps before any per-page outcome was read (`02_DESIGN/framework_retro_test_381.md` and its manifest); the stamp is anchored in Bitcoin block 971,506, mined at 04:05 UTC on 15 October 2026."),
    ("was stamped with OpenTimestamps on 15 October 2026 before any reading under it.",
     "was stamped with OpenTimestamps before any reading under it, in the same Bitcoin block."),
    ("and replaced a stale copy of Figure 5 whose panel showed −0.09 for the −0.11 the text reports.",
     "and replaced a stale copy of Figure 5 whose panel showed −0.09 for the −0.11 the text reports. A separate agent then reproduced the source bundle in a clean folder: no number differed from what the released scripts and data give, but the count of works naming the vendor tools included three duplicates (456, not 459), several Section 5.5 statistics were printed by no script, and the Section 7 and figure scripts did not run from the bundle; all are corrected, and Section 7's numbers are now also printed from the released aggregates."),
    ("**What has not been done, after ten rounds of AI-simulated review.** No independent party has checked any number in this paper. The one check that would change that",
     "**What has not been done, after ten rounds of AI-simulated review.** No person other than the author has checked any number in this paper; the checks above were made by AI agents working from the released files, which cannot catch a misread dashboard. The one check that would change that"),
])
P.write_text(s)
print(f"{len(s.split()):,} words")
