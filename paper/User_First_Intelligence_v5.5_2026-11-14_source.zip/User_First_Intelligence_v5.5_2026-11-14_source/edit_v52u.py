"""Version 5.2, 15 October 2026: the Study R1 amendment's proof was upgraded and attests Bitcoin block 971,522 (mined
06:10 UTC on 15 October 2026; merkle root 6069d88e...9692c, checked against a public block explorer), and the fourth
independent reproduction (08_REVIEW/reproduction_v5.2_run4_2026-10-15/) found no mismatch."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("a dated amendment, stamped separately and released with the plan's manifest, records this.",
     "a dated amendment, released with the plan's manifest and anchored separately in Bitcoin block 971,522 (06:10 UTC on 15 October 2026), records this."),
    ("Separate agents reproduced the source bundle three times in clean folders on 15 October 2026. In the third, of 1,696 values the paper quotes, 1,555 matched what the released scripts and data give or what the agent recomputed from them, seven differed (a correlation and an interval end rounded twice, +0.19 and +0.29 for +0.18 and +0.28, and a stale cell in a released table; all are corrected) and 134 could not be checked because they need withheld data; the paper builds from the bundle (`08_REVIEW/reproduction_v5.2_run3_2026-10-15/`, with the two earlier runs beside it).",
     "Separate agents reproduced the source bundle four times in clean folders on 15 October 2026. The third found seven values that differed (a correlation and an interval end rounded twice, +0.19 and +0.29 for +0.18 and +0.28, and a stale cell in a released table), all since corrected; in the fourth, of 1,479 values the paper quotes from its own study, 1,342 matched what the released scripts and data give or what the agent recomputed from them, none differed, and 137 could not be checked because they need withheld data; the paper builds from the bundle (`08_REVIEW/reproduction_v5.2_run4_2026-10-15/`, with the three earlier runs beside it)."),
])
P.write_text(s)
print("ok")
