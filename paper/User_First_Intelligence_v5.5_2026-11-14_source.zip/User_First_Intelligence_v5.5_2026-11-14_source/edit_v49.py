"""v4.8 -> v4.9: the cross-sector AI-citation study (Section 5.8), the framework stated (Section 1.4),
abstract and contributions updated, Previsible acknowledgment and conflict line, figure renumbering.
Every replacement must match exactly once; the script stops otherwise."""
import re
import sys
from pathlib import Path

P = Path(__file__).with_name("manuscript_v49.md")
s = P.read_text()


def rep(old, new, count=1):
    global s
    n = s.count(old)
    if n != count:
        sys.exit(f"expected {count} match(es), found {n}: {old[:90]!r}")
    s = s.replace(old, new)


# ---------------------------------------------------------------- title block, keywords
rep("Manuscript version 4.8, 12 October 2026. Preprint, not yet peer reviewed.",
    "Manuscript version 4.9, 13 October 2026. Preprint, not yet peer reviewed.")
rep("AI Overviews; generative engine optimization;",
    "AI Overviews; AI answer citations; generative engine optimization;")

# ---------------------------------------------------------------- abstract (both paragraphs)
start = s.index("## Abstract") + len("## Abstract")
end = s.index("## 1 Introduction")
ABSTRACT = """

People say what they want to know in many places that are not a search box: forum threads, question sites, video comments, reviews, support tickets, social groups. Keyword-volume tools see the part of that demand that reaches a search engine in a countable form, and AI answer surfaces now stand between the question and the page. User First Intelligence (UFI) is a framework built on that premise: collect what people ask beyond the website; link it to the entities of an industry held under an ontology; keep structure, coverage and demand sources in separate roles in a knowledge graph; express user needs as executable competency questions; and score where the organization does not answer, treating the form of the answer as something to measure. An open implementation reading thirteen demand surfaces is released.

Three measurements motivate the framework. On 381 area-code pages of a large US telecommunications provider, observed from zero, two commercial analytics platforms differed on estimated monthly visits by 7.5x to 27.1x; across twelve sections of the same domain the ratio ran from 0.20x to 7.24x, unrelated to section age (Spearman −0.11), while the platforms agreed on which section is larger in 60 of 66 pairs. On 37,193 reviews of 378 telecom stores linked to a 42,994-node keyword taxonomy, review demand and search volume agree across branches (Spearman +0.78) but barely across topics (+0.19). Across the eleven S&P 500 sectors, 109 companies and eight AI answer surfaces (99,000 cited-domain rows over 20.4 million recorded answers), video and community sites take a median 21% of citations on Google's AI Overviews and AI Mode against 2% on ChatGPT, Perplexity, Gemini and Copilot, and the Google figure is higher than ChatGPT's and Copilot's in every sector. Of four registered predictions, one held, one held in direction only and two failed. The scoring function is specified, not evaluated. No causal claim is made.

"""
s = s[:start] + ABSTRACT + s[end:]

# ---------------------------------------------------------------- introduction
rep("and AI answer surfaces now sit between many questions and any page at all. User First Intelligence",
    "and AI answer surfaces now sit between many questions and any page at all, citing different kinds of source depending on which answer engine is asked (Section 5.8). User First Intelligence")

# contributions: insert item 5, renumber 5-8 to 6-9
rep("Section 5.7.\n5. **A methodological consequence**",
    "Section 5.7.\n5. **A cross-sector measurement of what AI answers cite**, pre-registered: the eleven S&P 500 sectors, their ten largest companies and eight answer surfaces. Video and community sources take a median 21% of citations on Google's answer surfaces and 2% on chat assistants, and the most-cited sources on chat assistants are industry-specific. Section 5.8.\n6. **A methodological consequence**")
rep("Section 5.6.\n6. **A 77-day deployment series**", "Section 5.6.\n7. **A 77-day deployment series**")
rep("Section 6.\n7. **An observation about which pages AI answers cite**", "Section 6.\n8. **An observation about which pages AI answers cite**")
rep("Section 7.\n8. **The deployment's cost", "Section 7.\n9. **The deployment's cost")

# Figure 1 caption pointer to 5.8
rep("Section 5.7 adds a first run on business reviews. (b)",
    "Section 5.7 adds a first run on business reviews and Section 5.8 measures the answer layer across eleven industries. (b)")

# ---------------------------------------------------------------- 1.4 the framework, stated
rep("## 2 Related work\n", """### 1.4 The framework, stated

User First Intelligence has six components and three measures. Appendix B gives the formulas; the released implementation gives the code.

1. **Demand surfaces.** The places where people state a need, in their own words or as a tool's reconstruction of it: thirteen surface types in the released implementation (Figure 1a). Every record carries its surface, collection date and collection terms.
2. **Industry ontology.** The classes, relations and enumerable entity sets of one industry, with competency questions written against it before any demand data is collected.
3. **A knowledge graph with separated source roles.** Every assertion carries one of three roles: structure (what exists, from registries and taxonomies), coverage (who answers, from the organization's pages, competitors' pages and AI answers) and demand (who asks, from the demand surfaces). Coverage never counts as demand, which is the error lesson 1 of Section 9.2 records.
4. **Competency questions.** User needs expressed as executable queries over the graph. A question the ontology cannot express is reported as a declared gap with a reason, not scored as zero.
5. **Answer surfaces.** Where answers are delivered and cited: the organization's own pages, search results and AI answer engines. Which kinds of source a surface cites is measured per surface, not assumed; Section 5.8 shows that it differs sharply between surfaces.
6. **The Content Gap Score.** A ranking of entities by prior importance, the organization's own non-coverage and the share of competency questions left unanswered.

The three measures are the competency-question schema pass rate (can the ontology express the question), the instance coverage rate (does the graph answer it) and the Content Gap Score. In this paper the demand surfaces are exercised on two of the thirteen (competitor keyword exports in Section 6 and business reviews in Section 5.7), the answer surfaces on eleven industries (Section 5.8), and the score is specified but not evaluated.

## 2 Related work
""")

# ---------------------------------------------------------------- figure renumbering (8 -> 9 first, then 7 -> 8)
s = s.replace("Figure 8", "Figure 9").replace("Figure 7", "Figure 8")

# ---------------------------------------------------------------- 5.8 the cross-sector study
SEC58 = """### 5.8 What AI answers cite, across eleven sectors and eight answer surfaces

The framework treats the form of an answer as something to measure rather than assume. One measurable property is the kind of source an answer engine cites. A pilot on one market and a pre-registered study across the whole index measure it.

**Pilot.** A commercial AI-visibility dataset for the US online-learning market, computed by the author's own analytics platform from Ahrefs Brand Radar exports (snapshot 22 September 2026) and read through its dashboard, holds 372,853 AI answers to 348,450 prompts that name no tracked brand, carrying 2,343,022 citations. The 22 tracked course providers together drew 19.9% of citations; youtube.com alone drew 12.4%, the most of any single domain; and video, forum, social and user-publishing sites among the fifteen most-cited outside domains drew at least 20.1%. Google's AI Overviews and AI Mode produced 92.9% of those answers and 98.0% of the citations, so the pilot could not say whether the pattern belongs to the industry or to Google's answer products. The study below was designed to separate the two.

**Design.** The design was written and dated on 12 October 2026, before any sector data was collected, and two amendments made before the first export are recorded with it in the released design file. The frame is the eleven GICS sectors of the S&P 500, an exhaustive partition maintained by S&P Dow Jones Indices and MSCI, so no industry was chosen for its result. The companies are the ten largest holdings by index weight in each sector's Select Sector SPDR fund, read from State Street's public fund pages (holdings as of 9 October 2026): 109 companies, because Communication Services counts one issuer, Alphabet, through two share classes. The instrument is Ahrefs Brand Radar, Explore view, United States, read through its web interface on 12 and 13 October 2026 with no API. For each sector, the cited-domains table was exported for each of eight answer surfaces (AI Overviews and AI Mode, each on Ahrefs' prompt set and on its search-query set; ChatGPT; Perplexity; Gemini; Copilot) and for all surfaces together: 99 exports of the 1,000 domains found in the most answers, which is the most this table exports. The universe is the set of answers that name or cite at least one of the sector's ten companies: 20,389,967 answer records across the eleven sectors, from 18,763 (Utilities) to 7,766,466 (Consumer Discretionary), where an answer naming companies from two sectors is counted in both. Source types were fixed before collection: video, forums and question sites, social networks and user-publishing platforms (together, "video and community"), reference, news, government, the sector's own companies, and other web. Shares are of the summed count of answers citing each domain over the 1,000 exported domains, computed within each surface.

![Figure 7. What AI answers cite, by sector and answer surface: Ahrefs Brand Radar, United States, the ten largest companies of each S&P 500 sector, read 12 and 13 October 2026. (a) Share of citations going to video and community domains (YouTube, TikTok, Vimeo, Reddit, Quora, Stack Overflow and Stack Exchange, Facebook, Instagram, LinkedIn, X, Pinterest, Threads, Medium, Substack, DEV, GitHub), among the 1,000 domains found in the most answers; sectors ordered by the Google mean. AIO and AIM are Google's AI Overviews and AI Mode, each on Ahrefs' search-query and prompt sets. (b) The rank of youtube.com among domains that are not one of the sector's companies, one marker per sector; bars are medians; a cross marks a sector where YouTube is outside the exported 1,000.](fig10_sources.pdf)

**Results.** The answer surface decides the kind of source. In every one of the eleven sectors, each of the four Google views gave video and community domains a larger share of citations than ChatGPT and Copilot did. Across sectors and views, the median share was 21.3% on the Google surfaces (range 8.1% to 35.8%) against 2.1% on the four chat assistants (0.3% to 16.7%): 0.9% on ChatGPT, 0.6% on Copilot, 4.6% on Perplexity and 9.2% on Gemini (Figure 7a). youtube.com was among the three most-cited domains other than the sector's own companies in 38 of the 44 sector-by-Google-view cells and in none of the 44 chat cells; its median rank was 1 on AI Overviews, 2 on AI Mode, 7 on Perplexity and Gemini, 151 on ChatGPT and 161 on Copilot (Figure 7b). Gemini is a Google product and sits with the chat assistants, so the contrast is between search-based answer products and chat assistants, not between companies.

The industry decides which sources, most visibly on the chat assistants. The most-cited domain other than the sector's own companies on ChatGPT was the Food and Drug Administration in Health Care, the Securities and Exchange Commission in Energy, Utilities and Real Estate, a personal-finance publisher in Financials and a paint maker in Materials, while on Google's AI Overviews it was youtube.com in nine sectors. An exploratory measure that was not registered points the same way: the ten most-cited domains outside the sector's companies overlap between sectors far more on the Google surfaces (mean pairwise Jaccard 0.36 to 0.40 across the 55 sector pairs) than on the chat assistants (0.08 to 0.23).

**The registered predictions.** Of the four, one held, one held in direction only and two failed. P1, that youtube.com is the most-cited non-company domain on AI Overviews and AI Mode in a majority of sectors, failed as registered: it held on AI Overviews (9 of 11 sectors on search queries, 8 of 11 on prompts) and not on AI Mode (2 of 11 on each), where google.com usually ranked first and YouTube second. P2, that YouTube ranks outside the five most-cited non-company domains on ChatGPT, Perplexity and Copilot in a majority of sectors, held on all three (11, 6 and 11 of 11). P3, that Reddit is among the ten most-cited non-company domains on every surface except Copilot in a majority of sectors, failed: it held in 3 of 11, and ChatGPT was a failing surface in all eight sectors where it did not hold. P4, that the video and community share on AI Overviews is higher in five consumer-facing sectors than in the other five, held in direction (26.9% against 24.2% on search queries, 29.6% against 24.4% on prompts) and not beyond chance (exact one-sided permutation p = 0.27 and 0.21).

**Limits.** The universe is conditional on the sector's companies appearing in the answer, so answers built only from other sources are absent. The 1,000-domain export truncates each list; types are assigned from a fixed list, so every type share is a lower bound and the remainder sits in "other web". Company domains are those entered for the study, so other properties of the same company count as outside domains (for example go.com for Disney and google.com for Alphabet). The prompt and search-query sets are the vendor's, not observed user demand. The read is one date, one country and one vendor's answer index. One name was ambiguous: "RTX" also matched answers about graphics cards. A re-run with "RTX Corporation" left the Google results essentially unchanged (YouTube's rank on AI Overviews stayed 1; the video and community share moved from 31.3% to 30.1%); its ChatGPT export failed twice on the vendor's side and the registered file stands. Citations per answer differ by surface, so shares are compared within surfaces and not pooled.

What this establishes for the framework is narrow and usable: which forms of content an answer engine cites depend first on the engine and then on the industry, so a content plan for Google's answer surfaces and one for chat assistants are different plans, and the answer layer has to be measured per surface.

## 6 The deployment series
"""
rep("## 6 The deployment series\n", SEC58)

# ---------------------------------------------------------------- threats: external validity
rep("one vendor pair; one read date for the cross-section; no ground truth.",
    "one vendor pair; one read date for the cross-section; no ground truth. For Section 5.8: one vendor's answer index, one country, one read date, and a universe conditional on the sector's companies appearing in the answer.")

# ---------------------------------------------------------------- 11: registered studies
rep("**A persona study on AI answer surfaces.**",
    "**A prompt-level replication of Section 5.8.** The same eleven sectors and eight surfaces at the level of the individual answer, with the cited pages of each, so that the source mix can be split by question type (how-to, definition, comparison, purchase) and the format claim tested within each sector rather than across them.\n\n**A persona study on AI answer surfaces.**")

# ---------------------------------------------------------------- 12: data, ethics, acknowledgment, conflicts
rep("at `data/instrument_divergence/` in the repository named above.",
    "at `data/instrument_divergence/` in the repository named above. For Section 5.8, the design file, the 109-company list with its source, the analysis and figure scripts, and the per-sector, per-surface aggregates (shares, ranks and the scored predictions) are released; the 99 raw vendor exports are not redistributed, because the vendor's terms restrict redistribution of its data, and any Brand Radar subscriber can re-export them with the settings the design file records.")
rep("and only per-label aggregate counts are reported.",
    "and only per-label aggregate counts are reported. The Brand Radar exports in Section 5.8 were read through the vendor's web interface, with no API, under a subscription held by Previsible, a digital marketing agency, with its written permission of 11 October 2026; the pilot dataset in Section 5.8 was computed by the author's own analytics platform and is reported in aggregate with no client named.")
rep("**Conflicts of interest.** As stated in Section 10.",
    "**Conflicts of interest.** As stated in Section 10. In addition, the author works with Previsible, whose subscription supplied the Section 5.8 data, and built the analytics platform that computed its pilot.")

# ---------------------------------------------------------------- rounds of review
rep("**What has not been done, after seven rounds of internal review.**",
    "**What has not been done, after nine rounds of internal review.**")
rep("has been through seven rounds of adversarial internal review.",
    "has been through nine rounds of adversarial internal review.")

# ---------------------------------------------------------------- conclusion
rep("most for complaints: one in seven unhappy reviews named waiting, which the taxonomy records at 12 searches a month.",
    "most for complaints: one in seven unhappy reviews named waiting, which the taxonomy records at 12 searches a month. Across the eleven sectors of the S&P 500 and eight AI answer surfaces, which kinds of source an answer cites depended first on the answer engine: video and community sites took a median 21% of citations on Google's AI Overviews and AI Mode and 2% on chat assistants, and on chat assistants the most-cited sources were specific to each industry. That is why the framework measures the form of the answer per surface rather than assuming it.")

# ---------------------------------------------------------------- Appendix A
rep("The organization that operates the section is no longer named; the author's affiliation is given as KL University only.",
    "The organization that operates the section is no longer named; the author's affiliation is given as KL University only.\n\n**v4.9.** Section 5.8 and Figure 7 add a pilot on one market and a cross-sector study of what AI answers cite: the eleven S&P 500 sectors, their ten largest companies and eight answer surfaces, registered in a dated design file before collection, with two amendments made before the first export. Two of the four registered predictions failed and one held only in direction; all four are reported. Section 1.4 states the framework's components and measures. The abstract, contribution list, Section 10, Section 11, Section 12 and the conclusion were updated; former Figures 7 and 8 are now Figures 8 and 9. Section 12 now names the agency whose subscription supplied the Section 5.8 data and the author's role in the platform that computed its pilot.")

P.write_text(s)
abstract = s[s.index("## Abstract") + 11:s.index("## 1 Introduction")]
print("abstract words:", len(abstract.split()))
print("figure refs:", sorted(set(re.findall(r"Figure \d+", s)), key=lambda x: int(x.split()[1])))
