"""Version 5.5, seventh edit (14 November 2026): the title.

Every independent assessment since October noted that the title named a framework the paper specifies and partly
exercises but does not evaluate, while its results are three measurements. On the author's instruction to do what is
needed before the preprint is announced, the title now leads with the measurements and keeps the framework, the
author's name for it, the knowledge graph and "query discovery beyond search volume". Nothing else changes.
"""
import pathlib

p = pathlib.Path(__file__).with_name("manuscript_v50.md")
s = p.read_text()
a = "# User First Intelligence for Traditional and AI Search (SEO and GEO/AEO): Ontology-Driven Query Discovery from Multi-Source Knowledge Graphs Beyond Search Volume\n"
b = "# User First Intelligence: Three Measurements of Search and AI-Answer Analytics (SEO and GEO/AEO), and a Knowledge-Graph Framework for Query Discovery Beyond Search Volume\n"
if not s.startswith(a):
    raise SystemExit("REFUSE: the first line is not the expected title (already applied or changed)")
p.write_text(b + s[len(a):])
print("edit_v55g applied")
