# Instrument divergence cross-section, 12 October 2026

Two commercial search-analytics instruments read for twelve URL prefixes on one
domain, on one day, through each vendor's own web interface under a paid
subscription. No API was used.

- `ahrefs_prefixes_2026-10-12.csv`: Ahrefs Site Explorer, prefix mode, all
  locations. Columns are the overview-card values as displayed. The
  `first_traffic_month` column is the first month with non-zero organic traffic
  in the all-time performance chart, read visually to the nearest month or
  quarter, and is the age proxy used in the paper. The instrument's history
  begins in September 2015, so one age (/es-us/local/, first month 2015-09) is left-censored at that horizon; /deals/ (2015-10) and /stores/ (2016-01) lie close to it.
  `ahrefs_us_share` is the United States share of the prefix's estimated
  visits from the overview's traffic-by-location table, read 12 October 2026,
  used to territory-match the two instruments.
- `semrush_prefixes_2026-10-12.csv`: Semrush Domain Overview, subfolder mode,
  US database. Columns are the summary-card values as displayed.

Semrush's AI-visibility panel (mentions, cited pages) returned identical values
for every subfolder queried and is therefore domain-scoped; those columns are
omitted from the Semrush file for that reason and the observation is recorded
in the paper.

`analyze.py` (run in this folder: `python3 analyze.py`) recomputes the cross-section statistics of Section 5.5 from
these files; the remaining Section 5.5 figures (the ordering significance and intervals, the spread, the size bands,
Table 4's ratio columns and the power) are printed by `instrument_extra.py`, released with the paper's data.

Known limits: ages are chart reads; one domain; one date.
