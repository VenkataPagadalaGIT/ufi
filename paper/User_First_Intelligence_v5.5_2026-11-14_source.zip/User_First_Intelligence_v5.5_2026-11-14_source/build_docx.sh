#!/bin/zsh
# Build the reviewer DOCX from the manuscript, using 300 dpi PNG figures (Word cannot show PDF figures).
set -e
cd "$(dirname "$0")"
# In the project the figures are in 05_FIGURES and the build in 06_MANUSCRIPT/build; in the source bundle both are here.
if [ -d ../../05_FIGURES ]; then FIGS=../../05_FIGURES; B=../build; else FIGS=.; B=build; fi
mkdir -p $B
SRC=${1:-manuscript_v50.md}
OUT=${2:-$B/paper.docx}
sed -E 's/\]\((fig[0-9]+_[a-z]+)\.pdf\)/](\1.png)/' "$SRC" > $B/manuscript_docx.md
pandoc $B/manuscript_docx.md -f markdown+pipe_tables+tex_math_dollars+implicit_figures -t docx \
  --resource-path=$FIGS -o "$OUT"
echo "wrote $OUT"
