"""Version 5.3, 3 November 2026: from the fifth independent reproduction (08_REVIEW/reproduction_v5.3_run5_2026-11-03/; 1,781
values on the morning's package: 1,628 matched, 2 differed, the Study W block and its time, both already corrected by
edit_v53f.py; 151 need inputs the bundle does not hold). P3's bar could not have failed at the spreads observed, which
the paper now says (printed by wiki_demand_supplement.py); the +0.41 is marked as needing the withheld scores."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("(P3, held; the plan calls this bar lax, since it fails only if log requests track log volume at a Pearson correlation above about 0.9).",
     "(P3, held; the plan calls this bar lax, since at comparable spreads it fails only if log requests track log volume at a Pearson correlation above about 0.9, and at the spreads observed it could not have failed: the ratio's geometric standard deviation cannot fall below 11.1 at any correlation)."),
    ("The exploratory correlation between the Content Gap Score and the count, +0.41, is not a test of the score, which contains the vendor's volume.",
     "The exploratory correlation between the Content Gap Score and the count, +0.41, is not a test of the score, which contains the vendor's volume; it needs the per-code scores held back with Study R1, so a run on the released files prints every other figure and not this one."),
    ("and version 5.2 responds to that measurement;", "and versions 5.2 and 5.3 respond to that measurement;"),
    ("Separate agents reproduced the source bundle four times in clean folders on 15 October 2026.", "Separate agents reproduced the source bundle four times in clean folders on 15 October 2026 and once more on 3 November."),
    ("the paper builds from the bundle (`08_REVIEW/reproduction_v5.2_run4_2026-10-15/`, with the three earlier runs beside it).",
     "the paper builds from the bundle. The fifth, on the package before this version's last corrections, checked 1,781 values: 1,628 matched, 2 differed (one block number and its time in Section 6.2, since corrected) and 151 need inputs the bundle does not hold. Of the matches, 146 cannot fail, because those series files are parsed from the paper's own tables, and 220 confirm a value only against a released file recording a dashboard read or a plan, so none of these checks can catch a misread dashboard (`08_REVIEW/reproduction_v5.3_run5_2026-11-03/`, with the four earlier runs beside it)."),
])
P.write_text(s)
print(f"{len(s.split()):,} words")
