"""Version 5.2, 15 October 2026: from the final-version blind paper-measure runs (sha 728d784d). Two close works the
released independent search found are cited after checking each (Kirsten et al. 2026, Findings of ACL, on Crossref;
Grossman et al. 2026 on arXiv), and "released with the paper's data" is made consistent with Section 14, which says the
files are prepared for public release: they are in the source bundle distributed with the manuscript."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("(`vendor_reliance.py` and `stakes_screen_check.py`, released with the paper's data).",
     "(`vendor_reliance.py` and `stakes_screen_check.py`, in the source bundle)."),
    ("and an independent search of five databases with citation chasing by a separate agent on 15 October, both released with the paper's data,",
     "and an independent search of five databases with citation chasing by a separate agent on 15 October, both recorded in the source bundle,"),
    ("The per-label counts behind every correlation in this section are released in anonymized form,",
     "The per-label counts behind every correlation in this section are in the source bundle in anonymized form,"),
    ("the protocol and every file its stamped manifest lists are released with the paper's data.",
     "the protocol and every file its stamped manifest lists are in the source bundle."),
    ("this sentence is replaced by a commit hash when they are.",
     "this sentence is replaced by a commit hash when they are. Until then, every file prepared for release is in the source bundle distributed with this manuscript, which carries no licensed rows, review text or reviewer names."),
    ("did not appear on the first page of results shown with them [Xu, Iqbal & Montgomery 2026];",
     "did not appear on the first page of results shown with them [Xu, Iqbal & Montgomery 2026]; on 11,500 queries, the sources retrieved by Google Search, AI Overviews and Gemini overlapped little (Jaccard similarity below 0.2 on average), with the generative systems favoring Google-owned content [Grossman et al. 2026]; five generative search systems from three providers reached topical coverage comparable to Google's organic results through markedly different retrieval footprints [Kirsten et al. 2026];"),
])

NEW = {  # inserted before the reference that follows each alphabetically
    "Hannak, A.": "Grossman, R., Liu, S., Chen, M. K., Smith, M., Borcea, C., & Chen, Y. (2026). *How generative AI disrupts search: An empirical study of Google Search, Gemini, and AI Overviews* [Preprint]. arXiv:2604.27790.",
    "Kumar, P.": "Kirsten, E., Grosse Perdekamp, J., Wu, Q., Upadhyay, M., Gummadi, K. P., & Zafar, M. B. (2026). Characterizing web search in the age of generative AI. In *Findings of the Association for Computational Linguistics: ACL 2026* (pp. 10827–10848). https://doi.org/10.18653/v1/2026.findings-acl.526",
}
lines = s.split("\n")
for anchor, entry in NEW.items():
    idx = [i for i, x in enumerate(lines) if x.startswith(anchor)]
    if len(idx) != 1:
        raise SystemExit(f"REFUSE: {len(idx)} reference lines start with {anchor!r}")
    lines[idx[0]:idx[0]] = [entry, ""]
s = "\n".join(lines)
P.write_text(s)
print(f"{len(s.split()):,} words")
