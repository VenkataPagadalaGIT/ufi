User First Intelligence, manuscript v5.5 (14 November 2026): source bundle.

Build: paper.tex compiles with XeLaTeX (fontspec, unicode-math; fonts TeX Gyre Termes and
Latin Modern Math, loaded by file name, as arXiv's documentation requires for its xelatex
processor, offered since November 2025). Tested with tectonic 0.17.

manuscript_v50.md is the source of truth; build_tex.py converts it to paper.tex (in build/) and
build_docx.sh to Word (build/paper.docx), from the figures beside them. edit_v49*.py and edit_v5*.py record
every change made since version 4.8, in order (each refuses to run twice); edit_v49*.py and edit_v50.py ran on the file under its earlier
name, manuscript_v49.md. make_figs_v4.py and make_fig0.py draw the figures (the Section 6 and 7 figures are drawn
by make_fig_reviews_v50.py and make_fig_sources.py in their folders).

data/ holds the twelve-prefix instrument-divergence reads and analyze.py (Section 5.5).
review_demand/ holds the Section 6 scripts and their printed output (the review data itself is not released).
ai_citation_cross_sector/ holds the Section 7 design, scripts, outputs and aggregates; raw vendor
exports are not included. scripts/section7_from_aggregates.py prints Section 7's numbers from the aggregates
(see the folder's README).
instrument_divergence_extra/ holds instrument_extra.py (runs from this folder), its output, the series of
Tables 2, 3, 5 and 6 as CSV, and single_reads_2026-10.csv, every single dashboard read the paper quotes.
review_demand/ also holds the link check of Section 6: the sampling script and its output, the word count of each
sampled link's label, the two blind annotators' judgments (no review text) and the analysis that turns them into
precision and agreement (python3 r2_link_check.py runs in that folder), with the annotators' protocol
(r2_annotation_protocol.md); m2_label_counts.csv and m2_branches.csv hold Section 6's per-label counts, anonymized
(no label names, volumes as ranks), from which python3 m2_from_counts.py recomputes Section 6's correlations,
shares and intervals.
protocols/ holds the stamped replication protocols for Measurement 1 (Studies A and B) with every file their
manifest lists, so the timestamp can be checked.
stakes/ counts the works in OpenAlex naming the vendor tools (Section 1; python3 vendor_reliance.py --offline recounts
the released list); literature/ holds the novelty search, the independent search by a separate agent, and the search for
reporting checklists behind Appendix E (checklist_search_2026-10-31/).
08_REVIEW/reproduction_v5.*/ are the five independent reproductions of builds of this bundle (15 October and 3 November
2026), by AI agents; the changelog says what was done about each problem they found.
08_REVIEW/factcheck_v5.5_2026-11-14/ holds the three reports of the source check of 14 November 2026, in which AI agents
compared every reference entry and every citing sentence with its source; the changelog says what was reworded.
edu_ai_citations_intl/ holds Section 7.7: counts per country and vendor view for the author's education exports in thirteen
countries (no prompt, answer text or URL), the script that made them from the exports, and intl_from_cells.py, which prints
Section 7.7's numbers from the counts (python3 intl_from_cells.py runs in that folder); export_ledger.jsonl is the
collection's own record of each export file (name, rows returned and shown, checksum, counts per vendor view).
framework_test_r1/ holds the timestamped manifest of Study R1 (Section 13); its files name the website studied, which
the paper does not name, so they are held back; if they are released they can be checked against the manifest.
wikipedia_demand/ holds Study W (Section 6.2): the plan with its predictions, the manifest stamped before collection,
the collector, the per-title monthly Wikipedia pageviews it read, the per-article and per-code tables, the analysis
(python3 wiki_demand_analysis.py runs in that folder), a supplement written after the data were read, and the figure
script, all on public data.
arxiv_abstract.txt is the abstract for the arXiv form (under 1,920 characters).

On arXiv this bundle is the preprint's ancillary files (the anc/ folder), without paper.tex, which is the
submission's own source. Section 14 of the paper states what is open at posting.
