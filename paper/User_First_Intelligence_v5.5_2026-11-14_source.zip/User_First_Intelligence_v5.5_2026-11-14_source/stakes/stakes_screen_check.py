"""The stakes count screened: of a random sample of the works that name Ahrefs, Semrush or Similarweb in title or
abstract (stakes_screen_sample.py), how many use a vendor's figures as data, how many of those use one vendor only,
and how many compare vendors; judged from title and abstract by two blind annotators (separate AI agents on different
models, given only the sample and a fixed protocol, stakes_screen_protocol.md). Written and committed before either
annotator's judgments were read.

Inputs, in this folder: stakes_screen_judgments_1.csv and stakes_screen_judgments_2.csv
(sample_id, uses_vendor_data, tools_used, compares_tools). Prints the results; reads no abstract.
"""
import csv
import math
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent


def load(name):
    return {r["sample_id"]: r for r in csv.DictReader((HERE / name).open())}


def wilson(k, n, z=1.96):
    if n == 0:
        return float("nan"), float("nan")
    p = k / n
    c = (p + z * z / (2 * n)) / (1 + z * z / n)
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    return c - h, c + h


def kappa(a, b, ids):
    n = len(ids)
    po = sum(a[i] == b[i] for i in ids) / n
    ca, cb = Counter(a[i] for i in ids), Counter(b[i] for i in ids)
    pe = sum(ca[c] * cb[c] for c in set(ca) | set(cb)) / (n * n)
    return (po - pe) / (1 - pe) if pe < 1 else float("nan"), po


j1, j2 = load("stakes_screen_judgments_1.csv"), load("stakes_screen_judgments_2.csv")
ids = sorted(set(j1) & set(j2))
print(f"== Works sampled and judged by both annotators: {len(ids)}")
u1 = {i: j1[i]["uses_vendor_data"].strip().lower() for i in ids}
u2 = {i: j2[i]["uses_vendor_data"].strip().lower() for i in ids}
for name, u, j in (("annotator 1", u1, j1), ("annotator 2", u2, j2)):
    c = Counter(u.values())
    k, n = c["yes"], len(ids)
    lo, hi = wilson(k, n)
    yes = [i for i in ids if u[i] == "yes"]
    one = sum(1 for i in yes if len([t for t in j[i]["tools_used"].split(";") if t.strip()]) == 1)
    comp = sum(1 for i in yes if j[i]["compares_tools"].strip().lower() == "yes")
    l1, h1 = wilson(one, len(yes))
    print(f"  {name}: {dict(c)}; use a vendor's figures as data {k}/{n} = {k / n:.0%} [Wilson 95% {lo:.0%}, {hi:.0%}]; "
          f"of those, one vendor only {one}/{len(yes)} = {one / len(yes):.0%} [{l1:.0%}, {h1:.0%}]; compare vendors {comp}")
both = [i for i in ids if u1[i] == u2[i] == "yes"]
k_, po = kappa(u1, u2, ids)
print(f"  agreement on uses_vendor_data: {po:.0%} of {len(ids)}; Cohen's kappa {k_:.2f}; both say yes: {len(both)}")
lo, hi = wilson(len(both), len(ids))
print(f"  share both annotators judge to use a vendor's figures as data: {len(both)}/{len(ids)} = {len(both) / len(ids):.0%} [{lo:.0%}, {hi:.0%}]")
