# Screening the works that name a vendor tool: annotation protocol

Each annotator receives only `03_DATA/raw/stakes_screen/sample.csv` (sample_id, year, type, title, abstract) and
these instructions, and judges each work on its title and abstract alone.

For each row:

- **uses_vendor_data**: `yes` if the work uses figures produced by Ahrefs, Semrush or Similarweb (for example traffic
  or visit estimates, keyword rankings or search volumes, backlink or referring-domain counts, authority scores,
  audience or market-share figures) as data or evidence in its own analysis; `no` if a tool is only named (in a list of
  tools, as an example, as the subject of a description or review without its figures being analyzed, or the match is
  a different sense of the word); `unclear` if the title and abstract do not let you tell.
- **tools_used**: if yes, which of the three tools' figures are used, as a semicolon list (`Ahrefs;Semrush`); leave
  empty otherwise.
- **compares_tools**: `yes` if the work compares figures from two or more such tools (any vendor of traffic or SEO
  metrics) with each other or with first-party analytics; `no` otherwise; leave empty if uses_vendor_data is not yes.
- **reason**: at most twelve words of your own, not quoted from the abstract.

Read every row in full; do not sample, skip or guess. Do not search the web or open any other file.
