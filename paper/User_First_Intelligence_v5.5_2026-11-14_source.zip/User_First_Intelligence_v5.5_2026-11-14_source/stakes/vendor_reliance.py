"""How much published research names a commercial traffic-estimation tool (Section 1, the stakes of Measurement 1).

Counts works in OpenAlex whose title or abstract names Ahrefs, Semrush or Similarweb, by year, and how many of them
name only one of the three, a mechanical proxy for single-vendor use (naming one tool does not prove the work used one
vendor's figures as data, and naming several does not prove a comparison). Writes vendor_reliance_works.csv, the
list as retrieved (duplicates included), and prints the summary. Read through the public OpenAlex API; rerunning on a
later date returns more works.

Usage: python3 vendor_reliance.py            query OpenAlex now and rewrite the work list
       python3 vendor_reliance.py --offline  recompute the summary from the saved work list (the 14 October 2026 read)
Numbered paging can return a work twice; works are counted once by OpenAlex id (the 14 October list holds three such
repeats). --offline never rewrites the list.
"""
import sys
import csv
import json
import re
import urllib.parse
import urllib.request
from collections import Counter
from datetime import date
from pathlib import Path

UA = {"User-Agent": "vendor-reliance-count (mailto:none@example.org)"}
TOOLS = {"Ahrefs": re.compile(r"ahrefs", re.I), "Semrush": re.compile(r"semrush", re.I), "Similarweb": re.compile(r"similar\s?web", re.I)}
OUT = Path(__file__).with_name("vendor_reliance_works.csv")


def page(n):
    # numbered pages: cursor paging returned HTTP 401 on 14 October 2026; numbered pages reach 10,000 results
    q = {"filter": "title_and_abstract.search:semrush|ahrefs|similarweb", "per-page": 100, "page": n}
    u = "https://api.openalex.org/works?" + urllib.parse.urlencode(q)
    return json.load(urllib.request.urlopen(urllib.request.Request(u, headers=UA), timeout=60))


rows, n, cursor = [], 1, "--offline" not in sys.argv
if not cursor:
    rows = [dict(r, n_tools=int(r["n_tools"])) for r in csv.DictReader(OUT.open())]
while cursor:
    d = page(n)
    n += 1
    for w in d["results"]:
        inv = w.get("abstract_inverted_index") or {}
        pos = {p: t for t, ps in inv.items() for p in ps}
        text = (w.get("title") or "") + " " + " ".join(pos[i] for i in sorted(pos))
        named = [t for t, rx in TOOLS.items() if rx.search(text)]
        rows.append({"id": w["id"], "doi": w.get("doi") or "", "year": w.get("publication_year"), "type": w.get("type"),
                     "title": (w.get("title") or "").strip(), "tools_named": ";".join(named), "n_tools": len(named)})
    cursor = bool(d["results"]) and len(rows) < d["meta"]["count"]

ONLINE = "--offline" not in sys.argv
if ONLINE:
    with OUT.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
seen, uniq = set(), []
for r in rows:
    if r["id"] not in seen:
        seen.add(r["id"])
        uniq.append(r)
dups, rows = len(rows) - len(uniq), uniq

matched = [r for r in rows if r["n_tools"] >= 1]
by_year = Counter(r["year"] for r in matched)
one = sum(1 for r in matched if r["n_tools"] == 1)
recent = [r for r in matched if r["year"] and 2023 <= int(r["year"]) <= 2026]
print(f"{'offline, from the saved list' if '--offline' in sys.argv else 'read ' + str(date.today())}: {len(rows)} distinct works "
      f"({dups} duplicates dropped); {len(matched)} name at least one tool in the retrieved title or abstract")
print("by year:", ", ".join(f"{y}: {by_year[y]}" for y in sorted(k for k in by_year if k)))
print(f"name exactly one of the three: {one} of {len(matched)} ({one / len(matched):.0%}); two or more: {len(matched) - one}")
r1 = sum(1 for r in recent if r["n_tools"] == 1)
print(f"2023 to 2026: {len(recent)} works, {r1} ({r1 / len(recent):.0%}) name exactly one tool")
print("works per tool:", ", ".join(f"{t}: {sum(1 for r in matched if t in r['tools_named'].split(';'))}" for t in TOOLS))
if ONLINE:
    print(f"wrote {OUT.name}")
