"""Screening the stakes count (independent measurement, 15 October 2026: "the evidence that the field needs this
answer now is an unscreened keyword count"). Of the works in vendor_reliance_works.csv that name Ahrefs, Semrush or
Similarweb, a random sample (fixed seed) is drawn and each work's title and abstract are fetched from the public
OpenAlex API, so that two blind annotators can judge whether the work uses a vendor's figures as data.

Writes 03_DATA/raw/stakes_screen/sample.csv (titles and abstracts; git-ignored, since abstracts belong to their
publishers) and, beside this script, stakes_screen_ids.csv (sample id and OpenAlex id only, released).
Usage: python3 stakes_screen_sample.py
"""
import csv
import json
import random
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
DST = HERE.parents[1] / "03_DATA/raw/stakes_screen"
N, SEED = 120, 20261015
UA = {"User-Agent": "stakes-screen (mailto:none@example.org)"}

rows, seen = [], set()
for r in csv.DictReader((HERE / "vendor_reliance_works.csv").open()):
    if r["id"] not in seen and int(r["n_tools"]) >= 1:
        seen.add(r["id"])
        rows.append(r)
sample = random.Random(SEED).sample(rows, N)
DST.mkdir(parents=True, exist_ok=True)
with (DST / "sample.csv").open("w", newline="") as f, (HERE / "stakes_screen_ids.csv.tmp").open("w", newline="") as g:  # replaces the released list only on success
    w, wi = csv.writer(f), csv.writer(g)
    w.writerow(["sample_id", "year", "type", "title", "abstract"])
    wi.writerow(["sample_id", "openalex_id", "year", "tools_named_by_keyword_match"])
    for k, r in enumerate(sample, 1):
        wid = r["id"].rsplit("/", 1)[-1]
        d = json.load(urllib.request.urlopen(urllib.request.Request(f"https://api.openalex.org/works/{wid}", headers=UA), timeout=60))
        inv = d.get("abstract_inverted_index") or {}
        pos = {p: t for t, ps in inv.items() for p in ps}
        abstract = " ".join(pos[i] for i in sorted(pos))
        sid = f"S{k:03d}"
        w.writerow([sid, r["year"], r["type"], (d.get("title") or r["title"]).strip(), abstract])
        wi.writerow([sid, r["id"], r["year"], r["tools_named"]])
        time.sleep(0.15)
(HERE / "stakes_screen_ids.csv.tmp").replace(HERE / "stakes_screen_ids.csv")
print(f"{len(rows)} works name a tool; sampled {N} with seed {SEED}; wrote 03_DATA/raw/stakes_screen/sample.csv and stakes_screen_ids.csv")
