# Study R1, amendment of 15 October 2026 (disclosure; no analysis decision changed)

Written 15 October 2026, before any of Study R1's registered outcomes (O1 to O3, per code page) has been read for any
code. Kept in its own file so that `framework_retro_test_381.md` stays byte-identical to the version whose SHA-256 is in
the stamped manifest (`framework_retro_test_381_manifest.txt`, OpenTimestamps proof anchored in Bitcoin block 971,506).

**What had been seen before the plan was written.** The plan says that per-page outcomes "have not been read for this
study" and that the author had seen section-level totals (Table 5). That is true of O1 to O3, but it leaves out per-page
information that earlier reads for the paper had shown, on 11 October 2026, three days before the plan:

- Ahrefs Brand Radar's count of stored AI answers citing each page, for the eight most-cited pages under the prefix:
  five hub pages and the code pages for 214, 786 and 404 (manuscript Section 9.1, Figure 8). AI citation is not one of
  R1's outcomes.
- Ahrefs Site Explorer's top-pages report for the prefix, from which the share of estimated visits held by the ten and
  the fifty highest-traffic URLs was computed (Section 8). That report lists URLs with their estimated traffic, so it
  showed which pages led on traffic at day 77; O2 is estimated visits per page at day 37.

**Why the analysis is unchanged.** The predictors use only the October 2025 exports and the NANPA registry, with the
Content Gap Score's parameters taken from the lock committed to the released implementation on 12 October 2026 (digest
`7290a2235d8de05f`), before the plan; the hypotheses and the analysis follow the score's published specification. The
predictor table was frozen by checksum (`65c5c3cb...`) on 14 October. Nothing above was used to choose a predictor, a
parameter, an outcome or a hypothesis, but a reader cannot verify that, and the test should be read as one whose
author had seen this much.

**Reported in the paper.** Section 13 states which per-page information had been seen and cites this file.
