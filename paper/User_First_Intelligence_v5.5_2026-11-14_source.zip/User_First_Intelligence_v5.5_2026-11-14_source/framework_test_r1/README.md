# Study R1: the retrospective test of the Content Gap Score (held back)

The plan, the frozen predictions and the analysis script of Study R1 name the website studied, which the paper does not
name (manuscript Section 14). They are held back
from this release. What is released now is the manifest of their SHA-256 digests and its OpenTimestamps proof, which
show that the files existed, as committed, before any outcome was read. When the files are released, anyone can check
them against this manifest: `ots verify framework_retro_test_381_manifest.txt.ots`, then compare each file's SHA-256
with the manifest. `framework_retro_test_381_amendment_2026-10-15.md`, released here with its own timestamp (Bitcoin block 971,522,
mined at 06:10 UTC on 15 October 2026), discloses
the per-page information the author had seen before the plan was written; it changes no analysis decision, and it is
kept apart from the plan so that the plan still matches the manifest. The manifest's proof attests Bitcoin block 971,506, mined at 04:05 UTC on 15 October 2026 (merkle root
7bdc60257b41068f09d1157f28005268d7430ba65143d263243a5d46a24659a3, which `ots info` prints and any block explorer shows).
