"""Version 5.2 cycle (14 October 2026). Byline and acknowledgments from the author's information:
the KL University line in full with the author's title and email, as the author gave it; the employer line is
left out until the organization's written permission is in hand (author's decision, 14 October). The mentor is
thanked as the author worded it, without the clause about an April 2026 version, which this paper did not have.
Trailing backslashes make the byline lines hard breaks, so the DOCX keeps them on separate lines.
"""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:  # already applied: an insertion keeps its anchor, so a second run would insert twice
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("**Venkata Pagadala**\nKL University (doctoral program), Andhra Pradesh, India\n",
     "**Venkata Pagadala**\\\nResearch Scholar (Ph.D. in progress, Artificial Intelligence), KL University (Koneru Lakshmaiah Education Foundation), India\\\nvdepagadala@gmail.com\\\n"),
    ("\n## References\n",
     "\n## Acknowledgments\n\nThe author thanks Dr. Kurra Rajasekhara Rao, the author's doctoral mentor at KL University, for guidance.\n\n## References\n"),
])
P.write_text(s)
print(f"{len(s.split()):,} words")
