"""Version 5.2: the version line, Appendix A's record of what 5.2 changed, and the AI-use statement's account of the
independent measurement that prompted it."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:  # already applied: an insertion keeps its anchor, so a second run would insert twice
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("Manuscript version 5.1, 13 October 2026. Preprint, not yet peer reviewed.",
     "Manuscript version 5.2, 14 October 2026. Preprint, not yet peer reviewed."),
    ("Versions 5.0 and 5.1 together added 19 references.",
     "Versions 5.0 and 5.1 together added 19 references. Version 5.2 followed the first measurement of the manuscript by a separate scoring agent that saw only the paper and its released files: it moved the history of withdrawn claims out of the results into this appendix; added the closest prior comparisons of SEO tools, found by a documented search (Section 2), and the score's position against the closest methods (Appendix B), with six references; released every single dashboard read the paper quotes as a data file; made the script that prints the ordering significance and the reversed pairs print them, since those lines had been in its saved output without being produced by it (the values are unchanged); and replaced a stale copy of Figure 5 whose panel showed −0.09 for the −0.11 the text reports."),
    ("and ran the ten review rounds, recorded in the project's review log, as simulated panels of AI reviewers, which are not peer review.",
     "and ran the ten review rounds, recorded in the project's review log, as simulated panels of AI reviewers, which are not peer review; a separate scoring agent, given only the paper and its released files and none of the review history, measured the manuscript against a fixed rubric, and version 5.2 responds to that measurement."),
])
P.write_text(s)
print(f"{len(s.split()):,} words")
