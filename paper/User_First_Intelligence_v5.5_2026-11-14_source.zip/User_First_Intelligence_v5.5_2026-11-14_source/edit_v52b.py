"""Version 5.2 cycle, fixes from the first independent measurement (06_MANUSCRIPT/measurements/
2026-10-14_5df347a7_224253.md; paper-measure skill, blind assessor). Applied here: version-history narration taken
out of the results and kept in Appendix A, which gains the three withdrawals it lacked; the "455 cited pages"
cross-reference, which pointed to a section that does not carry the count, now points to the released single-read
file (03_DATA/single_reads_2026-10.csv). Figure 5 is rebuilt separately, so its panel shows the -0.11 the text
reports.
"""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:  # already applied: an insertion keeps its anchor, so a second run would insert twice
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("An earlier version of this work claimed a bound from a comparison with two carriers of similar authority; that comparison is computed within a set selected on the provider's own presence and bounds nothing, as Section 9.2 sets out.",
     "A comparison with two carriers of similar authority does not bound it either, because it is computed within a set selected on the provider's own presence (Section 9.2)."),
    ("Brand Radar's count of 455 distinct cited pages (Section 5.3) exceeds 434 by 21;",
     "Brand Radar's count of 455 distinct cited pages, read on 11 October and listed with the paper's other single dashboard reads in the released data, exceeds 434 by 21;"),
    ("Version 4.0 proposed that the narrowing of the visits ratio reflected section age and index coverage, and version 4.0 registered a cross-prefix replication as the test. It was run on 12 October 2026, on both instruments,",
     "That the narrowing of the visits ratio there reflects section age, each vendor's index filling in at its own rate, was stated as a hypothesis, with a cross-prefix test, before the test was run (Appendix A). The test was run on 12 October 2026, on both instruments,"),
    ("Six things follow (Figure 5), and the first retracts a claim this paper made in version 4.0.",
     "Six things follow (Figure 5); the first is that the age hypothesis fails."),
    ("The hypothesis in version 4.0, that each vendor's index fills in at its own rate and the ratio settles as a section ages, is withdrawn, and the narrowing",
     "The age hypothesis, that each vendor's index fills in at its own rate and the ratio settles as a section ages, is therefore withdrawn, and the narrowing"),
    ("which is inconsistent with the mechanism version 4.0 proposed;",
     "which is inconsistent with the index-coverage mechanism behind the age hypothesis;"),
    ("Section 5.3's withdrawal of the 9.2x AI-answer comparison, made in version 4.1 by inference from the page count, is confirmed by observation.",
     "This confirms by observation what Section 5.3 infers from the page count: the two instruments' AI-answer counts cannot be compared at the prefix level."),
    ("**A withdrawn comparison.** Earlier versions compared Brand Radar's 17,206 stored answers citing the section with Semrush's 158,100 mentions read on 10 October, a factor of 9.2. That ratio is a scope mismatch, not a divergence:",
     "**AI-answer counts are not comparable at the prefix level.** Brand Radar's 17,206 stored answers citing the section and Semrush's 158,100 mentions read on 10 October differ by a factor of 9.2, but that ratio is a scope mismatch, not a divergence:"),
    ("That comparison, and a claim that the two instruments disagree about the ordering of AI answer platforms, which rested on a breakdown whose figures did not sum to its total, are withdrawn.",
     "No comparison is drawn from those counts, nor about the ordering of AI answer platforms, whose per-platform breakdown did not sum to its total (Appendix A)."),
    ("Version 4.0 attributed this to section age and proposed index coverage as the mechanism. Section 5.5 tested that across twelve prefixes and found no detectable relationship between age and the ratio.",
     "Section age, with index coverage as the mechanism, was the hypothesis; Section 5.5 tested it across twelve prefixes and found no detectable relationship between age and the ratio."),
    ("**This establishes nothing about necessity**, and earlier versions of this work claimed that it did.",
     "**This establishes nothing about necessity.**"),
    ("**What does not.** Any claim about the full series. An earlier version concluded that link acquisition plays no part in explaining the outcome; most of the series postdates the network.",
     "**What does not.** Any claim about the full series, including that link acquisition plays no part in the outcome: most of the series postdates the network."),
    ("An earlier version named the carrier comparison in Section 9.2 as a bound; that comparison is computed on a set selected on the provider's presence and bounds nothing.",
     "The carrier comparison in Section 9.2 is not a bound: it is computed on a set selected on the provider's presence."),
    ("The cross-prefix replication registered in version 4.0 was performed on 12 October 2026 (Section 5.5);",
     "The cross-prefix replication, registered before it was run, was performed on 12 October 2026 (Section 5.5);"),
    ("An earlier pilot, computed by the author's own analytics platform, was withdrawn in version 5.1 (Appendix A).",
     "An earlier pilot, computed by the author's own analytics platform, has been withdrawn (Appendix A)."),
    ("which computed a pilot for Section 7 that was withdrawn in version 5.1,",
     "which computed a pilot for Section 7 that has been withdrawn (Appendix A),"),
    ("\n\nEarlier versions of this paper stated 290 code pages and an 88-code control group of uncovered codes; both figures were wrong, and fetching every page corrected them (Appendix A).", ""),
    ("**The within-class control, withdrawn.** Versions 3.1 to 4.1 registered a within-class control: the geographic codes for which no page was published, queried on the same instruments as the published ones. Section 3 records that no such set exists.",
     "**No within-class control exists.** A control of geographic codes with no page, queried on the same instruments as the published ones, would test whether publishing a page did anything; Section 3 records that no such set exists (Appendix A records the control that was registered and withdrawn)."),
    ("The design is withdrawn, and the paper no longer claims a permission-free test of whether publishing a page did anything.",
     "The paper therefore claims no test of whether publishing a page did anything."),
    # Appendix A: the withdrawals the body no longer narrates
    ("withdrew a 9.2x AI-answer comparison as a scope mismatch;",
     "withdrew a 9.2x AI-answer comparison as a scope mismatch, and a claim about the ordering of AI answer platforms that rested on a breakdown whose figures did not sum to its total; withdrew a claim that a comparison with two carriers of similar authority bounded the effect of domain authority, and a claim that the deployment showed content on the topic to be necessary; withdrew the conclusion that link acquisition played no part in the outcome once the primary checkpoint moved to day 37;"),
])
P.write_text(s)
print(f"{len(s.split()):,} words")
