# Web searches and fetches, 2026-10-31 (between 04:50 and 05:20 UTC)

Exact per-call timestamps were not captured by the web tools; the order below is the order of execution.

| # | tool | query or URL | outcome |
|---|---|---|---|
| W1 | WebSearch | "Minimum Information About a Google Trends Experiment" MIAGE checklist Bragazzi | No published version surfaced; results were Mavragani and Ochoa 2019 and unrelated MIAME pages. |
| W2 | WebSearch | EQUATOR network reporting guideline "Google Trends" OR infodemiology OR "digital epidemiology" OR "web-based data" studies | No EQUATOR guideline for these terms surfaced; Mavragani and Ochoa 2019 returned. |
| W3 | WebSearch | NISO RP-25-2016 altmetrics "code of conduct" data quality transparency altmetric providers | Confirmed: NISO RP-25-2016 published 22 September 2016; includes the Altmetrics Data Quality Code of Conduct with a self-reporting table (niso.org press releases). |
| W4 | WebSearch | reporting checklist research using Semrush Ahrefs Similarweb data "search volume" OR "traffic estimates" methodology recommendations researchers | Only vendor and practitioner blog posts (promodo, authorityhacker, ahrefs.com, customerthink and similar); no guideline; none cited in the record. |
| W5 | WebSearch | AAPOR task force report "Big Data in Survey Research" 2015 Japec data quality framework | Confirmed citation: Public Opinion Quarterly 79(4), 839-880, DOI 10.1093/poq/nfv039; author list as given by the IAB record (iab.de/publication/?id=5853725): Japec, Kreuter, Berg, Biemer, Decker, Lampe, Lane, O'Neil, Usher. |
| W6 | WebSearch | Wikipedia pageviews research data quality agent type spider automated "pageviews API" guidance researchers bots | Confirmed Wikimedia agent types user, spider, automated; Research:Page_view page on meta.wikimedia.org (HTTP 200 on direct check). |
| W7 | WebSearch | Hölzl Keusch Sajons "(mis)use of Google Trends data in the social sciences" recommendations preprint OR repository full text | Found CC BY PDF at https://madoc.bib.uni-mannheim.de/68637/1/1-s2.0-S0049089X24001212-main.pdf; also an accepted manuscript of Moon and Barlev at eprints.soton.ac.uk/507680. |
| F1 | WebFetch | https://preprints.jmir.org/preprint/13272 | Empty body (HTTP 202 on direct check); abstract taken from OpenAlex and Crossref. |
| F2 | WebFetch | https://doi.org/10.1016/j.ssresearch.2024.103099 | Redirect to linkinghub.elsevier.com; not followed; open PDF used instead (F8). |
| F3 | WebFetch | https://doi.org/10.1177/20563051231216947 | Redirect to journals.sagepub.com; direct fetch returned HTTP 403; PMC copy used instead (F11). |
| F4 | WebFetch | https://www.equator-network.org/?post_type=eq_guidelines&...&s=google+trends (and s=infodemiology, s=internet) | Home page returned; no search results. Full library listing downloaded with curl and scanned locally (fulltext_extracts.md, section F). |
| F5 | WebFetch | https://support.google.com/trends/answer/4365533 | Read (fulltext_extracts.md, section G). |
| F6 | WebFetch | https://www.equator-network.org/reporting-guidelines/?s=google+trends | Unfiltered library listing returned (261,585 characters; first 100,000 read); superseded by the local scan. |
| F7 | WebFetch | https://www.equator-network.org/?s=infodemiology | Home page returned. |
| F8 | WebFetch then Read | https://madoc.bib.uni-mannheim.de/68637/1/1-s2.0-S0049089X24001212-main.pdf | PDF saved locally (3.1 MB); pages 14 to 20 read as images (fulltext_extracts.md, section C). |
| F9 | WebFetch and curl | https://eprints.soton.ac.uk/507680/1/Google_Trends_Tutorial_AMPPS_Accepted_Full_Text.pdf | HTTP 403 (WebFetch) and HTTP 401 (curl); not read. |
| F10 | WebFetch | https://www.jmir.org/2016/2/e41/ | Fetcher returned only the citation; Europe PMC XML used instead (fulltext_extracts.md, section B). |
| F11 | WebFetch | https://pmc.ncbi.nlm.nih.gov/articles/PMC10795517/ | Read (fulltext_extracts.md, section D). |
| F12 | WebFetch | https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0109583 | Table 4 rendered as an image; Europe PMC XML used instead (fulltext_extracts.md, section A). |
| F13 | WebFetch | https://link.springer.com/chapter/10.1007/978-3-031-02304-0_4 | Redirect to Springer sign-in; not read. |
| E1 | Europe PMC REST | fullTextXML for PMC4215636, PMC4788740, PMC6660120 | Retrieved. PMC10795517 returned HTTP 500 from the XML endpoint (PMC HTML used, F11). |
| U1 | curl HEAD/GET | https://www.niso.org/publications/rp-25-2016-altmetrics | HTTP 200. |
| U2 | curl | https://meta.wikimedia.org/wiki/Research:Page_view | HTTP 200. |
| U3 | curl | https://madoc.bib.uni-mannheim.de/68637/ | HTTP 200. |
| S1 | curl | api.semanticscholar.org paper/search (two probes, 05:13 UTC) | HTTP 429 both times. |
| C1 | Crossref API (05:13 UTC) | https://api.crossref.org/works?query.title=Minimum+Information+About+a+Google+Trends+Experiment&query.author=Bragazzi&rows=5 | total-results 45 (fuzzy); first item 10.2196/preprints.13272, type posted-content, issued 2019-01-02; the other four of the top five were unrelated Google Trends papers; no journal version of MIAGE among them. |
