# Search record: reporting guidelines or checklists for studies that use commercial SEO or web-analytics figures as data

Date of search: 2026-10-31, 04:46 to 05:20 UTC (evening of 30 October, US time).
Run by: the research-scout agent (Claude Code, model Fable 5.1), on request of the workflow for Paper 03. One screener; no second independent screener, so no inter-screener agreement exists.
Saturation: **PARTIAL** (criteria in section 7).
Raw provenance: `raw/query_log_openalex_crossref.csv` (every API query, verbatim, with timestamp and counts), `raw/results/*.json` (the records returned per query), `raw/chase/` (citation chasing), `raw/doi_verification.csv` (Crossref and DataCite resolution of every DOI below), `raw/abstracts_*.json` (OpenAlex abstracts of screened candidates), `raw/fulltext_extracts.md` (verbatim checklist items taken from open full texts), `raw/web_log.md` (web searches and fetches).

**Correction, 3 November 2026 (added by the session's main agent after an independent assessor's report; the record below is unchanged).** This record passed over the nearest guidance on these tools: Font-Julián et al. 2026 (row 32 below, described there as having no checklist) closes with a section of methodological recommendations for using SEO tools in quantitative research (its Section 5.2), including reporting the tool, the extraction date, the market settings and each metric's definition. It is not a checklist, but the verdict's phrase "set of reporting recommendations" is too strong, and Appendix E says so.

## 0. Verdict in one paragraph

Scoped to the searches recorded here, no published reporting guideline, checklist, or set of reporting recommendations was found that is specific to figures taken from commercial SEO or web-analytics tools (Ahrefs, Semrush, Similarweb, Moz, Majestic, Sistrix and the like: search volume, estimated traffic, rankings, backlinks, authority scores). The nearest published instruments are documentation checklists for one adjacent third-party web metric, Google Trends (Nuti et al. 2014, Table 4; Hölzl, Keusch and Sajons 2025, Table 5), reporting and disclosure checklists for social-media data (Kim, Huang and Emery 2016, Textbox 1; Kostygina et al. 2023, Table 1), error frameworks and a documentation template for digital-trace data (Sen et al. 2021; Fröhling et al. 2023), webometrics guidance on the reliability of search-engine counts (Thelwall 2008, 2009, 2016; Ingwersen and Björneborn 2006), and a provider-side code of conduct for third-party metrics aggregators in altmetrics (NISO RP-25-2016). None names Ahrefs, Semrush or Similarweb. The EQUATOR Network library, scanned locally on the search date, lists no guideline for search-engine, SEO-tool or web-traffic data; its nearest entries concern routinely collected health data (RECORD), web surveys (CHERRIES), eHealth trials (CONSORT-EHEALTH) and one social-media-analytics framework for emergency care research. This is a statement about what these searches found, not about what exists (section 9).

## 1. Question as searched

Slot frame written before the first query.

- Object of study: published guidance (reporting guideline, checklist, minimum-information standard, recommendations, methodological framework, code of conduct) for studies that use figures from a third party's web-measurement product as research data.
- Factor: the data source is a commercial SEO or web-analytics tool (Ahrefs, Semrush, Similarweb, Moz, Majestic, Sistrix, Serpstat, Ubersuggest, Alexa, Compete, Quantcast) or a comparable free third-party web indicator (Google Trends, Google Keyword Planner, Wikipedia pageviews, search-engine hit counts, altmetrics aggregators, platform APIs).
- Comparison: guidance specific to such tools against generic guidance for observational, big-data or digital-trace research (STROBE, RECORD, total-error frameworks).
- Outcome: what the guidance tells authors to report (tool, version, retrieval date, territory, query parameters, sampling, repeated draws, uncertainty, validation against first-party data, vendor conflicts).
- Setting: any discipline; peer-reviewed, preprint, standards bodies, vendor documentation, grey literature.
- Window: 2000 to 2026 for webometrics; 2008 to 2026 for Google Trends and infodemiology; 2014 to 2026 for total-error and post-API work; exact-title queries unrestricted.

Assumptions filled in: "checklist" was read broadly to include numbered documentation items, minimum-information standards and tabulated recommendations; "commercial SEO tool" was read to include traffic-estimation and competitive-intelligence products, since the manuscript treats Similarweb and Semrush as instruments of the same kind; a search of three vocabularies was required before any conclusion (section 2.2).

## 2. Search record

### 2.1 Backends and their status on 2026-10-31

| Backend | Status | Control test |
|---|---|---|
| OpenAlex (`api.openalex.org/works`, `mailto` sent) | Working throughout. Two query modes used: `search=` (title, abstract and full text where indexed; query A01) and `filter=title_and_abstract.search:` (all other queries; "tas" in the log). One author-filtered query (B04, "filt"). | CTRL1 `"The parable of Google Flu"` returned 8 records including Lazer et al. 2014 (10.1126/science.1248506). CTRL3, the exact title of Kim, Huang and Emery 2016, returned 2 records including the target. Both ran in the same session as the zero-hit queries. |
| Crossref (`api.crossref.org/works`, `query.bibliographic`, `mailto` sent) | Working. Relevance ranking is fuzzy, so `total-results` is not a count of relevant works: the control CTRL2 (exact title of Lazer et al. 2014) returned 9,418,344. Crossref totals in the table below are recorded because the task asked for them, and must not be read as topic sizes. | CTRL2 returned the target as its first item. |
| Semantic Scholar (`api.semanticscholar.org/graph/v1/paper/search`) | **Unreachable without a key**: HTTP 429 on every attempt (two inside `litsearch.py` at 04:46 UTC, two direct probes at 05:13 UTC, 20 seconds apart). No Semantic Scholar result exists in this record. | n/a |
| DBLP, arXiv (through `litsearch.py`) | DBLP returned malformed JSON; arXiv returned HTTP 429 then timed out (04:47 UTC). Not retried; arXiv preprints are reachable through OpenAlex, which indexes them. | n/a |
| EQUATOR Network library (`equator-network.org/reporting-guidelines/`) | The site's search endpoint returned the home page to the fetcher, so the full library listing (712,716 bytes) was downloaded at 05:14 UTC and scanned locally for the terms listed in `raw/fulltext_extracts.md`, section F. | n/a |
| Web (WebSearch, WebFetch) | Used for grey literature: EQUATOR, NISO, AAPOR, Google's Trends FAQ, Wikimedia's pageview definitions, open full texts. | n/a |

### 2.2 Vocabularies

Three vocabularies were required by protocol; five were used.

- V1, infodemiology and Google Trends (health and economics): "Google Trends", infodemiology, checklist, reporting standards, minimum information, reproducibility, sampling, best practices, Keyword Planner.
- V2, webometrics and information science (Thelwall and colleagues; Spanish cibermetría): webometrics, web indicators, link analysis, hit counts, search engine coverage, commercial data sources, altmetrics code of conduct, Leiden Manifesto, herramientas SEO, posicionamiento web.
- V3, survey methodology and computational social science: digital trace data, total survey error, total error framework, API-based research, post-API, disclosure standards, documentation templates.
- V4, SEO practice and competitive intelligence: Ahrefs, Semrush, Similarweb, Moz, Majestic, Sistrix, domain authority, visibility index, traffic estimates, keyword tools, SERP audits.
- V5, generative-engine optimization: AI visibility, AI Overviews, measurement reliability, vendor.

### 2.3 Every query, verbatim

Columns: id; time (UTC, 2026-10-31); backend and mode (oa = OpenAlex; tas = `title_and_abstract.search` filter; search = `search=` parameter; filt = raw filter string; cr/bib = Crossref `query.bibliographic`); from-year filter; total hits reported by the API; records returned and screened by title (OpenAlex capped at 50, Crossref at 40). Queries whose OpenAlex total is inflated by an unparenthesized `OR` (the API treats a bare OR as a loose disjunction) are marked with an asterisk; the top 50 by relevance were still screened. Reason for exclusion was, in every case, "title and abstract do not concern guidance for third-party web-measurement data"; records kept are those cited in sections 3 to 5.

Preliminary runs through `litsearch.py` (routing: OpenAlex and Crossref, plus field backends that failed):

| id | time | backends | query | filter | hits | kept |
|---|---|---|---|---|---|---|
| q01 | 04:46 | openalex=50, crossref=50; semanticscholar FAILED 429 | `reporting guideline studies using Google Trends data` | from 2010, limit 50 | 100 raw (50 per backend); 50 reported after dedup (stderr log not saved) | Nuti 2014; Mavragani and Ochoa 2019 |
| q02 | 04:47 | openalex=50, crossref=50; dblp FAILED, arxiv FAILED | `webometrics data quality web indicators reporting Thelwall` | from 2000, limit 50 | 100 raw (50 per backend); 50 reported after dedup (stderr log not saved) | Thelwall 2008, 2009 |

Batch A, Google Trends and third-party web indicators:

| id | time | backend | query | from | total | returned |
|---|---|---|---|---|---|---|
| A01 | 05:04 | oa search | `"Google Trends" reporting guideline` | 2010 | 1,842 | 50 |
| A02 | 05:04 | oa tas | `"Google Trends" methodology framework reliability` | 2010 | 7 | 7 |
| A03 | 05:04 | oa tas | `"Google Trends" checklist` | 2010 | 15 | 15 |
| A04 | 05:04 | oa tas | `"Google Trends" reproducibility sampling` | 2010 | 14 | 14 |
| A05 | 05:04 | oa tas | `"Google Trends" recommendations researchers documentation` | 2010 | 0 | 0 |
| A06 | 05:04 | cr bib | `Google Trends reporting guideline checklist` | 2010 | 745,271 | 40 |
| A07 | 05:04 | oa tas | `infodemiology "reporting standards" OR "reporting guideline" OR checklist` | 2008 | 788 | 50 |
| A08 | 05:04 | oa tas | `("Wikipedia page views" OR "Wikipedia pageviews" OR "Wikipedia page view") AND (reliability OR "data quality" OR bots)` | 2010 | 5 | 5 |
| A09* | 05:04 | oa tas | `"Alexa rank" OR "Alexa ranking" OR "Alexa traffic rank" reliability` | 2005 | 1,823,070 | 50 |
| A10 | 05:04 | oa tas | `"search volume" ("keyword tool" OR "keyword planner" OR "keyword research tool") accuracy OR reliability` | 2010 | 71 | 50 |
| A11 | 05:04 | oa tas | `"Google Trends" "best practices"` | 2010 | 23 | 23 |
| A12* | 05:04 | oa tas | `"Google Trends" "quality data source" OR "data source quality" OR limitations` | 2010 | 8,554 | 50 |
| CTRL1 | 05:04 | oa tas | `"The parable of Google Flu"` | none | 8 | 8 |
| CTRL2 | 05:04 | cr bib | `The parable of Google Flu traps in big data analysis` | none | 9,418,344 | 40 |

Batch B, webometrics and information science:

| id | time | backend | query | from | total | returned |
|---|---|---|---|---|---|---|
| B01 | 05:04 | oa tas | `webometrics "data quality" "search engine"` | 2000 | 0 | 0 |
| B02 | 05:04 | oa tas | `webometrics ("practical guide" OR "methodological guidelines" OR "methodological issues")` | 2000 | 5 | 5 |
| B03 | 05:04 | oa tas | `"web indicators" "research evaluation"` | 2010 | 9 | 9 |
| B04 | 05:04 | oa filt | `raw_author_name.search:Thelwall,title_and_abstract.search:webometrics OR "web indicators" OR "link analysis" OR "search engine"` | 2000 | 140 | 50 |
| B05 | 05:04 | oa tas | `altmetrics ("data quality" OR "code of conduct" OR transparency) providers` | 2012 | 9 | 9 |
| B06 | 05:04 | oa tas | `("link database" OR backlinks OR "inlink") (Majestic OR Ahrefs OR "Open Site Explorer" OR Moz) reliability OR comparison` | 2008 | 42 | 42 |
| B07* | 05:04 | oa tas | `"search engine" "hit counts" OR "hit count estimates" reliability` | 2000 | 1,897 | 50 |
| B08 | 05:04 | cr bib | `webometrics data quality web indicators practical guide` | 2000 | 5,248,240 | 40 |
| B09 | 05:04 | oa tas | `"web traffic" ("data sources" OR "data source") (Alexa OR Compete OR Quantcast OR Similarweb) comparison` | 2008 | 0 | 0 |
| B10 | 05:04 | oa tas | `("academic SEO" OR "academic search engine optimization" OR "SEO tools") methodology validity` | 2010 | 0 | 0 |
| B11* | 05:04 | oa tas | `cybermetrics OR cibermetría "data sources" reliability` | 2000 | 10,050 | 50 |
| B12* | 05:04 | oa tas | `"Leiden Manifesto" OR "responsible metrics" indicators principles` | 2015 | 42,237 | 50 |

Batch C, digital-trace, API-based and computational social science:

| id | time | backend | query | from | total | returned |
|---|---|---|---|---|---|---|
| C01 | 05:04 | oa tas | `"digital trace data" "total error"` | 2015 | 4 | 4 |
| C02 | 05:04 | oa tas | `"API-based research" OR "API based research"` | 2015 | 10 | 10 |
| C03 | 05:04 | oa tas | `"post-API" ("digital methods" OR "social media research" OR "data access")` | 2018 | 16 | 16 |
| C04 | 05:04 | oa tas | `"social media data" ("reporting standards" OR "reporting guideline" OR "reporting guidelines" OR checklist)` | 2012 | 31 | 31 |
| C05* | 05:04 | oa tas | `"big data" "total survey error" OR "total error" framework` | 2014 | 44,579 | 50 |
| C06 | 05:04 | oa tas | `("third-party data" OR "third party data" OR "commercial data") ("web metrics" OR "web traffic" OR "search data") transparency OR reporting OR validity` | 2010 | 1 | 1 |
| C07 | 05:04 | oa tas | `"routinely collected" "reporting guideline" RECORD STROBE` | 2014 | 3 | 3 |
| C08 | 05:05 | cr bib | `digital trace data total error framework online platforms` | 2015 | 4,634,868 | 40 |
| C09 | 05:05 | oa tas | `("SEO tools" OR "SEO tool" OR "SEO software") ("data source" OR "data sources") research` | 2012 | 2 | 2 |
| C10 | 05:05 | oa tas | `"web analytics" (validity OR reliability OR "data quality") research methodology` | 2010 | 7 | 7 |
| C11 | 05:05 | oa tas | `(Similarweb OR SimilarWeb) (methodology OR validity OR accuracy OR limitations)` | 2012 | 42 | 42 |
| C12 | 05:05 | oa tas | `"computational social science" ("reporting standards" OR "reporting guidelines" OR "transparency checklist" OR "best practices") data` | 2015 | 23 | 23 |
| C13* | 05:05 | oa tas | `"search engine data" OR "search query data" (validity OR reliability OR "measurement error") research` | 2010 | 942,014 | 50 |

Batch D, exact titles and corrected (parenthesized) forms:

| id | time | backend | query | from | total | returned |
|---|---|---|---|---|---|---|
| D01 | 05:07 | oa tas | `"total error framework for digital traces"` | none | 7 | 7 |
| D02 | 05:07 | oa tas | `"Total Error in a Big Data World"` | none | 1 | 1 |
| D03 | 05:07 | oa tas | `"data collection methods on the Web for informetric purposes"` | none | 0 | 0 |
| D04 | 05:07 | oa tas | `"Web traffic and organization performance measures"` | none | 1 | 1 |
| D05 | 05:07 | oa tas | `"How reliable are website rankings"` | none | 1 | 1 |
| D06 | 05:07 | oa tas | `"hands-on guide to Google data"` | none | 1 | 1 |
| D07 | 05:07 | oa tas | `("Alexa rank" OR "Alexa ranking" OR "Alexa traffic rank" OR "Alexa Internet") AND (reliability OR accuracy OR validity OR "data source")` | 2005 | 28 | 28 |
| D08 | 05:07 | oa tas | `(Wikipedia AND ("page views" OR pageviews OR "page view")) AND (bots OR "automated traffic" OR "data quality" OR reliability OR limitations)` | 2010 | 36 | 36 |
| D09 | 05:07 | oa tas | `"Minimum Information About a Google Trends"` | none | 1 | 1 |
| D10 | 05:07 | oa tas | `"search engine optimization" (research OR studies) ("methodological" OR "research method" OR "data quality") (Semrush OR Ahrefs OR Sistrix OR "SEO tools")` | 2010 | 14 | 14 |
| D11 | 05:07 | oa tas | `("Keyword Planner" OR "keyword planner") (accuracy OR reliability OR validity OR "search volume")` | 2012 | 63 | 50 |
| D12 | 05:07 | oa tas | `("big data" OR "digital trace" OR "found data") ("total survey error") framework` | 2014 | 18 | 18 |
| D13* | 05:07 | oa tas | `"RECORD statement" OR "REporting of studies Conducted using Observational Routinely-collected"` | 2014 | 290 | 50 |
| D14 | 05:07 | oa tas | `("web data" OR "online data" OR "internet data") ("reporting guideline" OR "reporting checklist" OR "reporting standards") research` | 2010 | 4 | 4 |
| D15 | 05:07 | oa tas | `("third-party" OR "third party") ("traffic estimates" OR "traffic estimation" OR "web traffic data") (accuracy OR validity OR "measurement error" OR recommendations)` | 2010 | 5 | 5 |
| D16 | 05:07 | oa tas | `"digital methods" ("data quality" OR "data criticism" OR "source criticism") web (metrics OR indicators OR analytics)` | 2012 | 1 | 1 |
| D17 | 05:07 | oa tas | `("Google Trends" OR "search data") ("checklist" OR "reporting guideline" OR "reporting items" OR "minimum information")` | 2010 | 200 | 50 |
| D18 | 05:07 | oa tas | `("web indicators" OR webometric OR webometrics) ("commercial" OR "vendor" OR "proprietary") ("data source" OR "data sources" OR "data provider") (reliability OR transparency OR limitations)` | 2005 | 0 | 0 |
| D19 | 05:07 | cr bib | `Minimum Information About a Google Trends Experiment` | none | 4,443,947 | 40 |
| D20 | 05:07 | cr bib | `Garbage in garbage out data collection quality assessment reporting standards social media data` | 2015 | 2,240,160 | 40 |

Batch E, SEO practice, Spanish, altmetrics reporting, GEO:

| id | time | backend | query | from | total | returned |
|---|---|---|---|---|---|---|
| E01 | 05:09 | oa tas | `("search engine optimization" OR SEO) ("research agenda" OR "methodological challenges" OR "methodological issues" OR "research methods") (tools OR data)` | 2010 | 180 | 50 |
| E02 | 05:09 | oa tas | `("herramientas SEO" OR "posicionamiento web" OR cibermetría) (fiabilidad OR "fuentes de datos" OR metodología) (Ahrefs OR Semrush OR Sistrix OR Majestic)` | 2010 | 2 | 2 |
| E03 | 05:09 | oa tas | `(altmetrics OR "alternative metrics") ("reporting guidelines" OR "reporting standards" OR "guidelines for reporting" OR "minimum reporting")` | 2012 | 27 | 27 |
| E04 | 05:09 | oa tas | `("visibility index" OR Sistrix OR "Sichtbarkeitsindex") (methodology OR reliability OR validity OR research)` | 2010 | 169 | 50 |
| E05 | 05:09 | oa tas | `("digital trace data" OR "digital traces") ("documentation" OR "reporting" OR "transparency") (standards OR guidelines OR checklist OR "best practices")` | 2015 | 246 | 50 |
| E06 | 05:09 | oa tas | `("Google Trends" OR "search volume" OR "web traffic") ("measurement error" OR "errors-in-variables" OR "proxy") (econometric OR validity) recommendations` | 2010 | 2 | 2 |
| E07 | 05:09 | oa tas | `("black box" OR opaque OR proprietary) ("search volume" OR "traffic estimates" OR "keyword data" OR "SEO metrics") research` | 2010 | 18 | 18 |
| E08 | 05:09 | oa tas | `("domain authority" OR "Domain Rating" OR "Authority Score" OR "Trust Flow") (reliability OR validity OR comparison OR correlation) (Moz OR Ahrefs OR Semrush OR Majestic)` | 2012 | 13 | 13 |
| E09 | 05:09 | oa tas | `("competitive intelligence" OR "market intelligence") (Similarweb OR Semrush OR Ahrefs OR Alexa) (tools OR data) (reliability OR accuracy OR evaluation)` | 2010 | 8 | 8 |
| E10 | 05:09 | oa tas | `("web metrics" OR "web indicators" OR "web analytics") ("reporting" OR "documentation") (guideline OR guidelines OR standard OR checklist OR "good practice")` | 2005 | 56 | 50 |
| E11 | 05:09 | oa tas | `("search engine results" OR SERP) (audit OR study) ("keyword research tool" OR "keyword tools" OR Semrush OR Ahrefs) (sampling OR "query selection" OR methodology)` | 2015 | 6 | 6 |
| E12 | 05:09 | oa tas | `("generative engine optimization" OR "AI visibility" OR "AI Overviews") (methodology OR measurement OR "vendor" OR tools) (reliability OR validity OR reporting OR transparency)` | 2024 | 138 | 50 |
| CTRL3 | 05:09 | oa tas | `"Garbage in, Garbage Out: Data Collection, Quality Assessment and Reporting Standards"` | none | 2 | 2 |

Zero-hit queries (A05, B01, B09, B10, D03, D18) ran in the same session and backend as CTRL1 and CTRL3, which found their targets; the zeros are therefore properties of the query strings, not an outage. D03 is the exact title of a Bar-Ilan paper the scout expected to exist; see section 8.

### 2.4 Citation chasing (OpenAlex, `filter=cites:` with a title-and-abstract filter for forward; all `referenced_works` resolved for backward)

| seed | DOI | cited by (OpenAlex) | forward filter | forward hits | references resolved | new relevant records found |
|---|---|---|---|---|---|---|
| Nuti et al. 2014 | 10.1371/journal.pone.0109583 | 1,085 | checklist OR guideline OR guidelines OR "reporting" OR recommendations OR "minimum information" | 230 | 93 of 95 | Mavragani, Ochoa and Tsagarakis 2018; Arora, McKee and Stuckler 2019; Cebrián and Domènech 2024 |
| Mavragani and Ochoa 2019 | 10.2196/13439 | 517 | checklist OR guideline OR ... OR framework | 145 | 64 of 64 | Mavragani, Ochoa and Tsagarakis 2020 (scoping review); Hölzl et al. 2025 |
| Kim, Huang and Emery 2016 | 10.2196/jmir.4738 | 177 | checklist OR guideline OR ... OR disclosure OR transparency | 60 | 35 of 37 | Kostygina et al. 2023; Kim, Nordgren and Emery 2020; Pearson et al. 2025 |
| Hölzl, Keusch and Sajons 2025 | 10.1016/j.ssresearch.2024.103099 | 34 | checklist OR guideline OR recommendations OR reliability OR reproducibility OR inconsistencies | 6 | 86 of 90 | Hölzl, Keusch and Collins 2026; backward: Eichenauer et al. 2022; Franzén 2023; Behnen et al. 2020; Medeiros and Pires 2021; Jun, Yoo and Choi 2018 |
| Thelwall 2016 practical guide | 10.2200/s00733ed1v01y201609icr052 | 44 | commercial OR SEO OR traffic OR "data quality" OR reliability OR guide | 3 | 124 of 125 | none on this question |
| Prantl and Prantl 2018 | 10.1108/ijwis-01-2018-0001 | 28 | recommendations OR guideline OR methodology OR reliability OR validity OR accuracy OR comparison | 8 | 29 of 31 | Garg et al. 2025 |
| Jansen, Jung and Salminen 2022 | 10.1371/journal.pone.0268212 | 47 | ... OR estimates | 20 | 74 of 74 | Jansen, Salminen, Jung and Almerekhi 2022 |
| Font-Julián et al. 2026 | 10.1177/01655515261445903 | 0 | SEO OR tools OR methodology OR reliability | 0 | 33 of 33 | García-Carretero et al. 2016; Perriam, Birkbak and Freeman 2020 (already found) |
| Sen et al. 2021 (TED-On) | 10.1093/poq/nfab018 | 88 | "Google Trends" OR "search volume" OR "web traffic" OR "search engine" OR Wikipedia OR "search data" | 2 | 69 of 73 | none applying TED-On to search or traffic data |
| Reyes-Lillo et al. 2023 | 10.3145/epi.2023.jul.03 | 10 | SEO OR reliability OR tools OR metrics OR recommendations | 8 | 32 of 32 | none |

### 2.5 Web searches and fetches (between 04:50 and 05:20 UTC)

Listed with outcome in `raw/web_log.md`. In brief: WebSearch for the MIAGE checklist (no published version surfaced); for an EQUATOR guideline on Google Trends, infodemiology or web data (none surfaced); for NISO RP-25-2016 (confirmed, September 2016, includes the altmetrics data-quality Code of Conduct); for the AAPOR Big Data task force report (confirmed, Public Opinion Quarterly 2015); for Wikimedia pageview agent types (confirmed: user, spider, automated); for any reporting checklist for Semrush, Ahrefs or Similarweb data (only vendor and practitioner blog posts surfaced, none a guideline; not cited); for an open copy of Hölzl et al. 2025 (found, CC BY, University of Mannheim repository). WebFetch: Google's "FAQ about Google Trends data" (read); Nuti 2014 and Kim 2016 full texts via Europe PMC XML (read); Kostygina 2023 via PMC (read); Hölzl 2025 PDF (read, pages 14 to 20); Moon and Barlev 2026 accepted manuscript (HTTP 401, not read); Thelwall 2017 chapter 4 (Springer sign-in redirect, not read); JMIR Preprints page for MIAGE (empty body; abstract taken from OpenAlex and Crossref instead).

## 3. Closest works

Tiering: PR = peer-reviewed journal or edited handbook; BK = book from an academic publisher; ST = standards body; PP = preprint or working paper (nothing attaches; label at point of use); VD = vendor documentation. "Verified" means the DOI resolved at `api.crossref.org/works/DOI` (or DataCite for arXiv and Zenodo) on 2026-10-31; see `raw/doi_verification.csv`.

| # | Full reference | Identifier | Tier | What it recommends | How close to the question |
|---|---|---|---|---|---|
| 1 | Nuti, S. V., Wayda, B., Ranasinghe, I., Wang, S., Dreyer, R. P., Chen, S. I., et al. (2014). The use of Google Trends in health care research: A systematic review. *PLoS ONE, 9*(10), e109583. | 10.1371/journal.pone.0109583 (verified) | PR | Table 4, "Checklist for Documentation of Google Trends": access date, time period, query category, full search input (with combination and quotation syntax), rationale for search input, rationale for settings. Found 7% (5/70) of reviewed studies reproducible. | Closest published checklist for a third-party, modeled, opaque web index. Different instrument (Google Trends), health only, single tool, no item on comparing instruments or stating uncertainty. |
| 2 | Hölzl, J., Keusch, F., & Sajons, C. (2025). The (mis)use of Google Trends data in the social sciences: A systematic review, critique, and recommendations. *Social Science Research, 126*, 103099 (online 2024). | 10.1016/j.ssresearch.2024.103099 (verified) | PR | Table 5, "Checklist: Recommendations on using Google Trends for research": access dates, location of access, time period and unit, region and unit, category, full search input, data and code dissemination (FAIR); and challenges: rationale for keywords, construct, validity check against an external source, reliability (download samples on several days, average them, report variation, bootstrap intervals), generalizability. Review of 360 studies to end of 2021. | Closest in spirit to the manuscript's Section 5.6: it tells authors to draw repeated samples from one opaque vendor and report their dispersion. Different instrument; single vendor; social sciences. |
| 3 | Bragazzi, N. L. (2019). Minimum Information About a Google Trends Experiment (MIAGE). *JMIR Preprints*, 13272 (posted 2019-01-02). | 10.2196/preprints.13272 (verified as preprint) | PP | A 23-item "minimum information" checklist for Google Trends studies, modeled on the MIAME family of standards (abstract). | Closest by genre (a named minimum-information checklist for a web index), but unpublished; no published version found (section 8). |
| 4 | Kostygina, G., Kim, Y., Seeskin, Z. H., LeClere, F. B., & Emery, S. (2023). Disclosure standards for social media and generative artificial intelligence research: Toward transparency and replicability. *Social Media + Society, 9*(4). | 10.1177/20563051231216947 (verified) | PR | Table 1: 12 minimal disclosure items (funding, scope, platform, target population, point of data access, sampling approach, number of units, protocol and tools, data handling, query and filter construction, data quality assessment, data analysis) plus 5 optional items (source code, coding manual, IRB, data decay, spam index). Mentions third-party social-listening providers generically. | Closest disclosure checklist for data bought or drawn from a commercial intermediary; social media, not SEO tools; names no SEO or web-analytics product. |
| 5 | Kim, Y., Huang, J., & Emery, S. (2016). Garbage in, garbage out: Data collection, quality assessment and reporting standards for social media data use in health research, infodemiology and digital disease detection. *Journal of Medical Internet Research, 18*(2), e41. | 10.2196/jmir.4738 (verified) | PR | Textbox 1, "Checklist for social media data preparation and reporting": data source (site, time frame, how accessed, suitability, limitations), search-filter development, search-filter assessment (precision and recall). | Earliest explicit "reporting standard" for third-party web data found; retrieval-quality framing; Twitter, not SEO tools. |
| 6 | Mavragani, A., & Ochoa, G. (2019). Google Trends in infodemiology and infoveillance: Methodology framework. *JMIR Public Health and Surveillance, 5*(2), e13439. | 10.2196/13439 (verified) | PR | Step-by-step methodology: choose keyword(s), region(s), period, category; what to report for validity. | Methodology framework rather than a reporting checklist; Google Trends only. |
| 7 | Fassio, F., & Comberiati, P. (2021). Using Google Trends in biomedical research. *JMIR Preprints*, 33836. | 10.2196/preprints.33836 (verified as preprint) | PP | Proposes a checklist of all user-editable Google Trends parameters to make searches reproducible (abstract). | Same genre as 1 and 3; unpublished. |
| 8 | Bellaire, C. P., Rutland, J. W., Sayegh, F., Pesce, R. R., Tijerina, J. D., & Taub, P. J. (2021). Going viral: A systematic review of Google Trends in plastic surgery and a recommended framework for its use. *Aesthetic Surgery Journal, 41*(12), NP2034–NP2043. | 10.1093/asj/sjab084 (verified) | PR | Step-by-step guide for conducting and interpreting Google Trends research around its four input variables. | Specialty-specific framework; Google Trends. |
| 9 | Moon, J. W., & Barlev, M. (2026). Google-search data for psychological scientists: A tutorial and best practices. *Advances in Methods and Practices in Psychological Science, 9*(1). Preprint: PsyArXiv af7b2 (2024). | 10.1177/25152459251409146 (verified); 10.31234/osf.io/af7b2 (verified) | PR | Tutorial with "recommendations for safeguarding data quality and their interpretation" (abstract). Full text not read (section 8). | Best-practice guidance; Google Trends. |
| 10 | Alibudbud, R. C. (2023). Wikipedia page views for health research: A review. *Frontiers in Big Data, 6*, 1199060. | 10.3389/fdata.2023.1199060 (verified) | PR | Lists what future studies should specify: page(s), language, dates of collection and dates explored, type of data, whether page views were limited to internet users, whether crawlers and redirects were included. Review of 29 studies. | Reporting items for a second free third-party web indicator; not a formal checklist. |
| 11 | Sen, I., Flöck, F., Weller, K., Weiß, B., & Wagner, C. (2021). A total error framework for digital traces of human behavior on online platforms. *Public Opinion Quarterly, 85*(S1), 399–422. | 10.1093/poq/nfab018 (verified) | PR | TED-On: a vocabulary to diagnose and document error sources in platform-derived data, modeled on Total Survey Error. | Generic error framework; no application to search or traffic estimates found (forward chase: 2 hits, neither relevant). |
| 12 | Fröhling, L., Sen, I., Soldner, F., Steinbrinker, L., Zens, M., & Weller, K. (2023). Total Error Sheets for Datasets (TES-D): A critical guide to documenting online platform datasets. arXiv:2306.14219. | 10.48550/arxiv.2306.14219 (DataCite verified) | PP | A documentation template, with guiding questions and manual, for datasets collected from online platforms, built on TED-On. | Closest generic documentation template for platform-derived data; preprint; not specific to commercial estimates. |
| 13 | Amaya, A., Biemer, P. P., & Kinyon, D. L. (2020). Total error in a big data world: Adapting the TSE framework to big data. *Journal of Survey Statistics and Methodology, 8*(1), 89–119. | 10.1093/jssam/smz056 (verified) | PR | Total Error Framework for big data, illustrated by comparing survey estimates with three commercial databases (Zillow, Acxiom, CoreLogic). | The only framework found that is illustrated on commercial third-party estimates; housing, not web metrics. |
| 14 | Jansson, I., & Japec, L. (2026). A total error framework with a special focus on digital data. *International Statistical Review* (online first). | 10.1111/insr.70020 (verified) | PR | Unified error framework and quality indicators for statistics built from digital and blended sources. | Official-statistics framing; generic. |
| 15 | Vial, G. (2019). Reflections on quality requirements for digital trace data in IS research. *Decision Support Systems, 126*, 113133. | 10.1016/j.dss.2019.113133 (verified) | PR | A preliminary set of guidelines for considering and reporting the quality of digital trace data (GitHub case). | Reporting guidelines for trace data in information systems; not web metrics. |
| 16 | Thelwall, M. (2009). *Introduction to webometrics: Quantitative web research for the social sciences*. Morgan & Claypool; chapter 7, "Search engines and data reliability". | 10.2200/s00176ed1v01y200903icr004; chapter 10.1007/978-3-031-02261-6_7 (both verified) | BK | Textbook treatment of search-engine hit counts as unstable estimates and of what a webometric study should record about the engine, date and query. Chapter text not read for this record. | Foundational webometrics guidance on third-party counts; predates SEO tools. |
| 17 | Thelwall, M. (2016/2017). *Web indicators for research evaluation: A practical guide*. Morgan & Claypool / Springer; chapter 4, "Academic, commercial and organisational web indicators". | 10.2200/s00733ed1v01y201609icr052; chapter 10.1007/978-3-031-02304-0_4 (both verified) | BK | Practical guide to collecting and reporting web indicators. Chapter 4 content not read (paywall); its treatment of commercial sources is NOT VERIFIED. | Nearest "practical guide" in webometrics; research evaluation, not SEO. |
| 18 | Thelwall, M. (2008). Quantitative comparisons of search engine results. *Journal of the American Society for Information Science and Technology, 59*(11), 1702–1710. | 10.1002/asi.20834 (verified) | PR | Compares hit-count estimates and result URLs across three engine APIs on 1,587 queries; recommends which engine to use for which purpose and warns of inconsistencies. | Same design logic as the manuscript's two-instrument comparison, applied to search engines rather than SEO vendors. |
| 19 | Ingwersen, P., & Björneborn, L. (2006). Methodological issues of webometric studies. In *Handbook of quantitative science and technology research* (pp. 339–369). Kluwer. | 10.1007/1-4020-2755-9_16 (verified) | PR | Covers search-engine and crawler coverage, quality and sampling issues for webometric analyses. | Methodological guidance; no checklist. |
| 20 | Vaughan, L., & Thelwall, M. (2004). Search engine coverage bias: Evidence and possible causes. *Information Processing & Management, 40*(4), 693–707. | 10.1016/s0306-4573(03)00063-3 (verified) | PR | Documents systematic coverage bias in search engines as a data source. | Evidence base for the webometric caution; no guideline. |
| 21 | Carpenter, T., & Lagace, N. (2017). Defining community recommended practice for altmetrics. *Performance Measurement and Metrics, 18*(1), 9–15; and NISO. (2016). *RP-25-2016, Outputs of the NISO Alternative Assessment Metrics Project*, including the Altmetrics Data Quality Code of Conduct. | 10.1108/pmm-09-2016-0039 (verified); https://www.niso.org/publications/rp-25-2016-altmetrics (HTTP 200) | PR; ST | A code of conduct asking third-party metrics providers and aggregators to disclose provenance, transparency, replicability and accuracy, with a self-reporting table. | The only standards-body instrument found for vendors of third-party web metrics; aimed at providers, not authors; altmetrics, not SEO. |
| 22 | Haustein, S. (2016). Grand challenges in altmetrics: Heterogeneity, data quality and dependencies. *Scientometrics, 108*(1), 413–423. | 10.1007/s11192-016-1910-9 (verified) | PR | Frames data-quality and dependency on commercial aggregators as the field's open problems. | Adjacent field; no checklist. |
| 23 | Japec, L., Kreuter, F., Berg, M., Biemer, P., Decker, P., Lampe, C., Lane, J., O'Neil, C., & Usher, A. (2015). Big data in survey research: AAPOR Task Force report. *Public Opinion Quarterly, 79*(4), 839–880. | 10.1093/poq/nfv039 (verified) | PR (association report) | Describes the big-data process, its challenges and research needs; calls for TSE-style quality evaluation. | Institutional report; generic. |
| 24 | Cebrián, E., & Domènech, J. (2023). Is Google Trends a quality data source? *Applied Economics Letters, 30*(6), 811–815; and (2024) Addressing Google Trends inconsistencies. *Technological Forecasting and Social Change, 202*, 123318. | 10.1080/13504851.2021.2023088; 10.1016/j.techfore.2024.123318 (both verified) | PR | Shows that repeating the same query on six days gives different values; models the sampling process and gives recommendations for building consistent series by averaging extractions. | Reliability-of-instrument evidence with recommendations; Google Trends. |
| 25 | Eichenauer, V. Z., Indergand, R., Martínez, I. Z., & Sax, C. (2022). Obtaining consistent time series from Google Trends. *Economic Inquiry, 60*(2), 694–705. | 10.1111/ecin.13049 (verified) | PR | A procedure (R package) to remove frequency inconsistency and sampling noise. | Method, not a reporting guideline. |
| 26 | Hölzl, J., Keusch, F., & Collins, J. T. (2026). Where you are is what you get! Inconsistencies of digital trace data across download locations. *Social Science Computer Review* (online first). | 10.1177/08944393261469494 (verified) | PR | Shows Google Trends and YouTube API samples differ by download country; closes with practical recommendations for API users. | Adds "location of access" as a reporting item. |
| 27 | Kim, Y., Nordgren, R. K., & Emery, S. (2020). The story of Goldilocks and three Twitter's APIs: A pilot study on Twitter data sources and disclosure. *International Journal of Environmental Research and Public Health, 17*(3), 864. | 10.3390/ijerph17030864 (verified) | PR | Same filters on three APIs retrieve different datasets; argues for disclosure of the access path. | Disclosure of access path for platform data; not SEO. |
| 28 | Pearson, G. D. H., Silver, N. A., Robinson, J. Y., Azadi, M., Schillo, B., & Kreslake, J. M. (2025). Beyond the margin of error: A systematic and replicable audit of the TikTok research API. *Information, Communication & Society, 28*(3), 452–470. | 10.1080/1369118x.2024.2420032 (verified) | PR | Audit of API metadata against the front end; engagement counts differed by orders of magnitude. | Audit design for a vendor-supplied count; not SEO. |
| 29 | Jansen, B. J., Salminen, J. O., Jung, S.-G., & Almerekhi, H. (2022). The illusion of data validity: Why numbers about people are likely wrong. *Data and Information Management, 6*(4), 100020. | 10.1016/j.dim.2022.100020 (verified) | PR | Argues that people-numbers are measures, not counts, and proposes practical remedies. | Same framing as the manuscript's "reported as counts" point; reflection piece, no checklist. |
| 30 | García-Carretero, L., Codina, L., Díaz-Noci, J., & Iglesias-García, M. (2016). Herramientas e indicadores SEO: Características y aplicación para análisis de cibermedios. *El Profesional de la Información, 25*(3). | 10.3145/epi.2016.may.19 (verified) | PR | Presents the most used SEO tools and nine indicators for online-media research. | Earliest academic treatment of SEO tools as research instruments found; descriptive, no reporting guidance. |
| 31 | Reyes-Lillo, D., Morales-Vargas, A., & Rovira, C. (2023). Reliability of domain authority scores calculated by Moz, Semrush, and Ahrefs. *El Profesional de la Información*. | 10.3145/epi.2023.jul.03 (verified) | PR | Inter-tool agreement on domain authority (Spearman above 0.9 on 3,151 domains). | Empirical reliability study of SEO tools; already in the manuscript; no guideline. |
| 32 | Font-Julián, C. I., Lopezosa, C., Orduña-Malea, E., & Aguillo, I. F. (2026). Assessing discrepancies across SEO tools in the collection of scholarly web metrics. *Journal of Information Science, 52*(4), 1075–1088. | 10.1177/01655515261445903 (verified) | PR | Four SEO tools on two publishers' domains overlap little; tool choice determines findings. | Already in the manuscript; the nearest empirical warning, with no checklist. |
| 33 | Sielinski, R. (2026). Quantifying uncertainty in AI visibility: A statistical framework for generative search measurement. arXiv:2603.08924. | 10.48550/arxiv.2603.08924 (DataCite verified) | PP | Argues citation-visibility metrics must be reported with uncertainty estimates and gives sample-size guidance. | Reporting recommendation for a vendor-measured AI-answer metric; preprint. |
| 34 | Kirichenko, S. (2026). How reproducible is AI search visibility? Prompt-paraphrase sensitivity and a confidence-aware measurement protocol for generative engine optimization. Zenodo. | 10.5281/zenodo.21498260 (DataCite verified) | PP | Proposes a "GEO-Signal Passport" of reproducibility metrics in place of a single percentage. | Preprint; vendor-adjacent; not a consensus guideline. |
| 35 | Google. (n.d.). FAQ about Google Trends data. | https://support.google.com/trends/answer/4365533 (HTTP 200) | VD | States the data are a sample, normalized to 0 to 100, that random noise is added, that Trends "is not a scientific poll" and "should always be considered as one data point among others". | Vendor documentation that the checklists above operationalize; no vendor of SEO tools was found to publish an equivalent checklist. |

Adjacent registered guidelines (EQUATOR library, scanned 2026-10-31): RECORD (routinely collected health data), RECORD-PE, CHERRIES (internet e-surveys), CONSORT-EHEALTH, CODE-EHR, and "Initial Standardized Framework for Reporting Social Media Analytics in Emergency Care Research" (title only; DOI not resolved here, section 8). None concerns search-engine, SEO-tool or traffic-estimate data.

## 4. What the literature establishes, and where it disagrees

Established, with the strength of the evidence:

- Google Trends returns different values for the same query on different days and from different download locations; the recommended remedy is repeated draws, averaging, and reporting dispersion (Cebrián and Domènech 2023, 2024; Behnen et al. 2020, 10.1007/978-3-030-65965-3_25; Medeiros and Pires 2021, arXiv:2104.03065; Eichenauer et al. 2022; Hölzl et al. 2025, 2026). Multiple independent peer-reviewed replications; strong.
- Documentation of Google Trends studies has been poor: 7% (5/70) reproducible in health care to 2013 (Nuti et al. 2014); 26 of 360 social-science studies to 2021 checked sample stability (Hölzl et al. 2025, Fig. 6, read from the PDF). Two systematic reviews; strong for the populations reviewed.
- Search-engine hit counts and result sets differ across engines and over time, and webometrics has long told authors to report engine, date and query (Thelwall 2008; Vaughan and Thelwall 2004; Ingwersen and Björneborn 2006). Older but consistent.
- Platform APIs deliver different data from different access paths and from the front end (Kim, Nordgren and Emery 2020; Pearson et al. 2025; Hölzl et al. 2026). Audits; moderate.
- Reporting checklists for third-party web data exist for Google Trends and social media (items 1 to 5 above); none found for SEO-tool figures.

Disagreements:

- Whether Google Trends should be used at all: Franzén (2023, *Acta Sociologica*, 10.1177/00016993221151118) concludes researchers "should refrain" from using it; Hölzl et al. (2025), Cebrián and Domènech (2024) and Eichenauer et al. (2022) propose remedies instead. Both sides are peer-reviewed; Franzén rests on one unplanned experiment.
- Whether SEO tools agree with one another: Reyes-Lillo et al. (2023) find inter-tool correlations above 0.9 for domain-authority scores; Font-Julián et al. (2026) find low overlap in keyword counts, volumes and URL-level traffic. The metrics differ, so the disagreement is about which metrics are stable, not a contradiction.
- What "quality" means for third-party data: retrieval precision and recall (Kim, Huang and Emery 2016) against disclosure completeness (Kostygina et al. 2023) against total-error decomposition (Sen et al. 2021; Amaya et al. 2020). Complementary framings rather than contradictions.

## 5. Judgment, scoped to these searches

1. No reporting guideline, checklist or recommendation set specific to commercial SEO or web-analytics tool figures was found in OpenAlex (66 queries, including two controls that passed), Crossref (6 queries), the EQUATOR library (local scan of the full listing), ten citation chases, or the web. Semantic Scholar was not searched because it was unreachable.
2. The closest published instruments are Google Trends documentation checklists (Nuti 2014; Hölzl, Keusch and Sajons 2025) and social-media disclosure checklists (Kim, Huang and Emery 2016; Kostygina et al. 2023). Their items (tool, access date, location, parameters, repeated samples, dispersion, external validation, data sharing, access path, vendor limitations) transfer by analogy to SEO-tool data, but none of them says so, and none names an SEO vendor.
3. The only standards-body instrument for third-party web metrics found is NISO RP-25-2016's code of conduct, addressed to altmetrics providers rather than to authors.
4. For the manuscript (`06_MANUSCRIPT/src/manuscript_v50.md`), which currently cites none of items 1 to 23 (grep for "Nuti", "Mavragani", "Thelwall", "checklist", "reporting guideline", "total error" returns nothing), the precedent that matters is Hölzl et al. 2025, Table 5: it already instructs authors to draw several samples from one opaque instrument and report their variation. The manuscript's Section 5.6 ("Reporting both makes the range of estimates visible; reporting one does not") extends the same logic across two instruments; it can be positioned as an extension of that recommendation, not as the first call for it.

## 6. Coverage gaps

- Semantic Scholar: not searched (HTTP 429 without a key). Settling it: obtain a free key, rerun queries A03, A07, C04, D17, E10.
- DBLP and arXiv direct APIs: failed; arXiv is covered through OpenAlex, DBLP is not (conference papers in information retrieval and web science without DOIs may be missed).
- Paywalled book chapters: Thelwall 2009 chapter 7 and 2017 chapter 4 were not read; their guidance on commercial data sources is asserted here from titles only.
- Non-English literature: one Spanish query (E02, 2 hits); no German, Portuguese, Russian or Chinese queries, although Russian- and Ukrainian-language Similarweb papers surfaced in C11, which suggests a practitioner literature in those languages.
- Grey literature of the SEO industry: vendor help centers (Ahrefs, Semrush, Similarweb methodology pages), practitioner "accuracy studies", and conference talks were not systematically searched; the one web search that reached them returned only blog posts, none a guideline. The manuscript's own Section 2 already cites two such studies (Langridge 2016; Soulo 2022).
- Journal author guidelines: whether any journal (for example JMIR, which published items 1, 5 and 6) imposes a Google Trends or web-data reporting requirement in its instructions to authors was not checked.
- Theses and dissertations: not searched beyond what OpenAlex indexes (one 2026 Valencia thesis surfaced in E02).
- Datasets and code: not searched.
- Date range: OpenAlex coverage of 2026 works is still filling; the newest guidance could be missed.

## 7. Saturation assessment

**PARTIAL.** Criteria met: five vocabularies; two universal backends plus EQUATOR and the web; 72 logged API queries plus two preliminary runs; three in-session controls passed; forward and backward chasing from ten seeds, which returned records already in the set (Nuti, Mavragani, Hölzl, Kim and Kostygina cite and are cited by one another) and nothing new on SEO-tool reporting. Criteria not met: Semantic Scholar unreachable; DBLP failed; two book chapters unread; non-English and industry grey literature only touched. The judgment in section 5 is therefore defensible for the indexed English-language literature and should be stated with that scope.

## 8. NOT VERIFIED

- MIAGE (Bragazzi 2019) as a published checklist. The preprint DOI resolves (Crossref type posted-content, issued 2019-01-02). A Crossref title-and-author search (45 fuzzy results, top five inspected) and a web search found no journal version. Settling it: search PubMed and the author's ORCID for 2019 to 2026 titles containing "MIAGE" or "minimum information".
- The 23 items of MIAGE and the checklist of Fassio and Comberiati 2021: item lists not read (JMIR Preprints page returned an empty body). Settling it: open the preprint PDFs.
- Moon and Barlev 2026 recommendations: abstract only (accepted-manuscript PDF returned HTTP 401).
- Thelwall 2009 chapter 7 and 2017 chapter 4: contents not read.
- "Initial Standardized Framework for Reporting Social Media Analytics in Emergency Care Research" (EQUATOR entry): DOI and authors not resolved here. Settling it: Crossref title query.
- Bar-Ilan, "Data collection methods on the Web for informetric purposes": exact-title query D03 returned 0 in OpenAlex. The paper may be indexed under a variant title; settling it: Crossref `query.bibliographic` with author filter.
- SAGE Research Methods (2024), "Best Practices for the Analysis and Visualisation of Google Trends Data" (10.4135/9781529694109, resolves as a database entry): authorship and content not read.
- Lo and Sedhain (2006), "How reliable are website rankings?" (10.48009/2_iis_2006_233-240): DOI resolves; the OpenAlex record carries no author names, so the attribution is from the Crossref record's title only and the authors are not confirmed here.
- Khosravi and Yoganarasimhan (2026): the SSRN DOI 10.2139/ssrn.7514898 resolves; the manuscript cites an arXiv identifier for the same title, which was not cross-checked here.

## 9. DO NOT ASSERT

1. "No reporting checklist exists for commercial SEO-tool data." Not earned. What is earned: none was found in the searches listed in section 2 on 2026-10-31, with Semantic Scholar and DBLP unsearched and vendor grey literature only sampled. Earning the stronger claim would need a registered systematic review across at least five databases, including non-English sources, and a check of journal author guidelines.
2. "This paper is the first to recommend reporting figures from more than one instrument, with a date, territory and a statement of uncertainty." Not earned. Google Trends checklists already require access date, location of access, full parameters, repeated samples and reported dispersion (Nuti 2014; Hölzl et al. 2025), and social-media checklists require the access path and vendor limitations (Kim et al. 2016; Kostygina et al. 2023). The manuscript can claim to extend these to a two-vendor design for SEO-tool estimates, scoped to the searches recorded here.
3. "MIAGE is a published 23-item checklist." Not earned; it is a 2019 preprint with no published version found.
4. "Hölzl et al. (2024)". The journal issue is 2025 (vol. 126, article 103099); the article appeared online in 2024. Cite as 2025 and say so.
5. "Google Trends sampling instability shows that Ahrefs or Semrush estimates are unstable." Not earned. Different data-generating processes; the Trends findings motivate the design of a check, they do not supply its result.
6. "The webometrics literature (Thelwall) gives a checklist for SEO-tool data." Not earned; the chapters were not read, and what was read (Thelwall 2008; Ingwersen and Björneborn 2006) concerns search-engine hit counts.
7. Any Crossref `total-results` figure as the size of a literature. The control for a single known paper returned 9,418,344.
8. Any OpenAlex total from a query marked with an asterisk (A09, A12, B07, B11, B12, C05, C13, D13) as a topic size; the unparenthesized OR inflated them.
9. "Semantic Scholar contains nothing on this question." It was not searched; HTTP 429 throughout.
10. "The EQUATOR Network has no relevant guideline." Earned only as: the library listing downloaded on 2026-10-31 contains no entry whose title mentions search engines, SEO tools, web traffic, Google Trends or infodemiology; entries for routinely collected data, e-surveys, eHealth trials and one social-media-analytics framework exist.
11. "NISO RP-25-2016 applies to SEO vendors." Not earned; it addresses altmetrics data providers.
12. "Reyes-Lillo et al. (2023) show SEO tools are accurate." Not earned; inter-tool agreement on one metric is not validity against a ground truth.
13. "Kostygina et al. (2023) cover SEO or web-analytics tools." Not earned; the checklist names none, and Google Trends appears once as an illustration of relative counts.
14. Any count from this record (for example 66 OpenAlex queries, 35 tabulated works) as a count of works that exist; they are counts of what was run and kept.
15. The manuscript's OpenAlex figure of 456 works naming Ahrefs, Semrush or Similarweb is not comparable to any count here; the queries differ.

## Files

- This record: `/Users/venkatapagadala/Desktop/Research-Papers/Paper-03-user-first-intelligence/01_LITERATURE/checklist_search_2026-10-31/search_record.md`
- Raw provenance (same directory, `raw/`): query log, per-query result sets, chase logs and record sets, DOI verification, abstracts, full-text extracts, web log.
- No existing project file was modified.
