# Independent novelty search: two claims for Paper 03 (scout run, 2026-10-15)

**Saturation: PARTIAL for both claims** (criteria in section 7). Searches ran 2026-10-15 03:52 to 04:37 UTC (evening of 2026-10-14, US time). One screener (the research-scout agent); there was no second independent screener, so no agreement rate exists. No file in the Research-Papers tree was read; this search is independent of the author's own search. No contact email was sent to any API.

## 0. Verdicts at a glance

| Claim | Verdict | One-line reason |
|---|---|---|
| 1. Two commercial SEO or traffic-estimation vendors (e.g. Ahrefs and Semrush) compared on one website section followed from its go-live date; or a cross-section of several sections of one domain read on both vendors on one day | **PARTLY** | No record found of a two-vendor, section-level series that starts at go-live. Same-day multi-vendor reads inside a domain do exist: at URL level with Ahrefs, SEMrush and two other tools (Font-Julián et al. 2026, all data downloaded 5 July 2024), and at subdomain level with a different vendor pair (Vállez & Ventura 2020, Sistrix with Xovi as a control). |
| 2. Source types cited by AI answer surfaces (AI Overviews, AI Mode, ChatGPT, Perplexity, Gemini, Copilot) compared across all eleven GICS sectors of the S&P 500, sector frame fixed by an external rule | **PARTLY** | Studies crossing several AI surfaces, industries and cited-source types exist, mostly vendor reports (OtterlyAI, Tinuiti, Profound, Yext) plus Hendricks 2026, Chen et al. 2025 and Lee 2026. Every industry frame found is author-chosen or undefined. No record found uses GICS sectors or S&P 500 constituents as the frame. |

Both verdicts describe what this search found. Neither is a statement that no such work exists (see section 9).

## 1. Question as searched

Frames were written before the first query, in `question_frames.txt` (scratch); they are reproduced here.

**Claim 1 slot frame**
- Object: records that commercial SEO or traffic-estimation vendors hold about a website. The vendors in scope were Ahrefs and Semrush, plus Similarweb, Moz, Majestic, SE Ranking, Sistrix, Serpstat, Alexa, Compete and Quantcast.
- Factor: vendor identity, with two or more vendors read on the same target.
- Comparison: vendor A against vendor B, with or without first-party ground truth (Google Analytics, Search Console).
- Outcome: any vendor record, such as estimated organic traffic, keywords, rankings, backlinks, authority scores, or time to first detection.
- Setting: (a) one section of a site (subfolder, subdomain or path prefix) followed from a known go-live date; (b) several sections of one domain read on both vendors on one day.
- Window: 1996 to 2026 (Alexa launched in 1996).
- Assumptions I filled in: "section" means a subfolder, subdirectory, subdomain or path prefix of one registrable domain. Any pair of commercial vendors counts as close prior work; Ahrefs plus Semrush counts as a match. "Published" includes peer-reviewed work, preprints, theses, datasets and vendor or practitioner reports, each labelled by tier.

**Claim 2 slot frame**
- Object: AI answer surfaces, namely Google AI Overviews, Google AI Mode, ChatGPT (search), Perplexity, Gemini and Microsoft Copilot.
- Factor: the industry sector of the query subject, using the 11 GICS sectors of the S&P 500 as the frame, fixed by an external rule.
- Comparison: across surfaces and across sectors.
- Outcome: types of cited sources, such as brand-owned, news or earned media, UGC or social, government or institutional, reference, and reviews.
- Window: 2022 to 2026.
- Assumptions I filled in: "close" means several surfaces, plus classification of cited sources, plus stratification by industry, vertical or sector. "Match" means the GICS or S&P 500 frame, or another externally fixed industry taxonomy.

**Vocabularies searched (at least three per claim)**
- Claim 1:
  - (V1) SEO practitioner terms: Ahrefs, Semrush, Similarweb, Sistrix, Serpstat, Majestic, Moz, SEO tools, organic traffic estimates, domain authority, keyword search volume.
  - (V2) Webometrics and information science: website traffic measurement, competitive intelligence tools, web traffic data sources, Alexa, academic SEO, link databases, visibility index.
  - (V3) Internet measurement: top lists, top sites, domain or website popularity rankings, Tranco, Umbrella, CrUX.
  - (V4) Econometrics and data quality: third-party web traffic estimates, measurement error, clickstream panel, web analytics data quality.
  - (V5) Temporal and section design: new website, newly launched, website launch, since launch, went live, subfolder, subdirectory, subdomain, site section.
  - Non-English: Spanish, Portuguese, German, Indonesian, Russian and Ukrainian comparison terms.
- Claim 2:
  - (V1) IR and NLP: generative search engines, verifiability, attribution, cited sources, source types, search-augmented LLMs.
  - (V2) Marketing: generative engine optimization (GEO), answer engine optimization (AEO), AI visibility, brand visibility, AI Overviews, AI Mode.
  - (V3) Journalism: news source citing patterns, publishers, earned media.
  - (V4) Finance: S&P 500, GICS, Global Industry Classification Standard, Fortune 500, Russell 1000.
  - (V5) Audit studies: audit, source exposure, source diversity, combined with sector, industry or vertical terms.

## 2. Search record

### 2.1 Backend status and control tests

| Backend | Status on 2026-10-15 | Control test and result |
|---|---|---|
| OpenAlex | Working. One HTTP 429 recovered on retry. Deep cursor paging returned duplicate pages and then HTTP 401, so page-number paging was used instead (all 641 records of c2_oa01 retrieved). | Title query for "tranco" returned the Tranco paper (W2904027722). |
| Crossref | Working. Fuzzy relevance ranking produces noise on free-text queries, so title queries were used. | n/a |
| arXiv API | Working. | c1_ax02 returned 0; the same-session control `abs:"search engine optimization"` returned 60, so the 0 reflects the query. A known-title control (GEO, 2311.09735) was also found. |
| Semantic Scholar (keyless) | HTTP 429 inside litsearch runs. Direct calls with backoff succeeded. | The query "GEO: Generative Engine Optimization" returned 878 total, with 2311.09735 first. |
| DBLP | **Outage.** dblp.org, dblp.uni-trier.de and dblp.dagstuhl.de all returned an anti-bot challenge page ("Making sure you're not a bot!") instead of JSON. | A known-title control ("Tranco research-oriented top sites ranking") also failed, so every DBLP result is void. DBLP-indexed CS work is covered only through OpenAlex and Semantic Scholar, which carry DBLP keys. |
| Google Scholar (web) | Reachable for light use; first result page only; 7 queries. | c2_gs02 parsed 0 results; the control "GEO: Generative Engine Optimization" returned 242, so the 0 reflects the long OR query. |
| SSRN | HTTP 403 on abstract pages and PDFs, from both WebFetch and curl. | Not resolvable; see section 8. |
| Zenodo API | One HTTP 403 ("unusual traffic"), then success. | Lee 2026 record 19831300 retrieved. |
| Search Engine Land, Business Wire, digitrendz | HTTP 403. | Yext verified on yext.com instead; SEL is NOT VERIFIED. |
| Internet Archive | Not fetchable with WebFetch. | The archived Authority Hacker study could not be checked. |

### 2.2 Database queries (verbatim; generated from the run log)

The tools were `~/.claude/skills/research-paper/scripts/litsearch.py` for the c1_q* rows, and direct calls to the OpenAlex `/works` API (filter syntax shown), the arXiv `export.arxiv.org/api/query` (sorted by submittedDate, descending), the Semantic Scholar `/graph/v1/paper/search/bulk` endpoint (Boolean syntax: `+` AND, `|` OR), Crossref `query.title`, and the Google Scholar web page 1. A "kept" record was retained for the closest-work or background set of the relevant claim; records outside scope were excluded at title or abstract.

| ID | Date (UTC) | Backend | Exact query or filter | Sort / limits | Hits (backend total) | Screened and kept |
|---|---|---|---|---|---|---|
| c1_q01 | 2026-10-15 03:52 UTC | src:openalex,crossref | `Ahrefs Semrush` | since=- limit=50 | {"openalex": 50, "crossref": 12} | 7 kept: Font-Julián 2026 (JIS), Font-Julián 2025 preprint, Font-Julián 2025 dataset, Reyes-Lillo 2023 dataset, Kostagiolas 2020, Gabry & Martins 2024, Wilde 2026 |
| c1_q02 | 2026-10-15 03:53 UTC | field:computer science | `Ahrefs Semrush comparison` | since=- limit=50 | {"openalex": 50, "crossref": 50, "arxiv": 0} | 2 new kept: Reyes-Lillo 2023 article, Jansen 2022. DBLP failed (anti-bot page); S2 HTTP 429 |
| c1_q03 | 2026-10-15 03:54 UTC | field:computer science | `SEO tools discrepancies traffic estimates` | since=- limit=50 | {"openalex": 50, "crossref": 50, "arxiv": 0} | 0 (road-traffic noise). DBLP failed; S2 HTTP 429 |
| c1_q04 | 2026-10-15 03:54 UTC | field:information retrieval | `accuracy of SEO tool organic traffic estimates` | since=- limit=50 | {"openalex": 50, "crossref": 50, "arxiv": 0} | 0. DBLP failed |
| c1_q05 | 2026-10-15 03:54 UTC | src:openalex,crossref,semanticscholar | `Semrush Similarweb Google Analytics comparison website traffic` | since=- limit=50 | {"openalex": 50, "crossref": 50} | 0 for Claim 1. S2 HTTP 429 |
| c1_oa01 | 2026-10-15 03:54 UTC | openalex-direct | `filter=title_and_abstract.search:(ahrefs AND semrush)` | sort=relevance_score:desc per-page=100 | {"openalex_total": 42} | all 42 screened; 8 kept (overlap with c1_q01) |
| c1_oa02 | 2026-10-15 03:55 UTC | openalex-direct | `filter=title_and_abstract.search:((ahrefs OR semrush OR similarweb OR moz OR majestic OR sistrix OR serpstat) AND (comparison OR compare OR compared OR discrepancies OR discrepancy OR agreement OR reliability OR accuracy OR validity OR triangulation))` | sort=relevance_score:desc per-page=200 | {"openalex_total": 1024} | superseded: "moz"/"majestic" collide with chemistry and adjectives; first 200 titles screened, 0 kept |
| c1_oa03 | 2026-10-15 03:55 UTC | openalex-direct | `filter=title_and_abstract.search:((ahrefs OR semrush OR similarweb OR sistrix OR serpstat OR "majestic seo" OR "moz pro" OR "open site explorer") AND (comparison OR compare OR compared OR discrepancies OR discrepancy OR agreement OR reliability OR accuracy OR validity OR triangulation OR "ground truth"))` | sort=relevance_score:desc per-page=200 | {"openalex_total": 124} | all 124 titles screened; 4 new kept: Prantl 2018, Rasool 2026, Garg 2025, Jääskö 2018 |
| c1_oa04 | 2026-10-15 03:56 UTC | openalex-direct | `filter=title_and_abstract.search:(("web traffic" OR "website traffic" OR "site traffic" OR "traffic estimates" OR "traffic estimation" OR "audience measurement") AND (alexa OR similarweb OR compete.com OR comscore OR quantcast OR "third-party" OR "third party" OR "competitive intelligence") AND (accuracy OR validity OR reliability OR comparison OR discrepancies OR "ground truth" OR "google analytics"))` | sort=relevance_score:desc per-page=200 | {"openalex_total": 42} | all 42 screened; 1 kept: Fuss et al. 2018 |
| c1_oa05 | 2026-10-15 03:56 UTC | openalex-direct | `filter=title.search:(similarweb OR "similar web" OR alexa.com OR "alexa rank" OR "alexa traffic" OR "traffic rank" OR semrush OR ahrefs OR "seo tools" OR "seo tool")` | sort=relevance_score:desc per-page=200 | {"openalex_total": 113} | all 113 screened; 1 new kept: Cahyono et al. 2024 |
| c1_oa06 | 2026-10-15 03:56 UTC | openalex-direct | `filter=title_and_abstract.search:((majestic AND (ahrefs OR moz OR backlink OR backlinks OR webometric OR webometrics OR "link analysis" OR inlinks)) OR (ahrefs AND (webometric OR webometrics OR "link analysis" OR inlinks OR backlinks)))` | sort=relevance_score:desc per-page=200 | {"openalex_total": 50} | all 50 screened; 0 new (single-vendor webometrics only) |
| c1_oa07 | 2026-10-15 03:56 UTC | openalex-direct | `filter=title_and_abstract.search:(("top lists" OR "top list" OR "top sites" OR "domain rankings" OR "website rankings" OR "popularity rankings" OR "website popularity") AND (alexa OR majestic OR umbrella OR tranco OR similarweb OR crux OR quantcast))` | sort=relevance_score:desc per-page=200 | {"openalex_total": 76} | all 76 screened; 5 kept as background: Scheitle 2018, Le Pochat 2019, Rweyemamu 2019, Ruth 2022, Alby & Jäschke 2022 |
| c1_oa08 | 2026-10-15 03:56 UTC | openalex-direct | `filter=title_and_abstract.search:(("new website" OR "newly launched" OR "website launch" OR "site launch" OR "brand-new website" OR "new domain" OR "since launch" OR "went live") AND (seo OR "search engine optimization" OR "organic traffic" OR "search visibility") AND (ahrefs OR semrush OR similarweb OR sistrix OR moz OR "search console" OR "seo tools"))` | sort=relevance_score:desc per-page=200 | {"openalex_total": 2} | 2, both already seen (Jääskö 2018 kept; Marchuk 2024 excluded) |
| c1_oa09 | 2026-10-15 03:56 UTC | openalex-direct | `filter=title_and_abstract.search:((subfolder OR subfolders OR subdirectory OR subdirectories OR subdomain OR subdomains OR "site section" OR "website section" OR "website sections") AND (seo OR "search engine optimization" OR "organic traffic" OR "search visibility" OR ahrefs OR semrush))` | sort=relevance_score:desc per-page=200 | {"openalex_total": 22} | all 22 screened; 0 |
| c1_s2_01 | 2026-10-15 03:57 UTC | semanticscholar-direct bulk | `(ahrefs \| semrush \| similarweb \| serpstat \| sistrix) + (comparison \| compare \| discrepancies \| reliability \| accuracy \| validity \| agreement)` | year=None | {"s2_total": 71} | 71 returned, 63 already in set; 0 new works kept (Jansen et al. S2 record = PLOS ONE 2022 work) |
| c1_ax01 | 2026-10-15 03:58 UTC | arxiv-direct | `all:similarweb OR all:semrush OR all:ahrefs OR abs:"traffic estimates" OR abs:"web traffic estimates"` | sort=submittedDate desc max=100 | {"arxiv_total": 37} | 1 kept: Khosravi & Yoganarasimhan 2026 |
| c1_ax02 | 2026-10-15 03:58 UTC | arxiv-direct | `abs:"search engine optimization" AND (abs:tools OR abs:metrics) AND (abs:comparison OR abs:discrepancies OR abs:accuracy)` | sort=submittedDate desc max=100 | {"arxiv_total": 0} | 0 returned; control below |
| c1_ax02_control | 2026-10-15 03:58 UTC | arxiv-direct | `abs:"search engine optimization"` | sort=submittedDate desc max=30 | {"arxiv_total": 60} | CONTROL for c1_ax02: 60 returned, so the 0 is a property of the query |
| c1_ax03 | 2026-10-15 03:58 UTC | arxiv-direct | `abs:"search engine optimization" AND (abs:ahrefs OR abs:semrush OR abs:moz OR abs:tool OR abs:tools)` | sort=submittedDate desc max=50 | {"arxiv_total": 6} | 0 |
| c1_oa10 | 2026-10-15 03:58 UTC | openalex-direct | `filter=title_and_abstract.search:(("keyword search volume" OR "search volume estimates" OR "keyword planner" OR "keyword volume") AND (ahrefs OR semrush OR moz OR "seo tools" OR comparison OR accuracy OR discrepancies))` | sort=relevance_score:desc per-page=100 | {"openalex_total": 34} | 0 |
| c1_oa11 | 2026-10-15 03:58 UTC | openalex-direct | `filter=title_and_abstract.search:(("web analytics" OR "website analytics" OR "traffic data" OR "web traffic") AND ("data quality" OR "measurement error" OR discrepancies OR "inter-tool" OR "cross-platform" OR triangulation) AND (similarweb OR semrush OR ahrefs OR alexa OR "third-party" OR panel OR clickstream))` | sort=relevance_score:desc per-page=100 | {"openalex_total": 12} | 0 new (SSRN copy of Khosravi & Yoganarasimhan) |
| c1_cr_title_semrush | 2026-10-15 04:04 UTC | crossref-direct | `query.title=semrush` | rows=100 | {"crossref_total": 7} | all title matches already in set |
| c1_cr_title_ahrefs | 2026-10-15 04:05 UTC | crossref-direct | `query.title=ahrefs` | rows=100 | {"crossref_total": 3} | all title matches already in set |
| c1_cr_title_similarweb | 2026-10-15 04:05 UTC | crossref-direct | `query.title=similarweb` | rows=100 | {"crossref_total": 4} | all title matches already in set |
| c1_oa12 | 2026-10-15 04:05 UTC | openalex-direct | `filter=title_and_abstract.search:((herramientas OR ferramentas OR Werkzeuge OR "SEO-Tools" OR alat OR инструменты OR сервисы OR інструменти) AND (semrush OR ahrefs OR sistrix OR similarweb OR serpstat) AND (comparación OR comparativa OR comparação OR Vergleich OR perbandingan OR сравнение OR порівняння OR fiabilidad OR precisión OR discrepancias))` | sort=relevance_score:desc per-page=100 | {"openalex_total": 4} | 0 |
| c1_oa13 | 2026-10-15 04:05 UTC | openalex-direct | `filter=title_and_abstract.search:((sistrix OR "sichtbarkeitsindex" OR "visibility index") AND (semrush OR ahrefs OR searchmetrics OR xovi))` | sort=relevance_score:desc per-page=100 | {"openalex_total": 10} | 0 |
| c1_gs01 | 2026-10-15 04:05 UTC | google-scholar-web | `"Ahrefs" "Semrush" comparison` | page1  | {"gs_reported": "132", "blocked": false} | first page only; 1 new kept (Sarıkaya 2021 thesis, content NOT VERIFIED); also surfaced Kunal 2026 (Claim 2) |
| c1_gs02 | 2026-10-15 04:05 UTC | google-scholar-web | `"Semrush" "Ahrefs" subfolder OR subdirectory OR "new website" traffic estimates` | page1  | {"gs_reported": "11", "blocked": false} | first page only; 0 kept (theses on SEO for new websites; no vendor comparison in snippets) |
| c2_oa01 | 2026-10-15 04:07 UTC | openalex-direct | `filter=title_and_abstract.search:(("AI Overviews" OR "AI Overview" OR "AI Mode" OR "generative search" OR "generative engine" OR "generative engines" OR "answer engine" OR "answer engines" OR "AI search" OR "LLM-based search" OR "conversational search engine" OR perplexity.ai OR "ChatGPT search") AND (citation OR citations OR cited OR "sources cited" OR "source types" OR "cited sources" OR "cited domains"))` | sort=publication_date:desc per-page=200 | {"openalex_total": 641} | run twice (page 1, then all 4 pages); all 641 titles screened; about 60 abstracts read; about 15 kept, incl. Hendricks 2026, Arshad 2026, House 2026, Lee 2026 (fan-out), Kumar 2026 |
| c2_ax01 | 2026-10-15 04:12 UTC | arxiv-direct | `abs:"AI Overviews" OR abs:"AI Overview" OR abs:"AI Mode" OR ti:"AI Overviews"` | sort=submittedDate desc max=200 | {"arxiv_total": 40} | all 40 screened; about 10 kept (AI Overviews audits) |
| c2_ax02 | 2026-10-15 04:12 UTC | arxiv-direct | `(abs:citations OR abs:cited OR abs:"cited sources" OR abs:"source types") AND (abs:"generative search" OR abs:"generative engine" OR abs:"generative engines" OR abs:"answer engine" OR abs:"answer engines" OR abs:"AI search" OR abs:perplexity OR abs:"search-augmented")` | sort=submittedDate desc max=300 | {"arxiv_total": 94} | all 94 screened; about 18 kept (multi-engine citation audits) |
| c2_oa01 | 2026-10-15 04:22 UTC | openalex-direct (all pages) | `filter=title_and_abstract.search:(("AI Overviews" OR "AI Overview" OR "AI Mode" OR "generative search" OR "generative engine" OR "generative engines" OR "answer engine" OR "answer engines" OR "AI search" OR "LLM-based search" OR "conversational search engine" OR perplexity.ai OR "ChatGPT search") AND (citation OR citations OR cited OR "sources cited" OR "source types" OR "cited sources" OR "cited domains"))` | sort=publication_date:desc | {"openalex_total": 641} | run twice (page 1, then all 4 pages); all 641 titles screened; about 60 abstracts read; about 15 kept, incl. Hendricks 2026, Arshad 2026, House 2026, Lee 2026 (fan-out), Kumar 2026 |
| c2_oa02 | 2026-10-15 04:23 UTC | openalex-direct | `filter=title_and_abstract.search:(("S&P 500" OR "S&P500" OR GICS OR "Global Industry Classification Standard" OR "Fortune 500" OR "Russell 1000") AND ("AI Overviews" OR "AI Mode" OR "generative engine" OR "generative search" OR "AI search" OR "answer engine" OR perplexity OR chatgpt OR gemini OR copilot OR "large language model" OR "large language models" OR LLM OR LLMs))` | sort=relevance_score:desc per-page=200 | {"openalex_total": 284} | first 200 of 284 screened; 0 kept (finance and trading applications) |
| c2_oa02all | 2026-10-15 04:23 UTC | openalex-direct (all pages) | `filter=title_and_abstract.search:(("S&P 500" OR "S&P500" OR GICS OR "Global Industry Classification Standard" OR "Fortune 500" OR "Russell 1000") AND ("AI Overviews" OR "AI Mode" OR "generative engine" OR "generative search" OR "AI search" OR "answer engine" OR perplexity OR chatgpt OR gemini OR copilot OR "large language model" OR "large language models" OR LLM OR LLMs))` | sort=publication_date:desc | {"openalex_total": 284} | all 284 titles screened; 0 kept: none concerns sources cited by AI answer surfaces |
| c2_s2_01 | 2026-10-15 04:23 UTC | semanticscholar-direct bulk | `("S&P 500" \| GICS \| "Global Industry Classification") + ("AI Overviews" \| "AI Mode" \| "generative engine" \| "generative search" \| "AI search" \| "answer engine" \| Perplexity \| "search-augmented")` | year=None | {"s2_total": 1} | 1 returned (LSTM code study); 0 kept |
| c2_ax03 | 2026-10-15 04:23 UTC | arxiv-direct | `(abs:"S&P 500" OR abs:GICS) AND (abs:citations OR abs:cited OR abs:sources) AND (abs:LLM OR abs:LLMs OR abs:"AI search" OR abs:ChatGPT OR abs:Perplexity OR abs:"generative")` | sort=submittedDate desc max=100 | {"arxiv_total": 24} | all 24 screened; 0 kept (finance NLP) |
| c2_gs01 | 2026-10-15 04:23 UTC | google-scholar-web | `"S&P 500" "AI Overviews" OR "AI Mode" OR "Perplexity" citations sources sectors` | page1  | {"gs_reported": "134", "blocked": false} | first page; 1 kept: Cook 2025 (SSRN; content NOT VERIFIED) |
| c2_gs02 | 2026-10-15 04:24 UTC | google-scholar-web | `GICS sectors "AI search" OR "generative engine" OR "answer engine" citations source types` | page1  | {"gs_reported": null, "blocked": false} | 0 parsed; control below |
| c2_gs02_control | 2026-10-15 04:24 UTC | google-scholar-web | `"GEO: Generative Engine Optimization"` | page1  | {"gs_reported": "242", "blocked": false} | CONTROL for c2_gs02: 242 reported, so Scholar was reachable |
| c2_gs02b | 2026-10-15 04:24 UTC | google-scholar-web | `GICS "AI search" citations` | page1  | {"gs_reported": "17", "blocked": false} | first page; 1 kept: Lee 2026 |
| c2_s2_02 | 2026-10-15 04:27 UTC | semanticscholar-direct bulk | `(sector \| sectors \| industry \| industries \| vertical \| verticals) + (citations \| cited \| "source types" \| "cited sources") + ("AI Overviews" \| "AI Overview" \| "generative engine" \| "generative engines" \| "answer engine" \| "answer engines" \| "AI search" \| Perplexity \| "AI Mode")` | year=None | {"s2_total": 23} | all 23 screened; 0 new (all already found via arXiv/OpenAlex) |
| c2_oa03 | 2026-10-15 04:27 UTC | openalex-direct (all pages) | `filter=title_and_abstract.search:((industries OR sectors OR verticals OR "industry sectors" OR "by industry" OR "by sector" OR "business sectors") AND ("AI Overviews" OR "AI Overview" OR "AI Mode" OR "answer engine" OR "answer engines" OR "AI search" OR "generative engine" OR "generative engines" OR "generative search" OR perplexity OR "ChatGPT search" OR "LLM search") AND (cite OR cites OR cited OR citation OR citations OR sources))` | sort=publication_date:desc | {"openalex_total": 252} | all 252 titles screened (148 not in c2_oa01); 0 new close works |
| c2_oa_fulltext | 2026-10-15 04:33 UTC | openalex-direct fulltext | `filter=fulltext.search:GICS,title_and_abstract.search:("AI Overviews" OR "generative engine" OR "answer engine" OR "AI search" OR perplexity OR "AI Mode")` | per-page=50 | {"openalex_total": 11} | full-text n-gram noise; 0 kept |
| c2_oa_fulltext | 2026-10-15 04:33 UTC | openalex-direct fulltext | `filter=fulltext.search:"S&P 500",title_and_abstract.search:("AI Overviews" OR "generative engine" OR "answer engine" OR "AI search" OR "AI Mode") ` | per-page=50 | {"openalex_total": 1} | full-text n-gram noise; 0 kept |
| c2_oa_fulltext | 2026-10-15 04:33 UTC | openalex-direct fulltext | `filter=fulltext.search:GICS,title_and_abstract.search:(citations OR cited) ,title_and_abstract.search:(LLM OR LLMs OR ChatGPT OR "large language")` | per-page=50 | {"openalex_total": 10} | full-text n-gram noise; 0 kept |
| c2_ax03_rerun | 2026-10-15 04:36 UTC | arxiv-direct | `(abs:"S&P 500" OR abs:GICS) AND (abs:citations OR abs:cited OR abs:sources) AND (abs:LLM OR abs:LLMs OR abs:"AI search" OR abs:ChatGPT OR abs:Perplexity OR abs:"generative")` | sort=submittedDate desc max=100 | {"arxiv_total": 24} | same query re-run to save output; 24 |

### 2.3 Grey literature: web searches (WebSearch, 2026-10-15)

| # | Query (verbatim) | Mode | Outcome |
|---|---|---|---|
| W1 | Ahrefs vs Semrush traffic estimates accuracy study compared Google Search Console data | standard | Found the Ahrefs 2022 self-study, Promodo 2024, and secondhand mentions of Authority Hacker, Collaborator.pro and Pikeraai. |
| W2 | study tracking new website from launch day in Ahrefs and Semrush how long until traffic estimates appear | standard | No study that tracks a site from launch in both tools. |
| W3 | SparkToro OR "Authority Hacker" traffic estimation tools accuracy study Similarweb Semrush Ahrefs Google Analytics websites compared | standard | Found Screaming Frog 2016; Backlinko and SparkToro only secondhand. |
| W4 | compare Ahrefs Semrush subfolder subdirectory traffic same site sections discrepancy analysis | standard | No source compares subfolder-level traffic between Ahrefs and Semrush. |
| W5 | "Mind the Invisibility Gap" "80 leading global brands" LLM answers Niall Cook sector | standard | No primary source found. |
| W6 | "Query Intent and Google Rank as Joint Predictors of AI Citation" Anthony Lee multi-platform observational study | standard | Not found by web search; later resolved through OpenAlex and Zenodo. |
| W7 | "S&P 500" companies AI search citations study ChatGPT Perplexity "AI Overviews" sources cited by sector | extended | No S&P 500 study; found Otterly (17 industries) and Attrifast (12 verticals). |
| W8 | GICS sectors AI visibility report which sources AI answer engines cite by industry sector 2026 | extended | No GICS-framed report; found Trendos/SEJ (3 industries) and Profound. |
| W9 | Yext research AI citations 6.8 million industries first-party websites listings Gemini ChatGPT Perplexity | standard | Yext October 2025 (verified on yext.com). |
| W10 | Muck Rack "What is AI Reading" report journalism citations ChatGPT Claude Gemini industries | standard | Muck Rack Generative Pulse, 17 industries (secondhand only). |
| W11 | BrightEdge OR Conductor OR Profound AI Overviews citations by industry report healthcare finance ecommerce source types 2025 2026 | standard | Profound vertical breakdown (verified); Conductor 10 industries (secondhand). |
| W12 | searchengineland AI search citations 11 industries study which sources cited | standard | SEL 11-industry study; the industries named secondhand are not GICS sectors; NOT VERIFIED. |
| W13 | Tinuiti AI citations nine verticals seven AI platforms study source types | standard | Tinuiti Q1 2026 (verified). |
| W14 | study AI chatbots answers about public companies investor relations sources cited S&P 500 OR "Fortune 500" ChatGPT Perplexity Gemini Copilot | extended | Everything-PR 2026 (verified; no company sample is stated). |
| W15 | "Fortune 500" AI search visibility study citations source types AI Overviews ChatGPT sector breakdown | standard | No Fortune 500 study. |
| W16 | Semrush "AI Visibility Index" industries brands sources cited ChatGPT Google AI Mode methodology | standard | Semrush index 2025/2026 (secondhand). |
| W17 | Stacker "2026 AI Trust Report" 3.9 million citations six platforms 10 verticals source types | standard | Stacker 2026 (secondhand). |
| W18 | "S&P 500" brands "AI visibility" OR "generative engine" OR "AI answers" study by sector Evertune OR Brandlight OR Scrunch OR Profound OR "Bloomberg Intelligence" OR "S&P Global" | extended | Only AI-adoption studies of S&P 500 firms; Similarweb 2026 GenAI index (6 industries, secondhand). |

Pages fetched to verify (WebFetch or curl):
- Read: the RiuNet records 10251/223019 and 10251/236956, arXiv 2609.30481 and 2512.24968, ahrefs.com/blog/traffic-estimations-accuracy/, promodo.com/blog/data-accuracy-at-similarweb-ahrefs-and-semrush, screamingfrog.co.uk/how-accurate-are-website-traffic-estimators/, diposit.ub.edu handle 2445/182744, hendricks.ai/research/the-answer-index, otterly.ai/blog/ai-search-index/, searchenginejournal.com/ai-search-citation-sources-trendos-spa/586289/, tryprofound.com/blog/enhanced-citation-categories, tinuiti.com/research-insights/research/ai-citation-trends-report-q1-2026/, everything-pr.com/who-controls-ai-answers-in-investor-relations, and yext.com/about/news-media/ai-citations-release.
- Failed: authorityhacker.com/traffic-estimates-accuracy (now a landing page with no study), web.archive.org (not fetchable), and SSRN, SEL, Business Wire and digitrendz (HTTP 403).

### 2.4 Full texts read (beyond abstracts)

- Font-Julián et al. 2025, OSF preprint PDF.
- Font-Julián et al. 2026, accepted manuscript (RiuNet DSpace REST).
- Vállez & Ventura 2020, submitted version (diposit.ub.edu DSpace REST).
- Khosravi & Yoganarasimhan 2026, arXiv PDF, including Table 1 (21 papers that use Similarweb or Semrush data).
- Zhao & Berman 2025 v4, arXiv PDF.
- Chen et al. 2025, arXiv PDF.
- Lee 2026 v6, Zenodo PDF.
- Martinez 2026 survey, arXiv PDF, reference list.

### 2.5 Citation chasing (one hop, both directions where available)

| Seed | Backend | Backward (refs) | Forward (citing) | New relevant records added |
|---|---|---|---|---|
| Font-Julián et al. 2026, doi:10.1177/01655515261445903 | OpenAlex | 33 (30 new to set) | 0 | Vállez & Ventura 2020; García-Carretero et al. 2016; Orduña-Malea & Aguillo 2022 (QSS); Orduña-Malea & Font-Julián 2024 |
| Reyes-Lillo et al. 2023, doi:10.3145/epi.2023.jul.03 | OpenAlex | 32 (23 new) | 10 (6 new) | none |
| Jansen et al. 2022, doi:10.1371/journal.pone.0268212 | OpenAlex | 74 (67 new) | 47 (43 new) | Vaughan & Yang 2013 |
| Prantl & Prantl 2018, doi:10.1108/ijwis-01-2018-0001 | OpenAlex | 29 (26 new) | 28 (19 new) | Lo & Sedhain 2006 |
| Vaughan & Yang 2013, doi:10.1016/j.joi.2013.04.005 | OpenAlex | 23 (18 new) | 49 (43 new) | Vaughan & Yang 2012 |
| Rasool et al. 2026, doi:10.1108/pmm-07-2026-0065 | OpenAlex | 34 (25 new) | 0 | none |
| Khosravi & Yoganarasimhan 2026, arXiv:2609.30481 | PDF reference list and Table 1 | 21 papers in Table 1 | n/a | Zhao & Berman 2025; Cao, Koning & Nanda 2023 |
| GEO, Aggarwal et al. 2024, doi:10.1145/3637528.3671900 | OpenAlex / Semantic Scholar | n/a | 55 (OpenAlex), 118 (S2); filtered by sector, industry, vertical, GICS, S&P 500 and source-type terms: 9 and 12 | Lee 2026 (SSRN); Jack et al. 2026; Zatuchin 2026; Chen et al. 2026 |
| Chen et al. 2025, arXiv:2509.08919 | OpenAlex / Semantic Scholar | full text read | 4 (OpenAlex), 43 (S2); with terms: 2 and 8 | Chen & Koudas 2026; Zatuchin 2026; Jack et al. 2026 |
| Liu, Zhang & Liang 2023, doi:10.18653/v1/2023.findings-emnlp.467 | OpenAlex | n/a | 137; with terms: 4 | none |
| Yang 2025, arXiv:2507.05301; Venkit et al. 2024, arXiv:2410.22349; Search Arena 2025, arXiv:2506.05334 | OpenAlex | n/a | 0, 2 and 1 (OpenAlex under-links arXiv citations) | none |
| Martinez 2026 survey, arXiv:2607.14035 | PDF reference list | about 60 refs | n/a | Kirsten et al. 2026 (Findings ACL); Li & Sinnamon 2024 (ASIS&T). The survey text contains no GICS, S&P 500 or sector-stratified study. |

Depth: one hop. Citation chasing added 300 records to the Claim 1 set and about 360 to the Claim 2 set.

### 2.6 Flow counts

| Stage | Claim 1 | Claim 2 |
|---|---|---|
| Unique records identified (deduplicated by DOI or normalized title) | 910 (about 610 from database runs, 300 from citation chasing) | 1,156 from database runs plus Semantic Scholar forward chasing; plus 199 from OpenAlex forward chasing; plus 30 Scholar page-1 results; plus about 20 grey-literature pages |
| Screened on title | all | all |
| Abstracts read | about 60 | about 90 |
| Full texts or primary pages read | 5 full texts; 3 practitioner pages | 3 full texts (Chen et al. 2025, Lee 2026, Martinez 2026); 7 vendor or grey pages |
| Kept as closest or background (sections 3 and 5) | about 30 | about 40 |

Exclusion reasons at title and abstract stage:
- Claim 1: different construct (road traffic, network traffic, phishing, single-vendor SEO case studies, tool lists, coupons); no vendor-versus-vendor comparison; first-party analytics only.
- Claim 2: LLM finance applications with no cited-source analysis; brand-mention studies with no source-type classification; single-surface topic audits with no industry dimension (kept as background where informative).

## 3. What the literature establishes

Tier key: [PR] peer-reviewed; [PRE] preprint, thesis or dataset; [V] vendor, agency or practitioner report (nothing attaches; interested parties are flagged).

**Claim 1 (vendor records of websites)**

1. **Commercial SEO tools disagree a great deal on keyword and URL-level data for the same domains.** [PR] Font-Julián, Lopezosa, Orduña-Malea & Aguillo 2026, doi:10.1177/01655515261445903.
   - Data: Ahrefs, SEMrush, Serpstat and Ubersuggest on mdpi.com and frontiersin.org, all downloaded on 5 July 2024 (US/English desktop). That gave 151,145 keywords and 84,386 URLs.
   - Overlap: only 1,914 URLs (2.3%) appear in all four tools. Every pair of tools has a Jaccard index below 0.3 on the top 2,500 URLs.
   - Agreement: the Ahrefs to SEMrush correlation of URL traffic is Rs = 0.73. Mean coefficient of variation across URLs is 0.77.
   - Strength: moderate. Two domains, one date, academic publishers, and the authors caution that results may differ for less diverse sites.
2. **Domain-level authority scores agree closely across vendors.** [PR] Reyes-Lillo, Morales-Vargas & Rovira 2023, doi:10.3145/epi.2023.jul.03 (data doi:10.5281/zenodo.8025045).
   - Moz DA, Semrush Authority Score and Ahrefs DR for 3,151 domains, collected November to December 2022: pairwise Spearman rho above 0.9.
   - Authority scores are a different construct from traffic or keywords.
3. **Third-party traffic estimates diverge from first-party or audited traffic.**
   - [PR] Jansen, Jung & Salminen 2022, doi:10.1371/journal.pone.0268212: Google Analytics against SimilarWeb on 86 websites, using one year of monthly averages.
   - [PR] Prantl & Prantl 2018, doi:10.1108/ijwis-01-2018-0001: Alexa and SimilarWeb against accurate traffic data for Czech sites; neither ranks sites accurately.
4. **Vendor-against-vendor differences are statistically significant.** [PR] Rasool, Thakur & Nabi 2026, doi:10.1108/pmm-07-2026-0065.
   - Similarweb against Semrush on 50 repositories: significant differences in total visits, unique visitors, bounce rate and session duration.
   - Semrush estimated 3.88% more total visits; Similarweb estimated 4.09% more unique visitors.
5. **Vendor daily series may not show known shocks.** [PRE] Khosravi & Yoganarasimhan 2026, arXiv:2609.30481 (also doi:10.2139/ssrn.7514898).
   - Similarweb (via Dewey) daily organic referral clicks to 7,791 domains show no visible discontinuity around the Google disruption of 1 May 2024 or the Bing outage of 23 May 2024.
   - The authors model smoothing, cross-source leakage and calibration error as mechanisms. This is diagnostic evidence plus theory.
6. **SEO tools can read sections inside a domain.**
   - [PR] Vállez & Ventura 2020, doi:10.1016/j.acalib.2020.102171: library subdomains or subfolders of 20 university domains, read with Sistrix in the last week of April 2019, with Xovi as a control test.
   - [PR] Orduña-Malea & Aguillo 2022, doi:10.1162/qss_a_00199: 352 MDPI journals (journal-level units on one domain), Majestic link data, a single vendor.
7. **Vendor popularity lists disagree with each other and with server-side data.**
   - [PR] Scheitle et al. 2018, doi:10.1145/3278532.3278574.
   - [PR] Le Pochat et al. 2019, doi:10.14722/ndss.2019.23386.
   - [PR] Ruth et al. 2022, doi:10.1145/3517745.3561444: most top lists capture popularity poorly against Cloudflare data; CrUX is the most accurate.
   - All three work at domain level.
8. **Practitioner tests compare vendors with first-party data at whole-site level only.** [V]
   - Ahrefs 2022 (Tim Soulo; self-run by an interested party), https://ahrefs.com/blog/traffic-estimations-accuracy/
     - Sample: 1,635 sites, compared with US Search Console monthly traffic.
     - Median deviation: Ahrefs 49.52%, SEMrush 68.36%. Pearson correlation for Ahrefs: 0.76.
   - Promodo 2024, https://promodo.com/blog/data-accuracy-at-similarweb-ahrefs-and-semrush
     - Sample: 184 sites, compared with Search Console data for the first half of 2024.
     - Average error across all three tools: 50%. The text gives no per-tool figure.
   - Screaming Frog 2016 (Langridge), https://www.screamingfrog.co.uk/how-accurate-are-website-traffic-estimators/
     - Sample: 25 sites, compared with Google Analytics UK organic visits, February to April 2016.
     - Error in total visits: SimilarWeb +17%, Ahrefs -17%, SEMrush -30%.
   - None of these works below the site level, and none starts at a launch date.

**Claim 2 (sources cited by AI answer surfaces)**

9. **AI answer surfaces cite different sources from each other and from Google organic results.**
   - [PR] Kirsten et al. 2026, doi:10.18653/v1/2026.findings-acl.526 (arXiv:2510.11560): Google organic against five generative systems from three providers.
   - [PRE] Grossman et al. 2026, arXiv:2604.27790: Google, AI Overviews and Gemini on 11,500 queries; source-set Jaccard below 0.2; generative engines more likely to retrieve Google-owned content.
   - [PRE] Huang et al. 2026, arXiv:2603.16138: five systems including AI Overviews; Wikipedia over-represented and social media under-represented.
   - [PRE] Tannenbaum 2026, arXiv:2609.22655: ChatGPT, Copilot, Google and Perplexity on 15 prompts on 6 June 2026; mean pairwise URL Jaccard 0.0079.
   - [PRE] Xu, Iqbal & Montgomery 2026, arXiv:2605.14021: AI Overviews only; 55,393 queries in 19 topical categories, 13 March to 21 April 2026; nearly 30% of cited domains do not appear on the first results page.
   - The direction is consistent across sources.
10. **The mix of cited source types depends on topic, industry and query intent.**
    - [PRE] Lee 2026, doi:10.5281/zenodo.18653093: query intent by vertical, chi-squared(28) = 5,195, Cramér's V = 0.258.
    - [PRE] Nguyen et al. 2026, arXiv:2609.00319: ChatGPT, Perplexity and AI Overviews on mental-health questions; 15,942 citations; government, commercial health and academic sources each about 22%.
    - [PRE] Chen et al. 2025, arXiv:2509.08919: AI search favours earned media over brand-owned and social sources; Google's mix is more balanced.
    - [V] OtterlyAI 2026; Tinuiti 2026; Profound 2026; Yext 2025; Trendos 2026 (section 5).
    - The direction (industry matters) is consistent; magnitudes conflict (section 4).
11. **The access channel changes what is cited.** [PRE] Lee 2026: Reddit received zero citations through the API, against 8.9% to 15.6% of citations in web-UI responses. Hendricks 2026 flags that API answers are not consumer surfaces.
12. **The field is very recent and mostly unrefereed.**
    - Peer-reviewed anchors: Liu, Zhang & Liang 2023 (Findings EMNLP, doi:10.18653/v1/2023.findings-emnlp.467); Li & Sinnamon 2024 (ASIS&T, doi:10.1002/pra2.1021); Aggarwal et al. 2024 (KDD, doi:10.1145/3637528.3671900); Venkit et al. 2025 (FAccT, doi:10.1145/3715275.3732089); Kirsten et al. 2026.
    - Most industry-stratified work is 2025 to 2026 vendor material or preprints.

## 4. Where the literature disagrees

**Claim 1**
- **D1. Do vendors agree with each other?**
  - Reyes-Lillo et al. 2023 (authority scores, rho above 0.9) conclude the three tools "can be considered as providing reliable data".
  - Font-Julián et al. 2026 (keywords and URL traffic, low overlap) conclude that "tool selection significantly determines findings".
  - The constructs differ, which may reconcile the two, but no single design tests both.
- **D2. Which vendor is closest to first-party data?** All of these are [V] and use different baselines (Search Console against Google Analytics), periods and samples.
  - Ahrefs 2022 (self-run): Ahrefs is closer than SEMrush.
  - Screaming Frog 2016: SimilarWeb is closest on total volume; Ahrefs is best for high-traffic sites.
  - Promodo 2024: no tool is best.
- **D3. Do multi-vendor series agree on event effects?**
  - Zhao & Berman 2025 v4 (arXiv:2512.24968): about a 7% decline in weekly visits within 6 weeks after publishers blocked GenAI crawlers, whether measured by Similarweb, Semrush or Comscore (the Comscore estimate is imprecise).
  - Khosravi & Yoganarasimhan 2026 describe the same paper as finding that Semrush and Similarweb lead to "different findings" from Comscore.
  - Which version of Zhao & Berman they read is NOT VERIFIED.

**Claim 2**
- **D4. Owned against third-party sources.**
  - Chen et al. 2025: AI search overwhelmingly favours earned media.
  - Zatuchin 2026 (arXiv:2606.25787): 85.7% of brand-answer citations go to third-party sites.
  - Yext 2025 [V]: 86% of citations come from brand-managed sources (websites 44%, listings 42%).
  - Kumar 2026 (arXiv:2606.20065): about 78% of cited sources are corporate websites for brand prompts.
  - Likely drivers are query type (local or branded against unbranded), the classification scheme and the access channel. Kunal 2026, "Who Does AI Cite? Reconciling Conflicting Evidence..." (doi:10.2139/ssrn.7528060), addresses this directly, but its content is NOT VERIFIED (SSRN returned 403).
- **D5. Does Google rank predict AI citation?**
  - Lee 2026: Google rank is the strongest page-level predictor (cross-validated AUC 0.802).
  - Xu et al. 2026: about 30% of AI Overviews-cited domains are not on the first results page. Grossman et al. 2026: source-set Jaccard below 0.2.
  - Different units of analysis (page-level probability against set overlap) partly reconcile these.
- **D6. Reddit and UGC.**
  - Lee 2026: 0 citations through the API; 8.9% to 15.6% through the web UI.
  - Yext 2025: about 2% for Reddit-like sources after intent and location are accounted for.
  - Huang et al. 2026: social content is under-represented in AI summaries.

## 5. Closest prior work and verdicts

### Claim 1: PARTLY

Sub-verdicts:
- **(a) Two vendors on one section, followed from its go-live date: no record found by this search.** The nearest work has either multiple vendors without a launch date, or a launch date with a single vendor.
- **(b) Several sections of one domain read on both vendors on one day: close prior work exists.** The difference is the unit of analysis (URLs or subdomains rather than sections) or the vendor pair.

Closest records, nearest first:

1. **Font-Julián, Lopezosa, Orduña-Malea & Aguillo (2026)**, "Assessing discrepancies across SEO tools in the collection of scholarly web metrics", *Journal of Information Science*, doi:10.1177/01655515261445903 [PR]. Accepted manuscript: hdl 10251/236956. Data: doi:10.4995/dataset/10251/223019.
   - What it does: reads Ahrefs, SEMrush, Serpstat and Ubersuggest on the same day (5 July 2024) across tens of thousands of URLs within each of two domains. This is nearly Claim 1(b) at URL granularity.
   - How it differs: it aggregates to URLs and whole domains, not to site sections. The domains are mature, with no go-live date, and nothing is followed over time.
2. **Font-Julián, Orduña-Malea, Lopezosa & Aguillo (2025)**, "SEO Metrics for Enhanced Academic Research Visibility: A Comparative Study of Global and Country-Level Traffic", doi:10.31235/osf.io/j4ryx_v1 [PRE].
   - What it does: four tools including Ahrefs and Semrush give monthly global organic traffic for February to June 2024, collected retrospectively on 5 July 2024, plus June 2024 country-level traffic.
   - How it differs: the units are whole established domains with no section and no known start date; the series is backfilled, not followed forward.
3. **Vállez & Ventura (2020)**, "Analysis of the SEO visibility of university libraries and how they impact the web visibility of their universities", *Journal of Academic Librarianship*, doi:10.1016/j.acalib.2020.102171 [PR]. Open copy: hdl:2445/182744.
   - What it does: library subdomains and subfolders of 20 university domains are read with Sistrix in the last week of April 2019, with Xovi as a control. A within-domain subdomain keyword-share analysis also uses Sistrix.
   - How it differs:
     - The vendors are Sistrix and Xovi, not Ahrefs and Semrush.
     - The design has one section per domain across 20 domains.
     - The several-subdomains-of-one-domain analysis uses one vendor only.
     - The authors say of the two tools that "it only allows for the observation of similar trends", rather than offering a metric-by-metric comparison.
     - No single-day read is stated.
4. **Reyes-Lillo, Morales-Vargas & Rovira (2023)**, *El Profesional de la Información*, doi:10.3145/epi.2023.jul.03 [PR].
   - What it does: Moz, Semrush and Ahrefs authority scores for 3,151 domains, collected November to December 2022.
   - How it differs: the units are whole domains and the construct is an authority score; there are no sections and no time-from-launch.
5. **Zhao & Berman (2025, v4 April 2026)**, "Strategic Response of News Publishers to Generative AI", arXiv:2512.24968 [PRE].
   - What it does: Similarweb and Semrush daily or weekly series (plus Comscore) for news publisher domains, each used to estimate effects around dated crawler-blocking events.
   - How it differs: the units are domains, the vendor pair is Similarweb and Semrush, the dated event is a blocking decision rather than a section go-live, and the comparison is of estimated effects, not of the records themselves.

Also close, but further away:
- Rasool, Thakur & Nabi 2026 (doi:10.1108/pmm-07-2026-0065) [PR]: Similarweb against Semrush on 50 repository domains; the collection date is not stated in the abstract.
- Khosravi & Yoganarasimhan 2026 (arXiv:2609.30481) [PRE]: temporal validity of vendor series.
- Kostagiolas, Strzelecki, Banou & Lavranos 2020 (doi:10.1108/cc-01-2020-0002) [PR]: SEMrush and Ahrefs data on five STM publisher domains, April to May 2019; the abstract does not show a tool-against-tool comparison.
- Cahyono, Baita & Kamarudin 2024 (OpenAlex W7217943418) [PR, Indonesian]: Ahrefs against Majestic backlinks for 10 universities.
- Wilde 2026 (doi:10.5281/zenodo.21409586) [PRE]: Ahrefs and Semrush data collected on 14 July 2026 for seven agency domains, used for classification rather than vendor comparison.
- Jääskö 2018 (Theseus thesis, OpenAlex W2787170606) [PRE]: one new website followed for 9 months from its January 2017 launch, using Ahrefs among its tools; a single vendor.
- Cao, Koning & Nanda 2023 (*Management Science*, doi:10.1287/mnsc.2021.01740) [PR]: traffic from 6 months before to 12 months after a Product Hunt launch. Its vendor (Similarweb) is attributed in Khosravi & Yoganarasimhan's Table 1, not in the abstract; a single vendor.
- [V] Ahrefs 2022, Promodo 2024 and Screaming Frog 2016: whole-site level only.

### Claim 2: PARTLY

What is not new: comparing source types cited by several AI surfaces across industries. Several reports and preprints do this, all with author-chosen industries. What this search did not find is any study whose industry frame is the 11 GICS sectors, or S&P 500 constituents, or any other externally fixed classification. Doing this across all six named surfaces in one design is also found only in vendor reports (OtterlyAI, Tinuiti).

Closest records, nearest first:

1. **OtterlyAI (R. Tousseyn), "The AI Search Index: What ChatGPT, Gemini, Perplexity and Google Actually Cite in 17 Industries"**, vendor blog, last updated 8 September 2026, https://otterly.ai/blog/ai-search-index/ [V, interested party].
   - What it does: seven engines (ChatGPT, Gemini, Perplexity, Copilot, Google AI Mode, Claude, AI Overviews); 6,095,520 citations, July to August 2026, US only; ten source categories reported by industry.
   - How it differs:
     - Industries are author-chosen and their selection is not stated; only 16 of the 17 are named.
     - There is no external rule and no GICS.
     - The page contains internal inconsistencies (ten categories against nine; 17 industries against 16 named).
2. **Tinuiti, "Q1 2026 AI Citation Trends Report"**, https://tinuiti.com/research-insights/research/ai-citation-trends-report-q1-2026/ [V; built on the Profound tool].
   - What it does: seven platforms covering all six named surfaces plus Meta AI, October 2025 to January 2026; nine consumer categories; social, Reddit, YouTube and e-commerce source shares reported by platform and by category.
   - How it differs: the nine categories have no stated standard; the source taxonomy is partial; the prompt count is not stated.
3. **Hendricks (2026), "The Answer Index: what AI answer engines cite across eight industries"**, doi:10.5281/zenodo.22242102 [PRE; dataset with companion page].
   - What it does: a fixed panel of 480 questions (8 industries by 10 question types) sent to AI Overviews, ChatGPT, Perplexity and Gemini through a vendor API on 2026-09-01; 16,069 citations.
   - How it differs:
     - The industries are author-chosen ("eight instances, not a sample").
     - AI Mode and Copilot are explicitly excluded.
     - It uses API answers, not consumer surfaces.
     - Only a provider-owned against non-provider split is published; the 11-class breakdown is withheld after a 28% blind-audit disagreement.
4. **Chen, Wang, Chen & Koudas (2025), "Generative Engine Optimization: How to Dominate AI Search"**, arXiv:2509.08919 [PRE].
   - What it does: classifies sources cited by GPT web search, Perplexity, Claude and Gemini against Google as Brand, Earned or Social, across author-chosen consumer verticals (for example consumer electronics, automotive and software products), regions and languages.
   - How it differs: no AI Overviews, AI Mode or Copilot, and verticals are product categories, not a company-sector frame.
5. **Lee (2026), "Query Intent and Google Rank as Joint Predictors of AI Citation: A Multi-Platform Observational Study"**, doi:10.5281/zenodo.18653093 (v6, 27 April 2026; also doi:10.2139/ssrn.6240278) [PRE].
   - What it does: citation source-type distributions differ by vertical. The surfaces are ChatGPT, Claude, Perplexity and Gemini, with Google AI Mode added in a 10-vertical web-UI study.
   - How it differs: verticals are author-chosen (8 commercial verticals; then Technology, Health, Finance, Travel and others); there are no AI Overviews or Copilot; v6 never mentions GICS.

Also close:
- Profound 2026, "Enhanced citation categories" (8 January 2026), https://tryprofound.com/blog/enhanced-citation-categories [V]: 27 million citations; 15 verticals with no stated definition; Brand, Media, Institution and Social buckets by platform and industry.
- Yext 2025, https://yext.com/about/news-media/ai-citations-release [V, interested party]: 6.8 million citations from ChatGPT, Gemini and Perplexity, 1 July to 31 August 2025; four industries (retail, financial services, healthcare, food service) with no stated rationale.
- Trendos via Search Engine Journal, 27 August 2026 (sponsored), https://www.searchenginejournal.com/ai-search-citation-sources-trendos-spa/586289/ [V]: 107 million answers; three industries ("IT & solutions services", "consumer goods", "communication services") on ChatGPT, Perplexity, Gemini and AI Overviews. "Communication services" matches a GICS sector name, but no GICS frame is stated.
- Arshad 2026 (doi:10.5281/zenodo.22491737) [PRE]: four surfaces, six languages, five commercial verticals; measures brand citation, not source types.
- House 2026, AI Visibility Index Phase 2 dataset (doi:10.5281/zenodo.20048940) [PRE]: 2,729 businesses in 14 verticals and 4 metropolitan markets across ChatGPT, Claude, Gemini, Perplexity and AI Overviews; measures brand mention and recommendation, not cited-source types.
- Lee 2026b, "How AI Platforms Search: Fan-Out Query Behavior Across Intent Types, Verticals, and Platforms" (doi:10.5281/zenodo.19555392) [PRE]: ChatGPT, Gemini and Perplexity across 10 commercial verticals; measures fan-out queries, not cited-source types.
- Kumar & Palkhouski 2025 (arXiv:2509.10762) [PRE]: Brave, AI Overviews and Perplexity on B2B SaaS pages; reports vertical effects.
- Topic-stratified audits, not industry-stratified: Nguyen et al. 2026; Allaham & Diakopoulos 2026 (arXiv:2605.23684; ChatGPT, Copilot, Gemini, Perplexity; politics, health, environment); Xu et al. 2026; Huang et al. 2026; Li & Sinnamon 2024; Yang 2025 (news).

Adjacent (an S&P 500 frame, but not AI): deHaan, Lawrence & Litjens (*Management Science*, doi:10.1287/mnsc.2022.02174) [PR]. It studies 2.7 billion website visits following Google searches for S&P 500 ticker symbols. This shows the S&P 500 frame has been applied to search destinations in classic search.

## 6. Coverage gaps

- **DBLP outage.** CS proceedings were reached only through OpenAlex and Semantic Scholar. Fix: rerun DBLP from a browser session, or try later.
- **SSRN blocked.** Cook 2025 and Kunal 2026 are known only by title or snippet. Fix: institutional SSRN access, or ask the authors. Kunal 2026 is a review of conflicting evidence and should be read before submission.
- **Vendor and analyst reports.** Muck Rack, Semrush, Stacker, Similarweb, Conductor, BrightEdge and Search Atlas methods were not read at the source. Sell-side research, S&P Global, Bloomberg Intelligence, Gartner, Forrester and consulting reports were not searched; these communities routinely use GICS, so they are the most likely place for a GICS-framed AI-citation analysis to exist. Fix: targeted requests or licensed databases.
- **Non-English literature.** Chinese-language GEO literature (CNKI, Baidu-focused audits) is large and was not searched beyond arXiv. Japanese, Korean and Russian venues were not searched systematically. Fix: CNKI and regional indexes.
- **Theses.** ProQuest was not accessible; only theses indexed in OpenAlex (Theseus, DiVA) were seen.
- **Paywalled full texts not read:** Rasool et al. 2026, Kostagiolas et al. 2020, Cahyono et al. 2024, Garg et al. 2025, and Alby & Jäschke 2022. Fix: library access.
- **Practitioner case studies** (blogs, LinkedIn, X, conference talks) that track a new section in Ahrefs and Semrush from launch are not systematically indexable. Fix: practitioner surveys, or searches of industry conference programmes (BrightonSEO, SMX, MozCon).
- **Indexing lag.** arXiv items up to 2026-10-11 were seen, but OpenAlex and Semantic Scholar lag by weeks, and 2026 conference programmes (SIGIR, CIKM, WWW 2027 submissions) may hold unindexed work.
- **Google Scholar.** Only the first page of 7 queries was read, to avoid blocking.

## 7. Saturation assessment

**Claim 1: PARTIAL.**
- Criteria met:
  - Five vocabularies plus non-English terms were searched.
  - Late queries returned known records: c1_s2_01 returned 71 with 63 already known, and all Crossref title matches were already in the set.
  - Backward and forward chasing from the six closest records added background but no closer work.
  - Absent source types are named in section 6.
- Not met: DBLP was down; practitioner case studies and theses are not systematically reachable; the full texts of four paywalled papers were not read.

**Claim 2: PARTIAL.**
- Criteria met:
  - Five vocabularies were searched.
  - All 641 plus 252 OpenAlex records were title-screened, and all 284 S&P 500 / GICS records were title-screened.
  - Forward chasing (Semantic Scholar, 161 citing works) and backward chasing (a 2026 survey) converged on already-known records.
  - Sector-frame probes in every backend returned no GICS or S&P 500 framed AI-citation study.
- Not met:
  - The field is publishing weekly: 16 arXiv preprints on AI-search citation, GEO or AI-search audits were submitted between 2 September and 11 October 2026 (c2_ax01, c2_ax02).
  - SSRN content was blocked.
  - Analyst and sell-side reports, and Chinese-language work, were not searched.

## 8. NOT VERIFIED

| Item | What is known | What would settle it |
|---|---|---|
| Authority Hacker traffic-estimates case study (figures quoted secondhand: about 47 to 50 sites, six tools, 22.5% average discrepancy for Ahrefs) | URL now serves a landing page; the archive was not fetchable | An archived copy, or the authors |
| Collaborator.pro study (184 sites; Semrush average error 61.58%) | Secondhand only | The primary page |
| Backlinko 2023 (1,000 sites; 42% discrepancy between Semrush and Similarweb) | Secondhand, via Statvoo | The primary page |
| SparkToro traffic-estimate comparison | Secondhand only | The primary page |
| Sarıkaya 2021 thesis "Exploring Search Engine Optimization Factors" | Scholar snippet only | The full text at avesis.aybu.edu.tr |
| Cook 2025, "Mind the Invisibility Gap..." doi:10.2139/ssrn.5698748 | Scholar snippet mentions mentions by sector and the S&P 500; the sector frame and source-type content are unknown | SSRN access; this is the one item that could bear on the S&P 500 frame |
| Kunal 2026, "Who Does AI Cite?..." doi:10.2139/ssrn.7528060 | Title only | SSRN access |
| Search Engine Land 11-industry citation study (about 800 sites) | HTTP 403; industry names known secondhand (e.g. computers/electronics, telecom, food/beverage) suggest it is not GICS | Direct access |
| Muck Rack Generative Pulse (17 industries; about 25 million links; earned media about 84%) | Secondhand | generativepulse.ai report |
| Semrush AI Visibility Index 2025/2026; Stacker 2026 AI Trust Report; Similarweb 2026 GenAI Brand Visibility Index; Conductor 2026 benchmarks; Search Atlas 2025 | Secondhand | Primary reports |
| OtterlyAI "company-owned 53.7%" and Tinuiti "Reddit 24% of Perplexity citations" | From search summaries, not on the fetched pages | Primary pages or PDFs |
| "GEO Multi-Vertical Citation Tracker" (doi:10.5281/zenodo.19687957); "Breitenmessung KI-Sichtbarkeit 2026" (doi:10.5281/zenodo.23207495) | Titles only | Zenodo records |
| Rasool et al. 2026: whether both vendors were read on one day | Abstract silent | Full text |
| Kostagiolas et al. 2020: whether SEMrush and Ahrefs were compared against each other | Abstract silent | Full text |
| Khosravi & Yoganarasimhan's description of Zhao & Berman as divergent across sources | Contradicts Zhao & Berman v4 text | Check Zhao & Berman v1 to v3 |
| Vaughan & Yang 2013 data sources (Alexa, Compete?) | Abstract not retrievable; only a Semantic Scholar TLDR | Full text |

## 9. DO NOT ASSERT

1. **"No study has ever compared Ahrefs and Semrush on a site section from launch."** This search found none in the sources it could reach, and DBLP, SSRN and practitioner channels were partly or fully unavailable. Earn it with: "To our knowledge, based on a search of OpenAlex, Crossref, Semantic Scholar, arXiv and Google Scholar on 2026-10-15 (DBLP unavailable)...".
2. **"First cross-section of several sections of one domain read on two vendors on one day."** Font-Julián et al. 2026 read Ahrefs, SEMrush and two other tools across tens of thousands of URLs of one domain on one day. Vállez & Ventura 2020 read subdomains with Sistrix and Xovi. Earn it only by citing both and stating the difference: section-level aggregation, the Ahrefs and Semrush pair, and one domain.
3. **"First study of which source types AI answer engines cite across industries"** is false. OtterlyAI, Tinuiti, Profound, Yext, Hendricks 2026, Chen et al. 2025 and Lee 2026 do this with author-chosen industries. The defensible novelty is the externally fixed GICS / S&P 500 frame.
4. **"First to cover AI Overviews, AI Mode, ChatGPT, Perplexity, Gemini and Copilot together"** is false for grey literature (OtterlyAI 2026; Tinuiti 2026). It may hold for peer-reviewed or preprint literature, but that claim needs its own check.
5. **"No one has used GICS for AI citation analysis."** Analyst, sell-side, consulting and non-English sources were not searched, and Cook 2025 is unread. Earn it with access to those sources, or narrow the claim to the scholarly indexes searched.
6. **Any single figure for "the share of AI citations that are brand-owned" or "earned"** as a general fact. Estimates range from about 14% owned (Zatuchin 2026) to 86% brand-managed (Yext 2025, a vendor). Report the measurement conditions with every number.
7. **Any "vendor X is the most accurate" claim.** The evidence is [V], partly self-run (Ahrefs 2022), contradictory, and at whole-site level. It says nothing about sections or new sites.
8. **Any number marked NOT VERIFIED in section 8**, including Authority Hacker 22.5%, Collaborator.pro 61.58%, Backlinko 42%, Muck Rack 84%, OtterlyAI 53.7% and Tinuiti 24%.
9. **Causal explanations for why vendors disagree** (panels, filtering, bot handling). Font-Julián et al. state these cannot be confirmed because the methods are proprietary.
10. **Generalising Font-Julián et al.'s low-overlap findings to small or new sites.** The authors note the overlap may differ for less diverse websites, and only two large publishers were studied.

## How to rerun

```bash
# Universal backbone (log goes to stderr)
python3 ~/.claude/skills/research-paper/scripts/litsearch.py --query "Ahrefs Semrush" \
  --source openalex,crossref --limit 50 --format json --out c1_q01.json --verbose 2> c1_q01.log
# OpenAlex Boolean title+abstract filter (example c1_oa01); paginate with &page=N, not deep cursors
curl "https://api.openalex.org/works?filter=title_and_abstract.search:(ahrefs%20AND%20semrush)&per-page=100"
# arXiv (example c2_ax01)
curl 'https://export.arxiv.org/api/query?search_query=abs:%22AI+Overviews%22+OR+abs:%22AI+Mode%22&max_results=200&sortBy=submittedDate&sortOrder=descending'
# Semantic Scholar bulk Boolean search (example c2_s2_02)
curl 'https://api.semanticscholar.org/graph/v1/paper/search/bulk?query=(sector|industry|vertical)+(citations|cited)+("AI Overviews"|"answer engine"|Perplexity)&fields=title,year,externalIds'
# Forward citations
curl "https://api.openalex.org/works?filter=cites:W7162874630&sort=publication_date:desc"
curl "https://api.semanticscholar.org/graph/v1/paper/arXiv:2509.08919/citations?fields=title,year,abstract,externalIds&limit=500"
```

Hit counts will drift. The 2026 grey literature on Claim 2 grows weekly, so rerun the Claim 2 forward-citation and arXiv date-sorted queries immediately before submission.
