# Novelty search, 14 October 2026

The search behind the paper's novelty statement for Measurement 1 ("no comparison of two vendors' records of a single object followed from a known start date") and the related-work additions of version 5.2. Run through the public APIs of OpenAlex (which indexes arXiv preprints) and Crossref. arXiv's own API refused repeated requests that day (rate limit), so arXiv was reached through OpenAlex only.

## Queries and hits

| Database | Query | Total hits | Screened |
|---|---|---|---|
| OpenAlex | website traffic estimation third-party tools accuracy | 8,541 | top 25 by relevance |
| OpenAlex | Ahrefs Semrush comparison | 127 | top 25 |
| OpenAlex | SEO tools traffic estimates validity | 6,047 | top 25 |
| OpenAlex | Similarweb accuracy website traffic | 409 | top 25 |
| OpenAlex | keyword research tools search volume accuracy | 123,774 | top 25 |
| OpenAlex | web analytics estimates comparison Google Analytics third-party | 34,722 | top 25 |
| OpenAlex | search engine optimization tool measurement reliability | 65,210 | top 25 |
| OpenAlex | commercial SEO data providers disagreement | 1,217 | top 25 |
| OpenAlex | AI Overviews citations audit sources | 15,333 | top 25 |
| OpenAlex | generative search engine citation sources audit | 3,971 | top 25 |
| Crossref | Ahrefs Semrush traffic estimate comparison | 1,378,057 | top 30 |
| Crossref | SEO tool web traffic estimates discrepancy | 1,367,713 | top 30 |
| Crossref | third-party website traffic estimates accuracy | 1,017,723 | top 30 |
| Crossref | search engine optimization tools data reliability comparison | 6,173,707 | top 30 |

Raw results: `openalex_results.csv` (250 rows), `crossref_results.csv` (120 rows); full records of the relevant works: `relevant_records.json`. Screening was by title, then abstract, by the AI assistant that drafts the paper; it was not done by an independent person.

## Relevant works found, and how the paper now cites them

| Work | What it does | Where cited |
|---|---|---|
| Font-Julián, Lopezosa, Orduña-Malea & Aguillo 2026, *Journal of Information Science* 52(4) | compares Ahrefs, Semrush, Serpstat and Ubersuggest on organic keywords, search volumes and URL-level traffic for two academic publishers' domains; low overlap; tool choice determines findings | Section 2, tool validity; the closest prior comparison of SEO tools |
| Reyes-Lillo, Morales-Vargas & Rovira 2023, *El Profesional de la Información* | reliability of Moz, Semrush and Ahrefs domain-authority scores | Section 2, tool validity |
| Khosravi & Yoganarasimhan 2026, arXiv:2609.30481 | third-party traffic estimates (Similarweb, Semrush) can shrink, inflate or reverse estimated treatment effects | Section 2, tool validity |
| Kumar 2026, arXiv:2606.20065 | brand visibility across AI engines on 100,000+ prompt responses; corporate sites about 78% of citations; YouTube leads non-corporate sources | Section 2, AI answer surfaces |
| Romero Ramos et al. 2026, *Latitude* 2(24) | scoping review of 23 studies on how GEO presence and citation are measured | Section 2, AI answer surfaces |
| Schultheiß, Lewandowski, von Mach & Yagci 2023, *PeerJ Computer Science* 9 | samples queries and their volumes from keyword research tools for studies of search | Section 2, demand in users' own words |

None of them compares two vendors' records of one object followed from a known start date, and none reads a cross-section of sections within one domain; the novelty statement is limited to that.

## Limits

Ten OpenAlex and four Crossref queries, the top 25 or 30 results each by relevance; no citation chasing beyond the works' abstracts; one screener, not independent. A systematic review would go further.
