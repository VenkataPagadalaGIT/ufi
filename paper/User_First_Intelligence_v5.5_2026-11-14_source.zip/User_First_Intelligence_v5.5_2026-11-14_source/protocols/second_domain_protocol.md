# Measurement 1 on a second domain, and a second read date (protocol, written 14 October 2026)

Purpose: the independent measurement's largest single gain ("Measurement 1 rests on one domain and one vendor pair ...
run Measurement 1 on a second domain and read date"). Two studies, each a day of reading or less.

## Rules fixed before any reading

**Who reads.** A person reads the dashboards by hand. No browser assistant or script operates Ahrefs (its terms,
clause 4.4(j), prohibit automated use except through its API).

**Study A, second read date of the same twelve prefixes.** Re-read the twelve prefixes of `03_DATA/instrument_divergence_*_prefixes_2026-10-12.csv`
on one day at least seven days after 12 October 2026, current data (not historical), with the same modes as the first
read (Ahrefs Site Explorer, prefix mode, all locations, plus the US share from traffic by location; Semrush Domain
Overview, subfolder mode, US database). Record in `second_read_template.csv` with read_date set to that day.
Question: does the vendor ratio of each prefix keep its size and direction a week or more later?

**Study B, a second domain.**
1. Domain rule: the highest-ranked domain in the Tranco list of the reading day (https://tranco-list.eu, the default
   list) that is (a) a US-based commercial site, (b) has at least twelve top-level subfolders listed in its main
   navigation or its XML sitemap, and (c) is neither the author's employer nor a client of the author or of the agency
   whose subscription was used in Section 7. Record the list's ID and the domains skipped and why.
2. Prefix rule: the first twelve top-level subfolders in the domain's main navigation, in the order shown (or in the
   XML sitemap's order if the navigation has fewer than twelve). Do not look at either vendor before the twelve are
   written down.
3. Commit this file with the domain, the list ID and the twelve prefixes filled in below **before** reading; the
   commit time is the timestamp (a public deposit, for example OSF or a pushed commit, is stronger).
4. Read both instruments on the same day, same modes as Study A, into `second_domain_template.csv`.
5. Analysis, fixed now: run `04_ANALYSIS/instrument_divergence/release_data/analyze.py` and sections 3, 4 and 6 of
   `instrument_extra.py` on the new files unchanged. Report the ratio range, the median, the count below one, the
   ordering agreement (Spearman, Kendall, concordant pairs, size bands) and the dispersion, beside the first domain's.
   Prediction, stated before reading: the ratio is again prefix-specific (spread across the twelve of more than one
   order of magnitude) and the ordering agreement again high (Spearman above 0.7). Either can fail and will be
   reported as it comes.

## Filled in before reading (Study B)

- Reading day:
- Tranco list ID:
- Domains skipped, and why:
- Domain:
- Twelve prefixes, in order:
