"""Run the stamped reread_compare.py, unchanged, from the source bundle or the public release.

reread_compare.py is pinned by SHA-256 in protocols_manifest.txt (OpenTimestamps proof anchored in Bitcoin block
971,506), so it cannot be edited without breaking the stamp. It reads the twelve-prefix files from the research
project's layout (../../03_DATA/ from its own folder). This wrapper checks the script's hash against the manifest,
copies it and the released prefix files into a temporary folder laid out as the project is, and runs it there.

Usage: python3 reread_compare_anywhere.py [filled sheet, default reread_sheet.csv]
"""
import hashlib
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
script = HERE / "reread_compare.py"
pinned = dict((Path(p).name, h) for h, p in re.findall(r"^([0-9a-f]{64})\s+(\S+)$", (HERE / "protocols_manifest.txt").read_text(), re.M))
got = hashlib.sha256(script.read_bytes()).hexdigest()
if got != pinned["reread_compare.py"]:
    raise SystemExit("reread_compare.py does not match the stamped manifest")
names = ("ahrefs_prefixes_2026-10-12.csv", "semrush_prefixes_2026-10-12.csv")
for base in (HERE.parent, HERE.parent / "data", HERE.parents[1] / "03_DATA"):
    if all((base / n).exists() or (base / f"instrument_divergence_{n}").exists() for n in names):
        break
else:
    raise SystemExit("the twelve-prefix files were not found beside this folder")
sheet = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else HERE / "reread_sheet.csv"
with tempfile.TemporaryDirectory() as td:
    t = Path(td)
    (t / "03_DATA").mkdir()
    (t / "09_SUBMISSION/author_tasks").mkdir(parents=True)
    for n in names:
        src = base / n if (base / n).exists() else base / f"instrument_divergence_{n}"
        shutil.copy2(src, t / "03_DATA" / f"instrument_divergence_{n}")
    shutil.copy2(script, t / "09_SUBMISSION/author_tasks/reread_compare.py")
    print(f"reread_compare.py matches the stamped manifest (SHA-256 {got[:16]}...); prefix files from {base.name}/", flush=True)
    sys.exit(subprocess.run([sys.executable, str(t / "09_SUBMISSION/author_tasks/reread_compare.py"), str(sheet)]).returncode)
