# Measurement 1 replication protocols, as stamped

`second_domain_protocol.md` fixes, before any reading, two replications of Measurement 1: Study A (the same twelve
prefixes read again a week or more later) and Study B (twelve prefixes of a second domain chosen by rule). Its rules
were stamped with OpenTimestamps through `protocols_manifest.txt`, whose proof (`protocols_manifest.txt.ots`) attests
Bitcoin block 971,506, mined at 04:05 UTC on 15 October 2026. No Study A or Study B read had been made then, and none
has been made since: the templates are still empty.

To check the stamp: `ots verify protocols_manifest.txt.ots` (with a Bitcoin node), or compare the merkle root that
`ots info` prints with a block explorer; then compare each file's SHA-256 with the manifest. Every file the manifest
lists is here, under the same name, except two analysis scripts:

- `analyze.py` is the released one beside the data (unchanged since the stamp; same SHA-256).
- `instrument_extra.py` has gained sections 7 to 9 and the bundle and release layouts since the stamp. The stamped
  version is kept here as `instrument_extra_as_stamped.py` (SHA-256 as in the manifest). The protocol uses its
  sections 3, 4 and 6; on 15 October 2026 the stamped and current scripts printed identical sections 1 to 6 on the
  twelve-prefix data.

Reads must be made by a person: Ahrefs' and Semrush's terms restrict automated use of their web interfaces.
`reread_sheet.csv` and `reread_compare.py` are for the separate blind re-read of Table 4 and the day-37 row by someone
other than the author. The stamped `reread_compare.py` reads the project's folders, so outside the project run
`python3 reread_compare_anywhere.py <filled sheet>`, which checks the stamped script's hash and runs it unchanged.
