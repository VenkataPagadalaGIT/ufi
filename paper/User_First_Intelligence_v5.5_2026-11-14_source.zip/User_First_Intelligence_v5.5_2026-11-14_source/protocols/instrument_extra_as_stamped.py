"""Round 10 analyses for Measurement 1 (Section 5), on data already held. Not registered.

1. Growth per instrument month on month (Table 2): a constant level bias cancels in a within-instrument
   lift, so the question is whether the two instruments agree on growth.
2. The keyword-universe decomposition under both territory pairings.
3. Ordering agreement by size band across the twelve prefixes (Table 4).
4. The spread of the unmatched visits ratio: geometric SD and an illustrative 95% range.
5. Writes Tables 2, 3, 5 and 6 of the manuscript to 03_DATA as CSV, parsed from the manuscript, so the
   series exists as data and not only as text.
"""
import csv
import math
import re
import statistics
from itertools import combinations
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
if (ROOT / "03_DATA").is_dir():  # the research project
    MS = ROOT / "06_MANUSCRIPT/src/manuscript_v50.md"
    A_CSV = ROOT / "03_DATA/instrument_divergence_ahrefs_prefixes_2026-10-12.csv"
    S_CSV = ROOT / "03_DATA/instrument_divergence_semrush_prefixes_2026-10-12.csv"
    D = ROOT / "03_DATA"
else:  # the paper's source bundle: this folder, the manuscript one level up, the prefix data in ../data
    MS = HERE.parent / "manuscript_v50.md"
    A_CSV = HERE.parent / "data/ahrefs_prefixes_2026-10-12.csv"
    S_CSV = HERE.parent / "data/semrush_prefixes_2026-10-12.csv"
    D = HERE

# Table 2 (read 10 and 11 October 2026; Semrush completed months re-read unchanged on 13 October)
T2 = {"July": (3862, 100012, 103045), "August": (32281, 876153, 963937),
      "September": (150113, 1534362, 1765077), "October (run-rate)": (215577, 1610284, 1858297)}
print("== 1. Growth per instrument (Table 2)")
ms = list(T2)
for a, b in zip(ms, ms[1:]):
    ga = T2[b][0] / T2[a][0]
    gu = T2[b][1] / T2[a][1]
    gw = T2[b][2] / T2[a][2]
    print(f"  {a} -> {b}: Ahrefs worldwide {ga:.2f}x; Semrush US {gu:.2f}x; Semrush worldwide {gw:.2f}x; "
          f"Ahrefs growth / Semrush US growth {ga / gu:.2f}")

print("\n== 2. Decomposition of the October visits ratio")
v_us = 1610284 / 215577
k_us = 58586 / 29000
print(f"  Semrush US vs Ahrefs worldwide (10-11 Oct): visits {v_us:.2f}x = keywords {k_us:.2f}x x per-keyword {v_us / k_us:.2f}x; "
      f"keyword share of log ratio {math.log(k_us) / math.log(v_us):.0%}")
v_ww = 1858297 / 215577
k_ww = 92300 / 28900
print(f"  worldwide vs worldwide (visits 10-11 Oct; keywords 12 Oct): visits {v_ww:.2f}x = keywords {k_ww:.2f}x x per-keyword {v_ww / k_ww:.2f}x; "
      f"keyword share of log ratio {math.log(k_ww) / math.log(v_ww):.0%}")

print("\n== 3 and 4. Twelve prefixes (Table 4)")
A = {r["prefix"]: r for r in csv.DictReader(A_CSV.open())}
S = {r["prefix"]: r for r in csv.DictReader(S_CSV.open())}
P = list(A)
a = {p: float(A[p]["ahrefs_organic_traffic"]) for p in P}
s = {p: float(S[p]["semrush_organic_traffic_us"]) for p in P}
size = {p: math.sqrt(a[p] * s[p]) for p in P}
bands = {"within 3x": [], "3x to 10x": [], "over 10x": []}
for x, y in combinations(P, 2):
    gap = max(size[x], size[y]) / min(size[x], size[y])
    agree = (a[x] - a[y]) * (s[x] - s[y]) > 0
    key = "within 3x" if gap <= 3 else "3x to 10x" if gap <= 10 else "over 10x"
    bands[key].append(agree)
for k, v in bands.items():
    print(f"  pairs whose sizes (geometric mean of the two estimates) differ {k}: {sum(v)} of {len(v)} ordered alike")
lr = [math.log(s[p] / a[p]) for p in P]
m, sd = statistics.mean(lr), statistics.stdev(lr)
print(f"  unmatched ratio: geometric mean {math.exp(m):.2f}x, geometric SD {math.exp(sd):.2f}; "
      f"normal range on the log scale (describes these twelve; not a prediction) {math.exp(m - 1.96 * sd):.2f}x to {math.exp(m + 1.96 * sd):.2f}x")

print("\n== 5. Tables to CSV")
text = MS.read_text()
for n, name in ((2, "visits_by_month"), (3, "ai_overview_citation_by_month"), (5, "checkpoints"), (6, "intervals")):
    i = text.index(f"*Table {n}.")
    block = text[i:].split("\n\n")[1]
    rows = [[c.strip().replace("**", "") for c in ln.strip("|").split("|")] for ln in block.splitlines() if ln.startswith("|") and not ln.startswith("|---")]
    out = D / f"instrument_series_table{n}_{name}.csv"
    with out.open("w", newline="") as f:
        csv.writer(f).writerows(rows)
    print(f"  wrote {out.name}: {len(rows) - 1} rows")

# 6. Significance of the ordering agreement, and the pairs the two instruments order oppositely. (Until 14 October
# 2026 these lines were in the saved output without being printed by this file; they are now computed here.)
from scipy.stats import kendalltau, spearmanr
sp, kt = spearmanr([a[p] for p in P], [s[p] for p in P]), kendalltau([a[p] for p in P], [s[p] for p in P])
print(f"\n== 6. Ordering agreement significance: Spearman {sp.statistic:+.3f} (p={sp.pvalue:.1g}); Kendall {kt.statistic:+.3f} (p={kt.pvalue:.2g})")
for x, y in combinations(P, 2):
    if (a[x] - a[y]) * (s[x] - s[y]) < 0:
        ga, gs = max(a[x], a[y]) / min(a[x], a[y]), max(s[x], s[y]) / min(s[x], s[y])
        flag = "three or more times apart on one instrument" if max(ga, gs) >= 3 else "within 3x on both"
        print(f"  ordered oppositely: {x} vs {y}: Ahrefs {a[x]:,.0f} vs {a[y]:,.0f} ({ga:.1f}x); "
              f"Semrush {s[x]:,.0f} vs {s[y]:,.0f} ({gs:.1f}x); {flag}")
