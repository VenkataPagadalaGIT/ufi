"""Compare an independent re-read (reread_sheet.csv, filled in by someone other than the author) with the values the
paper reports. Run after the sheet is filled; prints each quantity's paper value, re-read value and relative
difference, and a summary. The re-reader should not see the paper's values before reading; this script is the only
place they meet.

Usage: python3 reread_compare.py [filled sheet, default reread_sheet.csv]
"""
import csv
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sheet = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "reread_sheet.csv"
A = {r["prefix"]: r for r in csv.DictReader((ROOT / "03_DATA/instrument_divergence_ahrefs_prefixes_2026-10-12.csv").open())}
S = {r["prefix"]: r for r in csv.DictReader((ROOT / "03_DATA/instrument_divergence_semrush_prefixes_2026-10-12.csv").open())}
DAY37 = {"ranking positions, all": 15830, "positions 1 to 3": 1874, "estimated visits (read from the daily chart)": 51800,
         "live referring domains": 19}


def paper_value(row):
    p, q = row["prefix"], row["quantity"]
    if row["table"] == "Table 5 day 37":
        return DAY37[q]
    if "Ahrefs" in row["where and when to read"]:
        key = {"organic keywords": "ahrefs_organic_keywords", "organic traffic (estimated monthly visits)": "ahrefs_organic_traffic",
               "United States share of traffic": "ahrefs_us_share"}[q]
        return float(A[p][key])
    key = {"organic traffic (estimated monthly visits)": "semrush_organic_traffic_us", "organic keywords": "semrush_organic_keywords_us"}[q]
    return float(S[p][key])


def num(x):
    x = str(x).replace(",", "").replace("%", "").strip()
    if not x:
        return None
    mult = 1.0
    if x[-1] in "KkMm":
        mult, x = (1e3 if x[-1] in "Kk" else 1e6), x[:-1]
    return float(x) * mult


done, diffs = 0, []
for row in csv.DictReader(sheet.open()):
    v = num(row["value read"])
    if v is None:
        continue
    pv = paper_value(row)
    if row["quantity"] == "United States share of traffic" and v > 1:
        v /= 100
    rel = (v - pv) / pv if pv else float("nan")
    diffs.append(abs(rel))
    done += 1
    print(f"{row['table']:15} {row['prefix']:22} {row['quantity'][:44]:44} paper {pv:>12,.3f}  re-read {v:>12,.3f}  {rel:+.1%}  (tool date {row['date the tool showed']})")
if done:
    diffs.sort()
    print(f"\n{done} quantities re-read; median absolute difference {diffs[len(diffs) // 2]:.1%}; within 1%: {sum(d <= 0.01 for d in diffs)}; within 5%: {sum(d <= 0.05 for d in diffs)}")
else:
    print("the sheet has no values yet")
