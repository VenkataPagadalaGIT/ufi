"""Version 5.1, fixes from the PhD examiner's final review (08_REVIEW/R10_phd_examiner.md, "Final review", F1 to F16).
F1 (title) and F3 (first pilot, scope of the agency's permission) are the author's decisions and are not applied here;
only F1's request to define "query discovery" in the body is.
New numbers: 04_ANALYSIS/review_demand/supplement_r10_output.txt, section 7 (the fifteen labels split 7 waiting,
8 appointments/queues/callbacks with 13,170 searches, 0 check-in); 04_ANALYSIS/ai_cited_sources/
make_tables_sector_surface_output.txt (company properties marked). New reference: Gottfried & Park 2025 (Pew Research
Center, read 13 October 2026).
"""
from pathlib import Path

HERE = Path(__file__).parent
P = HERE / "manuscript_v50.md"
s = P.read_text()


def rep(text, pairs):
    for a, b in pairs:
        n = text.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        text = text.replace(a, b)
    return text


s = rep(s, [
    # F2: the range is due to attribution only between +0.47 and +0.75; +0.78 used a different volume measure
    ("(Spearman +0.47 to +0.78, depending on how labels are assigned to branches)",
     "(Spearman +0.47 to +0.75, depending on how labels are attributed to branches)"),
    ("against +0.78 in an earlier computation that summed each label's volume over every level and assigned it to one branch, and +0.47 (p = 0.06) if each label's mentions go to the branch holding most of its nodes; the branch-level agreement therefore depends on how a label that occurs in several branches is attributed.",
     "and +0.47 (p = 0.06) if each label's mentions go to the branch holding most of its nodes; the branch-level agreement therefore depends on how a label that occurs in several branches is attributed. An earlier computation gave +0.78; it summed nested volumes over only the labels that reviews mention, which selects the volume measure on the outcome, and it is superseded."),
    ("(+0.47 to +0.78, depending on attribution)", "(+0.47 to +0.75, depending on attribution)"),
    ("branch agreement reported as +0.47 to +0.78 depending on how labels are attributed,",
     "branch agreement reported as +0.47 to +0.75 depending on how labels are attributed, replacing an earlier +0.78 computed on review-mentioned labels only,"),
    ("| M2 branch agreement | Spearman between branch shares, by attribution rule | +0.47 (modal), +0.75 (split), +0.78 (earlier) | `supplement_r10` |",
     "| M2 branch agreement | Spearman between branch shares on each branch's own volume, by attribution rule | +0.47 (modal), +0.75 (split) | `supplement_r10` |"),
    # F5: seven of the fifteen are waiting labels; eight name a remedy; none concerns check-in
    ("Labels for the remedies, appointments, queues and check-in, number 15 with 13,520 searches a month, among them one for scheduling a store appointment.",
     "Eight labels name a remedy, appointments, queues or callbacks, with 13,170 searches a month between them, most of it for appointment reminders; the label for scheduling a store appointment carries none, and no label concerns check-in."),
    # F6: Table 5 is an 11 October read, as its caption says
    ("and its trajectory over time is observable.", "and its trajectory over time can be read from each instrument's history."),
    ("; Table 5 states the source of each checkpoint value.",
     "; so are the checkpoint values in Table 5, read on 11 October from the Ahrefs daily series and from Brand Radar's stored answers, as its caption states."),
    ("it was not one of the fifteen-day checkpoints at which the full quantity set was captured, so it is reported on four quantities and not nine.",
     "it is not one of the fifteen-day checkpoints, and the 11 October read gives four of the nine quantities for it, not all nine."),
    ("\"n/r\" means not recorded: the quantity was not captured on that date, the daily series does not retain it, and it is not interpolated here.",
     "\"n/r\" means not recorded: the 11 October read gives no value for that date, and none is interpolated here."),
    # F7: script attribution
    ("except the spread and the size-banded agreement, which are printed by `instrument_extra.py`, prepared for release.",
     "except the p-value of the ordering correlation, the spread and the size-banded agreement, which are printed by `instrument_extra.py`, prepared for release."),
    ("the script for Section 5.5 is public, and those for Sections 6 and 7 are prepared for release (open item 3).",
     "the script for Section 5.5, `analyze.py`, is public; `instrument_extra.py`, which prints the further Measurement 1 statistics, and the scripts for Sections 6 and 7 are prepared for release (open item 3)."),
    # F8: ten rounds, nineteen references, title and conflicts statement
    ("and ran the nine review rounds,", "and ran the ten review rounds,"),
    ("**What has not been done, after nine rounds of AI-simulated review.**", "**What has not been done, after ten rounds of AI-simulated review.**"),
    ("This manuscript has been through nine rounds of AI-simulated adversarial review;", "This manuscript has been through ten rounds of AI-simulated adversarial review;"),
    ("stated the vendor's collection method for Measurement 3; and added eleven references.",
     "stated the vendor's collection method for Measurement 3; corrected the conflict-of-interest statement, which had described a business relationship with the agency that does not exist; changed the title to name the framework's purpose; and added Appendix D and the tables of cited sources by sector and surface (Appendix C). Versions 5.0 and 5.1 together added 19 references."),
    # F9: Appendix D coverage and script column
    ("Every quantity the paper reports, with its definition, its value here and the script that prints it.",
     "The principal quantities the paper reports, with their definitions, their values here and the script that prints each, or the table it is computed from."),
    ("*Table D1. Metrics, definitions, values in this paper and the scripts that print them.",
     "*Table D1. Metrics, definitions, values in this paper and the scripts that print them; \"arithmetic on\" names the table a value is computed from where no script prints it."),
    ("| 7.5x to 27.1x; 8.6x to 29.9x; 9.2x to 33.3x | Table 2 |", "| 7.5x to 27.1x; 8.6x to 29.9x; 9.2x to 33.3x | arithmetic on Table 2 |"),
    ("| 5.2 at 27.1x | Section 5.6 |", "| 5.2 at 27.1x | arithmetic on Table 2 |"),
    ("| 12.6% to 20.0% | Table 3 |", "| 12.6% to 20.0% | arithmetic on Table 3 |"),
    ("| Table C1 | `cross_sector` |", "| Table C1 | `cross_sector`, `cross_sector_sensitivity2` |"),
    # F10, F11: the protocol paragraph aligned with Section 13 and with the selection rule
    ("for the Content Gap Score, precision at k and nDCG at k [Järvelin & Kekäläinen 2002] of the score's ranking against top-ten presence on a frozen query set at day 37, read on both instruments, with volume-ranked and random rankings as comparisons and inter-annotator agreement reported as weighted kappa [Cohen 1968];",
     "for the Content Gap Score, the three classes of Section 13 (top by score, top by volume, bottom quartile of the score) compared on top-ten presence on a frozen query set at day 37, read on both instruments, with precision at k and nDCG at k [Järvelin & Kekäläinen 2002] of the score's ranking of entities against each entity's outcome, and inter-annotator agreement reported as weighted kappa [Cohen 1968];"),
    ("and for business disclosures, the correlation over quarters between what companies say about AI search and their citation shares.",
     "and for business disclosures, the correlation over quarters between what companies say about AI search and how often answers cite their domains on a prompt set fixed in advance, since the shares of Section 7 are partly fixed by the selection rule."),
    # F12: future work as further directions, with a source and without presuming the result
    ("**Where demand will be: surfaces that move.**",
     "### 13.1 Further directions\n\nThe three directions below do not test a claim made here; they follow the framework's premise to where demand is moving.\n\n**Where demand will be: surfaces that move.**"),
    ("and which of them a given community uses changes over time.",
     "and which of them people use changes over time: among US adults, use of TikTok rose from 21% in 2021 to 37% in 2025 and use of Reddit from 18% to 26% over the same four years, while use of YouTube and Facebook held steady [Gottfried & Park 2025]."),
    ("Companies now report how AI search affects them, on the record and with a date.",
     "Some companies, Costco among them, now report how AI search affects them, on the record and with a date."),
    ("Logging what those companies say about AI search each quarter, beside their citation shares, would show whether what companies report about AI answers moves with what the answers cite, and would let a content program anticipate a shift rather than read it afterwards.",
     "Logging what those companies say about AI search each quarter, beside how often AI answers cite their domains on a prompt set fixed in advance (the shares of Section 7 are partly fixed by the selection rule and cannot serve), would show whether what companies report about AI answers moves with what the answers cite, and would test whether a content program could anticipate a shift rather than read it afterwards."),
    # F14
    ("on ChatGPT, the two surfaces whose source mix differs most. Same source and rules as Table C3.*",
     "on ChatGPT, two contrasting surfaces. Same source and rules as Table C3.*"),
    # F13: company properties marked in Tables C3 and C4
    ("Properties of a sector's companies that were not entered as company domains (for example go.com, a Disney property) count as non-company, and",
     "Properties of a sector's companies that were not entered as company domains count as non-company and are marked with a dagger (†); the largest case is Communication Services, where the top source on all four Google views, youtube.com or google.com, belongs to Alphabet, which was entered as abc.xyz; and"),
    ("On Google's surfaces the top source is youtube.com or google.com in 38 of the 44 sector-by-view cells.",
     "On Google's surfaces the top source is youtube.com or google.com in 38 of the 44 sector-by-view cells, four of them Alphabet's own properties in Communication Services."),
    # F15: GEO cited, AEO labeled a practitioner term
    ("known as generative or answer engine optimization (GEO/AEO).",
     "known as generative engine optimization (GEO) [Aggarwal et al. 2024] or, in practitioner usage, answer engine optimization (AEO)."),
    # F1, in part: define query discovery in the body
    ("User First Intelligence has six components, the last of which, the Content Gap Score, is its output,",
     "Query discovery, as the term is used in the title, is the framework's first task: finding the questions people ask about an industry's entities, on any surface and in their own words, before deciding which of them an organization should answer. A content gap is one outcome of discovery, not its object; Measurement 2 (Section 6) is a first run of discovery on one surface, and Section 13 specifies the run across surfaces. User First Intelligence has six components, the last of which, the Content Gap Score, is its output,"),
    # new reference, alphabetical after Golebiewski
    ("Golebiewski, M., & boyd, d. (2018).", "GOLEBIEWSKI_ANCHOR"),
])
lines = s.split("\n")
i = next(k for k, x in enumerate(lines) if x.startswith("GOLEBIEWSKI_ANCHOR"))
lines[i] = lines[i].replace("GOLEBIEWSKI_ANCHOR", "Golebiewski, M., & boyd, d. (2018).")
lines[i + 1:i + 1] = ["", "Gottfried, J., & Park, E. (2025, November 20). *Americans' social media use 2025.* Pew Research Center. https://www.pewresearch.org/internet/2025/11/20/americans-social-media-use-2025/"]  # references are separated by blank lines
s = "\n".join(lines)

# F13: replace the two Appendix C tables with the script's marked output
out = (HERE.parents[1] / "04_ANALYSIS/ai_cited_sources/make_tables_sector_surface_output.txt").read_text().split("\n")
blocks, cur = [], []
for x in out:
    if x.startswith("|"):
        cur.append(x)
    elif cur:
        blocks.append(cur)
        cur = []
c3_new, c4_new = blocks[0], blocks[1]
lines = s.split("\n")
for cap, new in (("*Table C3.", c3_new), ("*Table C4.", c4_new)):
    caps = [k for k, x in enumerate(lines) if x.startswith(cap)]
    if len(caps) != 1:
        raise SystemExit(f"REFUSE: {len(caps)} captions start with {cap!r}")
    a = next(k for k in range(caps[0] + 1, len(lines)) if lines[k].startswith("|"))
    if lines[a] != new[0]:
        raise SystemExit(f"REFUSE: header after {cap!r} differs from the script's")
    b = a
    while b < len(lines) and lines[b].startswith("|"):
        b += 1
    if b - a != len(new):
        raise SystemExit(f"REFUSE: table at {head!r} has {b - a} rows, new has {len(new)}")
    lines[a:b] = new
s = "\n".join(lines)
P.write_text(s)

# The companion protocol: F2, F5, F7, F10, F11, F16
Q = HERE.parent / "UFI_Metrics_and_Evaluation_Protocol_v1.0.md"
q = rep(Q.read_text(), [
    ("runs from +0.47 to +0.78 depending on how a label is assigned to a branch.",
     "runs from +0.47 to +0.75 depending on how a label is attributed to a branch."),
    ("| Spearman $\\rho$ between branch shares of mentions and of volume, under a declared attribution rule | $+0.47$ ($p = 0.06$, modal branch), $+0.75$ (mentions split across branches, own branch volumes), $+0.78$ (earlier rule) |",
     "| Spearman $\\rho$ between branch shares of mentions and of each branch's own volume, under a declared attribution rule | $+0.47$ ($p = 0.06$, modal branch), $+0.75$ (mentions split across branches); an earlier $+0.78$ used summed volumes of review-mentioned labels only and is superseded |"),
    ("| Share gap | review share minus volume share per branch | carriers 66.8% against 14.9%; broadband 4.0% against 18.1% |",
     "| Share gap | review share minus volume share per branch, in percentage points | carriers $+51.9$ (66.8% against 14.9%); devices $-21.7$ (11.0% against 32.7%); broadband $-14.1$ (4.0% against 18.1%) |"),
    ("none about waiting in a store; 15 labels for appointments, queues and check-in (13,520 searches)",
     "none about waiting in a store; 8 labels for appointments, queues or callbacks (13,170 searches), none for check-in"),
    ("| $+0.94$ ($p < 0.001$), $\\tau = +0.82$, 60 of 66 pairs | `analyze.py` |",
     "| $+0.94$ ($p < 0.001$), $\\tau = +0.82$, 60 of 66 pairs | `analyze.py`; $p$ from `instrument_extra.py` |"),
    ("| Visits ratio, worldwide | both instruments worldwide | 8.6x to 29.9x | Table 2 |",
     "| Visits ratio, worldwide | both instruments worldwide | 8.6x to 29.9x | Table 2 (arithmetic) |"),
    ("| 9.2x to 33.3x | Table 2 |", "| 9.2x to 33.3x | Table 2 (arithmetic) |"),
    ("| 12.6% to 20.0% by month | Table 3 |", "| 12.6% to 20.0% by month | Table 3 (arithmetic) |"),
    ("branch $\\rho$ $+0.47$ to $+0.78$.", "branch $\\rho$ $+0.47$ to $+0.75$."),
    ("Freeze and hash a query set before launch; publish pages for classes ranked by the score, by volume and at random; measure top-ten presence on the frozen set at day 37 on both instruments. Report precision at $k$ and nDCG at $k$ [Järvelin & Kekäläinen 2002] of each ranking against the observed outcome,",
     "Freeze and hash a query set before launch; publish pages for the three classes of the manuscript's Section 13 (top class by score, top class by volume, a class in the bottom quartile of the score), with matched page counts; measure top-ten presence on the frozen set at day 37 on both instruments. Compare the classes on that outcome, and, at the level of entities, report precision at $k$ and nDCG at $k$ [Järvelin & Kekäläinen 2002] of the score's ranking of entities and of the volume ranking against each entity's observed outcome,"),
    ("*Comparison:* the score against volume ranking and random ranking, with parameters locked before collection.",
     "*Comparison:* the score against volume ranking, with parameters locked before collection; a random ranking of entities may be added as a floor."),
    ("and report the correlation, over quarters, between disclosure and the company's citation share by surface.",
     "and report the correlation, over quarters, between disclosure and the number of answers citing the company's domains, by surface, on a prompt set fixed in advance that does not depend on whether the answer names the company. The citation shares of Measurement 3 are partly fixed by its selection rule and cannot serve."),
])
Q.write_text(q)
print(f"{len(s.split()):,} words in the manuscript")
