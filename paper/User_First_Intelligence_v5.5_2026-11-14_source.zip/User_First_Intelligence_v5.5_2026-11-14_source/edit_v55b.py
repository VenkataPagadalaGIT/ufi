"""Version 5.5, second edit (14 November 2026). The mentor's name in the Acknowledgments, in the form the author gave on
14 November 2026 ("Dr. K. Rajasekhara Rao"), which is also the form KL University's pages use. The expanded first name in
earlier versions could not be confirmed from a public source. No title is added: the author gave "Vice-Chancellor", while
the university's Academic Council page (undated, read 14 November 2026) lists him as Pro Vice-Chancellor, and the
acknowledgment needs neither. Authorship is unchanged."""
import pathlib

p = pathlib.Path(__file__).with_name("manuscript_v50.md")
s = p.read_text()
a = "The author thanks Dr. Kurra Rajasekhara Rao, the author's doctoral mentor at KL University, for guidance."
b = "The author thanks Dr. K. Rajasekhara Rao, the author's doctoral mentor at KL University, for guidance."
if s.count(a) != 1:
    raise SystemExit(f"REFUSE: {s.count(a)} matches")
p.write_text(s.replace(a, b))
print("edit_v55b applied")
