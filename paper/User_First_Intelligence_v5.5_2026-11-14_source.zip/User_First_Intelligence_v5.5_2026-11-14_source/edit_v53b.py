"""Version 5.3, 31 October 2026: Study W (Section 6.2), a public request count against the vendor's modeled volume on
the 372 area codes, with its plan, predictions and analysis stamped before collection (02_DESIGN/wikipedia_demand_372.md;
04_ANALYSIS/wikipedia_demand/). Every number below is printed by wiki_demand_analysis.py (its output and
wiki_demand_headline.json are beside it). Edits: abstract, RQ2, contribution 2, the new subsection and Figure 7, the
threats, Section 13, Section 14 (release and AI use), the conclusion and Table D1."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


SEC62 = """### 6.2 A public request count against the vendor's volume on the 372 area codes

The reviews above are one first-party surface. A second comparison uses a demand signal that is tallied from request logs rather than estimated from a model, and that anyone can re-read to the digit. Every one of the 372 geographic area codes in service at the section's launch has an English Wikipedia article, alone or shared with the codes of its overlay complex (240 articles: 125 about one code, 102 about two, 13 about three to five), and the Wikimedia Foundation publishes for each article the monthly number of requests it classifies as human. The vendor side is the table frozen for Study R1 on 14 October 2026 (Section 13): for each code, the sum of DataForSEO monthly search volume over the pre-launch keywords that name it. The plan, four predictions and the analysis script were committed and stamped with OpenTimestamps on 31 October 2026, before any request count was collected and after four AI reviewers had read a draft of them (`02_DESIGN/wikipedia_demand_372.md`). The collection, 1,497 requests to two public APIs on the same day, read the article title, every redirect to it and every title on each code's resolution path, so that a request by any name for an article is counted once; no title was missing and none lacked data. The window is October 2024 to September 2025, the twelve months before the vendor exports.

**The two instruments agree roughly on the ranking and not at all on the magnitudes.** Across the 240 articles, the rank correlation between the vendor's summed volume and the year's requests is +0.45 (bootstrap 95% interval +0.34 to +0.54; Kendall's tau +0.30; Figure 7), and +0.54 (+0.45 to +0.62) between the number of matched keywords and requests. Prediction P1 (positive, with an interval excluding zero) held; P2 (a point estimate between +0.40 and +0.80, the band inside which Measurement 2's branch-level estimates fall) held at its boundary, because the interval crosses +0.40; P4 (every code covered by an article that names it) held. The magnitudes are another matter. Requests vary little across articles, a geometric standard deviation of 1.5 (7,989 to 120,065 in the year, 87.5% of articles between 15,000 and 50,000), while the vendor's summed volumes vary by a factor of 16.7 (50 to 3,704,650 searches a month), so monthly searches per monthly request run from 0.3 at the 10th percentile to 244 at the 90th (median 35), a geometric standard deviation of 14.5 against the 3.1 that Measurement 1 reports for the vendor pair across twelve prefixes (P3, held; the plan calls this bar lax, since it fails only if log requests track log volume at a Pearson correlation above about 0.9). Whatever the public count measures, it is not a scaled copy of the vendor's volume: the vendor's figure spreads the class across five orders of magnitude where the count spreads it across one.

![Figure 7. A public request count against the vendor's volume on the 372 area codes. Each marker is one English Wikipedia article (240): its requests per month, Wikimedia pageviews API, agent type user, October 2024 to September 2025, summed over the article's title and every redirect to it, against the DataForSEO monthly search volume summed over the codes the article covers, from the table frozen for Study R1. Filled squares are articles shared by several codes; both axes logarithmic. Data and scripts in the source bundle (`wikipedia_demand/`).](fig11_wikipedia.pdf)

**The ranking agreement holds under every pre-specified variation and is weaker among single-code articles.** Shifting the window a month earlier gives +0.45; the six months outside the Foundation's reclassification of automated traffic, +0.45; twelve times the median month, which removes single-month spikes (one article, for codes 327 and 870, had a month 4.6 times its median), +0.44; dropping the six articles that hold a code entering service after October 2025 or a code with no matched keyword, +0.46; the first two full months after the section's launch, +0.39 (+0.29 to +0.49), with the public count itself stable between the windows (+0.85). Counting an article's current title alone gives +0.32, because ten articles carry their current title only since January 2025 or later, renamed as overlay codes were added, and their former titles, now redirects, carry most of their requests (pooled, 9.3% of requests arrive through redirect titles; for the median article, 0.7%). Among the 125 articles about one code the correlation is +0.30 (+0.12 to +0.46): a shared article pools several codes' demand on both sides, which raises agreement.

**What this does and does not show.** A Wikipedia request and a keyword search are different acts joined by the search result page: how many searches become article visits depends on whether the engine answers the query in place and on which sources it cites, which varies by code, so the two readings are coupled rather than independent, and the dispersion cannot be attributed to either alone. Requests are worldwide where the volume is the US database; the Foundation's human and automated split uses rules it revised inside the window; and the query universe behind the vendor side inherits Study R1's selection on the carriers' rankings. Within those limits the result has the same shape as Section 6.1's: on the same 372 entities, a free public count and a commercial volume model agree only roughly on which carry more demand (+0.45, against +0.47 to +0.75 for the taxonomy's branches) and size them very differently. The exploratory correlation between the Content Gap Score and the count, +0.41, is not a test of the score, which contains the vendor's volume. The plan was written, stamped and run by AI agents (Section 14). Everything here is public data: the per-title monthly counts, the API responses they came from, the per-article and per-code tables and the scripts are released, and the analysis reruns from them.

"""

rep([
    # abstract
    ("on links that two blind AI annotators judged about two-thirds correct. In one vendor's index of AI answers",
     "on links that two blind AI annotators judged about two-thirds correct. On the 372 area codes the section covers, a public count of requests for each code's Wikipedia article and the vendor's keyword volume agreed roughly on the ranking (Spearman +0.45, bootstrap 95% interval +0.34 to +0.54, over 240 articles) and not on the magnitudes (searches per request from 0.3 to 244 between the 10th and 90th percentiles), in a comparison whose predictions and analysis were stamped before collection. In one vendor's index of AI answers"),
    # research question and contribution
    ("RQ2: do the topics people raise in their own words, in reviews, rank as keyword volume ranks them?",
     "RQ2: do other observations of demand, people's own words in reviews and a public count of requests for the same entities, rank topics and entities as keyword volume ranks them?"),
    ("2. **Measurement 2, reviews against keyword volume** (Section 6; RQ2), bearing on the first-party demand surfaces. On 37,193 business reviews linked to a 42,994-node keyword taxonomy, the two demand signals agree only roughly on the taxonomy's branches, size them very differently, and barely agree on topics, most for complaints. It is one surface in one industry, not the multi-surface study of Section 13.",
     "2. **Measurement 2, reviews and a public count against keyword volume** (Section 6; RQ2), bearing on the demand surfaces. On 37,193 business reviews linked to a 42,994-node keyword taxonomy, the two demand signals agree only roughly on the taxonomy's branches, size them very differently, and barely agree on topics, most for complaints (Section 6.1). On the 372 area codes, a public count of requests for each code's Wikipedia article and the vendor's volume agree roughly on the ranking (+0.45 over 240 articles) and not on the magnitudes, in a comparison stamped before collection (Section 6.2). These are two surfaces in one industry, not the multi-surface study of Section 13."),
    # the subsection
    ("## 7 Measurement 3: what AI answers cite, across eleven sectors and eight answer surfaces\n",
     SEC62 + "## 7 Measurement 3: what AI answers cite, across eleven sectors and eight answer surfaces\n"),
    # threats
    ("No person has checked the links or the waiting matches, and a review is a different construct from an information need.",
     "No person has checked the links or the waiting matches, and a review is a different construct from an information need. Section 6.2's public count is coupled to search demand through the result page, worldwide where the vendor's volume is US-only, and split from automated traffic by rules the Foundation revised inside the window; its plan was written, stamped and run by AI agents, and the author had not read it when it was stamped."),
    # Section 13
    ("Measurement 2 (Section 6) is a first run on one surface; the study specified here extends it.",
     "Measurement 2 (Section 6) is a first run on one first-party surface, with a public count as a second (Section 6.2); the study specified here extends it."),
    # Section 14: release and AI use
    ("the licensed review export itself is not released.",
     "the licensed review export itself is not released. For Section 6.2, everything is public data and is released: the plan with its stamped manifest, the per-title monthly request counts and the API responses they came from, the per-article and per-code tables and the scripts; the per-article sums of vendor volume are derived aggregates, and no keyword, per-keyword volume or per-code score is released."),
    ("and two more the screened sample of Section 1's count of works.",
     "and two more the screened sample of Section 1's count of works. Section 6.2's plan, predictions, scripts and collection were made by AI agents under the author's standing instruction to complete what could be completed without the author; four further agents reviewed the plan before it was stamped, and the author had not read it when it was stamped."),
    # conclusion
    ("with 622 searches a month.\n",
     "with 622 searches a month. On the 372 area codes, a public count of requests for each code's Wikipedia article agreed with the vendor's volume roughly on the ranking (+0.45 over 240 articles) and not at all on magnitudes, the count spreading the class across a factor of 1.5 and the vendor's volume across a factor of 16.7, in a comparison whose predictions were stamped before its data were read.\n"),
    # Table D1
    ("| M2 waiting-match precision | sampled waiting matches judged complaints about waiting; share in store | 83% to 85%, kappa 0.93; about 90% in store | `r2_link_check` |\n",
     "| M2 waiting-match precision | sampled waiting matches judged complaints about waiting; share in store | 83% to 85%, kappa 0.93; about 90% in store | `r2_link_check` |\n"
     "| M2 public count agreement | Spearman between the vendor's summed volume and Wikipedia requests per article (240 articles, October 2024 to September 2025), bootstrap 95% interval; the matched keyword count against requests | +0.45 (+0.34 to +0.54); +0.54 (+0.45 to +0.62) | `wiki_demand_analysis` |\n"
     "| M2 public count dispersion | monthly searches per monthly request across articles: median; 10th and 90th percentiles; geometric SD | 35; 0.3 to 244; 14.5 | `wiki_demand_analysis` |\n"
     "| M2 public count predictions | P1 to P4 as stamped before collection | P1, P3 and P4 held; P2 held at its boundary | `wiki_demand_analysis` |\n"),
])
P.write_text(s)
print(f"{len(s.split()):,} words")
