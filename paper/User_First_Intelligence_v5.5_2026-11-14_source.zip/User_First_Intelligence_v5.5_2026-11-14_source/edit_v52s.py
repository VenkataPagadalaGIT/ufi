"""Version 5.2, 15 October 2026: the stakes count screened (final blind paper-measure runs: "the evidence that the
field needs this answer now is an unscreened keyword count"), and the third independent reproduction reported.

Screen: a random sample of 120 of the 456 works (seed 20261015, stakes_screen_sample.py), judged from title and
abstract by two blind AI annotators on different models under a fixed protocol (stakes_screen_protocol.md), analysed
by stakes_screen_check.py, committed before either annotator's judgments existed (commit 5c5807e).
Third reproduction: 08_REVIEW/reproduction_v5.2_run3_2026-10-15/ (1,696 values; 1,555 matched, 7 differed, 134 need
withheld data; the 7 are corrected by edit_v52r.py and a regenerated table file)."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("and 110 in 2026 to mid-October, and 86% name only one of the three; the list is a keyword match, not screened for whether a work uses a tool's figures as data, so this suggests, without proving, reliance on a single vendor's figures (`vendor_reliance.py`, released with the paper's data).",
     "and 110 in 2026 to mid-October. Screened from title and abstract by two blind AI annotators, a random sample of 120 of them gives 82% to 87% that use a vendor's figures as data (Wilson 95% intervals 75% to 92%; Cohen's kappa 0.63), and of those, 87% to 88% use one vendor's figures only, while five to seven compare vendors (`vendor_reliance.py` and `stakes_screen_check.py`, released with the paper's data)."),
    ("| Stakes | works in OpenAlex naming Ahrefs, Semrush or Similarweb in title or abstract; share naming only one | 456; 86% (read 14 October 2026) | `vendor_reliance` |",
     "| Stakes | works in OpenAlex naming Ahrefs, Semrush or Similarweb in title or abstract (read 14 October 2026); in a screened random sample of 120, the share using a vendor's figures as data, and of those, the share using one vendor only | 456; 82% to 87% (kappa 0.63); 87% to 88% | `vendor_reliance`, `stakes_screen_check` |"),
    ("two further agents, on different models and blind to the analysis, annotated the samples of Section 6's link check.",
     "two further agents, on different models and blind to the analysis, annotated the samples of Section 6's link check, and two more the screened sample of Section 1's count of works."),
    ("A separate agent reproduced the source bundle twice in a clean folder on 15 October 2026. In the second, fuller run, of 1,056 numbers the paper quotes, 899 matched what the released scripts and data give or what the agent recomputed from them, one differed (Table 2's day count, now corrected) and 156 could not be checked because they need withheld data; the paper builds from the bundle (`08_REVIEW/reproduction_v5.2_2026-10-15/` and `reproduction_v5.2_run2_2026-10-15/`).",
     "Separate agents reproduced the source bundle three times in clean folders on 15 October 2026. In the third, of 1,696 values the paper quotes, 1,555 matched what the released scripts and data give or what the agent recomputed from them, seven differed (a correlation and an interval end rounded twice, +0.19 and +0.29 for +0.18 and +0.28, and a stale cell in a released table; all are corrected) and 134 could not be checked because they need withheld data; the paper builds from the bundle (`08_REVIEW/reproduction_v5.2_run3_2026-10-15/`, with the two earlier runs beside it)."),
    ("the count of works naming the vendor tools is 456, not 459 (three works were counted twice);",
     "the count of works naming the vendor tools is 456, not 459 (three works were counted twice), and a screened sample now measures how many use a vendor's figures; the topic-level correlation of Measurement 2 is +0.18, not +0.19, which had rounded a printed +0.185 a second time;"),
])
P.write_text(s)
print(f"{len(s.split()):,} words")
