"""Version 5.5 (14 November 2026). Two things.

1. The author's determination on organizational permission, in the author's words to the assistant on 14 November 2026:
   no approval of the employer is needed, because the paper uses none of its first-party data and does not name it.
   The paragraphs that made that approval, a public release, an ethics determination and the removal of old public
   copies conditions of submission are replaced by a statement of the determination and of what is open at posting.
   Nothing is removed from the paper's evidence. The data and scripts are posted with the preprint as ancillary files,
   so "prepared for release" becomes "in the source bundle".
2. Defects found by the blind measurements of version 5.4 (three runs, 14 November): a wrong cross-reference in
   Section 7.7, "441-page" for 434 in Section 10.1, a positioning sentence that overreached, Study R1 not named in
   Section 13, +0.91 not marked post hoc in the abstract, the linker's filter not stated in Section 6.1, and a project
   path in the text. (The reference list's broken tail is fixed in build_tex.py.)

Each replacement must match exactly once and must not already be applied.
"""
import pathlib

p = pathlib.Path(__file__).with_name("manuscript_v50.md")
s = p.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


def rep_par(prefix, new, must):
    """Replace the one paragraph (one line) that starts with prefix and contains every string in must."""
    global s
    lines = s.split("\n")
    hits = [i for i, l in enumerate(lines) if l.startswith(prefix)]
    if len(hits) != 1:
        raise SystemExit(f"REFUSE: {len(hits)} paragraphs start with {prefix!r}")
    old = lines[hits[0]]
    for m in must:
        if m not in old:
            raise SystemExit(f"REFUSE: paragraph {prefix!r} lacks {m[:80]!r} (already applied or changed)")
    lines[hits[0]] = new
    s = "\n".join(lines)


rep([
    ("Manuscript version 5.4, 14 November 2026.", "Manuscript version 5.5, 14 November 2026."),
    # abstract: the top of the range is a post hoc restriction
    ("agree on branches to a degree that depends on attribution and link quality (+0.47 to +0.91), while sizing them very differently.",
     "agree on branches to a degree that depends on attribution and link quality (+0.47 to +0.75 on all links, up to +0.91 on multi-word labels, post hoc), while sizing them very differently."),
    # first mention of the source bundle says where it is
    ("(`vendor_reliance.py` and `stakes_screen_check.py`, in the source bundle).",
     "(`vendor_reliance.py` and `stakes_screen_check.py`, in the source bundle, which is posted with this preprint as its ancillary files)."),
    # positioning: the cross-section is a comparison of tools at one time, like the prior studies; what differs is the unit
    ("This paper does none of these: it has no ground truth, and it holds the site fixed. What it adds is a reading of two vendors on an object both observed from zero, and a cross-section of twelve sections of one domain on one day, which separates disagreement about a site from disagreement about a section of it.",
     "This paper has no ground truth and does not compare across sites. Its cross-section is, like the last of those, a comparison of two tools at one time; what differs is the unit, twelve sections of one domain, which separates disagreement about a site from disagreement about a section of it. It adds a reading of two vendors on a section both observed from zero, made in a single retrospective read."),
    ("or `instrument_extra.py`, prepared for release, which prints", "or `instrument_extra.py`, in the source bundle, which prints"),
    # Section 6.1: which labels the linker can match
    ("with the released exact-match linker (`TokenLinker`), so every attribution is auditable from the label. The taxonomy repeats",
     "with the released exact-match linker (`TokenLinker`), so every attribution is auditable from the label. A label is linkable if it has at least two words or at least six characters and is not one of ten generic terms the script lists (among them \"phone\", \"store\", \"service\" and \"internet\"). The taxonomy repeats"),
    ("the per-article and per-code tables and the scripts are in the source bundle and prepared for release, and the analysis reruns from them.",
     "the per-article and per-code tables and the scripts are in the source bundle, and the analysis reruns from them."),
    ("from a hand-built list prepared for release with the design file (Section 14)", "from a hand-built list in the source bundle beside the design file (Section 14)"),
    ("against 77% for surface and 14% for sector in Section 7.5.", "against 77% for surface and 14% for sector in Section 7.3."),
    ("failed to export and is missing). These are answer-level rows",
     "failed to export and is missing; the collection's ledger of files, row counts and checksums is in the source bundle). These are answer-level rows"),
    ("A 441-page section entering an index does not grow linearly.", "A section of 434 pages entering an index does not grow linearly."),
    ("**A retrospective test of the score on this deployment, fixed before its outcomes were read.**",
     "**A retrospective test of the score on this deployment (Study R1), fixed before its outcomes were read.**"),
    ("was read for any code (`02_DESIGN/framework_retro_test_381.md` and its manifest);",
     "was read for any code (the plan names the website and is held back; the manifest of its files' digests and its proof are in `framework_test_r1/` in the source bundle);"),
    ("The series in Tables 2, 3, 5 and 6 are kept as CSV files with the paper's data, prepared for release with the Section 7 artifacts (open item 2); they are transcribed from those tables,",
     "The series in Tables 2, 3, 5 and 6 are in the source bundle as CSV files; they are transcribed from those tables,"),
    ("not to treat that confirmation as a precondition, so it is not among the open items below, and a reader should weigh that decision.",
     "not to treat that confirmation as a precondition, and a reader should weigh that decision."),
    ("the full version history is in a changelog included with the paper's source files.", "the full version history is in the changelog in the source bundle."),
    ("(Claude Opus 5, Opus 5.5, Fable 5 and Fable 5.1, in October and November 2026)", "(Claude Opus 5, Opus 5.5, Fable 5, Fable 5.1 and Fable 5.2, in October and November 2026)"),
    ("measured the manuscript against a fixed rubric, and versions 5.2 and 5.3 respond to that measurement;",
     "measured the manuscript against a fixed rubric, and versions 5.2, 5.3 and 5.5 respond to its measurements;"),
    ("and Appendix F transcribes the author's inventory.",
     "and Appendix F transcribes the author's inventory. This version's statement on organizational permission is the author's determination, given to the assistant in the author's words on 14 November 2026; the assistant drafted the paragraph."),
    ("and the scripts for Sections 6 and 7 are prepared for release (open item 2), with", "and the scripts for Sections 6 and 7 are in the source bundle, with"),
    ("(`08_REVIEW/reproduction_v5.3_run5_2026-11-03/`, with the four earlier runs beside it)", "(the reports of all five runs are in the source bundle)"),
    ("(not peer review), is in the changelog released with the paper's source files.", "(not peer review), is in the changelog in the source bundle."),
    ("the same unsupported assertion reappeared in the public versions 4.6 to 4.8 and is withdrawn (open item 4).",
     "the same unsupported assertion reappeared in the public versions 4.6 to 4.8 and is withdrawn; the public copies had not been removed when version 5.5 was built. Versions 4.9 to 5.4 said that publication needed the organization's approval and that the manuscript would not be submitted until that approval, a public release of the Section 7 artifacts, an ethics determination and the removal of the public copies were in hand; version 5.5 replaces this with the author's determination that the approval is not needed, posts the artifacts with the preprint, and states the rest as open (Section 14)."),
    ("*User First Intelligence: Metrics and Evaluation Protocol*, distributed with the source files,", "*User First Intelligence: Metrics and Evaluation Protocol*, in the source bundle,"),
    ("Here the twelve-prefix reads and `analyze.py` are public, and the other read values and scripts are in the source bundle pending release (Section 14).",
     "Here the twelve-prefix reads and `analyze.py` are in the public repository, and the other read values and scripts are in the source bundle (Section 14)."),
])

rep_par("**Data released with this version.**",
        "**Data released with this version.** The twelve-prefix cross-section (Table 4) is released as two CSV files, one per instrument, each row carrying the prefix, the figures read, the read date and the read method, at `data/instrument_divergence/` in the repository named above. Everything else this paragraph names is in the source bundle, which is posted with this preprint as its ancillary files and carries no licensed rows, review text or reviewer names; it is not in the repository at the cited commit, and it has no DOI. For Section 7, the bundle holds the design file with its amendments, the 109-company list with its source, the company-property list, the report-URL file, the analysis, sensitivity and figure scripts, the per-cell sizes, the per-sector and per-surface aggregates, the ranked top-ten non-company domain names and the checksums of the raw exports. The raw vendor exports are not redistributed, because the vendor's terms restrict use of its data; a Brand Radar subscriber can re-export them with the recorded settings, which reproduces the procedure and not the figures, because the index refreshes. For Section 6, the bundle holds the per-label counts behind its correlations, anonymized (no label names; volumes as ranks, which is all a rank correlation uses), the link-check judgments and the annotators' protocol, and `m2_from_counts.py` recomputes from them every Section 6 correlation, branch share and interval that does not need the review text; the licensed review export itself is not released. For Section 6.2, everything is public data and is in the bundle: the plan with its stamped manifest, the per-title monthly request counts and the API responses they came from, the per-article and per-code tables and the scripts; the per-article sums of vendor volume are derived aggregates, and no keyword, per-keyword volume or per-code score is released. For Section 7.7, the bundle holds the counts per country and view, the scripts and the collection's ledger of export files with their row counts and checksums; the answer-level rows are not redistributed.",
        ["**are not yet public**", "prepared for release alongside; the answer-level rows are not redistributed."])

rep_par("**Organizational permission.**",
        "**Organizational permission.** The organization that operates the section has not been asked to approve this paper and has not approved it. The author's determination is that its approval is not needed, on two grounds a reader can check against the paper. First, the paper uses none of the organization's own data: none of its analytics, logs, crawl output or internal databases (*What is not released*, above); every figure about the section is a commercial vendor's estimate for public URL prefixes, which any subscriber can re-read, or a count of the section's public pages. Second, the organization is not named. This determination is the author's alone: the organization has not confirmed it, and no legal review of it is reported. What does come from the author's employment is marked where it appears: the publishing history in Section 3, the account of the deployment in Section 11, and the cost figures of Table 7, which the author reconstructed from project records. The twelve-prefix reads of Table 4 have been in the public repository since 12 October 2026. Not naming the organization does not make it unidentifiable: the prefixes in Table 4 and the author-independence statement in Section 12 allow a reader with access to the same instruments to identify it, and that statement is kept because the disclosure is required. The name is withheld; the identity is not claimed to be concealed.",
        ["needs the approval of the organization", "No written approval has been received."])

rep_par("**Open items before submission.**",
        "**Matters open at posting.** This preprint is posted with four matters unsettled, each stated where it arises: no institutional ethics determination is reported for the analysis of public reviews in Section 6; neither vendor has confirmed that reads and exports made through a browser assistant fall within its terms, and the agency's permission is not established to cover the Section 7.7 exports; earlier manuscript copies in the public repository that assert the organization's approval or name it had not been removed when this version was built; and no person other than the author has re-read a dashboard figure (below). Versions 4.9 to 5.4 made the first and third of these, with the organization's approval and a public release of the Section 7 artifacts, conditions of submission; the author has since decided to post with them stated instead (Appendix A).",
        ["The manuscript is not submitted anywhere, including a preprint server"])

for stale in ("open item", "prepared for release", "pending release", "not yet public", "needs the approval", "is not submitted anywhere"):
    if stale in s:
        raise SystemExit(f"REFUSE: stale wording survives: {stale!r}")
if "—" in s:
    raise SystemExit("REFUSE: em dash")
p.write_text(s)
print("edit_v55a applied")
