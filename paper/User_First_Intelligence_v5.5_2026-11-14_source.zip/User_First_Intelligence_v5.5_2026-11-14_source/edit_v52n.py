"""Version 5.2, 15 October 2026: responses to the three blind paper-measure runs on the packaged v5.2 (median 6.8;
06_MANUSCRIPT/measurements/), the AI-simulated editorial gate at Information Processing & Management
(08_REVIEW/R11_editorial_IPM.md) and the second independent reproduction (08_REVIEW/reproduction_v5.2_run2_2026-10-15/).

- Abstract: the age test's low power, the ordering agreement within a factor of three, and that the annotators are AI.
- Section 1.2: the three research questions stated.
- Section 2: three works the reviews found missing, each verified (Rasool, Thakur & Nabi 2026 on Crossref; Zhao &
  Berman 2025 v4 on arXiv, full text; Kakimov et al. 2026 on PMLR), and a closest-work paragraph per measurement.
- Section 3: the 52 hubs traced to the released code list.
- Section 5.5: "does not predict" narrowed to what +0.17 and +0.52 support, with p-values (instrument_extra.py section 9).
- Sections 5.6 and 15: "right in direction" replaced by agreement with the other instrument (no ground truth).
- Table 2: the days-live column sums to 78 (days 0 to 77), not 77.
- Section 6: label-level p-values dropped (labels are not independent), multiplicity stated, anonymized counts noted.
- Section 7.2 and 14: amendment A4 and Semrush's terms disclosed; the permission placeholders restated as a status.
- Section 13: Study R1's claim made exact about which per-page information had been seen; dated amendment cited.
- Section 14: what is released for Section 6; the second reproduction.
- Appendix A condensed to the corrections themselves (the narrative is in the changelog).
- References: three preprints replaced by their peer-reviewed versions (AIES 2026, ICLR 2025, Proc. ASIS&T 61),
  each checked on the publisher's page or Crossref; three references added.
"""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()
if "Three questions organize the measurements." in s:
    raise SystemExit("REFUSE: already applied")


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    # abstract
    ("with no detectable relationship to section age (Spearman −0.11), while the platforms agreed on which section is larger in 60 of 66 pairs.",
     "with no detectable relationship to section age (Spearman −0.11, a test of low power with twelve sections), while the platforms agreed on which section is larger in 60 of 66 pairs, though in only 9 of the 15 pairs within a factor of three."),
    ("on links two blind annotators judged about two-thirds correct.",
     "on links that two blind AI annotators judged about two-thirds correct."),
    # Section 1.2
    ("Measurement 3 on the answer surfaces, which cite different sources.\n\n1. **Measurement 1, two instruments on one prefix** (Section 5), an instrument-validity result",
     "Measurement 3 on the answer surfaces, which cite different sources.\n\n"
     "Three questions organize the measurements. RQ1: how far apart are two commercial platforms' estimates of the same pages, and is the gap a constant a researcher could correct for? RQ2: do the topics people raise in their own words, in reviews, rank as keyword volume ranks them? RQ3: do AI answer surfaces cite the same kinds of sources, in industries chosen by an external rule? Each is answered once below, with what the answer does not show.\n\n"
     "1. **Measurement 1, two instruments on one prefix** (Section 5; RQ1), an instrument-validity result"),
    ("2. **Measurement 2, reviews against keyword volume** (Section 6), bearing", "2. **Measurement 2, reviews against keyword volume** (Section 6; RQ2), bearing"),
    ("3. **Measurement 3, what AI answers cite** (Section 7), bearing", "3. **Measurement 3, what AI answers cite** (Section 7; RQ3), bearing"),
    # stakes
    ("and 86% name only one of the three, which suggests, without proving, reliance on a single vendor's figures",
     "and 86% name only one of the three; the list is a keyword match, not screened for whether a work uses a tool's figures as data, so this suggests, without proving, reliance on a single vendor's figures"),
    # Section 2
    ("differences systematic enough to estimate one service's figures from the other's for related sites [Jansen, Jung & Salminen 2022].",
     "differences systematic enough to estimate one service's figures from the other's for related sites [Jansen, Jung & Salminen 2022]. The pattern recurs between two estimators: on 50 open-access repositories, SimilarWeb and Semrush differed significantly in level, by about 4% on average for visits and for visitors, while ranking the repositories almost identically (Spearman 0.997 on total visits) [Rasool, Thakur & Nabi 2026]; and a study of news publishers found the same traffic effect of blocking generative-AI crawlers, a decline of about 7% within six weeks, on SimilarWeb and on Semrush [Zhao & Berman 2025]."),
    ("; and ChatGPT, Copilot, Gemini and Perplexity on 712 queries, about 16% of whose cited sources were AI-generated [Allaham & Diakopoulos 2026].",
     "; ChatGPT, Copilot, Gemini and Perplexity on 712 queries, about 16% of whose cited sources were AI-generated [Allaham & Diakopoulos 2026]; and Google's AI Overviews on \"your money or your life\" queries drawn from MS MARCO Web Search, which cited AI-generated documents more often than human-authored ones at the same retrieval rank [Kakimov et al. 2026]."),
    ("Since the function is not evaluated here, Appendix B positions it against the closest of these methods.\n\n## 3 Setting",
     "Since the function is not evaluated here, Appendix B positions it against the closest of these methods.\n\n"
     "**Closest prior work, by measurement.** For Measurement 1: comparisons of estimators with first-party analytics or with one another, across many established sites at one time [Jansen, Jung & Salminen 2022; Rasool, Thakur & Nabi 2026; Font-Julián et al. 2026]; this paper holds one site fixed, follows one section from its first day on two instruments, and compares twelve sections of the site on one date. For Measurement 2: aspect mining of reviews [Hu & Liu 2004] and keyword tools as a source of queries and volumes [Schultheiß et al. 2023]; this paper places the two signals on one taxonomy and compares the topics each ranks. For Measurement 3: comparisons of cited sources across engines in industries or query sets their authors chose [Hendricks 2026; Lee 2026; Huang et al. 2026]; this paper fixes the industries by an external rule, the eleven GICS sectors, and compares eight vendor-collected surfaces.\n\n## 3 Setting"),
    # Section 3
    ("the section holds 381 code pages**: 374 for geographic codes assigned to US states and the District of Columbia (all 372 in service and two assigned but not yet in service), and 7 for toll-free codes;",
     "the section holds 381 code pages**: 374 for geographic codes assigned to US states and the District of Columbia (all 372 in service and two assigned but not yet in service), and 7 for toll-free codes (the released list of the pages gives each code's registry location, which takes 52 values: the 50 states, the District, and the plan-wide toll-free codes);"),
    # Section 5.5
    ("Across sections, then, the keyword universe does not predict the visits ratio, which is inconsistent with the index-coverage mechanism behind the age hypothesis;",
     "Across sections, then, the keyword-universe ratio has no detectable relationship with the visits ratio (two-sided p = 0.60 over all twelve and 0.10 without the area-code section; `instrument_extra.py`), so the index-coverage mechanism behind the age hypothesis finds no support here;"),
    # Sections 5.6 and 15
    ("so a single-vendor ranking of sections is right in direction when sections differ several-fold on both instruments and less reliable when they are within a factor of three (9 of 15 pairs);",
     "so a single-vendor ranking of sections agrees in direction with the other instrument's when sections differ several-fold on both instruments and less often when they are within a factor of three (9 of 15 pairs); with no ground truth, agreement between the two is all that can be shown;"),
    ("while a single-vendor ranking of sections is right in direction when sections differ several-fold on both instruments;",
     "while a single-vendor ranking of sections agrees in direction with the other instrument's when sections differ several-fold on both;"),
    # Table 2
    ("| October 2026 (run-rate) | 11 (77 cumulative) |", "| October 2026 (run-rate) | 11 (78 in all, days 0 to 77) |"),
    # Section 6
    ("is +0.19 (bootstrap 95% interval +0.12 to +0.25; Kendall's tau +0.13); counting the 26,809 linkable labels that no review mentions as zero, it is +0.27 (+0.26 to +0.29); both p < 0.001. It is +0.28 (p < 0.001) among the 213 labels with at least twenty mentions, and +0.16 (p = 0.10) among the 106 labels mentioned at least twenty times in one- and two-star reviews (Figure 6a).",
     "is +0.19 (bootstrap 95% interval over labels +0.12 to +0.25; Kendall's tau +0.13); counting the 26,809 linkable labels that no review mentions as zero, it is +0.27 (+0.26 to +0.29). It is +0.28 among the 213 labels with at least twenty mentions, and +0.16 among the 106 labels mentioned at least twenty times in one- and two-star reviews (Figure 6a). Labels share reviews and nest in one taxonomy, so they are not independent draws: these intervals, and the p-values below 0.001 the scripts print, are too narrow, and the label-level figures are descriptive. A bootstrap over reviews does not repair this here, because label counts are small integers and resampling or reweighting reviews shifts their ties, and the rank correlation with them (`supplement_r10.py`, section 12)."),
    ("computed instead on each node's own volume (its volume less its children's), the two label-level correlations are +0.16 and +0.26.",
     "computed instead on each node's own volume (its volume less its children's), the two label-level correlations are +0.16 and +0.26. Several variants are reported (attribution rule, nested or own volumes, mentioned or all labels, and, after the link check, multi-word labels only); none is adjusted for multiple comparisons, and the multi-word variants are post hoc. The per-label counts behind every correlation in this section are released in anonymized form, without label names and with volumes as ranks, with a script that recomputes them (Section 14)."),
    # Section 7.2
    ("A third amendment, A3, made after the review of this section, records corrections: how the exports were made, the stopped prompt-level sample, and the company-property list used in one sensitivity check.",
     "A third amendment, A3, made after the review of this section, records corrections: how the exports were made, the stopped prompt-level sample, and the company-property list used in one sensitivity check. A fourth, A4, records the author's decision not to wait for the vendor's written confirmation before using the data (Section 14)."),
    # Section 13
    ("were committed on 14 October 2026 and stamped with OpenTimestamps before any per-page outcome was read (`02_DESIGN/framework_retro_test_381.md` and its manifest); the stamp is anchored in Bitcoin block 971,506, mined at 04:05 UTC on 15 October 2026.",
     "were committed on 14 October 2026 and stamped with OpenTimestamps before any of its registered outcomes (each code page's ranking keywords, visits and query coverage) was read for any code (`02_DESIGN/framework_retro_test_381.md` and its manifest); the stamp is anchored in Bitcoin block 971,506, mined at 04:05 UTC on 15 October 2026. Earlier reads for this paper had shown some per-page information, the pages most cited in AI answers (Figure 8) and the share of visits held by the highest-traffic URLs (Section 8); a dated amendment kept apart from the stamped plan records this (`02_DESIGN/framework_retro_test_381_amendment_2026-10-15.md`)."),
    # Section 14: vendor terms
    ("and the prompt-level collection of Section 13 was stopped when the clause was found.",
     "and the prompt-level collection of Section 13 was stopped when the clause was found. The Section 7 design had made using and publishing the collected data conditional on the vendor's written confirmation (amendment A3); amendment A4 records the author's decision of 13 October 2026 not to treat that confirmation as a precondition. Semrush's terms prohibit using or launching \"any automated system\" that sends more requests than a person could reasonably produce, and to \"harvest or scrape any content of the Services\" (section 3.3, items (k) and (p), read 15 October 2026); the Semrush figures were read from its dashboards by the same browser assistant, and Semrush has not been asked whether that falls within those terms."),
    # Section 14: permission
    ("Approval date: *[to be completed]*. Approving role and unit: *[to be completed]*. Scope: *[to be completed]*. Until these three fields are filled from a written approval, this paper does not state that approval was given.",
     "No written approval has been received. When it is, this paragraph will give its date, the approving role and unit, and its scope; until then, this paper does not state that approval was given."),
    ("(1) the three permission fields above, from a written approval whose scope covers every table and section that uses the organization's figures;",
     "(1) the organization's written approval, with its date, approving role and unit, and a scope covering every table and section that uses the organization's figures;"),
    # Section 14: data released
    ("The raw vendor exports are not redistributed, because the vendor's terms restrict use of its data; a Brand Radar subscriber can re-export them with the recorded settings, which reproduces the procedure and not the figures, because the index refreshes.",
     "The raw vendor exports are not redistributed, because the vendor's terms restrict use of its data; a Brand Radar subscriber can re-export them with the recorded settings, which reproduces the procedure and not the figures, because the index refreshes. For Section 6, the per-label counts behind its correlations, anonymized (no label names; volumes as ranks, which is all a rank correlation uses), the link-check judgments and the annotators' protocol are prepared for release alongside, and `m2_from_counts.py` recomputes from them every Section 6 correlation, branch share and interval that does not need the review text; the licensed review export itself is not released."),
    # Section 14: reproduction
    ("A separate agent reproduced the source bundle in a clean folder on 15 October 2026: of 173 numbers the paper quotes, 136 matched what the released scripts and data give, none differed, and 37 could not be checked because they need withheld data (`08_REVIEW/reproduction_v5.2_2026-10-15/`).",
     "A separate agent reproduced the source bundle twice in a clean folder on 15 October 2026. In the second, fuller run, of 1,056 numbers the paper quotes, 899 matched what the released scripts and data give or what the agent recomputed from them, one differed (Table 2's day count, now corrected) and 156 could not be checked because they need withheld data; the paper builds from the bundle (`08_REVIEW/reproduction_v5.2_2026-10-15/` and `reproduction_v5.2_run2_2026-10-15/`)."),
])

# Appendix A, condensed: the corrections themselves; the narrative of each round is in the changelog
i, j = s.index("## Appendix A: Corrections across versions"), s.index("## Appendix B")
s = s[:i] + """## Appendix A: Corrections across versions

The full version history, including ten rounds of AI-simulated review (not peer review), is in the changelog released with the paper's source files. These are the corrections that change how a figure or claim must be read.

- **Integrity.** Early versions (v1 to v2.2) said that two independent annotators had graded audit samples (none had) and that the ontology had been released (it had not), and asserted organizational permission with the date blank; the same unsupported assertion reappeared in the public versions 4.6 to 4.8 and is withdrawn (open item 4). Version 4.9 had called the Section 7 design pre-registered, called its shares citations and lower bounds, said artifacts were released before they were and did not disclose the use of AI tools; version 5.1 corrected a conflict-of-interest statement that described a business relationship with the agency that does not exist, and removed a first Section 7 pilot, a dataset the author's own analytics platform computed on 7 October 2026 from vendor data accessed through the agency's account before its permission was given.
- **Measurement 1.** The page count is 381, not 290, which removed the 88-code within-class control. The primary checkpoint is day 37, not day 45, because the automated link network had arrived by day 45. A 9.2x AI-answer comparison was withdrawn as a scope mismatch, and a claim about the ordering of AI answer platforms was withdrawn because its breakdown did not sum to its total. Table 2's October row is a monthly run-rate, and its days-live column sums to 78 (days 0 to 77). Disagreement between instruments is a bound on the larger error, by a factor of 5.2 at 27.1x, not 13 times. The hypothesis that the vendor ratio narrows as a section ages was stated with a cross-prefix test before the test was run, and was retracted after it; Section 5.5 was regenerated from its released script after being written from recollection, and a stale copy of Figure 5 that printed −0.09 for −0.11 was replaced.
- **The deployment.** Withdrawn: that link acquisition played no part in the outcome (once the checkpoint moved to day 37), that the results were broad rather than concentrated in a few pages, that a comparison with two carriers of similar authority bounded the effect of domain authority, and that the deployment showed content on the topic to be necessary.
- **Measurement 2.** Branch agreement is +0.47 to +0.75 depending on how labels are attributed, replacing an earlier +0.78 computed on review-mentioned labels only, with branch shares on each branch's own volume; the taxonomy holds 11 labels containing "wait", not one.
- **Measurement 3.** The sector claim now accounts for single-company dominance and company properties, and the per-surface pilot that preceded the predictions is reported.
- **Version 5.2**, after an independent scoring agent, two independent reproductions of the source bundle and an independent literature search, all by separate AI agents: the count of works naming the vendor tools is 456, not 459 (three works were counted twice); statistics that no script printed are now printed; the Section 7 and figure scripts run from the bundle, and Section 7's numbers are also printed from the released aggregates; every quoted single dashboard read is in a released data file; and the closest prior work found by the searches is cited (Section 2).


""" + s[j:]

# references: peer-reviewed versions, and three additions
rep([
    ("Allaham, M., & Diakopoulos, N. (2026). *Synthetic sources?: Auditing generative search engine citations for evidence of AI-generated sources.* arXiv:2605.23684.",
     "Allaham, M., & Diakopoulos, N. (2026). Synthetic sources?: Auditing generative search engine citations for evidence of AI-generated sources. *Proceedings of the AAAI/ACM Conference on AI, Ethics, and Society, 9*(1), 142–154. https://doi.org/10.1609/aies.v9i1.43129"),
    ("Eloundou, T., Beutel, A., Robinson, D. G., Gu-Lemberg, K., Brakman, A.-L., Mishkin, P., Shah, M., Heidecke, J., Weng, L., & Kalai, A. T. (2024). *First-person fairness in chatbots.* arXiv:2410.19803.",
     "Eloundou, T., Beutel, A., Robinson, D., Gu, K., Brakman, A.-L., Mishkin, P., Shah, M., Heidecke, J., Weng, L., & Kalai, A. T. (2025). First-person fairness in chatbots. In *The Thirteenth International Conference on Learning Representations (ICLR 2025)*. https://proceedings.iclr.cc/paper_files/paper/2025/hash/92af0c8c2664429de2bb44c2692d84ae-Abstract-Conference.html"),
    ("Li, A., & Sinnamon, L. (2024). *Generative AI search engines as arbiters of public knowledge: An audit of bias and authority.* arXiv:2405.14034.",
     "Li, A., & Sinnamon, L. (2024). Generative AI search engines as arbiters of public knowledge: An audit of bias and authority. *Proceedings of the Association for Information Science and Technology, 61*(1), 205–217. https://doi.org/10.1002/pra2.1021"),
])
n = s.count("[Eloundou et al. 2024]")
if n != 2:
    raise SystemExit(f"REFUSE: {n} citations of Eloundou et al. 2024")
s = s.replace("[Eloundou et al. 2024]", "[Eloundou et al. 2025]")

NEW = {  # inserted before the reference that follows each alphabetically
    "Kamerer, D.": "Kakimov, R., Tan, X., Gillham, J., & Bejtic, N. (2026). Auditing citation behavior in AI-generated search summaries: A framework and a case study of Google AI Overviews. In *Proceedings of the 39th Canadian Conference on Artificial Intelligence* (Proceedings of Machine Learning Research, Vol. 318, pp. 224–235). https://proceedings.mlr.press/v318/kakimov26a.html",
    "Razniewski, S., Arnaout": "Rasool, A., Thakur, K., & Nabi, S. (2026). Digital performance of global repositories: A comparative webometric analysis. *Performance Measurement and Metrics*, 1–19. https://doi.org/10.1108/pmm-07-2026-0065",
    "Zobel, J.": "Zhao, H., & Berman, R. (2025). *Strategic response of news publishers to generative AI* (Version 4, revised 15 April 2026) [Preprint]. arXiv:2512.24968.",
}
lines = s.split("\n")
for anchor, entry in NEW.items():
    idx = [i for i, x in enumerate(lines) if x.startswith(anchor)]
    if len(idx) != 1:
        raise SystemExit(f"REFUSE: {len(idx)} reference lines start with {anchor!r}")
    lines[idx[0]:idx[0]] = [entry, ""]
s = "\n".join(lines)
P.write_text(s)
k = s.index("## Abstract")
print(f"{len(s.split()):,} words; abstract {len(s[k:s.index(chr(10) + '## ', k + 5)].split()) - 2} words")
