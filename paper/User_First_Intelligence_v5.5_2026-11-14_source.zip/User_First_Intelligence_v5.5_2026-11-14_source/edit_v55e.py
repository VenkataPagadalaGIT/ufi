"""Version 5.5, fifth edit (14 November 2026): the exhaustive source check.

Three checking agents compared all 97 reference entries with the sources' own records and all 133 sentences that cite
them with the sources themselves (08_REVIEW/factcheck_v5.5_2026-11-14/report_1.md to report_3.md). No entry was
fabricated or pointed to the wrong work. One attributed statement was not supported (Shao et al. 2024, cited for gap
discovery; it drafts articles from scratch) and twenty said somewhat more than the source does; each is reworded here
to what the source supports. Three entries cited as preprints have since been published; DOIs, pages, subtitles and
current URLs are added where the record has them; two corporate entries get the page's own byline. Every DOI added
was resolved at Crossref first. Three-author sources are now all cited with three names.

Each replacement must match exactly once and must not already be applied.
"""
import pathlib

p = pathlib.Path(__file__).with_name("manuscript_v50.md")
s = p.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:120]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:120]!r}")
        s = s.replace(a, b)


def move_entry(starts_with, before_starts_with):
    """Move one reference paragraph so that it stands just before another (keeps the Markdown list alphabetical)."""
    global s
    lines = s.split("\n")
    i = [k for k, l in enumerate(lines) if l.startswith(starts_with)]
    if len(i) != 1:
        raise SystemExit(f"REFUSE: {len(i)} entries start with {starts_with!r}")
    entry = lines[i[0]]
    del lines[i[0]:i[0] + 2]  # the entry and the blank line after it
    j = [k for k, l in enumerate(lines) if l.startswith(before_starts_with)]
    if len(j) != 1:
        raise SystemExit(f"REFUSE: {len(j)} entries start with {before_starts_with!r}")
    lines[j[0]:j[0]] = [entry, ""]
    s = "\n".join(lines)


# ---------------------------------------------------------------- statements reworded to what the source supports
rep([
    # Section 1
    ("a practice the validity studies in Section 2 caution against [Kamerer 2013; Prantl & Prantl 2018; Jansen, Jung & Salminen 2022]",
     "a practice the validity studies in Section 2 caution against [Kamerer 2013; Jansen, Jung & Salminen 2022] or show to be unreliable [Prantl & Prantl 2018]"),
    ("the nearest guidance is the set of recommendations closing one empirical comparison of the tools",
     "the nearest guidance is the set of recommendations in the discussion of one empirical comparison of the tools"),
    ("has been audited on public-interest, news and real search queries [Li & Sinnamon 2024; Yang 2025; Huang et al. 2026; Allaham & Diakopoulos 2026]",
     "has been audited on public-interest queries, for news sources, and on real search queries [Li & Sinnamon 2024; Yang 2025; Huang et al. 2026; Allaham & Diakopoulos 2026]"),
    # Section 1.4
    ("[Carroll et al. 2005; Lebo et al. 2013]", "[Carroll et al. 2005; Lebo, Sahoo & McGuinness 2013]"),
    # Section 2, measurement validity
    ("report for two academic publishers' domains, which overlapped so little that the choice of tool determined the findings [Font-Julián et al. 2026]",
     "report for two academic publishers' domains, where the keywords and URLs the tools returned overlapped so little that the choice of tool determined the findings [Font-Julián et al. 2026]"),
    ("Comparisons of estimators with first-party analytics have found large and variable errors: Compete and Quantcast underestimated traffic for 18 sites, with occasional overestimates [Kamerer 2013], and neither Alexa nor SimilarWeb ranked Czech websites accurately, although both indicated their approximate size [Prantl & Prantl 2018]",
     "Comparisons of estimators with first-party analytics or reference traffic data have found large and variable errors: Compete and Quantcast underestimated traffic in a panel of 18 sites (Quantcast reported on eight of them), with occasional overestimates [Kamerer 2013], and neither Alexa nor SimilarWeb ranked Czech websites accurately, although both indicated a site's approximate significance [Prantl & Prantl 2018]"),
    ("measures robust to incomplete judgments were proposed for exactly that case [Buckley & Voorhees 2004]",
     "a measure robust to incomplete judgments was proposed for exactly that case [Buckley & Voorhees 2004]"),
    # Section 2, AI answer surfaces
    ("five systems including Google AI Overviews on 11,000 real queries, with Wikipedia over-represented and social media under-represented among cited sources [Huang et al. 2026]",
     "five systems including Google AI Overviews on 11,000 real queries, with Wikipedia the most-cited domain and over-represented in the generated summaries, and cited social media under-represented in the summaries of Google's AI Overviews [Huang et al. 2026]"),
    ("about 16% of whose cited sources were AI-generated [Allaham & Diakopoulos 2026]",
     "about 16% of whose unique cited sources an AI-text detector classed as AI-generated [Allaham & Diakopoulos 2026]"),
    ("OpenAI, Perplexity and Google models on 366,000 citations from a public comparison arena",
     "OpenAI, Perplexity and Google models on over 366,000 citations from a public comparison arena"),
    ("more often than human-authored ones at the same retrieval rank [Kakimov et al. 2026]",
     "more often than human-authored ones even after controlling for retrieval rank [Kakimov et al. 2026]"),
    ("query intent and Google rank as predictors of citation across four chat assistants and eight verticals [Lee 2026]",
     "query intent and Google rank as predictors of citation, intent across four chat assistants and eight verticals and rank on two assistants and ten verticals [Lee 2026]"),
    ("vendor measurement across 15,000 prompts reports that only 12% of URLs cited by ChatGPT, Gemini and Copilot rank in Google's top ten for the same prompt, with Perplexity at 28.6% [Linehan & Guan 2025]",
     "vendor measurement across 15,000 prompts reports that on average only 12% of the URLs cited by ChatGPT, Gemini, Copilot and Perplexity rank in Google's top ten for the same prompt, 28.6% for Perplexity and about 8% for the others [Linehan 2025]"),
    ("in 17 undefined industries [OtterlyAI 2026]", "in 17 undefined industries [Tousseyn 2026]"),
    ("19.4% against 5.3% across 15 industries [Punturo et al. 2026]",
     "19.4% against 5.3% in a report that also breaks citations down for 15 industries [Punturo, Torres Llorca & Fishkin 2026]"),
    # Section 2, persona
    ("Chatbot responses have been shown to vary with users' demographic attributes [Eloundou et al. 2025];",
     "Chatbot responses have been shown to vary with the gender and race associated with a user's name [Eloundou et al. 2025];"),
    # Section 2, information needs
    ("The gap between the unit a user has in mind and the unit a retrieval system indexes is old ground [Belkin, Oddy & Brooks 1982; Taylor 1968],",
     "The gap between the need a user has in mind and the request a retrieval system can match is old ground [Belkin, Oddy & Brooks 1982; Taylor 1968],"),
    # Section 2, demand measurement
    ("Studies of search increasingly sample their queries, and the queries' volumes, from keyword research tools [Schultheiß et al. 2023].",
     "Some studies of search sample their queries, and the queries' volumes, from keyword research tools, and a systematic method for doing so has been proposed [Schultheiß et al. 2023]."),
    # Section 2, completeness
    ("[Razniewski et al. 2016; Galárraga et al. 2017; Balaraman et al. 2018; Luggen et al. 2019; Razniewski et al. 2024]",
     "[Razniewski, Suchanek & Nutt 2016; Galárraga et al. 2017; Balaraman, Razniewski & Nutt 2018; Luggen et al. 2019; Razniewski et al. 2024]"),
    ("and on gap discovery for encyclopedias [Wulczyn et al. 2016; Piccardi et al. 2018; Redi et al. 2020; Shao et al. 2024], with Ripoll et al. [2025] giving the most recent typology of content gaps",
     "on the discovery and classification of gaps in encyclopedias [Wulczyn et al. 2016; Piccardi et al. 2018; Redi et al. 2020] and on the question-driven drafting of encyclopedia articles from scratch [Shao et al. 2024], with Ripoll et al. [2025] giving a recent typology of content gaps"),
    # Section 2, closest prior work
    ("comparisons of estimators with first-party analytics or with one another, across many established sites at one time [Jansen,",
     "comparisons of estimators with first-party analytics or with one another, on established sites at one time [Jansen,"),
    ("follows the work that treats search-engine hit counts [Thelwall 2008], Google Trends [Hölzl, Keusch & Sajons 2025] and Wikipedia page views [Alibudbud 2023] as instruments whose settings, access dates and handling of crawlers and redirects must be reported,",
     "follows the work that treats search-engine hit counts as an instrument whose consistency must be checked before use [Thelwall 2008], and Google Trends [Hölzl, Keusch & Sajons 2025] and Wikipedia page views [Alibudbud 2023] as instruments whose settings and access dates, and for page views the handling of crawlers and redirects, should be reported,"),
    # Section 6.2
    ("The items a review of page-view studies asks authors to state, the pages, the language, the dates, the agent type and whether crawlers and redirects were included [Alibudbud 2023], are fixed in the plan.",
     "The items a review of page-view studies asks authors to state, the pages, the language, the collection dates and the period covered, the type of data (monthly here), the agent type and whether crawlers and redirects were included [Alibudbud 2023], are fixed in the plan."),
    # Section 7.2
    ("Whether the surfaces share one query set is not stated, and model versions and search settings are not documented.",
     "Whether the surfaces share one query set is not stated, and model versions are not documented; of the search settings, the vendor states that prompts run through the free, public web interfaces."),
    # Section 7.7
    ("The author analysed and published the collection, with different source categories, before it was read for this paper [Pagadala 2026b],",
     "The author analysed and published the collection, with different source categories, on 14 November 2026 [Pagadala 2026b], before it was read for this paper,"),
    # Section 13
    ("which classic web search audits found only weakly for demographic attributes [Hannak et al. 2013], which has been measured for chatbot responses [Eloundou et al. 2025],",
     "which a classic web search audit did not find for demographic attributes such as gender and age [Hannak et al. 2013], which has been measured for chatbot responses, for the gender and race a user's name suggests [Eloundou et al. 2025],"),
    # Appendix B
    ("as in test-driven ontology development, which tests a question against the ontology's vocabulary and separately against its instances [Keet & Ławrynowicz 2016; Wiśniewski et al. 2019]:",
     "as in test-driven ontology development, which first checks that a question's vocabulary is present in the ontology and then tests whether the ontology entails the answer, at the schema level or through individuals [Keet & Ławrynowicz 2016], and as in the finding that many published competency questions cannot be translated into queries for want of vocabulary in the ontology [Wiśniewski et al. 2019]:"),
    # Appendix E
    ("an empirical comparison of four SEO tools closes with methodological recommendations [Font-Julián et al. 2026, Section 5.2], to use several tools where possible,",
     "an empirical comparison of four SEO tools sets out five methodological recommendations in its discussion [Font-Julián et al. 2026, Section 5.2], among them to use several tools where possible,"),
])

# ---------------------------------------------------------------- reference entries
rep([
    ("Ahrefs. (2026b). *What is Organic Traffic in Ahrefs and how do we calculate it?*", "Ahrefs. (2026b, September 3). *What is Organic Traffic in Ahrefs and how do we calculate it?*"),
    ("In *Companion Proceedings of The Web Conference 2018* (pp. 1787–1792). ACM.", "In *Companion Proceedings of The Web Conference 2018* (pp. 1787–1792). ACM. https://doi.org/10.1145/3184558.3191641"),
    ("*Journal of Documentation, 38*(2), 61–71.", "*Journal of Documentation, 38*(2), 61–71. https://doi.org/10.1108/eb026722"),
    ("*SIGIR Forum, 36*(2), 3–10.", "*SIGIR Forum, 36*(2), 3–10. https://doi.org/10.1145/792550.792552"),
    ("Retrieval evaluation with incomplete information. In *Proceedings of the 27th Annual International ACM SIGIR Conference on Research and Development in Information Retrieval* (pp. 25–32). ACM.",
     "Retrieval evaluation with incomplete information. In *Proceedings of the 27th Annual International ACM SIGIR Conference on Research and Development in Information Retrieval* (pp. 25–32). ACM. https://doi.org/10.1145/1008992.1009000"),
    ("In *Proceedings of the 14th International Conference on World Wide Web (WWW '05)*. ACM. https://doi.org/10.1145/1060745.1060835",
     "In *Proceedings of the 14th International Conference on World Wide Web (WWW '05)* (pp. 613–622). ACM. https://doi.org/10.1145/1060745.1060835"),
    ("*Google users are less likely to click on links when an AI summary appears in the results.* Pew Research Center.",
     "*Google users are less likely to click on links when an AI summary appears in the results.* Pew Research Center. https://www.pewresearch.org/short-reads/2025/07/22/google-users-are-less-likely-to-click-on-links-when-an-ai-summary-appears-in-the-results/"),
    ("Synthesis Lectures on Information Concepts, Retrieval, and Services. Morgan & Claypool.",
     "Synthesis Lectures on Information Concepts, Retrieval, and Services. Morgan & Claypool. https://doi.org/10.2200/S00654ED1V01Y201507ICR043"),
    ("Eloundou, T., Beutel, A., Robinson, D., Gu, K., Brakman, A.-L.,", "Eloundou, T., Beutel, A., Robinson, D. G., Gu-Lemberg, K., Brakman, A.-L.,"),
    ("Font-Julián, C. I., Orduña-Malea, E., Lopezosa, C., & Aguillo, I. F. (2025).", "Font-Julián, C. I., Orduña-Malea, E., Lopezosa, C., & Aguillo, I. (2025)."),
    ("In *WSDM '17* (pp. 375–383). ACM.", "In *WSDM '17* (pp. 375–383). ACM. https://doi.org/10.1145/3018661.3018739"),
    ("In *WSDM '10* (pp. 201–210). ACM.", "In *WSDM '10* (pp. 201–210). ACM. https://doi.org/10.1145/1718487.1718513"),
    ("*Data voids: Where missing data can easily be exploited.* Data & Society Research Institute.",
     "*Data voids: Where missing data can easily be exploited.* Data & Society Research Institute. https://datasociety.net/research-library/data-voids-where-missing-data-can-easily-be-exploited/"),
    ("Grossman, R., Liu, S., Chen, M. K., Smith, M., Borcea, C., & Chen, Y. (2026). *How generative AI disrupts search: An empirical study of Google Search, Gemini, and AI Overviews* [Preprint]. arXiv:2604.27790.",
     "Grossman, R., Liu, S., Chen, M. K., Smith, M., Borcea, C., & Chen, Y. (2026). How generative AI disrupts search: An empirical study of Google Search, Gemini, and AI Overviews. In *Proceedings of the 49th International ACM SIGIR Conference on Research and Development in Information Retrieval (SIGIR '26)* (pp. 448–459). ACM. https://doi.org/10.1145/3805712.3809667"),
    ("In *Proceedings of the 22nd International Conference on World Wide Web (WWW 2013)* (pp. 527–538). ACM.",
     "In *Proceedings of the 22nd International Conference on World Wide Web (WWW 2013)* (pp. 527–538). ACM. https://doi.org/10.1145/2488388.2488435"),
    ("In *WWW '02* (pp. 517–526). ACM.", "In *WWW '02* (pp. 517–526). ACM. https://doi.org/10.1145/511446.511513"),
    ("*The Answer Index: What AI answer engines cite across eight industries* [Data set and report]. Zenodo.", "*The Answer Index: What AI answer engines cite across eight industries* [Data set]. Zenodo."),
    ("In *NAACL-HLT 2018, Industry Papers* (pp. 200–207). ACL.", "In *NAACL-HLT 2018, Industry Papers* (pp. 200–207). ACL. https://doi.org/10.18653/v1/N18-3025"),
    ("Huang, M., Goyal, A., Saha, K., & Chandrasekharan, E. (2026). *Answer bubbles: Information exposure in AI-mediated search.* arXiv:2603.16138.",
     "Huang, M., Goyal, A., Saha, K., & Chandrasekharan, E. (2026). Answer bubbles: Information exposure in AI-mediated search. In *Findings of the Association for Computational Linguistics: EMNLP 2026* (pp. 147–162). ACL. https://doi.org/10.18653/2026.findings-emnlp.8"),
    ("In *The Semantic Web: Latest Advances and New Domains (ESWC 2016)*, LNCS (pp. 642–657). Springer.", "In *The Semantic Web. Latest Advances and New Domains (ESWC 2016)*, LNCS 9678 (pp. 642–657). Springer."),
    ("Kostygina, G., Kim, Y., Seeskin, Z. H., LeClere, F. B., & Emery, S. (2023).", "Kostygina, G., Kim, Y., Seeskin, Z., LeClere, F., & Emery, S. (2023)."),
    ("*Social Media + Society, 9*(4). https://doi.org/10.1177/20563051231216947", "*Social Media + Society, 9*(4), 20563051231216947. https://doi.org/10.1177/20563051231216947"),
    ("https://www.screamingfrog.co.uk/how-accurate-are-website-traffic-estimators/", "https://www.screamingfrog.co.uk/blog/how-accurate-are-website-traffic-estimators/"),
    ("In *Proceedings of the Network and Distributed System Security Symposium (NDSS 2019)*. Internet Society.",
     "In *Proceedings of the Network and Distributed System Security Symposium (NDSS 2019)*. Internet Society. https://doi.org/10.14722/ndss.2019.23386"),
    ("Linehan, L., & Guan, X. (2025, August 11). *Only 12% of AI cited URLs rank in Google's top 10 for the original prompt.* Ahrefs. https://ahrefs.com/blog/ai-search-overlap/ (15,000 long-tail prompts across ChatGPT, Gemini, Copilot and Perplexity; accessed 12 October 2026.)",
     "Linehan, L. (2025, August 11). *Only 12% of AI cited URLs rank in Google's top 10 for the original prompt.* Ahrefs. https://ahrefs.com/blog/ai-search-overlap/ (15,000 long-tail prompts across ChatGPT, Gemini, Copilot and Perplexity; X. Guan is listed as contributor; accessed 12 October 2026.)"),
    ("When web search fails, searchers become askers. In *Proceedings of the 35th", "When web search fails, searchers become askers: Understanding the transition. In *Proceedings of the 35th"),
    ("In *ISWC 2019* (pp. 453–469). Springer.", "In *ISWC 2019* (pp. 453–469). Springer. https://doi.org/10.1007/978-3-030-30793-6_26"),
    ("What do people ask their social networks, and why? In *Proceedings of the SIGCHI", "What do people ask their social networks, and why? A survey study of status message Q&A behavior. In *Proceedings of the SIGCHI"),
    ("OtterlyAI. (2026, updated September 8). *AI search index.* https://otterly.ai/blog/ai-search-index/",
     "Tousseyn, R. (2026, updated September 8). *The AI search index: What ChatGPT, Gemini, Perplexity and Google actually cite in 17 industries.* OtterlyAI. https://otterly.ai/blog/ai-search-index/"),
    ("In *SIGIR '18* (pp. 665–674). ACM.", "In *SIGIR '18* (pp. 665–674). ACM. https://doi.org/10.1145/3209978.3209984"),
    ("Profound. https://tryprofound.com/blog/enhanced-citation-categories", "Profound. https://www.tryprofound.com/blog/enhanced-citation-categories"),
    ("But what do we actually know? In *AKBC 2016* (pp. 40–44). ACL.", "But what do we actually know? In *Proceedings of the 5th Workshop on Automated Knowledge Base Construction (AKBC 2016)* (pp. 40–44). ACL. https://doi.org/10.18653/v1/W16-1308"),
    ("*A taxonomy of knowledge gaps for Wikimedia projects.* arXiv:2008.12314.", "*A taxonomy of knowledge gaps for Wikimedia projects (first draft).* arXiv:2008.12314v1."),
    ("In *The Semantic Web: Trends and Challenges (ESWC 2014)*, LNCS (pp. 752–767). Springer.", "In *The Semantic Web: Trends and Challenges (ESWC 2014)*, LNCS 8465 (pp. 752–767). Springer."),
    ("*El Profesional de la Información*, e320403.", "*El Profesional de la información, 32*(4), e320403."),
    ("In *Proceedings of the Internet Measurement Conference 2018 (IMC '18)*. ACM.", "In *Proceedings of the Internet Measurement Conference 2018 (IMC '18)* (pp. 478–493). ACM. https://doi.org/10.1145/3278532.3278574"),
    ("https://www.semrush.com/kb/semrush-reports-tools/domain-analytics/ranks/traffic-ranks/", "https://www.semrush.com/kb/27-rank"),
    ("In *NAACL 2024.* ACL.", "In *NAACL 2024* (pp. 6252–6278). ACL. https://doi.org/10.18653/v1/2024.naacl-long.347"),
    ("*College & Research Libraries, 29*(3), 178–194.", "*College & Research Libraries, 29*(3), 178–194. https://doi.org/10.5860/crl_29_03_178"),
    ("Tinuiti. (2026). *Q1 2026 AI citation trends report*", "Tinuiti. (2026, February 25). *Q1 2026 AI citation trends report*"),
    ("*Journal of Informetrics, 7*(3), 699–711.", "*Journal of Informetrics, 7*(3), 699–711. https://doi.org/10.1016/j.joi.2013.04.005"),
    ("Score adjustment for correction of pooling bias. In *Proceedings of the 32nd International ACM SIGIR Conference on Research and Development in Information Retrieval* (pp. 444–451). ACM.",
     "Score adjustment for correction of pooling bias. In *Proceedings of the 32nd International ACM SIGIR Conference on Research and Development in Information Retrieval* (pp. 444–451). ACM. https://doi.org/10.1145/1571941.1572018"),
    ("In *WWW '16* (pp. 975–985). ACM.", "In *Proceedings of the 25th International Conference on World Wide Web (WWW '16)* (pp. 975–985). International World Wide Web Conferences Steering Committee. https://doi.org/10.1145/2872427.2883077"),
    ("Xu, H., Iqbal, U., & Montgomery, J. M. (2026). *Measuring Google AI Overviews: Activation, source quality, claim fidelity, and publisher impact.* arXiv:2605.14021.",
     "Xu, H., Iqbal, U., & Montgomery, J. M. (2026). Measuring Google AI Overviews: Activation, source quality, claim fidelity, and publisher impact. In *Proceedings of the 2026 ACM Internet Measurement Conference (IMC '26)* (pp. 529–546). ACM. https://doi.org/10.1145/3777912.3839818"),
    ("[Press release]. https://yext.com/about/news-media/ai-citations-release", "[Press release]. https://www.yext.com/about/news-media/ai-citations-release"),
    ("In *Proceedings of the 21st Annual International ACM SIGIR Conference on Research and Development in Information Retrieval* (pp. 307–314). ACM.",
     "In *Proceedings of the 21st Annual International ACM SIGIR Conference on Research and Development in Information Retrieval* (pp. 307–314). ACM. https://doi.org/10.1145/290941.291014"),
])

# keep the Markdown list in the order the built paper prints
move_entry("The Motley Fool. (2026", "Nuti, S. V.")
move_entry("Tousseyn, R. (2026", "Vállez, M.")

for stale in ("Linehan & Guan", "OtterlyAI 2026]", "Punturo et al.", "Lebo et al.", "Balaraman et al.", "Razniewski et al. 2016"):
    if stale in s:
        raise SystemExit(f"REFUSE: old citation key survives: {stale!r}")
if "—" in s:
    raise SystemExit("REFUSE: em dash")
p.write_text(s)
print("edit_v55e applied")
