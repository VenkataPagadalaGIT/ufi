"""Appendix C tables of which sources AI answers cite, by sector and answer surface (Section 7).

Reads 03_DATA/processed/cross_sector_top10_nonbrand.csv (ranked non-company domains per cell, written by
cross_sector_sensitivity.py) and prints Markdown for Table C3 (the most-cited non-company domain in every
sector and surface) and Table C4 (the three most-cited on AI Overviews, search queries, and on ChatGPT).
A dagger marks a property of one of the sector's own companies that was not entered as a company domain
(02_DESIGN/cross_sector_company_properties.csv); such domains count as non-company, as in Section 7.
"""
import csv
from pathlib import Path

import cross_sector as cs

top = {}
for r in csv.DictReader((cs.OUT / "cross_sector_top10_nonbrand.csv").open()):
    top.setdefault((r["etf"], r["surface"]), []).append((int(r["rank"]), r["domain"]))
top = {k: [d for _, d in sorted(v)] for k, v in top.items()}
props = {(r["etf"], r["domain"]) for r in csv.DictReader((cs.DESIGN / "cross_sector_company_properties.csv").open())}
cur = None  # sector being printed, for the property mark
sh = lambda d: (d[:-4] if d.endswith(".com") else d) + ("†" if (cur, d) in props else "")  # tables omit .com
short = {"aio_searchqueries": "AIO search", "aio_prompts": "AIO prompt", "aimode_searchqueries": "AIM search",
         "aimode_prompts": "AIM prompt", "chatgpt": "ChatGPT", "perplexity": "Perplexity", "gemini": "Gemini", "copilot": "Copilot"}
print("| Sector | " + " | ".join(short[p] for p in cs.SURFACES) + " |")
print("|---" * (len(cs.SURFACES) + 1) + "|")
for s in cs.SECTORS:
    cur = s
    print(f"| {cs.SECTOR_NAME[s]} | " + " | ".join(sh(top[(s, p)][0]) for p in cs.SURFACES) + " |")
print()
print("| Sector | AI Overviews (search queries) | ChatGPT |")
print("|---|---|---|")
for s in cs.SECTORS:
    cur = s
    print(f"| {cs.SECTOR_NAME[s]} | " + ", ".join(map(sh, top[(s, 'aio_searchqueries')][:3])) + " | " + ", ".join(map(sh, top[(s, 'chatgpt')][:3])) + " |")
print()
g = [top[(s, p)][0] for s in cs.SECTORS for p in cs.GOOGLE]
print(f"Google surfaces: top source youtube.com or google.com in {sum(d in ('youtube.com', 'google.com') for d in g)} of {len(g)} cells")
c = [top[(s, 'copilot')][0] for s in cs.SECTORS]
print(f"Copilot: top source walmart.com or amazon.com in {sum(d in ('walmart.com', 'amazon.com') for d in c)} of 11 sectors; msn.com in {c.count('msn.com')}")
gp = [top[(s, p)][0] for s in cs.SECTORS for p in ('perplexity', 'gemini')]
print(f"Perplexity and Gemini: top source wikipedia.org or reddit.com in {sum(d in ('wikipedia.org', 'reddit.com') for d in gp)} of 22 cells")
ch = [top[(s, 'chatgpt')][0] for s in cs.SECTORS]
print(f"ChatGPT: top source a .gov domain in {sum(d.endswith('.gov') for d in ch)} of 11 sectors")
c3 = [(s, top[(s, p)][0]) for s in cs.SECTORS for p in cs.SURFACES]
c4 = [(s, d) for s in cs.SECTORS for p in ("aio_searchqueries", "chatgpt") for d in top[(s, p)][:3]]
print(f"company properties marked: Table C3 {sum(x in props for x in c3)} of {len(c3)} cells; Table C4 {sum(x in props for x in c4)} of {len(c4)} entries")
print("  in Table C3:", sorted({f"{cs.SECTOR_NAME[s]}: {d}" for s, d in c3 if (s, d) in props}))
print("  in Table C4:", sorted({f"{cs.SECTOR_NAME[s]}: {d}" for s, d in c4 if (s, d) in props}))
