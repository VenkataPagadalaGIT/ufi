"""Figure: what AI answers cite, by sector and answer surface (cross-sector study).

Reads 03_DATA/processed/cross_sector_platform_metrics.csv (written by cross_sector.py) and
cross_sector_cells.csv (written by cross_sector_sensitivity.py; marks cells where YouTube is not cited).
Grayscale-safe: values are printed in every cell; panel (b) uses marker shape, not hue.
Writes fig10_sources.pdf/.png to 05_FIGURES/ (in the released folder, beside this script).
"""
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import cross_sector as cs

SRC = cs.OUT / "cross_sector_platform_metrics.csv"
OUTS = [cs.ROOT / "05_FIGURES"] if (cs.ROOT / "05_FIGURES").is_dir() else [Path(__file__).resolve().parent]

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["Times New Roman", "STIXGeneral", "DejaVu Serif"],
    "font.size": 7.5, "axes.titlesize": 8, "axes.labelsize": 7.5, "xtick.labelsize": 7,
    "ytick.labelsize": 7, "axes.linewidth": 0.6, "pdf.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False,
})

SURF = ["aio_searchqueries", "aio_prompts", "aimode_searchqueries", "aimode_prompts",
        "chatgpt", "perplexity", "gemini", "copilot"]
SURF_LABEL = ["AIO\nsearch", "AIO\nprompt", "AIM\nsearch", "AIM\nprompt",
              "Chat-\nGPT", "Perplex-\nity", "Gem-\nini", "Co-\npilot"]
SECT_LABEL = {
    "xlk": "Information Technology", "xlv": "Health Care", "xlf": "Financials",
    "xly": "Consumer Discretionary", "xlc": "Communication Services", "xli": "Industrials",
    "xlp": "Consumer Staples", "xle": "Energy", "xlu": "Utilities", "xlre": "Real Estate",
    "xlb": "Materials",
}

rows = [r for r in csv.DictReader(SRC.open()) if r["etf"] in SECT_LABEL]
share = {(r["etf"], r["surface"]): float(r["share_community_video"]) for r in rows}
ytr = {(r["etf"], r["surface"]): (int(r["yt_rank_nonbrand"]) if r["yt_rank_nonbrand"] else None)
       for r in rows}
notcited = {(r["etf"], r["surface"]) for r in csv.DictReader((SRC.parent / "cross_sector_cells.csv").open())
            if int(r["youtube_cited_in"]) == 0}
order = sorted(SECT_LABEL, key=lambda s: -np.mean([share[(s, p)] for p in SURF[:4]]))

fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.1, 3.15),
                             gridspec_kw={"width_ratios": [1.25, 1.0], "wspace": 0.42})

# (a) heatmap of video + community share
M = np.array([[share[(s, p)] * 100 for p in SURF] for s in order])
im = a1.imshow(M, cmap="Greys", vmin=0, vmax=40, aspect="auto")
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        v = M[i, j]
        a1.text(j, i, f"{v:.0f}", ha="center", va="center", fontsize=6.3,
                color="white" if v > 22 else "black")
a1.axvline(3.5, color="black", lw=1.0)
a1.set_xticks(range(len(SURF)))
a1.set_xticklabels(SURF_LABEL, fontsize=6.2)
a1.set_yticks(range(len(order)))
a1.set_yticklabels([SECT_LABEL[s] for s in order], fontsize=6.6)
a1.tick_params(length=0)
for sp in a1.spines.values():
    sp.set_visible(False)
a1.set_title("(a) Video and community share of\ncitation incidences, %", loc="left", pad=15)
a1.text(1.5, -0.85, "Google answer surfaces", ha="center", fontsize=6.6, style="italic")
a1.text(5.5, -0.85, "Other four surfaces", ha="center", fontsize=6.6, style="italic")

# (b) YouTube's rank among non-brand cited domains
CAP = 1000
for j, p in enumerate(SURF):
    ys = [None if (s, p) in notcited else ytr[(s, p)] for s in order]
    xs = j + np.linspace(-0.22, 0.22, len(ys))
    shown = [min(y, CAP) if y else CAP for y in ys]
    missing = [y is None for y in ys]
    a2.scatter([x for x, m in zip(xs, missing) if not m], [y for y, m in zip(shown, missing) if not m],
               s=10, marker="o" if j < 4 else "s", facecolor="0.15" if j < 4 else "white",
               edgecolor="0.1", lw=0.5, zorder=3)
    a2.scatter([x for x, m in zip(xs, missing) if m], [CAP] * sum(missing), s=14, marker="x",
               color="0.1", lw=0.7, zorder=3)
    med = np.median([y if y else CAP for y in ys])
    a2.plot([j - 0.3, j + 0.3], [med, med], color="black", lw=1.1, zorder=4)
a2.set_yscale("log")
a2.set_ylim(CAP * 1.6, 0.7)
a2.set_yticks([1, 3, 10, 30, 100, 300, 1000])
a2.set_yticklabels(["1", "3", "10", "30", "100", "300", "not\ncited"])
a2.axvline(3.5, color="black", lw=1.0)
a2.set_xticks(range(len(SURF)))
a2.set_xticklabels([l.replace("-\n", "").replace("\n", " ") for l in SURF_LABEL], fontsize=6.4, rotation=90)
a2.set_ylabel("rank of youtube.com among non-company domains (log)")
a2.grid(axis="y", color="0.88", lw=0.5)
a2.set_axisbelow(True)
a2.set_title("(b) Where YouTube ranks,\n11 sectors per surface", loc="left", pad=15)

for d in OUTS:
    d.mkdir(parents=True, exist_ok=True)
fig.savefig(OUTS[0] / "fig10_sources.pdf", bbox_inches="tight", pad_inches=0.02)
fig.savefig(OUTS[0] / "fig10_sources.png", dpi=300, bbox_inches="tight", pad_inches=0.02)
print("wrote fig10_sources.pdf/.png; sector order:", order)
