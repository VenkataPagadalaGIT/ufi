"""Second set of post-review checks for Section 5.8 (Round 9 verification). Not registered.

1. For each source type, the share of the variance of its 88 cell shares explained by answer surface
   and by sector (unweighted two-way decomposition of sums of squares; the remainder is interaction).
2. P4 under the company-property list and under the first 500 export rows.
3. Which hosts make up google.com on the AI Mode views.
4. P3 without Industrials, and P2 per arm without Industrials.
5. Per-surface median and range of every registered type share, and each cell's size (for Appendix C).
Prints everything; reads 03_DATA/processed and the raw exports.
"""
import csv
import statistics

import cross_sector as cs
import cross_sector_sensitivity as ss

TS = {(r["etf"], r["surface"]): {k: float(v) for k, v in r.items() if k.startswith("share_")}
      for r in csv.DictReader((cs.OUT / "cross_sector_type_shares.csv").open())}
TS2 = {}
for (s, p), t in TS.items():
    t = dict(t)
    t["share_video_community"] = t["share_video"] + t["share_forum"] + t["share_social"] + t["share_user_publishing"]
    TS2[(s, p)] = t
KEYS = ["share_video_community", "share_video", "share_forum", "share_social", "share_reference", "share_news",
        "share_government", "share_report_brands", "share_other_web"]

print("== Variance of cell shares explained by surface and by sector")
for k in KEYS:
    v = {(s, p): TS2[(s, p)][k] for s in cs.SECTORS for p in cs.SURFACES}
    g = statistics.mean(v.values())
    tot = sum((x - g) ** 2 for x in v.values())
    ssp = len(cs.SECTORS) * sum((statistics.mean(v[(s, p)] for s in cs.SECTORS) - g) ** 2 for p in cs.SURFACES)
    sss = len(cs.SURFACES) * sum((statistics.mean(v[(s, p)] for p in cs.SURFACES) - g) ** 2 for s in cs.SECTORS)
    print(f"  {k[6:]:18s} surface {ssp / tot:5.0%}  sector {sss / tot:5.0%}  interaction {1 - (ssp + sss) / tot:5.0%}")

print("\n== P4 under sensitivities (AI Overviews, consumer vs five others; exact one-sided p)")
BO = {s: ss.B[s] | ss.PROPS.get(s, set()) for s in cs.SECTORS}
for label, mk in (("company properties", lambda s, p: ss.comm_share(ss.agg_of(ss.rows(s, p)), BO[s])),
                  ("first 500 rows", lambda s, p: ss.comm_share(ss.agg_of(ss.rows(s, p)[:500]), ss.B[s]))):
    for p in ("aio_searchqueries", "aio_prompts"):
        a = [mk(s, p) for s in cs.CONSUMER]
        b = [mk(s, p) for s in cs.NONCONSUMER]
        print(f"  {label:20s} {cs.SURFACE_NAME[p]:30s} {statistics.mean(a):.1%} vs {statistics.mean(b):.1%}, p {cs.exact_mwu_p(a, b):.2f}")

print("\n== Hosts behind google.com on AI Mode (share of google.com incidences, median over sectors)")
for p in ("aimode_searchqueries", "aimode_prompts"):
    hosts = {}
    for s in cs.SECTORS:
        rs = [r for r in ss.rows(s, p) if cs.registrable(r["Domain"]) == "google.com"]
        tot = sum(int(r["Cited in"]) for r in rs) or 1
        for r in rs:
            hosts.setdefault(r["Domain"], []).append(int(r["Cited in"]) / tot)
    top = sorted(hosts.items(), key=lambda kv: -statistics.median(kv[1] + [0] * (11 - len(kv[1]))))[:5]
    print(f"  {cs.SURFACE_NAME[p]:30s} " + "; ".join(f"{h} {statistics.median(v + [0] * (11 - len(v))):.0%}" for h, v in top))

print("\n== Without Industrials (RTX)")
xi = [s for s in cs.SECTORS if s != "xli"]
A = {(s, p): ss.agg_of(ss.rows(s, p)) for s in xi for p in cs.SURFACES}
for p in ("chatgpt", "perplexity", "copilot"):
    print(f"  P2 {cs.SURFACE_NAME[p]:12s} {sum((ss.nonbrand_rank(A[(s, p)], ss.B[s], 'youtube.com') or 9999) > 5 for s in xi)}/10")
print(f"  P3 {sum(all((ss.nonbrand_rank(A[(s, p)], ss.B[s], 'reddit.com') or 9999) <= 10 for p in cs.SURFACES if p != 'copilot') for s in xi)}/10")

print("\n== Appendix C1: registered type shares by surface, median (min to max) over 11 sectors")
for p in cs.SURFACES:
    print(f"  {cs.SURFACE_NAME[p]:30s} " + " | ".join(
        f"{k[6:]} {statistics.median(TS2[(s, p)][k] for s in cs.SECTORS):.1%} ({min(TS2[(s, p)][k] for s in cs.SECTORS):.1%}-{max(TS2[(s, p)][k] for s in cs.SECTORS):.1%})"
        for k in KEYS if k not in ("share_video", "share_forum", "share_social")))
print("\n== Appendix C2: summed citation incidences per cell, thousands")
cells = {(r["etf"], r["surface"]): int(r["cited_in_sum"]) for r in csv.DictReader((cs.OUT / "cross_sector_cells.csv").open())}
for s in cs.SECTORS:
    print(f"  {cs.SECTOR_NAME[s]:24s} " + " ".join(f"{cells[(s, p)] / 1000:,.1f}" for p in cs.SURFACES))

print("\n== Bootstrap 95% intervals for the variance shares (sectors resampled, 10,000 times; independent measurement, 14 October 2026)")
import random
rng = random.Random(20261015)
for k in ("share_video_community", "share_news"):
    surf, sect = [], []
    for _ in range(10_000):
        S_ = [rng.choice(cs.SECTORS) for _ in cs.SECTORS]
        v = {(i, p): TS2[(s, p)][k] for i, s in enumerate(S_) for p in cs.SURFACES}
        g = statistics.mean(v.values())
        tot = sum((x - g) ** 2 for x in v.values())
        if tot == 0:
            continue
        surf.append(len(S_) * sum((statistics.mean(v[(i, p)] for i in range(len(S_))) - g) ** 2 for p in cs.SURFACES) / tot)
        sect.append(len(cs.SURFACES) * sum((statistics.mean(v[(i, p)] for p in cs.SURFACES) - g) ** 2 for i in range(len(S_))) / tot)
    surf.sort(); sect.sort()
    n = len(surf)
    print(f"  {k[6:]:18s} surface [{surf[int(0.025 * n)]:.0%}, {surf[int(0.975 * n) - 1]:.0%}]  sector [{sect[int(0.025 * n)]:.0%}, {sect[int(0.975 * n) - 1]:.0%}]")
