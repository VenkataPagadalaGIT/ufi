"""Cross-sector AI-citation study: source mix by sector and answer surface.

Inputs
  02_DESIGN/cross_sector_companies.csv                       the ten companies per GICS sector
  03_DATA/raw/brand_radar_sectors_2026-10-12/<etf>/<platform>_top1000.csv
  03_DATA/raw/brand_radar_sectors_2026-10-12/sector_answer_counts.csv

Outputs
  03_DATA/processed/cross_sector_platform_metrics.csv       one row per sector x surface
  03_DATA/processed/cross_sector_predictions.json           the four registered predictions, scored
  stdout                                                    every number the manuscript quotes

Definitions follow 02_DESIGN/cross_sector_ai_citation_study.md. "Cited in" is the number of
AI responses citing a domain; shares are of the summed "Cited in" over the exported top
1,000 domains (Ahrefs caps this table's export at 1,000 rows). Domains are reduced to the
registrable domain (www.youtube.com and m.youtube.com both count as youtube.com).
"""
import csv
import json
import statistics
from itertools import combinations
from pathlib import Path

HERE = Path(__file__).resolve().parent
if (HERE.parent / "aggregates").is_dir():  # the released folder: scripts/, design/, aggregates/ (raw exports withheld)
    ROOT, DESIGN, OUT = HERE.parent, HERE.parent / "design", HERE.parent / "aggregates"
    RAW = HERE.parent / "raw_exports_withheld"
else:  # the research project
    ROOT = HERE.parents[1]
    DESIGN, OUT = ROOT / "02_DESIGN", ROOT / "03_DATA/processed"
    RAW = ROOT / "03_DATA/raw/brand_radar_sectors_2026-10-12"


def need_raw():
    if not RAW.is_dir():
        raise SystemExit("This step reads the raw vendor exports, which are not released. section7_from_aggregates.py "
                         "recomputes from the released aggregates every Section 7 number that does not need row-level "
                         "data; the sensitivities that do (listed in its docstring) are in this script's saved output only.")

SECTORS = ["xlk", "xlv", "xlf", "xly", "xlc", "xli", "xlp", "xle", "xlu", "xlre", "xlb"]
SECTOR_NAME = {
    "xlk": "Information Technology", "xlv": "Health Care", "xlf": "Financials",
    "xly": "Consumer Discretionary", "xlc": "Communication Services", "xli": "Industrials",
    "xlp": "Consumer Staples", "xle": "Energy", "xlu": "Utilities", "xlre": "Real Estate",
    "xlb": "Materials",
}
GOOGLE = ["aio_searchqueries", "aio_prompts", "aimode_searchqueries", "aimode_prompts"]
CHAT = ["chatgpt", "perplexity", "gemini", "copilot"]
SURFACES = GOOGLE + CHAT
SURFACE_NAME = {
    "aio_searchqueries": "AI Overviews (search queries)", "aio_prompts": "AI Overviews (prompts)",
    "aimode_searchqueries": "AI Mode (search queries)", "aimode_prompts": "AI Mode (prompts)",
    "chatgpt": "ChatGPT", "perplexity": "Perplexity", "gemini": "Gemini", "copilot": "Copilot",
}
CONSUMER = ["xly", "xlp", "xlc", "xlv", "xlk"]
NONCONSUMER = ["xle", "xlb", "xlu", "xlre", "xli"]

# Source types, as registered before collection (amendment-free).
TYPES = {
    "video": {"youtube.com", "tiktok.com", "vimeo.com"},
    "forum": {"reddit.com", "quora.com", "stackoverflow.com", "stackexchange.com"},
    "social": {"facebook.com", "instagram.com", "linkedin.com", "x.com", "twitter.com",
               "pinterest.com", "threads.net"},
    "user_publishing": {"medium.com", "substack.com", "dev.to", "github.com"},
    "reference": {"wikipedia.org", "britannica.com", "investopedia.com"},
    "news": {"reuters.com", "apnews.com", "bloomberg.com", "cnbc.com", "wsj.com", "nytimes.com",
             "forbes.com", "ft.com", "washingtonpost.com", "theverge.com", "techcrunch.com"},
}
COMMUNITY = ("video", "forum", "social", "user_publishing")
TWO_LEVEL = {"co", "com", "org", "net", "gov", "ac", "edu"}


def registrable(domain):
    d = domain.strip().lower().removeprefix("www.")
    if d.endswith("wikipedia.org"):
        return "wikipedia.org"
    parts = d.split(".")
    if len(parts) > 2 and parts[-2] in TWO_LEVEL and len(parts[-1]) == 2:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:])


def kind(dom, brands):
    if dom in brands:
        return "report_brands"
    for t, ds in TYPES.items():
        if dom in ds:
            return t
    if dom.endswith(".gov"):
        return "government"
    return "other_web"


def brand_domains():
    out = {}
    for r in csv.DictReader((DESIGN / "cross_sector_companies.csv").open()):
        out.setdefault(r["etf"].lower(), set()).add(registrable(r["domain_used"]))
    return out


def load(folder, surface):
    need_raw()
    agg = {}
    with (RAW / folder / f"{surface}_top1000.csv").open(encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            d = registrable(r["Domain"])
            agg[d] = agg.get(d, 0) + int(r["Cited in"])
    return agg


def metrics(folder, surface, brands):
    agg = load(folder, surface)
    total = sum(agg.values())
    ranked = [d for d, _ in sorted(agg.items(), key=lambda x: (-x[1], x[0]))]
    nonbrand = [d for d in ranked if d not in brands]
    by = {}
    for d, c in agg.items():
        k = kind(d, brands)
        by[k] = by.get(k, 0) + c

    def rank(lst, d):
        return lst.index(d) + 1 if d in lst else None

    row = {
        "domains": len(agg), "cited_in_sum": total,
        "yt_rank_all": rank(ranked, "youtube.com"), "yt_rank_nonbrand": rank(nonbrand, "youtube.com"),
        "yt_share": agg.get("youtube.com", 0) / total,
        "reddit_rank_nonbrand": rank(nonbrand, "reddit.com"),
        "wikipedia_rank_nonbrand": rank(nonbrand, "wikipedia.org"),
        "top1_nonbrand": nonbrand[0], "top2_nonbrand": nonbrand[1], "top3_nonbrand": nonbrand[2],
    }
    for k in list(TYPES) + ["government", "report_brands", "other_web"]:
        row[f"share_{k}"] = by.get(k, 0) / total
    row["share_community_video"] = sum(row[f"share_{k}"] for k in COMMUNITY)
    return row


def exact_mwu_p(a, b):
    """One-sided exact permutation p for mean(a) > mean(b)."""
    pooled = a + b
    obs = statistics.mean(a) - statistics.mean(b)
    n, k = len(pooled), len(a)
    hits = tot = 0
    for idx in combinations(range(n), k):
        s = set(idx)
        x = [pooled[i] for i in idx]
        y = [pooled[i] for i in range(n) if i not in s]
        tot += 1
        hits += (statistics.mean(x) - statistics.mean(y)) >= obs - 1e-12
    return hits / tot


def main():
    brands = brand_domains()
    rows = []
    M = {}
    for s in SECTORS:
        for p in SURFACES:
            m = metrics(s, p, brands[s])
            M[(s, p)] = m
            rows.append({"etf": s, "sector": SECTOR_NAME[s], "surface": p,
                         "surface_name": SURFACE_NAME[p], **m})
    # Robustness: Industrials with "RTX Corporation" (ChatGPT export unavailable, see MISSING_chatgpt.txt)
    R = {}
    for p in SURFACES:
        if (RAW / "xli_rtxcorp" / f"{p}_top1000.csv").exists():
            R[p] = metrics("xli_rtxcorp", p, brands["xli"])
            rows.append({"etf": "xli_rtxcorp", "sector": "Industrials (RTX Corporation)",
                         "surface": p, "surface_name": SURFACE_NAME[p], **R[p]})

    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "cross_sector_platform_metrics.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        for r in rows:
            w.writerow({k: (round(v, 6) if isinstance(v, float) else v) for k, v in r.items()})

    counts = {r["etf"]: int(r["ai_responses_us_all_platforms"])
              for r in csv.DictReader((RAW / "sector_answer_counts.csv").open())}
    print(f"SECTORS {len(SECTORS)}; companies {sum(len(brands[s]) for s in SECTORS)}; "
          f"files {len(SECTORS) * (len(SURFACES) + 1)}; domain rows {len(SECTORS) * (len(SURFACES) + 1) * 1000:,}")
    print(f"AI response records (US, all platforms), summed over sectors: {sum(counts.values()):,}; "
          f"range {min(counts.values()):,} ({min(counts, key=counts.get)}) to "
          f"{max(counts.values()):,} ({max(counts, key=counts.get)})")

    # Headline contrasts
    g_comm = [M[(s, p)]["share_community_video"] for s in SECTORS for p in GOOGLE]
    c_comm = [M[(s, p)]["share_community_video"] for s in SECTORS for p in CHAT]
    print(f"community+video share: Google views median {statistics.median(g_comm):.1%} "
          f"(range {min(g_comm):.1%}-{max(g_comm):.1%}); chat median {statistics.median(c_comm):.1%} "
          f"(range {min(c_comm):.1%}-{max(c_comm):.1%})")
    for p in SURFACES:
        v = [M[(s, p)]["share_community_video"] for s in SECTORS]
        y = [M[(s, p)]["yt_rank_nonbrand"] or 9999 for s in SECTORS]
        print(f"  {SURFACE_NAME[p]:32s} comm+video median {statistics.median(v):5.1%}  "
              f"YouTube non-brand rank median {statistics.median(y):>5}  top3 in {sum(r <= 3 for r in y)}/11")
    higher = sum(min(M[(s, p)]["share_community_video"] for p in GOOGLE) >
                 max(M[(s, p)]["share_community_video"] for p in ("chatgpt", "copilot")) for s in SECTORS)
    print(f"sectors where every Google view exceeds both ChatGPT and Copilot on comm+video: {higher}/11")
    yt_g = sum((M[(s, p)]["yt_rank_nonbrand"] or 9999) <= 3 for s in SECTORS for p in GOOGLE)
    print(f"YouTube in non-brand top 3 on Google views: {yt_g}/44")

    # P1: YouTube is the most cited non-brand domain on AIO and AI Mode in a majority of sectors.
    p1_pairs = {p: [s for s in SECTORS if M[(s, p)]["yt_rank_nonbrand"] == 1] for p in GOOGLE}
    p1_sector = [s for s in SECTORS if any(M[(s, p)]["yt_rank_nonbrand"] == 1 for p in GOOGLE[:2])
                 and any(M[(s, p)]["yt_rank_nonbrand"] == 1 for p in GOOGLE[2:])]
    # P2: YouTube outside non-brand top 5 on ChatGPT, Perplexity and Copilot in a majority of sectors.
    p2 = {p: [s for s in SECTORS if (M[(s, p)]["yt_rank_nonbrand"] or 9999) > 5]
          for p in ("chatgpt", "perplexity", "copilot")}
    # P3: Reddit in non-brand top 10 on every surface except Copilot, in a majority of sectors.
    p3 = [s for s in SECTORS if all((M[(s, p)]["reddit_rank_nonbrand"] or 9999) <= 10
                                    for p in SURFACES if p != "copilot")]
    p3_fail = {s: [p for p in SURFACES if p != "copilot" and (M[(s, p)]["reddit_rank_nonbrand"] or 9999) > 10]
               for s in SECTORS if s not in p3}
    # P4: comm+video share on AI Overviews higher in consumer-facing than in other sectors.
    p4 = {}
    for p in ("aio_searchqueries", "aio_prompts"):
        a = [M[(s, p)]["share_community_video"] for s in CONSUMER]
        b = [M[(s, p)]["share_community_video"] for s in NONCONSUMER]
        p4[p] = {"consumer_mean": statistics.mean(a), "other_mean": statistics.mean(b),
                 "exact_one_sided_p": exact_mwu_p(a, b)}
    preds = {
        "P1": {"rule": "YouTube is the most cited non-brand domain on Google AI Overviews and Google AI Mode in a majority of sectors",
               "per_view_sectors_with_rank1": {k: len(v) for k, v in p1_pairs.items()},
               "sectors_rank1_on_both_products": p1_sector, "holds": len(p1_sector) >= 6},
        "P2": {"rule": "YouTube ranks outside the five most cited non-brand domains on ChatGPT, Perplexity and Copilot in a majority of sectors",
               "sectors_outside_top5": {k: len(v) for k, v in p2.items()},
               "holds_per_platform": {k: len(v) >= 6 for k, v in p2.items()}},
        "P3": {"rule": "Reddit is among the ten most cited non-brand domains on every platform except Copilot in a majority of sectors",
               "sectors_holding": p3, "failures": p3_fail, "holds": len(p3) >= 6},
        "P4": {"rule": "Video-plus-community share on Google AI Overviews is higher in consumer-facing sectors than in Energy, Materials, Utilities, Real Estate and Industrials",
               "tests": p4, "holds_search_queries": p4["aio_searchqueries"]["consumer_mean"] > p4["aio_searchqueries"]["other_mean"]},
    }
    (OUT / "cross_sector_predictions.json").write_text(json.dumps(preds, indent=1))
    print("P1", preds["P1"]["per_view_sectors_with_rank1"], "both products:", len(p1_sector), "->", preds["P1"]["holds"])
    print("P2", preds["P2"]["sectors_outside_top5"], "->", preds["P2"]["holds_per_platform"])
    print("P3 sectors holding:", len(p3), p3, "-> holds", preds["P3"]["holds"])
    print("   failures:", p3_fail)
    for p, t in p4.items():
        print(f"P4 {p}: consumer {t['consumer_mean']:.1%} vs other {t['other_mean']:.1%}, exact p {t['exact_one_sided_p']:.3f}")

    print("\nPer sector (Google 4 views | chat 4 views): YouTube non-brand rank; comm+video share")
    for s in SECTORS:
        g = [M[(s, p)]["yt_rank_nonbrand"] for p in GOOGLE]
        c = [M[(s, p)]["yt_rank_nonbrand"] for p in CHAT]
        gc = [M[(s, p)]["share_community_video"] for p in GOOGLE]
        cc = [M[(s, p)]["share_community_video"] for p in CHAT]
        tops = M[(s, "chatgpt")]["top1_nonbrand"], M[(s, "aio_searchqueries")]["top1_nonbrand"]
        print(f"{s:5s} G {g} {min(gc):.0%}-{max(gc):.0%} | C {c} {min(cc):.0%}-{max(cc):.0%} | "
              f"top non-brand ChatGPT {tops[0]}, AIO-sq {tops[1]}")
    # Exploratory, not registered: how much the non-brand top 10 overlaps between sectors.
    def top10(s, p):
        agg = load(s, p)
        r = [d for d, _ in sorted(agg.items(), key=lambda x: (-x[1], x[0])) if d not in brands[s]]
        return set(r[:10])
    jac = {}
    for p in SURFACES:
        js = [len(top10(a, p) & top10(b, p)) / len(top10(a, p) | top10(b, p))
              for a, b in combinations(SECTORS, 2)]
        jac[p] = statistics.mean(js)
    print("\nExploratory: mean pairwise Jaccard of the non-brand top 10 across the 55 sector pairs")
    for p in SURFACES:
        print(f"  {SURFACE_NAME[p]:32s} {jac[p]:.2f}")
    print(f"  Google views mean {statistics.mean(jac[p] for p in GOOGLE):.2f}; "
          f"chat mean {statistics.mean(jac[p] for p in CHAT):.2f}")
    preds["exploratory_top10_jaccard"] = jac
    (OUT / "cross_sector_predictions.json").write_text(json.dumps(preds, indent=1))

    if R:
        print("\nRobustness, Industrials with 'RTX Corporation' (ChatGPT unavailable):")
        for p, m in R.items():
            o = M[("xli", p)]
            print(f"  {SURFACE_NAME[p]:32s} YouTube rank {o['yt_rank_nonbrand']} -> {m['yt_rank_nonbrand']}; "
                  f"comm+video {o['share_community_video']:.1%} -> {m['share_community_video']:.1%}; "
                  f"top {o['top1_nonbrand']} -> {m['top1_nonbrand']}")


if __name__ == "__main__":
    main()
