"""Sensitivity checks for the cross-sector AI-citation study (Section 5.8), added after Round 9 review.

None of these checks is registered; each is reported as a sensitivity of a registered or descriptive
result, and the registered analysis in cross_sector.py is unchanged. Every number the manuscript
quotes from a sensitivity is printed here.

Inputs: as cross_sector.py, plus
  02_DESIGN/cross_sector_company_properties.csv   secondary domains owned by a listed company
                                                   (hand-built from the top-25 non-company lists)
  03_DATA/raw/brand_radar_cited_domains_us_2026-10-12/   the education per-platform export (pilot)
Outputs:
  03_DATA/processed/cross_sector_cells.csv         per-cell size, zero rows, tail mass, YouTube count
  03_DATA/processed/cross_sector_type_shares.csv   every registered source-type share, per cell
  03_DATA/processed/cross_sector_top10_nonbrand.csv  ranked top-10 non-company domains per cell (names only)
  stdout
"""
import csv
import random
import statistics
from pathlib import Path

import cross_sector as cs

ROOT = cs.ROOT
OUT = cs.OUT
B = cs.brand_domains()
PROPS = {}
for r in csv.DictReader((cs.DESIGN / "cross_sector_company_properties.csv").open()):
    PROPS.setdefault(r["etf"], set()).add(r["domain"])
TYPE_KEYS = list(cs.TYPES) + ["government", "report_brands", "other_web"]


def rows(folder, surface, base=None):
    if base is None:
        cs.need_raw()
        base = cs.RAW
    with (base / folder / f"{surface}_top1000.csv").open(encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def agg_of(rs, col="Cited in", how="sum"):
    a = {}
    for r in rs:
        d = cs.registrable(r["Domain"])
        v = int(r[col])
        a[d] = a.get(d, 0) + v if how == "sum" else max(a.get(d, 0), v)
    return a


def comm_share(a, brands, exclude=()):
    tot = sum(a.values())
    num = sum(c for d, c in a.items()
              if d not in exclude and cs.kind(d, brands) in cs.COMMUNITY)
    return num / tot if tot else 0.0


def type_shares(a, brands):
    tot = sum(a.values())
    by = {}
    for d, c in a.items():
        k = cs.kind(d, brands)
        by[k] = by.get(k, 0) + c
    return {k: by.get(k, 0) / tot for k in TYPE_KEYS}


def nonbrand_rank(a, brands, dom):
    r = [d for d, _ in sorted(a.items(), key=lambda x: (-x[1], x[0])) if d not in brands]
    return r.index(dom) + 1 if dom in r and a[dom] > 0 else None  # zero count = not cited


def med(xs):
    return statistics.median(xs)


def pct(x):
    return f"{x:.1%}"


def headline(label, share):
    """share(s, p) -> comm+video share; print Google vs chat medians and per-surface medians."""
    g = [share(s, p) for s in cs.SECTORS for p in cs.GOOGLE]
    c = [share(s, p) for s in cs.SECTORS for p in cs.CHAT]
    per = {p: med([share(s, p) for s in cs.SECTORS]) for p in cs.SURFACES}
    every = sum(min(share(s, p) for p in cs.GOOGLE) > max(share(s, p) for p in cs.CHAT) for s in cs.SECTORS)
    print(f"{label}: Google median {pct(med(g))}, other four median {pct(med(c))}; "
          + ", ".join(f"{cs.SURFACE_NAME[p].split(' (')[0][:9]}{'-sq' if 'search' in p else '-pr' if 'prompts' in p else ''} {pct(v)}"
                      for p, v in per.items())
          + f"; lowest Google view above highest other surface in {every}/11 sectors")
    return g, c


def main():
    R = {(s, p): rows(s, p) for s in cs.SECTORS for p in cs.SURFACES}
    A = {k: agg_of(v) for k, v in R.items()}

    print("== Registered reduction (sum of 'Cited in' over hosts of a registrable domain)")
    g, c = headline("baseline", lambda s, p: comm_share(A[(s, p)], B[s]))
    mp = [comm_share(A[(s, p)], B[s]) for s in cs.SECTORS for p in ("aio_prompts", "aimode_prompts")]
    print(f"matched prompt views only: AIO+AI Mode prompts median {pct(med(mp))} vs other four {pct(med(c))}")

    # Bootstrap over sectors (cells within a sector move together).
    rnd = random.Random(20261013)
    bg, bc = [], []
    for _ in range(10000):
        ss = [rnd.choice(cs.SECTORS) for _ in cs.SECTORS]
        bg.append(med([comm_share(A[(s, p)], B[s]) for s in ss for p in cs.GOOGLE]))
        bc.append(med([comm_share(A[(s, p)], B[s]) for s in ss for p in cs.CHAT]))
    q = lambda xs: (sorted(xs)[249], sorted(xs)[9749])
    print(f"bootstrap over sectors, 95% interval of the median: Google {pct(q(bg)[0])} to {pct(q(bg)[1])}; "
          f"other four {pct(q(bc)[0])} to {pct(q(bc)[1])}")

    print("\n== Sensitivities of the headline contrast")
    headline("YouTube removed from numerator", lambda s, p: comm_share(A[(s, p)], B[s], exclude={"youtube.com"}))
    AF = {k: agg_of(v, col="Found in") for k, v in R.items()}
    headline("'Found in' instead of 'Cited in'", lambda s, p: comm_share(AF[(s, p)], B[s]))
    AM = {k: agg_of(v, how="max") for k, v in R.items()}
    headline("largest single host instead of summed hosts", lambda s, p: comm_share(AM[(s, p)], B[s]))
    BO = {s: B[s] | PROPS.get(s, set()) for s in cs.SECTORS}
    headline("company properties counted as company domains", lambda s, p: comm_share(A[(s, p)], BO[s]))
    for k in (100, 250, 500):
        Ak = {key: agg_of(v[:k]) for key, v in R.items()}
        headline(f"first {k} export rows only", lambda s, p: comm_share(Ak[(s, p)], B[s]))
    xlc = {p: (comm_share(A[("xlc", p)], B["xlc"]), comm_share(A[("xlc", p)], BO["xlc"])) for p in cs.SURFACES}
    print("Communication Services, entered domains -> with Alphabet and Meta properties as company: "
          + "; ".join(f"{cs.SURFACE_NAME[p]} {pct(a)} -> {pct(b)}" for p, (a, b) in xlc.items()))

    print("\n== Registered predictions under the sensitivities")
    for label, Agg, Bs in (("baseline", A, B), ("company properties", A, BO), ("largest host", AM, B)):
        yt = {(s, p): nonbrand_rank(Agg[(s, p)], Bs[s], "youtube.com") for s in cs.SECTORS for p in cs.SURFACES}
        rd = {(s, p): nonbrand_rank(Agg[(s, p)], Bs[s], "reddit.com") for s in cs.SECTORS for p in cs.SURFACES}
        p1v = {p: sum(yt[(s, p)] == 1 for s in cs.SECTORS) for p in cs.GOOGLE}
        p1 = sum(any(yt[(s, p)] == 1 for p in cs.GOOGLE[:2]) and any(yt[(s, p)] == 1 for p in cs.GOOGLE[2:])
                 for s in cs.SECTORS)
        p2 = {p: sum((yt[(s, p)] or 9999) > 5 for s in cs.SECTORS) for p in ("chatgpt", "perplexity", "copilot")}
        p3 = sum(all((rd[(s, p)] or 9999) <= 10 for p in cs.SURFACES if p != "copilot") for s in cs.SECTORS)
        print(f"{label:20s} P1 per view {p1v}, both products {p1}/11; P2 {p2}; P3 {p3}/11")
    # P1 with google.com set aside (Google's answer surfaces citing Google's own pages).
    yt_ng = {(s, p): nonbrand_rank(A[(s, p)], B[s] | {"google.com"}, "youtube.com") for s in cs.SECTORS for p in cs.GOOGLE}
    print("P1 with google.com set aside: per view", {p: sum(yt_ng[(s, p)] == 1 for s in cs.SECTORS) for p in cs.GOOGLE},
          "both products", sum(any(yt_ng[(s, p)] == 1 for p in cs.GOOGLE[:2]) and any(yt_ng[(s, p)] == 1 for p in cs.GOOGLE[2:]) for s in cs.SECTORS))
    xi = [s for s in cs.SECTORS if s != "xli"]
    print(f"ChatGPT without Industrials (RTX): comm+video median {pct(med([comm_share(A[(s, 'chatgpt')], B[s]) for s in xi]))} "
          f"(with: {pct(med([comm_share(A[(s, 'chatgpt')], B[s]) for s in cs.SECTORS]))}); "
          f"P2 ChatGPT {sum((nonbrand_rank(A[(s, 'chatgpt')], B[s], 'youtube.com') or 9999) > 5 for s in xi)}/10; "
          f"P3 holding {sum(all((nonbrand_rank(A[(s, p)], B[s], 'reddit.com') or 9999) <= 10 for p in cs.SURFACES if p != 'copilot') for s in xi)}/10")

    print("\n== RTX Corporation re-run, every available surface (registered 'RTX' -> 'RTX Corporation')")
    for p in cs.SURFACES:
        f = cs.RAW / "xli_rtxcorp" / f"{p}_top1000.csv"
        if not f.exists():
            print(f"  {cs.SURFACE_NAME[p]:30s} not available (vendor error, MISSING_chatgpt.txt)")
            continue
        a0, a1 = A[("xli", p)], agg_of(rows("xli_rtxcorp", p))
        t0 = [d for d, _ in sorted(a0.items(), key=lambda x: (-x[1], x[0])) if d not in B["xli"]][0]
        t1 = [d for d, _ in sorted(a1.items(), key=lambda x: (-x[1], x[0])) if d not in B["xli"]][0]
        print(f"  {cs.SURFACE_NAME[p]:30s} comm+video {pct(comm_share(a0, B['xli']))} -> {pct(comm_share(a1, B['xli']))}; "
              f"YouTube rank {nonbrand_rank(a0, B['xli'], 'youtube.com')} -> {nonbrand_rank(a1, B['xli'], 'youtube.com')}; "
              f"top {t0} -> {t1}")

    print("\n== Name contamination, domain-level screen (Financials, 'Visa')")
    for p in cs.SURFACES:
        a = A[("xlf", p)]
        tot = sum(a.values())
        imm = sum(a.get(d, 0) for d in ("state.gov", "uscis.gov", "cbp.gov", "dhs.gov"))
        print(f"  {cs.SURFACE_NAME[p]:30s} state.gov+uscis.gov+cbp.gov+dhs.gov {pct(imm / tot)}; "
              f"state.gov rank {nonbrand_rank(a, B['xlf'], 'state.gov')}")

    print("\n== Registered source types, median share by surface over sectors (chat half of the registered question)")
    TS = {(s, p): type_shares(A[(s, p)], B[s]) for s in cs.SECTORS for p in cs.SURFACES}
    print("surface".ljust(32) + "".join(k[:9].rjust(10) for k in TYPE_KEYS))
    for p in cs.SURFACES:
        print(cs.SURFACE_NAME[p].ljust(32) + "".join(pct(med([TS[(s, p)][k] for s in cs.SECTORS])).rjust(10) for k in TYPE_KEYS))
    for grp, ps in (("Google views", cs.GOOGLE), ("other four", cs.CHAT)):
        print(grp.ljust(32) + "".join(pct(med([TS[(s, p)][k] for s in cs.SECTORS for p in ps])).rjust(10) for k in TYPE_KEYS))

    print("\n== Cell sizes and truncation")
    cells = []
    for s in cs.SECTORS:
        for p in cs.SURFACES:
            rs = R[(s, p)]
            v = [int(r["Cited in"]) for r in rs]
            tot = sum(v)
            yt = A[(s, p)].get("youtube.com", 0)
            cells.append({"etf": s, "surface": p, "export_rows": len(rs), "registrable_domains": len(A[(s, p)]),
                          "cited_in_sum": tot, "rows_cited_in_zero": sum(x == 0 for x in v),
                          "mass_rows_501_1000": round(sum(v[500:]) / tot, 6) if tot else 0,
                          "mass_rows_901_1000": round(sum(v[900:]) / tot, 6) if tot else 0,
                          "youtube_cited_in": yt,
                          "youtube_rank_nonbrand": nonbrand_rank(A[(s, p)], B[s], "youtube.com") or "not cited"})
    with (OUT / "cross_sector_cells.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(cells[0]))
        w.writeheader()
        w.writerows(cells)
    sz = [c["cited_in_sum"] for c in cells]
    print(f"cited_in_sum per cell: {min(sz):,} to {max(sz):,}; registrable domains per cell "
          f"{min(c['registrable_domains'] for c in cells)} to {max(c['registrable_domains'] for c in cells)}")
    for p in cs.SURFACES:
        cp = [c for c in cells if c["surface"] == p]
        print(f"  {cs.SURFACE_NAME[p]:30s} median mass in rows 501-1000 {pct(med([c['mass_rows_501_1000'] for c in cp]))}; "
              f"rows 901-1000 {pct(med([c['mass_rows_901_1000'] for c in cp]))}; cells where YouTube not cited "
              f"{sum(c['youtube_cited_in'] == 0 for c in cp)}")
    with (OUT / "cross_sector_type_shares.csv").open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["etf", "surface"] + [f"share_{k}" for k in TYPE_KEYS])
        for (s, p), t in TS.items():
            w.writerow([s, p] + [round(t[k], 6) for k in TYPE_KEYS])
    with (OUT / "cross_sector_top10_nonbrand.csv").open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["etf", "surface", "rank", "domain"])
        for (s, p), a in A.items():
            r = [d for d, _ in sorted(a.items(), key=lambda x: (-x[1], x[0])) if d not in B[s] and a[d] > 0]
            for i, d in enumerate(r[:10], 1):
                w.writerow([s, p, i, d])
    print("\nChatGPT top non-company domain, all eleven sectors: "
          + "; ".join(f"{cs.SECTOR_NAME[s]} {[d for d, _ in sorted(A[(s, 'chatgpt')].items(), key=lambda x: (-x[1], x[0])) if d not in B[s]][0]}"
                      for s in cs.SECTORS))

    print("\n== Company dominance proxy: largest company's share of the ten company domains' incidences, all-surface export")
    names = {(r["etf"].lower(), cs.registrable(r["domain_used"])): r["brand_name_used"]
             for r in csv.DictReader((cs.DESIGN / "cross_sector_companies.csv").open())}
    for s in cs.SECTORS:
        a = {d: c for d, c in agg_of(rows(s, "all")).items() if d in B[s]}
        top = max(a, key=a.get)
        print(f"  {cs.SECTOR_NAME[s]:24s} {names[(s, top)]:26s} {pct(a[top] / sum(a.values()))}")

    print("\n== Education per-platform export (12 Oct 22:21-22:26), the pilot that preceded the design")
    # The rest of this section is left out of the released copy (design amendment A3: it names the pilot's
    # competitor set). The lines it prints are released as pilot_section_output.txt.
    print("  (left out of the released copy; see pilot_section_output.txt)")


if __name__ == "__main__":
    main()
