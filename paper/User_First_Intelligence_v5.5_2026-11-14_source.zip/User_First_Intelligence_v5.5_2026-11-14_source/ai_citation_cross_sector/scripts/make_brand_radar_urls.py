"""Build Ahrefs Brand Radar report URLs for the cross-sector study.

One URL per (sector, platform) for the Cited pages report, plus the Overview and
AI responses report per sector. Brands and competitors are read from
02_DESIGN/cross_sector_companies.csv; the ETF rank-1 company is the brand, the rest
are competitors. The URL shape copies the one the Ahrefs UI itself produced on
2026-10-12 for the education pilot. These URLs were loaded in the browser for each export.

Correction, 13 October 2026: an earlier version of this docstring said "The UI is still driven by
hand". It was not. Every export was made by an AI browser assistant (Claude in Chrome) that loaded
these URLs in the owner's logged-in browser and clicked the interface's export control. Ahrefs'
terms prohibit automated use except through its API (clause 4.4(j)); see design amendment A3.
"""
import csv
import json
import urllib.parse
from pathlib import Path

import cross_sector as cs

COMPANIES = cs.DESIGN / "cross_sector_companies.csv"
OUT = cs.DESIGN / "cross_sector_report_urls.json"

PLATFORMS = {
    "all": "",
    "aio_searchqueries": "googleAiOverviewsKeywords",
    "aio_prompts": "googleAiOverviews",
    "aimode_searchqueries": "googleAiModeKeywords",
    "aimode_prompts": "googleAiMode",
    "chatgpt": "chatgpt",
    "perplexity": "perplexity",
    "gemini": "gemini",
    "copilot": "copilot",
}


def entity(name, domain):
    return {
        "keywords": [{"keyword": name, "match_mode": ["MatchAsEntity", {
            "match_mode": ["EntityContains"], "category": ["AnyCategory"]}]}],
        "urls_groups": [{"urls": [domain], "mode": "subdomains"}],
    }


def url(path, brand, competitors, model):
    q = {
        "aggregation": "total",
        "brandFilter": "mentioned=&operator=and&pages=",
        "brands": json.dumps([brand], separators=(",", ":")),
        "chartMetric": "mentions",
        "chatbotModel": model,
        "comparisonBasis": "Absolute",
        "competitors": json.dumps(competitors, separators=(",", ":")),
        "country": "us",
        "date": "latest",
        "keywordVolume": "",
        "tagsFilter": json.dumps({"matchType": "all", "rules": []}, separators=(",", ":")),
    }
    return "https://app.ahrefs.com/brand-radar/" + path + "?" + urllib.parse.urlencode(q)


sectors = {}
for r in csv.DictReader(COMPANIES.open()):
    if r["brand_name_used"] == "TO BE VERIFIED":
        continue
    sectors.setdefault((r["sector"], r["etf"]), []).append(r)

out = {}
for (sector, etf), rows in sectors.items():
    rows.sort(key=lambda r: int(r["rank"]))
    brand = entity(rows[0]["brand_name_used"], rows[0]["domain_used"])
    comps = [entity(r["brand_name_used"], r["domain_used"]) for r in rows[1:]]
    key = etf.lower()
    out[key] = {
        "sector": sector, "n_companies": len(rows),
        "overview": url("overview", brand, comps, ""),
        "cited_pages": {p: url("ai/cited-pages", brand, comps, m) for p, m in PLATFORMS.items()},
        "responses": {p: url("ai/responses", brand, comps, m) for p, m in PLATFORMS.items() if p != "all"},
    }

OUT.write_text(json.dumps(out, indent=1))
print(f"{len(out)} sectors; companies per sector:",
      {k: v["n_companies"] for k, v in out.items()})
print("example:", out["xlf"]["cited_pages"]["chatgpt"][:160], "...")
