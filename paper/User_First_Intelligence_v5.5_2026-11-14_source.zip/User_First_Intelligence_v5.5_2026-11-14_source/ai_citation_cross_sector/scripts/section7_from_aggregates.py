"""Section 7's numbers recomputed from the released aggregates alone, so that a reader without the withheld raw vendor
exports can reproduce them (independent reproduction of 15 October 2026: no Section 7 script ran from the bundle).

The raw-export scripts (cross_sector.py, cross_sector_sensitivity.py, cross_sector_sensitivity2.py) wrote these
aggregates; this script reads only them, with the same definitions, seeds and quantiles, and prints every Section 7
headline, the predictions, the overlap, the variance split, Tables C1 and C2 and the RTX check. Runs in the project
(03_DATA/processed) or in the released folder (../aggregates). Sensitivities that need row-level data ("Found in",
largest host, company properties, truncation, the "Visa" check) are printed only by cross_sector_sensitivity.py.
"""
import csv
import json
import random
import statistics
from itertools import combinations
from pathlib import Path

HERE = Path(__file__).resolve().parent
for cand in (HERE.parent / "aggregates", HERE.parents[1] / "03_DATA/processed"):
    if (cand / "cross_sector_platform_metrics.csv").exists():
        AGG = cand
        break
else:
    raise SystemExit("aggregates not found (looked in ../aggregates and 03_DATA/processed)")
COUNTS = AGG / "sector_answer_counts.csv"
if not COUNTS.exists():
    COUNTS = HERE.parents[1] / "03_DATA/raw/brand_radar_sectors_2026-10-12/sector_answer_counts.csv"

SECTORS = ["xlk", "xlv", "xlf", "xly", "xlc", "xli", "xlp", "xle", "xlu", "xlre", "xlb"]
GOOGLE = ["aio_searchqueries", "aio_prompts", "aimode_searchqueries", "aimode_prompts"]
CHAT = ["chatgpt", "perplexity", "gemini", "copilot"]
SURFACES = GOOGLE + CHAT
CONSUMER, NONCONSUMER = ["xly", "xlp", "xlc", "xlv", "xlk"], ["xle", "xlb", "xlu", "xlre", "xli"]
med = statistics.median


def pct(x):
    return f"{x:.1%}"


def rank(v):
    return int(v) if v not in ("", None) else 9999  # empty: not cited


PM = {(r["etf"], r["surface"]): r for r in csv.DictReader((AGG / "cross_sector_platform_metrics.csv").open())}
TS = {(r["etf"], r["surface"]): {k: float(v) for k, v in r.items() if k.startswith("share_")}
      for r in csv.DictReader((AGG / "cross_sector_type_shares.csv").open())}
for t in TS.values():
    t["share_video_community"] = t["share_video"] + t["share_forum"] + t["share_social"] + t["share_user_publishing"]
CELLS = {(r["etf"], r["surface"]): r for r in csv.DictReader((AGG / "cross_sector_cells.csv").open())}
TOP = {}
for r in csv.DictReader((AGG / "cross_sector_top10_nonbrand.csv").open()):
    TOP.setdefault((r["etf"], r["surface"]), []).append((int(r["rank"]), r["domain"]))
TOP = {k: [d for _, d in sorted(v)] for k, v in TOP.items()}


def comm(s, p):
    return float(PM[(s, p)]["share_community_video"])


print("== Frame")
counts = {r["etf"]: int(r["ai_responses_us_all_platforms"]) for r in csv.DictReader(COUNTS.open())} if COUNTS.exists() else {}
if counts:
    print(f"  answer records, US, all platforms, summed over sectors {sum(counts.values()):,}; "
          f"range {min(counts.values()):,} ({min(counts, key=counts.get)}) to {max(counts.values()):,} ({max(counts, key=counts.get)})")
sizes = [int(CELLS[(s, p)]["cited_in_sum"]) for s in SECTORS for p in SURFACES]
doms = [int(CELLS[(s, p)]["registrable_domains"]) for s in SECTORS for p in SURFACES]
print(f"  88 cells; summed citation incidences per cell {min(sizes):,} to {max(sizes):,}; registrable domains per export {min(doms)} to {max(doms)}")

print("\n== Video and community share (registered reduction)")
g = [comm(s, p) for s in SECTORS for p in GOOGLE]
c = [comm(s, p) for s in SECTORS for p in CHAT]
print(f"  Google views median {pct(med(g))} (range {pct(min(g))} to {pct(max(g))}); other four median {pct(med(c))} (range {pct(min(c))} to {pct(max(c))})")
print("  per surface: " + ", ".join(f"{p} {pct(med([comm(s, p) for s in SECTORS]))}" for p in SURFACES))
every = sum(min(comm(s, p) for p in GOOGLE) > max(comm(s, p) for p in CHAT) for s in SECTORS)
print(f"  sectors where the lowest Google view exceeds the highest other surface: {every}/11")
mp = [comm(s, p) for s in SECTORS for p in ("aio_prompts", "aimode_prompts")]
print(f"  Google prompt views only: median {pct(med(mp))}")
rnd = random.Random(20261013)  # as cross_sector_sensitivity.py
bg, bc = [], []
for _ in range(10000):
    ss = [rnd.choice(SECTORS) for _ in SECTORS]
    bg.append(med([comm(s, p) for s in ss for p in GOOGLE]))
    bc.append(med([comm(s, p) for s in ss for p in CHAT]))
q = lambda xs: (sorted(xs)[249], sorted(xs)[9749])
print(f"  bootstrap over sectors, 95% interval of the median: Google {pct(q(bg)[0])} to {pct(q(bg)[1])}; other four {pct(q(bc)[0])} to {pct(q(bc)[1])}")
nyt = lambda s, p: comm(s, p) - float(PM[(s, p)]["yt_share"])
gn = [nyt(s, p) for s in SECTORS for p in GOOGLE]
cn = [nyt(s, p) for s in SECTORS for p in CHAT]
everyn = sum(min(nyt(s, p) for p in GOOGLE) > max(nyt(s, p) for p in CHAT) for s in SECTORS)
print(f"  without YouTube: Google median {pct(med(gn))}, other four {pct(med(cn))}; lowest Google view above highest other in {everyn}/11")

print("\n== YouTube among non-company domains")
for p in SURFACES:
    y = [rank(PM[(s, p)]["yt_rank_nonbrand"]) for s in SECTORS]
    print(f"  {p:22s} median rank {med(y):>5}; in the top three in {sum(r <= 3 for r in y)}/11")
print(f"  top three on Google views {sum(rank(PM[(s, p)]['yt_rank_nonbrand']) <= 3 for s in SECTORS for p in GOOGLE)}/44; "
      f"on the other four {sum(rank(PM[(s, p)]['yt_rank_nonbrand']) <= 3 for s in SECTORS for p in CHAT)}/44")

print("\n== Other source types, medians")
for k in ("share_reference", "share_forum", "share_report_brands", "share_other_web"):
    print(f"  {k[6:]:15s} Google {pct(med([TS[(s, p)][k] for s in SECTORS for p in GOOGLE]))}; other four {pct(med([TS[(s, p)][k] for s in SECTORS for p in CHAT]))}; "
          f"Copilot {pct(med([TS[(s, 'copilot')][k] for s in SECTORS]))}")


def exact_p(a, b):
    pooled, obs = a + b, statistics.mean(a) - statistics.mean(b)
    hits = tot = 0
    for idx in combinations(range(len(pooled)), len(a)):
        x = [pooled[i] for i in idx]
        y = [pooled[i] for i in range(len(pooled)) if i not in set(idx)]
        tot += 1
        hits += (statistics.mean(x) - statistics.mean(y)) >= obs - 1e-12
    return hits / tot


print("\n== Predictions written before collection")
p1 = {p: sum(rank(PM[(s, p)]["yt_rank_nonbrand"]) == 1 for s in SECTORS) for p in GOOGLE}
both = [s for s in SECTORS if any(rank(PM[(s, p)]["yt_rank_nonbrand"]) == 1 for p in GOOGLE[:2]) and any(rank(PM[(s, p)]["yt_rank_nonbrand"]) == 1 for p in GOOGLE[2:])]
print(f"  P1 sectors with YouTube first, per view {p1}; on both products {len(both)}/11 -> {'holds' if len(both) >= 6 else 'fails'}")
p2 = {p: sum(rank(PM[(s, p)]["yt_rank_nonbrand"]) > 5 for s in SECTORS) for p in ("chatgpt", "perplexity", "copilot")}
print(f"  P2 sectors with YouTube outside the top five {p2} -> {'holds' if all(v >= 6 for v in p2.values()) else 'fails'}")
p3 = [s for s in SECTORS if all(rank(PM[(s, p)]["reddit_rank_nonbrand"]) <= 10 for p in SURFACES if p != "copilot")]
chat_fail = sum(rank(PM[(s, "chatgpt")]["reddit_rank_nonbrand"]) > 10 for s in SECTORS if s not in p3)
print(f"  P3 sectors with Reddit in the top ten on every surface but Copilot {len(p3)}/11 -> {'holds' if len(p3) >= 6 else 'fails'}; ChatGPT fails in {chat_fail} of the {11 - len(p3)} others")
for p in ("aio_searchqueries", "aio_prompts"):
    a_, b_ = [comm(s, p) for s in CONSUMER], [comm(s, p) for s in NONCONSUMER]
    print(f"  P4 {p}: consumer {pct(statistics.mean(a_))} against other {pct(statistics.mean(b_))}; exact one-sided p {exact_p(a_, b_):.3f}")

print("\n== Exploratory: mean pairwise Jaccard of the non-company top ten across the 55 sector pairs")
jac = {p: statistics.mean(len(set(TOP[(a, p)]) & set(TOP[(b, p)])) / len(set(TOP[(a, p)]) | set(TOP[(b, p)])) for a, b in combinations(SECTORS, 2)) for p in SURFACES}
print("  " + ", ".join(f"{p} {v:.2f}" for p, v in jac.items()))
print(f"  Google views {min(jac[p] for p in GOOGLE):.2f} to {max(jac[p] for p in GOOGLE):.2f}; other four {min(jac[p] for p in CHAT):.2f} to {max(jac[p] for p in CHAT):.2f}")

print("\n== Variance of cell shares explained by surface and by sector (unweighted)")
KEYS = ["share_video_community", "share_news", "share_government", "share_report_brands"]


def split(v, sectors):
    gm = statistics.mean(v.values())
    tot = sum((x - gm) ** 2 for x in v.values())
    ssp = len(sectors) * sum((statistics.mean(v[(i, p)] for i in range(len(sectors))) - gm) ** 2 for p in SURFACES)
    sss = len(SURFACES) * sum((statistics.mean(v[(i, p)] for p in SURFACES) - gm) ** 2 for i in range(len(sectors)))
    return ssp / tot, sss / tot


for k in KEYS:
    sp_, ss_ = split({(i, p): TS[(s, p)][k] for i, s in enumerate(SECTORS) for p in SURFACES}, SECTORS)
    print(f"  {k[6:]:18s} surface {sp_:.0%}  sector {ss_:.0%}")
rng = random.Random(20261015)  # as cross_sector_sensitivity2.py
for k in ("share_video_community", "share_news"):
    a_, b_ = [], []
    for _ in range(10_000):
        S_ = [rng.choice(SECTORS) for _ in SECTORS]
        v = {(i, p): TS[(s, p)][k] for i, s in enumerate(S_) for p in SURFACES}
        if sum((x - statistics.mean(v.values())) ** 2 for x in v.values()) == 0:
            continue
        x_, y_ = split(v, S_)
        a_.append(x_)
        b_.append(y_)
    a_.sort()
    b_.sort()
    n = len(a_)
    print(f"  bootstrap {k[6:]:18s} surface [{a_[int(0.025 * n)]:.0%}, {a_[int(0.975 * n) - 1]:.0%}]  sector [{b_[int(0.025 * n)]:.0%}, {b_[int(0.975 * n) - 1]:.0%}]")

print("\n== Appendix C1: registered type shares by surface, median (min to max) over 11 sectors")
for p in SURFACES:
    print(f"  {p:22s} " + " | ".join(f"{k[6:]} {pct(med([TS[(s, p)][k] for s in SECTORS]))} ({pct(min(TS[(s, p)][k] for s in SECTORS))}-{pct(max(TS[(s, p)][k] for s in SECTORS))})"
                                     for k in ["share_video_community", "share_reference", "share_news", "share_government", "share_report_brands", "share_other_web"]))
print("\n== Appendix C2: summed citation incidences per cell, thousands")
for s in SECTORS:
    print(f"  {s:5s} " + " ".join(f"{int(CELLS[(s, p)]['cited_in_sum']) / 1000:,.1f}" for p in SURFACES))

print("\n== Truncation: median share of a cell's incidences in export rows 501 to 1,000")
m5 = {p: med([float(CELLS[(s, p)]["mass_rows_501_1000"]) for s in SECTORS]) for p in SURFACES}
print("  " + ", ".join(f"{p} {pct(v)}" for p, v in m5.items()) + f"; range of medians {pct(min(m5.values()))} to {pct(max(m5.values()))}")

if any(k[0] == "xli_rtxcorp" for k in PM):
    print("\n== Industrials re-run as 'RTX Corporation' (ChatGPT export unavailable)")
    for p in SURFACES:
        if ("xli_rtxcorp", p) in PM:
            o, r = PM[("xli", p)], PM[("xli_rtxcorp", p)]
            print(f"  {p:22s} video and community {pct(float(o['share_community_video']))} -> {pct(float(r['share_community_video']))}; "
                  f"YouTube rank {o['yt_rank_nonbrand'] or 'not cited'} -> {r['yt_rank_nonbrand'] or 'not cited'}; top non-company {o['top1_nonbrand']} -> {r['top1_nonbrand']}")
pj = AGG / "cross_sector_predictions.json"
if pj.exists():
    j = json.loads(pj.read_text())
    print(f"\n(check) predictions file: P1 per view {j['P1']['per_view_sectors_with_rank1']}; P2 {j['P2']['sectors_outside_top5']}; P3 {len(j['P3']['sectors_holding'])}")
