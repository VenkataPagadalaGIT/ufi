# Measurement 3: what AI answers cite, across eleven sectors and eight answer surfaces (manuscript Section 7)

Ahrefs Brand Radar "cited domains" exports for the ten largest S&P 500 companies of each of the eleven GICS sectors,
on eight answer surfaces, read 12 and 13 October 2026. The raw exports are not released (vendor terms); their SHA-1
checksums are in `aggregates/raw_exports_SHA1SUMS.txt`. Everything the paper reports from them is recomputable from the
aggregates in this folder.

| Folder | What it holds |
|---|---|
| `design/` | the design written before collection, with amendments A1 to A4 (released copy: the education pilot's brand names are redacted, amendment A3), the company list, the company properties used in one sensitivity, and the report addresses |
| `aggregates/` | per-cell aggregates written by the scripts from the raw exports: source-type shares, platform metrics, cell sizes, the ten most-cited non-company domains per cell, the prediction tally, and the all-platform answer counts |
| `scripts/` | the scripts and the output each printed |

## Running

From `scripts/`:

```
python3 section7_from_aggregates.py
```

prints every Section 7 headline, the predictions, the overlap, the variance split with its bootstrap, Tables C1 and C2
and the RTX check from `../aggregates` alone; its output is `section7_from_aggregates_output.txt`, identical to the
output of the same script in the research project.

`cross_sector.py`, `cross_sector_sensitivity.py` and `cross_sector_sensitivity2.py` read the raw exports. Run here,
they stop with a message saying so (`cross_sector_sensitivity2.py` first prints the variance block it can compute
from the aggregates). Their outputs (`*_output.txt`) are the record of their runs on the exports; the
released `cross_sector_sensitivity.py` was itself run on the exports to print `cross_sector_sensitivity_output.txt`.
Its last section, on the education pilot that preceded the design, is left out of the released copy because it names
the pilot's competitor set (amendment A3); the lines that section prints are in `pilot_section_output.txt`.
`make_tables_sector_surface.py` prints Tables C3 and C4; `make_fig_sources.py` draws the figure; `make_brand_radar_urls.py`
builds the report addresses from the company list.

## One field to read with care

`yt_rank_nonbrand` in `cross_sector_platform_metrics.csv` is YouTube's position among the cell's non-company domains
ordered by "Cited in", with ties broken by name. Where YouTube is not cited at all, the position is among the domains
with a count of zero: for Utilities on ChatGPT it is 825, while `cross_sector_cells.csv` records the same cell as "not
cited" (`youtube_cited_in` 0). Both describe a count of zero. No median the paper reports changes under either reading.
