> Released copy, 13 October 2026. Identical to the design file of record except that the education pilot's brand names and the paths to its unreleased records are redacted (amendment A3, last bullet).

# Cross-sector AI-citation study: pre-registration

**Status:** DRAFT, written 12 October 2026 before any sector data was collected. Pending owner approval. Once approved, this file is frozen; any change after collection starts is recorded as a dated amendment at the end, never edited in place.

## Question

Does the pattern found on the education pilot (the author's pilot records (not released)) hold across industries: that the sources AI answer surfaces cite depend on the platform, with video and community sources leading on Google's search-based answer products and reference, job and forum sources leading on the chat products?

## Why these industries

The frame is the eleven GICS sectors of the S&P 500. Reasons a reviewer can check:

1. **Exhaustive, not selected.** The eleven sectors partition the whole index. Every sector is included, so no industry was chosen for its result.
2. **Externally defined and maintained.** GICS is maintained by S&P Dow Jones Indices and MSCI, not by the author.
3. **Dated and free to verify.** The constituent lists come from the eleven Select Sector SPDR ETFs published by State Street Global Advisors, holdings as of 9 October 2026, read from each fund's public page on 12 October 2026. The funds partition the S&P 500 by GICS sector.

The education pilot is not a GICS sector (education services sits inside Consumer Discretionary); it stays as the pilot and is not re-run.

## Why these companies

For each sector, the ten largest holdings by index weight on 9 October 2026, which is float-adjusted market capitalization. Share classes of one issuer count once (Alphabet Class A and Class C in Communication Services), so that sector has nine distinct companies unless the eleventh holding is taken from the fund's daily holdings file; which of the two is used is recorded below before collection.

| Sector (ETF) | Ten largest holdings, 9 Oct 2026, in weight order |
|---|---|
| Information Technology (XLK) | NVIDIA; Apple; Microsoft; Advanced Micro Devices; Broadcom; Micron Technology; Intel; Palantir Technologies; Cisco Systems; Applied Materials |
| Health Care (XLV) | Eli Lilly; Johnson & Johnson; AbbVie; Merck; UnitedHealth Group; Thermo Fisher Scientific; Amgen; Gilead Sciences; Abbott Laboratories; Pfizer |
| Financials (XLF) | Berkshire Hathaway; JPMorgan Chase; Visa; Mastercard; Bank of America; Goldman Sachs; Wells Fargo; Morgan Stanley; Citigroup; American Express |
| Consumer Discretionary (XLY) | Amazon; Tesla; Home Depot; McDonald's; TJX Companies; Booking Holdings; Lowe's; Starbucks; Marriott International; DoorDash |
| Communication Services (XLC) | Meta Platforms; Alphabet (two share classes); Walt Disney; Take-Two Interactive; Netflix; AppLovin; AT&T; Comcast; T-Mobile US |
| Industrials (XLI) | Caterpillar; General Electric; GE Vernova; RTX; Eaton; Union Pacific; Deere; Boeing; Uber Technologies; Parker Hannifin |
| Consumer Staples (XLP) | Walmart; Costco Wholesale; Procter & Gamble; Coca-Cola; Philip Morris International; Altria Group; Colgate-Palmolive; Target; Mondelez International; PepsiCo |
| Energy (XLE) | ExxonMobil; Chevron; ConocoPhillips; Marathon Petroleum; Valero Energy; Phillips 66; Williams Companies; EOG Resources; SLB; Kinder Morgan |
| Utilities (XLU) | NextEra Energy; Southern Company; Constellation Energy; Duke Energy; American Electric Power; Dominion Energy; Sempra; Vistra; Entergy; Xcel Energy |
| Real Estate (XLRE) | Welltower; Prologis; Equinix; American Tower; Public Storage; Simon Property Group; Digital Realty Trust; "VIVMARK RESIDENTIAL" as listed on the fund page, to be verified against the holdings file before collection; CBRE Group; Ventas |
| Materials (XLB) | Linde; Newmont; Freeport-McMoRan; Ecolab; Sherwin-Williams; Steel Dynamics; Vulcan Materials; Nucor; Air Products and Chemicals; Martin Marietta Materials |

Known consequence of the rule, stated rather than fixed: some holdings are holding companies or business-to-business firms with little consumer question demand (Berkshire Hathaway, Linde, Prologis). Their answer sets will be small. That is a result about the sector, not a reason to swap them out.

The organization that operates the section studied in Sections 5 and 6 appears in one list by this rule. Its presence is a consequence of the rule and nothing in this study links it to the deployment.

## Instrument and settings

Ahrefs Brand Radar, Explore view, read through the web interface only (no API, no MCP). Previsible's workspace, with Previsible's written permission of 11 October 2026.

- Report per sector: brand = largest holding; competitors = the next nine. If Brand Radar caps competitors below nine, the sector is split into two reports whose domain tables are unioned, and the split is recorded.
- Brand entity: company name as Ahrefs matches it. Domain: the one Ahrefs proposes for the name, recorded in the run log as proposed. The brand's own domain affects only its own citation count, not the outside-source mix this study reports.
- Location: United States.
- Report: Cited pages, "All domains" tab, sorted by Ahrefs' default (responses found in, descending), "First 1,000" rows, CSV UTF-8. Ahrefs caps this export at 1,000 rows.
- Platform filters, one export each: Google AI Overviews (search queries), Google AI Overviews (prompts), Google AI Mode (search queries), Google AI Mode (prompts), ChatGPT, Perplexity, Gemini, Copilot. Grok is paused in Brand Radar and excluded. Plus one export with no platform filter.
- Also read, not exported: the Overview table's response count per platform for the sector's brand set.

Totals: 11 sectors × 9 exports × 1,000 rows = 99,000 export rows, 0 credits.

## Universe, stated

Brand Radar's Explore universe is answers that mention or cite at least one brand in the report. Answers built only from sources outside the ten companies are absent. Outside-source shares are therefore lower bounds, and that bias runs against the study's predictions.

## Source types, fixed before collection

Each domain is assigned by a fixed list written here; any domain not on the list is "other web", which again makes the community and video shares lower bounds.

- video: youtube.com, tiktok.com, vimeo.com
- forum and Q&A: reddit.com, quora.com, stackoverflow.com, stackexchange.com and its subdomains
- social: facebook.com, instagram.com, linkedin.com, x.com, twitter.com, pinterest.com, threads.net
- user publishing: medium.com, substack.com, dev.to, github.com
- reference: wikipedia.org (any language), britannica.com, investopedia.com
- news: reuters.com, apnews.com, bloomberg.com, cnbc.com, wsj.com, nytimes.com, forbes.com, ft.com, washingtonpost.com, theverge.com, techcrunch.com
- government: any .gov domain
- report brands: the ten companies' domains as proposed by Ahrefs
- other web: everything else

## Predictions, registered

- P1. youtube.com is the most cited domain outside the report brands on Google AI Overviews and Google AI Mode in a majority of sectors.
- P2. youtube.com ranks outside the five most cited non-brand domains on ChatGPT, Perplexity and Copilot in a majority of sectors.
- P3. reddit.com is among the ten most cited non-brand domains on every platform except Copilot in a majority of sectors.
- P4. The video-plus-community share of citations is higher in consumer-facing sectors (Consumer Discretionary, Consumer Staples, Communication Services, Health Care, Information Technology) than in Energy, Materials, Utilities, Real Estate and Industrials, on Google AI Overviews.

A prediction that fails is reported as failed.

## Analysis

`04_ANALYSIS/ai_cited_sources/brand_radar_platforms.py`, generalized to read one folder per sector. Shares are of the summed "Cited in" over the exported top 1,000 domains. Every number in the manuscript is printed by the script.

## Storage

Raw CSVs under `03_DATA/raw/brand_radar_sectors_<date>/<sector>/<platform>_top1000.csv`, with `SHA1SUMS.txt` and a README recording export times, report settings and the domains Ahrefs proposed. The same files are loaded into the research Postgres (`vp-research-db`) under a `paper03` schema for visualization; the CSVs in this folder remain the source of record.

## Amendments

**A1, 12 October 2026, before collection.** Owner approved the rule ("Download all data"). Decisions recorded before the first sector export:
- Communication Services runs with nine companies; the eleventh holding is not taken.
- The Real Estate eighth holding "VIVMARK RESIDENTIAL" is Vivmark Residential (NYSE: VMRK), the company formed by the August 2026 merger of AvalonBay Communities and Equity Residential; website vivmarkresidential.com (StockAnalysis company page, read 12 October 2026).
- Brand names and domains are entered from `cross_sector_companies.csv` through report URLs built by `04_ANALYSIS/ai_cited_sources/make_brand_radar_urls.py`, in the exact shape the Ahrefs interface produced for the education pilot, instead of Ahrefs' per-run suggestions. Reason: Ahrefs' suggested competitor set for the same seed differed between two runs forty minutes apart (the suggested competitor set at 22:19 and at 22:55 differed by two of five names), so it is not a reproducible rule. The brand name used is the company's common name; the domain is the company's primary website, both recorded in the CSV. The brand's own domain affects only its own citation count.
- Prompt-level sample (Tier 2) rule: per sector and platform, the 10,000 highest-volume prompts (all if fewer), from the AI responses report sorted by volume descending, exported as CSV UTF-8. Up to 880,000 rows.
- The visualization copy goes into the research Postgres (`vp-research-db`) after the raw files are stored; the CSVs remain the source of record.

**A2, 13 October 2026, after collection.** Recorded after all 99 registered exports were filed and before any manuscript text was written.
- Industrials: the registered brand name "RTX" also matched answers about graphics cards (the ChatGPT list's top domains included nvidia.com and tomshardware.com). A robustness re-run with "RTX Corporation" was exported to `xli_rtxcorp/`; the registered `xli/` files remain the primary data. The re-run's ChatGPT export failed twice with a vendor-side error and is recorded in `xli_rtxcorp/MISSING_chatgpt.txt`.
- Eight exports that repeated an earlier view or mixed two platforms, because a page change did not load before export, were set aside in `_discarded/` with a README and are not used.
- P1 names "Google AI Overviews and Google AI Mode"; each has a prompt set and a search-query set. P1 is scored as holding in a sector only if YouTube ranks first among non-company domains on at least one set of each product, and the per-set counts are reported alongside.
- "Non-brand" in P1 to P3 means not one of the sector's ten company domains as entered (column `domain_used`).
- One exploratory measure, not registered, is reported and labelled as such: the mean pairwise Jaccard overlap of the ten most-cited non-company domains between sectors, per surface.

- Prompt-level sample (A1, last bullet): the AI responses table offers no volume sort that persists in the page address, so each export takes the first rows in Ahrefs' default "relevance" order. On the 1,000-row test export that order is volume-descending except for 3 adjacent inversions. The prompt-level sample is for the registered replication in Section 11 and for visualization; no Section 5.8 result depends on it.

**A3, 13 October 2026, after the Round 9 review.** Corrections of record; no analysis decision in A1 or A2 is changed.
- Status. This file is a design document written before collection. It was not deposited with any registry and was first committed to version control at 01:22 on 13 October 2026 (commit `f6d93f8`), after collection, so its date rests on the author's attestation. The status line at the top ("DRAFT ... Pending owner approval") is superseded by A1, which records the owner's approval. The last bullet of A2 (prompt-level sample order) was appended after that commit, on 13 October; it carries this amendment's date.
- Analysis. Every number in the manuscript comes from `04_ANALYSIS/ai_cited_sources/cross_sector.py`, not `brand_radar_platforms.py` as the Analysis section says; it reduces hosts to registrable domains and sums "Cited in" over hosts. Sensitivity checks added after review are in `cross_sector_sensitivity.py` and are not registered.
- Collection method. Every export in this study, and the answer counts in `sector_answer_counts.csv`, were made through the Ahrefs web interface by an AI browser assistant (Claude in Chrome) operating the owner's logged-in browser: it navigated to report URLs and clicked the interface's own export control. The docstring of `make_brand_radar_urls.py`, which said the interface was "driven by hand", was wrong and is corrected. Ahrefs' terms prohibit using its services "through an automated means" except through its API (clause 4.4(j), read 13 October 2026); collection was stopped when this was found, and whether the collected data may be used and published needs the vendor's written confirmation.
- Prompt-level sample (A1, last bullet). Collection began on 13 October 01:27 and was stopped at 01:39 after 14 of 88 exports: Energy, all eight surfaces, and Utilities, six surfaces (Perplexity and Copilot not made). 44,463 rows are filed in `03_DATA/raw/brand_radar_prompts_2026-10-13/` with `export_log.csv`. They are unanalysed.
- Company properties. A list of 64 secondary domains owned by the listed companies (`cross_sector_company_properties.csv`) was built after collection from each sector's 25 most-cited non-company domains, from general knowledge of ownership rather than filings. It is used only in a sensitivity check; the registered definition (A2) is unchanged.
- Storage. The visualization copy is in a dedicated Postgres container, `paper03-db`, not the shared research database A1 names.
- Release. In the released copy of this file, the education competitor names in A1 are replaced by "the suggested competitor set", so that the pilot's market leader is not named.
- Wording superseded by the manuscript (added 13 October 2026 after the verification round). The title word "pre-registration" and the phrase "pre-registered" are superseded: the file is a design written before collection, with no third-party timestamp. "Outside-source shares are therefore lower bounds" (Universe, stated) and "make the community and video shares lower bounds" (Source types) are superseded: truncation at 1,000 rows biases shares upward and the fixed type list biases them downward, so the net direction is unknown. The registered question's second half (reference, job and forum sources leading on the chat products) was not supported (manuscript Section 5.8).

**A4, 14 October 2026, recording the owner's decision of 13 October 2026.** Written confirmation from the vendor is not treated as a precondition for using or publishing the collected data; this supersedes the last clause of A3's collection-method bullet. The manuscript (Section 14) discloses the clause, the collection method and that no confirmation from the vendor has been obtained.
