"""Version 5.4, 14 November 2026: Section 7.7, Measurement 3's registered source types applied to the author's education
exports for thirteen countries (3,724,208 answers; 04_ANALYSIS/edu_ai_citations/), read after the author had analysed and
published them, so not predicted; and Appendix F, the author's inventory of one hundred sources the framework is meant
to collect, of which this paper has read eight. Every number of Section 7.7 and Table C5 is printed by intl_from_cells.py."""
import unicodedata
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


SEC77 = """### 7.7 The same contrast in one category across thirteen countries

Section 7's contrast was read in one country, in a universe conditional on companies. A later collection relaxes both limits for one category. On 13 and 14 November 2026 the author exported from the same vendor's index every answer whose prompt the vendor files under Jobs and Education > Education, with no site or company filter, for thirteen countries: 3,724,208 answers dated 17 August to 14 November 2026, in 44 export files, each checked against the row count the interface showed (one slice, 1,492 ChatGPT answers for France, failed to export and is missing). These are answer-level rows with each answer's cited pages, not the cited-domain tables of Section 7.2. The author analysed and published the collection, with different source categories, before it was read for this paper [Pagadala 2026b], so nothing here was predicted and this subsection is a replication read after the fact. What was fixed in advance is the measure: the source types registered on 12 October 2026 and Section 7's statistic, applied unchanged by a script that stops if the lists differ (`intl_surface_cells.py`).

**The contrast holds in every country.** Over the 104 cells (thirteen countries by eight vendor views; the smallest holds 1,335 answers), video and community sources take a median 14.0% of citation incidences on Google's four views (bootstrap 95% interval over countries 10.5% to 17.0%) against 0.6% (0.4% to 1.0%) on ChatGPT, Copilot, Perplexity and Gemini. The lowest Google view is above the highest of the other four in 13 of 13 countries, by the narrowest margin in Japan (1.2% against 0.6%; Table C5). The view accounts for 76% of the sum of squares of the cell shares and the country for 13%, against 77% for surface and 14% for sector in Section 7.5. Counted by answers, a median 36.8% of the answers on Google's views cite at least one such source, against 1.3% on the others.

**Limits.** This is one vendor's index, one category and the vendor's own filing of prompts: by a labelled sample the author reports, roughly one answer in ten is not about education [Pagadala 2026b]. The registered lists name platforms prominent in the United States, so community sources local to a country, a question site in Japan for example, count as other websites, and the shares outside the United States are floors. Google's views hold 91.6% of the answers. The surfaces are again tracked on query sets of different size, so a difference between surfaces may partly reflect the questions each is asked. Shares here are over every cited domain of every answer, not over a cell's 1,000 most-cited domains, so their levels are not comparable with Section 7.3's; the ordering of surfaces is. How the exports were made, and under which permission and terms, is stated in Section 14; the rows are not redistributed, and the per-cell counts are in the source bundle (`edu_ai_citations_intl/`).

"""

TABLE_C5 = """*Table C5. Section 7.7 by country: answers, and the video and community share of citation incidences on the lowest of Google's four views against the highest of the other four surfaces. Source: Ahrefs Brand Radar, AI responses, education prompts, exported 13 and 14 November 2026; source types as registered for Section 7; printed by `intl_from_cells.py`.*

| Country | Answers | Lowest Google view | Highest other surface |
|---|---|---|---|
| United States | 1,456,743 | 9.3% | 2.8% |
| India | 629,880 | 9.5% | 2.1% |
| Japan | 274,068 | 1.2% | 0.6% |
| United Kingdom | 222,184 | 4.9% | 2.4% |
| Indonesia | 170,993 | 14.0% | 1.5% |
| Brazil | 161,570 | 15.7% | 2.9% |
| Mexico | 141,634 | 17.0% | 2.5% |
| Canada | 131,414 | 7.2% | 3.6% |
| Australia | 128,845 | 4.5% | 2.3% |
| France | 111,959 | 3.6% | 1.1% |
| Germany | 109,804 | 4.2% | 1.5% |
| Philippines | 93,035 | 16.7% | 4.7% |
| Spain | 92,079 | 7.7% | 2.3% |

"""

APPENDIX_F = """
## Appendix F: The sources the framework is meant to collect

The framework's first step is to go where an industry's customers already talk. The implementation declares thirteen surface types (Figure 1a); the inventory below is the author's working list, of November 2026, of the concrete sources behind them: one hundred, in ten groups. It is a plan for collection and not a record of it. This paper has read eight of the hundred, in four of the ten groups, each through the instrument its section names; the other ninety-two are unread. Search is one group of ten, and the framework's premise is that the other nine hold what search volume does not show, which Sections 6 and 7 begin to test and Section 13 specifies.

*Table F1. One hundred sources in ten groups (the author's inventory, November 2026). Bold marks the eight read in this paper: Google Search through two vendors' rankings and a third's keyword volume (Sections 5 and 6), five AI answer engines through one vendor's index (Section 7), Wikipedia through its public request counts (Section 6.2) and Google Business reviews through a licensed export (Section 6.1).*

| Group | Sources |
|---|---|
| 1. Search and discovery | **Google Search**, Google autocomplete, People also ask, Google Trends, Bing, DuckDuckGo, YouTube search, Amazon search, App Store search, Pinterest |
| 2. AI answer engines | **ChatGPT**, **Perplexity**, **Gemini**, Claude, **Copilot**, **Google AI Overviews**, Meta AI, Grok, You.com, DeepSeek |
| 3. Video and audio | YouTube videos, YouTube comments, YouTube live chat, TikTok, Instagram Reels, Twitch, Spotify podcasts, Apple Podcasts, Vimeo, webinar replays |
| 4. Social | X posts and replies, LinkedIn posts, LinkedIn comments, Facebook groups, Facebook pages, Instagram comments, Threads, Bluesky, Snapchat, Nextdoor |
| 5. Communities and Q&A | Reddit, Quora, Stack Exchange, Stack Overflow, Discord servers, Slack communities, Hacker News, Product Hunt, brand support forums, XDA and niche forums |
| 6. Expert and long-form | Substack, Medium, Hugging Face, GitHub issues, arXiv, Google Scholar, **Wikipedia**, Wikidata, conference notes, industry newsletters |
| 7. Company and market | SEC filings, earnings calls, investor presentations, press releases, job postings, competitor sitemaps, competitor pricing pages, Crunchbase, patents, analyst reports |
| 8. Marketplace reviews | Amazon reviews and Q&A, Best Buy reviews, Target reviews, Costco reviews, Walmart reviews, Home Depot reviews, eBay listings, Etsy reviews, Wayfair reviews, Newegg reviews |
| 9. Ratings and responses | **Google Business reviews**, owner responses to reviews, Yelp, Trustpilot, Better Business Bureau, G2, Capterra, Glassdoor, App Store reviews, Google Play reviews |
| 10. Your own and public data | Site search logs, support tickets, chat transcripts, call center logs, sales call notes, surveys and NPS verbatims, Regulations.gov, Census and data.gov, court records, Common Crawl |
"""

rep([
    ("Manuscript version 5.3, 3 November 2026. Preprint, not yet peer reviewed.", "Manuscript version 5.4, 14 November 2026. Preprint, not yet peer reviewed."),
    # abstract and contribution
    ("in every sector. Traffic estimates and cited sources therefore have to be measured",
     "in every sector; a later read of education answers in thirteen countries, not predicted, shows the same contrast in every country (14.0% against 0.6%). Traffic estimates and cited sources therefore have to be measured"),
    ("It motivates a per-surface term the framework does not yet have.",
     "A later read of one category in thirteen countries, with the same registered source types and no prediction, shows the same contrast in every country (Section 7.7). It motivates a per-surface term the framework does not yet have."),
    # framework: the inventory
    ("The implementation declares thirteen surface types (Figure 1a) and ships two generic file adapters, for CSV and JSON Lines; collection from each platform is left to the deployment.",
     "The implementation declares thirteen surface types (Figure 1a) and ships two generic file adapters, for CSV and JSON Lines; collection from each platform is left to the deployment. Appendix F lists the one hundred concrete sources the framework is meant to collect, of which this paper has read eight."),
    ("The thirteen surface types the implementation declares are a snapshot.", "The thirteen surface types the implementation declares, and the hundred sources of Appendix F, are a snapshot."),
    # the subsection and its table
    ("## 8 The deployment series\n", SEC77 + "## 8 The deployment series\n"),
    ("## Appendix D: Metrics, values and scripts\n", TABLE_C5 + "## Appendix D: Metrics, values and scripts\n"),
    # threats and Section 13
    ("Section 7.6 lists the rest.", "Section 7.6 lists the rest. Section 7.7 relaxes two of these for one category, after the fact and with no prediction: thirteen countries, and no company filter."),
    ("those rows are stored and unanalyzed, and the study's predictions are not yet written.",
     "those rows are stored and unanalyzed, and the study's predictions are not yet written. Section 7.7 is a partial step of this kind in one category: answer-level rows for thirteen countries, read after the fact."),
    # Section 14
    ("and Semrush has not been asked whether that falls within those terms.",
     "and Semrush has not been asked whether that falls within those terms. The exports of Section 7.7 were made on 13 and 14 November 2026 from the same vendor's web interface, by the author according to the author's statement; the records kept with them show a script, run by an AI coding assistant, filing each downloaded file and checking its row count, and no script operating the vendor's interface. By the collection's own notes they were made in the agency's workspace; whether the agency's permission of 11 October covers them and their publication is not established here. An earlier set of education exports for 33 named sites, made on 1 October 2026 before that permission, is not used in this paper."),
    ("no keyword, per-keyword volume or per-code score is released.",
     "no keyword, per-keyword volume or per-code score is released. For Section 7.7, the counts per country and view and the scripts are prepared for release alongside; the answer-level rows are not redistributed."),
    ("four further agents reviewed the plan before it was stamped, and the author had not read it when it was stamped.",
     "four further agents reviewed the plan before it was stamped, and the author had not read it when it was stamped. Section 7.7's scripts and text were written by an AI agent from the author's exports, and Appendix F transcribes the author's inventory."),
    # conclusion and Table D1
    ("That is why a per-surface term is the framework's next design question.",
     "A later read of education answers in thirteen countries, not predicted, shows the same contrast in every one of them. That is why a per-surface term is the framework's next design question."),
    ("| M3 predictions | P1 to P4 as written before collection | one held, one in direction, two failed | `cross_sector` |\n",
     "| M3 predictions | P1 to P4 as written before collection | one held, one in direction, two failed | `cross_sector` |\n"
     "| M3 across countries (Section 7.7; not predicted) | median video and community share of citation incidences, Google's four views against the other four, over 104 cells in thirteen countries, bootstrap over countries; countries where the lowest Google view exceeds the highest other surface | 14.0% (10.5 to 17.0) against 0.6% (0.4 to 1.0); 13 of 13 | `intl_surface_cells`, `intl_from_cells` |\n"),
    # Appendix A and the author's two notes
    ("and the first-comparison claim of Section 1 now rests on the two searches that tested it.\n",
     "and the first-comparison claim of Section 1 now rests on the two searches that tested it.\n- **Version 5.4** adds Section 7.7, Table C5 and Appendix F and changes no earlier result.\n"),
    ("is set out in a separate note [Pagadala 2026].", "is set out in a separate note [Pagadala 2026a]."),
])
if "## Appendix F:" in s:
    raise SystemExit("REFUSE: Appendix F already present")
s = s.rstrip("\n") + "\n" + APPENDIX_F

head, refs_and_rest = s.split("\n## References\n", 1)
refs, rest = refs_and_rest.split("\n## Appendix A", 1)
lines = refs.split("\n")
hits = [i for i, x in enumerate(lines) if x.startswith("Pagadala, V.")]
if len(hits) != 1 or "(2026" not in lines[hits[0]] or "(2026a" in lines[hits[0]]:
    raise SystemExit("REFUSE: the author's note is not in the reference list once")
lines[hits[0]] = lines[hits[0]].replace("(2026", "(2026a", 1)
lines[hits[0] + 1:hits[0] + 1] = ["", "Pagadala, V. (2026b). *AI search citations in education by country (2026)* [Author's study page, with data files]. Retrieved November 14, 2026, from https://venkatapagadala.com/ai-retrieval-citations-research/education-industry/by-country"]
s = head + "\n## References\n" + "\n".join(lines) + "\n## Appendix A" + rest
P.write_text(s)
print(f"{len(s.split()):,} words")
