"""Section 7.7's numbers from the released aggregates (edu_intl_cells.csv: one row per country and vendor view, counts only).
The measure is Section 7's: the share of a cell's citation incidences that fall on video and community sources, with the
source types registered on 12 October 2026. Also printed: the share of answers citing at least one such source. Bootstrap over
countries, 10,000 resamples, seed 20261114. Exploratory: the data had been analysed and published by the author before this
script was written. Usage: python3 intl_from_cells.py"""
import csv
import statistics
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CELLS = ROOT / "03_DATA/processed/edu_intl_cells.csv" if (ROOT / "03_DATA/processed/edu_intl_cells.csv").is_file() else HERE / "edu_intl_cells.csv"
GOOGLE = ["Google AI Overviews (search queries)", "Google AI Overviews", "Google AI Mode (search queries)", "Google AI Mode"]
OTHER = ["ChatGPT", "Copilot", "Perplexity", "Gemini"]
NAMES = {"us": "United States", "in": "India", "jp": "Japan", "gb": "United Kingdom", "id": "Indonesia", "br": "Brazil", "mx": "Mexico",
         "ca": "Canada", "au": "Australia", "fr": "France", "de": "Germany", "ph": "Philippines", "es": "Spain"}
COMM = ("video", "forum", "social", "user_publishing")
R = {(r["country"], r["view"]): {k: int(v) for k, v in r.items() if k not in ("country", "view")} for r in csv.DictReader(CELLS.open())}
C = sorted({c for c, _ in R}, key=lambda c: -sum(R[(c, v)]["answers"] for v in GOOGLE + OTHER if (c, v) in R))
OUT = []


def say(s=""):
    print(s)
    OUT.append(s)


def inc(c, v):
    x = R[(c, v)]
    return sum(x["inc_" + k] for k in COMM) / x["incidences"]


def ans(c, v):
    return R[(c, v)]["ans_video_community"] / R[(c, v)]["answers"]


say("== 1. Cells")
tot = sum(x["answers"] for x in R.values())
missing = [(c, v) for c in C for v in GOOGLE + OTHER if (c, v) not in R]
sizes = sorted((x["answers"], k) for k, x in R.items())
say(f"  countries {len(C)}; cells {len(R)} of {len(C) * 8}; missing {missing}; answers {tot:,}; citation incidences {sum(x['incidences'] for x in R.values()):,}")
say(f"  smallest cell {sizes[0][0]:,} answers ({NAMES[sizes[0][1][0]]}, {sizes[0][1][1]}); largest {sizes[-1][0]:,}; cells under 1,000 answers: {sum(n < 1000 for n, _ in sizes)}")
say(f"  answers on Google's four views: {100 * sum(x['answers'] for (c, v), x in R.items() if v in GOOGLE) / tot:.1f}%")

for label, f in (("share of citation incidences on video and community sources (Section 7's measure)", inc),
                 ("share of answers citing at least one video or community source", ans)):
    say(f"\n== {label}")
    g = [f(c, v) for c in C for v in GOOGLE]
    o = [f(c, v) for c in C for v in OTHER]
    say(f"  median over cells: Google's four views {100 * statistics.median(g):.1f}%, the other four {100 * statistics.median(o):.1f}%")
    rng = np.random.default_rng(20261114)
    bg, bo = [], []
    for _ in range(10000):
        idx = rng.integers(0, len(C), len(C))
        bg.append(statistics.median(f(C[i], v) for i in idx for v in GOOGLE))
        bo.append(statistics.median(f(C[i], v) for i in idx for v in OTHER))
    say(f"  bootstrap over countries, 95%: Google {100 * np.percentile(bg, 2.5):.1f}% to {100 * np.percentile(bg, 97.5):.1f}%; others {100 * np.percentile(bo, 2.5):.1f}% to {100 * np.percentile(bo, 97.5):.1f}%")
    for v in GOOGLE + OTHER:
        x = [f(c, v) for c in C]
        say(f"    {v}: median {100 * statistics.median(x):.1f}%, range {100 * min(x):.1f}% to {100 * max(x):.1f}%")
    k = 0
    say("  per country, lowest of Google's views against highest of the other four:")
    for c in C:
        lo, hi = min(f(c, v) for v in GOOGLE), max(f(c, v) for v in OTHER)
        k += lo > hi
        say(f"    {NAMES[c]} ({sum(R[(c, v)]['answers'] for v in GOOGLE + OTHER):,} answers): {100 * lo:.1f}% against {100 * hi:.1f}%" + ("" if lo > hi else "   NOT higher"))
    say(f"  countries where the lowest Google view exceeds the highest other surface: {k} of {len(C)}")
    M = np.array([[f(c, v) for v in GOOGLE + OTHER] for c in C])
    gm = M.mean()
    ss = ((M - gm) ** 2).sum()
    say(f"  two-way split of the sum of squares of cell shares: view {100 * len(C) * ((M.mean(0) - gm) ** 2).sum() / ss:.0f}%, country {100 * 8 * ((M.mean(1) - gm) ** 2).sum() / ss:.0f}%")

say("\n== Video alone (YouTube, TikTok, Vimeo): share of answers citing at least one, platforms pooled as on the published pages")
for c in C:
    row = []
    for name, vs in (("AI Overviews", GOOGLE[:2]), ("AI Mode", GOOGLE[2:]), ("ChatGPT", ["ChatGPT"]), ("Perplexity", ["Perplexity"]), ("Copilot", ["Copilot"]), ("Gemini", ["Gemini"])):
        a = sum(R[(c, v)]["answers"] for v in vs)
        row.append(f"{name} {100 * sum(R[(c, v)]['ans_video'] for v in vs) / a:.1f}")
    say(f"  {NAMES[c]}: " + "; ".join(row))
(HERE / "intl_from_cells_output.txt").write_text("\n".join(OUT) + "\n")
