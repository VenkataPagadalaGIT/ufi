# Section 7.7: Measurement 3's source types on education answers in thirteen countries

| File | What it is |
|---|---|
| `intl_surface_cells.py`, `intl_surface_cells_output.txt` | reads the 44 raw exports (not redistributed; they stay with the author) and counts, per country and vendor view, answers, citation incidences and the incidences and answers on Section 7's registered source types; stops if the type lists differ from Section 7's; its output shows every file's row count against the exports' ledger |
| `edu_intl_cells.csv` (in `03_DATA/processed/`; beside this file in the release) | the counts: 104 cells, no prompt, answer text or URL |
| `intl_from_cells.py`, `intl_from_cells_output.txt` | prints every number of Section 7.7 and Table C5 from the counts |
| `export_ledger.jsonl`, `export_gaps.json` | the collection's own record of each export file: name, rows returned and rows the interface showed, checksum, counts per vendor view, and the one slice that failed to export. 45 rows: the 44 files of Section 7.7 (`selection` is `educat`) and one further export for Spain that Section 7.7 does not use. No prompt, answer text or URL |
| `site_surface_contrast.py`, `verify_spain_from_raw.py` and outputs (project only) | checks of the author's published figures: the per-platform video shares on the published pages, and Spain's published counts against its raw export |

The exports were analysed and published by the author before these scripts were written (venkatapagadala.com, "AI Search
Citations in Education by Country"), so nothing here was predicted. What was fixed in advance is the measure: the source
types and the domain rule of `04_ANALYSIS/ai_cited_sources/cross_sector.py`, registered on 12 October 2026.

Run: `python3 intl_from_cells.py` (needs only the counts). `intl_surface_cells.py` needs the raw exports.
