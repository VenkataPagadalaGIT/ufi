"""Section 7.7: Measurement 3's source types, unchanged, on the author's education exports for thirteen countries.

Reads the 44 Ahrefs Brand Radar "AI responses" exports of 13 to 14 November 2026 (every answer the vendor files under Jobs and
Education > Education, no site filter; 3,724,208 answers), which stay in ~/Downloads/edu_intl_2026-11-14/ and are not
redistributed (03_DATA/raw/edu_ai_citations_2026-11/). For each country and each of the eight vendor views it counts answers,
citation incidences (an answer citing a registrable domain at least once, Section 7's "Cited in") and the incidences and
answers that fall on Section 7's registered source types. The type lists and the domain rule are those of
04_ANALYSIS/ai_cited_sources/cross_sector.py, fixed on 12 October 2026, and this script stops if they differ.

Writes 03_DATA/processed/edu_intl_cells.csv (aggregates only: no prompt, answer text or URL) and prints row checks against
the exports' ledger. Usage: python3 intl_surface_cells.py"""
import ast
import collections
import csv
import gzip
import json
import sys
from pathlib import Path
from urllib.parse import urlsplit

csv.field_size_limit(10**9)
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
RAW = Path.home() / "Downloads/edu_intl_2026-11-14/brand_radar_educat"
LEDGER = ROOT / "03_DATA/raw/edu_ai_citations_2026-11/ledger.jsonl"
if not RAW.is_dir() or not LEDGER.is_file():
    raise SystemExit("needs the research project and the raw exports in ~/Downloads/edu_intl_2026-11-14/ (not redistributed); "
                     "intl_from_cells.py prints Section 7.7's numbers from the released aggregates")

TYPES = {
    "video": {"youtube.com", "tiktok.com", "vimeo.com"},
    "forum": {"reddit.com", "quora.com", "stackoverflow.com", "stackexchange.com"},
    "social": {"facebook.com", "instagram.com", "linkedin.com", "x.com", "twitter.com", "pinterest.com", "threads.net"},
    "user_publishing": {"medium.com", "substack.com", "dev.to", "github.com"},
}
COMMUNITY = ("video", "forum", "social", "user_publishing")
TWO_LEVEL = {"co", "com", "org", "net", "gov", "ac", "edu"}
src = ROOT / "04_ANALYSIS/ai_cited_sources/cross_sector.py"
if src.is_file():  # the registered lists, read from the Section 7 script itself
    reg = {}
    for node in ast.parse(src.read_text()).body:
        if isinstance(node, ast.Assign) and node.targets[0].id in ("TYPES", "COMMUNITY", "TWO_LEVEL"):
            reg[node.targets[0].id] = ast.literal_eval(node.value)
    if {k: reg["TYPES"][k] for k in COMMUNITY} != TYPES or tuple(reg["COMMUNITY"]) != COMMUNITY or reg["TWO_LEVEL"] != TWO_LEVEL:
        raise SystemExit("REFUSE: the source types differ from Section 7's registered lists")
KIND = {d: t for t, ds in TYPES.items() for d in ds}


def registrable(host):  # Section 7's rule (cross_sector.py), unchanged
    d = host.strip().lower().removeprefix("www.")
    if d.endswith("wikipedia.org"):
        return "wikipedia.org"
    parts = d.split(".")
    if len(parts) > 2 and parts[-2] in TWO_LEVEL and len(parts[-1]) == 2:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:])


cells = collections.defaultdict(collections.Counter)
files = sorted(RAW.glob("brand-radar_ai-responses_*_educat_*_2026-11-14.csv.gz"))
per_file = {}
for f in files:
    n = 0
    with gzip.open(f, "rt", encoding="utf-8-sig", newline="") as h:
        rd = csv.reader(h)
        head = next(rd)
        iC, iM, iP = head.index("Country"), head.index("Model"), head.index("Cited pages")
        for r in rd:
            n += 1
            c = cells[(r[iC], r[iM])]
            c["answers"] += 1
            doms = {registrable(urlsplit(u.strip()).netloc) for u in r[iP].split("\n") if u.strip()}
            doms.discard("")
            if not doms:
                continue
            c["answers_citing"] += 1
            c["incidences"] += len(doms)
            kinds = set()
            for d in doms:
                k = KIND.get(d)
                if k:
                    c["inc_" + k] += 1
                    kinds.add(k)
            for k in kinds:
                c["ans_" + k] += 1
            if kinds:
                c["ans_video_community"] += 1
            if "youtube.com" in doms:
                c["ans_youtube"] += 1
    per_file[f.name] = n
    print(f"{f.name}: {n:,} rows", flush=True)

led = {}
for line in LEDGER.read_text().splitlines():
    r = json.loads(line)
    if r.get("selection") == "educat":
        led[r["file"] + ".gz"] = r["rows"]
bad = [f for f in per_file if per_file[f] != led.get(f)]
print(f"files {len(per_file)}; rows {sum(per_file.values()):,}; files whose row count differs from the ledger: {len(bad)} {bad}")
cols = ["answers", "answers_citing", "incidences"] + ["inc_" + k for k in COMMUNITY] + ["ans_" + k for k in COMMUNITY] + ["ans_video_community", "ans_youtube"]
out = ROOT / "03_DATA/processed/edu_intl_cells.csv"
with out.open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["country", "view"] + cols)
    for (cc, view) in sorted(cells):
        w.writerow([cc, view] + [cells[(cc, view)][k] for k in cols])
print(f"wrote {out.relative_to(ROOT)}: {len(cells)} cells")
