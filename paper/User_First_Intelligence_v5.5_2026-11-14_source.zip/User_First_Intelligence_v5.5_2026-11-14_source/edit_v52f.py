"""Version 5.2, the stakes of Measurement 1 shown rather than asserted (independent measurement, relevance 6.0: "the
stakes are asserted ... no evidence of how many studies or decisions rest on single-vendor magnitudes"). Counts from
04_ANALYSIS/stakes/vendor_reliance_output.txt (OpenAlex, read 14 October 2026)."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()
if 'works name Ahrefs, Semrush or Similarweb in their title or abstract' in s:  # this script inserts the stakes sentence; later edits changed its wording, so check for the passage itself
    raise SystemExit("REFUSE: already applied (the stakes sentence is present)")


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:  # already applied: an insertion keeps its anchor, so a second run would insert twice
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("a practice the validity studies in Section 2 caution against [Kamerer 2013; Prantl & Prantl 2018; Jansen, Jung & Salminen 2022].",
     "a practice the validity studies in Section 2 caution against [Kamerer 2013; Prantl & Prantl 2018; Jansen, Jung & Salminen 2022]. The practice is growing: in OpenAlex, 459 works name Ahrefs, Semrush or Similarweb in their title or abstract, 28 of them published in 2020, 88 in 2025 and 111 in 2026 to mid-October, and 86% name only one of the three, which suggests, without proving, reliance on a single vendor's figures (`vendor_reliance.py`, released with the paper's data)."),
    ("| M1 visits ratio | Semrush over Ahrefs estimated monthly visits: unmatched; worldwide; US to US (estimated) |",
     "| Stakes | works in OpenAlex naming Ahrefs, Semrush or Similarweb in title or abstract; share naming only one | 459; 86% (read 14 October 2026) | `vendor_reliance` |\n| M1 visits ratio | Semrush over Ahrefs estimated monthly visits: unmatched; worldwide; US to US (estimated) |"),
])
P.write_text(s)
print(f"{len(s.split()):,} words")
