"""Version 5.0, Round 10 fixes: the PhD examiner (08_REVIEW/R10_phd_examiner.md, E1 to E28) and the TOIS
editorial panel (08_REVIEW/R10_editorial_TOIS.md, E2 to E26) items fixable by editing or by analysis of
data already held. New numbers come from 04_ANALYSIS/instrument_divergence/instrument_extra_output.txt and
04_ANALYSIS/review_demand/supplement_r10_output.txt; new references were verified on Crossref, arXiv and
OpenAlex on 13 October 2026. Exact replacements; each must match once.
"""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:  # already applied: an insertion keeps its anchor, so a second run would insert twice
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    # abstract (TOIS E2, PhD E24)
    ("review demand and search volume agree across branches (Spearman +0.78) but barely across topics (+0.19)",
     "review demand and search volume rank the taxonomy's branches alike (Spearman +0.75) but barely agree on topics (+0.19)"),
    # introduction (TOIS E6, PhD E5, click models)
    ("Almost every empirical claim in applied search research rests on a commercial analytics platform.",
     "Much of the empirical evidence in applied search research rests on commercial analytics platforms."),
    ("What has not been reported, to the author's knowledge, is a direct, longitudinal comparison of two vendors on a single object with a known start date; this paper reports one.",
     "What has not been reported, to the author's knowledge, is a direct comparison of two vendors' records of a single object from a known start date; this paper reports one."),
    ("which describes click models over estimated volumes at estimated positions.",
     "which describes click models, of the kind studied in information retrieval [Chuklin, Markov & de Rijke 2015], applied to estimated volumes at estimated positions."),
    # Measurement 1 as an instrument-validity result on the outcome layer (PhD E1, E2; TOIS E9)
    ("For a framework whose premise is that volume tools see demand only partly and imprecisely, that number matters: it shows that one tool's magnitudes cannot be trusted alone, which is why the framework does not rely on a single source of demand.",
     "For a framework that reads its outcomes on such instruments (Figure 1b), that number matters: it bounds how far one platform's magnitudes can be trusted, which is why the framework reads its outcomes on more than one."),
    ("Each measurement bears on one part of the framework and is stated with what it does not show: Measurement 1 on the premise that one volume tool's magnitudes do not transfer to another,",
     "The paper's original contribution is Measurement 1: two commercial analytics platforms' estimates of the same pages differ by up to thirty times, in no fixed direction across sections, while the platforms mostly agree on how the sections rank, so no constant converts one into the other. Around it, the paper specifies, and does not evaluate, a framework for finding content gaps from demand observed beyond the search box. Each measurement bears on one part of the framework and is stated with what it does not show: Measurement 1 on the outcome layer, where a content program's results are read on analytics platforms,"),
    ("2. **Measurement 1, two instruments on one prefix** (Section 5), bearing on the premise that volume tools see demand only partly and imprecisely.",
     "2. **Measurement 1, two instruments on one prefix** (Section 5), an instrument-validity result bearing on the framework's outcome layer."),
    ("the two demand signals agree across branches and diverge across topics, most for complaints.",
     "the two demand signals rank the taxonomy's branches alike but size them very differently, and barely agree on topics, most for complaints."),
    ("an observation that each of the five most-cited enumerating hub pages is cited in more AI answers than any per-entity page (1.2 to 2.0 times the most-cited one),",
     "an observation, offered as a hypothesis because a hub pools questions about many codes, that each of the five most-cited hub pages is cited in more AI answers than any per-entity page (1.2 to 2.0 times the most-cited one),"),
    # Section 1.4 (PhD E17)
    ("none of its three measures takes a per-surface input,", "neither its two measures nor its score takes a per-surface input,"),
    # related work (PhD E11, TOIS E7)
    ("which separates disagreement about a site from disagreement about a section of it.",
     "which separates disagreement about a site from disagreement about a section of it. Comparisons of estimators with first-party analytics have found large and variable errors: Compete and Quantcast underestimated traffic for 18 sites, with occasional overestimates [Kamerer 2013], and neither Alexa nor SimilarWeb ranked Czech websites accurately, although both indicated their approximate size [Prantl & Prantl 2018]. Closest to this paper, a comparison of SimilarWeb with Google Analytics on 86 sites found significant differences in level, rank orderings that correlated, and differences systematic enough to estimate one service's figures from the other's for related sites [Jansen, Jung & Salminen 2022]. Section 5.5 finds the same agreement on ordering between two estimators and the opposite on calibration: across twelve sections of one site, the ratio between them is not systematic."),
    ("Users click less when a summary appears and rarely click its sources:",
     "Generative engine optimization was introduced as a way to raise a source's visibility in generated answers [Aggarwal et al. 2024]; the citations of generative search engines have been audited for whether they support the statements they accompany [Liu, Zhang & Liang 2023]; and the evaluation of retrieval has been reframed for systems that generate rather than rank [Gienapp et al. 2024]. Users click less when a summary appears and rarely click its sources:"),
    ("argues that the foundational GEO paper's gains establish neither", "argues that the foundational paper's gains establish neither"),
    ("The gap between the unit a user has in mind and the unit a retrieval system indexes is old ground [Belkin, Oddy & Brooks 1982; Taylor 1968],",
     "People take questions to their social networks [Morris, Teevan & Panovich 2010] and to question-answering sites when web search fails [Liu et al. 2012], and phrase questions differently from queries [White, Richardson & Yih 2015]. The gap between the unit a user has in mind and the unit a retrieval system indexes is old ground [Belkin, Oddy & Brooks 1982; Taylor 1968],"),
    ("one need expressed as thousands of distinct strings.", "one need expressed as many distinct strings (the 381 code pages rank for 29,000 keywords on one instrument)."),
    # Section 4.1 (TOIS E11, E21)
    ("The section ranks in 105 countries with 18.5% of Ahrefs' estimated visits from outside the US,",
     "The section ranks in 105 countries with 18.5% of Ahrefs' estimated visits from outside the US (18.6% in the 12 October read of Table 4),"),
    ("**They are models, not counters.** Estimated visits are a click model over an estimated volume at an estimated position. No figure in this paper is a measured visit.",
     "**They are models, not counters.** Estimated visits are a click model over an estimated volume at an estimated position. No figure in this paper is a measured visit.\n\n**How the figures were read.** Every vendor figure was read from the vendors' web interfaces by an AI browser assistant operating the author's logged-in browser, under the author's direction, with no API (Section 14). Monthly figures are each instrument's own history as read on the stated date, not values captured month by month; a vendor may revise its history, and the 13 October re-read of Semrush found its completed months unrevised."),
    # Section 5.1 (PhD E3, E5; TOIS E5)
    ("**The October row is each instrument's current monthly run-rate as read on 10–11 October, not eleven days of accumulated traffic**, and is marked accordingly.",
     "**The October row is each instrument's current monthly run-rate as read on 10–11 October, not eleven days of accumulated traffic**, and is marked accordingly. Every row is the instrument's history as read on that date."),
    ("**The disagreement is larger than the quantity most papers report.** An applied paper reporting a 40% lift from a technique, measured on one of these instruments, is reporting an effect roughly one twentieth the size of the disagreement between instruments about the level.",
     "**The instruments disagree about change as well as level.** A constant difference in level would cancel in a comparison of growth within one instrument, so the question for an applied study is whether the two agree on how much a section grew. From July to August they did (8.4x on Ahrefs, 8.8x on Semrush US); from August to September Ahrefs' estimate grew 4.65x and Semrush's 1.75x, and into October's run-rate 1.44x against 1.05x. A month's lift measured on one instrument can therefore differ from the same lift on the other by a factor of more than two."),
    # Section 5.3 intervals (PhD E20, TOIS E12)
    ("It is reported because numerator and denominator come from one instrument on one date, and no trend is drawn from it.",
     "It is reported because numerator and denominator come from one instrument on one date, and no trend is drawn from it. Its Wilson interval treats the month's AI Overview keywords as draws from a stable process: it shows binomial noise in the ratio, not the instrument's error."),
    # Section 5.4 (PhD E19)
    ("against 913 on 11 October, and its new-and-lost report for September gives 917 new against 95 lost, which with nineteen at day 37 implies 841.",
     "against 913 on 11 October, and its new-and-lost report for September gives 917 new against 95 lost, which with nineteen at day 37 implies about 841 at the end of September, an earlier date; the three figures are consistent with a count still rising."),
    ("which with nineteen at day 37 implies 841. Three figures for quantities that should nearly agree. The gap is partly explained by domains gained and lost within the month counting in both columns, and not wholly.",
     "which with nineteen at day 37 implies about 841 at the end of September. The three figures are for different dates (the end of September, day 75 and day 77), so they need not agree, and their order is consistent with the network still arriving."),
    # Section 5.5 (PhD E12, E13, E14; TOIS E17; PhD E4)
    ("the area-code section and eleven others chosen to span ages from under two years to the instrument's horizon.",
     "the area-code section and eleven others chosen by the author to span ages from under two years to the instrument's horizon; the selection was purposive, not random, and the results describe these twelve."),
    ("and no single correction factor maps one onto the other.",
     "and no single correction factor maps one onto the other. Taken across the twelve, the unmatched ratio has a geometric mean of 1.13 and a geometric standard deviation of 3.1; read as a spread for another section of this domain, it runs from about 0.12x to 10.6x."),
    ("The consequence for practice is restated in Section 5.6 in that form.",
     "The agreement depends on how different two sections are in size: of the pairs whose sizes, taken as the geometric mean of the two estimates, differ by more than a factor of three, all 51 are ordered alike; of the 15 pairs within a factor of three, 9 are. The consequence for practice is restated in Section 5.6 in that form."),
    ("The larger part of the disagreement is therefore in what each vendor's click model assigns to a discovered keyword, not in how many keywords it discovered, which is consistent with the decomposition in Section 5.6 and inconsistent with the mechanism version 4.0 proposed.",
     "Across sections, then, the keyword universe does not predict the visits ratio, which is inconsistent with the mechanism version 4.0 proposed; how much of the area-code section's own divergence the keyword universe accounts for depends on the territory pairing (Section 5.6)."),
    # Section 5.6 (PhD E18, E4, E2, E12; TOIS E16, E4)
    ("In absolute terms the bound is larger: the two readings differ by at least 13 times the smaller one.",
     "In absolute terms the bound is larger: the larger of the two errors is at least 13 times the smaller reading."),
    ("The index-coverage hypothesis is also the minority term where it can be checked. On 10–11 October, the only date both the visits and the keyword-universe figures were read, the divergence decomposes as",
     "Where it can be checked, the index-coverage term is not negligible, and its size depends on the territory pairing. With Semrush's US figures against Ahrefs' worldwide ones, read on 10 and 11 October, the divergence decomposes as"),
    ("so the keyword universe accounts for about 35% of the divergence in log terms and the click model applied to each discovered keyword accounts for 65%. Whatever drives the narrowing, the larger component at that date is not how much surface each vendor has discovered.",
     "so the keyword universe accounts for about 35% of the divergence in log terms. With both read worldwide (keywords read on 12 October), it is 8.62x = 3.19x (keyword universe) × 2.70x (per keyword), and the keyword universe accounts for about 54%. How Semrush aggregates its worldwide keyword count across national databases is not documented in the report, so the decomposition is reported both ways and no claim is made about which component is larger."),
    ("so a single-vendor ranking of sections is usually right in direction; the magnitude of any difference,",
     "so a single-vendor ranking of sections is right in direction when sections differ several-fold in size and less reliable when they are within a factor of three (9 of 15 pairs); the magnitude of any difference,"),
    ("An effect of the size applied papers usually report is small against that.",
     "Growth measured on the two instruments also differed, by a factor of 2.7 in one month (Section 5.1)."),
    ("It is also the measurement that motivates the framework in Figure 1: a content program that needs the magnitude of demand for a topic cannot read it from one volume tool alone. That the demand which never reaches a search box differs in which topics it names and in what form it takes is the framework's hypothesis, not a consequence of this measurement, and Section 13 specifies its test.",
     "It bears on the framework's outcome layer (Figure 1b): a content program that reads its results on one platform cannot take the magnitudes at face value. Whether demand that never reaches a search box differs in topic and form is the framework's separate hypothesis, which Measurement 2 begins to test and Section 13 specifies."),
    # Section 6 (TOIS E2, E3, E18; PhD E9, E27)
    ("At the level of the taxonomy's 17 top-level branches the two signals agree: the share of review mentions and the share of search volume have a rank correlation of +0.78 (p < 0.001; Figure 6b). At the level of topics they barely do. Across the 1,008 labels the rank correlation between review mentions and monthly volume is +0.19 (Kendall's tau +0.13), +0.28 among the 213 labels with at least twenty mentions,",
     "At the level of the taxonomy's 17 top-level branches the two signals rank alike and size differently. The taxonomy's volumes are hierarchical, so each branch's volume is taken from its own top node, and each label's mentions are split across the branches where the label occurs; the rank correlation between the share of review mentions and the share of search volume is then +0.75 (p < 0.001, 17 branches; Figure 6b), against +0.78 in an earlier computation that summed each label's volume over every level and assigned it to one branch. The shares differ widely: carriers draw 66.8% of review mentions and 14.9% of search volume, devices 11.0% and 32.7%, broadband 4.0% and 18.1%. At the level of topics the two barely agree. Across the 1,008 labels that at least one review mentions, the rank correlation between review mentions and monthly volume is +0.19 (Kendall's tau +0.13); counting the 26,809 linkable labels that no review mentions as zero, it is +0.27. It is +0.28 among the 213 labels with at least twenty mentions,"),
    (" Reviews concentrate on carriers and the store experience, 73.0% of mentions against 29.4% of search volume; broadband is 18.8% of search volume and 0.7% of mentions.",
     " A label's volume is summed over the nodes that carry it, which can include nested nodes."),
    ("Of 6,620 one- and two-star reviews, 924 (14.0%) mention waiting, against 1.9% of five-star reviews; the taxonomy built from 1.9 million keywords holds one label containing \"wait\", at 12 searches a month.",
     "Of 6,620 one- and two-star reviews, 924 (14.0%) match a pattern for waiting (wait, waited, waiting, long line, hours in line), against 1.9% of five-star reviews; the matches have not been checked by hand. The whole taxonomy, built from 1.9 million keywords, holds 11 labels containing \"wait\", with 622 searches a month between them, and most concern call waiting or waitlists rather than waiting in a store; the one that reviews mention carries 12."),
    ("Within those limits it establishes the framework's narrowest claim: on one industry, what people write in their own words and what a volume tool counts agree on the broad shape of demand and disagree on its topics, and the disagreement is largest for complaints.",
     "Within those limits it is consistent with the framework's narrowest claim: on one industry, what people write in their own words and what a volume tool counts rank the broad areas of demand alike, size them very differently and barely agree on topics, and the disagreement is largest for complaints."),
    # Section 7 (PhD E22, E10, E20; TOIS E15)
    ("read in one collection session from 23:05 on 12 October to 01:05 on 13 October 2026",
     "read in one collection session from 23:05 on 12 October to 01:15 on 13 October 2026 (exports until 01:05, answer counts from 01:10)"),
    ("The vendor's collection conditions (model versions, search settings, how prompts are generated and refreshed) are its own and are not reported here.",
     "By the vendor's own description, which is vendor documentation [Bek 2026], its queries come from Google's \"People Also Ask\" corpus and its keyword database; it tracks about 282 million queries a month on AI Overviews, 24 million on AI Mode and 13 to 15 million on each chat assistant; chat answers are refreshed monthly over a 90-day reporting window and Google's continuously. Whether the surfaces share one query set is not stated, and model versions and search settings are not documented."),
    ("and by surface 0.6% on Copilot, 0.9% on ChatGPT, 4.6% on Perplexity and 9.2% on Gemini.",
     "and by surface 0.6% on Copilot, 0.9% on ChatGPT, 4.6% on Perplexity and 9.2% on Gemini. The bootstrap resamples sectors: it shows how much the median depends on which sectors are in the frame, not sampling error in the vendor's index."),
    ("The prompt and search-query sets are the vendor's, not observed user demand, and whether the Google prompt views and the other four surfaces draw on one prompt set is not established here, so the surfaces may differ in the questions asked as well as in how they answer.",
     "The prompt and search-query sets are the vendor's, not observed user demand. The surfaces are tracked on query sets of very different size (Section 7.2), and whether they share one set is not established, so a difference between surfaces may partly reflect the questions each is asked as well as how it answers."),
    # Section 8 Table 5 (TOIS E20) and verification (TOIS E14)
    ("\"n/r\" means not recorded: the quantity was not captured on that date, the daily series does not retain it, and it is not interpolated here.*",
     "\"n/r\" means not recorded: the quantity was not captured on that date, the daily series does not retain it, and it is not interpolated here. \"≈\" marks a value read from the daily chart rather than from a table.*"),
    ("It closes every full column.", "It closes every full column. The row is small, and the instrument does not document its band definitions in the report, so the row is not interpreted."),
    ("The Ahrefs daily series reproduces the checkpoint rows until it ages out of the six-month window.",
     "The Ahrefs daily series should reproduce the checkpoint rows until it ages out of the six-month window; it was not re-read for this version. The series in Tables 2, 3, 5 and 6 are kept as CSV files with the paper's data, prepared for release with the Section 7 artifacts (open item 3)."),
    # Section 9.1 hubs (PhD E7; TOIS E8)
    ("### 9.1 Enumerating pages outrank per-entity pages", "### 9.1 Enumerating pages are cited more often than any single code page"),
    ("Each exceeds any individual code page: 214 Dallas 238, 786 Miami 228, 404 Atlanta 218 (Figure 8).",
     "Each exceeds any individual code page: 214 Dallas 238, 786 Miami 228, 404 Atlanta 218 (Figure 8). A hub lists many codes, so it pools the questions about all of them: per code it lists, a state hub is cited less often than the most-cited code pages. The observation is about which page an answer engine cites, not about which page answers a given question better."),
    ("A per-entity content strategy predicts the opposite. The question \"where is area code 214\" is answered most directly by the 214 page, and that page is cited less than the page listing every Texas code. If this generalizes, enumerating pages are more citable than per-entity pages for this class of question, and the unit a content program should publish is not the unit the question names.",
     "A per-entity content strategy predicts that per-entity pages are cited most. The question \"where is area code 214\" is answered most directly by the 214 page, and that page is cited less than the page listing every Texas code. The hypothesis this raises, to be tested per question rather than per page, is that an answer engine prefers a page that answers a family of questions to pages that each answer one; if it holds, the unit a content program should publish is not the unit the question names."),
    ("It is an observation on one section. It is the finding in this paper most worth testing elsewhere,",
     "It is a hypothesis from one section. It is the observation in this paper most worth testing elsewhere, per question,"),
    ("can test whether that ordering holds, on either instrument,", "can test whether that ordering holds per question, on either instrument,"),
    ("in tension with Section 9.1's observation that enumerating pages are cited more;", "which Section 9.1's observation questions but does not test;"),
    # Section 10.1 links (PhD E8; TOIS E19)
    ("That result does not depend on link acquisition, and it is this paper's negative result about links, stated at the checkpoint that supports it.",
     "It was reached before the automated network arrived, so the early positions did not need that network; it does not show that links played no part, because nineteen referring domains are not none and their quality is not assessed here."),
    # Section 12 (consolidated additions)
    ("External validity: twelve prefixes on one domain, one of them followed for 77 days; one vendor pair; one read date for the cross-section; no ground truth.",
     "The two instruments also disagree about growth, by a factor of 2.7 in one month, and the share of the divergence the keyword universe explains depends on the territory pairing (35% or 54%). Ordering agreement holds for sections that differ several-fold in size and is weaker within a factor of three. External validity: twelve purposively chosen prefixes on one domain, one of them followed for 77 days; one vendor pair; one read date for the cross-section; no ground truth."),
    ("The reviews describe store locations rather than the area-code section.",
     "The reviews describe store locations rather than the area-code section. The links and the waiting matches have not been checked by hand, and a review is a different construct from an information need."),
    # conclusion (PhD E5, E2, E7; TOIS E2, E19)
    ("Two commercial analytics platforms watched the same section from the day it appeared.",
     "Two commercial analytics platforms' histories of the same section begin on the day it appeared."),
    ("while a single-vendor ranking of sections is usually right in direction. That is why the framework does not rely on one source of demand.",
     "while a single-vendor ranking of sections is right in direction when sections differ several-fold in size. The two also disagreed about growth, by a factor of 2.7 in one month. That is why the framework reads its outcomes on more than one instrument."),
    ("the two agreed on the broad shape of demand (+0.78 across branches) and diverged on its topics (+0.19), most for complaints: one in seven unhappy reviews named waiting, which the taxonomy records at 12 searches a month.",
     "the two ranked the taxonomy's branches alike (+0.75) while sizing them very differently, and barely agreed on topics (+0.19, or +0.27 counting labels no review mentions), most for complaints: one in seven unhappy reviews matched a waiting pattern, while the whole taxonomy holds 11 labels mentioning waiting, mostly about call waiting and waitlists, with 622 searches a month."),
    ("and by day 77 appeared in 17,206 recorded AI answers having earned no editorial link. The pages most cited were the ones that enumerate rather than the ones that answer.",
     "and by day 77 appeared in 17,206 recorded AI answers, with no link built or solicited by the author. The pages cited most were hubs that list many codes, which raises a hypothesis about the unit an answer engine prefers rather than establishing one."),
    ("Section 9.1 shows why, and the released score does not yet do so.", "Section 9.1 suggests why, and the released score does not yet do so."),
])

# references, each verified on 13 October 2026
REFS = {
    "Aggarwal": "Aggarwal, P., Murahari, V., Rajpurohit, T., Kalyan, A., Narasimhan, K., & Deshpande, A. (2024). GEO: Generative engine optimization. In *Proceedings of the 30th ACM SIGKDD Conference on Knowledge Discovery and Data Mining (KDD '24)* (pp. 5–16). ACM. https://doi.org/10.1145/3637528.3671900",
    "Bek": "Bek, R. (2026, updated February 26). *Ahrefs Brand Radar methodology: How we collect and model AI visibility data.* Ahrefs. https://ahrefs.com/blog/brand-radar-methodology/ (vendor documentation; accessed 13 October 2026.)",
    "Chuklin": "Chuklin, A., Markov, I., & de Rijke, M. (2015). *Click models for web search.* Synthesis Lectures on Information Concepts, Retrieval, and Services. Morgan & Claypool.",
    "Gienapp": "Gienapp, L., Scells, H., Deckers, N., Bevendorff, J., Wang, S., Kiesel, J., Syed, S., Fröbe, M., Zuccon, G., Stein, B., Hagen, M., & Potthast, M. (2024). *Evaluating generative ad hoc information retrieval.* arXiv:2311.04694.",
    "Jansen": "Jansen, B. J., Jung, S.-G., & Salminen, J. (2022). Measuring user interactions with websites: A comparison of two industry standard analytics approaches using data of 86 websites. *PLOS ONE, 17*(5), e0268212. https://doi.org/10.1371/journal.pone.0268212",
    "Kamerer": "Kamerer, D. (2013). Estimating online audiences: Understanding the limitations of competitive intelligence services. *First Monday, 18*(5). https://doi.org/10.5210/fm.v18i5.3986",
    "Liu, N.": "Liu, N. F., Zhang, T., & Liang, P. (2023). *Evaluating verifiability in generative search engines.* arXiv:2304.09848.",
    "Liu, Q.": "Liu, Q., Agichtein, E., Dror, G., Maarek, Y., & Szpektor, I. (2012). When web search fails, searchers become askers. In *Proceedings of the 35th International ACM SIGIR Conference on Research and Development in Information Retrieval* (pp. 801–810). ACM. https://doi.org/10.1145/2348283.2348390",
    "Morris": "Morris, M. R., Teevan, J., & Panovich, K. (2010). What do people ask their social networks, and why? In *Proceedings of the SIGCHI Conference on Human Factors in Computing Systems (CHI '10)* (pp. 1739–1748). ACM. https://doi.org/10.1145/1753326.1753587",
    "Prantl": "Prantl, D., & Prantl, M. (2018). Website traffic measurement and rankings: Competitive intelligence tools examination. *International Journal of Web Information Systems, 14*(4), 423–437. https://doi.org/10.1108/IJWIS-01-2018-0001",
    "White": "White, R. W., Richardson, M., & Yih, W. (2015). Questions vs. queries in informational search tasks. In *Proceedings of the 24th International Conference on World Wide Web (WWW '15 Companion)* (pp. 135–136). ACM. https://doi.org/10.1145/2740908.2742769",
}
i0 = s.index("## References\n\n") + len("## References\n\n")
i1 = s.index("\n\n## Appendix A")
entries = [e for e in s[i0:i1].split("\n\n") if e.strip()] + list(REFS.values())
import re
entries.sort(key=lambda e: (re.sub(r"[^a-z]", "", e.split(",")[0].lower()), re.sub(r"[^a-z]", "", e.split("(")[0].lower())))
s = s[:i0] + "\n\n".join(entries) + s[i1:]

P.write_text(s)
print(f"{len(s.split()):,} words; {len(entries)} references")
