"""Version 5.2, Section 3's page count checked against the numbering plan registry (14 October 2026): the section's
index and state hubs link exactly 381 code pages (03_DATA/section_code_pages_2026-10-14.csv); every one of the 372 US
geographic codes in service outside the territories has a page, as do two codes assigned but not yet in service (565,
761) and the seven toll-free codes. Code 451, assigned to North Carolina on 15 September 2026, after launch, and not
yet in service, has none, so "the only geographic codes with no page are the six territory codes" was off by one."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:  # already applied: an insertion keeps its anchor, so a second run would insert twice
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("the section holds 381 code pages**: 374 for geographic codes assigned to US states and the District of Columbia, and 7 for toll-free codes.",
     "the section holds 381 code pages**: 374 for geographic codes assigned to US states and the District of Columbia (all 372 in service and two assigned but not yet in service), and 7 for toll-free codes; a re-fetch on 14 October 2026 found the same 381 and matched them to the numbering plan administrator's registry of that date."),
    ("The only geographic codes in the plan with no page are the six assigned to US territories.",
     "The only geographic codes in the plan with no page are the six assigned to US territories and 451, assigned to North Carolina on 15 September 2026, after launch, and not yet in service."),
    ("The section holds a page for every geographic code assigned to a US state or the District of Columbia;",
     "The section holds a page for every geographic code in service in a US state or the District of Columbia;"),
])
P.write_text(s)
print(f"{len(s.split()):,} words")
