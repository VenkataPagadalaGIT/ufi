"""Version 5.2, 15 October 2026: two rounding errors found by the third independent reproduction
(08_REVIEW/reproduction_v5.2_run3_2026-10-15/). The topic-level correlation is 0.1849 (m2_from_counts.py and
supplement_r10.py print +0.185), so +0.18, not +0.19, which rounded the printed value a second time; the upper end of
the all-labels interval is 0.2850 printed from 0.284982, so +0.28, not +0.29."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("and barely on topics (+0.19), on links that two blind AI annotators", "and barely on topics (+0.18), on links that two blind AI annotators"),
    ("the rank correlation between review mentions and monthly volume is +0.19 (bootstrap 95% interval over labels",
     "the rank correlation between review mentions and monthly volume is +0.18 (bootstrap 95% interval over labels"),
    ("it is +0.27 (+0.26 to +0.29).", "it is +0.27 (+0.26 to +0.28)."),
    ("and barely agreed on topics (+0.19, or +0.27 counting labels no review mentions)",
     "and barely agreed on topics (+0.18, or +0.27 counting labels no review mentions)"),
    ("| +0.19 (mentioned), +0.27 (all linkable) |", "| +0.18 (mentioned), +0.27 (all linkable) |"),
])
P.write_text(s)
print("ok")
