"""Study W: descriptive figures quoted in manuscript Section 6.2 that the stamped analysis script does not print. Written
after the data were read, on 3 November 2026, so it is not part of the plan; wiki_demand_analysis.py is left exactly as
stamped. Reads wiki_groups.csv and, for the renamed articles, pageviews_monthly.csv (project or release layout).
Usage: python3 wiki_demand_supplement.py"""
import csv
import math
import statistics
from pathlib import Path

import numpy as np
from scipy.stats import rankdata, spearmanr

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
IN_PROJECT = (ROOT / "03_DATA/processed/wiki_groups.csv").is_file()
GROUPS = ROOT / "03_DATA/processed/wiki_groups.csv" if IN_PROJECT else HERE / "wiki_groups.csv"
MONTHLY = ROOT / "03_DATA/raw/wikipedia_2026-10/pageviews_monthly.csv" if IN_PROJECT else HERE / "pageviews_monthly.csv"
G = list(csv.DictReader(GROUPS.open()))
OUT = []


def say(s):
    print(s)
    OUT.append(s)


W = [int(g["views_primary"]) for g in G]
dem = [int(g["dem"]) for g in G]
say(f"articles {len(G)}; about one code {sum(g['n_codes'] == '1' for g in G)}, two {sum(g['n_codes'] == '2' for g in G)}, three to five {sum(int(g['n_codes']) >= 3 for g in G)}")
say(f"requests in the primary window: minimum {min(W):,}, maximum {max(W):,}; between 15,000 and 50,000: {sum(15000 <= w <= 50000 for w in W)} of {len(W)} ({100 * sum(15000 <= w <= 50000 for w in W) / len(W):.1f}%)")
say(f"vendor summed volume: minimum {min(dem):,}, maximum {max(dem):,}")
say("exact correlations with the vendor's summed volume, to five decimals (the paper rounds these, not the three-decimal print):")
for k, lab in (("views_primary", "primary"), ("views_shifted", "shifted window"), ("views_clean6", "six months outside the reclassified span"),
               ("views_primary_median_x12", "median month"), ("views_primary_article_only", "article title only"), ("views_post", "Aug to Sep 2026")):
    say(f"  {lab}: {spearmanr(dem, [float(g[k]) for g in G]).statistic:+.5f}")
s1 = [g for g in G if g["n_codes"] == "1"]
say(f"  single-code articles: {spearmanr([int(g['dem']) for g in s1], [int(g['views_primary']) for g in s1]).statistic:+.5f}")
ld, lw = [math.log(x) for x in dem], [math.log(x) for x in W]
sd, sw = statistics.stdev(ld), statistics.stdev(lw)
say(f"P3 floor: geometric SDs {math.exp(sd):.2f} (volume) and {math.exp(sw):.2f} (requests); the ratio's geometric SD cannot fall below {math.exp(abs(sd - sw)):.1f} at any correlation; log-log Pearson {statistics.correlation(ld, lw):+.2f}")
K = [int(g["n_keywords"]) for g in G]
lk = [math.log(x) for x in K]
per = [d / k for d, k in zip(dem, K)]
say(f"summed volume and matched keyword count: Spearman {spearmanr(dem, K).statistic:+.3f}; log-log Pearson squared {statistics.correlation(ld, lk) ** 2:.3f}; "
    f"volume per keyword: median {statistics.median(per):,.0f}, geometric SD {math.exp(statistics.stdev(math.log(x) for x in per)):.2f}")
rd, rk, rw = rankdata(dem), rankdata(K), rankdata(W)


def partial(i):
    def res(y, x):
        return y - np.polyval(np.polyfit(x, y, 1), x)
    return float(np.corrcoef(res(rd[i], rk[i]), res(rw[i], rk[i]))[0, 1])


nprng = np.random.default_rng(20261103)
draws = [partial(nprng.integers(0, len(G), len(G))) for _ in range(5000)]
say(f"partial rank correlation of volume and requests given the matched keyword count (post hoc): {partial(np.arange(len(G))):+.3f}, percentile bootstrap 95% {np.percentile(draws, 2.5):+.3f} to {np.percentile(draws, 97.5):+.3f}; keyword count and requests alone: {spearmanr(K, W).statistic:+.3f}")
spike = max(G, key=lambda g: int(g["views_primary_max_month"]) / (float(g["views_primary_median_x12"]) / 12))
say(f"largest month against median month: {spike['codes'].replace(';', ',')}: {int(spike['views_primary_max_month']):,} against {float(spike['views_primary_median_x12']) / 12:,.0f}, {int(spike['views_primary_max_month']) / (float(spike['views_primary_median_x12']) / 12):.1f} times")
first = {}
for r in csv.DictReader(MONTHLY.open()):
    if int(r["views"]) > 0:
        first[r["title"]] = min(first.get(r["title"], "999999"), r["month"])
late = [(g["codes"].replace(";", ","), g["article"], first.get(g["article"], "none")) for g in G if first.get(g["article"], "999999") > "202409"]
say(f"articles whose current title has requests only from a later month than September 2024: {len(late)}; earliest such month {min(x[2] for x in late)}")
for x in late:
    say(f"  {x[0]}: {x[1]}: first month {x[2]}")
codes_late = {x[0] for x in late}
keep = [g for g in G if g["codes"].replace(";", ",") not in codes_late]
for k, lab in (("views_primary", "all titles"), ("views_primary_article_only", "article title only")):
    say(f"without those {len(late)} articles (n = {len(keep)}), {lab}: {spearmanr([int(g['dem']) for g in keep], [int(g[k]) for g in keep]).statistic:+.5f}")
shares = sorted(1 - int(g["views_primary_article_only"]) / int(g["views_primary"]) for g in G if g["codes"].replace(";", ",") in codes_late)
say(f"share of requests through redirect titles among those {len(late)} articles: " + ", ".join(f"{100 * x:.0f}%" for x in shares))
(HERE / "wiki_demand_supplement_output.txt").write_text("\n".join(OUT) + "\n")
