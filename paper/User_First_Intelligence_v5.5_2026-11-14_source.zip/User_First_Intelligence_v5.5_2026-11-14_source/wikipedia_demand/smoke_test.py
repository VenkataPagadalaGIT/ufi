"""Smoke test for the Study W analysis and figure scripts on made-up tables with the collector's exact columns, run in a
temporary folder so that no project file is touched. It checks that both scripts run to the end and write their outputs;
it says nothing about the study's data. Usage: python3 smoke_test.py"""
import csv
import random
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
rng = random.Random(1)
with tempfile.TemporaryDirectory() as d:
    d = Path(d)
    for s in ("wiki_demand_analysis.py", "make_fig_wikipedia.py"):
        shutil.copy2(HERE / s, d / s)
    codes, groups = [], []
    code = 201
    for gid in range(60):
        n = rng.choice([1, 1, 1, 2, 2, 3])
        cs = [str(code + i) for i in range(n)]
        code += n
        late = int(gid == 3)
        zero = int(gid in (5, 7))
        vols = [0 if zero else rng.randint(500, 600000) for _ in cs]
        prim = [rng.randint(0, 3000) for _ in range(12)]
        if gid == 9:
            prim = [0] * 12
        views = sum(prim)
        article = f"Area code {cs[0]}" if n == 1 else "Area codes " + ", ".join(cs[:-1]) + f", and {cs[-1]}"
        for c, v in zip(cs, vols):
            codes.append({"code": c, "title": f"Area code {c}", "article": article, "article_pageid": 1000 + gid, "covered": 1,
                          "coverage_note": "", "chain_titles": f"Area code {c}", "volume": v, "n_keywords": 0 if zero else rng.randint(1, 60),
                          "in_service_after_2025_10_01": late, "own_title_views_primary": rng.randint(0, 500)})
        med = sorted(prim)[5:7]
        groups.append({"article_pageid": 1000 + gid, "article": article, "codes": ";".join(cs), "n_codes": n, "n_redirect_titles": rng.randint(0, 8),
                       "n_titles_no_data": 0, "views_primary": views, "views_primary_article_only": int(views * 0.8),
                       "views_primary_median_x12": 12 * (med[0] + med[1]) / 2, "views_primary_max_month": max(prim),
                       "views_shifted": int(views * 1.02), "views_clean6": int(views * 0.5), "views_post": int(views * 0.2),
                       "views_all_months": int(views * 2.1), "dem": sum(vols), "n_keywords": sum(int(c["n_keywords"]) for c in codes if c["code"] in cs),
                       "late_codes": late * n, "zero_keyword_codes": zero * n})
    codes.append({"code": "999", "title": "Area code 999", "article": "", "article_pageid": "", "covered": 0,
                  "coverage_note": "not covered: title missing; search fallback found nothing", "chain_titles": "Area code 999",
                  "volume": 10, "n_keywords": 1, "in_service_after_2025_10_01": 0, "own_title_views_primary": ""})
    for name, rows in (("wiki_codes.csv", codes), ("wiki_groups.csv", groups)):
        with (d / name).open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0]))
            w.writeheader()
            w.writerows(rows)
    for s in ("wiki_demand_analysis.py", "make_fig_wikipedia.py"):
        r = subprocess.run([sys.executable, s], cwd=d, capture_output=True, text=True)
        if r.returncode:
            print(r.stdout[-2000:], r.stderr[-3000:])
            raise SystemExit(f"{s} failed on synthetic data")
    for out in ("wiki_demand_analysis_output.txt", "wiki_demand_headline.json", "fig11_wikipedia.pdf", "fig11_wikipedia.png"):
        assert (d / out).is_file(), out
    print("smoke test passed: both scripts ran on synthetic tables and wrote their outputs")
