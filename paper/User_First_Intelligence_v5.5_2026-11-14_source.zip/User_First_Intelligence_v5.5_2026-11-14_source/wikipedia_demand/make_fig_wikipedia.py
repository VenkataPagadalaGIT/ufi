"""Study W figure: Wikipedia requests per month (October 2024 to September 2025) against the vendor's summed monthly
keyword volume, one marker per article group. Groups with a zero count are drawn at the axis edge with their own marker.
Reads wiki_groups.csv and wiki_demand_headline.json; saves to 05_FIGURES in the research project, beside this script
elsewhere."""
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "DejaVu Serif"], "font.size": 8, "axes.linewidth": 0.6})
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PROC = ROOT / "03_DATA/processed" if (ROOT / "03_DATA/processed/wiki_groups.csv").is_file() else HERE
OUT = ROOT / "05_FIGURES" if (ROOT / "05_FIGURES").is_dir() else HERE
G = list(csv.DictReader((PROC / "wiki_groups.csv").open()))
H = json.loads((HERE / "wiki_demand_headline.json").read_text())
dem = np.array([float(g["dem"]) for g in G])
W = np.array([float(g["views_primary"]) for g in G]) / 12
multi = np.array([int(g["n_codes"]) > 1 for g in G])
XF, YF = 5.0, 0.5  # axis floors for zero counts
zx, zy = dem == 0, W == 0
x = np.where(zx, XF, dem)
y = np.where(zy, YF, W)
ordinary = ~zx & ~zy

fig, ax = plt.subplots(figsize=(3.4, 3.1))
ax.scatter(x[ordinary & ~multi], y[ordinary & ~multi], s=9, facecolor="none", edgecolor="0.25", lw=0.5,
           label=f"article about one code ({int((ordinary & ~multi).sum())})")
ax.scatter(x[ordinary & multi], y[ordinary & multi], s=11, marker="s", facecolor="0.35", edgecolor="0.1", lw=0.4,
           label=f"article shared by several codes ({int((ordinary & multi).sum())})")
if zx.any():
    ax.scatter(x[zx], y[zx], s=16, marker="<", facecolor="white", edgecolor="0.1", lw=0.5, label=f"zero vendor volume, drawn at the left edge ({int(zx.sum())})")
if zy.any():
    ax.scatter(x[zy & ~zx], y[zy & ~zx], s=16, marker="v", facecolor="white", edgecolor="0.1", lw=0.5, label=f"zero requests, drawn at the bottom edge ({int((zy & ~zx).sum())})")
ax.set_xscale("log")
ax.set_yscale("log")
ax.set_xlabel("vendor monthly search volume, summed over the article's codes (log)")
ax.set_ylabel("Wikipedia requests per month, all titles of the article (log)")
r, lo, hi = H["primary"]["spearman"], *H["primary"]["ci"]
ax.set_title(f"{len(G)} articles, Spearman {r:+.2f} [{lo:+.2f}, {hi:+.2f}]", loc="left", fontsize=8)
for i in list(np.argsort(-W)[:2]) + list(np.argsort(-dem)[:2]):
    ax.annotate(G[i]["codes"].replace(";", ", "), (x[i], y[i]), xytext=(4, -3), textcoords="offset points", fontsize=6.5)
ax.grid(True, lw=0.3, color="0.85")
ax.legend(fontsize=6, frameon=False, loc="upper left")
fig.savefig(OUT / "fig11_wikipedia.png", dpi=300, bbox_inches="tight")
fig.savefig(OUT / "fig11_wikipedia.pdf", bbox_inches="tight")
print("ok")
