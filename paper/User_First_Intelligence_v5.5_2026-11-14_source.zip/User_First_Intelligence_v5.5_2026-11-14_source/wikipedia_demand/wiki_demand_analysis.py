"""Study W (02_DESIGN/wikipedia_demand_372.md): the analysis fixed before collection.

Reads wiki_groups.csv and wiki_codes.csv (written by wiki_collect.py) and prints every number the plan lists:
coverage (P4), the rank correlation between the vendor's summed volume and the Wikipedia request count per article (P1,
P2), the dispersion of searches per view (P3, descriptive statistics and the geometric-SD comparison), the
sensitivities, the secondary window, the descriptive extremes and the two exploratory correlations. Spearman and Kendall
from scipy; 95% percentile bootstrap intervals from 10,000 resamples of groups, seed 20261031.

Layouts: in the research project it reads 03_DATA/processed/ and refuses to run if r1_predictors.csv has left its frozen
hash; in the release it reads the two CSV files beside it (the exploratory score correlation then prints "not available").
Output: wiki_demand_analysis_output.txt and wiki_demand_headline.json beside this script.

Usage: python3 wiki_demand_analysis.py
"""
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.stats import kendalltau, spearmanr

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
IN_PROJECT = (ROOT / "03_DATA/processed/wiki_groups.csv").is_file()
PROC = ROOT / "03_DATA/processed" if IN_PROJECT else HERE
PRED = ROOT / "03_DATA/processed/r1_predictors.csv"
FROZEN = "65c5c3cb2ca76e1e681acf4086703696b91293f4d8b7063310881da1f6e69cd4"
SEED, B = 20261031, 10000
M1_GSD = 3.1  # Measurement 1's geometric SD of the vendor ratio across twelve prefixes (manuscript Section 5.5)
OUT = []
HEAD = {}


def say(*a):
    s = " ".join(str(x) for x in a)
    print(s)
    OUT.append(s)


def rho(x, y):
    return float(spearmanr(x, y).statistic)


def tau(x, y):
    return float(kendalltau(x, y).statistic)


def boot(x, y, seed=SEED):
    x, y = np.asarray(x, float), np.asarray(y, float)
    rng = np.random.default_rng(seed)
    n = len(x)
    vals = []
    for _ in range(B):
        idx = rng.integers(0, n, n)
        if np.ptp(x[idx]) == 0 or np.ptp(y[idx]) == 0:
            continue
        vals.append(spearmanr(x[idx], y[idx]).statistic)
    if len(vals) < B // 2:
        return float("nan"), float("nan")
    return float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))


def corr_line(label, x, y, key=None):
    x, y = np.asarray(x, float), np.asarray(y, float)
    if len(x) < 3 or np.ptp(x) == 0 or np.ptp(y) == 0:
        say(f"  {label}: not computable (n = {len(x)}, or a constant series)")
        return float("nan"), float("nan"), float("nan")
    r, (lo, hi) = rho(x, y), boot(x, y)
    t = tau(x, y)
    say(f"  {label}: Spearman {r:+.3f} [{lo:+.3f}, {hi:+.3f}], Kendall {t:+.3f}, n = {len(x)}")
    if key:
        HEAD[key] = {"spearman": round(r, 3), "ci": [round(lo, 3), round(hi, 3)], "kendall": round(t, 3), "n": int(len(x))}
    return r, lo, hi


if IN_PROJECT:
    if not PRED.is_file() or hashlib.sha256(PRED.read_bytes()).hexdigest() != FROZEN:
        raise SystemExit("REFUSE: r1_predictors.csv is missing or not the frozen table")
G = list(csv.DictReader((PROC / "wiki_groups.csv").open()))
C = list(csv.DictReader((PROC / "wiki_codes.csv").open()))
INT = ("n_codes", "n_redirect_titles", "n_titles_no_data", "views_primary", "views_primary_article_only",
       "views_primary_max_month", "views_shifted", "views_clean6", "views_post", "views_all_months", "dem", "n_keywords",
       "late_codes", "zero_keyword_codes")
for g in G:
    for k in INT:
        g[k] = int(g[k])
    g["views_primary_median_x12"] = float(g["views_primary_median_x12"])
dem = np.array([g["dem"] for g in G], float)
W = np.array([g["views_primary"] for g in G], float)
Wa = np.array([g["views_primary_article_only"] for g in G], float)
K = np.array([g["n_keywords"] for g in G], float)

say("== 1. Coverage of the class (P4)")
n_unc = sum(1 - int(c["covered"]) for c in C)
say(f"  codes {len(C)}; covered by an article whose title names the code {len(C) - n_unc}; not covered {n_unc}")
for c in C:
    if not int(c["covered"]) or "fallback" in c["coverage_note"]:
        say(f"    {c['code']}: {c['coverage_note']}")
say(f"  article groups {len(G)}; codes per group: " + ", ".join(f"{k} codes x {v}" for k, v in sorted(
    {n: sum(g['n_codes'] == n for g in G) for n in {g['n_codes'] for g in G}}.items())))
say(f"  redirect titles in all {sum(g['n_redirect_titles'] for g in G)}; titles with no pageview data {sum(g['n_titles_no_data'] for g in G)}")
say(f"  groups with zero requests in the primary window {int((W == 0).sum())}; with zero vendor volume {int((dem == 0).sum())}")
p4 = bool(n_unc == 0)
say(f"  P4 (every code covered by an article that names it): {'HELD' if p4 else 'FAILED'}")
HEAD.update({"codes": len(C), "not_covered": n_unc, "groups": len(G), "p4": p4})

say("== 2. Primary: vendor summed volume against Wikipedia requests per article, October 2024 to September 2025 (P1, P2)")
r, lo, hi = corr_line("dem(g) vs W(g)", dem, W, "primary")
corr_line("K(g) keywords vs W(g)", K, W, "keywords")
p1 = bool(r > 0 and lo > 0)
p2 = bool(0.40 <= r <= 0.80)
boundary = bool(p2 and (lo < 0.40 or hi > 0.80))
against = bool(lo > 0.80)
say(f"  P1 (positive, interval excludes zero): {'HELD' if p1 else 'FAILED'}")
say(f"  P2 (point estimate between +0.40 and +0.80): {'HELD' if p2 else 'FAILED'}{' (boundary: the interval crosses an edge of the band)' if boundary else ''}")
say(f"  interval entirely above +0.80 (counts against the generality of Measurement 2's finding): {'yes' if against else 'no'}")
HEAD.update({"p1": p1, "p2": p2, "p2_boundary": boundary, "interval_above_080": against})

say("== 3. Dispersion: monthly searches per monthly request (P3)")
ok = (dem > 0) & (W > 0)
ratio = dem[ok] / (W[ok] / 12)
p10, p50, p90 = (float(v) for v in np.percentile(ratio, [10, 50, 90]))
gm, gsd = float(np.exp(np.log(ratio).mean())), float(np.exp(np.log(ratio).std(ddof=1)))
say(f"  groups used {int(ok.sum())} (excluded for a zero count: {int((~ok).sum())})")
say(f"  median {p50:.1f} searches per request; 10th percentile {p10:.1f}; 90th {p90:.1f}; ratio 90th/10th {p90 / p10:.1f} (descriptive)")
say(f"  groups above one search per request {int((ratio > 1).sum())}, below {int((ratio < 1).sum())}")
say(f"  geometric mean {gm:.1f}, geometric SD {gsd:.2f}; for comparison, the vendor volume's own geometric SD across these groups "
    f"{float(np.exp(np.log(dem[ok]).std(ddof=1))):.2f} and the requests' {float(np.exp(np.log(W[ok]).std(ddof=1))):.2f}")
p3 = bool(gsd > M1_GSD)
say(f"  P3 (geometric SD of searches per request above {M1_GSD}, Measurement 1's figure for the vendor pair): {'HELD' if p3 else 'FAILED'}")
HEAD.update({"ratio_median": round(p50, 1), "ratio_p10": round(p10, 1), "ratio_p90": round(p90, 1), "ratio_spread": round(p90 / p10, 1),
             "ratio_gm": round(gm, 1), "ratio_gsd": round(gsd, 2), "p3": p3, "ratio_n": int(ok.sum())})

say("== 4. Sensitivities")
single = np.array([g["n_codes"] == 1 for g in G])
corr_line("single-code groups only", dem[single], W[single], "single")
keep = np.array([g["late_codes"] == 0 and g["zero_keyword_codes"] == 0 for g in G])
dropped = [g for g in G if g["late_codes"] or g["zero_keyword_codes"]]
say(f"  groups dropped for containing a late or zero-keyword code: {len(dropped)} ({sum(g['n_codes'] for g in dropped)} codes): "
    + "; ".join(g["codes"].replace(";", ",") for g in dropped))
corr_line("excluding those groups", dem[keep], W[keep], "excl_late_zero")
corr_line("requests for the article title only (redirect titles dropped)", dem, Wa, "article_only")
Ws = np.array([g["views_shifted"] for g in G], float)
corr_line("window shifted one month earlier (September 2024 to August 2025)", dem, Ws, "shifted")
Wc = np.array([g["views_clean6"] for g in G], float)
corr_line("the six months outside the Foundation's reclassified span (October 2024 to February 2025, September 2025)", dem, Wc, "clean6")
Wm = np.array([g["views_primary_median_x12"] for g in G], float)
corr_line("twelve times the median month (robust to single-month spikes)", dem, Wm, "median_month")
mx = np.array([g["views_primary_max_month"] for g in G], float)
spiky = [g for g, m, md in zip(G, mx, Wm / 12) if md > 0 and m > 3 * md] + [g for g, md in zip(G, Wm) if md == 0]
say(f"  groups whose largest month exceeds three times their median month (or whose median is zero): {len(spiky)}: "
    + "; ".join(f"{g['codes'].replace(';', ',')} (max {g['views_primary_max_month']:,}, median {g['views_primary_median_x12'] / 12:,.0f})" for g in spiky[:40])
    + (" ..." if len(spiky) > 40 else ""))
HEAD["spiky_groups"] = len(spiky)

say("== 5. Secondary window: August and September 2026 (descriptive; no change is attributed to the section's launch)")
Wp = np.array([g["views_post"] for g in G], float)
corr_line("dem(g) vs requests Aug to Sep 2026", dem, Wp, "post")
say(f"  total requests, all groups: primary window {int(W.sum()):,} over 12 months ({W.sum() / 12:,.0f} a month); "
    f"Aug to Sep 2026 {int(Wp.sum()):,} over 2 months ({Wp.sum() / 2:,.0f} a month)")
corr_line("requests Oct 2024 to Sep 2025 vs requests Aug to Sep 2026 (stability of the public count)", W, Wp, "stability")

say("== 6. Descriptive extremes and redirect shares")
order_w = np.argsort(-W)
order_d = np.argsort(-dem)
fmt = lambda i: f"{G[i]['codes'].replace(';', ',')} ({G[i]['article']}): {int(W[i]):,} requests, volume {int(dem[i]):,}"
say("  highest requests: " + " | ".join(fmt(i) for i in order_w[:5]))
say("  lowest requests: " + " | ".join(fmt(i) for i in order_w[-5:]))
say("  highest volume: " + " | ".join(fmt(i) for i in order_d[:5]))
say("  lowest volume: " + " | ".join(fmt(i) for i in order_d[-5:]))
pos = W > 0
share = 1 - Wa[pos] / W[pos]
pooled = 1 - Wa.sum() / W.sum() if W.sum() else float("nan")
say(f"  share of requests arriving through redirect titles: pooled {100 * pooled:.1f}%; across the {int(pos.sum())} groups with requests, "
    f"median {100 * float(np.median(share)):.1f}%, minimum {100 * float(share.min()):.1f}%, maximum {100 * float(share.max()):.1f}%")
HEAD.update({"redirect_share_pooled": round(float(100 * pooled), 1), "redirect_share_median": round(float(100 * np.median(share)), 1)})

say("== 7. Exploratory (labelled; not tests)")
own = np.array([float(c["own_title_views_primary"]) if c["own_title_views_primary"] != "" else np.nan for c in C])
vol = np.array([float(c["volume"]) for c in C])
m = ~np.isnan(own)
corr_line("per code: volume vs requests for the code's own title 'Area code e' (inconsistent measure)", vol[m], own[m], "own_title")
if IN_PROJECT:
    pred = {r["code"]: float(r["cgs"]) for r in csv.DictReader(PRED.open())}
    cgs_g = np.array([np.mean([pred[c] for c in g["codes"].split(";")]) for g in G])
    corr_line("mean Content Gap Score of the group's codes vs W(g) (the score contains dem; not a test of the score)", cgs_g, W, "cgs")
else:
    say("  score correlation: not available (the per-code scores are not in the release)")

say("== Predictions (no adjustment for multiple comparisons; P1 is the only interval-based test)")
say(f"  P1 {'held' if p1 else 'failed'}; P2 {'held' if p2 else 'failed'}{' (boundary)' if boundary else ''}; P3 {'held' if p3 else 'failed'}; P4 {'held' if p4 else 'failed'}")
(HERE / "wiki_demand_analysis_output.txt").write_text("\n".join(OUT) + "\n")
(HERE / "wiki_demand_headline.json").write_text(json.dumps(HEAD, indent=1) + "\n")
