# Study W: a counted public demand signal against the vendor's modeled volume on the 372 area codes

Manuscript Section 6.2. Plan with predictions P1 to P4: `02_DESIGN/wikipedia_demand_372.md`, committed and submitted for an
OpenTimestamps stamp (`02_DESIGN/wikipedia_demand_372_manifest.txt`, `.ots`) at 05:10 UTC on 31 October 2026, before any
pageview of the study's units was collected apart from the probes it lists. The collection ran from 05:11 to 05:19 UTC,
before the stamp reached a Bitcoin block (the earliest is 973,934, 05:44 UTC), so the proof shows the plan existed within 25
minutes of the end of the read and does not by itself order the two; the order rests on the commit history and the collection log. Everything here is public data: the Wikimedia Foundation's monthly pageview counts and the MediaWiki API's
title resolution. No vendor interface was touched; the vendor side is the frozen Study R1 table.

| File | What it is |
|---|---|
| `wiki_collect.py` | resolves "Area code {e}" for the 372 codes, lists every redirect to each article, reads monthly user views of every title (October 2024 to September 2026) and writes the tables below |
| `wiki_demand_analysis.py`, `wiki_demand_analysis_output.txt`, `wiki_demand_headline.json` | the analysis fixed in the plan; prints every number Section 6.2 quotes |
| `wiki_demand_supplement.py`, `wiki_demand_supplement_output.txt` | written after the data were read (3 November 2026), not part of the plan: descriptive figures Section 6.2 quotes that the stamped script does not print, and the exact correlations |
| `make_fig_wikipedia.py` | Figure 7 (`05_FIGURES/fig11_wikipedia.*`) |
| `stamp_manifest.sh` | wrote and stamped the manifest after the commit that added the plan and scripts |
| `smoke_test.py` | ran the analysis and figure scripts on made-up tables before the stamp |
| `R12_studyW_plan_review_2026-10-31.md` (in the release) | the review of the plan's first draft: findings and what was done about each |

Data (written by the collector): `03_DATA/raw/wikipedia_2026-10/` holds every API response used (`resolution.jsonl`,
`redirects.jsonl`, `pageviews.jsonl`), the per-title monthly views (`pageviews_monthly.csv`) and the collection log;
`03_DATA/processed/wiki_codes.csv` is one row per code (title, article, vendor volume and keyword count from the frozen
table, own-title views) and `wiki_groups.csv` one row per Wikipedia article (its codes, views by window, summed vendor
volume). The per-article sums of vendor volume are derived aggregates over 5,848 keywords; no keyword or per-keyword
volume is released, and the per-code Content Gap Scores stay with the Study R1 files.

Run, from this folder: `python3 wiki_collect.py` (about ten minutes; needs the network), then
`python3 wiki_demand_analysis.py`, then `python3 make_fig_wikipedia.py`. In the release the analysis reads the two CSV
files beside it and prints "not available" for the one exploratory line that needs the per-code scores. It writes its two output
files beside itself, as the plan fixed, so a run in the release replaces the shipped copies with ones that lack that one line and
key; `wiki_demand_analysis.py` is left exactly as stamped.
