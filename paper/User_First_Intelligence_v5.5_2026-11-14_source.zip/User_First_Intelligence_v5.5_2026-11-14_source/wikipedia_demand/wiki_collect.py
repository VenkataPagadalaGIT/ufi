"""Study W (02_DESIGN/wikipedia_demand_372.md): collect the public side.

For the 372 units of Study R1 (03_DATA/processed/r1_predictors.csv, frozen 14 October 2026), resolve the English
Wikipedia title "Area code {e}" through the MediaWiki API (following redirect chains), judge whether the page it reaches
is an article about the code (its title starts "Area code" or "Area codes" and names the code's three digits), try one
fixed fallback search for codes whose title is missing or reaches another page, list every article-namespace redirect to
each covered article, and read the monthly count of requests the Wikimedia Foundation classifies as human ("user") for
every title from the pageviews REST API, September 2024 to September 2026. Only free public endpoints that need no key
are used, at no more than five requests a second; no vendor interface is touched.

Writes (project layout; in the release, where the frozen table is held back, the units are read from wiki_codes.csv
beside this script and everything is written to recollected/ beside it, with a note that redirect lists and pageviews
are read live and may differ from the released files)
  03_DATA/raw/wikipedia_2026-10/resolution.jsonl      every MediaWiki response used to resolve the titles
  03_DATA/raw/wikipedia_2026-10/search_fallback.jsonl every fallback search response
  03_DATA/raw/wikipedia_2026-10/redirects.jsonl       every response listing the redirects of a covered article
  03_DATA/raw/wikipedia_2026-10/pageviews.jsonl       every pageviews response (one line per title)
  03_DATA/raw/wikipedia_2026-10/pageviews_monthly.csv title, article, month, views (0 for months without data)
  03_DATA/raw/wikipedia_2026-10/collection_log.txt    appended as the run proceeds: when, counts, what failed
  03_DATA/processed/wiki_codes.csv                    one row per code: title, page reached, coverage, vendor volume
  03_DATA/processed/wiki_groups.csv                   one row per covered article: codes, views by window, vendor demand
and prints the SHA-256 of each. In the project the predictor table must carry its frozen hash, or the script stops.

Usage: python3 wiki_collect.py
"""
import csv
import datetime as dt
import hashlib
import json
import re
import statistics
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PRED = ROOT / "03_DATA/processed/r1_predictors.csv"
FROZEN = "65c5c3cb2ca76e1e681acf4086703696b91293f4d8b7063310881da1f6e69cd4"
IN_PROJECT = PRED.is_file()
RAW = ROOT / "03_DATA/raw/wikipedia_2026-10" if IN_PROJECT else HERE / "recollected"
PROC = ROOT / "03_DATA/processed" if IN_PROJECT else HERE / "recollected"
UA = "UFI-research-paper03/1.0 (https://github.com/VenkataPagadalaGIT/ufi; vdepagadala@gmail.com) python-urllib"
MW = "https://en.wikipedia.org/w/api.php"
PV = "https://wikimedia.org/api/rest_v1/metrics/pageviews/per-article/en.wikipedia/all-access/user/{}/monthly/2024090100/2026093000"
MONTHS = [f"{y}{m:02d}" for y in (2024, 2025, 2026) for m in range(1, 13) if (2024, 9) <= (y, m) <= (2026, 9)]
PRIMARY = [m for m in MONTHS if "202410" <= m <= "202509"]          # the twelve months to the vendor exports
SHIFTED = [m for m in MONTHS if "202409" <= m <= "202508"]          # one month earlier
CLEAN6 = [m for m in PRIMARY if m <= "202502" or m >= "202509"]     # outside the Foundation's reclassified span
POST = ["202608", "202609"]                                          # the first two full months after launch
TITLE_RULE = re.compile(r"^Area codes? \d{3}")
PAUSE = 0.2  # seconds between requests: at most five per second
REQUESTS = 0


def log(msg):
    line = f"{dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} UTC  {msg}"
    print(line)
    with (RAW / "collection_log.txt").open("a") as f:
        f.write(line + "\n")


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def get(url, tries=5):
    """GET with the project's User-Agent; returns (status, text). 404 is returned; other failures are retried."""
    global REQUESTS
    for i in range(tries):
        REQUESTS += 1
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": UA}), timeout=60) as r:
                body = r.read().decode("utf-8")
                time.sleep(PAUSE)
                return r.status, body
        except urllib.error.HTTPError as e:
            if e.code == 404:
                time.sleep(PAUSE)
                return 404, e.read().decode("utf-8", "replace")
            if e.code == 429 or e.code >= 500:
                time.sleep(3 * (i + 1))
                continue
            raise
        except OSError:  # URLError, timeouts, connection resets, remote disconnects
            time.sleep(3 * (i + 1))
    log(f"FAILED after {tries} tries: {url}")
    raise SystemExit(f"gave up on {url}")


def mw(params, out):
    params = dict(params, format="json")
    url = MW + "?" + urllib.parse.urlencode(params)
    status, body = get(url)
    if status != 200:
        log(f"FAILED: MediaWiki {status} for {url}")
        raise SystemExit(f"MediaWiki request failed: {status}")
    j = json.loads(body)
    out.write(json.dumps({"url": url, "status": status, "body": j}) + "\n")
    return j


def pv_title(title):
    return urllib.parse.quote(title.replace(" ", "_"), safe="")


def covers(title, code):
    return bool(TITLE_RULE.match(title)) and re.search(rf"\b{code}\b", title) is not None


RAW.mkdir(parents=True, exist_ok=True)
PROC.mkdir(parents=True, exist_ok=True)
if IN_PROJECT:
    if sha(PRED) != FROZEN:
        raise SystemExit("REFUSE: r1_predictors.csv is not the frozen table")
    units = list(csv.DictReader(PRED.open()))
    log(f"start; {len(units)} units from r1_predictors.csv (sha256 {FROZEN[:12]})")
else:
    units = list(csv.DictReader((HERE / "wiki_codes.csv").open()))
    log(f"start; {len(units)} units from the released wiki_codes.csv; redirect lists and pageviews are read live and "
        f"may differ from the released files; writing to {RAW}")
codes = [r["code"] for r in units]
assert len(codes) == 372, len(codes)

# 1. Resolve "Area code {e}" for every code, 50 titles per request, following redirect chains
norm, redir, pages, missing = {}, {}, {}, set()
with (RAW / "resolution.jsonl").open("w") as res_out:
    for i in range(0, len(codes), 50):
        q = mw({"action": "query", "titles": "|".join(f"Area code {c}" for c in codes[i:i + 50]), "redirects": 1}, res_out)["query"]
        for n in q.get("normalized", []):
            norm[n["from"]] = n["to"]
        for r in q.get("redirects", []):
            redir[r["from"]] = r["to"]
        for p in q["pages"].values():
            if "missing" in p:
                missing.add(p["title"])
            else:
                pages[p["title"]] = int(p["pageid"])


def resolve(title):
    """Follow the redirect map to its end; returns (final title, titles on the way including the start)."""
    chain, seen = [title], {title}
    while chain[-1] in redir and redir[chain[-1]] not in seen:
        chain.append(redir[chain[-1]])
        seen.add(chain[-1])
    return chain[-1], chain


code_rows, chains = [], 0
with (RAW / "search_fallback.jsonl").open("w") as sf_out:
    for r in units:
        t0 = f"Area code {r['code']}"
        t1 = norm.get(t0, t0)
        target, chain = resolve(t1)
        if len(chain) > 2:
            chains += 1
            log(f"redirect chain for {t1}: {' -> '.join(chain)}")
        pid = pages.get(target)
        note = ""
        if pid is None:
            note = "title missing"
        elif not covers(target, r["code"]):
            note = f"title reaches another page: {target}"
        if note:  # one fixed fallback: the top hit of a title search for "area code e"
            hits = mw({"action": "query", "list": "search", "srsearch": f'"area code {r["code"]}"', "srlimit": 1,
                       "srnamespace": 0}, sf_out)["query"]["search"]
            if hits and covers(hits[0]["title"], r["code"]):
                target, pid, chain = hits[0]["title"], int(hits[0]["pageid"]), [t1, hits[0]["title"]]
                note = f"search fallback after '{note}'"
            else:
                target, pid = "", None
                note = f"not covered: {note}; search fallback found {hits[0]['title'] if hits else 'nothing'}"
        code_rows.append({"code": r["code"], "title": t1, "article": target if pid else "", "article_pageid": pid or "",
                          "covered": int(pid is not None), "coverage_note": note, "chain_titles": ";".join(chain),
                          "volume": r["volume"], "n_keywords": r["n_keywords"],
                          "in_service_after_2025_10_01": r["in_service_after_2025_10_01"]})
n_uncovered = sum(1 - c["covered"] for c in code_rows)
log(f"covered {len(code_rows) - n_uncovered} of {len(code_rows)} codes; not covered {n_uncovered}; redirect chains {chains}; "
    f"{len({c['article_pageid'] for c in code_rows if c['covered']})} distinct articles; "
    f"fallback used for {sum('fallback' in c['coverage_note'] for c in code_rows)}")

# 2. Every article-namespace redirect to each covered article, plus every title on each code's own path
groups = defaultdict(lambda: {"codes": [], "titles": set()})
for c in code_rows:
    if c["covered"]:
        g = groups[c["article_pageid"]]
        g["article"] = c["article"]
        g["codes"].append(c["code"])
        g["titles"].update([c["article"], c["title"], *c["chain_titles"].split(";")])
with (RAW / "redirects.jsonl").open("w") as red_out:
    for pid, g in groups.items():
        params = {"action": "query", "prop": "redirects", "rdlimit": "max", "rdnamespace": 0, "pageids": pid}
        while True:
            j = mw(params, red_out)
            for rd in j["query"]["pages"][str(pid)].get("redirects", []):
                g["titles"].add(rd["title"])
            if "continue" in j:
                params.update(j["continue"])
            else:
                break
all_titles = sorted({t for g in groups.values() for t in g["titles"]})
log(f"{len(groups)} articles, {len(all_titles)} titles including redirects")

# 3. Monthly views of every title
views, no_data = {}, []
with (RAW / "pageviews.jsonl").open("w") as pv_out:
    for k, t in enumerate(all_titles):
        url = PV.format(pv_title(t))
        status, body = get(url)
        pv_out.write(json.dumps({"title": t, "url": url, "status": status, "body": json.loads(body) if body.startswith("{") else body}) + "\n")
        views[t] = {m: 0 for m in MONTHS}
        if status == 404:
            no_data.append(t)
            continue
        if status != 200:
            log(f"FAILED: pageviews {status} for {t!r}")
            raise SystemExit(f"pageviews request failed for {t!r}: {status}")
        for it in json.loads(body)["items"]:
            views[t][it["timestamp"][:6]] = int(it["views"])
        if (k + 1) % 100 == 0:
            log(f"  {k + 1} of {len(all_titles)} titles read")
log(f"pageviews read for {len(all_titles)} titles; {len(no_data)} titles with no data at all (404); {REQUESTS} requests in all")

# 4. Files
t2pid = {t: pid for pid, g in groups.items() for t in g["titles"]}
with (RAW / "pageviews_monthly.csv").open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["title", "article_pageid", "month", "views"])
    for t in all_titles:
        for m in MONTHS:
            w.writerow([t, t2pid[t], m, views[t][m]])
for c in code_rows:
    c["own_title_views_primary"] = sum(views[c["title"]][m] for m in PRIMARY) if c["covered"] else ""
with (PROC / "wiki_codes.csv").open("w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(code_rows[0]))
    w.writeheader()
    w.writerows(code_rows)
grp_rows = []
for pid, g in sorted(groups.items(), key=lambda kv: int(kv[0])):
    cs = g["codes"]
    rows = [c for c in code_rows if c["code"] in cs]
    month_tot = {m: sum(views[t][m] for t in g["titles"]) for m in MONTHS}
    prim = [month_tot[m] for m in PRIMARY]
    med = statistics.median(prim)
    grp_rows.append({
        "article_pageid": pid, "article": g["article"], "codes": ";".join(cs), "n_codes": len(cs),
        "n_redirect_titles": len(g["titles"]) - 1, "n_titles_no_data": sum(t in no_data for t in g["titles"]),
        "views_primary": sum(prim), "views_primary_article_only": sum(views[g["article"]][m] for m in PRIMARY),
        "views_primary_median_x12": round(12 * med, 1), "views_primary_max_month": max(prim),
        "views_shifted": sum(month_tot[m] for m in SHIFTED), "views_clean6": sum(month_tot[m] for m in CLEAN6),
        "views_post": sum(month_tot[m] for m in POST), "views_all_months": sum(month_tot.values()),
        "dem": sum(int(c["volume"]) for c in rows), "n_keywords": sum(int(c["n_keywords"]) for c in rows),
        "late_codes": sum(int(c["in_service_after_2025_10_01"]) for c in rows),
        "zero_keyword_codes": sum(int(c["n_keywords"]) == 0 for c in rows)})
with (PROC / "wiki_groups.csv").open("w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(grp_rows[0]))
    w.writeheader()
    w.writerows(grp_rows)
log("done")
for p in (RAW / "resolution.jsonl", RAW / "search_fallback.jsonl", RAW / "redirects.jsonl", RAW / "pageviews.jsonl",
          RAW / "pageviews_monthly.csv", RAW / "collection_log.txt", PROC / "wiki_codes.csv", PROC / "wiki_groups.csv"):
    print(f"{sha(p)}  {p.relative_to(ROOT) if IN_PROJECT else p.name}")
