#!/bin/zsh
# Study W: write the manifest of the plan and scripts as committed, then stamp it with OpenTimestamps.
# Run after the commit that adds them and before wiki_collect.py is run. Usage: stamp_manifest.sh <ots binary>
set -e
cd "$(dirname "$0")/../.."
OTS=${1:?path to the ots client}
M=02_DESIGN/wikipedia_demand_372_manifest.txt
C=$(git rev-parse --short HEAD)
{
  echo "Study W (02_DESIGN/wikipedia_demand_372.md): manifest stamped with OpenTimestamps before any pageview of the study's units was collected."
  echo "Written $(date -u '+%Y-%m-%d %H:%M UTC'). 03_DATA/raw/wikipedia_2026-10/ and 03_DATA/processed/wiki_*.csv did not exist at this time."
  echo
  echo "Commit: $C (repository Research-Papers, Paper-03-user-first-intelligence)."
  echo
  echo "SHA-256 of the files as committed:"
  shasum -a 256 02_DESIGN/wikipedia_demand_372.md 04_ANALYSIS/wikipedia_demand/wiki_collect.py 04_ANALYSIS/wikipedia_demand/wiki_demand_analysis.py 04_ANALYSIS/wikipedia_demand/make_fig_wikipedia.py 03_DATA/processed/r1_predictors.csv
} > $M
cat $M
rm -f $M.ots
$OTS stamp $M
ls -la $M $M.ots
