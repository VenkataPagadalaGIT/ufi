"""Version 5.2, the abstract reordered to lead with the three measurements, which are the paper's evidence, and to
present the framework as built on them (independent measurement, writing and relevance: "the title and the first half
of the abstract present a framework the paper does not evaluate"). The title is the author's and is unchanged; no
number changes."""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()
old_open = ("People say what they want to know in many places that are not a search box, and keyword-volume tools see only the part that reaches a search engine in countable form. User First Intelligence (UFI) is a framework built on that premise: collect what people ask beyond the website; link it to the entities of an industry held under an ontology; keep structure, coverage, answerability and demand sources in separate roles; express user needs as competency questions; and score where the organization does not answer. An open implementation is released.\n\n"
            "Three measurements, made using two analytics platforms, a review dataset and a vendor index of AI answers, motivate it. On 381 area-code pages")
new_open = ("People say what they want to know in many places that are not a search box, and the commercial tools that search and AI-answer optimization rely on see only part of that demand, through models whose figures are often reported as if they were counts. This paper reports three measurements of what such instruments show and builds a framework on them.\n\n"
            "On 381 area-code pages")
old_close = ("The implication is that traffic estimates and cited sources have to be measured per instrument and per answer surface, not inferred. The scoring function is specified, not evaluated. No causal claim is made.")
new_close = ("Traffic estimates and cited sources therefore have to be measured per instrument and per answer surface, not inferred.\n\n"
             "User First Intelligence (UFI) is the framework built on that premise: collect what people ask beyond the website; link it to the entities of an industry held under an ontology; keep structure, coverage, answerability and demand sources in separate roles; express user needs as competency questions; and score where the organization does not answer. An open implementation is released; its scoring function is specified, not evaluated. No causal claim is made.")
for a, b in ((old_open, new_open), (old_close, new_close)):
    if s.count(a) != 1:
        raise SystemExit(f"REFUSE: {s.count(a)} matches for {a[:80]!r}")
    s = s.replace(a, b)
P.write_text(s)
i = s.index("## Abstract")
ab = s[i:s.index("\n## ", i + 5)]
print(f"abstract words: {len(ab.split()) - 2}")
