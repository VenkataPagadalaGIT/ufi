"""Version 5.5, third edit (14 November 2026): points raised by the three blind measurements of version 5.5 and by a
mechanical check of citations, links and cross-references.

1. Table 2's monthly rows were called "completed-month totals". How either vendor forms a month's figure was not
   recorded, and the first instrument's own daily series (Table 5) shows its monthly point lying inside months in which
   the daily estimate more than doubled. Section 5.1 now says so and gives the August and September ratios against
   the daily series (17.0x and 6.3x, from 876,153/51,517 and 1,534,362/244,041), so that a reader does not take the
   whole of 27.1x for a difference between instruments. Section 12, Appendix A and Table D1 point to it.
2. Appendix F names its table (Table F1), which the text introduced only as "the inventory below".
(The reference list's filing of "The Motley Fool" under M is a change in build_tex.py.)

Each replacement must match exactly once and must not already be applied.
"""
import pathlib

p = pathlib.Path(__file__).with_name("manuscript_v50.md")
s = p.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


NEW = ("**What a month's figure is was not recorded, and in a section's first months it matters.** The reads took each "
       "dashboard's monthly view as displayed and did not record how either vendor forms a month's point. The first "
       "instrument's own daily series (Table 5) reads 22,016 on day 15 and 51,517 on day 30 against 32,281 for August, and "
       "92,897 on day 45 and 244,041 on day 60 against 150,113 for September, so its monthly point sits inside a month in "
       "which its daily estimate more than doubled, as an average over the month would. If the second instrument's monthly "
       "point describes a date late in the month, part of the August and September ratios is a difference of dates and not "
       "of instruments: against the first instrument's values on day 30 (25 August) and day 60 (24 September) they are "
       "17.0x and 6.3x, not 27.1x and 10.2x (18.7x and 7.2x worldwide against worldwide). The growth comparison above "
       "carries the same caution. The October row and the cross-section of Section 5.5 are read on one date for both "
       "instruments and do not. The range 7.5x to 27.1x is therefore the range of the two monthly views as displayed, and "
       "the bound of Section 5.6 holds at 17.0x with a factor of 4.1 in place of 5.2.")

rep([
    ("The June to September rows are completed-month totals.",
     "The June to September rows are each dashboard's figure for the completed month, labelled \"total\" in the rows; how a month's figure is formed was not recorded (fourth note below)."),
    ("June to September are completed-month totals; October is each instrument's current monthly run-rate.",
     "June to September are each dashboard's figure for the completed month; October is each instrument's current monthly run-rate."),
    ("Three things about this table and Figure 2.", "Four things about this table and Figure 2."),
    ("Section 5.6 takes up what the narrowing can and cannot be attributed to.\n\n### 5.2",
     "Section 5.6 takes up what the narrowing can and cannot be attributed to.\n\n" + NEW + "\n\n### 5.2"),
    ("**Measurement 1 (Section 5).** Instrumentation is its subject rather than a caveat on it, and no outcome is a measured visit.",
     "**Measurement 1 (Section 5).** Instrumentation is its subject rather than a caveat on it, and no outcome is a measured visit. The July to September ratios of Table 2 compare monthly points whose construction was not recorded, and part of them may be a difference of dates (Section 5.1)."),
    ("and a stale copy of Figure 5 that printed −0.09 for −0.11 was replaced.",
     "and a stale copy of Figure 5 that printed −0.09 for −0.11 was replaced. Version 5.5 adds that Table 2's monthly rows are the dashboards' monthly views, whose construction was not recorded, and gives the August and September ratios against the first instrument's daily series, 17.0x and 6.3x (Section 5.1)."),
    ("| M1 visits ratio | Semrush over Ahrefs estimated monthly visits: unmatched; worldwide; US to US (estimated) |",
     "| M1 visits ratio | Semrush over Ahrefs estimated monthly visits, monthly views as displayed: unmatched; worldwide; US to US (estimated). Against Ahrefs' daily series, August 17.0x and September 6.3x (Section 5.1) |"),
    ("the inventory below is the author's working list, of November 2026,", "the inventory in Table F1 is the author's working list, of November 2026,"),
])
if "—" in s:
    raise SystemExit("REFUSE: em dash")
p.write_text(s)
print("edit_v55c applied")
