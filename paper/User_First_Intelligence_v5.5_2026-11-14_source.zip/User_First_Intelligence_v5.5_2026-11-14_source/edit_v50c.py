"""Version 5.0, fixes from the TOIS re-review (08_REVIEW/R10_editorial_TOIS.md, "Re-review after revision":
N-R1 to N-R8 and the partly fixed E6, E7, E12, E24) and, where they overlap, the PhD re-examination.
New numbers: 04_ANALYSIS/review_demand/supplement_r10_output.txt (modal attribution +0.468, p 0.058) and
04_ANALYSIS/instrument_divergence/instrument_extra_output.txt (Spearman +0.937, p 7e-06; two reversed pairs).
Edits made by hand after this script ran: "call-centre" to "call-center"; the abstract's first two sentences merged
into one ("People say what they want to know in many places that are not a search box, and keyword-volume
tools see only the part that reaches a search engine in countable form.") to keep it near 340 words.
"""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:  # already applied: an insertion keeps its anchor, so a second run would insert twice
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    # branch correlation depends on attribution (TOIS E2 residual)
    ("review demand and search volume rank the taxonomy's branches alike (Spearman +0.75) but barely agree on topics (+0.19)",
     "review demand and search volume agree only roughly on the taxonomy's branches (Spearman +0.47 to +0.78, depending on how labels are assigned to branches) and barely on topics (+0.19)"),
    ("the two demand signals rank the taxonomy's branches alike but size them very differently, and barely agree on topics, most for complaints.",
     "the two demand signals agree only roughly on the taxonomy's branches, size them very differently, and barely agree on topics, most for complaints."),
    ("At the level of the taxonomy's 17 top-level branches the two signals rank alike and size differently.",
     "At the level of the taxonomy's 17 top-level branches the two signals agree only roughly, and size the branches very differently."),
    ("against +0.78 in an earlier computation that summed each label's volume over every level and assigned it to one branch.",
     "against +0.78 in an earlier computation that summed each label's volume over every level and assigned it to one branch, and +0.47 (p = 0.06) if each label's mentions go to the branch holding most of its nodes; the branch-level agreement therefore depends on how a label that occurs in several branches is attributed."),
    ("counting the 26,809 linkable labels that no review mentions as zero, it is +0.27. It is +0.28 among the 213 labels with at least twenty mentions,",
     "counting the 26,809 linkable labels that no review mentions as zero, it is +0.27; both p < 0.001. It is +0.28 (p < 0.001) among the 213 labels with at least twenty mentions,"),
    ("what people write in their own words and what a volume tool counts rank the broad areas of demand alike, size them very differently and barely agree on topics,",
     "what people write in their own words and what a volume tool counts agree only roughly on the broad areas of demand, size them very differently and barely agree on topics,"),
    ("the two ranked the taxonomy's branches alike (+0.75) while sizing them very differently,",
     "the two agreed only roughly on the taxonomy's branches (+0.47 to +0.78, depending on attribution) while sizing them very differently,"),
    # N-R1: the eleven "wait" labels
    ("and most concern call waiting or waitlists rather than waiting in a store; the one that reviews mention carries 12.",
     "and none concerns waiting in a store: they cover call waiting, waitlists, activation and unlock delays, call-centre wait times and a campaign name; the one that reviews mention carries 12."),
    ("while the whole taxonomy holds 11 labels mentioning waiting, mostly about call waiting and waitlists, with 622 searches a month.",
     "while the whole taxonomy holds 11 labels mentioning waiting, none about waiting in a store, with 622 searches a month."),
    # N-R2: ordering on one instrument
    ("so a single-vendor ranking of sections is right in direction when sections differ several-fold in size and less reliable when they are within a factor of three (9 of 15 pairs);",
     "so a single-vendor ranking of sections is right in direction when sections differ several-fold on both instruments and less reliable when they are within a factor of three (9 of 15 pairs); measured on one instrument alone, two pairs six to seven times apart were ordered the other way on the second;"),
    ("while a single-vendor ranking of sections is right in direction when sections differ several-fold in size.",
     "while a single-vendor ranking of sections is right in direction when sections differ several-fold on both instruments; on one instrument alone, two pairs six to seven times apart were reversed on the other."),
    ("Ordering agreement holds for sections that differ several-fold in size and is weaker within a factor of three.",
     "Ordering agreement holds for sections that differ several-fold on both instruments and is weaker within a factor of three; on one instrument alone, two pairs six to seven times apart were reversed."),
    # N-R3: the spread describes these twelve
    ("Taken across the twelve, the unmatched ratio has a geometric mean of 1.13 and a geometric standard deviation of 3.1; read as a spread for another section of this domain, it runs from about 0.12x to 10.6x.",
     "Taken across the twelve, the unmatched ratio has a geometric mean of 1.13 and a geometric standard deviation of 3.1, a normal range on the log scale of about 0.12x to 10.6x; with twelve purposively chosen sections this describes them and is not a prediction for another section."),
    # N-R4: which script prints which statistic
    ("**every statistic quoted in this section is printed by the script `analyze.py` released beside them**.",
     "**every statistic quoted in this section is printed by the script `analyze.py` released beside them**, except the spread and the size-banded agreement, which are printed by `instrument_extra.py`, prepared for release."),
    # N-R5: "should"
    ("which is why the framework reads its outcomes on more than one.",
     "which is why the framework should read its outcomes on more than one."),
    ("That is why the framework reads its outcomes on more than one instrument.",
     "That is why the framework should read its outcomes on more than one instrument; the released implementation has no outcome layer yet."),
    # N-R6: capture mode per quantity
    ("Monthly figures are each instrument's own history as read on the stated date, not values captured month by month; a vendor may revise its history, and the 13 October re-read of Semrush found its completed months unrevised.",
     "The monthly figures in Tables 2 and 3 are each instrument's own history as read on 10 and 11 October, not values captured month by month; Table 5 states the source of each checkpoint value. A vendor may revise its history, and the 13 October re-read of Semrush found its completed months unrevised."),
    # N-R8
    ("two commercial analytics platforms' estimates of the same pages differ by up to thirty times,",
     "two commercial analytics platforms' estimates of the same pages differ by up to about 30 times worldwide (33 times US to US, estimated),"),
    # E6 residual: cite the single-vendor practice to the paper's own related work
    ("and they are reported the way measurements are reported: as quantities, sometimes to five significant figures, usually from one vendor, rarely with any statement of uncertainty.",
     "and they are often reported the way measurements are reported: as quantities, usually from one vendor and without a statement of uncertainty, a practice the validity studies in Section 2 caution against [Kamerer 2013; Prantl & Prantl 2018; Jansen, Jung & Salminen 2022]."),
    # E12: p-values and the variance decomposition defined
    ("is +0.94 (Kendall's tau +0.82, 60 of 66 pairs concordant).", "is +0.94 (p < 0.001; Kendall's tau +0.82, 60 of 66 pairs concordant)."),
    ("(unweighted decomposition).", "(the share of the total sum of squares of the 88 cell shares explained by the surface means and by the sector means, unweighted; the remainder is interaction)."),
    # E24: the 455 pointer and the Table 1 caption
    ("The Ahrefs figure of 17,206 stored answers is reported in Table 5 as a single-instrument count, with its 455 distinct cited pages in Section 3, and is not paired with a second reading.",
     "The Ahrefs figure of 17,206 stored answers is reported in Table 5 as a single-instrument count and is not paired with a second reading."),
    ("for the measured quantities in Sections 4 to 10.", "for the measured quantities in Sections 5 to 10."),
    # E7: published versions
    ("Gienapp, L., Scells, H., Deckers, N., Bevendorff, J., Wang, S., Kiesel, J., Syed, S., Fröbe, M., Zuccon, G., Stein, B., Hagen, M., & Potthast, M. (2024). *Evaluating generative ad hoc information retrieval.* arXiv:2311.04694.",
     "Gienapp, L., Scells, H., Deckers, N., Bevendorff, J., Wang, S., Kiesel, J., Syed, S., Fröbe, M., Zuccon, G., Stein, B., Hagen, M., & Potthast, M. (2024). Evaluating generative ad hoc information retrieval. In *Proceedings of the 47th International ACM SIGIR Conference on Research and Development in Information Retrieval (SIGIR '24)* (pp. 1916–1929). ACM. https://doi.org/10.1145/3626772.3657849"),
    ("Liu, N. F., Zhang, T., & Liang, P. (2023). *Evaluating verifiability in generative search engines.* arXiv:2304.09848.",
     "Liu, N. F., Zhang, T., & Liang, P. (2023). Evaluating verifiability in generative search engines. In *Findings of the Association for Computational Linguistics: EMNLP 2023* (pp. 7001–7025). ACL. https://doi.org/10.18653/v1/2023.findings-emnlp.467"),
    # PhD re-examination items
    ("observed for 77 days, with ranking positions captured daily and the other quantities at seven checkpoints and monthly.",
     "observed for 77 days, with ranking positions from the instrument's daily series and the other quantities at seven checkpoints and as monthly histories (Section 4.1 states how each was read)."),
    ("Primary outcome: top-ten presence on the frozen set at day 37.", "Primary outcome: top-ten presence on the frozen set at day 37, read on both instruments."),
    ("Like for like, Semrush's worldwide count", "Like for like in territory (Section 5.6 notes that how Semrush aggregates its worldwide count is not documented), Semrush's worldwide count"),
    ("a preference for the per-entity form that this observation runs against (Appendix B)", "a preference for the per-entity form that this observation questions (Appendix B)"),
    ("A label's volume is summed over the nodes that carry it, which can include nested nodes.",
     "A label's volume is summed over the nodes that carry it, which can include nested nodes; computed instead on each node's own volume (its volume less its children's), the two label-level correlations are +0.16 and +0.26."),
    ("the one that reviews mention carries 12.",
     "the one that reviews mention carries 12. Labels for the remedies, appointments, queues and check-in, number 15 with 13,520 searches a month, among them one for scheduling a store appointment."),
    ("prepared for release with the Section 7 artifacts (open item 3).",
     "prepared for release with the Section 7 artifacts (open item 3); they are transcribed from those tables, and the dashboard reads behind them are not archived."),
    ("Manuscript version 5.0, 13 October 2026.", "Manuscript version 5.1, 13 October 2026."),
    ("Version 5.0 restructured the paper around its three measurements (Sections 5 to 7) and stated its single thread in Section 1.2 and the conclusion; no number changed.",
     "Version 5.0 restructured the paper around its three measurements (Sections 5 to 7) and stated its single thread in Section 1.2 and the conclusion. Version 5.1 corrected the reviews analysis (branch agreement reported as +0.47 to +0.78 depending on how labels are attributed, branch shares recomputed on each branch's own volume, and the taxonomy-wide count of waiting labels, 11 rather than one); added analyses of growth, of the decomposition under both territory pairings, of ordering by size and of dispersion to Measurement 1; framed the hub observation as a hypothesis; stated the vendor's collection method for Measurement 3; and added eleven references."),
])
lines = s.split("\n")
idx = {k: next(i for i, x in enumerate(lines) if x.startswith(k)) for k in
       ("1. **The User First Intelligence framework**", "2. **Measurement 1,", "3. **Measurement 2,", "4. **Measurement 3,", "5. **The deployment as context**")}
items = [lines[idx[k]] for k in idx]
fw, m1, m2, m3, dep = items
new = ["1." + m1[2:], "2." + m2[2:], "3." + m3[2:], "4." + fw[2:], "5." + dep[2:]]
for k, v in zip(idx, new):
    lines[idx[k]] = v
s = "\n".join(lines)
P.write_text(s)
print(f"{len(s.split()):,} words")
