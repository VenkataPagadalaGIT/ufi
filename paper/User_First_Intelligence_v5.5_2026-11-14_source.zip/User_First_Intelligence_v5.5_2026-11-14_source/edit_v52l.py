"""Version 5.2, fixes from the independent reproduction of the source bundle (08_REVIEW/reproduction_v5.2_2026-10-15/;
136 of 173 quoted numbers matched, none mismatched, 37 need withheld data) and from the independent literature search
(01_LITERATURE/novelty_search_scout_2026-10-15/; verdict PARTLY for both novelty claims, with close works named).

- Stakes: the OpenAlex work list held three duplicates; 456 works, not 459 (86% unchanged).
- Section 5.5's attribution: what analyze.py prints, and what instrument_extra.py now prints (Table 4's ratio columns,
  the per-prefix figures, the intervals); power is now computed (37.8%).
- Appendix C: Tables C1 and C2 are also printed from the released aggregates (section7_from_aggregates.py).
- Section 7.1: the pilot's figures come from a script section that is not released.
- Section 14: the reproducibility statement reports the independent reproduction.
- Section 2 and the introduction: the independent search, and the close works it found, each checked against
  Crossref, DataCite, arXiv or the publisher's page (Tinuiti's report could not be opened and is not cited).
"""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:  # already applied: an insertion keeps its anchor, so a second run would insert twice
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("in OpenAlex, 459 works name Ahrefs, Semrush or Similarweb in their title or abstract, 28 of them published in 2020, 88 in 2025 and 111 in 2026 to mid-October, and 86% name only one of the three,",
     "in OpenAlex, 456 works name Ahrefs, Semrush or Similarweb in their title or abstract, 27 of them published in 2020, 87 in 2025 and 110 in 2026 to mid-October, and 86% name only one of the three,"),
    ("| 459; 86% (read 14 October 2026) | `vendor_reliance` |", "| 456; 86% (read 14 October 2026) | `vendor_reliance` |"),
    ("and **every statistic quoted in this section is printed by the script `analyze.py` released beside them**, except the p-value of the ordering correlation, the spread and the size-banded agreement, which are printed by `instrument_extra.py`, prepared for release.",
     "and **every statistic quoted in this section is printed by a script**: `analyze.py`, released beside them, or `instrument_extra.py`, prepared for release, which prints the ordering correlation's significance and intervals, the spread, the size-banded agreement, the ratio columns of Table 4 and the remaining per-prefix figures."),
    ("Twelve prefixes give roughly 38% power to detect a correlation of 0.5,",
     "Twelve prefixes give about 38% power to detect a correlation of 0.5 (37.8% by the Fisher approximation),"),
    ("The script `cross_sector_sensitivity2.py` prints Tables C1 and C2.",
     "The script `cross_sector_sensitivity2.py` prints Tables C1 and C2 from the raw exports, and `section7_from_aggregates.py` prints them, with every other Section 7 number the aggregates allow, from the released aggregates alone."),
    ("and reddit.com was in the top three on every surface except Copilot (240th). The predictions below were written after seeing it,",
     "and reddit.com was in the top three on every surface except Copilot (240th); these figures are printed by the project's copy of `cross_sector_sensitivity.py`, whose pilot section is not released because the pilot's brand set and exports are withheld. The predictions below were written after seeing it,"),
    ("Every statistic in Sections 5.5 and 6, and every share, rank, prediction tally and sensitivity in Section 7, is printed by a script; the script for Section 5.5, `analyze.py`, is public; `instrument_extra.py`, which prints the further Measurement 1 statistics, and the scripts for Sections 6 and 7 are prepared for release (open item 2).",
     "Every statistic in Sections 5.5 and 6, and every share, rank, prediction tally and sensitivity in Section 7, is printed by a script; the script for Section 5.5, `analyze.py`, is public; `instrument_extra.py`, which prints the further Measurement 1 statistics, and the scripts for Sections 6 and 7 are prepared for release (open item 2), with `section7_from_aggregates.py` printing Section 7's numbers from the released aggregates for readers without the withheld exports. A separate agent reproduced the source bundle in a clean folder on 15 October 2026: of 173 numbers the paper quotes, 136 matched what the released scripts and data give, none differed, and 37 could not be checked because they need withheld data (`08_REVIEW/reproduction_v5.2_2026-10-15/`)."),
    ("A search of OpenAlex and Crossref on 14 October 2026, whose queries and screened results are released with the paper's data, found vendor tools compared with first-party analytics and with each other on established domains (Section 2), but no comparison of two vendors' records of a single object followed from a known start date; this paper reports one.",
     "A search of OpenAlex and Crossref on 14 October 2026, and an independent search of five databases with citation chasing by a separate agent on 15 October, both released with the paper's data, found vendor tools compared with first-party analytics and with each other on established domains (Section 2), but no comparison of two vendors' records of a single object followed from a known start date; to the extent of those searches, this paper reports the first."),
    ("which overlapped so little that the choice of tool determined the findings [Font-Julián et al. 2026].",
     "which overlapped so little that the choice of tool determined the findings [Font-Julián et al. 2026], with traffic compared at global and country level for the same two publishers [Font-Julián et al. 2025]; SEO tools have also been used to compare the visibility of university library sites with that of their universities [Vállez & Ventura 2020]."),
    ("Vendor-tracked brand visibility has also been measured:",
     "Comparisons across industries exist, in frames their authors chose: a fixed panel of 480 questions across eight industries sent to Google's AI Overviews, ChatGPT, Perplexity and Gemini [Hendricks 2026]; controlled experiments across verticals that found AI search engines favoring earned, third-party sources over brand-owned and social content, unlike Google [Chen et al. 2025]; query intent and Google rank as predictors of citation across four chat assistants and eight verticals [Lee 2026]; and a vendor index of 6,095,520 citations from seven engines in 17 undefined industries [OtterlyAI 2026]. Vendor-tracked brand visibility has also been measured:"),
])

NEW = {  # inserted after the reference that precedes each alphabetically (accents ignored, as the build sorts)
    "Chapekis, A.": "Chen, M., Wang, X., Chen, K., & Koudas, N. (2025). *Generative engine optimization: How to dominate AI search.* arXiv:2509.08919.",
    "Font-Julián, C. I., Lopezosa": "Font-Julián, C. I., Orduña-Malea, E., Lopezosa, C., & Aguillo, I. F. (2025). *SEO metrics for enhanced academic research visibility: A comparative study of global and country-level traffic* [Preprint]. SocArXiv. https://doi.org/10.31235/osf.io/j4ryx_v1",
    "Haveliwala, T. H.": "Hendricks, B. L. (2026). *The Answer Index: What AI answer engines cite across eight industries* [Data set and report]. Zenodo. https://doi.org/10.5281/zenodo.22242102",
    "Le Pochat, V.": "Lee, A. (2026). *Query intent and Google rank as joint predictors of AI citation: A multi-platform observational study.* Zenodo. https://doi.org/10.5281/zenodo.18653093",
    "Morris, M. R.": "OtterlyAI. (2026, updated September 8). *AI search index.* https://otterly.ai/blog/ai-search-index/ (vendor report: seven engines, 6,095,520 citations, US, July and August 2026; accessed 15 October 2026.)",
    "Taylor, R. S.": "Vállez, M., & Ventura, A. (2020). Analysis of the SEO visibility of university libraries and how they impact the web visibility of their universities. *The Journal of Academic Librarianship, 46*(4), 102171. https://doi.org/10.1016/j.acalib.2020.102171",
}
lines = s.split("\n")
for anchor, entry in NEW.items():
    idx = [i for i, x in enumerate(lines) if x.startswith(anchor)]
    if len(idx) != 1:
        raise SystemExit(f"REFUSE: {len(idx)} reference lines start with {anchor!r}")
    lines[idx[0] + 1:idx[0] + 1] = ["", entry]
s = "\n".join(lines)
P.write_text(s)
print(f"{len(s.split()):,} words")
