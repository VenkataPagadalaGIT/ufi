"""Version 5.5, eighth edit (14 November 2026): how the class was found.

The paper said only that the gap was "identified through competitor keyword exports" and that the deployment was "not a
run of the framework". On 14 November 2026 the author gave the account of how the area-code class was found: the
industry's competitors, direct and indirect, and their topics and queries were connected in one graph, and the class
became visible there after it had not been visible in lists read by hand. The author's platform holds dated records
consistent with that (read by the assistant on the same day and noted in the project, outside this bundle): a build-log entry and a rescoring note of 4 July 2026, and a snapshot committed on 18 July, eight days
before the section launched. A new Section 3.2 gives the account and the records, labelled as the author's and as not
released, and says what they do not show. The employer's commercial reasons for the content are not in the paper.

Each replacement must match exactly once and must not already be applied.
"""
import pathlib

p = pathlib.Path(__file__).with_name("manuscript_v50.md")
s = p.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


SEC = ("### 3.2 How the class was found\n\n"
       "This is the author's account, with the dated records that bear on it. The records belong to the author's own platform "
       "and are not released, and nothing in this subsection tests the framework's score. The author gathered the industry's "
       "competitors, direct and indirect, collected the topics they are found on, and connected those topics and their queries "
       "in one graph on that platform; the taxonomy of Section 6.1 was exported from the same platform. By the author's account "
       "the class had not been visible in keyword lists read by hand and became visible in the graph: the area-code queries "
       "gathered in one node, the carriers ranked for them only with pages about other things, such as store pages, and the "
       "pages written for the topic belonged to third parties, the directories and voice vendors of condition 6. The graph also "
       "showed what the topic connects to; in the snapshot named below its sub-topics include location and international "
       "calling. The platform's records are consistent with the account. On 4 July 2026 its build log records 1,196 area-code "
       "keywords carrying 6.7 million monthly searches being gathered into one node, and a note of the same day records a "
       "competitor's store pages ranking for area-code lookups; a snapshot committed on 18 July shows that node with 14,164 "
       "keywords. The section launched on 26 July. This is discovery from one kind of source, keyword data joined to a list of "
       "competitors. Section 11.2 states what the deployment did not do, and Section 13 describes the test that would show "
       "whether the score ranks such opportunities better than search volume does.\n\n")

rep([
    ("The deployment reported here was built from a gap identified through one of those surfaces, competitor keyword exports, before the framework's other surfaces were implemented; it is a case of the kind of gap the framework targets, not a run of the framework.",
     "The deployment reported here was built from a gap found in the framework's graph when it held one of those surfaces, competitor keyword exports, and before the others were implemented (Section 3.2); it is a case of the graph finding the kind of gap the framework targets, not a run of the whole framework and not a test of its score."),
    ("and Section 14 treats it as an ethics question rather than a tactic.\n\n## 4 Measurement design",
     "and Section 14 treats it as an ethics question rather than a tactic.\n\n" + SEC + "## 4 Measurement design"),
    ("No figure in this paper is drawn from them; the cost figures in Section 11.1 are the author's reconstruction from project records.",
     "No figure in this paper is drawn from them; the cost figures in Section 11.1 are the author's reconstruction from project records. The build log and snapshot of the author's platform cited in Section 3.2 are not released either."),
    ("and Appendix F transcribes the author's inventory.",
     "and Appendix F transcribes the author's inventory. Section 3.2 is the author's account as given to the assistant on 14 November 2026; the assistant read the platform's records it cites."),
])
if "—" in s:
    raise SystemExit("REFUSE: em dash")
p.write_text(s)
print("edit_v55h applied")
