"""Version 5.5, fourth edit (14 November 2026): three facts the author stated on 14 November 2026, which the paper had
left vague and an independent assessor had asked for.

1. The Ahrefs and Semrush subscriptions behind the Section 5 reads are the author's own personal accounts.
2. The DataForSEO review export and the telecom taxonomy of Section 6 were made under the author's own license and on
   the author's own platform, not for the organization.
3. The author made every export of 13 and 14 November 2026 (Section 7.7) by hand in the vendor's web interface.

Each replacement must match exactly once and must not already be applied.
"""
import pathlib

p = pathlib.Path(__file__).with_name("manuscript_v50.md")
s = p.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("were read from the vendors' web dashboards under paid subscriptions held for other work (Section 11.1), and the Section 7 exports",
     "were read from the vendors' web dashboards under the author's own paid subscriptions, held for other work (Section 11.1), and the Section 7 exports"),
    ("Ahrefs and Semrush subscriptions already held for other work; no incremental spend attributable to this deployment",
     "the author's own Ahrefs and Semrush subscriptions, already held for other work; no incremental spend attributable to this deployment"),
    ("obtained through DataForSEO under its license and exported on 8 September 2026",
     "obtained through DataForSEO under the author's own license and exported on 8 September 2026"),
    ("built by the author's clustering engine from 1,898,584 keywords",
     "built by the author's clustering engine, on the author's own platform, from 1,898,584 keywords"),
    ("The review dataset in Section 6 was obtained through DataForSEO, a licensed data provider, under its terms;",
     "The review dataset in Section 6 was obtained through DataForSEO, a licensed data provider, under the author's own license and its terms;"),
    ("The exports of Section 7.7 were made on 13 and 14 November 2026 from the same vendor's web interface, by the author according to the author's statement; the records kept with them show a script, run by an AI coding assistant, filing each downloaded file and checking its row count, and no script operating the vendor's interface.",
     "The author made the exports of Section 7.7 by hand on 13 and 14 November 2026 in the same vendor's web interface; a script, run by an AI coding assistant, filed each downloaded file and checked its row count, and no script or assistant operated the vendor's interface."),
    ("which any subscriber can re-read, or a count of the section's public pages. Second, the organization is not named.",
     "which any subscriber can re-read, or a count of the section's public pages. The accounts behind the figures are not the organization's either: the Section 5 reads were made under the author's own subscriptions, the Section 6 export and taxonomy under the author's own license and on the author's own platform, and the Section 7 exports under the agency's subscription. Second, the organization is not named."),
])
if "—" in s:
    raise SystemExit("REFUSE: em dash")
p.write_text(s)
print("edit_v55d applied")
