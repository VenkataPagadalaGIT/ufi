"""Version 5.2, 15 October 2026: from the final blind paper-measure runs on the packaged v5.2 (sha 499b89df; median
7.2). Each source below was checked at the source on 15 October 2026.

- Abstract: the estimates cover the whole section (381 code pages and 53 hubs), not the code pages alone.
- Section 4.1: one vendor figure (Semrush's worldwide keyword count) was read by the author, not the assistant.
- Section 5.1: the vendor ratios are ratios of two point estimates and carry no stated uncertainty.
- Section 13: the amendment's long path ran across the column gap; it is described instead.
- Section 2 and 7.6: three vendor reports with author-chosen frames (Tinuiti 2026, built on Profound; Punturo et al.
  2026 for Profound; Yext 2025), and the contrast between their Perplexity social shares and Section 7's.
- Appendix B: the score positioned against the practitioner method, competitor keyword-gap analysis, from the
  vendors' own documentation (Ahrefs Help Center; Semrush Knowledge Base).
"""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v50.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:110]!r}")
        if b in s:
            raise SystemExit(f"REFUSE: already applied: {b[:110]!r}")
        s = s.replace(a, b)


rep([
    ("On 381 area-code pages of a large US telecommunications provider, observed from zero, two commercial analytics platforms",
     "On the area-code section of a large US telecommunications provider's website (381 code pages and 53 hubs), observed from zero, two commercial analytics platforms"),
    ("**How the figures were read.** Every vendor figure was read from the vendors' web interfaces by an AI browser assistant",
     "**How the figures were read.** Every vendor figure but one (Semrush's worldwide keyword count in Section 5.2, read by the author) was read from the vendors' web interfaces by an AI browser assistant"),
    ("Estimated visits are a click model over an estimated volume at an estimated position. No figure in this paper is a measured visit.",
     "Estimated visits are a click model over an estimated volume at an estimated position. No figure in this paper is a measured visit. Neither vendor states an uncertainty for its estimates, so the ratios between them are ratios of two point estimates and carry none; what the paper can show is how they range across months and sections."),
    ("a dated amendment kept apart from the stamped plan records this (`02_DESIGN/framework_retro_test_381_amendment_2026-10-15.md`).",
     "a dated amendment, stamped separately and released with the plan's manifest, records this."),
    ("and a vendor index of 6,095,520 citations from seven engines in 17 undefined industries [OtterlyAI 2026].",
     "and a vendor index of 6,095,520 citations from seven engines in 17 undefined industries [OtterlyAI 2026]. Other vendor reports, built on their own tools, publish source shares by platform for categories they define: social sources made up 31% of Perplexity's citations against about 7% of ChatGPT's in nine consumer categories in January 2026 [Tinuiti 2026], 19.4% against 5.3% across 15 industries [Punturo et al. 2026], and brand-managed sources 86% of the citations of three engines in four industries [Yext 2025]."),
    ("medians over cells weight every sector equally, although cells range from 860 to 18,381,848 incidences (Appendix C gives each cell's size).",
     "medians over cells weight every sector equally, although cells range from 860 to 18,381,848 incidences (Appendix C gives each cell's size). Vendor reports on other universes and tools put Perplexity's share of social sources far higher (19.4% to 31%; Section 2) than the 4.6% median video-and-community share found here, so how a surface ranks on source mix depends on the instrument and the universe of answers, which is Measurement 1's lesson applied to answer surfaces."),
    ("which corresponds to the score's coverage term when an organization's content is represented as a knowledge base.",
     "which corresponds to the score's coverage term when an organization's content is represented as a knowledge base. The practitioner method closest to the score is competitor gap analysis in commercial SEO tools, which lists the keywords that competitors rank for and a site does not [Ahrefs 2026; Semrush n.d.]; the deployment's own gap was found from competitor keyword exports (Section 1). The score differs in three respects: it scores the entities of an industry's ontology rather than keyword strings, so one entity's many phrasings count once; it takes demand from surfaces beyond keyword tools; and it keeps the organization's coverage, competitors' coverage and answerability as separate terms, competitor coverage being only one of them. Study R1's second hypothesis tests the competitor-gap signal (`cov_K`) directly."),
])

NEW = {  # inserted before the reference that follows each alphabetically
    "Allaham, M.": "Ahrefs. (2026, September 3). *How to use Content Gap to find keyword ideas from competitor websites* [Help center article]. https://help.ahrefs.com/en/articles/9025740-how-to-use-content-gap-to-find-keyword-ideas-from-competitor-websites",
    "Rasool, A.": "Punturo, B., Torres Llorca, D., & Fishkin, G. (2026, January 8). *Who shapes AI answers? Introducing enhanced citation categories* [Vendor report]. Profound. https://tryprofound.com/blog/enhanced-citation-categories",
    "Shao, Y.": "Semrush. (n.d.). *How to use Keyword Gap?* [Knowledge base article]. Retrieved October 15, 2026, from https://www.semrush.com/kb/28-keyword-gap",
    "Vállez, M.": "Tinuiti. (2026). *Q1 2026 AI citation trends report* [Vendor report; data from the Profound tool]. https://tinuiti.com/research-insights/research/ai-citation-trends-report-q1-2026/",
    "Zhao, H.": "Yext. (2025, October 9). *Yext research: 86% of AI citations come from brand-managed sources, clarifying how marketers can compete in the AI search era* [Press release]. https://yext.com/about/news-media/ai-citations-release",
}
lines = s.split("\n")
for anchor, entry in NEW.items():
    idx = [i for i, x in enumerate(lines) if x.startswith(anchor)]
    if len(idx) != 1:
        raise SystemExit(f"REFUSE: {len(idx)} reference lines start with {anchor!r}")
    lines[idx[0]:idx[0]] = [entry, ""]
s = "\n".join(lines)
P.write_text(s)
k = s.index("## Abstract")
print(f"{len(s.split()):,} words; abstract {len(s[k:s.index(chr(10) + '## ', k + 5)].split()) - 2} words")
