"""Strengthen v4.9 as one paper: three measurements as their own sections, five contributions,
like-for-like ratio in the abstract, shorter retraction passages, Appendix A summarized (full history
moved to CHANGELOG_versions.md), and the vendor paragraph reduced to a factual method statement at the
author's decision (13 October 2026).

Order: (1) content edits written in the old numbering, (2) cross-references renumbered on every
non-heading line, (3) headings renumbered, (4) ranges whose meaning changed fixed by hand.
Old -> new: 5.7 -> 6, 5.8 -> 7, 6 -> 8, 7 -> 9, 8 -> 10, 9 -> 11, 10 -> 12, 11 -> 13, 12 -> 14, 13 -> 15.
"""
import re
from pathlib import Path

P = Path(__file__).with_name("manuscript_v49.md")
s = P.read_text()


def rep(text, pairs):
    for a, b in pairs:
        n = text.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:100]!r}")
        text = text.replace(a, b)
    return text


def between(text, start, end):
    i = text.index(start)
    return text[i:text.index(end, i)]


# ---------------------------------------------------------------- (1) content edits, old numbering
s = rep(s, [
    ("two commercial analytics platforms differed on estimated monthly visits by 7.5x to 27.1x;",
     "two commercial analytics platforms differed on estimated monthly visits by 7.5x to 27.1x, and by 8.6x to 29.9x with both read worldwide;"),
])

old12 = between(s, "### 1.2 What this paper reports\n", "### 1.3 What this paper does not report")
new12 = """### 1.2 What this paper reports

Each measurement bears on one component of the framework, and each is stated with what it does not show.

1. **The User First Intelligence framework** (Section 1.4, Figure 1): six components (demand surfaces, an industry ontology, a knowledge graph with separated source roles, competency questions, answer surfaces and a Content Gap Score) and two competency-question measures, with an open implementation (Section 12). The score is specified in Appendix B and not evaluated here; Section 11 specifies the studies that would test it.
2. **Measurement 1, two instruments on one prefix** (Sections 5.1 to 5.6), bearing on the premise that volume tools see demand only partly and imprecisely. Two commercial platforms observing one URL prefix from zero differ on estimated visits by 7.5x to 27.1x (8.6x to 29.9x worldwide against worldwide); across twelve sections of one domain the ratio spans 0.20x to 7.24x with no detectable relationship to section age, while the platforms agree on the ordering of sections in 60 of 66 pairs, so no domain-level factor converts one platform's magnitudes into the other's. This is the paper's main empirical result. It does not say which platform is closer to the truth.
3. **Measurement 2, reviews against keyword volume** (Section 5.7), bearing on the first-party demand surfaces. On 37,193 business reviews linked to a 42,994-node keyword taxonomy, the two demand signals agree across branches and diverge across topics, most for complaints. It is one surface in one industry, not the multi-surface study of Section 11.
4. **Measurement 3, what AI answers cite** (Section 5.8), bearing on the answer surfaces. In one vendor's index, across the eleven S&P 500 sectors and eight answer surfaces, Google's AI Overviews and AI Mode give video and community sites about ten times the pooled median share of the other four surfaces, in every sector; of four predictions written before collection, one held, one held in direction only and two failed. It motivates a per-surface term the framework does not yet have.
5. **The deployment as context** (Sections 3.1 and 6 to 9): a 77-day series with a primary checkpoint chosen to precede three identified disturbances, an observation that enumerating pages are cited in AI answers about twice as often as per-entity pages, the deployment's cost, its six enabling conditions, and six lessons stated as what it got wrong. It is a case of the kind of gap the framework targets, not a run of the framework, and no causal claim is made.

"""
s = s.replace(old12, new12)

old290 = next(x for x in s.split("\n") if x.startswith("Earlier versions of this paper, up to and including version 4.1, stated that 290"))
s = rep(s, [(old290, "Earlier versions of this paper stated 290 code pages and an 88-code control group of uncovered codes; both figures were wrong, and fetching every page corrected them (Appendix A).")])

oldwd = next(x for x in s.split("\n") if x.startswith("**A withdrawn comparison.**"))
s = rep(s, [(oldwd, "**A withdrawn comparison.** Earlier versions compared Brand Radar's 17,206 stored answers citing the section with Semrush's 158,100 mentions, a factor of 9.2. That ratio is a scope mismatch, not a divergence: Semrush's companion count of 29,600 cited pages is 68 times the 434 URLs the section holds, so its figures are scoped to the domain rather than the prefix, as Section 5.5 confirms by observation. That comparison, and a claim about platform ordering that rested on a breakdown whose figures did not sum to its total, are withdrawn.")])

s = rep(s, [("**Ethics, data collection and vendor terms.**", "**Ethics and data collection.**")])
oldvend = next(x for x in s.split("\n") if x.startswith("Every vendor figure in Sections 3 and 5.1 to 8 was read"))
s = rep(s, [(oldvend, "The vendor figures in Sections 3, 5.1 to 5.6 and 6 to 8 were read from the vendors' web dashboards under paid subscriptions held for other work (Section 9.1), and the Section 5.8 exports were made through the Ahrefs Brand Radar web interface, using its own export function, under a subscription held by Previsible, a digital marketing agency, with its written permission of 11 October 2026. In both cases the browser was operated by an AI browser assistant (Claude in Chrome, from Anthropic) under the author's direction: it read the displayed figures and, for Section 5.8, clicked the interface's export control for each export. No API was used, and raw vendor exports are not redistributed. The first pilot in Section 5.8 was computed on 7 October 2026 (UTC), before Previsible's permission, by the author's own analytics platform from Brand Radar data accessed through Previsible's account, and is reported in aggregate with no provider named.")])

oldopen = next(x for x in s.split("\n") if x.startswith("**Open items before submission.**"))
s = rep(s, [(oldopen, "**Open items before submission.** The manuscript is not submitted anywhere, including a preprint server, until each of these is closed: (1) the three permission fields above, from a written approval whose scope covers every table and section that uses the organization's figures; (2) the basis on which the author's platform held the pilot data, and the consent of any client for whom it was computed, or removal of the pilot; (3) public release of the Section 5.8 artifacts at a cited commit; (4) an institutional ethics determination for Section 5.7; and (5) withdrawal or correction of the earlier manuscript copies in the public repository that assert the organization's approval or name it.")])

s = rep(s, [
    ("Collection was stopped after two small sectors, Energy and Utilities (14 of 88 exports, 44,463 answers), when the vendor-terms question in Section 12 arose; those rows are stored and unanalyzed, the study's predictions are not yet written, and the remaining exports need the vendor's consent.",
     "Collection was stopped after two small sectors, Energy and Utilities (14 of 88 exports, 44,463 answers); those rows are stored and unanalyzed, and the study's predictions are not yet written."),
    ("**Corrections to earlier versions.** Appendix A is the single record of corrections across versions, including those that change how a figure must be read.",
     "**Corrections to earlier versions.** Appendix A summarizes the corrections that change how a figure or claim must be read; the full version history is released with the paper as a changelog."),
])

# Appendix A: full history to the changelog, summary in the paper
oldA = between(s, "## Appendix A: Version history\n", "## Appendix B")
Path(__file__).resolve().parents[1].joinpath("CHANGELOG_versions.md").write_text(
    "# User First Intelligence: version history (full)\n\nMoved out of the manuscript's Appendix A on 13 October 2026; section numbers are those of each version.\n\n"
    + oldA.split("\n", 1)[1].strip() + "\n")
newA = """## Appendix A: Corrections across versions

This manuscript is the fourth structural version and has been through nine rounds of AI-simulated adversarial review; no human has reviewed it. The full version history is released with it as a changelog. The corrections that change how a figure or claim must be read are these. Early versions (v1 to v2.2) stated that two independent annotators had graded audit samples (none had) and that the ontology had been released (it had not), and asserted organizational permission with the date blank. Later versions corrected the page count from 290 to 381, which removed the 88-code within-class control; moved the primary checkpoint from day 45 to day 37, because the automated link network had arrived by day 45; withdrew a 9.2x AI-answer comparison as a scope mismatch; restated divergence between instruments as a bound on the larger error rather than as error; retracted, after the twelve-prefix cross-section, the hypothesis that the vendor ratio narrows as a section ages; and regenerated Section 5.5 from its released script after it had been written from recollection. In version 4.9 the ninth review round found that the first draft of Section 5.8 and of the disclosures overstated several things: the design was called pre-registered, shares were called citations and lower bounds, the sector claim ignored single-company dominance and company properties, the framework's description did not match its code, artifacts were said to be released before they were, and the use of AI tools was not disclosed. All are corrected in this version.

"""
s = s.replace(oldA, newA)

s = rep(s, [("Sections 5.1 to 5.6 are the paper's primary result. They are reported first because they do not rest on the author's judgment: every figure in them is",
             "This section is the paper's primary result. It is reported first because it does not rest on the author's judgment: every figure in it is")])

# ---------------------------------------------------------------- (2) renumber cross-references
MAP = {"5.7": "6", "5.8": "7", "6": "8", "7": "9", "7.1": "9.1", "7.2": "9.2", "8": "10", "8.1": "10.1",
       "9": "11", "9.1": "11.1", "9.2": "11.2", "10": "12", "11": "13", "12": "14", "13": "15"}
NUM = r"\d+(?:\.\d+)?"
REF = re.compile(rf"\b(Sections?) ({NUM}(?:(?:, | to | and ){NUM})*)")


def remap(m):
    nums = re.sub(NUM, lambda k: MAP.get(k.group(0), k.group(0)), m.group(2))
    return f"{m.group(1)} {nums}"


lines = s.split("\n")
lines = [x if x.startswith("#") else REF.sub(remap, x) for x in lines]
s = "\n".join(lines)

# ---------------------------------------------------------------- (3) headings
s = rep(s, [
    ("## 5 Two instruments on one prefix, and two studies beyond it", "## 5 Measurement 1: two instruments on one prefix"),
    ("### 5.7 Two demand signals on one taxonomy: reviews against keyword volume", "## 6 Measurement 2: reviews against keyword volume on one taxonomy"),
    ("### 5.8 What AI answers cite, across eleven sectors and eight answer surfaces", "## 7 Measurement 3: what AI answers cite, across eleven sectors and eight answer surfaces"),
    ("## 6 The deployment series", "## 8 The deployment series"),
    ("## 7 What the answers cite, and what they do not", "## 9 What the answers cite, and what they do not"),
    ("### 7.1 Enumerating pages", "### 9.1 Enumerating pages"),
    ("### 7.2 Who else is cited", "### 9.2 Who else is cited"),
    ("## 8 The link profile", "## 10 The link profile"),
    ("### 8.1 What the link profile", "### 10.1 What the link profile"),
    ("## 9 What the deployment cost", "## 11 What the deployment cost"),
    ("### 9.1 Cost", "### 11.1 Cost"),
    ("### 9.2 Six lessons", "### 11.2 Six lessons"),
    ("## 10 Threats to validity", "## 12 Threats to validity"),
    ("## 11 What would test", "## 13 What would test"),
    ("## 12 Reproducibility, ethics", "## 14 Reproducibility, ethics"),
    ("## 13 Conclusion", "## 15 Conclusion"),
    ("## Appendix C: Section 5.8 by source type and cell", "## Appendix C: Section 7 by source type and cell"),
    ("**Two pilots.** The first is", "### 7.1 Two pilots\n\nThe first is"),
    ("**Design.** The design was written", "### 7.2 Design\n\nThe design was written"),
    ("**Results, descriptive.** The share going", "### 7.3 Results\n\n**Descriptive.** The share going"),
    ("**Results, the source types fixed before collection.**", "**Source types fixed before collection.**"),
    ("**Results, by sector (exploratory).**", "**By sector (exploratory).**"),
    ("**The predictions written before collection.** Of the four,", "### 7.4 The predictions written before collection\n\nOf the four,"),
    ("**Sensitivity.** None of the following", "### 7.5 Sensitivity\n\nNone of the following"),
    ("**Limits.** The universe is conditional", "### 7.6 Limits\n\nThe universe is conditional"),
])

# ---------------------------------------------------------------- (4) ranges whose meaning changed
s = rep(s, [
    ("The rule governs the deployment universes of Sections 5.1 to 9.", "The rule governs the deployment universes of Sections 5, 8 and 9."),
    ("rather than the area-code section of Sections 5.1 to 8,", "rather than the area-code section of Sections 5 and 8,"),
    ("The organization studied in Sections 5.1 to 9 is one of them,", "The organization studied in Sections 5 and 8 to 10 is one of them,"),
])

P.write_text(s)
print(f"{len(s.split()):,} words")
