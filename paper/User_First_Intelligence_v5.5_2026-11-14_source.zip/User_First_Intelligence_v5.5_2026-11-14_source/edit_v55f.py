"""Version 5.5, sixth edit (14 November 2026): the use of AI agents for the source check is disclosed in Section 14."""
import pathlib

p = pathlib.Path(__file__).with_name("manuscript_v50.md")
s = p.read_text()
a = "and two more the screened sample of Section 1's count of works."
b = ("and two more the screened sample of Section 1's count of works. Before posting, three further agents compared every "
     "reference entry with the source's own record and every sentence that cites a source with the source itself; the "
     "statements they found to say more than a source does were reworded, and their reports are in the source bundle.")
if s.count(a) != 1:
    raise SystemExit(f"REFUSE: {s.count(a)} matches")
if b in s:
    raise SystemExit("REFUSE: already applied")
p.write_text(s.replace(a, b))
print("edit_v55f applied")
