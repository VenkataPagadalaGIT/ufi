"""Version 5.0: fixes from 08_REVIEW/R9_restructure_check.md (F1 to F32) and its three improvements
(one thread stated once with the conclusion in that order; threats to validity by measurement; related
work for Measurement 2), plus the 13 October Semrush re-read. Exact replacements, each must match once.
"""
from pathlib import Path

P = Path(__file__).with_name("manuscript_v49.md")
s = P.read_text()


def rep(pairs):
    global s
    for a, b in pairs:
        n = s.count(a)
        if n != 1:
            raise SystemExit(f"REFUSE: {n} matches for {a[:100]!r}")
        s = s.replace(a, b)


def between(start, end):
    i = s.index(start)
    return s[i:s.index(end, i)]


rep([
    ("Manuscript version 4.9, 13 October 2026.", "Manuscript version 5.0, 13 October 2026."),
    # F5
    ("For a framework whose premise is that volume tools see only part of demand, that number is not incidental: it is the size of the gap the framework's demand layer exists to fill, and it has to be measured before the framework can be evaluated against it.",
     "For a framework whose premise is that volume tools see demand only partly and imprecisely, that number matters: it shows that one tool's magnitudes cannot be trusted alone, which is why the framework does not rely on a single source of demand."),
    # F10 and improvement 1
    ("Each measurement bears on one component of the framework, and each is stated with what it does not show.",
     "Each measurement bears on one part of the framework and is stated with what it does not show: Measurement 1 on the premise that one volume tool's magnitudes do not transfer to another, Measurement 2 on the premise that what people write names different topics from what volume counts, and Measurement 3 on the answer surfaces, which cite different sources."),
    # F9, F17
    ("2. **Measurement 1, two instruments on one prefix** (Sections 5.1 to 5.6), bearing on the premise that volume tools see demand only partly and imprecisely.",
     "2. **Measurement 1, two instruments on one prefix** (Section 5), bearing on the premise that volume tools see demand only partly and imprecisely."),
    ("across twelve sections of one domain the ratio spans 0.20x to 7.24x with no detectable relationship to section age, while the platforms agree on the ordering of sections in 60 of 66 pairs, so no domain-level factor converts one platform's magnitudes into the other's.",
     "across twelve sections of one domain the ratio spans 0.20x to 7.24x with no detectable relationship to section age, so no domain-level factor converts one platform's magnitudes into the other's, while the platforms agree on the ordering of sections in 60 of 66 pairs."),
    # F1
    ("Google's AI Overviews and AI Mode give video and community sites about ten times the pooled median share of the other four surfaces, in every sector;",
     "Google's AI Overviews and AI Mode give video and community sites a larger share than every other surface in every sector, and about ten times their pooled median share (21.3% against 2.1%);"),
    # F2
    ("an observation that enumerating pages are cited in AI answers about twice as often as per-entity pages,",
     "an observation that each of the five most-cited enumerating hub pages is cited in more AI answers than any per-entity page (1.2 to 2.0 times the most-cited one),"),
    ("Section 9.1 reports that state hub pages are cited in AI answers roughly twice as often as the individual code pages they enumerate.",
     "Section 9.1 reports that each of the five most-cited hub pages is cited in more AI answers than any of the individual code pages they enumerate (1.2 to 2.0 times the most-cited code page)."),
    # F20
    ("Section 4 describes a deployment in which the operative distinction was granularity", "Section 8 describes a deployment in which the operative distinction was granularity"),
    # improvement 3: related work for Measurement 2 (references verified on Crossref, 13 October 2026)
    ("one need expressed as thousands of distinct strings.\n",
     "one need expressed as thousands of distinct strings.\n\n**Demand in users' own words.** Customer reviews have long been mined for the product aspects people raise and the opinions they attach to them [Hu & Liu 2004], and search volume has been used as a demand signal in its own right, for example to nowcast economic indicators [Choi & Varian 2012]. Measurement 2 compares the two on one taxonomy: which topics each signal names, rather than how well either predicts an outcome.\n"),
    # F22
    ("Everything in Sections 5 to 9 is an observation.", "Everything in Sections 5 to 11 is an observation."),
    ("The outcome quantities in Section 8 are therefore measured", "The outcome quantities in Sections 8 to 10 are therefore measured"),
    # F26
    ("The ratio labels are Semrush US over Ahrefs, as in Table 2.", "The ratio labels are Semrush US over Ahrefs worldwide, as in Table 2's first ratio column."),
    # F23, F31
    ("### 5.2 Ranking keywords: a factor of two, stable", "### 5.2 Ranking keywords: a factor of two, and three like for like"),
    (" Pages holding at least one position are 441 in Ahrefs. The two instruments agree on rank ordering of pages by traffic and disagree on every level.",
     " Pages holding at least one position are 441 in Ahrefs."),
    # F8, F15
    ("with Semrush's 158,100 mentions, a factor of 9.2.", "with Semrush's 158,100 mentions read on 10 October, a factor of 9.2."),
    ("That comparison, and a claim about platform ordering that rested on a breakdown whose figures did not sum to its total, are withdrawn.",
     "That comparison, and a claim that the two instruments disagree about the ordering of AI answer platforms, which rested on a breakdown whose figures did not sum to its total, are withdrawn."),
    # F21
    ("The Ahrefs figure of 17,206 stored answers on 455 distinct cited pages is reported in Section 8 as a single-instrument count and is not paired with a second reading.",
     "The Ahrefs figure of 17,206 stored answers is reported in Table 5 as a single-instrument count, with its 455 distinct cited pages in Section 3, and is not paired with a second reading."),
    # F16
    ("and Section 13 registered a cross-prefix replication as the test.", "and version 4.0 registered a cross-prefix replication as the test."),
    # F17
    ("rather than the area-code section of Sections 5 and 8,", "rather than the area-code section of Sections 5 and 8 to 11,"),
    ("The organization studied in Sections 5 and 8 to 10 is one of them,", "The organization studied in Sections 5 and 8 to 11 is one of them,"),
    ("Every figure in Sections 5.1 to 5.6 and 8 can be re-read", "Every figure in Sections 5 and 8 to 10 can be re-read"),
    ("The vendor figures in Sections 3, 5.1 to 5.6 and 8 to 10 were read", "The vendor figures in Sections 3, 5 and 8 to 10 were read"),
    # F10
    ("This section is a measurement study that stands apart from the framework: it uses none of the framework's ontology, graph, competency questions or score. It asks one question",
     "This measurement uses none of the framework's machinery (its ontology, graph, competency questions or score); it bears on the framework's answer-surface component. It asks one question"),
    # F30
    ("What this establishes is descriptive and narrow: in one vendor's index,", "**What Measurement 3 establishes.** The result is descriptive and narrow: in one vendor's index,"),
    # F14
    ("Collection was stopped after two small sectors, Energy and Utilities (14 of 88 exports, 44,463 answers); those rows",
     "Collection was stopped after two small sectors, Energy and Utilities (14 of 88 exports, 44,463 answers), a decision taken before any row was examined; those rows"),
    # F29: labels in Section 13
    ("Section 6 is a first run on one surface; the study specified here extends it.", "Measurement 2 (Section 6) is a first run on one surface; the study specified here extends it."),
    ("**A prompt-level replication of Section 7.**", "**A prompt-level replication of Measurement 3 (Section 7).**"),
    ("**A second domain for Section 5.5.**", "**A second domain for Measurement 1 (Section 5.5).**"),
    # F13
    ("with its written permission of 11 October 2026. In both cases the browser", "with its written permission of 11 October 2026 to use the agency's accounts and tools. In both cases the browser"),
    # re-read
    ("it is reported with its read date and is not claimed to be re-readable. The Ahrefs daily series",
     "it is reported with its read date and is not claimed to be re-readable. A re-read of Semrush on 13 October reproduced the July to September figures of Table 2 exactly, in both territories; the October run-rate had moved by about 3% (worldwide 1,910,867, US 1,659,636). The Ahrefs daily series"),
    # F3, F6, F24
    ("operated the browser for every vendor read and export, as stated above, and fetched",
     "operated the browser for the vendor reads and exports, as stated above (the author read Semrush's worldwide keyword count in Section 5.2), and fetched"),
    ("the scripts for Sections 5.5 and 6 are public and those for Section 7 are prepared for release (open item 4).",
     "the script for Section 5.5 is public, and those for Sections 6 and 7 are prepared for release (open item 3)."),
    ("the full version history is released with the paper as a changelog.", "the full version history is in a changelog included with the paper's source files."),
    # F28
    ("the prefixes in Table 4 and the conflict-of-interest statement in Section 12 allow", "the prefixes in Table 4 and the author-independence statement in Section 12 allow"),
    # F18
    ("*Table C1. Share of citation incidences by registered source type and answer surface:", "*Table C1. Share of citation incidences by source type fixed before collection and answer surface:"),
    # references
    ("Chapekis, A., & Lieb, A. (2025, July 22).",
     "Chapekis, A., & Lieb, A. (2025, July 22)."),
])

# references inserted in order
rep([
    ("\n\nEloundou, T., Beutel, A.,",
     "\n\nChoi, H., & Varian, H. (2012). Predicting the present with Google Trends. *Economic Record, 88*(s1), 2–9. https://doi.org/10.1111/j.1475-4932.2012.00809.x\n\nEloundou, T., Beutel, A.,"),
    ("\n\nHuang, M., Goyal, A.,",
     "\n\nHu, M., & Liu, B. (2004). Mining and summarizing customer reviews. In *Proceedings of the Tenth ACM SIGKDD International Conference on Knowledge Discovery and Data Mining (KDD '04)* (pp. 168–177). ACM. https://doi.org/10.1145/1014052.1014073\n\nHuang, M., Goyal, A.,"),
])

# improvement 2: Section 12 by measurement
old12 = between("## 12 Threats to validity\n", "## 13 What would test")
conf = next(x for x in old12.split("\n") if x.startswith("**Confounding, with directions.**"))
sel = next(x for x in old12.split("\n") if x.startswith("**Selection.**"))
auth = next(x for x in old12.split("\n") if x.startswith("**Author independence.**"))
auth = auth.replace("should weight the instrument readings of Sections 5.1 to 5.6, which are independently reproducible from two commercial subscriptions, far above anything else in the paper. Those sections are the primary result partly for that reason.",
                    "should weight the instrument readings of Section 5, which are independently reproducible from two commercial subscriptions, far above anything else in the paper. That section is the primary result partly for that reason.")
new12 = f"""## 12 Threats to validity

**Measurement 1 (Section 5).** Instrumentation is its subject rather than a caveat on it. No outcome is a measured visit. On the area-code prefix the two instruments differ by 7.5x to 27.1x on estimated visits (8.6x to 29.9x worldwide against worldwide), 2.0x on ranking keywords (3.2x worldwide) and 11.4x on referring domains; across twelve prefixes of the same domain the visits ratio runs from 0.20x to 7.24x (8.89x territory-matched). A fourth comparison, on AI answers, is withdrawn in Section 5.3 as a scope mismatch rather than a divergence. One instrument posted a data-reliability notice covering days 65 to 75. "AI Overview citation" has two operational definitions here, which differ by a factor that falls from 2.94 to 1.34; both are reported. The estimated-visit figures are vendor click models that do not distinguish automated from human requests, and a section attracting an automated link network may also attract automated requests; no instrument available here separates them. External validity: twelve prefixes on one domain, one of them followed for 77 days; one vendor pair; one read date for the cross-section; no ground truth. Internal analytics would resolve much of this and are not available.

**Measurement 2 (Section 6).** One first-party surface on one platform in one industry; exact-match linking whose precision has not been hand-checked; relative review dates; and a taxonomy whose labels are themselves search phrasings, which biases the comparison toward agreement. The reviews describe store locations rather than the area-code section.

**Measurement 3 (Section 7).** One vendor's answer index, one country, one collection session, a universe conditional on the sector's companies appearing in the answer, and company sets that one company dominates in several sectors. Section 7.6 lists the rest.

**The deployment (Sections 8 to 11).** {conf.replace("**Confounding, with directions.** ", "Confounding, with directions. ")} {sel.replace("**Selection.** ", "Selection: ")} "Visibility" is not value: no revenue, conversion or impression figure appears in this paper and none should be inferred. External validity: one organization, one industry, one class, a top-authority domain, 77 days, six stated conditions.

{auth}

"""
s = s.replace(old12, new12)

# improvement 1: conclusion in the paper's order
old15 = between("## 15 Conclusion\n", "## References")
new15 = """## 15 Conclusion

User First Intelligence starts from the observation that people ask most of what they want to know somewhere other than a search box, and that the tools which count search demand see only the countable part. The framework goes beyond the website to where the questions are, links them to an industry held under an ontology, keeps structure, coverage, answerability and demand sources in separate roles, with demand held in an index linked to the graph, asks that graph competency questions, and scores where the organization fails to answer. Its score is specified in Appendix B and released as an open implementation that declares thirteen demand-surface types; the score is not evaluated here. The framework is meant to treat the form of the answer as a property to measure rather than assume; Section 9.1 shows why, and the released score does not yet do so.

Measurement 1 is the paper's main result. Two commercial analytics platforms watched the same section from the day it appeared. Over four months they disagreed about its estimated traffic by factors between 7.5 and 27.1 with the territories mismatched, and between 8.6 and 29.9 with both read worldwide; read once, they disagreed about its ranking keywords by a factor of two (three worldwide) and about its referring domains by a factor of eleven. Read on the same day across twelve sections of the same domain, their ratio on estimated visits ran from one fifth to seven times, with no detectable relationship to how old each section was or to how many keywords each vendor had found, while they agreed on which of two sections was larger in 60 of 66 pairs. On this domain the correction factor between the vendors has no fixed sign or size, so a single-vendor study of magnitudes carries a range it cannot bound from its own data, while a single-vendor ranking of sections is usually right in direction. That is why the framework does not rely on one source of demand.

Measurement 2 compared what people write with what a volume tool counts, on one taxonomy. On 37,193 business reviews, the two agreed on the broad shape of demand (+0.78 across branches) and diverged on its topics (+0.19), most for complaints: one in seven unhappy reviews named waiting, which the taxonomy records at 12 searches a month.

Measurement 3 found, in one vendor's index of answers that name the largest companies of the eleven S&P 500 sectors, that the share of citations going to video and community platforms differs most between answer surfaces: a median 21% on Google's AI Overviews and AI Mode against 0.6% to 9.2% on the four other surfaces, higher on every Google view than on every other surface in every sector, while news, government and company sources varied more by sector and two of four predictions written before collection failed. That is why a per-surface term is the framework's next design question.

The deployment underneath these measurements is reported as context. Following the publication of one page per member of a finite enumerable class, templated from a free registry on a top-decile domain that no comparable competitor covered and no one defended, the section held 15,830 ranking positions with nineteen referring domains at day 37, and by day 77 appeared in 17,206 recorded AI answers having earned no editorial link. The pages most cited were the ones that enumerate rather than the ones that answer. What that conjunction depended on, and in what proportion, is not estimated here. Section 13 specifies the multi-platform demand study and the persona study on AI answers that would test the framework's two central claims; only the scoring parameters are locked so far.

"""
s = s.replace(old15, new15)

# Appendix A: F4, F7, F11, F12, F16, version 5.0
rep([
    ("This manuscript is the fourth structural version and has been through nine rounds of AI-simulated adversarial review; no human has reviewed it. The full version history is released with it as a changelog. The corrections that change how a figure or claim must be read are these.",
     "This manuscript has been through nine rounds of AI-simulated adversarial review; no human has reviewed it. The full version history is in a changelog included with the paper's source files. The principal corrections that change how a figure or claim must be read are these."),
    ("and asserted organizational permission with the date blank.",
     "and asserted organizational permission with the date blank; the same unsupported assertion reappeared in the public versions 4.6 to 4.8 and is withdrawn here (open item 5)."),
    ("withdrew a 9.2x AI-answer comparison as a scope mismatch;",
     "withdrew a 9.2x AI-answer comparison as a scope mismatch; relabeled Table 2's October row as a monthly run-rate rather than month-to-date; withdrew a claim that the deployment's results were broad rather than concentrated in a few pages;"),
    ("restated divergence between instruments as a bound on the larger error rather than as error;",
     "restated divergence between instruments as a bound on the larger error rather than as error, and corrected that bound from 13 times to a factor of 5.2;"),
    ("found that the first draft of Section 7 and of the disclosures overstated several things:",
     "found that the first draft of Section 7 (then Section 5.8) and of the disclosures overstated several things, including that the per-surface pilot that preceded the predictions was not reported:"),
    ("All are corrected in this version.", "All are corrected. Version 5.0 restructured the paper around its three measurements (Sections 5 to 7) and stated its single thread in Section 1.2 and the conclusion; no number changed."),
])

P.write_text(s)
cl = Path(__file__).resolve().parents[1] / "CHANGELOG_versions.md"
cl.write_text(cl.read_text().rstrip() + "\n\n**v5.0 (13 October 2026).** Restructured as one paper around three measurements: the instrument comparison (Section 5), reviews against keyword volume (Section 6, formerly 5.7) and what AI answers cite (Section 7, formerly 5.8), with the deployment as context (Sections 8 to 11). Five contributions instead of nine, each mapped to the part of the framework it bears on; threats to validity grouped by measurement; a related-work paragraph for the reviews measurement; the conclusion in the paper's order; Appendix A reduced to the principal corrections, with this changelog holding the full history; Table 2 gained worldwide and estimated US-to-US ratio columns; a 13 October Semrush re-read reproduced Table 2's completed months exactly; the vendor-terms clause analysis was replaced by a factual method statement at the author's decision. No result changed.\n")
print(f"{len(s.split()):,} words")
