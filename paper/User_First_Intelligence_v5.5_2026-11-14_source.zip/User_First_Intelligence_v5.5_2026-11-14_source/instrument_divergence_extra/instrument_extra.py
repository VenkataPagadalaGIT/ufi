"""Round 10 analyses for Measurement 1 (Section 5), on data already held. Not registered.

1. Growth per instrument month on month (Table 2): a constant level bias cancels in a within-instrument
   lift, so the question is whether the two instruments agree on growth.
2. The keyword-universe decomposition under both territory pairings.
3. Ordering agreement by size band across the twelve prefixes (Table 4).
4. The spread of the unmatched visits ratio: geometric SD and an illustrative 95% range.
5. Writes Tables 2, 3, 5 and 6 of the manuscript to 03_DATA as CSV, parsed from the manuscript, so the
   series exists as data and not only as text.
"""
import csv
import math
import re
import statistics
from itertools import combinations
from pathlib import Path

HERE = Path(__file__).resolve().parent
if (HERE.parent / "manuscript_v50.md").is_file():  # the paper's source bundle: the manuscript one level up, the prefix data in ../data
    MS = HERE.parent / "manuscript_v50.md"
    A_CSV = HERE.parent / "data/ahrefs_prefixes_2026-10-12.csv"
    S_CSV = HERE.parent / "data/semrush_prefixes_2026-10-12.csv"
    D = HERE
elif (HERE / "ahrefs_prefixes_2026-10-12.csv").is_file():  # the released data folder: the prefix data beside this script
    MS = None
    A_CSV = HERE / "ahrefs_prefixes_2026-10-12.csv"
    S_CSV = HERE / "semrush_prefixes_2026-10-12.csv"
    D = HERE
else:  # the research project
    ROOT = HERE.parents[1]
    MS = ROOT / "06_MANUSCRIPT/src/manuscript_v50.md"
    A_CSV = ROOT / "03_DATA/instrument_divergence_ahrefs_prefixes_2026-10-12.csv"
    S_CSV = ROOT / "03_DATA/instrument_divergence_semrush_prefixes_2026-10-12.csv"
    D = ROOT / "03_DATA"

# Table 2 (read 10 and 11 October 2026; Semrush completed months re-read unchanged on 13 October)
T2 = {"July": (3862, 100012, 103045), "August": (32281, 876153, 963937),
      "September": (150113, 1534362, 1765077), "October (run-rate)": (215577, 1610284, 1858297)}
print("== 1. Growth per instrument (Table 2)")
ms = list(T2)
for a, b in zip(ms, ms[1:]):
    ga = T2[b][0] / T2[a][0]
    gu = T2[b][1] / T2[a][1]
    gw = T2[b][2] / T2[a][2]
    print(f"  {a} -> {b}: Ahrefs worldwide {ga:.2f}x; Semrush US {gu:.2f}x; Semrush worldwide {gw:.2f}x; "
          f"Ahrefs growth / Semrush US growth {ga / gu:.2f}")

print("\n== 2. Decomposition of the October visits ratio")
v_us = 1610284 / 215577
k_us = 58586 / 29000
print(f"  Semrush US vs Ahrefs worldwide (10-11 Oct): visits {v_us:.2f}x = keywords {k_us:.2f}x x per-keyword {v_us / k_us:.2f}x; "
      f"keyword share of log ratio {math.log(k_us) / math.log(v_us):.0%}")
v_ww = 1858297 / 215577
k_ww = 92300 / 28900
print(f"  worldwide vs worldwide (visits 10-11 Oct; keywords 12 Oct): visits {v_ww:.2f}x = keywords {k_ww:.2f}x x per-keyword {v_ww / k_ww:.2f}x; "
      f"keyword share of log ratio {math.log(k_ww) / math.log(v_ww):.0%}")

print("\n== 3 and 4. Twelve prefixes (Table 4)")
A = {r["prefix"]: r for r in csv.DictReader(A_CSV.open())}
S = {r["prefix"]: r for r in csv.DictReader(S_CSV.open())}
P = list(A)
a = {p: float(A[p]["ahrefs_organic_traffic"]) for p in P}
s = {p: float(S[p]["semrush_organic_traffic_us"]) for p in P}
size = {p: math.sqrt(a[p] * s[p]) for p in P}
bands = {"within 3x": [], "3x to 10x": [], "over 10x": []}
for x, y in combinations(P, 2):
    gap = max(size[x], size[y]) / min(size[x], size[y])
    agree = (a[x] - a[y]) * (s[x] - s[y]) > 0
    key = "within 3x" if gap <= 3 else "3x to 10x" if gap <= 10 else "over 10x"
    bands[key].append(agree)
for k, v in bands.items():
    print(f"  pairs whose sizes (geometric mean of the two estimates) differ {k}: {sum(v)} of {len(v)} ordered alike")
lr = [math.log(s[p] / a[p]) for p in P]
m, sd = statistics.mean(lr), statistics.stdev(lr)
print(f"  unmatched ratio: geometric mean {math.exp(m):.2f}x, geometric SD {math.exp(sd):.2f}; "
      f"normal range on the log scale (describes these twelve; not a prediction) {math.exp(m - 1.96 * sd):.2f}x to {math.exp(m + 1.96 * sd):.2f}x")

print("\n== 5. Tables to CSV")
text = MS.read_text() if MS else ""
for n, name in ((2, "visits_by_month"), (3, "ai_overview_citation_by_month"), (5, "checkpoints"), (6, "intervals")):
    if not MS:
        print(f"  instrument_series_table{n}_{name}.csv: released beside this script (the manuscript, from which this section writes it, is not in this folder)")
        continue
    i = text.index(f"*Table {n}.")
    block = text[i:].split("\n\n")[1]
    rows = [[c.strip().replace("**", "") for c in ln.strip("|").split("|")] for ln in block.splitlines() if ln.startswith("|") and not ln.startswith("|---")]
    out = D / f"instrument_series_table{n}_{name}.csv"
    with out.open("w", newline="") as f:
        csv.writer(f).writerows(rows)
    print(f"  wrote {out.name}: {len(rows) - 1} rows")

# 6. Significance of the ordering agreement, and the pairs the two instruments order oppositely. (Until 14 October
# 2026 these lines were in the saved output without being printed by this file; they are now computed here.)
from scipy.stats import kendalltau, spearmanr
sp, kt = spearmanr([a[p] for p in P], [s[p] for p in P]), kendalltau([a[p] for p in P], [s[p] for p in P])
print(f"\n== 6. Ordering agreement significance: Spearman {sp.statistic:+.3f} (p={sp.pvalue:.1g}); Kendall {kt.statistic:+.3f} (p={kt.pvalue:.2g})")
for x, y in combinations(P, 2):
    if (a[x] - a[y]) * (s[x] - s[y]) < 0:
        ga, gs = max(a[x], a[y]) / min(a[x], a[y]), max(s[x], s[y]) / min(s[x], s[y])
        flag = "three or more times apart on one instrument" if max(ga, gs) >= 3 else "within 3x on both"
        print(f"  ordered oppositely: {x} vs {y}: Ahrefs {a[x]:,.0f} vs {a[y]:,.0f} ({ga:.1f}x); "
              f"Semrush {s[x]:,.0f} vs {s[y]:,.0f} ({gs:.1f}x); {flag}")

# 7. Intervals for the cross-section statistics (independent measurement, 14 October 2026: intervals on every headline).
# Percentile bootstrap over prefixes, 10,000 resamples, fixed seed; with twelve prefixes these are wide by construction.
import random
rng, B = random.Random(20261015), 10_000
sp_b, tau_b, gm_b, gsd_b = [], [], [], []
for _ in range(B):
    idx = [rng.randrange(len(P)) for _ in P]
    xa, xs = [a[P[i]] for i in idx], [s[P[i]] for i in idx]
    r = spearmanr(xa, xs).statistic
    if r == r:
        sp_b.append(r)
    t = kendalltau(xa, xs).statistic
    if t == t:
        tau_b.append(t)
    lrb = [math.log(xs[k] / xa[k]) for k in range(len(idx))]
    gm_b.append(math.exp(statistics.mean(lrb)))
    gsd_b.append(math.exp(statistics.stdev(lrb)))


def ci(v):
    v = sorted(v)
    return v[int(0.025 * len(v))], v[int(0.975 * len(v)) - 1]


print(f"\n== 7. Bootstrap 95% intervals over the twelve prefixes ({B:,} resamples)")
print(f"  Spearman (ordering) {sp.statistic:+.2f} [{ci(sp_b)[0]:+.2f}, {ci(sp_b)[1]:+.2f}]; Kendall {kt.statistic:+.2f} [{ci(tau_b)[0]:+.2f}, {ci(tau_b)[1]:+.2f}]")
print(f"  geometric mean of the ratio {math.exp(m):.2f}x [{ci(gm_b)[0]:.2f}x, {ci(gm_b)[1]:.2f}x]; geometric SD {math.exp(sd):.2f} [{ci(gsd_b)[0]:.2f}, {ci(gsd_b)[1]:.2f}]")

# 8. Table 4's ratio columns and the Section 5.5 figures that analyze.py does not print (independent reproduction of
# 15 October 2026 found them printed by no script). Age in months as analyze.py computes it (to October 2026).
from statistics import NormalDist
print("\n== 8. Table 4 ratios and the remaining Section 5.5 figures")
age = {p: (2026 - int(A[p]["ahrefs_first_traffic_month"][:4])) * 12 + (10 - int(A[p]["ahrefs_first_traffic_month"][5:7])) for p in P}
us = {p: float(A[p]["ahrefs_us_share"]) for p in P}
kr = {p: float(S[p]["semrush_organic_keywords_us"]) / float(A[p]["ahrefs_organic_keywords"]) for p in P}
rd = {p: float(A[p]["ahrefs_ref_domains"]) / float(S[p]["semrush_ref_domains"]) for p in P}
print(f"  {'prefix':22} {'age (months)':>12} {'US share':>9} {'visits ratio':>13} {'matched':>8} {'keyword ratio':>14} {'ref. domains A/S':>17}")
for p in sorted(P, key=lambda x: age[x]):
    print(f"  {p:22} {age[p]:>12} {us[p]:>9.1%} {s[p] / a[p]:>12.2f}x {s[p] / (a[p] * us[p]):>7.2f}x {kr[p]:>13.1f}x {rd[p]:>16.1f}x")
mid = [p for p in P if 84 <= age[p] < 144]
print(f"  sections aged seven to eleven years: {len(mid)}; unmatched ratio {min(s[p] / a[p] for p in mid):.2f}x to {max(s[p] / a[p] for p in mid):.2f}x; "
      f"matched {min(s[p] / (a[p] * us[p]) for p in mid):.2f}x to {max(s[p] / (a[p] * us[p]) for p in mid):.2f}x")
print(f"  prefixes under twenty-one months old: {sum(age[p] < 21 for p in P)}")
krs = sorted(P, key=lambda p: -kr[p])
print(f"  keyword ratio, largest two: {krs[0]} {kr[krs[0]]:.1f}x, {krs[1]} {kr[krs[1]]:.1f}x")
rds = sorted(P, key=lambda p: -rd[p])
print(f"  referring-domain ratio (Ahrefs over Semrush), largest two: {rds[0]} {rd[rds[0]]:.1f}x, {rds[1]} {rd[rds[1]]:.1f}x")
zr, se = math.atanh(0.5), 1 / math.sqrt(len(P) - 3)
nd = NormalDist()
power = nd.cdf(zr / se - 1.96) + nd.cdf(-zr / se - 1.96)
print(f"  power of a two-sided test at 5% to detect a Spearman correlation of 0.5 with {len(P)} prefixes (Fisher approximation): {power:.1%}")

# 9. Significance of the keyword-ratio correlation (independent measurement of 15 October 2026: "the keyword universe
# does not predict the visits ratio" was stronger than +0.17 over twelve and +0.52 over eleven support). Two-sided
# p-values from scipy's t approximation and from 100,000 random permutations, fixed seed.
vr = {p: s[p] / a[p] for p in P}
prng = random.Random(20261015)
print("\n== 9. Keyword ratio against visits ratio across prefixes")
for label, Q in (("all twelve prefixes", P), ("without /local/area-codes/", [p for p in P if p != "/local/area-codes/"])):
    xs, ys = [kr[p] for p in Q], [vr[p] for p in Q]
    res = spearmanr(xs, ys)
    obs, hits, ys2 = abs(res.statistic), 0, list(ys)
    for _ in range(100_000):
        prng.shuffle(ys2)
        hits += abs(spearmanr(xs, ys2).statistic) >= obs - 1e-12
    print(f"  {label} (n={len(Q)}): Spearman {res.statistic:+.2f}; two-sided p {res.pvalue:.2f} (t approximation), "
          f"{hits / 100_000:.2f} (permutation)")

# 10. Ordering agreement by how far apart a pair is on each instrument (review of Appendix E, 3 November 2026: section 3's
# bands are on the geometric mean of the two estimates, while a reader holding one instrument sees only that instrument).
print("\n== 10. Ordering agreement by the factor between a pair on each instrument")
bands = {"more than 3x apart on both instruments": [0, 0], "more than 3x apart on exactly one instrument": [0, 0],
         "within 3x on both instruments": [0, 0]}
for p, q in combinations(P, 2):
    fa, fs = max(a[p], a[q]) / min(a[p], a[q]), max(s[p], s[q]) / min(s[p], s[q])
    n = (fa > 3) + (fs > 3)
    key = "more than 3x apart on both instruments" if n == 2 else "more than 3x apart on exactly one instrument" if n == 1 else "within 3x on both instruments"
    bands[key][1] += 1
    concordant = (a[p] - a[q]) * (s[p] - s[q]) > 0
    bands[key][0] += concordant
    if not concordant:
        print(f"  reversed: {p} and {q}: {fa:.2f}x apart on Ahrefs, {fs:.2f}x on Semrush")
for k, (c, n) in bands.items():
    print(f"  {k}: {c} of {n} pairs concordant")
sub1 = [p for p in P if s[p] / a[p] < 1]
print(f"  prefixes with an unmatched visits ratio below one: {len(sub1)}; smallest keyword ratio among them {min(kr[p] for p in sub1):.1f}x")
